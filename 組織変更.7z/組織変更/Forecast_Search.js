/////////////////////////////////////////////////////
// クライアントスクリプト(Forecast検索画面用)
/////////////////////////////////////////////////////
// 更新履歴
//  Ver.     日付          担当者          変更内容
//  1.0      2002/06/03    竹村正義        新規作成
//  1.1      2002/09/19    Masayoshi.Takemura 予算合計を表示するように変更
//  1.2      2004/03/23    Masayoshi.Takemura ForecastStatus Vのみ表示対応(ソリューション推進部)
//  C00012   2006/02/16    Atsuko.Sashimura   表示列選択項目変更のため、Listのカラムも変更
//  C00019   2006/11/21    Atsuko.Sashimura   OracleSalesのデータを表示
//           2013/05/22    Mari.Suzuki        OppoTypeカラム分割対応
//           2014/03/26    Mari.Suzuki        Booking集計対象外カラム追加
//			 2014/10/14	   Minako.uenaka      言語切り替えボタンが押された際の再読み込み
//           2015/10/30    Mari.Suzuki        ProductName追加対応
//           2016/01/08    Mari.Suzuki        表示項目の全選択/デフォルトに戻す対応
//           2016/06/02    Mari.Suzuki        案件登録日追加対応
//           2016/07/06    Mari.Suzuki        Booking管理組織仕様変更
//           2017/05/10    Mari.Suzuki        ConsCategory追加
/////////////////////////////////////////////////////

//現在の検索タイプ
var title_type_;

//検索タイプ別
function changeSearchType(title_type)
{
	//表示・非表示
	full.style.display = 'none';
	contract.style.display = 'none';
	standard.style.display = 'none';
	standard2.style.display = 'none';
	standard3.style.display = 'none';
	description.style.display = 'none';
	project.style.display = 'none';

	//タイトル色変化
	title_full.style.color='black';
	title_contract.style.color='black';
	title_standard.style.color='black';
	title_project.style.color='black';

	//サブミットしないように無効にする
	document.all.c_org_id.disabled=true;
	document.all.c_prj_org.disabled=true;
	document.all.c_work_status.disabled=true;
	document.all.c_oppo_number.disabled=true;
	document.all.c_bunrui_code.disabled=true;
	document.all.c_proj_code.disabled=true;
	document.all.c_gsi_proj_code.disabled=true;
	document.all.c_proj_name.disabled=true;
	document.all.c_sales.disabled=true;
	document.all.c_proj_owner_id.disabled=true;
	document.all.c_proj_owner_name.disabled=true;
	document.all.c_proj_mgr_id.disabled=true;
	document.all.c_proj_mgr_name.disabled=true;
	document.all.c_end_user_name.disabled=true;
	document.all.c_client_name.disabled=true;
	document.all.c_contract_id.disabled=true;
	document.all.c_classification.disabled=true;
	document.all.c_booking_org.disabled=true;

	//フル検索
	if(title_type=='title_full')
	{
		title_type_ = 'title_full';
		title_full.style.color='red';

		full.style.display = 'block';
		contract.style.display = 'block';
		standard.style.display = 'block';
		standard2.style.display = 'block';
		standard3.style.display = 'block';
		description.style.display = 'block';
		project.style.display = 'block';

		document.all.c_org_id.disabled=false;
		document.all.c_prj_org.disabled=false;
		document.all.c_work_status.disabled=false;
		document.all.c_oppo_number.disabled=false;
		document.all.c_bunrui_code.disabled=false;
		document.all.c_proj_code.disabled=false;
		document.all.c_gsi_proj_code.disabled=false;
		document.all.c_proj_name.disabled=false;
		document.all.c_sales.disabled=false;
		document.all.c_proj_owner_id.disabled=false;
		document.all.c_proj_owner_name.disabled=false;
		document.all.c_proj_mgr_id.disabled=false;
		document.all.c_proj_mgr_name.disabled=false;
		document.all.c_end_user_name.disabled=false;
		document.all.c_client_name.disabled=false;
		document.all.c_contract_id.disabled=false;
		document.all.c_classification.disabled=false;
		document.all.c_booking_org.disabled=false;
	}
	else
	//契約先検索
	if(title_type=='title_contract')
	{
		title_type_ = 'title_contract';
		title_contract.style.color='red';

		contract.style.display = 'block';
		standard.style.display = 'block';
		standard2.style.display = 'block';
		standard3.style.display = 'block';
		description.style.display = 'block';

		document.all.c_org_id.disabled=false;
		document.all.c_prj_org.disabled=false;
		document.all.c_work_status.disabled=false;
		document.all.c_oppo_number.disabled=false;
		document.all.c_bunrui_code.disabled=false;
		document.all.c_proj_code.disabled=false;
		document.all.c_gsi_proj_code.disabled=false;
		document.all.c_sales.disabled=false;
		document.all.c_proj_owner_id.disabled=false;
		document.all.c_proj_owner_name.disabled=false;
		document.all.c_proj_mgr_id.disabled=false;
		document.all.c_proj_mgr_name.disabled=false;
		document.all.c_end_user_name.disabled=false;
		document.all.c_client_name.disabled=false;
	}
	else
	//スタンダード検索
	if(title_type=='title_standard')
	{
		title_type_ = 'title_standard';
		title_standard.style.color='red';

		standard.style.display = 'block';
		standard2.style.display = 'block';
		standard3.style.display = 'block';
		description.style.display = 'block';

		document.all.c_org_id.disabled=false;
		document.all.c_prj_org.disabled=false;
		document.all.c_work_status.disabled=false;
		document.all.c_oppo_number.disabled=false;
		document.all.c_bunrui_code.disabled=false;
		document.all.c_proj_code.disabled=false;
		document.all.c_gsi_proj_code.disabled=false;
		document.all.c_sales.disabled=false;
		document.all.c_proj_owner_id.disabled=false;
		document.all.c_proj_owner_name.disabled=false;
		document.all.c_proj_mgr_id.disabled=false;
		document.all.c_proj_mgr_name.disabled=false;
	}
	else
	//プロジェクト検索
	if(title_type=='title_project')
	{
		title_type_ = 'title_project';
		title_project.style.color='red';
		standard2.style.display = 'block';
		project.style.display = 'block';
		description.style.display = 'block';

		document.all.c_oppo_number.disabled=false;
		document.all.c_bunrui_code.disabled=false;
		document.all.c_proj_code.disabled=false;
		document.all.c_gsi_proj_code.disabled=false;
		document.all.c_proj_name.disabled=false;
	}
	area.style.visibility = 'visible'
}


//組織取得し直しリロード
function getOrg()
{
	//プロジェクト検索時以外組織をFYで変更する
	if(title_type_!='title_project')
	{
		var url = document.location.href.split('&forecastReport_flg');

		//Revenue CI
		for(i=0;i<document.all.c_revenue_ci.length;i++)
		{
			if(document.all.c_revenue_ci[i].checked)
			{
				revenue_ci = i;
			}
		}


		// fStatusかWinProbか
		for(i=0;i<document.all.c_fstatus_winprob.length;i++)
		{
			if(document.all.c_fstatus_winprob[i].checked)
			{
				fstatus_winprob_index = i;
			}
		}

		//URLが渡されていない場合は、記載
		var surl =  new String(url);
		if ( surl.indexOf("CTL_CODE") == -1) {
			var next_url = url[0]           +'?CTL_CODE=showForecastSearch'
											+ '&forecastReport_flg=no';
		}else{
			var next_url = url[0]
											+ '&forecastReport_flg=no'
		}
		next_url = next_url
											+ '&forecast_type=' + title_type_
											+ '&c_revenue_ci=' + revenue_ci
											+ '&c_history_id=' + document.form1.c_history_id.value
											+ '&c_fy=' + document.form1.c_fy.options[document.form1.c_fy.selectedIndex].value
											+ '&c_start_month=' + document.form1.c_start_month.value
											+ '&c_show_length=' + document.form1.c_show_length.value
											+ '&fy12_flg=' + document.form1.fy12_flg.value
											+ '&c_work_status=' + document.form1.c_work_status.value
											+ '&c_oppo_number=' + document.form1.c_oppo_number.value
											+ '&c_bunrui_code=' + document.form1.c_bunrui_code.value
											+ '&c_proj_code=' + document.form1.c_proj_code.value
											+ '&c_gsi_proj_code=' + document.form1.c_gsi_proj_code.value
											+ '&c_proj_name=' + document.form1.c_proj_name.value
											+ '&c_sales=' + document.form1.c_sales.value
											+ '&c_proj_owner_name=' + document.form1.c_proj_owner_name.value
											+ '&c_proj_mgr_name=' + document.form1.c_proj_mgr_name.value
											+ '&c_end_user_name=' + document.form1.c_end_user_name.value
											+ '&c_client_name=' + document.form1.c_client_name.value
											+ '&c_contract_id=' + document.form1.c_contract_id.value
											+ '&c_classification=' + document.form1.c_classification.value
											+ '&c_booking_org=' + document.form1.c_booking_org.value
											+ '&c_fstatus_winprob=' + document.form1.c_fstatus_winprob[fstatus_winprob_index].value
											+ '&c_win_prob_check0=' + document.form1.c_win_prob_check0.checked
											+ '&c_win_prob_check10=' + document.form1.c_win_prob_check10.checked
											+ '&c_win_prob_check20=' + document.form1.c_win_prob_check20.checked
											+ '&c_win_prob_check30=' + document.form1.c_win_prob_check30.checked
											+ '&c_win_prob_check40=' + document.form1.c_win_prob_check40.checked
											+ '&c_win_prob_check50=' + document.form1.c_win_prob_check50.checked
											+ '&c_win_prob_check60=' + document.form1.c_win_prob_check60.checked
											+ '&c_win_prob_check70=' + document.form1.c_win_prob_check70.checked
											+ '&c_win_prob_check80=' + document.form1.c_win_prob_check80.checked
											+ '&c_win_prob_check90=' + document.form1.c_win_prob_check90.checked
											+ '&c_win_prob_check100=' + document.form1.c_win_prob_check100.checked
											+ '&c_book_status_check1=' + document.form1.c_book_status_check1.checked
											+ '&c_book_status_check2=' + document.form1.c_book_status_check2.checked
											+ '&c_book_status_check3=' + document.form1.c_book_status_check3.checked
											+ '&c_book_status_check4=' + document.form1.c_book_status_check4.checked
											+ '&c_book_status_check5=' + document.form1.c_book_status_check5.checked
											+ '&c_book_status_check99=' + document.form1.c_book_status_check99.checked
											+ '&c_rev_status_check1=' + document.form1.c_rev_status_check1.checked
											+ '&c_rev_status_check2=' + document.form1.c_rev_status_check2.checked
											+ '&c_rev_status_check3=' + document.form1.c_rev_status_check3.checked
											+ '&c_rev_status_check4=' + document.form1.c_rev_status_check4.checked
											+ '&c_rev_status_check5=' + document.form1.c_rev_status_check5.checked
											+ '&c_rev_status_check99=' + document.form1.c_rev_status_check99.checked
											+ '&c_sort1=' + document.form1.c_sort1.selectedIndex
											+ '&c_sort2=' + document.form1.c_sort2.selectedIndex
											+ '&c_sort3=' + document.form1.c_sort3.selectedIndex
											+ '&o_proj_code=' + document.form1.o_proj_code.checked
											+ '&o_gsi_proj_code=' + document.form1.o_gsi_proj_code.checked
											+ '&o_oppo_number=' + document.form1.o_oppo_number.checked
											+ '&o_proj_name=' + document.form1.o_proj_name.checked
											+ '&o_client_name=' + document.form1.o_client_name.checked
											+ '&o_ex_cont=' + document.form1.o_ex_cont.checked
											+ '&o_ex_cont_id=' + document.form1.o_ex_cont_id.checked
											+ '&o_reason_for_change=' + document.form1.o_reason_for_change.checked
											+ '&o_end_user_name=' + document.form1.o_end_user_name.checked
											+ '&o_eu_official_name=' + document.form1.o_eu_official_name.checked
											+ '&o_key_acnt=' + document.form1.o_key_acnt.checked
											+ '&o_proj_owner_name=' + document.form1.o_proj_owner_name.checked
											+ '&o_proj_mgr_name=' + document.form1.o_proj_mgr_name.checked
											+ '&o_admi=' + document.form1.o_admi.checked
											+ '&o_latest_mporg=' + document.form1.o_latest_mporg.checked
											+ '&o_classification=' + document.form1.o_classification.checked
											+ '&o_booking_org=' + document.form1.o_booking_org.checked
											+ '&o_classification_4=' + document.form1.o_classification_4.checked
											+ '&o_project_total=' + document.form1.o_project_total.checked
											+ '&o_sa_info=' + document.form1.o_sa_info.checked
											+ '&o_book_status=' + document.form1.o_book_status.checked
											+ '&o_rev_status=' + document.form1.o_rev_status.checked
											+ '&o_work_status=' + document.form1.o_work_status.checked
											+ '&o_org_name=' + document.form1.o_org_name.checked
											+ '&o_pa_cc_id=' + document.form1.o_pa_cc_id.checked
											+ '&o_fpa=' + document.form1.o_fpa.checked
											+ '&o_cont_amount=' + document.form1.o_cont_amount.checked
											+ '&o_own_contract_amount=' + document.form1.o_own_cont_amount.checked
											+ '&o_contract_type=' + document.form1.o_contract_type.checked
											+ '&o_proj_start=' + document.form1.o_proj_start.checked
											+ '&o_proj_end=' + document.form1.o_proj_end.checked
											+ '&o_win_prob=' + document.form1.o_win_prob.checked
											+ '&o_contract_date=' + document.form1.o_contract_date.checked
											+ '&o_contract_quarter=' + document.form1.o_contract_quarter.checked
											+ '&o_opty_creation_date=' + document.form1.o_opty_creation_date.checked
											+ '&o_service_classification=' + document.form1.o_service_classification.checked
											+ '&o_oppo_status=' + document.form1.o_oppo_status.checked
											+ '&o_progress=' + document.form1.o_progress.checked
											+ '&o_module=' + document.form1.o_module.checked
											+ '&o_product_name=' + document.form1.o_product_name.checked
											+ '&o_cons_category=' + document.form1.o_cons_category.checked
											+ '&o_industry=' + document.form1.o_industry.checked
											+ '&o_bunrui=' + document.form1.o_bunrui.checked
											+ '&o_consul_type=' + document.form1.o_consul_type.checked
											+ '&o_revenue_type=' + document.form1.o_revenue_type.checked
											+ '&o_prd_org_name=' + document.form1.o_prd_org_name.checked
											+ '&o_not_book_sum=' + document.form1.o_not_book_sum.checked
											+ '&o_lic_oppo_id=' + document.form1.o_lic_oppo_id.checked
											+ '&o_contract_number=' + document.form1.o_contract_number.checked
											+ '&o_sku_no=' + document.form1.o_sku_no.checked
											+ '&o_sku_span=' + document.form1.o_sku_span.checked
											+ '&o_sku_rev_rec_rule=' + document.form1.o_sku_rev_rec_rule.checked
											+ '&o_update_button=' + document.form1.o_update_button.checked
											+ '&after_change_language=false'
											+ '&o_sum_budget=' + document.form1.o_sum_budget.checked;

		if(document.form1.c_admi != undefined){
			next_url = next_url + '&c_admi=' + document.form1.c_admi.value
					+ '&c_admi_isnull=' + document.form1.c_admi_isnull.checked;
		}
		if(document.form1.c_prj_org != undefined) {
			next_url = next_url	+ '&c_prj_org=' + document.form1.c_prj_org.value;
		}
		if(document.form1.c_org_id != undefined) {
			next_url = next_url	+ '&c_org_id=' + document.form1.c_org_id.value;
		}

		document.location.href = next_url;
	}
}

//FYを変えている途中で開始月を変えると画面が空白になってしまうため
//onChangeされた時には共に使えなくする
//サブミットボタンも
function disableFY()
{
	if(title_type_!='title_project')
	{
		window.document.all.c_fy.disabled=true;
		window.document.all.c_start_month.disabled=true;
		window.document.all.submit_button.disabled=true;
	}
}

//履歴が選択された時は更新ボタン不可
function checkUpdateButton()
{
	if(document.form1.c_history_id.value == '')
	{
		document.form1.o_update_button.disabled = false;
		if(document.form1.to_v_list != undefined){
			// ついでにto_v_listのチェックを外す
			document.form1.to_v_list.disabled = true;
			uncheckToVList();
			changeToVList();
		}
	}
	else
	{
		document.form1.o_update_button.disabled = true;
		if(document.form1.to_v_list != undefined){
			document.form1.to_v_list.disabled = false;
		}
	}
}

// to_v_listのチェックを解除する
function uncheckToVList(){
	document.form1.to_v_list.checked = false;
}

// to_v_listがチェックされたらf-status=disabledに,
// uncheckされたらf-statusを使えるように
function changeToVList(){
	if(document.form1.to_v_list.checked == true) {
		document.form1.c_fstatus_winprob[0].disabled=true;
		document.form1.c_fstatus_winprob[1].disabled=true;
		document.form1.c_fstatus_winprob[2].disabled=true;
		document.form1.c_book_status_check1.disabled=true;
		document.form1.c_book_status_check2.disabled=true;
		document.form1.c_book_status_check3.disabled=true;
		document.form1.c_book_status_check4.disabled=true;
		document.form1.c_book_status_check5.disabled=true;
		document.form1.c_book_status_check99.disabled=true;
		document.form1.c_rev_status_check1.disabled=true;
		document.form1.c_rev_status_check2.disabled=true;
		document.form1.c_rev_status_check3.disabled=true;
		document.form1.c_rev_status_check4.disabled=true;
		document.form1.c_rev_status_check5.disabled=true;
		document.form1.c_rev_status_check99.disabled=true;
		document.form1.c_win_prob_check0.disabled=true;
		document.form1.c_win_prob_check10.disabled=true;
		document.form1.c_win_prob_check20.disabled=true;
		document.form1.c_win_prob_check30.disabled=true;
		document.form1.c_win_prob_check40.disabled=true;
		document.form1.c_win_prob_check50.disabled=true;
		document.form1.c_win_prob_check60.disabled=true;
		document.form1.c_win_prob_check70.disabled=true;
		document.form1.c_win_prob_check80.disabled=true;
		document.form1.c_win_prob_check90.disabled=true;
		document.form1.c_win_prob_check100.disabled=true;
	}else if(document.form1.to_v_list.checked == false){
		document.form1.c_fstatus_winprob[0].disabled=false;
		document.form1.c_fstatus_winprob[1].disabled=false;
		document.form1.c_fstatus_winprob[2].disabled=false;
		changeStatusType();
	}
}

function changeStatusType() {
	if(document.form1.c_fstatus_winprob[0].checked == true) {
		document.form1.c_book_status_check1.disabled=false;
		document.form1.c_book_status_check2.disabled=false;
		document.form1.c_book_status_check3.disabled=false;
		document.form1.c_book_status_check4.disabled=false;
		document.form1.c_book_status_check5.disabled=false;
		document.form1.c_book_status_check99.disabled=false;
		document.form1.c_rev_status_check1.disabled=true;
		document.form1.c_rev_status_check2.disabled=true;
		document.form1.c_rev_status_check3.disabled=true;
		document.form1.c_rev_status_check4.disabled=true;
		document.form1.c_rev_status_check5.disabled=true;
		document.form1.c_rev_status_check99.disabled=true;
		document.form1.c_win_prob_check0.disabled=true;
		document.form1.c_win_prob_check10.disabled=true;
		document.form1.c_win_prob_check20.disabled=true;
		document.form1.c_win_prob_check30.disabled=true;
		document.form1.c_win_prob_check40.disabled=true;
		document.form1.c_win_prob_check50.disabled=true;
		document.form1.c_win_prob_check60.disabled=true;
		document.form1.c_win_prob_check70.disabled=true;
		document.form1.c_win_prob_check80.disabled=true;
		document.form1.c_win_prob_check90.disabled=true;
		document.form1.c_win_prob_check100.disabled=true;
	}else if(document.form1.c_fstatus_winprob[1].checked == true){
		document.form1.c_book_status_check1.disabled=true;
		document.form1.c_book_status_check2.disabled=true;
		document.form1.c_book_status_check3.disabled=true;
		document.form1.c_book_status_check4.disabled=true;
		document.form1.c_book_status_check5.disabled=true;
		document.form1.c_book_status_check99.disabled=true;
		document.form1.c_rev_status_check1.disabled=false;
		document.form1.c_rev_status_check2.disabled=false;
		document.form1.c_rev_status_check3.disabled=false;
		document.form1.c_rev_status_check4.disabled=false;
		document.form1.c_rev_status_check5.disabled=false;
		document.form1.c_rev_status_check99.disabled=false;
		document.form1.c_win_prob_check0.disabled=true;
		document.form1.c_win_prob_check10.disabled=true;
		document.form1.c_win_prob_check20.disabled=true;
		document.form1.c_win_prob_check30.disabled=true;
		document.form1.c_win_prob_check40.disabled=true;
		document.form1.c_win_prob_check50.disabled=true;
		document.form1.c_win_prob_check60.disabled=true;
		document.form1.c_win_prob_check70.disabled=true;
		document.form1.c_win_prob_check80.disabled=true;
		document.form1.c_win_prob_check90.disabled=true;
		document.form1.c_win_prob_check100.disabled=true;
	} else {
		document.form1.c_win_prob_check0.disabled=false;
		document.form1.c_win_prob_check10.disabled=false;
		document.form1.c_win_prob_check20.disabled=false;
		document.form1.c_win_prob_check30.disabled=false;
		document.form1.c_win_prob_check40.disabled=false;
		document.form1.c_win_prob_check50.disabled=false;
		document.form1.c_win_prob_check60.disabled=false;
		document.form1.c_win_prob_check70.disabled=false;
		document.form1.c_win_prob_check80.disabled=false;
		document.form1.c_win_prob_check90.disabled=false;
		document.form1.c_win_prob_check100.disabled=false;
		document.form1.c_book_status_check1.disabled=true;
		document.form1.c_book_status_check2.disabled=true;
		document.form1.c_book_status_check3.disabled=true;
		document.form1.c_book_status_check4.disabled=true;
		document.form1.c_book_status_check5.disabled=true;
		document.form1.c_book_status_check99.disabled=true;
		document.form1.c_rev_status_check1.disabled=true;
		document.form1.c_rev_status_check2.disabled=true;
		document.form1.c_rev_status_check3.disabled=true;
		document.form1.c_rev_status_check4.disabled=true;
		document.form1.c_rev_status_check5.disabled=true;
		document.form1.c_rev_status_check99.disabled=true;
	}
}

/*
 * 検索実行時のチェック
 * CI検索の時、BookingStatus または WinProb% の条件で検索しようとした場合はエラーとする
 *   CI案件には、BookingStatus,WinProb%はないので。
 * エラーがない場合は、excel表示チェックがあれば、target=_blank とし、なければtarget=down にSubmitする。
 */
function checkForm(){
	// CI検索の時
	if(document.form1.c_revenue_ci[1].checked==true){
		// BookSt検索 or WinProb検索の時はエラー
		if( ((document.form1.c_fstatus_winprob[0].checked == true)||(document.form1.c_fstatus_winprob[2].checked == true) ) && (document.form1.c_fstatus_winprob[0].disabled == false) ) {
			alert('CI案件には、BookingStatus,WinProb%はありません。\n検索条件 RevenueStatusをチェックして検索してください。');
			return false;
		}
	}

	//ソートID取得
	document.form1.c_sort1_id.value = document.form1.c_sort1.selectedIndex
	document.form1.c_sort2_id.value = document.form1.c_sort2.selectedIndex
	document.form1.c_sort3_id.value = document.form1.c_sort3.selectedIndex

	//PJ管理組織画面じゃない、かつ　csvにチェックが入っていない場合は、検索結果表示済みとしてクッキーに登録
	if(document.form1.fy12_flg.value!='indusA' && document.form1.csv.checked == false ){
		document.cookie = "after_search=True";
	}

	// SQLインジェクション対応のため入力チェック
	if (!checkMarkNoMsg(window.document.form1.c_proj_code))
	{
		return false;
	}
	if (!checkMarkNoMsg(window.document.form1.c_oppo_number))
	{
		return false;
	}
	if (!checkMarkNoMsg(window.document.form1.c_gsi_proj_code))
	{
		return false;
	}
	if (!checkMarkNoMsg(window.document.form1.c_bunrui_code))
	{
		return false;
	}
	if (!checkMarkNoMsg(window.document.form1.c_proj_name))
	{
		return false;
	}
	if (!checkMarkNoMsg(window.document.form1.c_proj_owner_name))
	{
		return false;
	}
	if (!checkMarkNoMsg(window.document.form1.c_proj_mgr_name))
	{
		return false;
	}
	if (!checkMarkNoMsg(window.document.form1.c_sales))
	{
		return false;
	}
	if (!checkMarkNoMsg(window.document.form1.c_admi))
	{
		return false;
	}
	if (!checkMarkNoMsg(window.document.form1.c_end_user_name))
	{
		return false;
	}
	if (!checkMarkNoMsg(window.document.form1.c_client_name))
	{
		return false;
	}

	window.document.form1.submit();
	return true;
}
// c_admi_isnullがチェックされたら担当アドミ検索ボックス=disabledに,
// uncheckされたらenableに
function admiIsNull(){
	if(document.all.c_admi != undefined){
		if(document.all.c_admi_isnull.checked == true) {
			document.form1.c_admi.disabled=true;
		}else{
			document.form1.c_admi.disabled=false;
		}
	}
	return true;
}

/**
 * 言語切り替えボタンが押された際の処理
 * 値やチェックがが入っている項目はそのまま引き継ぎ
 */
function changeLanguage()
{
	//========================================================
	//言語切り替え時に検索条件・表示条件の値を引き継いで表示させるため、
	//form1（検索ボタンsubmit）の検索条件・表示条件を、fomr2（言語切り替えボタンsubmit）に渡す
	//========================================================
	//----------------------------
	//検索タイプ
	//----------------------------
	document.form2.forecast_type.value = title_type_;
	//----------------------------
	//検索条件テキストボックス
	//----------------------------
	document.form2.c_proj_code.value = document.form1.c_proj_code.value;
	document.form2.c_oppo_number.value = document.form1.c_oppo_number.value;
	document.form2.c_gsi_proj_code.value = document.form1.c_gsi_proj_code.value;
	document.form2.c_proj_name.value = document.form1.c_proj_name.value;
	document.form2.c_sales.value = document.form1.c_sales.value;
	document.form2.c_proj_owner_name.value = document.form1.c_proj_owner_name.value;
	document.form2.c_proj_mgr_name.value = document.form1.c_proj_mgr_name.value;
	document.form2.c_admi.value = document.form1.c_admi.value;
	document.form2.c_end_user_name.value = document.form1.c_end_user_name.value;
	document.form2.c_client_name.value = document.form1.c_client_name.value;
	//----------------------------
	//検索条件プルダウン
	//----------------------------
	document.form2.c_history_id.value = document.form1.c_history_id.options[document.form1.c_history_id.selectedIndex].value;
	document.form2.c_fy.value = document.form1.c_fy.options[document.form1.c_fy.selectedIndex].value;
	document.form2.c_start_month.value = document.form1.c_start_month.options[document.form1.c_start_month.selectedIndex].value;
	document.form2.c_show_length.value = document.form1.c_show_length.options[document.form1.c_show_length.selectedIndex].value;
	document.form2.c_org_id.value = document.form1.c_org_id.options[document.form1.c_org_id.selectedIndex].value;
	document.form2.c_prj_org.value = document.form1.c_prj_org.options[document.form1.c_prj_org.selectedIndex].value;
	document.form2.c_work_status.value = document.form1.c_work_status.options[document.form1.c_work_status.selectedIndex].value;

	document.form2.c_bunrui_code.value = document.form1.c_bunrui_code.value;
	document.form2.c_contract_id.value = document.form1.c_contract_id.value;
	document.form2.c_classification.value = document.form1.c_classification.value;
	document.form2.c_booking_org.value = document.form1.c_booking_org.value;
	//----------------------------
	//検索条件チェックボックス
	//----------------------------
	document.form2.csv.value = document.form1.csv.checked;
	document.form2.isFull.value = document.form1.isFull.checked;
	document.form2.cont_meisai_flg.value = document.form1.cont_meisai_flg.checked;
	document.form2.noDone.value = document.form1.noDone.checked;
	document.form2.noRev.value = document.form1.noRev.checked;
	document.form2.c_admi_isnull.value = document.form1.c_admi_isnull.checked;
	document.form2.to_v_list.value = document.form1.to_v_list.checked;

	//----------------------------
	//Win Probラジオボタン
	//----------------------------
	for(i=0;i<document.form1.c_fstatus_winprob.length;i++)
	{
		if(document.form1.c_fstatus_winprob[i].checked)
		{
			document.form2.c_fstatus_winprob.value = i;
		}
	}

	//Win Prob
	document.form2.c_win_prob_check0.value = document.form1.c_win_prob_check0.checked;
	document.form2.c_win_prob_check10.value = document.form1.c_win_prob_check10.checked;
	document.form2.c_win_prob_check20.value = document.form1.c_win_prob_check20.checked;
	document.form2.c_win_prob_check30.value = document.form1.c_win_prob_check30.checked;
	document.form2.c_win_prob_check40.value = document.form1.c_win_prob_check40.checked;
	document.form2.c_win_prob_check50.value = document.form1.c_win_prob_check50.checked;
	document.form2.c_win_prob_check60.value = document.form1.c_win_prob_check60.checked;
	document.form2.c_win_prob_check70.value = document.form1.c_win_prob_check70.checked;
	document.form2.c_win_prob_check80.value = document.form1.c_win_prob_check80.checked;
	document.form2.c_win_prob_check90.value = document.form1.c_win_prob_check90.checked;
	document.form2.c_win_prob_check100.value = document.form1.c_win_prob_check100.checked;
	//Book Status
	document.form2.c_book_status_check1.value = document.form1.c_book_status_check1.checked;
	document.form2.c_book_status_check2.value = document.form1.c_book_status_check2.checked;
	document.form2.c_book_status_check3.value = document.form1.c_book_status_check3.checked;
	document.form2.c_book_status_check4.value = document.form1.c_book_status_check4.checked;
	document.form2.c_book_status_check5.value = document.form1.c_book_status_check5.checked;
	document.form2.c_book_status_check99.value = document.form1.c_book_status_check99.checked;
	//Revenue Status
	document.form2.c_rev_status_check1.value = document.form1.c_rev_status_check1.checked;
	document.form2.c_rev_status_check2.value = document.form1.c_rev_status_check2.checked;
	document.form2.c_rev_status_check3.value = document.form1.c_rev_status_check3.checked;
	document.form2.c_rev_status_check4.value = document.form1.c_rev_status_check4.checked;
	document.form2.c_rev_status_check5.value = document.form1.c_rev_status_check5.checked;
	document.form2.c_rev_status_check99.value = document.form1.c_rev_status_check99.checked;
	//----------------------------
	//ソートプルダウン
	//----------------------------
	document.form2.c_sort1.value = document.form1.c_sort1.selectedIndex
	document.form2.c_sort2.value = document.form1.c_sort2.selectedIndex
	document.form2.c_sort3.value = document.form1.c_sort3.selectedIndex

	//----------------------------
	//検索結果表示項目チェックボックス群
	//----------------------------
	document.form2.o_prd_org_name.value = document.form1.o_prd_org_name.checked;
	document.form2.o_org_name.value = document.form1.o_org_name.checked;
	document.form2.o_fpa.value = document.form1.o_fpa.checked;
	document.form2.o_work_status.value = document.form1.o_work_status.checked;
	document.form2.o_win_prob.value = document.form1.o_win_prob.checked;
	document.form2.o_book_status.value = document.form1.o_book_status.checked;
	document.form2.o_rev_status.value = document.form1.o_rev_status.checked;
	document.form2.o_oppo_status.value = document.form1.o_oppo_status.checked;
	document.form2.o_progress.value = document.form1.o_progress.checked;
	document.form2.o_proj_code.value = document.form1.o_proj_code.checked;
	document.form2.o_bunrui.value = document.form1.o_bunrui.checked;
	document.form2.o_oppo_number.value = document.form1.o_oppo_number.checked;
	document.form2.o_gsi_proj_code.value = document.form1.o_gsi_proj_code.checked;
	document.form2.o_client_name.value = document.form1.o_client_name.checked;
	document.form2.o_end_user_name.value = document.form1.o_end_user_name.checked;
	document.form2.o_eu_official_name.value = document.form1.o_eu_official_name.checked;
	document.form2.o_key_acnt.value = document.form1.o_key_acnt.checked;
	document.form2.o_proj_name.value = document.form1.o_proj_name.checked;
	document.form2.o_module.value = document.form1.o_module.checked;
	document.form2.o_consul_type.value = document.form1.o_consul_type.checked;
	document.form2.o_revenue_type.value = document.form1.o_revenue_type.checked;
	document.form2.o_classification.value = document.form1.o_classification.checked;
	document.form2.o_booking_org.value = document.form1.o_booking_org.checked;
	document.form2.o_project_total.value = document.form1.o_project_total.checked;
	document.form2.o_classification_4.value = document.form1.o_classification_4.checked;
	document.form2.o_sa_info.value = document.form1.o_sa_info.checked;
	document.form2.o_service_classification.value = document.form1.o_service_classification.checked;
	document.form2.o_sum_budget.value = document.form1.o_sum_budget.checked;
	document.form2.o_proj_start.value = document.form1.o_proj_start.checked;
	document.form2.o_proj_end.value = document.form1.o_proj_end.checked;
	document.form2.o_sales.value = document.form1.o_sales.checked;
	document.form2.o_proj_owner_name.value = document.form1.o_proj_owner_name.checked;
	document.form2.o_proj_mgr_name.value = document.form1.o_proj_mgr_name.checked;
	document.form2.o_contract_date.value = document.form1.o_contract_date.checked;
	document.form2.o_contract_quarter.value = document.form1.o_contract_quarter.checked;
	document.form2.o_opty_creation_date.value = document.form1.o_opty_creation_date.checked;
	document.form2.o_cont_amount.value = document.form1.o_cont_amount.checked;
	document.form2.o_own_cont_amount.value = document.form1.o_own_cont_amount.checked;
	document.form2.o_reason_for_change.value = document.form1.o_reason_for_change.checked;
	document.form2.o_contract_type.value = document.form1.o_contract_type.checked;
	document.form2.o_ex_cont.value = document.form1.o_ex_cont.checked;
	document.form2.o_ex_cont_id.value = document.form1.o_ex_cont_id.checked;
	document.form2.o_update_button.value = document.form1.o_update_button.checked;
	document.form2.o_industry.value = document.form1.o_industry.checked;
	document.form2.o_pa_cc_id.value = document.form1.o_pa_cc_id.checked;
	document.form2.o_admi.value = document.form1.o_admi.checked;
	document.form2.o_latest_mporg.value = document.form1.o_latest_mporg.checked;
	document.form2.o_not_book_sum.value = document.form1.o_not_book_sum.checked;
	document.form2.o_lic_oppo_id.value = document.form1.o_lic_oppo_id.checked;
	document.form2.o_product_name.value = document.form1.o_product_name.checked;
	document.form2.o_cons_category.value = document.form1.o_cons_category.checked;
	document.form2.o_contract_number.value = document.form1.o_contract_number.checked;
	document.form2.o_sku_no.value = document.form1.o_sku_no.checked;
	document.form2.o_sku_span.value = document.form1.o_sku_span.checked;
	document.form2.o_sku_rev_rec_rule.value = document.form1.o_sku_rev_rec_rule.checked;
	//----------------------------
	//Revenue_CIラジオボタン
	//----------------------------
	for(i=0;i<document.form1.c_revenue_ci.length;i++)
	{
		if(document.form1.c_revenue_ci[i].checked)
		{
			document.form2.c_revenue_ci.value = i;
		}
	}

	//========================================================
	//formをsubmit
	//========================================================
	//検索条件と表示条件を引き継ぎ、form2をsubmit
	window.document.form2.submit();

	//検索済みか判定するためにクッキー取得
	if(getCookie('after_search')){
		var setName = getCookie('after_search');
	}
	//検索結果表示済みの場合は検索結果も再読み込みするので、form1をsubmit
	if(setName=='True'){
		//ソートID取得
		document.form1.c_sort1_id.value = document.form1.c_sort1.selectedIndex
		document.form1.c_sort2_id.value = document.form1.c_sort2.selectedIndex
		document.form1.c_sort3_id.value = document.form1.c_sort3.selectedIndex
		window.document.form1.submit();
	}
}

/**
 *　クッキーの値を取得 getCookie(クッキー名);
 */
function getCookie(c_name)
{
	var st="";
	var ed="";
	if(document.cookie.length>0)
	{
		// クッキーの値を取り出す
		st=document.cookie.indexOf(c_name + "=");
		if(st!=-1)
		{
			st=st+c_name.length+1;
			ed=document.cookie.indexOf(";",st);
			if(ed==-1)
			{
				ed=document.cookie.length;
			}
			// 値をデコードして返す
			return unescape(document.cookie.substring(st,ed));
    	}
	}
}

// 全ての表示項目
var allCheckItem = new Array("o_prd_org_name","o_org_name","o_fpa","o_work_status","o_win_prob","o_book_status"
                        ,"o_rev_status","o_oppo_status","o_progress","o_proj_code","o_bunrui","o_oppo_number"
                        ,"o_gsi_proj_code","o_client_name","o_end_user_name","o_eu_official_name","o_key_acnt"
                        ,"o_proj_name","o_module","o_product_name","o_consul_type","o_revenue_type","o_classification"
                        ,"o_booking_org","o_project_total","o_classification_4","o_sa_info","o_service_classification"
                        ,"o_sum_budget","o_proj_start","o_proj_end","o_sales","o_proj_owner_name","o_proj_mgr_name"
                        ,"o_contract_date","o_contract_quarter","o_opty_creation_date","o_cont_amount","o_own_cont_amount","o_reason_for_change"
                        ,"o_contract_type","o_ex_cont","o_ex_cont_id","o_update_button","o_industry","o_pa_cc_id","o_admi"
                        ,"o_latest_mporg","o_not_book_sum","o_lic_oppo_id","o_cons_category","o_contract_number","o_sku_no","o_sku_span","o_sku_rev_rec_rule");
// デフォルトの表示項目
var defaltCheckItem = new Array("o_org_name","o_work_status","o_win_prob","o_book_status","o_rev_status","o_progress"
                           ,"o_proj_code","o_bunrui","o_oppo_number","o_gsi_proj_code","o_client_name","o_end_user_name"
                           ,"o_proj_name","o_sales","o_proj_owner_name","o_proj_mgr_name"
                           ,"o_contract_date","o_own_cont_amount","o_contract_type","o_ex_cont","o_update_button","o_contract_number","o_sku_no");
function allCheck()
{
   // 全てにチェックする
   for (i=0; i<allCheckItem.length; i++)
   {
      document.form1.elements[allCheckItem[i]].checked = true;
   }
}
function defaultCheck()
{
   // 一度全てのチェックを外す
   for (i=0; i<allCheckItem.length; i++)
   {
      document.form1.elements[allCheckItem[i]].checked = false;
   }
   // デフォルトの項目のみチェックする
   for (i=0; i<defaltCheckItem.length; i++)
   {
      document.form1.elements[defaltCheckItem[i]].checked = true;
   }
}

// SQLインジェクション対応
function checkMarkNoMsg(obj)
{
	if(obj != null && obj.value.match(/^[ -/:-@\'\[-\`\{-\~]+$/))
	{
		alert('半角記号は入力できません。');
		return false;
	}
	return true;
}


