/*IF whereOnlyFlg == null || whereOnlyFlg != "1"*/

  /*IF listFlg != "1"*/
select
     /*IF listFlg == "1"*/
       t2.ANKEN_ID
     , t2.RIREKI_ID
     , t2.COUNT
     , t2.SAISYU_SP
     , t2.SAISYU_NET
     /*END*/
     /*IF listFlg != "1"*/
       t2.ANKEN_ID
     , t2.RIREKI_ID
     , t2.ZENKAI_ID
     , t2.ANKEN_REV
     , t2.ANKEN_FLG
     , t2.SALES_CLASS
     , t2.SALES_CLASS_GENKA
     , t2.ANKEN_NAME
     , t2.PLANT_CODE
     , t2.PLANT_NAME
     , t2.STCH_NAME
     , t2.SUB_BU_NAME
     , t2.JISSI_NENDO
     , t2.TEIKEN
     , t2.URIAGE_END
     , t2.SAISYU_SP
     , t2.SAISYU_NET
     , t2.SAISYU_MRITU
     , t2.URIAGE_END_FLG
     , t2.URIAGE_END_FIN
     , CASE WHEN t2.ANKEN_FLG = '1' THEN t2.MAIN_ORDER_NO ELSE t2.ORDER_NO END AS ORDER_NO
     , PACK_MITUMORI_NO.FUNC_GET_MITUMORI_NO(t2.ANKEN_ID, t2.RIREKI_ID, t2.ANKEN_FLG, /*rirekiFlg*/) AS MITUMORI_NO
     , PACK_ANKEN_PERSON.FUNC_GET_ALL_JOB_GROUP_NAME(t2.ANKEN_ID, 'L') AS EIGYO_TAN_JOBGP_NAME
     , CASE WHEN t2.SN_KBN = 'N' THEN 'N発' ELSE NULL END AS SN_KBN_LABEL
     , t2.SN_KBN
     , t2.HAT_URIAGE_YOTEI
     , t2.ATSUKAI_TEAM_CODE
     , t2.ATSUKAI_C_CODE
     , t2.TRADE_NAME
     , t2.KEIYAKU_CUR_CODE
     , t2.SAISYU_SP_GAIKA
     , t2.SAISYU_JYUCHU_RATE
     , t2.SAISYU_URIAGE_RATE
     , t2.JYUCHU_END
     , t2.YOSAN_SP_GAIKA
     , t2.YOSAN_SP
     , t2.YOSAN_NET
     , t2.HAT_SP
     , t2.HAT_NET
     , t2.KEIYAKU_SP_GAIKA
     , t2.KEIYAKU_SP
     , t2.KEIYAKU_RENBAN_MAX
     , t2.URIAGE_SP_GAIKA
     , t2.URIAGE_SP
     , t2.URIAGE_NET
     , t2.JYUCHU_ZAN_SP
     , t2.JYUCHU_ZAN_NET
     , t2.BIKOU_KIKAN
     , t2.CHUKEI_SP
     , t2.CHUKEI_NET
     , t2.INPUT_ICHIRAN_FLG
     , t2.SHIRAJI_FLG
     , t2.HAT_JYUCHU_DATE
     , t2.HAT_SYUKKA_NICHIGEN
     , t2.HAT_KAISYU_YOTEI
     , t2.HAT_EG_EMP_NM
     , t2.SUB_BU_ID
     , t2.BUNRUI_CD
     , t2.TORIATSU_CD
     , t2.EG_TEAM_CD
     , t2.SZ_TEAM_CD
     , t2.GYOTAI
     , t2.HB_C_CD
     , t2.HB_S_CD
     , t2.HB_E_CD
     , t2.SZ_C_CD
     , t2.SZ_S_CD
     , t2.SZ_E_CD
     , (SELECT BUN.BUNRUI_NM FROM N7_BUNRUI_MST BUN WHERE BUN.BUNRUI_CD = t2.BUNRUI_CD) AS BUNRUI_NM
     , t2.HAT_EG_BUKA_RNM
     , t2.JYUCHU_ZAN_ISP
     , t2.JYUCHU_ZAN_TENBAI
     , t2.DIVISION_CODE
     , t2.IS_DELETED
     , t2.BUNKATSU_FLG
     , t2.MITUMORI_KBN
     , t2.MONDAI_FLG
     , t2.ANKEN_RANK
     , t2.CHUNYU_TYOKA_FLG
     , t2.SP_KAKUTEI_FLG
     , t2.NET_KAKUTEI_FLG
     , t2.SYUEKI_FLG
     , t2.STAGE_ID
     , t2.TORIATSU_NM
     , t2.SALES_ROUTE_NM
     , t2.LOSS_CONTROL_FLAG
       /*IF kanrenOrderNoFlg == "1"*/
     , GET_ORDER_NO(t2.ANKEN_ID, t2.RIREKI_ID, /*rirekiFlg*/) AS KANREN_ORDER_NO
       /*END*/
     /*END*/
     /*IF listDispType == "D" && (rirekiIdOld != null || dataKbn == "O")*/
     , B.SAISYU_SP_GAIKA_OLD
     , B.SAISYU_JYUCHU_RATE_OLD
     , B.SAISYU_URIAGE_RATE_OLD
     , B.SAISYU_SP_OLD
     , B.SAISYU_NET_OLD
     , B.JYUCHU_END_OLD
     , B.URIAGE_END_OLD
     , B.SAISYU_MRITU_OLD
     /*END*/
  from (select rownum as rowcnt
             , t.*
          from (
  /*END*/

SELECT
     /*IF listFlg == "1"*/
       0                 AS ANKEN_ID
     , 0                 AS RIREKI_ID
     , COUNT(*)          AS COUNT
     , SUM(A.SAISYU_SP)  AS SAISYU_SP
     , SUM(A.SAISYU_NET) AS SAISYU_NET
     /*END*/
     /*IF listFlg != "1"*/
       A.ANKEN_ID
     , A.RIREKI_ID
     , A.ZENKAI_ID
     , A.ANKEN_REV
     , A.ANKEN_FLG
     , A.SALES_CLASS
     , A.SALES_CLASS_GENKA
     , A.ANKEN_NAME
     , A.PLANT_CODE
     , A.PLANT_NAME
     , A.STCH_NAME
     , A.SUB_BU_NAME
     , A.JISSI_NENDO
     , A.TEIKEN
     , A.URIAGE_END
     , A.SAISYU_SP
     , A.SAISYU_NET
     , A.SAISYU_MRITU
     , A.URIAGE_END_FLG
     , A.URIAGE_END_FIN
     , A.MAIN_ORDER_NO
     , A.ORDER_NO
     , A.SN_KBN
     , A.HAT_URIAGE_YOTEI
     , A.ATSUKAI_TEAM_CODE
     , A.ATSUKAI_C_CODE
     , A.TRADE_NAME
     , A.KEIYAKU_CUR_CODE
     , A.SAISYU_SP_GAIKA
     , A.SAISYU_JYUCHU_RATE
     , A.SAISYU_URIAGE_RATE
     , A.JYUCHU_END
     , A.YOSAN_SP_GAIKA
     , A.YOSAN_SP
     , A.YOSAN_NET
     , A.HAT_SP
     , A.HAT_NET
     , A.KEIYAKU_SP_GAIKA
     , A.KEIYAKU_SP
     , A.KEIYAKU_RENBAN_MAX
     , A.URIAGE_SP_GAIKA
     , A.URIAGE_SP
     , A.URIAGE_NET
     , A.JYUCHU_ZAN_SP
     , A.JYUCHU_ZAN_NET
     , A.BIKOU_KIKAN
     , A.CHUKEI_SP
     , A.CHUKEI_NET
     , A.INPUT_ICHIRAN_FLG
     , A.SHIRAJI_FLG
     , A.HAT_JYUCHU_DATE
     , A.HAT_SYUKKA_NICHIGEN
     , A.HAT_KAISYU_YOTEI
     , A.HAT_EG_EMP_NM
     , A.SUB_BU_ID
     , A.BUNRUI_CD
     , A.TORIATSU_CD
     , A.EG_TEAM_CD
     , A.SZ_TEAM_CD
     , A.GYOTAI
     , A.HB_C_CD
     , A.HB_S_CD
     , A.HB_E_CD
     , A.SZ_C_CD
     , A.SZ_S_CD
     , A.SZ_E_CD
     , A.HAT_EG_BUKA_RNM
     , A.JYUCHU_ZAN_ISP
     , A.JYUCHU_ZAN_TENBAI
     , A.DIVISION_CODE
     , A.IS_DELETED
     , A.BUNKATSU_FLG
     , A.MITUMORI_KBN
     , A.MONDAI_FLG
     , A.ANKEN_RANK
     , A.CHUNYU_TYOKA_FLG
     , A.SP_KAKUTEI_FLG
     , A.NET_KAKUTEI_FLG
     , A.SYUEKI_FLG
     , A.STAGE_ID
     , A.TORIATSU_NM
     , A.SALES_ROUTE_NM
     , A.LOSS_CONTROL_FLAG
     /*END*/
  FROM SYU_/*IF rirekiFlg == "R"*/R_/*END*/GE_BUKKEN_INFO_TBL A
/*END*/


WHERE A.RIREKI_ID IN /*rirekiId*/('0')
/*IF targetAnkenId != null*/
   AND A.ANKEN_ID IN /*targetAnkenId*/('0')
/*END*/

/*IF bookMarkFlg == "1"*/
   AND EXISTS
       ( SELECT 'X'
           FROM SYU_GE_BOOKMARK_TBL GB
          WHERE GB.IDTUID = /*tuid*/
            AND GB.ANKEN_ID = A.ANKEN_ID
       )
   AND A.DIVISION_CODE IN /*divisionCode*/('1')
   AND A.IS_DELETED IN ('0','2')
   AND A.SYUEKI_FLG = '1'
/*END*/

/*IF bookMarkFlg != "1"*/
/*IF syuekiControlKbn != null && syuekiControlKbn != ""*/
  AND A.SYUEKI_FLG = /*syuekiControlKbn*/
/*END*/

/*IF shirajiDelFlg != "1"*/
   AND A.IS_DELETED = '0'
/*END*/
/*IF shirajiDelFlg == "1"*/
   AND A.IS_DELETED IN ('0','2')
/*END*/

/*IF myAnkenFlg != "1"*/
   AND A.DIVISION_CODE IN /*divisionCode*/('1')
/*END*/

/*IF myAnkenFlg == "1"*/
/*IF memberJobGr != null*/
   AND EXISTS
       ( SELECT 'X'
           FROM ANKEN_SYOKUSYU_ROLE_TBL AP
          WHERE AP.ANKEN_NO = A.ANKEN_ID
            AND AP.JOB_GROUP_CODE IN /*memberJobGr*/('1')
            AND ROWNUM <= 1
       )
/*END*/
/*IF myAnkenTuid != null && myAnkenTuid != ""*/
   AND EXISTS
       ( SELECT 'X'
           FROM ANKEN_PERSON_TBL AP
          WHERE AP.ANKEN_NO = A.ANKEN_ID
            AND AP.IDTUID = /*myAnkenTuid*/'1'
            AND ROWNUM <= 1
       )
/*END*/
/*END*/

/*IF subBuId != null*/
   AND A.SUB_BU_ID IN /*subBuId*/('1')
/*END*/

/*IF myTeamFlg != null && myTeamFlg == "T"*/
/*IF myTeamCd != null && myTeamCd != ""*/
   AND (A.ATSUKAI_TEAM_CODE IN /*myTeamCd*/('X') OR A.ATSUKAI_C_CODE IN /*myTeamCd*/('X'))
/*END*/
/*END*/
/*IF myTeamFlg != null && myTeamFlg == "D"*/
/*IF ankenTeamCode != null && ankenTeamCode != ""*/
   AND A.ATSUKAI_TEAM_CODE LIKE /*ankenTeamCode*/ || '%'
/*END*/
/*IF atsukaiCCode != null && atsukaiCCode != ""*/
   AND A.ATSUKAI_C_CODE LIKE /*atsukaiCCode*/ || '%'
/*END*/
/*END*/

/*IF genkaJobgrCode != null && genkaJobgrCode != ""*/
   AND EXISTS
       ( SELECT 'X'
           FROM ANKEN_SYOKUSYU_ROLE_TBL AP
          WHERE AP.ANKEN_NO = A.ANKEN_ID
            AND AP.JOB_GROUP_CODE = /*genkaJobgrCode*/
            AND AP.SYOKUSYU_CODE = 'M'
            AND ROWNUM <= 1
       )
/*END*/


/*IF juInputFlg == 1*/
   AND (
/*END*/

/*IF jyuchuInputFlg == 1*/
  /*IF juInputFlg == 0*/AND/*END*/
           (
              (   1 = 1
              /*IF juchuYmFrom != null && juchuYmFrom != ""*/
              AND TO_CHAR(A.JYUCHU_END, 'YYYYMM') >= /*juchuYmFrom*/
              /*END*/
              /*IF juchuYmTo != null && juchuYmTo != ""*/
              AND TO_CHAR(A.JYUCHU_END, 'YYYYMM') <= /*juchuYmTo*/
              /*END*/
              )
           OR
              (   A.SALES_CLASS = '1'
              /*IF juchuYmFrom != null && juchuYmFrom != ""*/
              AND A.SAIKEISAN_ENDDATE >= /*juchuYmFrom*/
              /*END*/
              /*IF juchuYmTo != null && juchuYmTo != ""*/
              AND TO_CHAR(A.URIAGE_START, 'YYYYMM') <= /*juchuYmTo*/
              /*END*/
              )
           OR
              (   A.SALES_CLASS = '0'
              AND EXISTS
                  (SELECT 'X'
                     FROM SYU_/*IF rirekiFlg == "R"*/R_/*END*/KI_JYUCHU_TOTAL_TBL J
                    WHERE J.ANKEN_ID = A.ANKEN_ID
                      AND J.RIREKI_ID = A.RIREKI_ID
                      /*IF rirekiFlg != "R"*/
                      AND (  (J.DATA_KBN = 'J' AND J.SYUEKI_YM <  /*kanjyoYm*/)
                          OR (J.DATA_KBN = 'M' AND J.SYUEKI_YM >= /*kanjyoYm*/)
                          )
                      /*END*/
                      /*IF rirekiFlg == "R"*/
                      AND (  (J.DATA_KBN = 'J' AND J.SYUEKI_YM <  A.KANJO_YM)
                          OR (J.DATA_KBN = 'M' AND J.SYUEKI_YM >= A.KANJO_YM)
                          )
                      /*END*/
                      /*IF juchuYmFrom != null && juchuYmFrom != ""*/
                      AND J.SYUEKI_YM >= /*juchuYmFrom*/
                      /*END*/
                      /*IF juchuYmTo != null && juchuYmTo != ""*/
                      AND J.SYUEKI_YM <= /*juchuYmTo*/
                      /*END*/
                  )
              )
           )
/*END*/

/*IF juInputFlg == 1*/
        /*IF juYmJoken == "and"*/
        and
        /*END*/
        /*IF juYmJoken != "and"*/
        or
        /*END*/
/*END*/

/*IF uriageYoteiInputFlg == 1*/
  /*IF juInputFlg == 0*/AND/*END*/
           (
              (   1 = 1
              /*IF uriageYoteiYmFrom != null && uriageYoteiYmFrom != ""*/
              AND TO_CHAR(A.URIAGE_END, 'YYYYMM') >= /*uriageYoteiYmFrom*/
              /*END*/
              /*IF uriageYoteiYmTo != null && uriageYoteiYmTo != ""*/
              AND TO_CHAR(A.URIAGE_END, 'YYYYMM') <= /*uriageYoteiYmTo*/
              /*END*/
              )
           OR 
              (   A.SALES_CLASS = '1'
              /*IF uriageYoteiYmFrom != null && uriageYoteiYmFrom != ""*/
              AND A.SAIKEISAN_ENDDATE >= /*uriageYoteiYmFrom*/
              /*END*/
              /*IF uriageYoteiYmTo != null && uriageYoteiYmTo != ""*/
              AND TO_CHAR(A.URIAGE_START, 'YYYYMM') <= /*uriageYoteiYmTo*/
              /*END*/
              )
           OR 
              (   A.SALES_CLASS = '0'
              AND (   EXISTS
                      (SELECT 'X'
                         FROM SYU_/*IF rirekiFlg == "R"*/R_/*END*/KI_SP_TOTAL_TBL S
                        WHERE S.ANKEN_ID = A.ANKEN_ID
                          AND S.RIREKI_ID = A.RIREKI_ID
                          /*IF rirekiFlg != "R"*/
                          AND (  (S.DATA_KBN = 'J' AND S.SYUEKI_YM <  /*kanjyoYm*/)
                              OR (S.DATA_KBN = 'M' AND S.SYUEKI_YM >= /*kanjyoYm*/)
                              )
                          /*END*/
                          /*IF rirekiFlg == "R"*/
                          AND (  (S.DATA_KBN = 'J' AND S.SYUEKI_YM <  A.KANJO_YM)
                              OR (S.DATA_KBN = 'M' AND S.SYUEKI_YM >= A.KANJO_YM)
                              )
                          /*END*/
                          /*IF uriageYoteiYmFrom != null && uriageYoteiYmFrom != ""*/
                          AND S.SYUEKI_YM >= /*uriageYoteiYmFrom*/
                          /*END*/
                          /*IF uriageYoteiYmTo != null && uriageYoteiYmTo != ""*/
                          AND S.SYUEKI_YM <= /*uriageYoteiYmTo*/
                          /*END*/
                      )
                   or EXISTS
                      (SELECT 'X'
                         FROM SYU_/*IF rirekiFlg == "R"*/R_/*END*/KI_NET_TOTAL_TBL S
                        WHERE S.ANKEN_ID = A.ANKEN_ID
                          AND S.RIREKI_ID = A.RIREKI_ID
                          /*IF rirekiFlg != "R"*/
                          AND (  (S.DATA_KBN = 'J' AND S.SYUEKI_YM <  /*kanjyoYm*/)
                              OR (S.DATA_KBN = 'M' AND S.SYUEKI_YM >= /*kanjyoYm*/)
                              )
                          /*END*/
                          /*IF rirekiFlg == "R"*/
                          AND (  (S.DATA_KBN = 'J' AND S.SYUEKI_YM <  A.KANJO_YM)
                              OR (S.DATA_KBN = 'M' AND S.SYUEKI_YM >= A.KANJO_YM)
                              )
                          /*END*/
                          /*IF uriageYoteiYmFrom != null && uriageYoteiYmFrom != ""*/
                          AND S.SYUEKI_YM >= /*uriageYoteiYmFrom*/
                          /*END*/
                          /*IF uriageYoteiYmTo != null && uriageYoteiYmTo != ""*/
                          AND S.SYUEKI_YM <= /*uriageYoteiYmTo*/
                          /*END*/
                      )
                   )
              )

           )
/*END*/

/*IF juInputFlg == 1*/
       )
/*END*/


/*IF uriageStartYmFrom != null && uriageStartYmFrom != ""*/
   AND TO_CHAR(A.URIAGE_START, 'YYYY/MM') >= /*uriageStartYmFrom*/
/*END*/
/*IF uriageStartYmTo != null && uriageStartYmTo != ""*/
   AND TO_CHAR(A.URIAGE_START, 'YYYY/MM') <= /*uriageStartYmTo*/
/*END*/


/*IF salesClass != null && salesClassGenka != null  */
   AND (( A.SALES_CLASS IN /*salesClass*/('1') 
         AND  A.SALES_CLASS_GENKA IS NULL 
        )
       OR A.SALES_CLASS_GENKA = /*salesClassGenka*/'1'
       )
/*END*/

/*IF salesClass == null || salesClassGenka == null */
/*IF salesClass != null*/
   AND ( A.SALES_CLASS IN /*salesClass*/('1') 
         AND A.SALES_CLASS_GENKA IS NULL
        )
/*END*/
/*IF salesClassGenka != null */
   AND A.SALES_CLASS_GENKA = /*salesClassGenka*/'1'
/*END*/
/*END*/






/*IF ankenId != null && ankenId != ""*/
   AND A.ANKEN_ID LIKE UPPER(TO_SINGLE_BYTE(TRIM(/*ankenId*/))) || '%'
/*END*/
/*IF orderNo != null && orderNo != ""*/
   AND (
         (A.MAIN_ORDER_NO LIKE UPPER(TO_SINGLE_BYTE(TRIM(/*orderNo*/))) || '%' AND A.ANKEN_FLG = '1')
       OR
         (A.ORDER_NO LIKE UPPER(TO_SINGLE_BYTE(TRIM(/*orderNo*/))) || '%' AND A.ANKEN_FLG != '1')
       )
/*END*/

/*IF koban != null && koban != ""*/
   AND EXISTS
/*IF rirekiFlg != "R"*/
       ( SELECT 'X'
           FROM SYU_GE_NET_ITEM_TBL K1
          WHERE K1.ANKEN_ID = A.ANKEN_ID
            AND K1.RIREKI_ID = A.RIREKI_ID
            AND K1.ORDER_ITEM LIKE UPPER(TO_SINGLE_BYTE(TRIM(/*koban*/))) || '%'
            AND A.ANKEN_FLG = '0'
            AND ROWNUM <= 1
         UNION ALL
         SELECT 'X'
           FROM SYU_GE_NET_ITEM_TBL K1
          WHERE K1.ANKEN_ID IN
                ( SELECT M.ANKEN_NO
                    FROM ANKEN_MATOME_MAP_TBL M
                   WHERE M.ANKEN_MATOME_NO = A.ANKEN_ID
                     AND A.ANKEN_FLG = '1'
                     AND ROWNUM <= 1
                )
            AND K1.RIREKI_ID = A.RIREKI_ID
            AND K1.ORDER_ITEM LIKE UPPER(TO_SINGLE_BYTE(TRIM(/*koban*/))) || '%'
            AND A.ANKEN_FLG = '1'
            AND ROWNUM <= 1
       )
/*END*/
/*IF rirekiFlg == "R"*/
       ( SELECT 'X'
           FROM SYU_R_GE_NET_ITEM_TBL K1
          WHERE K1.ANKEN_ID = A.ANKEN_ID
            AND K1.RIREKI_ID = A.RIREKI_ID
            AND K1.ORDER_ITEM LIKE UPPER(TO_SINGLE_BYTE(TRIM(/*koban*/))) || '%'
            AND A.ANKEN_FLG = '0'
            AND ROWNUM <= 1
         UNION ALL
         SELECT 'X'
           FROM SYU_R_GE_NET_ITEM_TBL K1
          WHERE K1.ANKEN_ID IN
                ( SELECT M.ANKEN_NO
                   FROM SYU_R_MATOME_ID_TBL M
                  WHERE M.ANKEN_MATOME_NO = A.ANKEN_ID
                    AND M.RIREKI_ID = A.RIREKI_ID
                    AND A.ANKEN_FLG = '1'
                    AND ROWNUM <= 1
                )
            AND K1.RIREKI_ID = A.RIREKI_ID
            AND K1.ORDER_ITEM LIKE UPPER(TO_SINGLE_BYTE(TRIM(/*koban*/))) || '%'
            AND A.ANKEN_FLG = '1'
            AND ROWNUM <= 1
       )
/*END*/
/*END*/

/*IF qno != null && qno != ""*/
   AND (
/*IF rirekiFlg != "R"*/
          (   A.ANKEN_FLG = '0'
          AND A.ANKEN_ID IN
              (SELECT AM1.ANKEN_NO
                 FROM ANKEN_MITUMORI_TBL AM1
                WHERE AM1.MITUMORI_NO LIKE UPPER(TO_SINGLE_BYTE(TRIM(/*qno*/))) || '%'
              )
          )
       OR 
          (   A.ANKEN_FLG = '1'
          AND EXISTS
              (SELECT 'X'
                 FROM ANKEN_MITUMORI_TBL AM1
                    , ANKEN_MATOME_MAP_TBL MM
                WHERE MM.ANKEN_MATOME_NO = A.ANKEN_ID
                  AND AM1.ANKEN_NO = MM.ANKEN_NO
                  AND AM1.MITUMORI_NO LIKE UPPER(TO_SINGLE_BYTE(TRIM(/*qno*/))) || '%'
                  AND ROWNUM <= 1
              )
          )
/*END*/
/*IF rirekiFlg == "R"*/
          (   A.ANKEN_FLG = '0'
          AND A.ANKEN_ID IN
              (SELECT AM1.ANKEN_NO
                 FROM SYU_R_MITSUMORI_TBL AM1
                WHERE AM1.MITUMORI_NO LIKE UPPER(TO_SINGLE_BYTE(TRIM(/*qno*/))) || '%'
                  AND AM1.RIREKI_ID = A.RIREKI_ID
              )
          )
       OR 
          (   A.ANKEN_FLG = '1'
          AND EXISTS
              (SELECT 'X'
                 FROM SYU_R_MITSUMORI_TBL AM1
                    , SYU_R_MATOME_ID_TBL MM
                WHERE MM.ANKEN_MATOME_NO = A.ANKEN_ID
                  AND AM1.RIREKI_ID = MM.RIREKI_ID
                  AND AM1.ANKEN_NO = MM.ANKEN_NO
                  AND AM1.RIREKI_ID = A.RIREKI_ID
                  AND AM1.MITUMORI_NO LIKE UPPER(TO_SINGLE_BYTE(TRIM(/*qno*/))) || '%'
                  AND ROWNUM <= 1
              )
          )
/*END*/
       )
/*END*/

/*IF ankenName != null && ankenName != ""*/
   AND GET_CHANGE_SEARCH_STR(A.ANKEN_NAME) LIKE '%' || GET_CHANGE_SEARCH_STR(/*ankenName*/) || '%'
/*END*/
/*IF tradeName != null && tradeName != ""*/
   AND GET_CHANGE_SEARCH_STR(A.TRADE_NAME) LIKE '%' || GET_CHANGE_SEARCH_STR(/*tradeName*/) || '%'
/*END*/
/*IF stchCode != null && stchCode != ""*/
   AND A.STCH_CODE = /*stchCode*/
/*END*/
/*IF stchName != null && stchName != ""*/
   AND GET_CHANGE_SEARCH_STR(A.STCH_NAME) LIKE '%' || GET_CHANGE_SEARCH_STR(/*stchName*/) || '%'
/*END*/

/*IF eigyoJobGrCodeList != null*/
   AND EXISTS
       ( SELECT 'X'
           FROM ANKEN_SYOKUSYU_ROLE_TBL AP
          WHERE AP.ANKEN_NO = A.ANKEN_ID
            AND AP.JOB_GROUP_CODE IN /*eigyoJobGrCodeList*/('1')
            AND AP.SYOKUSYU_CODE = 'L'
            AND ROWNUM <= 1
       )
/*END*/
/*IF eigyoTeamCodeList != null*/
   AND A.ANKEN_TEAM_CODE IN /*eigyoTeamCodeList*/('X')
/*END*/
/*IF kaisyuYmFlg == "1"*/
   AND (
          (   1 = 1
          /*IF kaisyuYmFrom != null && kaisyuYmFrom != ""*/
          AND TO_CHAR(A.KAISYU_END, 'YYYYMM') >= /*kaisyuYmFrom*/
          /*END*/
          /*IF kaisyuYmTo != null && kaisyuYmTo != ""*/
          AND TO_CHAR(A.KAISYU_END, 'YYYYMM') <= /*kaisyuYmTo*/
          /*END*/
          )
       OR 
          ( EXISTS
            (SELECT 'X' FROM SYU_/*IF rirekiFlg == "R"*/R_/*END*/KI_KAISYU_TBL KAIS
              WHERE KAIS.ANKEN_ID = A.ANKEN_ID
                AND KAIS.RIREKI_ID = A.RIREKI_ID
                /*IF rirekiFlg != "R"*/
                AND (  (KAIS.DATA_KBN = 'J' AND KAIS.SYUEKI_YM <  /*kanjyoYm*/)
                    OR (KAIS.DATA_KBN = 'M' AND KAIS.SYUEKI_YM >= /*kanjyoYm*/)
                    )
                /*END*/
                /*IF rirekiFlg == "R"*/
                AND (  (KAIS.DATA_KBN = 'J' AND KAIS.SYUEKI_YM <  A.KANJO_YM)
                    OR (KAIS.DATA_KBN = 'M' AND KAIS.SYUEKI_YM >= A.KANJO_YM)
                    )
                /*END*/
                /*IF kaisyuYmFrom != null && kaisyuYmFrom != ""*/
                AND KAIS.SYUEKI_YM >= /*kaisyuYmFrom*/
                /*END*/
                /*IF kaisyuYmTo != null && kaisyuYmTo != ""*/
                AND KAIS.SYUEKI_YM <= /*kaisyuYmTo*/
                /*END*/
            )
          )
       )
/*END*/
/*IF uriageShijiFlg != null*/
   AND A.URIAGE_SHIJI_FLG IN /*uriageShijiFlg*/('x')
/*END*/
/*IF uriSyuseiFlg != null && uriSyuseiFlg != ""*/
   AND A.URI_SYUSEI = '1'
/*END*/
/*IF keiyakuKeitaiCd != null && keiyakuKeitaiCd != ""*/
   AND A.KEIYAKU_KEITAI_CD = /*keiyakuKeitaiCd*/
/*END*/


/*IF ankenJyokyoMitKaitoFlg != null && ankenJyokyoMitKaitoFlg != ""*/
   AND A.MIT_KAITO_FLG = '1'
/*END*/
/*IF ankenJyokyoSateiKaitoFlg != null && ankenJyokyoSateiKaitoFlg != ""*/
   AND A.CHOTATU_KAITO_FLG = '1'
/*END*/
/*IF ankenJyokyoMondaiFlg != null && ankenJyokyoMondaiFlg != ""*/
   AND A.MONDAI_FLG = '1'
/*END*/
/*IF ankenJyokyoPotentialFlg != null && ankenJyokyoPotentialFlg != ""*/
   AND A.POTENTIAL_FLG = '1'
/*END*/
/*IF ankenJyokyoMikomiFlg != null && ankenJyokyoMikomiFlg != ""*/
   AND A.MIKOMI_FLG = '1'
/*END*/
/*IF ankenJyokyoKariUriFlg != null && ankenJyokyoKariUriFlg != ""*/
   AND (A.KARI_SP_FLG = '1' or A.KARI_NET_FLG = '1')
/*END*/
/*IF spNetKakuteiFlg == "0"*/
   AND (A.SP_KAKUTEI_FLG = '0' or A.NET_KAKUTEI_FLG = '0')
/*END*/
/*IF spKakuteiFlg == "0"*/
   AND A.SP_KAKUTEI_FLG = '0'
/*END*/
/*IF netKakuteiFlg == "0"*/
   AND A.NET_KAKUTEI_FLG = '0'
/*END*/


/*IF subBu != null*/
   AND A.SUB_BU_ID IN /*subBu*/('1')
/*END*/
/*IF dispKbn == "0"*/
   AND A.ANKEN_FLG = '0'
/*END*/
/*IF dispKbn == "1"*/
   AND (  ( A.ANKEN_FLG = '1' )
       OR (   A.ANKEN_FLG = '0'
          AND A.ANKEN_MATOME_NO IS NULL
          )
       )
/*END*/
/*IF bunruiCd != null && bunruiCd != ""*/
   AND A.BUNRUI_CD =/*bunruiCd*/
/*END*/
/*IF mitumoriKbn != null*/
   AND A.MITUMORI_KBN IN /*mitumoriKbn*/('K')
/*END*/
/*IF site != null && site != ""*/
   AND A.SITE_CD = /*site*/
/*END*/
/*IF plantCode != null && plantCode != ""*/
   AND A.PLANT_CODE = /*plantCode*/
/*END*/
/*IF jissiNendo != null && jissiNendo != ""*/
   AND A.JISSI_NENDO = /*jissiNendo*/
/*END*/
/*IF teiken != null && teiken != ""*/
   AND A.TEIKEN = /*teiken*/
/*END*/
/*IF ispKbn != null*/
   AND A.ISP_KBN IN /*ispKbn*/('1')
/*END*/
/*IF uriageEndFlg != null*/
   AND (  (A.URIAGE_END_FLG IN /*uriageEndFlg*/('1'))
       /*IF uriageTouKanbaiKbn == "1"*/
       OR (A.URIAGE_END_FLG = '2' AND TO_CHAR(A.URIAGE_END_FIN, 'YYYYMM') = /*kanjyoYm*/)
       /*END*/
       )
/*END*/
/*IF eigyoTanJobgrCode != null && eigyoTanJobgrCode != ""*/
   AND EXISTS
       ( SELECT 'X'
           FROM ANKEN_SYOKUSYU_ROLE_TBL AP
          WHERE AP.ANKEN_NO = A.ANKEN_ID
            AND AP.JOB_GROUP_CODE = /*eigyoTanJobgrCode*/
            AND ROWNUM <= 1
       )
/*END*/
/*IF tantoBumonCode != null && tantoBumonCode != ""*/
   AND EXISTS
       ( SELECT 'X'
           FROM ANKEN_SYOKUSYU_ROLE_TBL AP
          WHERE AP.ANKEN_NO = A.ANKEN_ID
            AND AP.DEPT_CODE IN /*tantoBumonCode*/('1')
            AND ROWNUM <= 1
       )
/*END*/
/*IF hatSyukkaNichigenFrom != null && hatSyukkaNichigenFrom != ""*/
   AND TO_CHAR(A.HAT_SYUKKA_NICHIGEN, 'YYYY/MM') >= /*hatSyukkaNichigenFrom*/
/*END*/
/*IF hatSyukkaNichigenTo != null && hatSyukkaNichigenTo != ""*/
   AND TO_CHAR(A.HAT_SYUKKA_NICHIGEN, 'YYYY/MM') <= /*hatSyukkaNichigenTo*/
/*END*/
/*IF hatKaisyuYoteiFrom != null && hatKaisyuYoteiFrom != ""*/
   AND TO_CHAR(A.HAT_KAISYU_YOTEI, 'YYYY/MM') >= /*hatKaisyuYoteiFrom*/
/*END*/
/*IF hatKaisyuYoteiTo != null && hatKaisyuYoteiTo != ""*/
   AND TO_CHAR(A.HAT_KAISYU_YOTEI, 'YYYY/MM') <= /*hatKaisyuYoteiTo*/
/*END*/
/*IF ankenRank != null*/
   AND A.ANKEN_RANK IN /*ankenRank*/('X')
/*END*/
/*IF aNo != null && aNo != ""*/
   AND A.A_NO LIKE /*aNo*/ || '%'
/*END*/
/*IF snKbn != null*/
   AND A.SN_KBN IN /*snKbn*/('X')
/*END*/
/*IF kouOtsuKbn != null*/
   AND A.KOU_OTSU_KBN IN /*kouOtsuKbn*/('1')
/*END*/
/*IF gyotai != null && gyotai != ""*/
   AND A.GYOTAI = /*gyotai*/
/*END*/
/*IF spFrom != null */
   AND A.SAISYU_SP >= /*spFrom*/
/*END*/
/*IF spTo != null */
   AND A.SAISYU_SP <= /*spTo*/
/*END*/
/*IF netFrom != null */
   AND A.SAISYU_NET >= /*netFrom*/
/*END*/
/*IF netTo != null */
   AND A.SAISYU_NET <= /*netTo*/
/*END*/
/*IF mrituFrom != null */
   AND A.SAISYU_MRITU >= /*mrituFrom*/
/*END*/
/*IF mrituTo != null */
   AND A.SAISYU_MRITU <= /*mrituTo*/
/*END*/
/*IF juchuZanFlg == "1"*/
   AND A.JYUCHU_ZAN_FLG = '1'
/*END*/
/*IF stageId != null && stageId != ""*/
   AND A.STAGE_ID = /*stageId*/
/*END*/
/*END*/


/*IF listFlg != "1" && (whereOnlyFlg == null || whereOnlyFlg != "1")*/
ORDER BY /*IF sort1 == "ankenCode"*/
         A.ANKEN_ID
         /*END*/
         /*IF sort1 == "orderNo"*/
         A.ORDER_NO
         /*END*/
         /*IF sort1 == "plantCode"*/
         A.PLANT_CODE
         /*END*/
         /*IF sort1 == "subBu"*/
         A.SUB_BU_ID
         /*END*/
         /*IF sort1 == "eigyoTanJobgrCode"*/
         A.ANKEN_ID
         /*END*/
         /*IF sort1 == "uriageKbn"*/
         A.SALES_CLASS
         /*END*/
         /*IF sort1 == "uriageYoteiYm"*/
         DECODE(A.URIAGE_END_FLG, '2', A.URIAGE_END_FIN, A.URIAGE_END)
         /*END*/
         /*IF sort1 == "kaiyuYm"*/
         A.KAISYU_END
         /*END*/
         /*IF sort1 == "sp"*/
         A.SAISYU_SP
         /*END*/
         /*IF sort1 == "net"*/
         A.SAISYU_NET
         /*END*/
         /*IF sort1Kbn == "1"*/
         DESC
         /*END*/

         /*IF sort2 == "ankenCode"*/
         , A.ANKEN_ID
         /*END*/
         /*IF sort2 == "orderNo"*/
         , A.ORDER_NO
         /*END*/
         /*IF sort2 == "plantCode"*/
         , A.PLANT_CODE
         /*END*/
         /*IF sort2 == "subBu"*/
         , SUB_BU_ID
         /*END*/
         /*IF sort2 == "eigyoTanJobgrCode"*/
         , ANKEN_ID
         /*END*/
         /*IF sort2 == "uriageKbn"*/
         , SALES_CLASS
         /*END*/
         /*IF sort2 == "uriageYoteiYm"*/
         , DECODE(A.URIAGE_END_FLG, '2', A.URIAGE_END_FIN, A.URIAGE_END)
         /*END*/
         /*IF sort2 == "kaiyuYm"*/
         , A.KAISYU_END
         /*END*/
         /*IF sort2 == "sp"*/
         , A.SAISYU_SP
         /*END*/
         /*IF sort2 == "net"*/
         , A.SAISYU_NET
         /*END*/
         /*IF sort2Kbn == "1"*/
         DESC
         /*END*/
         , A.ANKEN_ID

               ) t
       ) t2


    /*IF listDispType == "D" && (rirekiIdOld != null || dataKbn == "O")*/
         LEFT OUTER JOIN
       (SELECT C.ANKEN_ID
             , C.RIREKI_ID
             , C.SAISYU_SP_GAIKA AS SAISYU_SP_GAIKA_OLD
             , C.SAISYU_JYUCHU_RATE AS SAISYU_JYUCHU_RATE_OLD
             , C.SAISYU_URIAGE_RATE AS SAISYU_URIAGE_RATE_OLD
             , C.SAISYU_SP AS SAISYU_SP_OLD
             , C.SAISYU_NET AS SAISYU_NET_OLD
             , C.JYUCHU_END AS JYUCHU_END_OLD
             , C.URIAGE_END AS URIAGE_END_OLD
             , C.SAISYU_MRITU AS SAISYU_MRITU_OLD
          FROM SYU_R_GE_BUKKEN_INFO_TBL C
         WHERE 1 = 1
           /*IF rirekiIdOld != null*/
           AND C.RIREKI_ID IN /*rirekiIdOld*/('0')
           /*END*/
       ) B
        ON (B.ANKEN_ID = t2.ANKEN_ID /*IF dataKbn == "O"*/AND B.RIREKI_ID = t2.ZENKAI_ID/*END*/)
    /*END*/
    
    /*IF offset != null && end != null*/
where t2.rowcnt between /*offset*/ and /*end*/
    /*END*/
/*END*/
