SELECT A.ANKEN_ID
     , A.SALES_CLASS
     , A.RIREKI_ID
  FROM SYU_GE_BUKKEN_INFO_TBL A
 WHERE A.RIREKI_ID = 0
   AND A.SYUEKI_FLG = '1'
   AND A.IS_DELETED IN ('0', '2')
/*IF kbn == "0"*/
   AND A.ANKEN_ID = UPPER(TO_SINGLE_BYTE(TRIM(/*no*/)))
/*END*/
/*IF kbn == "1"*/
   AND A.ORDER_NO = UPPER(TO_SINGLE_BYTE(TRIM(/*no*/)))
/*END*/
/*IF kbn == "2"*/
   AND (
          (   A.ANKEN_FLG = '0'
          AND A.ANKEN_ID IN
              (SELECT AM1.ANKEN_NO
                 FROM ANKEN_MITUMORI_TBL AM1
                WHERE AM1.MITUMORI_NO = UPPER(TO_SINGLE_BYTE(TRIM(/*no*/)))
              )
          )
       )
/*END*/
/*IF kbn == "3"*/
   AND A.OLD_T_ANKEN_NO = /*no*/
/*END*/
/*IF divisionCode != null*/
   AND A.DIVISION_CODE IN /*divisionCode*/('1')
/*END*/
/*IF ankenFlg != null && ankenFlg != ""*/
   AND A.ANKEN_FLG = /*ankenFlg*/
/*END*/