SELECT A.*
  FROM SYU_/*IF rirekiFlg == "R"*/R_/*END*/GE_BUKKEN_INFO_TBL A
 WHERE A.ANKEN_ID = /*ankenId*/
   AND A.RIREKI_ID = /*rirekiId*/