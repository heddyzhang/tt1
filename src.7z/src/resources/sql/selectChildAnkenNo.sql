SELECT A.ANKEN_MATOME_NO
     , A.ANKEN_NO
  FROM /*IF rirekiFlg == "R"*/
       SYU_R_MATOME_ID_TBL A
       /*END*/
       /*IF rirekiFlg != "R"*/
       ANKEN_MATOME_MAP_TBL A
       /*END*/ 
 WHERE A.ANKEN_MATOME_NO = /*ankenId*/
/*IF rirekiFlg == "R"*/
   AND A.RIREKI_ID = /*rirekiId*/
/*END*/
/*IF noOrderNoFlg == "1"*/
   AND EXISTS
       (SELECT 'X' FROM SYU_/*IF rirekiFlg == "R"*/R_/*END*/GE_BUKKEN_INFO_TBL B1
         WHERE B1.ANKEN_ID = A.ANKEN_NO
           AND B1.RIREKI_ID = /*rirekiId*/
           AND (B1.ORDER_NO IS NULL or B1.STAGE_ID = 5))
/*END*/
ORDER BY A.ANKEN_NO