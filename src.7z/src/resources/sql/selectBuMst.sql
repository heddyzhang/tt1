SELECT *
  FROM BU_MST
 WHERE BU_CODE IS NOT NULL
   AND BU_NAME IS NOT NULL
   AND SBU_CODE IS NOT NULL
   AND SBU_NAME IS NOT NULL
   AND (AVAIL_FROM <= SYSDATE)
   AND (AVAIL_TO IS NULL OR AVAIL_TO > SYSDATE)
   AND IS_DELETED = 0
/*IF divisionCode != null*/
   AND DIVISION_CODE IN /*divisionCode*/('1')
/*END*/
/*IF sbuCode != null && sbuCode != ""*/
   AND SBU_CODE = /*sbuCode*/
/*END*/
/*IF buName != null && buName != ""*/
   AND BU_NAME = /*buName*/
/*END*/
/*IF sbuCodeList != null*/
   AND SBU_CODE IN /*sbuCodeList*/('1')
/*END*/
ORDER BY DIVISION_CODE
       , BU_CODE
       , SBU_CODE
