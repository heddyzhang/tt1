INSERT INTO SYU_SA_SP_CUR_TBL A
( A.ANKEN_ID
, A.RIREKI_ID
, A.DATA_KBN
, A.CURRENCY_CODE
/*IF keiyakuRate != null && keiyakuRate != ""*/
, A.KEIYAKU_RATE
/*END*/
/*IF keiyakAmount != null && keiyakAmount != ""*/
, A.KEIYAKU_AMOUNT
/*END*/
/*IF (keiyakuRate != null && keiyakuRate != "") && (keiyakAmount != null && keiyakAmount != "")*/
, A.KEIYAKU_ENKA_AMOUNT
/*END*/
, A.CREATED_AT
, A.CREATED_BY
, A.UPDATED_AT
, A.UPDATED_BY
)
SELECT
  /*ankenId*/
, /*rirekiId*/
, /*dataKbn*/
, /*currencyCode*/ 
/*IF keiyakuRate != null && keiyakuRate != ""*/
, /*keiyakuRate*/
/*END*/
/*IF keiyakAmount != null && keiyakAmount != ""*/
, /*keiyakAmount*/
/*END*/
/*IF (keiyakuRate != null && keiyakuRate != "") && (keiyakAmount != null && keiyakAmount != "")*/
, /*keiyakAmount*/ * /*keiyakuRate*/
/*END*/
, /*createdAt*/
, /*createdBy*/
, /*updatedAt*/
, /*updatedBy*/
FROM DUAL
WHERE NOT EXISTS
      (SELECT 'X' FROM SYU_SA_SP_CUR_TBL B
        WHERE B.ANKEN_ID = /*ankenId*/
          AND B.RIREKI_ID = /*rirekiId*/
          AND B.DATA_KBN = /*dataKbn*/
          AND B.CURRENCY_CODE = /*currencyCode*/)