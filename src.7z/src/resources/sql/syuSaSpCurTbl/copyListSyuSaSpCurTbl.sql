SELECT T.*
FROM (
SELECT NVL(A.ANKEN_ID, B.ANKEN_ID) AS ANKEN_ID
     , /*geRirekiId*/ AS RIREKI_ID
     , /*fromDataKbn*/ AS DATA_KBN
     , NVL(A.CURRENCY_CODE, B.CURRENCY_CODE) AS CURRENCY_CODE
     , A.KEIYAKU_RATE
     , A.KEIYAKU_AMOUNT
     , (SELECT CM.DISP_SEQ FROM SYU_CUR_MST CM WHERE CM.CURRENCY_CODE = NVL(A.CURRENCY_CODE, B.CURRENCY_CODE)) AS DISP_SEQ
  FROM (SELECT A.ANKEN_ID
             , A.CURRENCY_CODE
             , A.KEIYAKU_RATE
             , A.KEIYAKU_AMOUNT
          FROM SYU_/*IF fromRirekiFlg == "R"*/R_/*END*/SA_SP_CUR_TBL A
         WHERE A.ANKEN_ID = /*ankenId*/
           AND A.RIREKI_ID = /*fromRirekiId*/
           AND A.DATA_KBN = /*fromDataKbn*/) A

       FULL OUTER JOIN

       (SELECT B.ANKEN_ID
             , B.CURRENCY_CODE
          FROM SYU_SA_SP_CUR_TBL B
         WHERE B.ANKEN_ID = /*ankenId*/
           AND B.RIREKI_ID = /*rirekiId*/
           AND B.DATA_KBN IN /*toDataKbnList*/('x')
        GROUP BY B.ANKEN_ID, B.CURRENCY_CODE) B

       ON (A.ANKEN_ID = B.ANKEN_ID AND A.CURRENCY_CODE = B.CURRENCY_CODE)
) T
ORDER BY T.DISP_SEQ