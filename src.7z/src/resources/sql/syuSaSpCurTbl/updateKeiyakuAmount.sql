MERGE   INTO    SYU_SA_SP_CUR_TBL   SA
USING
(
    SELECT  /*ankenId*/ AS  ANKEN_ID
    ,/*rirekiId*/       AS  RIREKI_ID
    ,/*dataKbn*/        AS  DATA_KBN
    ,/*currencyCode*/   AS  CURRENCY_CODE
    FROM    DUAL
)   CHK
ON
(
    SA.ANKEN_ID=CHK.ANKEN_ID
AND SA.RIREKI_ID=CHK.RIREKI_ID
AND SA.DATA_KBN=CHK.DATA_KBN
AND SA.CURRENCY_CODE=CHK.CURRENCY_CODE
)
WHEN    MATCHED THEN
UPDATE
SET KEIYAKU_RATE=/*keiyakuRate*/
    ,KEIYAKU_AMOUNT=/*keiyakuAmount*/
    ,KEIYAKU_ENKA_AMOUNT=/*keiyakuAmount*/ * /*keiyakuRate*/
    ,UPDATED_AT=/*updatedAt*/
    ,UPDATED_BY=/*updatedBy*/
WHEN    NOT MATCHED THEN
INSERT
(
    ANKEN_ID
    ,RIREKI_ID
    ,DATA_KBN
    ,CURRENCY_CODE
    ,KEIYAKU_RATE
    ,KEIYAKU_AMOUNT
    ,KEIYAKU_ENKA_AMOUNT
    ,CREATED_AT
    ,CREATED_BY
    ,UPDATED_AT
    ,UPDATED_BY
)
VALUES
(
    /*ankenId*/
    ,/*rirekiId*/
    ,/*dataKbn*/
    ,/*currencyCode*/
    ,/*keiyakuRate*/
    ,/*keiyakuAmount*/
    ,/*keiyakuAmount*/ * /*keiyakuRate*/
    ,/*createdAt*/
    ,/*createdBy*/
    ,/*updatedAt*/
    ,/*updatedBy*/
)
WHERE   /*keiyakuRate*/ IS NOT NULL
OR     /*keiyakuAmount*/   IS NOT NULL
