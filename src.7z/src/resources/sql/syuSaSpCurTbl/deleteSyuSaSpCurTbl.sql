DELETE SYU_SA_SP_CUR_TBL A
 WHERE A.ANKEN_ID = /*ankenId*/
   AND A.RIREKI_ID = /*rirekiId*/
/*IF dataKbn != null && dataKbn != ""*/
   AND A.DATA_KBN = /*dataKbn*/
/*END*/
/*IF currencyCode != null && currencyCode != ""*/
   AND A.CURRENCY_CODE = /*currencyCode*/
/*END*/