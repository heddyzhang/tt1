SELECT T.ANKEN_ID
     , T.RIREKI_ID
     , T.SYUEKI_YM
     , T.DATA_KBN
     , CASE WHEN T.DATA_KBN = 'J' AND T.SYUEKI_YM = /*syuekiYm*/ THEN 'kikan_ikkan_diff'
            WHEN T.DATA_KBN = 'J' THEN 'fix_jisseki'
            ELSE NULL
       END AS CLASS_NAME
     , TO_CHAR(TO_DATE(T.SYUEKI_YM, 'YYYY/MM'), 'YYYY/MM') AS SYUEKI_YM_DATE
     , '0' as DISP_ADD_FLG
     , (SELECT KA.KAISYU_KBN FROM SYU_/*IF rirekiFlg == "R"*/R_/*END*/KI_KAISYU_TBL KA 
         WHERE KA.ANKEN_ID = T.ANKEN_ID AND KA.RIREKI_ID = T.RIREKI_ID AND KA.DATA_KBN = T.DATA_KBN AND KA.SYUEKI_YM = T.SYUEKI_YM AND ROWNUM <= 1) AS KAISYU_KBN
  FROM (SELECT ANKEN_ID
             , RIREKI_ID
             , DATA_KBN
             , SYUEKI_YM
             , SUBSTR(SYUEKI_YM, 7) AS END_WORD
          FROM /*IF rirekiFlg == "R"*/
               SYU_R_KI_SP_TOTAL_TBL
               /*END*/
               /*IF rirekiFlg != "R"*/
               SYU_KI_SP_TOTAL_TBL
               /*END*/ 
         WHERE ANKEN_ID = /*ankenId*/
           AND RIREKI_ID = /*rirekiId*/
           AND (  (   DATA_KBN = 'J'
                  /*IF rirekiFlg == "R"*/
                  AND SYUEKI_YM < /*syuekiYm*/
                  /*END*/
                  /*IF rirekiFlg != "R"*/
                  AND SYUEKI_YM <= /*syuekiYm*/
                  /*END*/
                  )
               OR (DATA_KBN = 'M' AND SYUEKI_YM >= /*syuekiYm*/)
               )
        UNION ALL
        SELECT ANKEN_ID
             , RIREKI_ID
             , DATA_KBN
             , SYUEKI_YM
             , SUBSTR(SYUEKI_YM, 7) AS END_WORD
          FROM /*IF rirekiFlg == "R"*/
               SYU_R_KI_NET_TOTAL_TBL
               /*END*/
               /*IF rirekiFlg != "R"*/
               SYU_KI_NET_TOTAL_TBL
               /*END*/ 
         WHERE ANKEN_ID = /*ankenId*/
           AND RIREKI_ID = /*rirekiId*/
           AND (  (   DATA_KBN = 'J'
                  /*IF rirekiFlg == "R"*/
                  AND SYUEKI_YM < /*syuekiYm*/
                  /*END*/
                  /*IF rirekiFlg != "R"*/
                  AND SYUEKI_YM <= /*syuekiYm*/
                  /*END*/
                  )
               OR (DATA_KBN = 'M' AND SYUEKI_YM >= /*syuekiYm*/)
               )
        UNION ALL
        SELECT ANKEN_ID
             , RIREKI_ID
             , DATA_KBN
             , SYUEKI_YM
             , SUBSTR(SYUEKI_YM, 7) AS END_WORD
          FROM /*IF rirekiFlg == "R"*/
               SYU_R_KI_JYUCHU_TOTAL_TBL
               /*END*/
               /*IF rirekiFlg != "R"*/
               SYU_KI_JYUCHU_TOTAL_TBL
               /*END*/ 
         WHERE ANKEN_ID = /*ankenId*/
           AND RIREKI_ID = /*rirekiId*/
           AND (  (   DATA_KBN = 'J'
                  /*IF rirekiFlg == "R"*/
                  AND SYUEKI_YM < /*syuekiYm*/
                  /*END*/
                  /*IF rirekiFlg != "R"*/
                  AND SYUEKI_YM <= /*syuekiYm*/
                  /*END*/
                  )
               OR (DATA_KBN = 'M' AND SYUEKI_YM >= /*syuekiYm*/)
               )
        UNION ALL
        SELECT ANKEN_ID
             , RIREKI_ID
             , DATA_KBN
             , SYUEKI_YM
             , SUBSTR(SYUEKI_YM, 7) AS END_WORD
          FROM /*IF rirekiFlg == "R"*/
               SYU_R_KI_KAISYU_TBL
               /*END*/
               /*IF rirekiFlg != "R"*/
               SYU_KI_KAISYU_TBL
               /*END*/ 
         WHERE ANKEN_ID = /*ankenId*/
           AND RIREKI_ID = /*rirekiId*/
           AND (  (   DATA_KBN = 'J'
                  /*IF rirekiFlg == "R"*/
                  AND SYUEKI_YM < /*syuekiYm*/
                  /*END*/
                  /*IF rirekiFlg != "R"*/
                  AND SYUEKI_YM <= /*syuekiYm*/
                  /*END*/
                  )
               OR (DATA_KBN = 'M' AND SYUEKI_YM >= /*syuekiYm*/)
               )
       ) T
 WHERE T.END_WORD IS NULL
GROUP BY T.ANKEN_ID, T.RIREKI_ID, T.SYUEKI_YM, T.DATA_KBN
ORDER BY T.SYUEKI_YM