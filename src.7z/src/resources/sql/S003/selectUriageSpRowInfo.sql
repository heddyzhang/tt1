SELECT ANKEN_ID
     , RIREKI_ID
     , CURRENCY_CODE
     , CURRENCY_CODE_SEQ
     , RENBAN
     , RENBAN_SEQ
     , URIAGE_YM
     , ORDER_NO
     , KEIYAKU_RATE
     , SUBSTRB(RENBAN, 1, 2) AS RENBAN_HEAD
     , COUNT(*) OVER(PARTITION BY ORDER_NO, SUBSTRB(RENBAN, 1, 2), URIAGE_YM) AS ROWSPAN_COUNT
     , ORDER_NO || '_' || SUBSTRB(RENBAN, 1, 2) || '_' || URIAGE_YM AS ROWSPAN_KEY_INFO
  FROM /*IF rirekiFlg == "R"*/
       SYU_R_KI_SP_CUR_TBL
       /*END*/
       /*IF rirekiFlg != "R"*/
       SYU_KI_SP_CUR_TBL
       /*END*/ 
 WHERE ANKEN_ID = /*ankenId*/
   AND RIREKI_ID = /*rirekiId*/
/*IF noExistsRenban != null && noExistsRenban != ""*/
   AND RENBAN <> /*noExistsRenban*/
/*END*/
ORDER BY ORDER_NO, RENBAN_SEQ, CURRENCY_CODE_SEQ, URIAGE_YM