SELECT CATEGORY_CODE
     , CATEGORY_KBN1
     , CATEGORY_KBN2
     , SUM(CASE WHEN DATA_KBN = 'F' AND SYUEKI_YM = '999900F' THEN NET ELSE NULL END) AS NET_F
     , SUM(CASE WHEN DATA_KBN = 'H' AND SYUEKI_YM = '999900H' THEN NET ELSE NULL END) AS NET_H
     , SUM(CASE WHEN DATA_KBN = 'A' AND SYUEKI_YM = '999900A' THEN NET ELSE NULL END) AS NET_K
     , SUM(CASE WHEN DATA_KBN = 'U' AND SYUEKI_YM = '999900U' THEN NET ELSE NULL END) AS NET_U
     , SUM(CASE WHEN DATA_KBN = 'E' AND SYUEKI_YM = '999900E' THEN NET ELSE NULL END) AS NET_E
     , SUM(CASE WHEN DATA_KBN = 'G' AND SYUEKI_YM = '999900G' THEN NET ELSE NULL END) as NET_G
     , SUM(CASE WHEN (DATA_KBN = 'M' OR (DATA_KBN = 'J' AND SYUEKI_YM <> /*kanjyoYm*/)) THEN NET ELSE NULL END) as NET_JM
     , NVL(SUM(CASE WHEN DATA_KBN = 'F' AND SYUEKI_YM = '999900F' THEN ITEM_FLG ELSE NULL END), '0') AS ITEM_FLG_F
/*$selectSyuekiYmInfo*/
  FROM /*IF rirekiFlg == "R"*/
       SYU_R_KI_NET_CATE_TUKI_TBL A
       /*END*/
       /*IF rirekiFlg != "R"*/
       SYU_KI_NET_CATE_TUKI_TBL A
       /*END*/
 WHERE ANKEN_ID = /*ankenId*/
   AND RIREKI_ID = /*rirekiId*/
   AND (  (   DATA_KBN = 'J'
          /*IF rirekiFlg == "R"*/
          AND SYUEKI_YM < /*kanjyoYm*/
          /*END*/
          /*IF rirekiFlg != "R"*/
          AND SYUEKI_YM <= /*kanjyoYm*/
          /*END*/
          )
       OR (DATA_KBN = 'M' AND SYUEKI_YM >= /*kanjyoYm*/)
       OR (DATA_KBN NOT IN ('J', 'M') AND 1 = 1)
       )
GROUP BY ANKEN_ID
       , RIREKI_ID
       , CATEGORY_CODE
       , CATEGORY_KBN1
       , CATEGORY_KBN2