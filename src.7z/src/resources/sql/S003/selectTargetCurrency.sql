SELECT T2.CURRENCY_CODE as STRING
  FROM (
        SELECT T.CURRENCY_CODE
          FROM (SELECT CURRENCY_CODE
                  FROM /*IF rirekiFlg == "R"*/
                       SYU_R_KI_JYUCHU_SP_TBL J
                       /*END*/
                       /*IF rirekiFlg != "R"*/
                       SYU_KI_JYUCHU_SP_TBL J
                       /*END*/
                 WHERE ANKEN_ID = /*ankenId*/
                   AND RIREKI_ID = /*rirekiId*/
                   AND (  (   DATA_KBN = 'J'
                          /*IF rirekiFlg == "R"*/
                          AND SYUEKI_YM < /*syuekiYm*/
                          /*END*/
                          /*IF rirekiFlg != "R"*/
                          AND SYUEKI_YM <= /*syuekiYm*/
                          /*END*/
                          )
                       OR (DATA_KBN = 'M' AND SYUEKI_YM >= /*syuekiYm*/)
                       OR (DATA_KBN NOT IN ('J', 'M') AND 1 = 1)
                       )
                UNION ALL
                SELECT CURRENCY_CODE
                  FROM /*IF rirekiFlg == "R"*/
                       SYU_R_KI_SP_CUR_TBL
                       /*END*/
                       /*IF rirekiFlg != "R"*/
                       SYU_KI_SP_CUR_TBL
                       /*END*/
                 WHERE ANKEN_ID = /*ankenId*/
                   AND RIREKI_ID = /*rirekiId*/
                ) T
        GROUP BY T.CURRENCY_CODE
       ) T2
           left outer join
       SYU_CUR_MST C
           on
       (T2.CURRENCY_CODE = C.CURRENCY_CODE)
ORDER BY C.DISP_SEQ NULLS LAST