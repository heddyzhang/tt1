SELECT CATEGORY_CODE
     , CATEGORY_KBN1
     , CATEGORY_KBN2
     , CATEGORY_NAME1
     , CATEGORY_NAME2
     , DIVISION_CODE
     , SALES_CLASS
     , IS_DELETED
     , BIKOU
  FROM SYU_GE_CATEGORY_MAP
 WHERE DIVISION_CODE = /*divisionCode*/
   AND SALES_CLASS = /*salesClass*/
   AND IS_DELETED = '0'
/*IF categoryName1 != null && categoryName1 != ""*/
   AND GET_CHANGE_SEARCH_STR(CATEGORY_NAME1) = GET_CHANGE_SEARCH_STR(/*categoryName1*/)
/*END*/
/*IF categoryName2 != null && categoryName2 != ""*/
   AND GET_CHANGE_SEARCH_STR(CATEGORY_NAME2) = GET_CHANGE_SEARCH_STR(/*categoryName2*/)
/*END*/
/*IF categoryName2 == null || categoryName2 == ""*/
   AND CATEGORY_NAME2 IS NULL
/*END*/