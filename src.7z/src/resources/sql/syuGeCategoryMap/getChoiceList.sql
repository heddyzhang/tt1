SELECT STRING
  FROM (
        SELECT M.CATEGORY_NAME AS STRING
             , CATEGORY_SEQ
          FROM (
                SELECT MIN(
                       /*IF choiceFlg == "1"*/
                           A.CATEGORY_NAME1
                       /*END*/
                       /*IF choiceFlg == "2"*/
                           A.CATEGORY_NAME2
                       /*END*/
                       ) AS CATEGORY_NAME
                     , MIN(CATEGORY_CODE) AS CATEGORY_SEQ 
                  FROM SYU_GE_CATEGORY_MAP A
                 WHERE A.DIVISION_CODE = /*divisionCode*/
                   AND A.SALES_CLASS = /*salesClass*/
                 GROUP BY
                       /*IF choiceFlg == "1"*/
                          A.CATEGORY_KBN1
                       /*END*/
                       /*IF choiceFlg == "2"*/
                          A.CATEGORY_KBN2
                       /*END*/
               ) M
         WHERE 1 = 1
        /*IF categoryName != null && categoryName != ""*/
           AND GET_CHANGE_SEARCH_STR(M.CATEGORY_NAME) LIKE '%' || GET_CHANGE_SEARCH_STR(/*categoryName*/)  || '%'
        /*END*/
           AND M.CATEGORY_NAME IS NOT NULL
         UNION
        
        SELECT 
        /*IF choiceFlg == "1"*/
               KS.CATEGORY_NAME1 AS STRING
        /*END*/
        /*IF choiceFlg == "2"*/
               KS.CATEGORY_NAME2 AS STRING
        /*END*/
             , CATEGORY_SEQ

          FROM (
                SELECT NVL(A.ANKEN_ID, B.ANKEN_ID) AS ANKEN_ID
                     , NVL(A.RIREKI_ID, B.RIREKI_ID) AS RIREKI_ID
                     , NVL(A.CATEGORY_CODE, B.CATEGORY_CODE) AS CATEGORY_CODE
                     , NVL(A.CATEGORY_KBN1, B.CATEGORY_KBN1) AS CATEGORY_KBN1
                     , NVL(A.CATEGORY_KBN2, B.CATEGORY_KBN2) AS CATEGORY_KBN2
                     , NVL(A.CATEGORY_NAME1, B.CATEGORY_NAME1) AS CATEGORY_NAME1
                     , NVL(A.CATEGORY_NAME2, B.CATEGORY_NAME2) AS CATEGORY_NAME2
                     , NVL(A.CATEGORY_SEQ, B.CATEGORY_SEQ) AS CATEGORY_SEQ
                  FROM (SELECT A1.*
                          FROM SYU_/*IF rirekiFlg == "R"*/R_/*END*/KI_NET_CATE_TITLE_TBL A1
                         WHERE A1.ANKEN_ID = /*ankenId*/
                           AND A1.RIREKI_ID = /*rirekiId*/) A
                         FULL OUTER JOIN
                       (SELECT B1.*
                          FROM SYU_/*IF rirekiFlg == "R"*/R_/*END*/SA_NET_CATE_TITLE_TBL B1
                         WHERE B1.ANKEN_ID = /*ankenId*/
                           AND B1.RIREKI_ID = /*rirekiId*/) B
                         ON (A.ANKEN_ID = B.ANKEN_ID AND A.RIREKI_ID = B.RIREKI_ID AND A.CATEGORY_CODE = B.CATEGORY_CODE)
               ) KS
         WHERE KS.ANKEN_ID = /*ankenId*/
           AND KS.RIREKI_ID = /*rirekiId*/
        /*IF choiceFlg == "1"*/
           /*IF categoryName != null && categoryName != ""*/
           AND GET_CHANGE_SEARCH_STR(KS.CATEGORY_NAME1) LIKE '%' || GET_CHANGE_SEARCH_STR(/*categoryName*/)  || '%'
           /*END*/
        /*END*/
        /*IF choiceFlg == "2"*/
           /*IF categoryName != null && categoryName != ""*/
           AND GET_CHANGE_SEARCH_STR(KS.CATEGORY_NAME2) LIKE '%' || GET_CHANGE_SEARCH_STR(/*categoryName*/)  || '%'
           /*END*/
           AND KS.CATEGORY_NAME2 IS NOT NULL
        /*END*/
       )
ORDER BY CATEGORY_SEQ
