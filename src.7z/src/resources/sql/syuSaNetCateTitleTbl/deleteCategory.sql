DELETE SYU_SA_NET_CATE_TITLE_TBL
 WHERE ANKEN_ID = /*ankenId*/
   AND RIREKI_ID = /*rirekiId*/
   AND CATEGORY_CODE = /*categoryCode*/ 