UPDATE SYU_SA_NET_CATE_TITLE_TBL
   SET CATEGORY_KBN1 = /*categoryKbn1*/
     , CATEGORY_KBN2 = /*categoryKbn2*/
     , CATEGORY_NAME1 = /*categoryName1*/
     , CATEGORY_NAME2 = /*categoryName2*/
     , UPDATED_AT = /*updatedAt*/
     , UPDATED_BY = /*updatedBy*/
 WHERE ANKEN_ID = /*ankenId*/
   AND RIREKI_ID = /*rirekiId*/
   AND CATEGORY_CODE = /*categoryCode*/