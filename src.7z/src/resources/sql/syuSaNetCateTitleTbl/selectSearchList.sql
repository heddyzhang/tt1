SELECT T2.*
  FROM (SELECT T.CATEGORY_CODE
             , T.CATEGORY_NAME/*$no*/ AS CATEGORY_NAME
             , T.CATEGORY_CODE AS CATEGORY_SEQ
          FROM (SELECT A.ANKEN_ID
                     , A.RIREKI_ID
                     , A.CATEGORY_CODE
                     , MIN(A.CATEGORY_NAME/*$no*/) AS CATEGORY_NAME/*$no*/
                  FROM SYU_/*IF rirekiFlg == "R"*/R_/*END*/SA_NET_CATE_TITLE_TBL A
                 WHERE A.ANKEN_ID = /*ankenId*/
                   AND A.RIREKI_ID = /*rirekiId*/
                   AND A.CATEGORY_NAME/*$no*/ IS NOT NULL
                 GROUP BY A.ANKEN_ID, A.RIREKI_ID, A.CATEGORY_CODE

/*IF childAnkenId != null*/
                    UNION ALL
                SELECT B1.ANKEN_ID
                     , B1.RIREKI_ID
                     , B1.SA_CATEGORY_CODE AS CATEGORY_CODE
                     , (SELECT MIN(B.CATEGORY_NAME/*$no*/) FROM SYU_/*IF rirekiFlg == "R"*/R_/*END*/SA_NET_CATE_TITLE_TBL B
                         WHERE B.ANKEN_ID = B1.ANKEN_ID
                           AND B.RIREKI_ID = B1.RIREKI_ID
                           AND B.CATEGORY_CODE = B1.SA_CATEGORY_CODE) AS CATEGORY_NAME/*$no*/
                  FROM SYU_/*IF rirekiFlg == "R"*/R_/*END*/GE_NET_ITEM_TBL B1
                 WHERE B1.ANKEN_ID IN /*childAnkenId*/('X')
                   AND B1.RIREKI_ID = /*rirekiId*/
                   AND B1.SINKO_CATEGORY_CODE IS NULL
                GROUP BY B1.ANKEN_ID, B1.RIREKI_ID, B1.SA_CATEGORY_CODE
/*END*/

               ) T

        ) T2
WHERE T2.CATEGORY_NAME IS NOT NULL
GROUP BY T2.CATEGORY_CODE, T2.CATEGORY_NAME, T2.CATEGORY_SEQ
ORDER BY T2.CATEGORY_SEQ