INSERT INTO SYU_SA_NET_CATE_TITLE_TBL (
      ANKEN_ID
    , RIREKI_ID
    , CATEGORY_CODE
    , CATEGORY_KBN1
    , CATEGORY_KBN2
    , CATEGORY_NAME1
    , CATEGORY_NAME2
    , CATEGORY_SEQ
    , INPUT_FLG
    , CREATED_AT
    , CREATED_BY
    , UPDATED_AT
    , UPDATED_BY
) VALUES (
      /*ankenId*/
    , /*rirekiId*/
　　, /*categoryCode*/
    , /*categoryKbn1*/
    , /*categoryKbn2*/
    , /*categoryName1*/
    , /*categoryName2*/
    , /*categorySeq*/
    , /*inputFlg*/
    , /*createdAt*/
    , /*createdBy*/
    , /*updatedAt*/
    , /*updatedBy*/
) 