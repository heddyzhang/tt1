SELECT T2.*
  FROM (SELECT T.CATEGORY_CODE
             , T.CATEGORY_NAME2 AS CATEGORY_NAME
             , (SELECT MIN(B.CATEGORY_SEQ) FROM SYU_/*IF rirekiFlg == "R"*/R_/*END*/SA_NET_CATE_TITLE_TBL B
                 WHERE B.ANKEN_ID = T.ANKEN_ID
                   AND B.RIREKI_ID = T.RIREKI_ID
                   AND B.CATEGORY_CODE = T.CATEGORY_CODE) AS CATEGORY_SEQ
          FROM (SELECT A.ANKEN_ID
                     , A.RIREKI_ID
                     , A.CATEGORY_CODE
                     , MIN(A.CATEGORY_NAME2) AS CATEGORY_NAME2
                  FROM SYU_/*IF rirekiFlg == "R"*/R_/*END*/SA_NET_CATE_TITLE_TBL A
                 WHERE A.ANKEN_ID = /*ankenId*/
                   AND A.RIREKI_ID = /*rirekiId*/
                   AND A.CATEGORY_NAME2 IS NOT NULL
                 GROUP BY A.ANKEN_ID, A.RIREKI_ID, A.CATEGORY_CODE) T
        ) T2
ORDER BY T2.CATEGORY_SEQ