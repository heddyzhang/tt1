SELECT ANKEN_ID
     , RIREKI_ID
     , CATEGORY_CODE
     , CATEGORY_KBN1
     , CATEGORY_KBN2
     , CATEGORY_NAME1
     , CATEGORY_NAME2
  FROM 
/*IF rirekiFlg != "R"*/
       SYU_SA_NET_CATE_TITLE_TBL
/*END*/
/*IF rirekiFlg == "R"*/
       SYU_R_SA_NET_CATE_TITLE_TBL
/*END*/
 WHERE ANKEN_ID = /*ankenId*/
   AND RIREKI_ID = /*rirekiId*/
ORDER BY CATEGORY_SEQ
