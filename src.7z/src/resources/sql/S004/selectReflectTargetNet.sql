SELECT /*categoryCode*/ || /*reflecFlg*/ AS CATEGORY_CODE
     , /*categoryKbn1*/ AS CATEGORY_KBN1
     , /*categoryKbn2*/ AS CATEGORY_KBN2
/*IF reflecFlg == "DIFF"*/
     , NVL(NET_M, 0) - NET_J AS NET_TM
/*END*/
/*IF reflecFlg == "J"*/
     , NET_J AS NET_TM
/*END*/
/*IF reflecFlg == "M"*/
     , NET_M AS NET_TM
/*END*/
  FROM (
      SELECT SUM(CASE WHEN DATA_KBN = 'J' THEN NET END) AS NET_J
           , SUM(CASE WHEN DATA_KBN = 'M' THEN NVL(NET, 0) END) AS NET_M
        FROM SYU_KI_NET_CATE_TUKI_TBL
       WHERE ANKEN_ID = /*ankenId*/
         AND RIREKI_ID = /*rirekiId*/
         AND CATEGORY_CODE = /*categoryCode*/
         AND CATEGORY_KBN1 = /*categoryKbn1*/
         AND CATEGORY_KBN2 = /*categoryKbn2*/
         AND SYUEKI_YM = /*syukeiYm*/
)
