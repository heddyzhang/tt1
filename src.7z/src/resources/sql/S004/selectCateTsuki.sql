SELECT TITLE.ANKEN_ID
     , TITLE.CATEGORY_CODE
     , TITLE.CATEGORY_KBN1
     , TITLE.CATEGORY_KBN2
     , TSUKI.NET
  FROM (
        SELECT ANKEN_ID
             , CATEGORY_CODE
             , CATEGORY_KBN1
             , CATEGORY_KBN2
             , CATEGORY_SEQ
          FROM 
               /*IF rirekiFlg == "R"*/
               SYU_R_KI_NET_CATE_TITLE_TBL
               /*END*/
               /*IF rirekiFlg != "R"*/
               SYU_KI_NET_CATE_TITLE_TBL
               /*END*/
         WHERE ANKEN_ID = /*ankenId*/
           AND RIREKI_ID = /*rirekiId*/
) TITLE
LEFT OUTER JOIN (
    SELECT ANKEN_ID
         , CATEGORY_CODE
         , CATEGORY_KBN1
         , CATEGORY_KBN2
         , NET
      FROM 
           /*IF rirekiFlg == "R"*/
           SYU_R_KI_NET_CATE_TUKI_TBL
           /*END*/
           /*IF rirekiFlg != "R"*/
           SYU_KI_NET_CATE_TUKI_TBL
           /*END*/
     WHERE ANKEN_ID = /*ankenId*/
       AND RIREKI_ID = /*rirekiId*/
       AND SYUEKI_YM = /*syuekiYm*/
       AND DATA_KBN = /*dataKbn*/
) TSUKI
ON ( TITLE.ANKEN_ID = TSUKI.ANKEN_ID
   AND TITLE.CATEGORY_CODE = TSUKI.CATEGORY_CODE
   AND TITLE.CATEGORY_KBN1 = TSUKI.CATEGORY_KBN1
   AND TITLE.CATEGORY_KBN2 = TSUKI.CATEGORY_KBN2
   )
ORDER BY CATEGORY_SEQ

