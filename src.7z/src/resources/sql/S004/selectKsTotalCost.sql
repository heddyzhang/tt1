-- 見積総原価合計
SELECT 1 AS CATEGORY_CODE
     , 1 AS CATEGORY_KBN1
     , 1 AS CATEGORY_KBN2
     , SUM(NOW.NET_1) AS NET_1
     , SUM(NOW.NET_2) AS NET_2
     , SUM(NOW.NET_3) AS NET_3
     , SUM(NOW.NET_4) AS NET_4
     , SUM(NOW.NET_5) AS NET_5
     , SUM(NOW.NET_6) AS NET_6
     , SUM(NOW.NET_7) AS NET_7
     , SUM(NOW.NET_8) AS NET_8
     , SUM(NOW.NET_9) AS NET_9
     , SUM(NOW.NET_10) AS NET_10
     , SUM(NOW.NET_11) AS NET_11
     , SUM(NOW.NET_12) AS NET_12
     , SUM(NOW.NET_K1) AS NET_K1
     , SUM(NOW.NET_K2) AS NET_K2
     , SUM(NOW.NET_G) AS NET_G
     , SUM(NOW.NET_F) AS NET_F
     , SUM(NOW.NET_1Q) AS NET_1Q
     , SUM(NOW.NET_2Q) AS NET_2Q
     , SUM(NOW.NET_3Q) AS NET_3Q
     , SUM(NOW.NET_4Q) AS NET_4Q
     , NVL(SUM(NOW.NET_TM_M),0) - SUM(NOW.NET_TM_J) AS NET_TM
     /*IF zenkaiRirekiId != null*/
     , NVL(SUM(NOW.NET_K1),0) - SUM(BEF.NET_K1) AS NET_K1_DIFF
     , NVL(SUM(NOW.NET_K2),0) - SUM(BEF.NET_K2) AS NET_K2_DIFF
     , NVL(SUM(NOW.NET_G),0) - SUM(BEF.NET_G) AS NET_G_DIFF
     , NVL(SUM(NOW.NET_1Q),0) - SUM(BEF.NET_1Q) AS NET_1Q_DIFF
     , NVL(SUM(NOW.NET_2Q),0) - SUM(BEF.NET_2Q) AS NET_2Q_DIFF
     , NVL(SUM(NOW.NET_3Q),0) - SUM(BEF.NET_3Q) AS NET_3Q_DIFF
     , NVL(SUM(NOW.NET_4Q),0) - SUM(BEF.NET_4Q) AS NET_4Q_DIFF
     /*END*/
     , NVL(SUM(NOW.NET_F),0) - SUM(NOW.NET_G) AS NET_DIFF
  FROM (
        SELECT ANKEN_ID
             , RIREKI_ID
             , SYUEKI_YM
             , CASE WHEN TO_DATE(/*kanjoYM*/, 'yyyymm') - TO_DATE(/*kikanA*/, 'yyyymm') >= 0
                 THEN CASE WHEN DATA_KBN = 'J' AND SYUEKI_YM = /*kikanA*/ THEN MITSUMORI_GENKA_NET END
               ELSE
                 CASE WHEN DATA_KBN = 'M' AND SYUEKI_YM = /*kikanA*/ THEN MITSUMORI_GENKA_NET END
               END AS NET_1          
             , CASE WHEN TO_DATE(/*kanjoYM*/, 'yyyymm') - TO_DATE(/*kikanB*/, 'yyyymm') >= 0
                 THEN CASE WHEN DATA_KBN = 'J' AND SYUEKI_YM = /*kikanB*/ THEN MITSUMORI_GENKA_NET END
               ELSE
                 CASE WHEN DATA_KBN = 'M' AND SYUEKI_YM = /*kikanB*/ THEN MITSUMORI_GENKA_NET END
               END AS NET_2          
             , CASE WHEN TO_DATE(/*kanjoYM*/, 'yyyymm') - TO_DATE(/*kikanC*/, 'yyyymm') >= 0
                 THEN CASE WHEN DATA_KBN = 'J' AND SYUEKI_YM = /*kikanC*/ THEN MITSUMORI_GENKA_NET END
               ELSE
                 CASE WHEN DATA_KBN = 'M' AND SYUEKI_YM = /*kikanC*/ THEN MITSUMORI_GENKA_NET END
               END AS NET_3          
             , CASE WHEN TO_DATE(/*kanjoYM*/, 'yyyymm') - TO_DATE(/*kikanD*/, 'yyyymm') >= 0
                 THEN CASE WHEN DATA_KBN = 'J' AND SYUEKI_YM = /*kikanD*/ THEN MITSUMORI_GENKA_NET END
               ELSE
                 CASE WHEN DATA_KBN = 'M' AND SYUEKI_YM = /*kikanD*/ THEN MITSUMORI_GENKA_NET END
               END AS NET_4          
             , CASE WHEN TO_DATE(/*kanjoYM*/, 'yyyymm') - TO_DATE(/*kikanE*/, 'yyyymm') >= 0
                 THEN CASE WHEN DATA_KBN = 'J' AND SYUEKI_YM = /*kikanE*/ THEN MITSUMORI_GENKA_NET END
               ELSE
                 CASE WHEN DATA_KBN = 'M' AND SYUEKI_YM = /*kikanE*/ THEN MITSUMORI_GENKA_NET END
               END AS NET_5          
             , CASE WHEN TO_DATE(/*kanjoYM*/, 'yyyymm') - TO_DATE(/*kikanF*/, 'yyyymm') >= 0
                 THEN CASE WHEN DATA_KBN = 'J' AND SYUEKI_YM = /*kikanF*/ THEN MITSUMORI_GENKA_NET END
               ELSE
                 CASE WHEN DATA_KBN = 'M' AND SYUEKI_YM = /*kikanF*/ THEN MITSUMORI_GENKA_NET END
               END AS NET_6          
             , CASE WHEN TO_DATE(/*kanjoYM*/, 'yyyymm') - TO_DATE(/*kikanG*/, 'yyyymm') >= 0
                 THEN CASE WHEN DATA_KBN = 'J' AND SYUEKI_YM = /*kikanG*/ THEN MITSUMORI_GENKA_NET END
               ELSE
                 CASE WHEN DATA_KBN = 'M' AND SYUEKI_YM = /*kikanG*/ THEN MITSUMORI_GENKA_NET END
               END AS NET_7          
             , CASE WHEN TO_DATE(/*kanjoYM*/, 'yyyymm') - TO_DATE(/*kikanH*/, 'yyyymm') >= 0
                 THEN CASE WHEN DATA_KBN = 'J' AND SYUEKI_YM = /*kikanH*/ THEN MITSUMORI_GENKA_NET END
               ELSE
                 CASE WHEN DATA_KBN = 'M' AND SYUEKI_YM = /*kikanH*/ THEN MITSUMORI_GENKA_NET END
               END AS NET_8          
             , CASE WHEN TO_DATE(/*kanjoYM*/, 'yyyymm') - TO_DATE(/*kikanI*/, 'yyyymm') >= 0
                 THEN CASE WHEN DATA_KBN = 'J' AND SYUEKI_YM = /*kikanI*/ THEN MITSUMORI_GENKA_NET END
               ELSE
                 CASE WHEN DATA_KBN = 'M' AND SYUEKI_YM = /*kikanI*/ THEN MITSUMORI_GENKA_NET END
               END AS NET_9          
             , CASE WHEN TO_DATE(/*kanjoYM*/, 'yyyymm') - TO_DATE(/*kikanJ*/, 'yyyymm') >= 0
                 THEN CASE WHEN DATA_KBN = 'J' AND SYUEKI_YM = /*kikanJ*/ THEN MITSUMORI_GENKA_NET END
               ELSE
                 CASE WHEN DATA_KBN = 'M' AND SYUEKI_YM = /*kikanJ*/ THEN MITSUMORI_GENKA_NET END
               END AS NET_10         
             , CASE WHEN TO_DATE(/*kanjoYM*/, 'yyyymm') - TO_DATE(/*kikanK*/, 'yyyymm') >= 0
                 THEN CASE WHEN DATA_KBN = 'J' AND SYUEKI_YM = /*kikanK*/ THEN MITSUMORI_GENKA_NET END
               ELSE
                 CASE WHEN DATA_KBN = 'M' AND SYUEKI_YM = /*kikanK*/ THEN MITSUMORI_GENKA_NET END
               END AS NET_11         
             , CASE WHEN TO_DATE(/*kanjoYM*/, 'yyyymm') - TO_DATE(/*kikanL*/, 'yyyymm') >= 0
                 THEN CASE WHEN DATA_KBN = 'J' AND SYUEKI_YM = /*kikanL*/ THEN MITSUMORI_GENKA_NET END
               ELSE
                 CASE WHEN DATA_KBN = 'M' AND SYUEKI_YM = /*kikanL*/ THEN MITSUMORI_GENKA_NET END
               END AS NET_12

             , CASE WHEN DATA_KBN = 'J' AND SYUEKI_YM = /*tmYm*/ THEN MITSUMORI_GENKA_NET
                    ELSE NULL
               END AS NET_TM_J
             , CASE WHEN DATA_KBN = 'M' AND SYUEKI_YM = /*tmYm*/ THEN MITSUMORI_GENKA_NET
                    ELSE NULL
               END AS NET_TM_M

             , CASE WHEN DATA_KBN = 'G' AND SYUEKI_YM = '999900G' THEN MITSUMORI_GENKA_NET END AS NET_G
             , CASE WHEN DATA_KBN = 'F' AND SYUEKI_YM = '999900M' THEN MITSUMORI_GENKA_NET END AS NET_F
             , CASE WHEN DATA_KBN = 'K' AND SYUEKI_YM = /*kiFrom*/ THEN MITSUMORI_GENKA_NET END AS NET_K1
             , CASE WHEN DATA_KBN = 'K' AND SYUEKI_YM = /*kiTo*/ THEN MITSUMORI_GENKA_NET END AS NET_K2

             , CASE WHEN DATA_KBN = 'Q' AND SYUEKI_YM = /*Q1*/ THEN MITSUMORI_GENKA_NET END AS NET_1Q
             , CASE WHEN DATA_KBN = 'Q' AND SYUEKI_YM = /*Q2*/ THEN MITSUMORI_GENKA_NET END AS NET_2Q
             , CASE WHEN DATA_KBN = 'Q' AND SYUEKI_YM = /*Q3*/ THEN MITSUMORI_GENKA_NET END AS NET_3Q
             , CASE WHEN DATA_KBN = 'Q' AND SYUEKI_YM = /*Q4*/ THEN MITSUMORI_GENKA_NET END AS NET_4Q
          FROM /*IF rirekiFlg == "R"*/
                SYU_R_KI_NET_SOGENKA_TOTAL_TBL
                /*END*/
                /*IF rirekiFlg != "R"*/
                SYU_KI_NET_SOGENKA_TOTAL_TBL
                /*END*/ 
         WHERE ANKEN_ID = /*ankenId*/
           AND RIREKI_ID = /*rirekiId*/
           AND (SYUEKI_YM BETWEEN /*kikanA*/ AND /*kikanL*/
             OR SYUEKI_YM = '999900G'
             OR SYUEKI_YM = '999900M'
             OR SYUEKI_YM = /*kiFrom*/
             OR SYUEKI_YM = /*kiTo*/

             OR SYUEKI_YM = /*Q1*/
             OR SYUEKI_YM = /*Q2*/
             OR SYUEKI_YM = /*Q3*/
             OR SYUEKI_YM = /*Q4*/

             OR SYUEKI_YM = /*tmYm*/
               )
        ) NOW
        /*IF zenkaiRirekiId != null*/
        LEFT OUTER JOIN (
            SELECT ANKEN_ID
                 , RIREKI_ID
                 , SYUEKI_YM
                 , CASE WHEN DATA_KBN = 'K' AND SYUEKI_YM = /*kiFrom*/ THEN MITSUMORI_GENKA_NET END AS NET_K1
                 , CASE WHEN DATA_KBN = 'K' AND SYUEKI_YM = /*kiTo*/ THEN MITSUMORI_GENKA_NET END AS NET_K2
                 , CASE WHEN DATA_KBN = 'G' AND SYUEKI_YM = '999900G' THEN MITSUMORI_GENKA_NET END AS NET_G

                 , CASE WHEN DATA_KBN = 'Q' AND SYUEKI_YM = /*Q1*/ THEN MITSUMORI_GENKA_NET END AS NET_1Q
                 , CASE WHEN DATA_KBN = 'Q' AND SYUEKI_YM = /*Q2*/ THEN MITSUMORI_GENKA_NET END AS NET_2Q
                 , CASE WHEN DATA_KBN = 'Q' AND SYUEKI_YM = /*Q3*/ THEN MITSUMORI_GENKA_NET END AS NET_3Q
                 , CASE WHEN DATA_KBN = 'Q' AND SYUEKI_YM = /*Q4*/ THEN MITSUMORI_GENKA_NET END AS NET_4Q
              FROM SYU_R_KI_NET_SOGENKA_TOTAL_TBL
             WHERE ANKEN_ID = /*ankenId*/
               AND RIREKI_ID = /*zenkaiRirekiId*/
               AND (SYUEKI_YM = '999900G'
                 OR SYUEKI_YM = /*kiFrom*/
                 OR SYUEKI_YM = /*kiTo*/

                 OR SYUEKI_YM = /*Q1*/
                 OR SYUEKI_YM = /*Q2*/
                 OR SYUEKI_YM = /*Q3*/
                 OR SYUEKI_YM = /*Q4*/
                   )
            ) BEF ON NOW.ANKEN_ID = BEF.ANKEN_ID AND NOW.SYUEKI_YM = BEF.SYUEKI_YM
        /*END*/ 