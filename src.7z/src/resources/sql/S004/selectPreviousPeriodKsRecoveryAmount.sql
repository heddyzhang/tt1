-- 回収金額
SELECT SKS.ANKEN_ID
     , SKS.RIREKI_ID
     , SKS.CURRENCY_CODE
     , SKK.RUIKEI_KAISYU_AMOUNT AS RUIKEI_KAISYU_AMOUNT_TOTAL
  FROM SYU_KI_SP_CUR_TBL SKS
      , (
            SELECT NOW.ANKEN_ID
                 , NOW.RIREKI_ID
                 , NOW.CURRENCY_CODE
                 , NOW.RUIKEI_KAISYU_AMOUNT
              FROM (
                    SELECT ANKEN_ID
                         , RIREKI_ID
                         , CURRENCY_CODE
                         , SYUEKI_YM
                         , KAISYU_AMOUNT
                         , RUIKEI_KAISYU_AMOUNT
                         , MI_KAISYU_AMOUNT
                      FROM SYU_KI_KAISYU_TBL

                     WHERE ANKEN_ID = /*ankenId*/
                       AND RIREKI_ID = /*rirekiId*/
                       AND SYUEKI_YM = /*zenki*/
                       AND DATA_KBN = 'K'
                    ) NOW
                    LEFT OUTER JOIN (
                        SELECT ANKEN_ID
                             , RIREKI_ID
                             , CURRENCY_CODE
                             , SYUEKI_YM
                             , KAISYU_AMOUNT
                             , RUIKEI_KAISYU_AMOUNT
                             , MI_KAISYU_AMOUNT
                          FROM SYU_KI_KAISYU_TBL
                         WHERE ANKEN_ID = /*ankenId*/
                           AND RIREKI_ID = '1'
                           AND SYUEKI_YM = /*zenki*/
                           AND DATA_KBN = 'K'
                        ) BEF ON NOW.ANKEN_ID = BEF.ANKEN_ID AND NOW.CURRENCY_CODE = BEF.CURRENCY_CODE AND NOW.SYUEKI_YM = BEF.SYUEKI_YM
       ) SKK
 WHERE SKS.ANKEN_ID = SKK.ANKEN_ID
   AND SKS.RIREKI_ID = SKK.RIREKI_ID
   AND SKS.CURRENCY_CODE = SKK.CURRENCY_CODE
   AND SKS.ANKEN_ID = /*ankenId*/ 
   AND SKS.RIREKI_ID = /*rirekiId*/
 ORDER BY SKS.CURRENCY_CODE_SEQ