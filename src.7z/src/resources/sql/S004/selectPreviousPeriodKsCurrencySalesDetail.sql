-- 売上高内訳
SELECT NVL(SKT.SEQ, 1) AS SEQ
     , SKC.ANKEN_ID
     , SKC.RIREKI_ID
     , NVL(SKC.CURRENCY_CODE, ' ') AS CURRENCY_CODE
     , DECODE(SKT.SEQ, 1, NULL, 2, DECODE(SKC.CURRENCY_CODE, 'JPY', NULL, 'kawaseRate'), 3, 'kawaseDiff', NULL) AS URIAGE_RATE
     , SKT.URI_RATE_TOTAL
     , SKT.URIAGE_KAWASESA_TOTAL
     , SKT.URIAGE_AMOUNT_TOTAL

  FROM SYU_KI_SP_CUR_TBL SKC 
         LEFT OUTER JOIN (
            SELECT 1 AS SEQ
                 , NOW.ANKEN_ID
                 , NOW.RIREKI_ID
                 , NOW.CURRENCY_CODE
                 , SUM(NOW.URI_RATE) AS URI_RATE_TOTAL
                 , SUM(NOW.URIAGE_KAWASESA) AS URIAGE_KAWASESA_TOTAL
                 , SUM(NOW.URIAGE_AMOUNT) AS URIAGE_AMOUNT_TOTAL
              FROM (
                    SELECT ANKEN_ID
                         , RIREKI_ID
                         , CURRENCY_CODE
                         , SYUEKI_YM
                         , URI_RATE
                         , URIAGE_KAWASESA
                         , URIAGE_AMOUNT

                      FROM SYU_KI_SP_TUKI_S_TBL

                     WHERE ANKEN_ID = /*ankenId*/
                       AND RIREKI_ID = /*rirekiId*/
                       AND SYUEKI_YM in /*kikan*/('1')
                       AND DATA_KBN = 'K'
                      ) NOW

                      LEFT OUTER JOIN (
                          SELECT ANKEN_ID
                               , RIREKI_ID
                               , CURRENCY_CODE
                               , SYUEKI_YM
                               , URI_RATE
                               , URIAGE_KAWASESA
                               , URIAGE_AMOUNT
                            FROM  SYU_KI_SP_TUKI_S_TBL
                           WHERE ANKEN_ID = /*ankenId*/ 
                             AND RIREKI_ID = '1'
                             AND SYUEKI_YM in /*kikan*/('1')
                             AND DATA_KBN = 'K'
                      ) BEF ON NOW.ANKEN_ID = BEF.ANKEN_ID AND NOW.CURRENCY_CODE = BEF.CURRENCY_CODE AND NOW.SYUEKI_YM = BEF.SYUEKI_YM

                       GROUP BY NOW.ANKEN_ID, NOW.RIREKI_ID, NOW.CURRENCY_CODE
            UNION ALL
            SELECT 2 AS SEQ
                 , NOW.ANKEN_ID
                 , NOW.RIREKI_ID
                 , NOW.CURRENCY_CODE
                 , SUM(NOW.URI_RATE) AS URI_RATE_TOTAL
                 , SUM(NOW.URIAGE_KAWASESA) AS URIAGE_KAWASESA_TOTAL
                 , SUM(NOW.URIAGE_AMOUNT) AS URIAGE_AMOUNT_TOTAL
              FROM (
                    SELECT ANKEN_ID
                         , RIREKI_ID
                         , CURRENCY_CODE
                         , SYUEKI_YM
                         , URI_RATE
                         , URIAGE_KAWASESA
                         , URIAGE_AMOUNT
                      FROM SYU_KI_SP_TUKI_S_TBL
                     WHERE ANKEN_ID = /*ankenId*/
                       AND RIREKI_ID = /*rirekiId*/
                       AND CURRENCY_CODE != 'JPY'
                       AND SYUEKI_YM in /*kikan*/('1')
                       AND DATA_KBN = 'K'
                      ) NOW
                      LEFT OUTER JOIN (
                          SELECT ANKEN_ID
                               , RIREKI_ID
                               , CURRENCY_CODE
                               , SYUEKI_YM
                               , URI_RATE
                               , URIAGE_KAWASESA
                               , URIAGE_AMOUNT
                            FROM  SYU_KI_SP_TUKI_S_TBL
                           WHERE ANKEN_ID = /*ankenId*/ 
                             AND RIREKI_ID = '1'
                             AND CURRENCY_CODE != 'JPY'
                             AND SYUEKI_YM in /*kikan*/('1')
                             AND DATA_KBN = 'K'
                      ) BEF ON NOW.ANKEN_ID = BEF.ANKEN_ID AND NOW.CURRENCY_CODE = BEF.CURRENCY_CODE AND NOW.SYUEKI_YM = BEF.SYUEKI_YM
                       GROUP BY NOW.ANKEN_ID, NOW.RIREKI_ID, NOW.CURRENCY_CODE
            UNION ALL
            SELECT 3 AS SEQ
                 , NOW.ANKEN_ID
                 , NOW.RIREKI_ID
                 , NOW.CURRENCY_CODE
                 , SUM(NOW.URI_RATE) AS URI_RATE_TOTAL
                 , SUM(NOW.URIAGE_KAWASESA) AS URIAGE_KAWASESA_TOTAL
                 , SUM(NOW.URIAGE_AMOUNT) AS URIAGE_AMOUNT_TOTAL
              FROM (
                    SELECT ANKEN_ID
                         , RIREKI_ID
                         , CURRENCY_CODE
                         , SYUEKI_YM
                         , URI_RATE
                         , URIAGE_KAWASESA
                         , URIAGE_AMOUNT
                      FROM  SYU_KI_SP_TUKI_S_TBL
                     WHERE ANKEN_ID = /*ankenId*/
                       AND RIREKI_ID = /*rirekiId*/
                       AND CURRENCY_CODE != 'JPY'
                       AND SYUEKI_YM in /*kikan*/('1')
                       AND DATA_KBN = 'K'
                      ) NOW

                      LEFT OUTER JOIN (
                          SELECT ANKEN_ID
                               , RIREKI_ID
                               , CURRENCY_CODE
                               , SYUEKI_YM
                               , URI_RATE
                               , URIAGE_KAWASESA
                               , URIAGE_AMOUNT

                            FROM SYU_KI_SP_TUKI_S_TBL
                           WHERE ANKEN_ID = /*ankenId*/ 
                             AND RIREKI_ID = '1'
                             AND CURRENCY_CODE != 'JPY'
                             AND SYUEKI_YM in /*kikan*/('1')
                             AND DATA_KBN = 'K'
                      ) BEF ON NOW.ANKEN_ID = BEF.ANKEN_ID AND NOW.CURRENCY_CODE = BEF.CURRENCY_CODE AND NOW.SYUEKI_YM = BEF.SYUEKI_YM

                       GROUP BY NOW.ANKEN_ID, NOW.RIREKI_ID, NOW.CURRENCY_CODE
         ) SKT ON SKC.ANKEN_ID = SKT.ANKEN_ID AND SKC.RIREKI_ID = SKT.RIREKI_ID AND SKC.CURRENCY_CODE = SKT.CURRENCY_CODE
 WHERE SKC.ANKEN_ID = /*ankenId*/ 
   AND SKC.RIREKI_ID = /*rirekiId*/
   AND SKC.RENBAN = '0000'
 ORDER BY SKC.CURRENCY_CODE_SEQ, SKT.SEQ