SELECT /*lossCol*/  AS ROW_NAME_ID
     /*IF lossCol == "LOSS_RUIKEI_HIKIATE"*/
     , (SELECT A1./*$lossCol*/ FROM SYU_/*IF rirekiFlg == "R"*/R_/*END*/KI_LOSS_TBL A1 WHERE A1.ANKEN_ID = NOW.ANKEN_ID AND A1.RIREKI_ID = /*rirekiId*/ AND A1.DATA_KBN = 'K' AND A1.SYUEKI_YM = /*zenki*/) AS LOSS_B_RUIKEI
     /*END*/
     /*IF lossCol != "LOSS_RUIKEI_HIKIATE"*/
     , (SELECT SUM(A1./*$lossCol*/) FROM SYU_/*IF rirekiFlg == "R"*/R_/*END*/KI_LOSS_TBL A1 WHERE A1.ANKEN_ID = NOW.ANKEN_ID AND A1.RIREKI_ID = /*rirekiId*/ AND A1.DATA_KBN = 'K' AND A1.SYUEKI_YM < /*kiFrom*/) AS LOSS_B_RUIKEI
     /*END*/
     , SUM(NOW.LOSS_1)  AS LOSS_1
     , SUM(NOW.LOSS_2)  AS LOSS_2
     , SUM(NOW.LOSS_3)  AS LOSS_3
     , SUM(NOW.LOSS_4)  AS LOSS_4
     , SUM(NOW.LOSS_5)  AS LOSS_5
     , SUM(NOW.LOSS_6)  AS LOSS_6
     , SUM(NOW.LOSS_7)  AS LOSS_7
     , SUM(NOW.LOSS_8)  AS LOSS_8
     , SUM(NOW.LOSS_9)  AS LOSS_9
     , SUM(NOW.LOSS_10) AS LOSS_10
     , SUM(NOW.LOSS_11) AS LOSS_11
     , SUM(NOW.LOSS_12) AS LOSS_12
     , SUM(NOW.LOSS_1Q) AS LOSS_1Q
     , SUM(NOW.LOSS_2Q) AS LOSS_2Q
     , SUM(NOW.LOSS_K1) AS LOSS_K1
     , SUM(NOW.LOSS_3Q) AS LOSS_3Q
     , SUM(NOW.LOSS_4Q) AS LOSS_4Q
     , SUM(NOW.LOSS_K2) AS LOSS_K2
     , SUM(NOW.LOSS_G)  AS LOSS_G

     , (  NVL((SELECT A1./*$lossCol*/ FROM SYU_/*IF rirekiFlg == "R"*/R_/*END*/KI_LOSS_TBL A1 WHERE A1.ANKEN_ID = NOW.ANKEN_ID AND A1.RIREKI_ID = /*rirekiId*/ AND A1.DATA_KBN = 'M' AND A1.SYUEKI_YM = /*tmYm*/), 0)
       - (SELECT A1./*$lossCol*/ FROM SYU_/*IF rirekiFlg == "R"*/R_/*END*/KI_LOSS_TBL A1 WHERE A1.ANKEN_ID = NOW.ANKEN_ID AND A1.RIREKI_ID = /*rirekiId*/ AND A1.DATA_KBN = 'J' AND A1.SYUEKI_YM = /*tmYm*/)
       )
       AS LOSS_TM

     /*IF zenkaiRirekiId != null*/
     , NVL(SUM(NOW.LOSS_K1), 0) - SUM(BEF.LOSS_K1) AS LOSS_K1_DIFF
     , NVL(SUM(NOW.LOSS_K2), 0) - SUM(BEF.LOSS_K2) AS LOSS_K2_DIFF
     , NVL(SUM(NOW.LOSS_G), 0) - SUM(BEF.LOSS_G)   AS LOSS_G_DIFF
     , NVL(SUM(NOW.LOSS_1Q), 0) - SUM(BEF.LOSS_1Q) AS LOSS_1Q_DIFF
     , NVL(SUM(NOW.LOSS_2Q), 0) - SUM(BEF.LOSS_2Q) AS LOSS_2Q_DIFF
     , NVL(SUM(NOW.LOSS_3Q), 0) - SUM(BEF.LOSS_3Q) AS LOSS_3Q_DIFF
     , NVL(SUM(NOW.LOSS_4Q), 0) - SUM(BEF.LOSS_4Q) AS LOSS_4Q_DIFF
     /*END*/

  FROM (SELECT A.ANKEN_ID
             , SUM(CASE WHEN A.SYUEKI_YM = /*kikanA*/ THEN A./*$lossCol*/ END) AS LOSS_1
             , SUM(CASE WHEN A.SYUEKI_YM = /*kikanB*/ THEN A./*$lossCol*/ END) AS LOSS_2
             , SUM(CASE WHEN A.SYUEKI_YM = /*kikanC*/ THEN A./*$lossCol*/ END) AS LOSS_3
             , SUM(CASE WHEN A.SYUEKI_YM = /*kikanD*/ THEN A./*$lossCol*/ END) AS LOSS_4
             , SUM(CASE WHEN A.SYUEKI_YM = /*kikanE*/ THEN A./*$lossCol*/ END) AS LOSS_5
             , SUM(CASE WHEN A.SYUEKI_YM = /*kikanF*/ THEN A./*$lossCol*/ END) AS LOSS_6
             , SUM(CASE WHEN A.SYUEKI_YM = /*kikanG*/ THEN A./*$lossCol*/ END) AS LOSS_7
             , SUM(CASE WHEN A.SYUEKI_YM = /*kikanH*/ THEN A./*$lossCol*/ END) AS LOSS_8
             , SUM(CASE WHEN A.SYUEKI_YM = /*kikanI*/ THEN A./*$lossCol*/ END) AS LOSS_9
             , SUM(CASE WHEN A.SYUEKI_YM = /*kikanJ*/ THEN A./*$lossCol*/ END) AS LOSS_10
             , SUM(CASE WHEN A.SYUEKI_YM = /*kikanK*/ THEN A./*$lossCol*/ END) AS LOSS_11
             , SUM(CASE WHEN A.SYUEKI_YM = /*kikanL*/ THEN A./*$lossCol*/ END) AS LOSS_12
             , SUM(CASE WHEN A.DATA_KBN = 'Q' AND A.SYUEKI_YM = /*Q1*/ THEN A./*$lossCol*/ END) AS LOSS_1Q
             , SUM(CASE WHEN A.DATA_KBN = 'Q' AND A.SYUEKI_YM = /*Q2*/ THEN A./*$lossCol*/ END) AS LOSS_2Q
             , SUM(CASE WHEN A.DATA_KBN = 'K' AND A.SYUEKI_YM = /*kiFrom*/ THEN A./*$lossCol*/ END) AS LOSS_K1
             , SUM(CASE WHEN A.DATA_KBN = 'Q' AND A.SYUEKI_YM = /*Q3*/ THEN A./*$lossCol*/ END) AS LOSS_3Q
             , SUM(CASE WHEN A.DATA_KBN = 'Q' AND A.SYUEKI_YM = /*Q4*/ THEN A./*$lossCol*/ END) AS LOSS_4Q
             , SUM(CASE WHEN A.DATA_KBN = 'K' AND A.SYUEKI_YM = /*kiTo*/ THEN A./*$lossCol*/ END) AS LOSS_K2
             , SUM(CASE WHEN A.DATA_KBN = 'G' THEN A./*$lossCol*/ END) AS LOSS_G

          FROM SYU_/*IF rirekiFlg == "R"*/R_/*END*/KI_LOSS_TBL A
         WHERE A.ANKEN_ID = /*ankenId*/
           AND A.RIREKI_ID = /*rirekiId*/
           AND (
                 (   A.DATA_KBN IN ('J', 'M')
                 AND A.SYUEKI_YM BETWEEN /*kikanA*/ AND /*kikanL*/
                 AND (  A.DATA_KBN = 'J' AND A.SYUEKI_YM < /*nowkanjoYM*/
                     OR A.DATA_KBN = 'M' AND A.SYUEKI_YM >= /*nowkanjoYM*/
                     )
                 )
                 OR
                 (A.DATA_KBN = 'G')
                 OR
                 (A.DATA_KBN = 'K' AND A.SYUEKI_YM IN (/*kiFrom*/, /*kiTo*/))
                 OR
                 (A.DATA_KBN = 'Q' AND A.SYUEKI_YM IN (/*Q1*/, /*Q2*/, /*Q3*/, /*Q4*/))
               )
        GROUP BY A.ANKEN_ID
       ) NOW

      /*IF zenkaiRirekiId != null*/
        LEFT OUTER JOIN
      (SELECT B.ANKEN_ID
            , SUM(CASE WHEN B.DATA_KBN = 'K' AND SYUEKI_YM = /*kiFrom*/ THEN B./*$lossCol*/ END) AS LOSS_K1
            , SUM(CASE WHEN B.DATA_KBN = 'K' AND SYUEKI_YM = /*kiTo*/ THEN B./*$lossCol*/ END) AS LOSS_K2
            , SUM(CASE WHEN B.DATA_KBN = 'G' THEN B./*$lossCol*/ END) AS LOSS_G
            , SUM(CASE WHEN B.DATA_KBN = 'Q' AND SYUEKI_YM = /*Q1*/ THEN B./*$lossCol*/ END) AS LOSS_1Q
            , SUM(CASE WHEN B.DATA_KBN = 'Q' AND SYUEKI_YM = /*Q2*/ THEN B./*$lossCol*/ END) AS LOSS_2Q
            , SUM(CASE WHEN B.DATA_KBN = 'Q' AND SYUEKI_YM = /*Q3*/ THEN B./*$lossCol*/ END) AS LOSS_3Q
            , SUM(CASE WHEN B.DATA_KBN = 'Q' AND SYUEKI_YM = /*Q4*/ THEN B./*$lossCol*/ END) AS LOSS_4Q
         FROM SYU_R_KI_LOSS_TBL B
        WHERE ANKEN_ID = /*ankenId*/
          AND RIREKI_ID = /*zenkaiRirekiId*/
          AND (
                 (B.DATA_KBN = 'G')
                 OR
                 (B.DATA_KBN = 'K' AND B.SYUEKI_YM IN (/*kiFrom*/, /*kiTo*/))
                 OR
                 (B.DATA_KBN = 'Q' AND B.SYUEKI_YM IN (/*Q1*/, /*Q2*/, /*Q3*/, /*Q4*/))
              )
       GROUP BY B.ANKEN_ID
      ) BEF ON NOW.ANKEN_ID = BEF.ANKEN_ID
     /*END*/

GROUP BY NOW.ANKEN_ID