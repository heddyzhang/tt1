-- 売上原価合計
SELECT 1 AS SEQ
     , 1 AS CURRENCY_CODE
     , SUM(NOW.URIAGE_GENKA) AS URIAGE_RUIKEI_AMOUNT
  FROM (
        SELECT ANKEN_ID
             , RIREKI_ID
             , SYUEKI_YM
             , URIAGE_GENKA
          FROM SYU_KI_NET_TOTAL_TBL

         WHERE ANKEN_ID = /*ankenId*/
           AND RIREKI_ID = /*rirekiId*/
           AND SYUEKI_YM in /*kikan*/('1')
           AND DATA_KBN = 'K'
        ) NOW