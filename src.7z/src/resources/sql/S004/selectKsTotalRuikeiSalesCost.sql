-- 売上原価累計合計
SELECT 1 AS SEQ
     , 1 AS CURRENCY_CODE
     , SUM(NOW.URIAGE_AMOUNT_1) AS URIAGE_AMOUNT_1
     , SUM(NOW.URIAGE_AMOUNT_2) AS URIAGE_AMOUNT_2
     , SUM(NOW.URIAGE_AMOUNT_3) AS URIAGE_AMOUNT_3
     , SUM(NOW.URIAGE_AMOUNT_4) AS URIAGE_AMOUNT_4
     , SUM(NOW.URIAGE_AMOUNT_5) AS URIAGE_AMOUNT_5
     , SUM(NOW.URIAGE_AMOUNT_6) AS URIAGE_AMOUNT_6
     , SUM(NOW.URIAGE_AMOUNT_7) AS URIAGE_AMOUNT_7
     , SUM(NOW.URIAGE_AMOUNT_8) AS URIAGE_AMOUNT_8
     , SUM(NOW.URIAGE_AMOUNT_9) AS URIAGE_AMOUNT_9
     , SUM(NOW.URIAGE_AMOUNT_10) AS URIAGE_AMOUNT_10
     , SUM(NOW.URIAGE_AMOUNT_11) AS URIAGE_AMOUNT_11
     , SUM(NOW.URIAGE_AMOUNT_12) AS URIAGE_AMOUNT_12
     , SUM(NOW.URIAGE_AMOUNT_K1) AS URIAGE_AMOUNT_K1
     , SUM(NOW.URIAGE_AMOUNT_K2) AS URIAGE_AMOUNT_K2
     , SUM(NOW.URIAGE_AMOUNT_G) AS URIAGE_AMOUNT_G
     , SUM(NOW.URIAGE_AMOUNT_F) AS URIAGE_AMOUNT_F

     , SUM(NOW.URIAGE_AMOUNT_1Q) AS URIAGE_AMOUNT_1Q
     , SUM(NOW.URIAGE_AMOUNT_2Q) AS URIAGE_AMOUNT_2Q
     , SUM(NOW.URIAGE_AMOUNT_3Q) AS URIAGE_AMOUNT_3Q
     , SUM(NOW.URIAGE_AMOUNT_4Q) AS URIAGE_AMOUNT_4Q

     , NVL(SUM(NOW.URIAGE_AMOUNT_TM_M),0) - SUM(NOW.URIAGE_AMOUNT_TM_J) AS URIAGE_AMOUNT_TM
     /*IF zenkaiRirekiId != null*/
     , NVL(SUM(NOW.URIAGE_AMOUNT_K1),0) - SUM(BEF.URIAGE_AMOUNT_K1) AS URIAGE_AMOUNT_K1_DIFF
     , NVL(SUM(NOW.URIAGE_AMOUNT_K2),0) - SUM(BEF.URIAGE_AMOUNT_K2) AS URIAGE_AMOUNT_K2_DIFF
     , NVL(SUM(NOW.URIAGE_AMOUNT_G),0) - SUM(BEF.URIAGE_AMOUNT_G) AS URIAGE_AMOUNT_G_DIFF

     , NVL(SUM(NOW.URIAGE_AMOUNT_1Q),0) - SUM(BEF.URIAGE_AMOUNT_1Q) AS URIAGE_AMOUNT_1Q_DIFF
     , NVL(SUM(NOW.URIAGE_AMOUNT_2Q),0) - SUM(BEF.URIAGE_AMOUNT_2Q) AS URIAGE_AMOUNT_2Q_DIFF
     , NVL(SUM(NOW.URIAGE_AMOUNT_3Q),0) - SUM(BEF.URIAGE_AMOUNT_3Q) AS URIAGE_AMOUNT_3Q_DIFF
     , NVL(SUM(NOW.URIAGE_AMOUNT_4Q),0) - SUM(BEF.URIAGE_AMOUNT_4Q) AS URIAGE_AMOUNT_4Q_DIFF
     /*END*/
     , NVL(SUM(NOW.URIAGE_AMOUNT_F),0) - SUM(NOW.URIAGE_AMOUNT_G) AS URIAGE_AMOUNT_DIFF
  FROM (
        SELECT ANKEN_ID
             , RIREKI_ID
             , SYUEKI_YM
             , CASE WHEN TO_DATE(/*kanjoYM*/, 'yyyymm') - TO_DATE(/*kikanA*/, 'yyyymm') >= 0
                 THEN CASE WHEN DATA_KBN = 'J' AND SYUEKI_YM = /*kikanA*/ THEN URIAGE_RUIKEI_NET END
               ELSE
                 CASE WHEN DATA_KBN = 'M' AND SYUEKI_YM = /*kikanA*/ THEN URIAGE_RUIKEI_NET END
               END AS URIAGE_AMOUNT_1          
             , CASE WHEN TO_DATE(/*kanjoYM*/, 'yyyymm') - TO_DATE(/*kikanB*/, 'yyyymm') >= 0
                 THEN CASE WHEN DATA_KBN = 'J' AND SYUEKI_YM = /*kikanB*/ THEN URIAGE_RUIKEI_NET END
               ELSE
                 CASE WHEN DATA_KBN = 'M' AND SYUEKI_YM = /*kikanB*/ THEN URIAGE_RUIKEI_NET END
               END AS URIAGE_AMOUNT_2          
             , CASE WHEN TO_DATE(/*kanjoYM*/, 'yyyymm') - TO_DATE(/*kikanC*/, 'yyyymm') >= 0
                 THEN CASE WHEN DATA_KBN = 'J' AND SYUEKI_YM = /*kikanC*/ THEN URIAGE_RUIKEI_NET END
               ELSE
                 CASE WHEN DATA_KBN = 'M' AND SYUEKI_YM = /*kikanC*/ THEN URIAGE_RUIKEI_NET END
               END AS URIAGE_AMOUNT_3          
             , CASE WHEN TO_DATE(/*kanjoYM*/, 'yyyymm') - TO_DATE(/*kikanD*/, 'yyyymm') >= 0
                 THEN CASE WHEN DATA_KBN = 'J' AND SYUEKI_YM = /*kikanD*/ THEN URIAGE_RUIKEI_NET END
               ELSE
                 CASE WHEN DATA_KBN = 'M' AND SYUEKI_YM = /*kikanD*/ THEN URIAGE_RUIKEI_NET END
               END AS URIAGE_AMOUNT_4          
             , CASE WHEN TO_DATE(/*kanjoYM*/, 'yyyymm') - TO_DATE(/*kikanE*/, 'yyyymm') >= 0
                 THEN CASE WHEN DATA_KBN = 'J' AND SYUEKI_YM = /*kikanE*/ THEN URIAGE_RUIKEI_NET END
               ELSE
                 CASE WHEN DATA_KBN = 'M' AND SYUEKI_YM = /*kikanE*/ THEN URIAGE_RUIKEI_NET END
               END AS URIAGE_AMOUNT_5          
             , CASE WHEN TO_DATE(/*kanjoYM*/, 'yyyymm') - TO_DATE(/*kikanF*/, 'yyyymm') >= 0
                 THEN CASE WHEN DATA_KBN = 'J' AND SYUEKI_YM = /*kikanF*/ THEN URIAGE_RUIKEI_NET END
               ELSE
                 CASE WHEN DATA_KBN = 'M' AND SYUEKI_YM = /*kikanF*/ THEN URIAGE_RUIKEI_NET END
               END AS URIAGE_AMOUNT_6          
             , CASE WHEN TO_DATE(/*kanjoYM*/, 'yyyymm') - TO_DATE(/*kikanG*/, 'yyyymm') >= 0
                 THEN CASE WHEN DATA_KBN = 'J' AND SYUEKI_YM = /*kikanG*/ THEN URIAGE_RUIKEI_NET END
               ELSE
                 CASE WHEN DATA_KBN = 'M' AND SYUEKI_YM = /*kikanG*/ THEN URIAGE_RUIKEI_NET END
               END AS URIAGE_AMOUNT_7          
             , CASE WHEN TO_DATE(/*kanjoYM*/, 'yyyymm') - TO_DATE(/*kikanH*/, 'yyyymm') >= 0
                 THEN CASE WHEN DATA_KBN = 'J' AND SYUEKI_YM = /*kikanH*/ THEN URIAGE_RUIKEI_NET END
               ELSE
                 CASE WHEN DATA_KBN = 'M' AND SYUEKI_YM = /*kikanH*/ THEN URIAGE_RUIKEI_NET END
               END AS URIAGE_AMOUNT_8          
             , CASE WHEN TO_DATE(/*kanjoYM*/, 'yyyymm') - TO_DATE(/*kikanI*/, 'yyyymm') >= 0
                 THEN CASE WHEN DATA_KBN = 'J' AND SYUEKI_YM = /*kikanI*/ THEN URIAGE_RUIKEI_NET END
               ELSE
                 CASE WHEN DATA_KBN = 'M' AND SYUEKI_YM = /*kikanI*/ THEN URIAGE_RUIKEI_NET END
               END AS URIAGE_AMOUNT_9          
             , CASE WHEN TO_DATE(/*kanjoYM*/, 'yyyymm') - TO_DATE(/*kikanJ*/, 'yyyymm') >= 0
                 THEN CASE WHEN DATA_KBN = 'J' AND SYUEKI_YM = /*kikanJ*/ THEN URIAGE_RUIKEI_NET END
               ELSE
                 CASE WHEN DATA_KBN = 'M' AND SYUEKI_YM = /*kikanJ*/ THEN URIAGE_RUIKEI_NET END
               END AS URIAGE_AMOUNT_10         
             , CASE WHEN TO_DATE(/*kanjoYM*/, 'yyyymm') - TO_DATE(/*kikanK*/, 'yyyymm') >= 0
                 THEN CASE WHEN DATA_KBN = 'J' AND SYUEKI_YM = /*kikanK*/ THEN URIAGE_RUIKEI_NET END
               ELSE
                 CASE WHEN DATA_KBN = 'M' AND SYUEKI_YM = /*kikanK*/ THEN URIAGE_RUIKEI_NET END
               END AS URIAGE_AMOUNT_11         
             , CASE WHEN TO_DATE(/*kanjoYM*/, 'yyyymm') - TO_DATE(/*kikanL*/, 'yyyymm') >= 0
                 THEN CASE WHEN DATA_KBN = 'J' AND SYUEKI_YM = /*kikanL*/ THEN URIAGE_RUIKEI_NET END
               ELSE
                 CASE WHEN DATA_KBN = 'M' AND SYUEKI_YM = /*kikanL*/ THEN URIAGE_RUIKEI_NET END
               END AS URIAGE_AMOUNT_12

             , CASE WHEN DATA_KBN = 'J' AND SYUEKI_YM = /*tmYm*/ THEN URIAGE_RUIKEI_NET
                    ELSE NULL
               END AS URIAGE_AMOUNT_TM_J
             , CASE WHEN DATA_KBN = 'M' AND SYUEKI_YM = /*tmYm*/ THEN URIAGE_RUIKEI_NET
                    ELSE NULL
               END AS URIAGE_AMOUNT_TM_M

             , CASE WHEN DATA_KBN = 'G' AND SYUEKI_YM = '999900G' THEN URIAGE_RUIKEI_NET END AS URIAGE_AMOUNT_G
             , CASE WHEN DATA_KBN = 'F' AND SYUEKI_YM = '999900M' THEN URIAGE_RUIKEI_NET END AS URIAGE_AMOUNT_F
             , CASE WHEN DATA_KBN = 'K' AND SYUEKI_YM = /*kiFrom*/ THEN URIAGE_RUIKEI_NET END AS URIAGE_AMOUNT_K1
             , CASE WHEN DATA_KBN = 'K' AND SYUEKI_YM = /*kiTo*/ THEN URIAGE_RUIKEI_NET END AS URIAGE_AMOUNT_K2

             , CASE WHEN DATA_KBN = 'Q' AND SYUEKI_YM = /*Q1*/ THEN URIAGE_RUIKEI_NET END AS URIAGE_AMOUNT_1Q
             , CASE WHEN DATA_KBN = 'Q' AND SYUEKI_YM = /*Q2*/ THEN URIAGE_RUIKEI_NET END AS URIAGE_AMOUNT_2Q
             , CASE WHEN DATA_KBN = 'Q' AND SYUEKI_YM = /*Q3*/ THEN URIAGE_RUIKEI_NET END AS URIAGE_AMOUNT_3Q
             , CASE WHEN DATA_KBN = 'Q' AND SYUEKI_YM = /*Q4*/ THEN URIAGE_RUIKEI_NET END AS URIAGE_AMOUNT_4Q
          FROM /*IF rirekiFlg == "R"*/
                SYU_R_KI_NET_TOTAL_TBL
                /*END*/
                /*IF rirekiFlg != "R"*/
                SYU_KI_NET_TOTAL_TBL
                /*END*/  
         WHERE ANKEN_ID = /*ankenId*/
           AND RIREKI_ID = /*rirekiId*/
           AND (SYUEKI_YM BETWEEN /*kikanA*/ AND /*kikanL*/
             OR SYUEKI_YM = '999900G'
             OR SYUEKI_YM = '999900M'
             OR SYUEKI_YM = /*kiFrom*/
             OR SYUEKI_YM = /*kiTo*/

             OR SYUEKI_YM = /*Q1*/
             OR SYUEKI_YM = /*Q2*/
             OR SYUEKI_YM = /*Q3*/
             OR SYUEKI_YM = /*Q4*/

             OR SYUEKI_YM = /*tmYm*/
               )
        ) NOW
        /*IF zenkaiRirekiId != null*/
        LEFT OUTER JOIN (
            SELECT ANKEN_ID
                 , RIREKI_ID
                 , SYUEKI_YM
                 , CASE WHEN DATA_KBN = 'K' AND SYUEKI_YM = /*kiFrom*/ THEN URIAGE_RUIKEI_NET END AS URIAGE_AMOUNT_K1
                 , CASE WHEN DATA_KBN = 'K' AND SYUEKI_YM = /*kiTo*/ THEN URIAGE_RUIKEI_NET END AS URIAGE_AMOUNT_K2
                 , CASE WHEN DATA_KBN = 'G' AND SYUEKI_YM = '999900G' THEN URIAGE_RUIKEI_NET END AS URIAGE_AMOUNT_G

                 , CASE WHEN DATA_KBN = 'Q' AND SYUEKI_YM = /*Q1*/ THEN URIAGE_RUIKEI_NET END AS URIAGE_AMOUNT_1Q
                 , CASE WHEN DATA_KBN = 'Q' AND SYUEKI_YM = /*Q2*/ THEN URIAGE_RUIKEI_NET END AS URIAGE_AMOUNT_2Q
                 , CASE WHEN DATA_KBN = 'Q' AND SYUEKI_YM = /*Q3*/ THEN URIAGE_RUIKEI_NET END AS URIAGE_AMOUNT_3Q
                 , CASE WHEN DATA_KBN = 'Q' AND SYUEKI_YM = /*Q4*/ THEN URIAGE_RUIKEI_NET END AS URIAGE_AMOUNT_4Q
              FROM SYU_R_KI_NET_TOTAL_TBL
             WHERE ANKEN_ID = /*ankenId*/
               AND RIREKI_ID = /*zenkaiRirekiId*/
               AND (SYUEKI_YM = '999900G'
                 OR SYUEKI_YM = /*kiFrom*/
                 OR SYUEKI_YM = /*kiTo*/

                 OR SYUEKI_YM = /*Q1*/
                 OR SYUEKI_YM = /*Q2*/
                 OR SYUEKI_YM = /*Q3*/
                 OR SYUEKI_YM = /*Q4*/
                   )
            ) BEF ON NOW.ANKEN_ID = BEF.ANKEN_ID AND NOW.SYUEKI_YM = BEF.SYUEKI_YM
        /*END*/  