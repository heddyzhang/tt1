SELECT MITSUMORI_GENKA_NET
  FROM 
       /*IF rirekiFlg == "R"*/
       SYU_R_KI_NET_SOGENKA_TOTAL_TBL
       /*END*/
       /*IF rirekiFlg != "R"*/
       SYU_KI_NET_SOGENKA_TOTAL_TBL
       /*END*/
 WHERE ANKEN_ID = /*ankenId*/
   AND RIREKI_ID = /*rirekiId*/
   AND DATA_KBN = /*dataKbn*/
   AND SYUEKI_YM = /*syuekiYm*/