SELECT ANKEN_ID
     , RIREKI_ID
     , ANKEN_REV
     , ANKEN_MATOME_NO
     , ORDER_NO
  FROM /*IF rirekiFlg == "R"*/
        SYU_R_GE_BUKKEN_INFO_TBL
        /*END*/
        /*IF rirekiFlg != "R"*/
        SYU_GE_BUKKEN_INFO_TBL
        /*END*/ 
 WHERE ANKEN_ID = /*ankenId*/
   AND RIREKI_ID = /*rirekiId*/
   AND SYUEKI_FLG = '1'
   AND IS_DELETED = '0'