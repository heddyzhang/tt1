SELECT *
  FROM SESSION_TBL
 WHERE SESSION_ID = /*sessionId*/
   AND IDTUID = /*tuid*/