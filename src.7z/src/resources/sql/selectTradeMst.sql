SELECT
/*IF listFlg == "1"*/
       COUNT(*) AS COUNT
/*END*/
/*IF listFlg != "1"*/
       ES86031_TRADE_CD_J AS TRADE_CD
     , ES86031_TRADE_NM AS TRADE_NM
/*END*/
  FROM ES86031_TBL
 WHERE ES86031_TRADE_KBN IN ('2','3')
/*IF tradeName != null && tradeName != ''*/
   AND GET_CHANGE_SEARCH_STR(ES86031_TRADE_NM) LIKE '%' || GET_CHANGE_SEARCH_STR(/*tradeName*/) || '%'
/*END*/
/*IF tradeCode != null && tradeCode != ''*/
   AND ES86031_TRADE_CD_J LIKE /*tradeCode*/ || '%'
/*END*/
/*IF listFlg != "1"*/
ORDER BY ES86031_TRADE_CD_J
/*END*/
