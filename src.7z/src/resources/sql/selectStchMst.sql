SELECT 
/*IF listFlg == "1"*/
       COUNT(*) AS COUNT
/*END*/
/*IF listFlg != "1"*/
       *
/*END*/
  FROM ES88051_TBL
 WHERE STCH_NAME_J IS NOT NULL
   AND NVL(DEL_FLG, '0') = '0'
/*IF stchName != null && stchName != ''*/
   AND GET_CHANGE_SEARCH_STR(STCH_NAME_J) LIKE '%' || GET_CHANGE_SEARCH_STR(/*stchName*/) || '%'
/*END*/
/*IF stchCode != null && stchCode != ''*/
   AND NEW_STCH_CD LIKE /*stchCode*/ || '%'
/*END*/
/*IF listFlg != "1"*/
ORDER BY NEW_STCH_CD
/*END*/
