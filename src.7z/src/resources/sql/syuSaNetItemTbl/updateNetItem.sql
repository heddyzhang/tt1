UPDATE SYU_SA_NET_ITEM_TBL
   SET NET_ENKA = /*enka*/
     , CURRENCY_CODE = /*currencyCode*/
     , RATE = /*rate*/
     , NET_GAIKA = /*gaika*/
     , UPDATED_AT = /*updatedAt*/
     , UPDATED_BY = /*updatedBy*/
 WHERE ANKEN_ID = /*ankenId*/
   AND RIREKI_ID = /*rirekiId*/
   AND DATA_KBN = /*dataKbn*/
   AND ORDER_NO = /*orderNo*/
   AND ORDER_ITEM = /*befOrderItem*/