INSERT INTO SYU_SA_NET_ITEM_TBL (
      ANKEN_ID
    , RIREKI_ID
    , DATA_KBN
    , ORDER_NO
    , ORDER_ITEM
    , NET_ENKA
    , CURRENCY_CODE
    , RATE
    , NET_GAIKA
    , CREATED_AT
    , CREATED_BY
    , UPDATED_AT
    , UPDATED_BY
) VALUES (
      /*ankenId*/
    , /*rirekiId*/
    , /*dataKbn*/
    , /*orderNo*/
    , /*befOrderItem*/
    , /*enka*/
    , /*currencyCode*/
    , /*rate*/
    , /*gaika*/
    , /*createdAt*/
    , /*createdBy*/
    , /*updatedAt*/
    , /*updatedBy*/
)