SELECT COUNT(*) AS COUNT
           FROM ANKEN_SYOKUSYU_ROLE_TBL AP
          WHERE AP.ANKEN_NO = /*ankenId*/
            AND AP.JOB_GROUP_CODE IN /*memberJobGr*/('1')
            AND ROWNUM <= 1