SELECT G.ANKEN_ID
     , G.RIREKI_ID
     , G.ANKEN_REV
     , G.ORDER_NO
     , G.ANKEN_NAME
  FROM 
/*IF rirekiFlg == "R"*/
       SYU_R_GE_BUKKEN_INFO_TBL G
     , ( SELECT M.ANKEN_NO
           FROM SYU_R_MATOME_ID_TBL M
          WHERE M.ANKEN_MATOME_NO = /*ankenId*/
            AND M.RIREKI_ID = /*rirekiId*/
       ) M
/*END*/
/*IF rirekiFlg != "R"*/
       SYU_GE_BUKKEN_INFO_TBL G
     , ( SELECT M.ANKEN_NO
           FROM ANKEN_MATOME_MAP_TBL M
          WHERE M.ANKEN_MATOME_NO = /*ankenId*/
       ) M
/*END*/ 
 WHERE G.ANKEN_ID = M.ANKEN_NO
   AND G.RIREKI_ID = /*rirekiId*/
   AND G.SYUEKI_FLG = '1'
   AND G.IS_DELETED = '0'
ORDER BY G.ANKEN_ID