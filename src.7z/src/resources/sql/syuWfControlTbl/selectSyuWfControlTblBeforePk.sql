SELECT TBL.*
  FROM SYU_WF_CONTROL_TBL TBL
 WHERE TBL.DIVISION_CODE = /*divisionCode*/
   AND TBL.GROUP_CODE = /*groupCode*/
   AND TBL.SALES_CLASS = /*salesClass*/
   AND TBL.HONSYA_SHISYA_KBN = /*honsyaShisyaKbn*/
   AND TBL.TEAM_CODE = /*teamCode*/
   AND TBL.SYUBETSU = /*syubetsu*/
   AND TBL.STATUS = '10'
   AND TBL.KANJYO_YM =
       ( SELECT MAX(B.KANJYO_YM)
           FROM SYU_WF_CONTROL_TBL B
          WHERE B.DIVISION_CODE = TBL.DIVISION_CODE
            AND B.GROUP_CODE = TBL.GROUP_CODE
            AND B.SALES_CLASS = TBL.SALES_CLASS
            AND B.SYUBETSU = TBL.SYUBETSU
            AND B.HONSYA_SHISYA_KBN = TBL.HONSYA_SHISYA_KBN
            AND B.TEAM_CODE = TBL.TEAM_CODE
            AND B.STATUS = TBL.STATUS
            AND B.KANJYO_YM <= /*beforeKanjyoYm*/
       )