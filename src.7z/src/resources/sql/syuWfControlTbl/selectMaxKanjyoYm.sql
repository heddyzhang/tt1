SELECT MAX(WC.KANJYO_YM) AS STRING
  FROM SYU_WF_CONTROL_TBL WC
 WHERE WC.SYUBETSU = /*dataKbn*/
   AND WC.DISP_FLG = '1'
/*IF divisionCode != null && divisionCode != ""*/
   AND WC.DIVISION_CODE = /*divisionCode*/
/*END*/
/*IF groupCode != null && groupCode != ""*/
   AND WC.C_BUKA_CODE = /*groupCode*/
/*END*/
/*IF salesClass != null*/
   AND WC.SALES_CLASS IN /*salesClass*/('1')
/*END*/