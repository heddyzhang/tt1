SELECT 
/*IF listFlg == "1"*/
       COUNT(*) AS COUNT
/*END*/
/*IF listFlg != "1"*/
       TBL.*
/*END*/
  FROM SYU_WF_CONTROL_TBL TBL
 WHERE DIVISION_CODE IN /*divisionCode*/('1')
/*IF groupCode != null && groupCode != ""*/
   AND (GROUP_CODE = /*groupCode*/ OR C_BUKA_CODE = /*groupCode*/)
/*END*/
/*IF dataKbn != null && dataKbn != ""*/
   AND SYUBETSU = /*dataKbn*/
/*END*/
/*IF fixedYmFrom != null && fixedYmFrom != ""*/
   AND KANJYO_YM >= REPLACE(/*fixedYmFrom*/, '/')
/*END*/
/*IF fixedYmTo != null && fixedYmTo != ""*/
   AND KANJYO_YM <= REPLACE(/*fixedYmTo*/, '/')
/*END*/
/*IF taisho != null && taisho != ""*/
   AND KANJYO_YM = REPLACE(/*taisho*/, '/')
/*END*/
/*IF salesClass != null*/
   AND SALES_CLASS IN /*salesClass*/('1')
/*END*/
   AND DISP_FLG = '1'
ORDER BY DIVISION_CODE
       , GROUP_CODE
       , SALES_CLASS
       , KANJYO_YM DESC