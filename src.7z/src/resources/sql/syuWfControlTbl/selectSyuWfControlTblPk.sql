SELECT TBL.*
  FROM SYU_WF_CONTROL_TBL TBL
 WHERE DIVISION_CODE = /*divisionCode*/
   AND GROUP_CODE = /*groupCode*/
   AND SALES_CLASS = /*salesClass*/
   AND KANJYO_YM = /*kanjyoYm*/
   AND HONSYA_SHISYA_KBN = /*honsyaShisyaKbn*/
   AND TEAM_CODE = /*teamCode*/