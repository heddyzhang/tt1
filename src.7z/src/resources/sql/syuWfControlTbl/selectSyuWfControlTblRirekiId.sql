SELECT RIREKI_ID AS STRING
  FROM SYU_WF_CONTROL_TBL
 WHERE RIREKI_ID IS NOT NULL
   AND DIVISION_CODE IN /*divisionCode*/('1')
/*IF salesClass != null*/
   AND SALES_CLASS IN /*salesClass*/('1')
/*END*/
/*IF taishoYm != null && taishoYm != ""*/
   AND KANJYO_YM = /*taishoYm*/
/*END*/
 ORDER BY RIREKI_ID