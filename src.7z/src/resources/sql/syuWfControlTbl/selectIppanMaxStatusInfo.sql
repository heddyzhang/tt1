SELECT /*divisionCode*/    AS DIVISION_CODE
     , ' '                 AS GROUP_CODE
     , /*honsyaShisyaKbn*/ AS HONSYA_SHISYA_KBN
     , ' '                 AS TEAM_CODE
     , /*salesClass*/      AS SALES_CLASS
     , /*kanjyoYm*/        AS KANJYO_YM
     , MIN(WF2.STATUS)     AS STATUS
     , MAX(WF2.KANJYO_1Q)  AS KANJYO_1Q
     , SUM(WF2.SP_1Q)      AS SP_1Q
     , SUM(WF2.NET_1Q)     AS NET_1Q
     , MAX(WF2.KANJYO_2Q)  AS KANJYO_2Q
     , SUM(WF2.SP_2Q)      AS SP_2Q
     , SUM(WF2.NET_2Q)     AS NET_2Q
     , MAX(WF2.KANJYO_3Q)  AS KANJYO_3Q
     , SUM(WF2.SP_3Q)      AS SP_3Q
     , SUM(WF2.NET_3Q)     AS NET_3Q
     , MAX(WF2.KANJYO_4Q)  AS KANJYO_4Q
     , SUM(WF2.SP_4Q)      AS SP_4Q
     , SUM(WF2.NET_4Q)     AS NET_4Q
     , SUM(WF2.SP_TOTAL)   AS SP_TOTAL
     , SUM(WF2.NET_TOTAL)  AS NET_TOTAL
  FROM SYU_WF_CONTROL_TBL WF2
 WHERE WF2.DISP_FLG = '0'
   AND WF2.DIVISION_CODE = /*divisionCode*/
   AND WF2.SALES_CLASS = /*salesClass*/
   AND WF2.KANJYO_YM = /*kanjyoYm*/
   AND (WF2.C_BUKA_CODE = /*cBukaCode*/ OR WF2.GROUP_CODE = /*cBukaCode*/)