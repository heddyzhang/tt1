SELECT WF.*
  FROM SYU_WF_CONTROL_TBL WF
 WHERE WF.DISP_FLG = '0'
   AND WF.DIVISION_CODE = /*divisionCode*/
   AND WF.SALES_CLASS = /*salesClass*/
   AND WF.KANJYO_YM = /*kanjyoYm*/
   AND(WF.C_BUKA_CODE = /*cBukaCode*/ OR WF.GROUP_CODE = /*cBukaCode*/)
/*IF concatTeamCode != null*/
   AND TEAM_CODE IN /*concatTeamCode*/('X')
/*END*/