SELECT WF.*
  FROM SYU_WF_CONTROL_TBL WF
WHERE DIVISION_CODE in /*divisionCode*/('N8')
  AND SALES_CLASS in /*salesClass*/(0)
  AND HONSYA_SHISYA_KBN ='S'
  AND DISP_FLG ='0'
  AND RIREKI_ID NOT IN /*targetRirekiId*/(0)
  AND STATUS ='10'
/*IF syubetsu == null || syubetsu != "Y"*/
   AND WF.KANJYO_YM = /*kanjyoYm*/
/*END*/
/*IF syubetsu != null && syubetsu == "Y"*/
   AND WF.SYUBETSU = /*syubetsu*/
   AND WF.KANJYO_YM LIKE /*ki*/ || '%'
   AND WF.RIREKI_ID IS NOT NULL
   AND NOT EXISTS
       (SELECT 'X'
          FROM SYU_WF_CONTROL_TBL B
         WHERE B.DIVISION_CODE = WF.DIVISION_CODE
           AND B.GROUP_CODE = WF.GROUP_CODE
           AND B.SALES_CLASS = WF.SALES_CLASS
           AND B.HONSYA_SHISYA_KBN = WF.HONSYA_SHISYA_KBN
           AND B.TEAM_CODE = WF.TEAM_CODE
           AND B.KANJYO_YM > WF.KANJYO_YM
           AND B.SYUBETSU = WF.SYUBETSU
           AND B.KANJYO_YM LIKE /*ki*/ || '%'
           AND B.RIREKI_ID IS NOT NULL
        )
/*END*/
