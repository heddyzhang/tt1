UPDATE SYU_WF_CONTROL_TBL
   SET UPDATED_AT = SYSDATE
     , UPDATED_BY = /*userId*/
     , STATUS = /*status*/

/*IF hininCommentFlg == "1"*/
     , HININ_AT = SYSDATE
     , HININ_BY = /*userId*/
     , HININ_NAME = /*userName*/
     , HININ_COMMENT = /*comment*/
/*END*/
/*IF status == "01"*/
     , KANJYO_1Q = NULL
     , SP_1Q = NULL
     , NET_1Q = NULL
     , KANJYO_2Q = NULL
     , SP_2Q = NULL
     , NET_2Q = NULL
     , KANJYO_3Q = NULL
     , SP_3Q = NULL
     , NET_3Q = NULL
     , KANJYO_4Q = NULL
     , SP_4Q = NULL
     , NET_4Q = NULL
     , SP_TOTAL = NULL
     , NET_TOTAL = NULL

     , RIREKI_ID = NULL
     , KISO_AT = NULL
     , KISO_BY = NULL
     , KISO_NAME = NULL
     , KISO_COMMENT = NULL
     , CHOSA_AT = NULL
     , CHOSA_BY = NULL
     , CHOSA_NAME = NULL
     , CHOSA_COMMENT = NULL
     , SYONIN_AT = NULL
     , SYONIN_BY = NULL
     , SYONIN_NAME = NULL
     , SYONIN_COMMENT = NULL
/*END*/
/*IF status == teishutsuStatus*/
     , RIREKI_ID = /*rirekiId*/
     , SYONIN_AT = NULL
     , SYONIN_BY = NULL
     , SYONIN_NAME = NULL
     , SYONIN_COMMENT = NULL
/*END*/
/*IF status == "10"*/
     , RIREKI_ID = /*rirekiId*/
     , SYONIN_AT = SYSDATE
     , SYONIN_BY = /*userId*/
     , SYONIN_NAME = /*userName*/
     , SYONIN_COMMENT = /*comment*/
     , HININ_AT = NULL
     , HININ_BY = NULL
     , HININ_NAME = NULL
     , HININ_COMMENT = NULL
/*END*/
 WHERE DIVISION_CODE = /*divisionCode*/
   AND GROUP_CODE = /*groupCode*/
   AND SALES_CLASS = /*salesClass*/
   AND KANJYO_YM = /*kanjyoYm*/
   AND HONSYA_SHISYA_KBN = /*honsyaShisyaKbn*/
   AND TEAM_CODE = /*teamCode*/