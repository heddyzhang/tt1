SELECT A.*
  FROM SYU_WF_CONTROL_TBL A
 WHERE 1 = 1
   AND (A.GROUP_CODE = /*cBukaCode*/ OR A.C_BUKA_CODE = /*cBukaCode*/)
/*IF divisionCode != null && divisionCode != ""*/
   AND A.DIVISION_CODE IN /*divisionCode*/('0')
/*END*/
/*IF salesClass != null && salesClass != ""*/
   AND A.SALES_CLASS IN /*salesClass*/('0')
/*END*/
/*IF dispFlg != null && dispFlg != ""*/
   AND A.DISP_FLG = /*dispFlg*/
/*END*/
/*IF syubetsu == null || syubetsu != "Y"*/
   AND A.KANJYO_YM = /*kanjyoYm*/
/*END*/
/*IF syubetsu != null && syubetsu == "Y"*/
   AND A.SYUBETSU = /*syubetsu*/
   AND A.KANJYO_YM LIKE /*ki*/ || '%'
   AND A.RIREKI_ID IS NOT NULL
   AND NOT EXISTS
       (SELECT 'X'
          FROM SYU_WF_CONTROL_TBL B
         WHERE B.DIVISION_CODE = A.DIVISION_CODE
           AND B.GROUP_CODE = A.GROUP_CODE
           AND B.SALES_CLASS = A.SALES_CLASS
           AND B.HONSYA_SHISYA_KBN = A.HONSYA_SHISYA_KBN
           AND B.TEAM_CODE = A.TEAM_CODE
           AND B.KANJYO_YM > A.KANJYO_YM
           AND B.SYUBETSU = A.SYUBETSU
           AND B.KANJYO_YM LIKE /*ki*/ || '%'
           AND B.RIREKI_ID IS NOT NULL
        )
/*END*/
ORDER BY HONSYA_SHISYA_KBN, C_BUKA_CODE, TEAM_CODE