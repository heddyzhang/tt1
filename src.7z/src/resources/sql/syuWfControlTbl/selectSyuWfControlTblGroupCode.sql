SELECT TBL.*
  FROM SYU_WF_CONTROL_TBL TBL
 WHERE DIVISION_CODE = /*divisionCode*/
   AND (GROUP_CODE = /*groupCode*/ OR C_BUKA_CODE = /*groupCode*/)
   AND SALES_CLASS = /*salesClass*/
   AND KANJYO_YM = /*kanjyoYm*/
   AND (  (DISP_FLG = '0' AND HONSYA_SHISYA_KBN = 'S')
       OR (DISP_FLG = '1' AND HONSYA_SHISYA_KBN = 'H') )