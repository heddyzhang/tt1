UPDATE SYU_WF_CONTROL_TBL WF
   SET STATUS     = /*status*/
     , UPDATED_AT = SYSDATE
     , UPDATED_BY = /*userId*/

/*IF hininCommentFlg == "1"*/
     , HININ_AT = SYSDATE
     , HININ_BY = /*userId*/
     , HININ_NAME = /*userName*/
     , HININ_COMMENT = /*comment*/
/*END*/

/*IF status == "01"*/
     , KANJYO_1Q  = NULL
     , SP_1Q      = NULL
     , NET_1Q     = NULL
     , KANJYO_2Q  = NULL
     , SP_2Q      = NULL
     , NET_2Q     = NULL
     , KANJYO_3Q  = NULL
     , SP_3Q      = NULL
     , NET_3Q     = NULL
     , KANJYO_4Q  = NULL
     , SP_4Q      = NULL
     , NET_4Q     = NULL
     , SP_TOTAL   = NULL
     , NET_TOTAL  = NULL
     , KISO_AT = NULL
     , KISO_BY = NULL
     , KISO_NAME = NULL
     , KISO_COMMENT = NULL
     , CHOSA_AT = NULL
     , CHOSA_BY = NULL
     , CHOSA_NAME = NULL
     , CHOSA_COMMENT = NULL
     , SYONIN_AT = NULL
     , SYONIN_BY = NULL
     , SYONIN_NAME = NULL
     , SYONIN_COMMENT = NULL
/*END*/
/*IF status == teishutsuStatus*/
     , SYONIN_AT = NULL
     , SYONIN_BY = NULL
     , SYONIN_NAME = NULL
     , SYONIN_COMMENT = NULL
/*END*/
/*IF status == "10"*/
     , SYONIN_AT = SYSDATE
     , SYONIN_BY = /*userId*/
     , SYONIN_NAME = /*userName*/
     , SYONIN_COMMENT = /*comment*/
     , HININ_AT = NULL
     , HININ_BY = NULL
     , HININ_NAME = NULL
     , HININ_COMMENT = NULL
/*END*/
/*IF status == "10" || status == teishutsuStatus*/
     , KANJYO_1Q  = /*kanjyo1q*/
     , SP_1Q      = /*sp1q*/
     , NET_1Q     = /*net1q*/
     , KANJYO_2Q  = /*kanjyo2q*/
     , SP_2Q      = /*sp2q*/
     , NET_2Q     = /*net2q*/
     , KANJYO_3Q  = /*kanjyo3q*/
     , SP_3Q      = /*sp3q*/
     , NET_3Q     = /*net3q*/
     , KANJYO_4Q  = /*kanjyo4q*/
     , SP_4Q      = /*sp4q*/
     , NET_4Q     = /*net4q*/
     , SP_TOTAL   = /*spTotal*/
     , NET_TOTAL  = /*netTotal*/
/*END*/
 WHERE WF.DIVISION_CODE = /*divisionCode*/
   AND WF.GROUP_CODE = /*groupCode*/
   AND WF.HONSYA_SHISYA_KBN = /*honsyaShisyaKbn*/
   AND WF.TEAM_CODE = /*teamCode*/
   AND WF.SALES_CLASS = /*salesClass*/
   AND WF.KANJYO_YM = /*kanjyoYm*/