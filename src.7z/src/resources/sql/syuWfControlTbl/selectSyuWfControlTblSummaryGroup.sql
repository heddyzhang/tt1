SELECT   
     ' ' AS DIVISION_CODE
     , A.GROUP_CODE
     , ' ' AS HONSYA_SHISYA_KBN
     , ' ' AS TEAM_CODE
     , ' ' AS SALES_CLASS
     , /*kanjyoYm*/ AS KANJYO_YM
     , A.TANTO_NM
  FROM SYU_WF_CONTROL_TBL A
 WHERE A.DIVISION_CODE IN /*divisionCode*/('1')
   AND A.KANJYO_YM = /*kanjyoYm*/
/*IF shisyaHonsyaKbn != null && shisyaHonsyaKbn != ""*/
   AND A.HONSYA_SHISYA_KBN = /*shisyaHonsyaKbn*/
/*END*/
   AND A.DISP_FLG ='1'
/*IF salesClass != null && salesClass != ""*/
   AND A.SALES_CLASS IN /*salesClass*/('1')
/*END*/
/*IF groupCode != null && groupCode != ""*/
   AND A.GROUP_CODE = /*groupCode*/
/*END*/
/*IF teamCode != null && teamCode != ""*/
   AND A.TEAM_CODE = /*teamCode*/
/*END*/
/*IF dispFlg != null && dispFlg != ""*/
   AND A.DISP_FLG = /*dispFlg*/
/*END*/
GROUP BY GROUP_CODE, TANTO_NM
ORDER BY GROUP_CODE
