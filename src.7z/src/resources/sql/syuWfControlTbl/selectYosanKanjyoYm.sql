SELECT DISTINCT(WC.KANJYO_YM) AS KANJYO_YM
     , 'X' AS DIVISION_CODE
     , 'X' AS GROUP_CODE
     , 'X' AS SALES_CLASS
     , 'X' AS SYUBETSU
     , 'X' AS HONSYA_SHISYA_KBN
     , 'X' AS TEAM_CODE
  FROM SYU_WF_CONTROL_TBL WC
 WHERE WC.SYUBETSU = /*dataKbn*/
   AND DISP_FLG = '1'
   AND DIVISION_CODE IN /*divisionCode*/('1')
/*IF groupCode != null && groupCode != ""*/
   AND (GROUP_CODE = /*groupCode*/ OR C_BUKA_CODE = /*groupCode*/)
/*END*/
/*IF salesClass != null*/
   AND SALES_CLASS IN /*salesClass*/('1')
/*END*/
 
ORDER BY WC.KANJYO_YM DESC   