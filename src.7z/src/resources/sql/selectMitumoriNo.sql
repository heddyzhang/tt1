SELECT DECODE(TBL.STRING, NULL, ' ', TBL.STRING) AS STRING
  FROM (SELECT PACK_MITUMORI_NO.FUNC_GET_MITUMORI_NO(/*ankenId*/, /*rirekiId*/, /*ankenFlg*/, /*rirekiFlg*/) AS STRING
          FROM DUAL
       ) TBL

