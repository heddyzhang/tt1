SELECT T.ANKEN_ID
     , T.RIREKI_ID
     , SUM(T.SP1)  AS SP1
     , SUM(T.SP2)  AS SP2
     , SUM(T.SP3)  AS SP3
     , SUM(T.SP4)  AS SP4
     , SUM(T.SP5)  AS SP5
     , SUM(T.SP6)  AS SP6
     , SUM(T.NET1) AS NET1
     , SUM(T.NET2) AS NET2
     , SUM(T.NET3) AS NET3
     , SUM(T.NET4) AS NET4
     , SUM(T.NET5) AS NET5
     , SUM(T.NET6) AS NET6
  FROM (SELECT B.ANKEN_ID
             , B.RIREKI_ID
             , NULL AS SP1
             , NULL AS SP2
             , NULL AS SP3
             , NULL AS SP4
             , NULL AS SP5
             , NULL AS SP6
             , SUM(CASE WHEN B.SYUEKI_YM = /*syuekiYm1*/ THEN B.URIAGE_GENKA ELSE NULL END) AS NET1
             , SUM(CASE WHEN B.SYUEKI_YM = /*syuekiYm2*/ THEN B.URIAGE_GENKA ELSE NULL END) AS NET2
             , SUM(CASE WHEN B.SYUEKI_YM = /*syuekiYm3*/ THEN B.URIAGE_GENKA ELSE NULL END) AS NET3
             , SUM(CASE WHEN B.SYUEKI_YM = /*syuekiYm4*/ THEN B.URIAGE_GENKA ELSE NULL END) AS NET4
             , SUM(CASE WHEN B.SYUEKI_YM = /*syuekiYm5*/ THEN B.URIAGE_GENKA ELSE NULL END) AS NET5
             , SUM(CASE WHEN B.SYUEKI_YM = /*syuekiYm6*/ THEN B.URIAGE_GENKA ELSE NULL END) AS NET6
          FROM SYU_KI_NET_TOTAL_TBL B
         WHERE B.ANKEN_ID = /*ankenId*/
           AND B.RIREKI_ID = /*rirekiId*/
           AND B.SYUEKI_YM BETWEEN /*syuekiYm1*/ AND /*syuekiYm6*/
           AND (  B.DATA_KBN = 'J' AND B.SYUEKI_YM < /*kanjyoYm*/
               OR B.DATA_KBN = 'M' AND B.SYUEKI_YM >= /*kanjyoYm*/)
        GROUP BY B.ANKEN_ID, B.RIREKI_ID
        UNION ALL
        SELECT C.ANKEN_ID
             , C.RIREKI_ID
             , SUM(CASE WHEN C.SYUEKI_YM = /*syuekiYm1*/ THEN C.URIAGE_AMOUNT ELSE NULL END) AS SP1
             , SUM(CASE WHEN C.SYUEKI_YM = /*syuekiYm2*/ THEN C.URIAGE_AMOUNT ELSE NULL END) AS SP2
             , SUM(CASE WHEN C.SYUEKI_YM = /*syuekiYm3*/ THEN C.URIAGE_AMOUNT ELSE NULL END) AS SP3
             , SUM(CASE WHEN C.SYUEKI_YM = /*syuekiYm4*/ THEN C.URIAGE_AMOUNT ELSE NULL END) AS SP4
             , SUM(CASE WHEN C.SYUEKI_YM = /*syuekiYm5*/ THEN C.URIAGE_AMOUNT ELSE NULL END) AS SP5
             , SUM(CASE WHEN C.SYUEKI_YM = /*syuekiYm6*/ THEN C.URIAGE_AMOUNT ELSE NULL END) AS SP6
             , NULL AS NET1
             , NULL AS NET2
             , NULL AS NET3
             , NULL AS NET4
             , NULL AS NET5
             , NULL AS NET6
          FROM SYU_KI_SP_TOTAL_TBL C
         WHERE C.ANKEN_ID = /*ankenId*/
           AND C.RIREKI_ID = /*rirekiId*/
           AND C.SYUEKI_YM BETWEEN /*syuekiYm1*/ AND /*syuekiYm6*/
           AND (  C.DATA_KBN = 'J' AND C.SYUEKI_YM < /*kanjyoYm*/
               OR C.DATA_KBN = 'M' AND C.SYUEKI_YM >= /*kanjyoYm*/)
        GROUP BY C.ANKEN_ID, C.RIREKI_ID
        ) T
GROUP BY T.ANKEN_ID, T.RIREKI_ID