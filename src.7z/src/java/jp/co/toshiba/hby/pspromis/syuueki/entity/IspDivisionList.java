package jp.co.toshiba.hby.pspromis.syuueki.entity;

import java.io.Serializable;
import java.math.BigDecimal;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.validation.constraints.NotNull;

/**
 *
 * @author ganryu
 */
@Entity
public class IspDivisionList implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @NotNull
    @Column(name = "ANKEN_ID")
    private String ankenId;
    @NotNull
    @Column(name = "ANKEN_REV")
    private long ankenRev;
    @Id
    @NotNull
    @Column(name = "RIREKI_ID")
    private int rirekiId;
    @Column(name = "ORDER_NO")
    private String orderNo;
    @Column(name = "ISP_DIVISION_NM")
    private String ispDivisionNm;
    @Column(name = "ANKEN_NAME")
    private String ankenName;
    @Column(name = "SAISYU_SP")
    private String saisyuSp;
    @Column(name = "SAISYU_NET")
    private String saisyuNet;
    @Column(name = "URIAGE_SP")
    private String uriageSp;
    @Column(name = "URIAGE_NET")
    private String uriageNet;
    @Column(name = "URIAGE_TOV")
    private String uriageTov;
    @Column(name = "ARARI")
    private String arari;
    @Column(name = "MRATE")
    private String mrate;
    @Column(name = "SHIRAJI_FLG")
    private String shirajiFlg = "0";

    public IspDivisionList() {
    }

    public String getAnkenId() {
        return ankenId;
    }

    public void setAnkenId(String ankenId) {
        this.ankenId = ankenId;
    }

    public long getAnkenRev() {
        return ankenRev;
    }

    public void setAnkenRev(long ankenRev) {
        this.ankenRev = ankenRev;
    }

    public int getRirekiId() {
        return rirekiId;
    }

    public void setRirekiId(int rirekiId) {
        this.rirekiId = rirekiId;
    }

    public String getOrderNo() {
        return orderNo;
    }

    public void setOrderNo(String orderNo) {
        this.orderNo = orderNo;
    }

    public String getIspDivisionNm() {
        return ispDivisionNm;
    }

    public void setIspDivisionNm(String ispDivisionNm) {
        this.ispDivisionNm = ispDivisionNm;
    }

    public String getAnkenName() {
        return ankenName;
    }

    public void setAnkenName(String ankenName) {
        this.ankenName = ankenName;
    }

    public String getSaisyuSp() {
        return saisyuSp;
    }

    public void setSaisyuSp(String saisyuSp) {
        this.saisyuSp = saisyuSp;
    }

    public String getSaisyuNet() {
        return saisyuNet;
    }

    public void setSaisyuNet(String saisyuNet) {
        this.saisyuNet = saisyuNet;
    }

    public String getUriageSp() {
        return uriageSp;
    }

    public void setUriageSp(String uriageSp) {
        this.uriageSp = uriageSp;
    }

    public String getUriageNet() {
        return uriageNet;
    }

    public void setUriageNet(String uriageNet) {
        this.uriageNet = uriageNet;
    }

    public String getUriageTov() {
        return uriageTov;
    }

    public void setUriageTov(String uriageTov) {
        this.uriageTov = uriageTov;
    }

    public String getArari() {
        return arari;
    }

    public void setArari(String arari) {
        this.arari = arari;
    }

    public String getMrate() {
        return mrate;
    }

    public void setMrate(String mrate) {
        this.mrate = mrate;
    }

    public String getShirajiFlg() {
        return shirajiFlg;
    }

    public void setShirajiFlg(String shirajiFlg) {
        this.shirajiFlg = shirajiFlg;
    }

    public boolean isShirajiFlg() {
        return (shirajiFlg.equals("1"));
    }
}
