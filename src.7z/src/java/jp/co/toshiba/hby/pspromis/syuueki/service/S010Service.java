package jp.co.toshiba.hby.pspromis.syuueki.service;

//import java.util.HashMap;
//import java.util.LinkedHashMap;
//import java.util.List;
//import java.util.Map;
import java.math.BigDecimal;
import java.util.*;
import javax.ejb.Stateless;
import javax.inject.Inject;
import javax.interceptor.Interceptors;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import jp.co.toshiba.hby.pspromis.syuueki.bean.S010Bean;
import jp.co.toshiba.hby.pspromis.syuueki.entity.OperationLog;
import jp.co.toshiba.hby.pspromis.syuueki.entity.SyuGeBukkenInfoTbl;
import jp.co.toshiba.hby.pspromis.syuueki.entity.SyuKiKanbaijTbl;
import jp.co.toshiba.hby.pspromis.syuueki.entity.SyuKiSpCurTbl;
import jp.co.toshiba.hby.pspromis.syuueki.facade.S010Facade;
import jp.co.toshiba.hby.pspromis.syuueki.facade.SyuGeBukenInfoTblFacade;
import jp.co.toshiba.hby.pspromis.syuueki.interceptor.TranceInterceptor;
import jp.co.toshiba.hby.pspromis.syuueki.util.LoginUserInfo;
import jp.co.toshiba.hby.pspromis.syuueki.util.Utils;
//import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
/**
 * PS-Promis収益管理システム
 * 完売実績入力 Service
 * @author masaki
 */
@Stateless
@Interceptors({TranceInterceptor.class})
public class S010Service {

    /**
     * ロガー
     */
    public static final Logger logger = LoggerFactory.getLogger(S010Service.class);

    @PersistenceContext(unitName = jp.co.toshiba.hby.pspromis.syuueki.util.ConstantString.syuuekiDataSourceName)
    private EntityManager em;

    /**
     * Injection loginUserInfo
     * (ユーザー情報(ユーザーid,名称,所属部課名)を格納したオブジェクト)
     */
    @Inject
    private LoginUserInfo loginUserInfo;
    /**
     * パラメータ格納クラスをinjection(CDI)<br>
     * InjectアノテーションよりAPサーバー(Glassfish)側で自動的にインスタンス作成(new)される。<br>
     */
    @Inject
    private S010Bean s010Bean;
    
    @Inject
    private S010Facade s010Facade;

    @Inject
    private SyuGeBukenInfoTblFacade geBukenInfoTblFacade;
        
    @Inject
    private StoredProceduresService storedProceduresService;

    @Inject
    private OperationLogService operationLogService;

    /**
     * 初期表示 ビジネスロジック
     * @throws Exception 
     */
    public void indexExecute() throws Exception {
        SyuKiKanbaijTbl kanbaiJEntity;
        
        // 検索条件をセット
        Map<String, Object> condition = new HashMap<>();
        condition.put("ankenId", s010Bean.getAnkenId());
        condition.put("rirekiId", s010Bean.getRirekiId());
            
        // 完売月(収益物件情報より）取得
        SyuGeBukkenInfoTbl ankenEntity = geBukenInfoTblFacade.findPk(condition);
        s010Bean.setSyuGeBukkenInfoTbl(ankenEntity);

        // 発番NET取得
        condition.put("currencyCode", "HAT");
        kanbaiJEntity = s010Facade.getSyuKiKanbaij(condition);
        if (kanbaiJEntity != null && kanbaiJEntity.getAmount() != null) {
            s010Bean.setHatNet(kanbaiJEntity.getAmount().toString());
        }

        // 製番損益NET取得
        condition.put("currencyCode", "SBN");
        kanbaiJEntity = s010Facade.getSyuKiKanbaij(condition);
        if (kanbaiJEntity != null && kanbaiJEntity.getAmount() != null) {
            s010Bean.setSbnNet(kanbaiJEntity.getAmount().toString());
        }

        // 為替洗替影響取得
        condition.put("currencyCode", "KWE");
        kanbaiJEntity = s010Facade.getSyuKiKanbaij(condition);
        if (kanbaiJEntity != null && kanbaiJEntity.getAmount() != null) {
            s010Bean.setKawaseEikyo(kanbaiJEntity.getAmount().toString());
        }

        // 通貨タイトル情報取得
        List<SyuKiSpCurTbl> list = s010Facade.getSyuKiSpCur(condition);

        // 通貨と今回売上高のセット
        List<Map<String, Object>> dispList = new ArrayList();
        for(SyuKiSpCurTbl syuKiSpCurTbl : list){
            condition.put("currencyCode", syuKiSpCurTbl.getCurrencyCode());
            
            Map<String, Object> map = new LinkedHashMap();
            map.put("currencyCode", syuKiSpCurTbl.getCurrencyCode());
            kanbaiJEntity = s010Facade.getSyuKiKanbaij(condition);
            if (kanbaiJEntity != null && kanbaiJEntity.getAmount() != null) {
                map.put("amount", kanbaiJEntity.getAmount().toString());
            }

            dispList.add(map);
            s010Bean.setAmountList(dispList);
        }
    }
    
    /**
     * 登録処理 ビジネスロジック
     * @return
     * @throws Exception 
     */
    public boolean save() throws Exception {

        // 更新条件をセット
        Map<String, Object> condition = new HashMap<>();
        condition.put("ankenId", s010Bean.getAnkenId());
        condition.put("rirekiId", s010Bean.getRirekiId());
        condition.put("userId", this.loginUserInfo.getUserId());
        condition.put("uriageEndFin", s010Bean.getUriageEndFin().replace("/", ""));
        
        // 発番NET更新
        condition.put("currencyCode", "HAT");
        condition.put("amount", Utils.changeBigDecimal(s010Bean.getHatNet()));
        updateKanbaiJ(condition);

        // 製番損益NET更新
        condition.put("currencyCode", "SBN");
        condition.put("amount", Utils.changeBigDecimal(s010Bean.getSbnNet()));
        updateKanbaiJ(condition);

        // 為替洗替影響更新
        condition.put("currencyCode", "KWE");
        condition.put("amount", Utils.changeBigDecimal(s010Bean.getKawaseEikyo()));
        updateKanbaiJ(condition);

        // 今回売上高更新
        if (s010Bean.getKeyCode() != null) {
            for (int i = 0; i < s010Bean.getKeyCode().length; i++) {
                condition.put("currencyCode", s010Bean.getKeyCode()[i]);
                condition.put("amount", Utils.changeBigDecimal(s010Bean.getKeyValue()[i]));
                updateKanbaiJ(condition);
            }
        }

        // 操作ログ登録
        registOperationLog();
        
        // 再計算処理
        calc();

        return true;
    }

    /**
     * 更新処理(完売実績)
     */
    private void updateKanbaiJ(Map<String, Object> data) {
        BigDecimal amount = (BigDecimal) data.get("amount");
        if (amount == null) {
            // 金額が無い場合
            SyuKiKanbaijTbl kanbaiJEntity = s010Facade.getSyuKiKanbaij(data);
            if (kanbaiJEntity != null) {
                em.remove(kanbaiJEntity);
            }

        } else {
            // 対象データの更新
            int count = s010Facade.updateSyuKiKanbaiJ(data);
            if (count == 0) {
                s010Facade.insertSyuKiKanbaiJ(data);
            }
        }
    }

     /**
     * 再計算処理実行
     */
    public void calc() throws Exception {
        geBukenInfoTblFacade.setSaikeisanFlg(s010Bean.getAnkenId(), Integer.parseInt(s010Bean.getRirekiId()), "1");
        
        // 再計算処理を実行
        callAnkenRecal();

        // 再計算FLGを解除
        geBukenInfoTblFacade.setSaikeisanFlg(s010Bean.getAnkenId(), Integer.parseInt(s010Bean.getRirekiId()), "0");
    }

     /**
     * 再計算処理をcallする(Step4見直し)。
     */
    private void callAnkenRecal() throws Exception {
        storedProceduresService.callAnkenRecalAuto(s010Bean.getAnkenId(), s010Bean.getRirekiId(), "0");
//        AnkenRecalDto dto = new AnkenRecalDto();
//        dto.setAnkenId(s010Bean.getAnkenId());
//        dto.setRirekiId(new Integer(s010Bean.getRirekiId()));
//        
//        storedProceduresService.callAnkenRecal(dto);
//        
//        if (!"0".equals(dto.getStatus())) {
//            throw new Exception("再計算処理[SYU_ANKEN_RECAL_MAIN]でエラーが発生しました。物件Key=" + s010Bean.getAnkenId());
//        }
    }
    
    /**
     * 操作ログの登録
     * @param operationCode
     * @throws Exception
     */
    public void registOperationLog() throws Exception{
        OperationLog operationLog = operationLogService.getOperationLog();

        operationLog.setOperationCode("SAVE_KANBAIJ");
        operationLog.setObjectId(20);
        operationLog.setObjectType("KIKAN_S");
        operationLog.setRemarks(s010Bean.getAnkenId());

        operationLogService.insertOperationLogSearch(operationLog);
    }
    
}
