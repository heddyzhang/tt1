/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package jp.co.toshiba.hby.pspromis.syuueki.servlet;

import java.util.HashMap;
import java.util.Map;
import javax.inject.Inject;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import jp.co.toshiba.hby.pspromis.syuueki.bean.BookMarkBean;
import jp.co.toshiba.hby.pspromis.syuueki.service.BookMarkService;
import jp.co.toshiba.hby.pspromis.syuueki.util.ParameterBinder;

/**
 *
 * @author ibayashi
 */
@WebServlet(name = "BookMark", urlPatterns = {"/servlet/BookMark", "/servlet/BookMark/*"})
public class BookMarkServlet extends AbstractServlet {

    /**
     * パラメータ格納クラスをinjection(CDI)<br>
     */
    @Inject
    private BookMarkBean bookMarkBean;

    /**
     * 使用serviceクラスをinjection(CDI)<br>
     */
    @Inject
    private BookMarkService bookMarkService;
    
    /**
     * 初期表示(BookMark取得)
     * @param req
     * @param resp
     * @return
     * @throws Exception 
     */
    public String indexAction(HttpServletRequest req, HttpServletResponse resp)
    throws Exception {
        logger.info("BookMarkServlet#indexAction");
        
        // リクエストパラメータをbookMarkBeanの同名フィールドに一括コピー
        ParameterBinder.Bind(bookMarkBean, req);
        
        // 更新処理を実行
        bookMarkService.indexExecute();
        
        // 結果セットをjson出力
        Map<String, Object> jsonMap = new HashMap<>();
        jsonMap.put("bookMarkFlg", bookMarkBean.getBookMarkFlg());
        resopnseDecodeJson(resp, jsonMap);
        
        // ここでは戻すjspが存在しないため、nullを返す。
        return null;
    }

    /**
     * BookMark更新
     * @param req
     * @param resp
     * @return
     * @throws Exception 
     */
    public String updateAction(HttpServletRequest req, HttpServletResponse resp)
    throws Exception {
        logger.info("BookMarkServlet#updateAction");
        
        // リクエストパラメータをbookMarkBeanの同名フィールドに一括コピー
        ParameterBinder.Bind(bookMarkBean, req);

        // 更新処理を実行
        bookMarkService.updateExecute();
        
        // 結果セットをjson出力
        Map<String, Object> jsonMap = new HashMap<>();
        jsonMap.put("bookMarkFlg", bookMarkBean.getBookMarkFlg());
        resopnseDecodeJson(resp, jsonMap);
        
        // ここでは戻すjspが存在しないため、nullを返す。
        return null;
        
        // リクエストパラメータをk001Beanの同名フィールドに一括コピー
        //ParameterBinder.Bind(k001Bean, req);

        //k001Service.indexExecute();

        //return INDEX_JSP;
    }
}
