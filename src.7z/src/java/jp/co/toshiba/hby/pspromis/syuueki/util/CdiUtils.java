package jp.co.toshiba.hby.pspromis.syuueki.util;

import java.util.Set;
import javax.enterprise.inject.Default;
import javax.enterprise.inject.spi.Bean;
import javax.enterprise.inject.spi.BeanManager;
import javax.enterprise.util.AnnotationLiteral;
import javax.naming.InitialContext;
import javax.naming.NamingException;

/**
 * CDI管理ユーティリティ
 * @author (NPC)S.Ibayashi
 */
public class CdiUtils {
    /**
     * CDI管理しているオブジェクトを取得
     * @param <T>
     * @param cls
     * @return 
     * @throws javax.naming.NamingException 
     */
    public static <T extends Object> T getBean(Class<T> cls) throws NamingException {
        InitialContext ic = new InitialContext();   

        BeanManager manager = (BeanManager)ic.lookup("java:comp/BeanManager");
        Set<Bean<?>> beans = manager.getBeans(cls, new AnnotationLiteral<Default>(){});  
        Bean<?> bean = manager.resolve(beans);   
        T obj = (T)manager.getReference(bean, cls, manager.createCreationalContext(bean));  
        return obj;
    }
}
