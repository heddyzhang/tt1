package jp.co.toshiba.hby.pspromis.syuueki.bean;

import java.util.Date;
import java.util.List;
import java.util.Map;
import javax.enterprise.context.RequestScoped;
import javax.inject.Named;
import jp.co.toshiba.hby.pspromis.syuueki.entity.SyuMikomiUpInfoTbl;
import jp.co.toshiba.hby.pspromis.syuueki.entity.SyuPatternMst;
import jp.co.toshiba.hby.pspromis.syuueki.entity.SyuMikomiRateMst;
import jp.co.toshiba.hby.pspromis.syuueki.entity.SyuCurMst;
/**
 *
 * @author sano
 */
@Named(value = "s009Bean")
@RequestScoped
public class S009Bean extends AbstractBean {

    /**
     * 一覧検索フラグ
     */
    private String listFlg = "0";

    /**
     * 検索条件：事業部
     */
    //@NotNull
    private String[] divisionCode;

    /**
     * buコード
     */
    private String[] buId;

    /**
     * サブBUコード
     */
    private String[] subBuId;

    /**
     * メニュー選択
     */
    private String selMenu;

    /**
     * 検索条件・プラント種別
     */
    private String plantKbn;

    /**
     * 検索条件・パターン区分
     */
    private String patternKbn;
    
    /**
     * 検索条件・パターン名称
     */
    private String patternName;
    
    /**
     * 検索条件・複写元パターン名称
     */
    private String copyPatternName;
    
    /**
     * 検索条件・見込レート種類
     */
    private String mikomiRateType;
    
    /**
     * 検索条件・見込レートの売上基準(2016A追加)
     */
    private String searchRateSalesClass;
    
    /**
     * 検索条件・見込レートマスタ検索対象の事業部
     */
    private String mikomiRateDivisionCode;
    
    /**
     * 一覧表示データ総件数
     */
    private Long count;

    /**
     * 現在表示するページ番号
     */
    private Integer page;

    /**
     * 一覧取得結果
     */
    private List<SyuPatternMst> list;

    /**
     * 一覧取得結果（見込レートマスタ）
     */
    private List<SyuMikomiRateMst> listRateType;

    /**
     * 一覧件数（見込レートマスタ）
     */
    private Long listRateTypeCnt;
    
    /**
     * 通貨リスト（見込レートマスタ）
     */
    private List<SyuCurMst> listCurMst; 
   
    /**
     * アップロード指定画面の各一覧指定内容
     */
    private Map<String, SyuMikomiUpInfoTbl> uploadInfo;

    /**
     * 当年を取得
     */
    private String nowYear;

    /**
     * 当月を取得
     */
    private String nowMonth;
    
    /**
     * アップロード対象の事業部コード
     */
    private String uploadDivisionCode;

    /**
     * 見込レートマスタ　レート適用月Fromを取得
     */
    private String rateMonthFrom;
    
    /**
     * 見込レートマスタ　レート適用月Toを取得
     */
    private String rateMonthTo;    
    
    /**
     * 見込レートマスタ　削除チェックボックス
     */
    private int[] rateIndex;

    /**
     * 見込レートマスタ　種類（PK）
     */
    private String[] rateType;

    /**
     * 見込レートマスタ　通貨コード（PK）
     */
    private String[] rateCurrencyCd;

    /**
     * 編集FLG
     */
    private String editFlg = "0";
    
    /**
     * 現在表示するデータ件数
     */
    private Long dispCount;
    
    /**
     * Creates a new instance of S001Bean
     */
    public S009Bean() {
    }

    public String getListFlg() {
        return listFlg;
    }

    public void setListFlg(String listFlg) {
        this.listFlg = listFlg;
    }

    public Long getCount() {
        return count;
    }

    public void setCount(Long count) {
        this.count = count;
    }

    public Integer getPage() {
        return page;
    }

    public void setPage(Integer page) {
        this.page = page;
    }
/*
    public List<SyuBukenInfoTblFacade> getList() {
        return list;
    }

    public void setList(List<SyuBukenInfoTblFacade> list) {
        this.list = list;
    }
*/
    public String[] getDivisionCode() {
        return divisionCode;
    }

    public void setDivisionCode(String[] divisionCode) {
        this.divisionCode = divisionCode;
    }
    public List<SyuPatternMst> getList() {
        return list;
    }

    public void setList(List<SyuPatternMst> list) {
        this.list = list;
    }

    public String getSelMenu() {
        return selMenu;
    }

    public void setSelMenu(String selMenu) {
        this.selMenu = selMenu;
    }

    public String getPlantKbn() {
        return plantKbn;
    }

    public void setPlantKbn(String plantKbn) {
        this.plantKbn = plantKbn;
    }

    public String getPatternKbn() {
        return patternKbn;
    }

    public void setPatternKbn(String patternKbn) {
        this.patternKbn = patternKbn;
    }
    
    public String getPatternName() {
        return patternName;
    }

    public void setPatternName(String patternName) {
        this.patternName = patternName;
    }
    
    public String getCopyPatternName() {
        return copyPatternName;
    }

    public void setCopyPatternName(String copyPatternName) {
        this.copyPatternName = copyPatternName;
    }

    public String getMikomiRateType() {
        return mikomiRateType;
    }

    public void setMikomiRateType(String mikomiRateType) {
        this.mikomiRateType = mikomiRateType;
    }

    public String[] getSubBuId() {
        return subBuId;
    }

    public void setSubBuId(String[] subBuId) {
        this.subBuId = subBuId;
    }

    public String[] getBuId() {
        return buId;
    }

    public void setBuId(String[] buId) {
        this.buId = buId;
    }

    public Map<String, SyuMikomiUpInfoTbl> getUploadInfo() {
        return uploadInfo;
    }

    public void setUploadInfo(Map<String, SyuMikomiUpInfoTbl> uploadInfo) {
        this.uploadInfo = uploadInfo;
    }

    public String getNowYear() {
        return nowYear;
    }

    public void setNowYear(String nowYear) {
        this.nowYear = nowYear;
    }

    public String getNowMonth() {
        return nowMonth;
    }

    public void setNowMonth(String nowMonth) {
        this.nowMonth = nowMonth;
    }

    public String getUploadDivisionCode() {
        return uploadDivisionCode;
    }

    public void setUploadDivisionCode(String uploadDivisionCode) {
        this.uploadDivisionCode = uploadDivisionCode;
    }

    public List<SyuMikomiRateMst> getListRateType() {
        return listRateType;
    }

    public void setListRateType(List<SyuMikomiRateMst> listRateType) {
        this.listRateType = listRateType;
    }

    public int[] getRateIndex() {
        return rateIndex;
    }

    public void setRateIndex(int[] rateIndex) {
        this.rateIndex = rateIndex;
    }

    public String[] getRateType() {
        return rateType;
    }

    public void setRateType(String[] rateType) {
        this.rateType = rateType;
    }

    public String[] getRateCurrencyCd() {
        return rateCurrencyCd;
    }

    public void setRateCurrencyCd(String[] rateCurrencyCd) {
        this.rateCurrencyCd = rateCurrencyCd;
    }

    public String getEditFlg() {
        return editFlg;
    }

    public void setEditFlg(String editFlg) {
        this.editFlg = editFlg;
    }

    public Long getDispCount() {
        return dispCount;
    }

    public void setDispCount(Long dispCount) {
        this.dispCount = dispCount;
    }

    public List<SyuCurMst> getListCurMst() {
        return listCurMst;
    }

    public void setListCurMst(List<SyuCurMst> listCurMst) {
        this.listCurMst = listCurMst;
    }

    public String getMikomiRateDivisionCode() {
        return mikomiRateDivisionCode;
    }

    public void setMikomiRateDivisionCode(String mikomiRateDivisionCode) {
        this.mikomiRateDivisionCode = mikomiRateDivisionCode;
    }

    public Long getListRateTypeCnt() {
        return listRateTypeCnt;
    }

    public void setListRateTypeCnt(Long listRateTypeCnt) {
        this.listRateTypeCnt = listRateTypeCnt;
    }

    public String getRateMonthFrom() {
        return rateMonthFrom;
    }

    public void setRateMonthFrom(String rateMonthFrom) {
        this.rateMonthFrom = rateMonthFrom;
    }

    public String getRateMonthTo() {
        return rateMonthTo;
    }

    public void setRateMonthTo(String rateMonthTo) {
        this.rateMonthTo = rateMonthTo;
    }

    public String getSearchRateSalesClass() {
        return searchRateSalesClass;
    }

    public void setSearchRateSalesClass(String searchRateSalesClass) {
        this.searchRateSalesClass = searchRateSalesClass;
    }

}
