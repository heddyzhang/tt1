/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package jp.co.toshiba.hby.pspromis.syuueki.facade;

import java.lang.reflect.InvocationTargetException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.interceptor.Interceptors;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import jp.co.toshiba.hby.pspromis.syuueki.entity.MSectionView;
import jp.co.toshiba.hby.pspromis.syuueki.interceptor.TranceInterceptor;
import org.apache.commons.beanutils.PropertyUtils;

/**
 *
 * @author ibayashi
 */
@Stateless
@Interceptors({TranceInterceptor.class})
public class MSectionFacade extends AbstractFacade<MSectionView> {
    @PersistenceContext(unitName = jp.co.toshiba.hby.pspromis.syuueki.util.ConstantString.syuuekiDataSourceName)
    private EntityManager em;

    @Override
    protected EntityManager getEntityManager() {
        return em;
    }

    public MSectionFacade() {
        super(MSectionView.class);
    }

    /**
     * 事業部・部・課のツリー構成リストを作成して取得
     * @param divitionCd 事業部コード
     * @return 
     * @throws java.lang.IllegalAccessException 
     * @throws java.lang.reflect.InvocationTargetException 
     * @throws java.lang.NoSuchMethodException 
     */
    public List<Map<String, Object>> findAllTreeList(String[] divitionCd) throws IllegalAccessException, InvocationTargetException, NoSuchMethodException {
        Map<String, Object> condition = new HashMap<>();
        condition.put("divitionCd", Arrays.asList(divitionCd));
        
        // 事業部の一覧を取得
        List<MSectionView> list
                = sqlExecutor.getResultList(em, MSectionView.class, "/sql/msection/selectJigyoubuList.sql", condition);

        List<Map<String, Object>> treeList = new ArrayList<>();
        Map<String, Object> entity;

        int jigyobuIndex = 0;
        int buIndex = 0;
        int kaIndex = 0;
        
        for (MSectionView sect : list) {
            jigyobuIndex++;

            entity = PropertyUtils.describe(sect);

            entity.put("deptLevel", "1");
            entity.put("treeId", jigyobuIndex);
            entity.put("parentId", null);
            treeList.add(entity);

            // 事業部配下のツリー情報取得
            List<MSectionView> sectTreeList = findTreeList(sect.getDeptCd());
            for (MSectionView mst : sectTreeList) {
                
                if ("2".equals(mst.getDeptLevel())) {
                    // 部の場合
                    buIndex = buIndex + 1;
                    kaIndex = 0;

                    entity = PropertyUtils.describe(mst);

                    entity.put("treeId", jigyobuIndex + "-" + buIndex);
                    entity.put("parentId", jigyobuIndex);

                } else if ("3".equals(mst.getDeptLevel())) {
                    // 課の場合
                    kaIndex++;
                    entity = PropertyUtils.describe(mst);
                    
                    entity.put("treeId", jigyobuIndex + "-" + buIndex + "-" + kaIndex);
                    entity.put("parentId", jigyobuIndex + "-" + buIndex);

                } else{
                    continue;
                }

                treeList.add(entity);
            }
            
        }
        
        return treeList;
    }

    /**
     * 指定した部課の下層構成を取得
     * @param deptCd
     * @return 
     */
    @TransactionAttribute(TransactionAttributeType.NOT_SUPPORTED)
    public List<MSectionView> findTreeList(String deptCd) {
        Map<String, Object> condition = new HashMap<>();
        condition.put("deptCd", deptCd);
        
        // 部課の一覧を取得
        List<MSectionView> list
                = sqlExecutor.getResultList(em, MSectionView.class, "/sql/msection/selectTreeList.sql", condition);

        return list;
    }

    /**
     * 指定した部課(複数)の一覧を取得
     */
    public List<MSectionView> findPluralBukaList(String[] deptCd) {
        Map<String, Object> condition = new HashMap<>();
        condition.put("deptCd", deptCd);
        
        // 部課の一覧を取得
        List<MSectionView> list
                = sqlExecutor.getResultList(em, MSectionView.class, "/sql/msection/selectPluralSectionList.sql", condition);

        return list;
    }

     /**
     * 事業部・部のツリー構成リストを作成して取得
     * @param divitionCd 事業部コード
     * @return 
     * @throws java.lang.IllegalAccessException 
     * @throws java.lang.reflect.InvocationTargetException 
     * @throws java.lang.NoSuchMethodException 
     */
    public List<Map<String, Object>> findJigyobuTreeList(String[] divitionCd) throws IllegalAccessException, InvocationTargetException, NoSuchMethodException {
        Map<String, Object> condition = new HashMap<>();
        condition.put("divitionCd", Arrays.asList(divitionCd));
        
        // 事業部の一覧を取得
        List<MSectionView> list
                = sqlExecutor.getResultList(em, MSectionView.class, "/sql/msection/selectJigyoubuList.sql", condition);

        List<Map<String, Object>> treeList = new ArrayList<>();
        Map<String, Object> entity;

        int jigyobuIndex = 0;
        int buIndex = 0;
        int kaIndex = 0;
        
        for (MSectionView sect : list) {
            jigyobuIndex++;

            entity = PropertyUtils.describe(sect);

            entity.put("deptLevel", "1");
            entity.put("treeId", jigyobuIndex);
            entity.put("parentId", null);
            treeList.add(entity);

            // 事業部配下のツリー情報取得(部)
            List<MSectionView> sectTreeList = findBuTreeList(sect.getDeptCd());
            for (MSectionView mst : sectTreeList) {
                
                if ("2".equals(mst.getDeptLevel())) {
                    // 部の場合
                    buIndex = buIndex + 1;
                    kaIndex = 0;

                    entity = PropertyUtils.describe(mst);

                    entity.put("treeId", jigyobuIndex + "-" + buIndex);
                    entity.put("parentId", jigyobuIndex);

                } /*else if ("3".equals(mst.getDeptLevel())) {
                    // 課の場合
                    kaIndex++;
                    entity = PropertyUtils.describe(mst);
                    
                    entity.put("treeId", jigyobuIndex + "-" + buIndex + "-" + kaIndex);
                    entity.put("parentId", jigyobuIndex + "-" + buIndex);

                }*/ else{
                    continue;
                }

                treeList.add(entity);
            }
            
        }
        
        return treeList;
    }
    
    /**
     * 指定した事業部の下層構成を取得
     * @param deptCd
     * @return 
     */
    @TransactionAttribute(TransactionAttributeType.NOT_SUPPORTED)
    public List<MSectionView> findBuTreeList(String deptCd) {
        Map<String, Object> condition = new HashMap<>();
        condition.put("deptCd", deptCd);
        
        // 部課の一覧を取得
        List<MSectionView> list
                = sqlExecutor.getResultList(em, MSectionView.class, "/sql/msection/selectBuTreeList.sql", condition);

        return list;
    }

    /**
     * 課を取得
     * @param deptCd
     * @return 
     */
    @TransactionAttribute(TransactionAttributeType.NOT_SUPPORTED)
    public List<MSectionView> findDeptKa(String deptCd) {
        Map<String, Object> condition = new HashMap<>();
        condition.put("deptCd", deptCd);
        
        // 課の一覧を取得
        List<MSectionView> list
                = sqlExecutor.getResultList(em, MSectionView.class, "/sql/msection/selectKaList.sql", condition);

        return list;
    }
    
    /**
     * 指定した事業部・職種の部課情報リストを取得
     * @param syokusyuCd
     * @param divisionCode
     * @return 
     */
    @TransactionAttribute(TransactionAttributeType.NOT_SUPPORTED)
    public List<MSectionView> findDivisionSyokusyuList(String syokusyuCd, String divisionCode) {
        Map<String, Object> condition = new HashMap<>();
        condition.put("syokusyuCd", syokusyuCd);
        condition.put("divisionCode", divisionCode);
        
        // 部課の一覧を取得
        List<MSectionView> list
                = sqlExecutor.getResultList(em, MSectionView.class, "/sql/msection/selectSyokusyuSectionList.sql", condition);

        return list;
    }
    
    
}
