package jp.co.toshiba.hby.pspromis.syuueki.bean;

import java.util.List;
import javax.enterprise.context.RequestScoped;
import javax.inject.Named;
import jp.co.toshiba.hby.pspromis.syuueki.entity.IspJissekiData;
import lombok.Getter;
import lombok.Setter;

/**
 *
 * @author watabe
 */
@Named(value = "s027Bean")
@RequestScoped
@Getter @Setter
public class S027Bean extends AbstractBean{

    private List<IspJissekiData> ispJissekiDataList;
    
    //注番
    private String orderNo;
    //ISP事業部(他事業部コード)
    private String ispDivisionNm;
    //案件名称
    private String ankenName;
    //ISP
    private String isp;
    //NET
    private String net;
    //年月(YYYYMM)
    private String syuekiYm;
    //引当用案件ID
    private String[] hikiAnkenId;
    //金額指定区分(実績全額(1)、金額指定(2))
    private String shiteiKbn;
    //リスト配列番号用
    private String flag;
    //勘定月
    private String kanjyoYm;
    //事業部コード
    private String divisionCode;
    
}
