/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package jp.co.toshiba.hby.pspromis.syuueki.dto;

/**
 * PS-Promis収益管理システム
 * RDBMS 月次確定(or確定解除)・履歴データ作成処理パッケージCall用パラメータdto
 * @author (NPS)S.Ibayashi
 */
public class PoRirekiMakeDto {
   
    /**
     * 事業部コード
     */
    private String divisionCode;
    
    /**
     * WFグループコード
     */
    private String groupCode;
    
    /**
     * 進行基準FLG(0:一般 1:進行基準)
     */
    private String salesClass;
    
    /**
     * 確定月
     */
    private String kanjyoYm;
    
    /**
     * 履歴id
     */
    private String rirekiId;
    
    /**
     * 処理FLG(0.確定（OR 承認）、9.解除)
     */
    private String syoriFlg;
    
    /**
     * 処理結果FLG(0:正常 9:異常)
     */
    private String errFlg;

    public String getDivisionCode() {
        return divisionCode;
    }

    public void setDivisionCode(String divisionCode) {
        this.divisionCode = divisionCode;
    }

    public String getGroupCode() {
        return groupCode;
    }

    public void setGroupCode(String groupCode) {
        this.groupCode = groupCode;
    }

    public String getSalesClass() {
        return salesClass;
    }

    public void setSalesClass(String salesClass) {
        this.salesClass = salesClass;
    }

    public String getKanjyoYm() {
        return kanjyoYm;
    }

    public void setKanjyoYm(String kanjyoYm) {
        this.kanjyoYm = kanjyoYm;
    }

    public String getRirekiId() {
        return rirekiId;
    }

    public void setRirekiId(String rirekiId) {
        this.rirekiId = rirekiId;
    }

    public String getSyoriFlg() {
        return syoriFlg;
    }

    public void setSyoriFlg(String syoriFlg) {
        this.syoriFlg = syoriFlg;
    }

    public String getErrFlg() {
        return errFlg;
    }

    public void setErrFlg(String errFlg) {
        this.errFlg = errFlg;
    }

}
