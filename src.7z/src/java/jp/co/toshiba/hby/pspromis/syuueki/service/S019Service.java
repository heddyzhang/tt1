package jp.co.toshiba.hby.pspromis.syuueki.service;

import java.util.List;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import javax.ejb.Stateless;
import javax.inject.Inject;
import javax.interceptor.Interceptors;
import jp.co.toshiba.hby.pspromis.common.exception.PspRunTimeExceotion;
import jp.co.toshiba.hby.pspromis.syuueki.bean.S019Bean;
import jp.co.toshiba.hby.pspromis.syuueki.enums.Label;
import jp.co.toshiba.hby.pspromis.syuueki.entity.SyuGeNetItemTblView;
import jp.co.toshiba.hby.pspromis.syuueki.facade.SyuGeNetItemTblViewFacade;
import jp.co.toshiba.hby.pspromis.syuueki.entity.OperationLog;
import jp.co.toshiba.hby.pspromis.syuueki.entity.SyuGeNetItemTbl;
import jp.co.toshiba.hby.pspromis.syuueki.entity.SyuKiNetItemTukiTbl;
import jp.co.toshiba.hby.pspromis.syuueki.entity.SyuGeBukkenInfoTbl;
import jp.co.toshiba.hby.pspromis.syuueki.facade.KanjyoMstFacade;
import jp.co.toshiba.hby.pspromis.syuueki.facade.SyuGeBukenInfoTblFacade;
import jp.co.toshiba.hby.pspromis.syuueki.facade.SyuKiNetItemTukiTblFacade;
import jp.co.toshiba.hby.pspromis.syuueki.facade.SyuSaNetItemTblFacade;
import jp.co.toshiba.hby.pspromis.syuueki.interceptor.TranceInterceptor;
import jp.co.toshiba.hby.pspromis.syuueki.util.EntityUtils;
import jp.co.toshiba.hby.pspromis.syuueki.util.LoginUserInfo;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
/**
 * ES-Promis収益管理システム
 * 発番引当 Service
 * @author 
 */
@Stateless
@Interceptors({TranceInterceptor.class})
public class S019Service {

    public static final Logger log = LoggerFactory.getLogger(S019Service.class);

    @Inject
    private S019Bean s019Bean;

    @Inject
    private LoginUserInfo loginUserInfo;

    @Inject
    private SyuGeNetItemTblViewFacade syuGeNetItemTblViewFacade;
    
    @Inject
    private SyuKiNetItemTukiTblFacade syuKiNetItemTukiTblFacade;
    
    @Inject
    private SyuSaNetItemTblFacade syuSaNetItemTblFacade;
    
    @Inject
    private OperationLogService operationLogService;
    
    @Inject
    private StoredProceduresService storedProceduresService;
    
    @Inject
    private KanjyoMstFacade kanjyoMstFacade;
    
    @Inject
    private SyuGeBukenInfoTblFacade syuGeBukenInfoTblFacade;

    /**
     * 初期表示時機能
     * @throws Exception
     */
    public void indexExecute() throws Exception {
        s019Bean.setInputseiban("");
        s019Bean.setInputorderItem(s019Bean.getOrderItem());
        s019Bean.setInputhinmei("");
        s019Bean.setSort1Kbn("0");
        s019Bean.setSort1("orderItem");
        s019Bean.setInitFlg("1");

        SyuGeBukkenInfoTbl ankenEntity = getAnkenEntity();
        s019Bean.setDivisionCode(StringUtils.defaultString(ankenEntity.getDivisionCode()));

        findTargetOrderItem();
    }

    /**
     * 共通の条件を作成して取得
     */
    private Map<String, Object> getBaseCondition() {
        Map<String, Object> condition = new HashMap<>();
        condition.put("ankenId", s019Bean.getAnkenId());
        condition.put("rirekiId", s019Bean.getRirekiId());
        return condition;
    }
    
    /**
     * 案件情報を取得
     */
    private SyuGeBukkenInfoTbl getAnkenEntity() {
        Map<String, Object> condition = getBaseCondition();
        SyuGeBukkenInfoTbl geEntity = syuGeBukenInfoTblFacade.findPk(condition);
        if (geEntity == null) {
            String errorMessage = Label.errorNoAnkenDate.getLabel();
            log.error(errorMessage + " ankenId=" + s019Bean.getAnkenId() + " rirekiId=" + s019Bean.getRirekiId());
            throw new PspRunTimeExceotion(errorMessage);
        }
        return geEntity;
    }

    /**
     * 引当対象の項番一覧の検索
     */
    private void findTargetOrderItem() {
        // 検索条件
        Map<String, Object> condition = getBaseCondition();
        List<String> orderItemList = new ArrayList<>();
        orderItemList.add(s019Bean.getOrderItem());
        condition.put("orderItemList", orderItemList);

        // 対象の見込項番を取得
        SyuGeNetItemTblView entity = syuGeNetItemTblViewFacade.getSubTargetItem(condition);

        s019Bean.setTargetItemCategory1(entity.getKiCategoryName1());
        s019Bean.setTargetItemCategory2(entity.getKiCategoryName2());
        s019Bean.setTargetItemOrderNo(entity.getOrderNo());
        s019Bean.setTargetItemSeiban(entity.getSeiban());
        s019Bean.setTargetItemOrderItem(entity.getOrderItem());
        s019Bean.setTargetItemHinmei(entity.getHinmei());
    }

    /**
     * 初期表示時機能
     * @throws Exception
     */
    public void searchExecute() throws Exception {
        s019Bean.setInitFlg("0");

        findHatsubanOrderItem();
    }

    /**
     * 発番済の項番一覧の検索
     */
    private void findHatsubanOrderItem() {
        // 検索条件
        Map<String, Object> condition = getBaseCondition();
        condition.put("inputseiban", s019Bean.getInputseiban());
        condition.put("inputorderItem", s019Bean.getInputorderItem());
        condition.put("inputhinmei", s019Bean.getInputhinmei());
        condition.put("sort1", s019Bean.getSort1());
        condition.put("sort1Kbn", s019Bean.getSort1Kbn());

        // 発番済項番を取得
        List<SyuGeNetItemTblView> entity = syuGeNetItemTblViewFacade.getHatsubanItemList(condition);
        s019Bean.setDispTargetItemList(entity);

    }

    /**
     * 保存処理
     * @throws java.lang.Exception
     */
    public void saveExecute() throws Exception {
        // 引き当て設定(見込項番の各見込月データ)
        saveHikiateTuki();

        // 引き当て設定(見込項番の最終見込データ)
        saveHikiateSaisyu();

        // 見込項番データ削除
        deleteMikomi();

        // 操作ログの登録
        registOperationLog();
        
        // 再計算（集計）パッケージ呼出
        storedProceduresService.callAnkenRecalAuto(s019Bean.getAnkenId(), s019Bean.getRirekiId(), "1");
    }

    /**
     * 引き当て設定(見込項番の各見込月データ)
     * @throws Exception
     */
    private void saveHikiateTuki() {
        //int intCnt;
        String strSyukeiYm = "";
        // 見込項番と選択した発番済項番を取得
        Map<String, Object> condition = getBaseCondition();
        condition.put("dataKbn", "M");
        condition.put("mikomiorderNo", s019Bean.getTargetItemOrderNo());
        condition.put("hatsubanorderNo", s019Bean.getSelectedOrderNo());
        condition.put("mikomiorderItem", s019Bean.getOrderItem());
        condition.put("hatsubanorderItem", s019Bean.getSelectorderItem());
        
        String salesClass = syuGeBukenInfoTblFacade.getSalesClass(s019Bean.getAnkenId(), s019Bean.getRirekiId());
        String kanjo = kanjyoMstFacade.getNowKanjoDate(salesClass);
        condition.put("kanjoYm", kanjo);

        // 発番済項番を取得
        List<SyuKiNetItemTukiTbl> dataList = syuKiNetItemTukiTblFacade.getHikiateItemList(condition);

        condition = getBaseCondition();
        condition.put("dataKbn", "M");
        condition.put("orderNo", s019Bean.getSelectedOrderNo());
        condition.put("orderItem", s019Bean.getSelectorderItem());
        EntityUtils.setCreatedInfo(condition, loginUserInfo.getUserId());

        // 各年月の見込/実績情報取得のSELECT句を作成
        for (SyuKiNetItemTukiTbl entity : dataList) {
            // 前データの年月と同じ場合（見込・発番済が双方存在）はスキップする
            if(!strSyukeiYm.equals(entity.getSyuekiYm())){
                // データ設定
                condition.put("syuekiYm", entity.getSyuekiYm());
                condition.put("cyunyuNet", entity.getCyunyuNet());
                condition.put("uriageNet", entity.getUriageNet());
                condition.put("seibanSonekiNet", entity.getSeibanSonekiNet());
                condition.put("fixedMikomiNet", entity.getFixedMikomiNet());
                
                //収益項番TBL（原価）　項番別詳細ー月別 更新
                int intCnt = syuKiNetItemTukiTblFacade.updateNetItemHikiate(condition);
                // 更新できない場合は登録処理
                if( intCnt == 0){
                    syuKiNetItemTukiTblFacade.insertNetItemHikiate(condition);
                }
            }
            // 年月をセット
            strSyukeiYm = entity.getSyuekiYm();
        }
       
    }

    /**
     * 引き当て設定(見込項番の最終見込データ)
     * @throws Exception
     */
    private void saveHikiateSaisyu() {
        // 検索条件
        Map<String, Object> condition = getBaseCondition();
        condition.put("orderItem", s019Bean.getOrderItem());

        // 対象の見込項番を取得
        SyuGeNetItemTbl entity = syuGeNetItemTblViewFacade.getMikomiItem(condition);
        if (entity != null) {
            condition = getBaseCondition();
            condition.put("orderItem", s019Bean.getSelectorderItem());
            
            condition.put("fixedMikomiNet", entity.getFixedMikomiNet());
            condition.put("fixedMikomiCurrecyCode", entity.getFixedMikomiNetCurrecyCode());
            condition.put("fixedMikomiRate", entity.getFixedMikomiRate());
            condition.put("fixedMikomiNetGaika", entity.getFixedMikomiNetGaika());
            // (2017/09/22)見積管理連携で取得した連携情報関連も引き当て対象にする
            condition.put("spurtNo", entity.getSpurtNo());
            condition.put("jobgrSeq", entity.getJobgrSeq());
            condition.put("reqSeq", entity.getReqSeq());
            condition.put("reqRev", entity.getReqRev());
            condition.put("iraiKbn", entity.getIraiKbn());
            condition.put("bundleCode", entity.getBundleCode());
            condition.put("qno", entity.getQno());
            condition.put("koubanSeq", entity.getKoubanSeq());
            condition.put("renkeiKey", entity.getRenkeiKey());

            EntityUtils.setCreatedInfo(condition, loginUserInfo.getUserId());
            
            // 最終見込データ更新
            syuGeNetItemTblViewFacade.updateSaisyuMikomi(condition);
            
            // 見積リンク用key項目の更新
            syuGeNetItemTblViewFacade.updateMitsumoriKey(condition);
        }

    }

    /**
     * 見込項番データ削除
     * @throws Exception
     */
    private void deleteMikomi() {
        Map<String, Object> condition = getBaseCondition();
        condition.put("orderNo", s019Bean.getTargetItemOrderNo());
        condition.put("orderitem", s019Bean.getTargetItemOrderItem());
        
        // 項番情報(SYU_GE_NET_ITEM_TBL)削除
        syuGeNetItemTblViewFacade.deleteKobanSyuGeNetItem(condition);
        
        // 期間損益項番別－月別詳細(SYU_KI_NET_ITEM_TUKI_TBL)削除
        syuKiNetItemTukiTblFacade.deleteKobanSyuKiNetItem(condition);
        
        // 最終見込損益項番別－イベント詳細(SYU_SA_NET_ITEM_TBL)削除
        syuSaNetItemTblFacade.deleteKobanSyuSaNetItem(condition);
    }

    /**
     * 操作ログの登録
     * @throws Exception
     */
    private void registOperationLog() throws Exception{
        OperationLog operationLog = operationLogService.getOperationLog();

//        String objectType = operationLogService.getObjectType(s016Bean.getProcId());
        String objectType = operationLogService.getObjectType("S005");
        
        operationLog.setOperationCode("HAT_HIKIATE");
        operationLog.setObjectId(20);
        operationLog.setObjectType(objectType);
        operationLog.setRemarks(s019Bean.getAnkenId()); // 備考1(引数.物件Key)
        operationLog.setRemarks2(s019Bean.getSelectorderItem()); // 備考2(発行済の項番)
        operationLog.setRemarks3(s019Bean.getOrderItem()); // 備考3(引当前の見込項番)

        operationLogService.insertOperationLogSearch(operationLog);
    }

}
