package jp.co.toshiba.hby.pspromis.syuueki.servlet;

import java.util.HashMap;
import java.util.Map;
import javax.inject.Inject;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpServletRequest;
import jp.co.toshiba.hby.pspromis.syuueki.bean.ResultMessageBean;
import jp.co.toshiba.hby.pspromis.syuueki.bean.S011Bean;
import jp.co.toshiba.hby.pspromis.syuueki.service.S011Service;
import jp.co.toshiba.hby.pspromis.syuueki.service.StoredProceduresService;
import jp.co.toshiba.hby.pspromis.syuueki.util.CdiUtils;
import jp.co.toshiba.hby.pspromis.syuueki.util.ParameterBinder;

/**
 * PS-Promis収益管理システム
 * 備考入力 Servlet
 * @author masaki
 */
@WebServlet(name="S011", urlPatterns={"/servlet/S011", "/servlet/S011/*"})
public class S011Servlet extends AbstractServlet {

    /**
     * jsp
     */
    private static final String INDEX_JSP = "S011/s011.jsp";

    /**
     * 使用serviceクラスをinjection(CDI)<br>
     * InjectアノテーションよりAPサーバー(Glassfish)側で自動的にインスタンス作成(new)される。<br>
     * service側はステートレスセッションbeanにするため、Statelessアノテーションをつけておくこと。<br>
     */
    @Inject
    private S011Service s011Service;

    @Inject
    private StoredProceduresService storedProceduresService;
    
    /**
     * パラメータ格納クラスをinjection(CDI)<br>
     * InjectアノテーションよりAPサーバー(Glassfish)側で自動的にインスタンス作成(new)される。<br>
     */
    @Inject
    private S011Bean s011Bean;
    
    /**
     * 初期表示
     * @param req
     * @param resp
     * @return
     * @throws Exception 
     */
    public String indexAction(HttpServletRequest req, HttpServletResponse resp)
    throws Exception {
        logger.info("S011Servlet#indexAction");
        
        ParameterBinder.Bind(s011Bean, req);
        // サービスの実行(トランザクションの単位にもなる)
        s011Service.indexExecute();

        return INDEX_JSP;
    }
    
    /**
     * 保存
     * @param req
     * @param resp
     * @return
     * @throws Exception 
     */
    public String saveAction(HttpServletRequest req, HttpServletResponse resp)
    throws Exception {
        logger.info("S011Servlet#saveAction");
        
        ParameterBinder.Bind(s011Bean, req);
        
        s011Service.save();
        // (2017/11/22 (原子力)連携バッチは自立型トランザクションになったため、いったん登録状態のcommitが確定された状態で実行するように変更
        s011Service.callNuclearSysRenkeiDisp();
        
        // (原子力)連携バッチを実行
        //storedProceduresService.callN7RenkeiBatchJudge(s011Bean.getAnkenId(), s011Bean.getRirekiId());

        // 処理結果を戻す。
        Map<String, Object> jsonMap = new HashMap<>();
        ResultMessageBean resultMessageBean = CdiUtils.getBean(ResultMessageBean.class);
        resultMessageBean.createResultMessage(jsonMap);
        resopnseDecodeJson(resp, jsonMap);

        return null;
    }
    
}
