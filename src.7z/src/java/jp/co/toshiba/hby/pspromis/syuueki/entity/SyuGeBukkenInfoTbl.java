package jp.co.toshiba.hby.pspromis.syuueki.entity;

import java.io.Serializable;
import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.Date;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
//import javax.persistence.Transient;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

/**
 *
 * @author ibayashi
 */
@Entity
@Table(name = "SYU_GE_BUKKEN_INFO_TBL")
public class SyuGeBukkenInfoTbl implements Serializable {
    private static final long serialVersionUID = 1L;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 32)
    @Column(name = "ANKEN_ID")
    @Id
    private String ankenId;
    @Basic(optional = false)
    @NotNull
    @Column(name = "RIREKI_ID")
    @Id
    private int rirekiId;
    @Basic(optional = false)
    @NotNull
    @Column(name = "ANKEN_REV")
    private long ankenRev;
    @Size(max = 1)
    @Column(name = "STATUS")
    private String status;
    @Size(max = 32)
    @Column(name = "SAKUSEI_DEPT_CODE")
    private String sakuseiDeptCode;
    @Size(max = 32)
    @Column(name = "ANKEN_MATOME_NO")
    private String ankenMatomeNo;
    @Size(max = 32)
    @Column(name = "SPURT_NO")
    private String spurtNo;
    @Size(max = 32)
    @Column(name = "SPURT_REV")
    private String spurtRev;
    @Size(max = 32)
    @Column(name = "OLD_T_ANKEN_NO")
    private String oldTAnkenNo;
    @Size(max = 1)
    @Column(name = "ANKEN_FLG")
    private String ankenFlg;
    @Size(max = 1)
    @Column(name = "HB_NET_FLG")
    private String hbNetFlg;
    @Size(max = 1)
    @Column(name = "SALES_CLASS")
    private String salesClass;
    @Size(max = 1)
    @Column(name = "NET_KANRI_FLG")
    private String netKanriFlg;
    @Size(max = 2)
    @Column(name = "KEIYAKU_GAIKA_FLG")
    private String keiyakuGaikaFlg;
    @Size(max = 2)
    @Column(name = "CHOTATU_GAIKA_FLG")
    private String chotatuGaikaFlg;
    @Size(max = 1)
    @Column(name = "SYUEKI_FLG")
    private String syuekiFlg;
    @Size(max = 6)
    @Column(name = "KANJO_YM")
    private String kanjoYm;
    @Size(max = 12)
    @Column(name = "MAIN_ORDER_NO")
    private String mainOrderNo;
    @Size(max = 12)
    @Column(name = "ORDER_NO")
    private String orderNo;
    @Size(max = 256)
    @Column(name = "ANKEN_NAME")
    private String ankenName;
    @Size(max = 256)
    @Column(name = "ANKEN_MATOME_NAME")
    private String ankenMatomeName;
    @Size(max = 32)
    @Column(name = "STCH_CODE")
    private String stchCode;
    @Size(max = 256)
    @Column(name = "STCH_NAME")
    private String stchName;
    @Size(max = 256)
    @Column(name = "TRADE_NAME")
    private String tradeName;
    @Size(max = 32)
    @Column(name = "PLANT_CODE")
    private String plantCode;
    @Size(max = 256)
    @Column(name = "PLANT_NAME")
    private String plantName;
    @Size(max = 32)
    @Column(name = "TRADE_CODE")
    private String tradeCode;
    @Size(max = 7)
    @Column(name = "TRADE_CODE_PREFIX")
    private String tradeCodePrefix;
    @Size(max = 11)
    @Column(name = "DESTINATION_TRADE_CD_J")
    private String destinationTradeCdJ;
    @Size(max = 7)
    @Column(name = "DESTINATION_TRADE_CD_J_PREFIX")
    private String destinationTradeCdJPrefix;
    @Size(max = 256)
    @Column(name = "DESTINATION_TRADE_NM")
    private String destinationTradeNm;
    @Column(name = "URIAGE_START")
    @Temporal(TemporalType.TIMESTAMP)
    private Date uriageStart;
    @Column(name = "URIAGE_END")
    @Temporal(TemporalType.TIMESTAMP)
    private Date uriageEnd;
    @Column(name = "URIAGE_END_FIN")
    @Temporal(TemporalType.TIMESTAMP)
    private Date uriageEndFin;
    @Size(max = 12)
    @Column(name = "DIVISION_CODE")
    private String divisionCode;
    @Size(max = 10)
    @Column(name = "ANKEN_TEAM_CODE")
    private String ankenTeamCode;
    @Size(max = 12)
    @Column(name = "ISSUED_SECTION_ID")
    private String issuedSectionId;
    @Size(max = 6)
    @Column(name = "ISSUED_DEPT_CODE")
    private String issuedDeptCode;
    @Size(max = 32)
    @Column(name = "ISSUED_DEPT_NAME2")
    private String issuedDeptName2;
    @Size(max = 32)
    @Column(name = "ISSUED_DEPT_NAME3")
    private String issuedDeptName3;
    @Size(max = 256)
    @Column(name = "ISSUED_JOB_GROUP_CODE")
    private String issuedJobGroupCode;
    @Size(max = 256)
    @Column(name = "ISSUED_JOB_GROUP_NAME")
    private String issuedJobGroupName;
    @Size(max = 12)
    @Column(name = "SUB_BU_ID")
    private String subBuId;
    @Size(max = 32)
    @Column(name = "SUB_BU_NAME")
    private String subBuName;
    @Column(name = "BU_ID")
    private Long buId;
    @Size(max = 32)
    @Column(name = "BU_NAME")
    private String buName;
    @Column(name = "SP")
    private BigInteger sp;
    @Column(name = "NET")
    private BigInteger net;
    @Size(max = 32)
    @Column(name = "CHUNYU_PTN_NO")
    private String chunyuPtnNo;
    @Column(name = "CHUNYU_START_YM")
    @Temporal(TemporalType.TIMESTAMP)
    private Date chunyuStartYm;
    @Column(name = "STAGE_ID")
    private Long stageId;
    @Size(max = 64)
    @Column(name = "STAGE_NAME")
    private String stageName;
    @Size(max = 30)
    @Column(name = "BUNRUI_CD")
    private String bunruiCd;
    @Size(max = 2)
    @Column(name = "ANKEN_KBN")
    private String ankenKbn;
    @Size(max = 2)
    @Column(name = "FIXED_LEVEL_ID")
    private String fixedLevelId;
    @Size(max = 1)
    @Column(name = "MITUMORI_KBN")
    private String mitumoriKbn;
    @Size(max = 32)
    @Column(name = "SITE_CD")
    private String siteCd;
    @Size(max = 8)
    @Column(name = "JISSI_NENDO")
    private String jissiNendo;
    @Column(name = "TEIKEN")
    private Integer teiken;
    @Size(max = 2)
    @Column(name = "ISP_KBN")
    private String ispKbn;
    @Size(max = 256)
    @Column(name = "BIKOU_FIXED_MIKOMI")
    private String bikouFixedMikomi;
    @Size(max = 256)
    @Column(name = "BIKOU_KIKAN")
    private String bikouKikan;
    @Column(name = "KEIYAKU_SP")
    private BigInteger keiyakuSp;
    @Column(name = "URIAGE_NET")
    private BigInteger uriageNet;
    @Size(max = 1)
    @Column(name = "IS_DELETED")
    private String isDeleted;
    @Size(max = 2)
    @Column(name = "URIAGE_END_FLG")
    private String uriageEndFlg;
    @Column(name = "CREATED_AT")
    @Temporal(TemporalType.TIMESTAMP)
    private Date createdAt;
    @Size(max = 32)
    @Column(name = "CREATED_BY")
    private String createdBy;
    @Column(name = "UPDATED_AT")
    @Temporal(TemporalType.TIMESTAMP)
    private Date updatedAt;
    @Size(max = 32)
    @Column(name = "UPDATED_BY")
    private String updatedBy;
    @Column(name = "UPDATED_BATCH_AT")
    @Temporal(TemporalType.TIMESTAMP)
    private Date updatedBatchAt;
    @Column(name = "UPDATED_BATCH_BY")
    private String updatedBatchBy;
    @Column(name = "SABUN_HANEI_FLG")
    private String sabunHaneiFlg;
    @Column(name = "KOUSIN_FLG")
    private String koushinFlg;
    @Column(name = "INPUT_ANNEN_FLG")
    private String inputAnkenFlg;
    @Column(name = "INPUT_KI_NET_FLG")
    private String inputKiNetFlg;
    @Column(name = "INPUT_SA_NET_FLG")
    private String inputSaNetFlg;
    @Column(name = "SAIKEISAN_FLG")
    private String saikeisanFlg;
    @Column(name = "ISP_ORDER_NO")
    private String ispOrderNo;
    @Column(name = "INPUT_ANKEN_DISP")
    private String inputAnkenDisp;
    @Column(name = "QUARTER_DISP_FLG")
    private String quarterDispFlg;
    @Column(name = "MAERUIKEI_DISP_FLG")
    private String maeruikeiDispFlg;
    @Column(name = "SHIRAJI_FLG")
    private String shirajiFlg;
    @Column(name = "SN_KBN")
    private String snKbn;
    @Column(name = "TORIATSU_CD")
    private String toriatsuCd;
    @Column(name = "EG_TEAM_CD")
    private String egTeamCd;
    @Column(name = "SZ_TEAM_CD")
    private String szTeamCd;
    @Column(name = "HB_C_CD")
    private String hbCCd;
    @Column(name = "HB_S_CD")
    private String hbSCd;
    @Column(name = "HB_E_CD")
    private String hbECd;
    @Column(name = "SZ_C_CD")
    private String szCCd;
    @Column(name = "SZ_S_CD")
    private String szSCd;
    @Column(name = "SZ_E_CD")
    private String szECd;
    @Column(name = "HAT_JYUCHU_DATE")
    @Temporal(TemporalType.DATE)
    private Date hatJyuchuDate;
    @Column(name = "HAT_SYUKKA_NICHIGEN")
    @Temporal(TemporalType.DATE)
    private Date hatSyukkaNichigen;
    @Column(name = "HAT_KAISYU_YOTEI")
    @Temporal(TemporalType.DATE)
    private Date hatKaisyuYotei;
    @Column(name = "KOU_OTSU_KBN")
    private String kouOtsuKbn;
    @Column(name = "GYOTAI")
    private String gyotai;
    @Column(name = "HAT_URIAGE_YOTEI")
    @Temporal(TemporalType.DATE)
    private Date hatUriageYotei;
    @Size(max = 240)
    @Column(name = "TORIATSU_NM")
    private String toriatsuNm;
    @Column(name = "SAISYU_SP_GAIKA")
    private BigDecimal saisyuSpGaika;
    @Column(name = "SAISYU_JYUCHU_RATE")
    private BigDecimal saisyuJyuchuRate;
    @Column(name = "SAISYU_URIAGE_RATE")
    private BigDecimal saisyuUriageRate;
    @Column(name = "SAISYU_SP")
    private BigInteger saisyuSp;
    @Column(name = "SAISYU_NET")
    private BigInteger saisyuNet;
    @Column(name = "SAISYU_MRITU")
    private BigDecimal saisyuMritu;
    @Column(name = "JYUCHU_END")
    @Temporal(TemporalType.DATE)
    private Date jyuchuEnd;
    @Column(name = "YOSAN_KANJYO_YM")
    private Integer yosanKanjyoYm;
    @Column(name = "YOSAN_SP_GAIKA")
    private BigDecimal yosanSpGaika;
    @Column(name = "YOSAN_SP")
    private BigInteger yosanSp;
    @Column(name = "YOSAN_NET")
    private BigInteger yosanNet;
    @Column(name = "HAT_SP")
    private BigInteger hatSp;
    @Column(name = "HAT_NET")
    private BigInteger hatNet;
    @Column(name = "KEIYAKU_SP_GAIKA")
    private BigDecimal keiyakuSpGaika;
    @Size(max = 2)
    @Column(name = "KEIYAKU_RENBAN_MAX")
    private String keiyakuRenbanMax;
    @Size(max = 9)
    @Column(name = "KEIYAKU_CUR_CODE")
    private String keiyakuCurCode;
    @Column(name = "URIAGE_SP_GAIKA")
    private BigDecimal uriageSpGaika;
    @Column(name = "URIAGE_SP")
    private BigInteger uriageSp;
    @Column(name = "JYUCHU_ZAN_SP")
    private BigInteger jyuchuZanSp;
    @Column(name = "JYUCHU_ZAN_NET")
    private BigInteger jyuchuZanNet;
    @Size(max = 1)
    @Column(name = "JYUCHU_ZAN_FLG")
    private String jyuchuZanFlg;
    @Column(name = "CHUKEI_SP")
    private BigInteger chukeiSp;
    @Column(name = "CHUKEI_NET")
    private BigInteger chukeiNet;
    @Size(max = 1)
    @Column(name = "INPUT_ICHIRAN_FLG")
    private String inputIchiranFlg;
    @Size(max = 10)
    @Column(name = "ATSUKAI_TEAM_CODE")
    private String atsukaiTeamCode;
    @Size(max = 15)
    @Column(name = "ATSUKAI_C_CODE")
    private String atsukaiCCode;
    @Size(max = 6)
    @Column(name = "SAIKEISAN_ENDDATE")
    private String saikeisanEnddate;

    @Column(name = "HAT_EG_EMP_NO")
    private String hatEgEmpNo;

    @Column(name = "HAT_EG_EMP_NM")
    private String hatEgEmpNm;

    @Column(name = "HATLINK_SPNET_FLG")
    private String hatlinkSpnetFlg;

    @Column(name = "HATLINK_DATE_FLG")
    private String hatlinkDateFlg;

    @Column(name = "ANKEN_RANK")
    private String ankenRank;

    @Column(name = "POTENTIAL_FLG")
    private String potentialFlg;

    @Column(name = "MONDAI_FLG")
    private String mondaiFlg;

    @Column(name = "MONDAI_COMMENT")
    private String mondaiComment;

    @Column(name = "SP_KAKUTEI_FLG")
    private String spKakuteiFlg;

    @Column(name = "NET_KAKUTEI_FLG")
    private String netKakuteiFlg;

    @Column(name = "KAISYU_END")
    @Temporal(TemporalType.DATE)
    private Date kaisyuEnd;

    @Column(name = "NOKI")
    @Temporal(TemporalType.DATE)
    private Date noki;

    @Column(name = "KENSYUTUKI")
    private String kensyutuki;

    @Column(name = "A_NO")
    private String aNo;

    @Column(name = "KEIYAKU_KEITAI_CD")
    private String keiyakuKeitaiCd;

    @Column(name = "ANKEN_SYS_ID")
    private BigInteger ankenSysId;
    @Size(max = 10)
    @Column(name = "HAT_EG_BUKA_CD")
    private String hatEgBukaCd;
    @Size(max = 24)
    @Column(name = "HAT_EG_BUKA_RNM")
    private String hatEgBukaRnm;
    @Size(max = 10)
    @Column(name = "SYU_JOBGR_CD")
    private String syuJobgrCd;
    @Size(max = 32)
    @Column(name = "SYU_JOBGR_NM")
    private String syuJobgrNm;
    @Size(max = 8)
    @Column(name = "SYU_TANTO_ID")
    private String syuTantoId;
    @Size(max = 30)
    @Column(name = "SYU_TANTO_NM")
    private String syuTantoNm;
    @Size(max = 10)
    @Column(name = "EIG_JOBGR_CD")
    private String eigJobgrCd;
    @Size(max = 32)
    @Column(name = "EIG_JOBGR_NM")
    private String eigJobgrNm;
    @Size(max = 8)
    @Column(name = "EIG_TANTO_ID")
    private String eigTantoId;
    @Size(max = 30)
    @Column(name = "EIG_TANTO_NM")
    private String eigTantoNm;
    @Size(max = 10)
    @Column(name = "SYUKAN_JOBGR_CD")
    private String syukanJobgrCd;
    @Size(max = 32)
    @Column(name = "SYUKAN_JOBGR_NM")
    private String syukanJobgrNm;
    @Size(max = 11)
    @Column(name = "SETU_BUNRUI_CD")
    private String setuBunruiCd;
    @Column(name = "JYUCHU_ZAN_ISP")
    private BigInteger jyuchuZanIsp;
    @Column(name = "JYUCHU_ZAN_TENBAI")
    private BigInteger jyuchuZanTenbai;
    @Size(max = 1)
    @Column(name = "BUNKATSU_FLG")
    private String bunkatsuFlg;
    @Size(max = 1)
    @Column(name = "URIAGE_SHIJI_FLG")
    private String uriageShijiFlg;
    @Size(max = 1)
    @Column(name = "URI_SYUSEI")
    private String uriSyusei;
    @Size(max = 1)
    @Column(name = "MIT_KAITO_FLG")
    private String mitKaitoFlg;
    @Size(max = 1)
    @Column(name = "MIKOMI_FLG")
    private String mikomiFlg;
    @Size(max = 1)
    @Column(name = "CHUNYU_TYOKA_FLG")
    private String chunyuTyokaFlg;
    @Size(max = 1)
    @Column(name = "KARI_SP_FLG")
    private String kariSpFlg;
    @Size(max = 1)
    @Column(name = "KARI_NET_FLG")
    private String kariNetFlg;
    @Size(max = 1)
    @Column(name = "CHOTATU_KAITO_FLG")
    private String chotatuKaitoFlg;
    @Size(max = 12)
    @Column(name = "ISP_DIVISION_NM")
    private String ispDivisionNm;
    @Size(max = 32)
    @Column(name = "ISP_RELATE_ID")
    private String ispRelateId;

    @Column(name = "ZENKAI_ID")
    private int zenkaiId;
    @Column(name = "KAISYU_KAKUNIN_FLG")
    private Short kaisyuKakuninFlg;
    @Column(name = "URIAGE_TOV")
    private BigInteger uriageTov;
    @Size(max = 12)
    @Column(name = "KESSAI_STS_NM")
    private String kessaiStsNm;
    @Size(max = 32)
    @Column(name = "KESSAI_ID")
    private String kessaiId;
    @Column(name = "SALES_ROUTE_NM")
    private String salesRouteNm;
    
    //20180302 原価回収基準対応　ADD 
    @Column(name = "SALES_CLASS_GENKA")
    private String salesClassGenka;
    
    // 2018A ロスコン対象FLG ADD
    @Column(name = "LOSS_CONTROL_FLAG")
    private String lossControlFlag;
    
    public SyuGeBukkenInfoTbl() {
    }

    public String getAnkenId() {
        return ankenId;
    }

    public void setAnkenId(String ankenId) {
        this.ankenId = ankenId;
    }

    public int getRirekiId() {
        return rirekiId;
    }

    public void setRirekiId(int rirekiId) {
        this.rirekiId = rirekiId;
    }

    public long getAnkenRev() {
        return ankenRev;
    }

    public void setAnkenRev(long ankenRev) {
        this.ankenRev = ankenRev;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getSakuseiDeptCode() {
        return sakuseiDeptCode;
    }

    public void setSakuseiDeptCode(String sakuseiDeptCode) {
        this.sakuseiDeptCode = sakuseiDeptCode;
    }

    public String getAnkenMatomeNo() {
        return ankenMatomeNo;
    }

    public void setAnkenMatomeNo(String ankenMatomeNo) {
        this.ankenMatomeNo = ankenMatomeNo;
    }

    public String getSpurtNo() {
        return spurtNo;
    }

    public void setSpurtNo(String spurtNo) {
        this.spurtNo = spurtNo;
    }

    public String getSpurtRev() {
        return spurtRev;
    }

    public void setSpurtRev(String spurtRev) {
        this.spurtRev = spurtRev;
    }

    public String getOldTAnkenNo() {
        return oldTAnkenNo;
    }

    public void setOldTAnkenNo(String oldTAnkenNo) {
        this.oldTAnkenNo = oldTAnkenNo;
    }

    public String getAnkenFlg() {
        return ankenFlg;
    }

    public void setAnkenFlg(String ankenFlg) {
        this.ankenFlg = ankenFlg;
    }

    public String getHbNetFlg() {
        return hbNetFlg;
    }

    public void setHbNetFlg(String hbNetFlg) {
        this.hbNetFlg = hbNetFlg;
    }

    public String getSalesClass() {
        return salesClass;
    }

    public void setSalesClass(String salesClass) {
        this.salesClass = salesClass;
    }

    public String getNetKanriFlg() {
        return netKanriFlg;
    }

    public void setNetKanriFlg(String netKanriFlg) {
        this.netKanriFlg = netKanriFlg;
    }

    public String getKeiyakuGaikaFlg() {
        return keiyakuGaikaFlg;
    }

    public void setKeiyakuGaikaFlg(String keiyakuGaikaFlg) {
        this.keiyakuGaikaFlg = keiyakuGaikaFlg;
    }

    public String getChotatuGaikaFlg() {
        return chotatuGaikaFlg;
    }

    public void setChotatuGaikaFlg(String chotatuGaikaFlg) {
        this.chotatuGaikaFlg = chotatuGaikaFlg;
    }

    public String getSyuekiFlg() {
        return syuekiFlg;
    }

    public void setSyuekiFlg(String syuekiFlg) {
        this.syuekiFlg = syuekiFlg;
    }

    public String getKanjoYm() {
        return kanjoYm;
    }

    public void setKanjoYm(String kanjoYm) {
        this.kanjoYm = kanjoYm;
    }

    public String getMainOrderNo() {
        return mainOrderNo;
    }

    public void setMainOrderNo(String mainOrderNo) {
        this.mainOrderNo = mainOrderNo;
    }

    public String getOrderNo() {
        return orderNo;
    }

    public void setOrderNo(String orderNo) {
        this.orderNo = orderNo;
    }

    public String getAnkenName() {
        return ankenName;
    }

    public void setAnkenName(String ankenName) {
        this.ankenName = ankenName;
    }

    public String getAnkenMatomeName() {
        return ankenMatomeName;
    }

    public void setAnkenMatomeName(String ankenMatomeName) {
        this.ankenMatomeName = ankenMatomeName;
    }

    public String getStchCode() {
        return stchCode;
    }

    public void setStchCode(String stchCode) {
        this.stchCode = stchCode;
    }

    public String getStchName() {
        return stchName;
    }

    public void setStchName(String stchName) {
        this.stchName = stchName;
    }

    public String getTradeName() {
        return tradeName;
    }

    public void setTradeName(String tradeName) {
        this.tradeName = tradeName;
    }

    public String getPlantCode() {
        return plantCode;
    }

    public void setPlantCode(String plantCode) {
        this.plantCode = plantCode;
    }

    public String getPlantName() {
        return plantName;
    }

    public void setPlantName(String plantName) {
        this.plantName = plantName;
    }

    public String getTradeCode() {
        return tradeCode;
    }

    public void setTradeCode(String tradeCode) {
        this.tradeCode = tradeCode;
    }

    public String getTradeCodePrefix() {
        return tradeCodePrefix;
    }

    public void setTradeCodePrefix(String tradeCodePrefix) {
        this.tradeCodePrefix = tradeCodePrefix;
    }

    public String getDestinationTradeCdJ() {
        return destinationTradeCdJ;
    }

    public void setDestinationTradeCdJ(String destinationTradeCdJ) {
        this.destinationTradeCdJ = destinationTradeCdJ;
    }

    public String getDestinationTradeCdJPrefix() {
        return destinationTradeCdJPrefix;
    }

    public void setDestinationTradeCdJPrefix(String destinationTradeCdJPrefix) {
        this.destinationTradeCdJPrefix = destinationTradeCdJPrefix;
    }

    public String getDestinationTradeNm() {
        return destinationTradeNm;
    }

    public void setDestinationTradeNm(String destinationTradeNm) {
        this.destinationTradeNm = destinationTradeNm;
    }

    public Date getUriageStart() {
        return uriageStart;
    }

    public void setUriageStart(Date uriageStart) {
        this.uriageStart = uriageStart;
    }

    public Date getUriageEnd() {
        return uriageEnd;
    }

    public void setUriageEnd(Date uriageEnd) {
        this.uriageEnd = uriageEnd;
    }

    public Date getUriageEndFin() {
        return uriageEndFin;
    }

    public void setUriageEndFin(Date uriageEndFin) {
        this.uriageEndFin = uriageEndFin;
    }

    public String getDivisionCode() {
        return divisionCode;
    }

    public void setDivisionCode(String divisionCode) {
        this.divisionCode = divisionCode;
    }

    public String getAnkenTeamCode() {
        return ankenTeamCode;
    }

    public void setAnkenTeamCode(String ankenTeamCode) {
        this.ankenTeamCode = ankenTeamCode;
    }

    public String getIssuedSectionId() {
        return issuedSectionId;
    }

    public void setIssuedSectionId(String issuedSectionId) {
        this.issuedSectionId = issuedSectionId;
    }

    public String getIssuedDeptCode() {
        return issuedDeptCode;
    }

    public void setIssuedDeptCode(String issuedDeptCode) {
        this.issuedDeptCode = issuedDeptCode;
    }

    public String getIssuedDeptName2() {
        return issuedDeptName2;
    }

    public void setIssuedDeptName2(String issuedDeptName2) {
        this.issuedDeptName2 = issuedDeptName2;
    }

    public String getIssuedDeptName3() {
        return issuedDeptName3;
    }

    public void setIssuedDeptName3(String issuedDeptName3) {
        this.issuedDeptName3 = issuedDeptName3;
    }

    public String getIssuedJobGroupCode() {
        return issuedJobGroupCode;
    }

    public void setIssuedJobGroupCode(String issuedJobGroupCode) {
        this.issuedJobGroupCode = issuedJobGroupCode;
    }

    public String getIssuedJobGroupName() {
        return issuedJobGroupName;
    }

    public void setIssuedJobGroupName(String issuedJobGroupName) {
        this.issuedJobGroupName = issuedJobGroupName;
    }

    public String getSubBuId() {
        return subBuId;
    }

    public void setSubBuId(String subBuId) {
        this.subBuId = subBuId;
    }

    public String getSubBuName() {
        return subBuName;
    }

    public void setSubBuName(String subBuName) {
        this.subBuName = subBuName;
    }

    public Long getBuId() {
        return buId;
    }

    public void setBuId(Long buId) {
        this.buId = buId;
    }

    public String getBuName() {
        return buName;
    }

    public void setBuName(String buName) {
        this.buName = buName;
    }

    public BigInteger getSp() {
        return sp;
    }

    public void setSp(BigInteger sp) {
        this.sp = sp;
    }

    public BigInteger getNet() {
        return net;
    }

    public void setNet(BigInteger net) {
        this.net = net;
    }

    public String getChunyuPtnNo() {
        return chunyuPtnNo;
    }

    public void setChunyuPtnNo(String chunyuPtnNo) {
        this.chunyuPtnNo = chunyuPtnNo;
    }

    public Date getChunyuStartYm() {
        return chunyuStartYm;
    }

    public void setChunyuStartYm(Date chunyuStartYm) {
        this.chunyuStartYm = chunyuStartYm;
    }

    public Long getStageId() {
        return stageId;
    }

    public void setStageId(Long stageId) {
        this.stageId = stageId;
    }

    public String getStageName() {
        return stageName;
    }

    public void setStageName(String stageName) {
        this.stageName = stageName;
    }

    public String getBunruiCd() {
        return bunruiCd;
    }

    public void setBunruiCd(String bunruiCd) {
        this.bunruiCd = bunruiCd;
    }

    public String getAnkenKbn() {
        return ankenKbn;
    }

    public void setAnkenKbn(String ankenKbn) {
        this.ankenKbn = ankenKbn;
    }

    public String getFixedLevelId() {
        return fixedLevelId;
    }

    public void setFixedLevelId(String fixedLevelId) {
        this.fixedLevelId = fixedLevelId;
    }

    public String getMitumoriKbn() {
        return mitumoriKbn;
    }

    public void setMitumoriKbn(String mitumoriKbn) {
        this.mitumoriKbn = mitumoriKbn;
    }

    public String getSiteCd() {
        return siteCd;
    }

    public void setSiteCd(String siteCd) {
        this.siteCd = siteCd;
    }

    public String getJissiNendo() {
        return jissiNendo;
    }

    public void setJissiNendo(String jissiNendo) {
        this.jissiNendo = jissiNendo;
    }

    public Integer getTeiken() {
        return teiken;
    }

    public void setTeiken(Integer teiken) {
        this.teiken = teiken;
    }

    public String getIspKbn() {
        return ispKbn;
    }

    public void setIspKbn(String ispKbn) {
        this.ispKbn = ispKbn;
    }

    public String getBikouFixedMikomi() {
        return bikouFixedMikomi;
    }

    public void setBikouFixedMikomi(String bikouFixedMikomi) {
        this.bikouFixedMikomi = bikouFixedMikomi;
    }

    public String getBikouKikan() {
        return bikouKikan;
    }

    public void setBikouKikan(String bikouKikan) {
        this.bikouKikan = bikouKikan;
    }

    public BigInteger getKeiyakuSp() {
        return keiyakuSp;
    }

    public void setKeiyakuSp(BigInteger keiyakuSp) {
        this.keiyakuSp = keiyakuSp;
    }

    public BigInteger getUriageNet() {
        return uriageNet;
    }

    public void setUriageNet(BigInteger uriageNet) {
        this.uriageNet = uriageNet;
    }

    public String getIsDeleted() {
        return isDeleted;
    }

    public void setIsDeleted(String isDeleted) {
        this.isDeleted = isDeleted;
    }

    public Date getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(Date createdAt) {
        this.createdAt = createdAt;
    }

    public String getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    public Date getUpdatedAt() {
        return updatedAt;
    }

    public void setUpdatedAt(Date updatedAt) {
        this.updatedAt = updatedAt;
    }

    public String getUpdatedBy() {
        return updatedBy;
    }

    public void setUpdatedBy(String updatedBy) {
        this.updatedBy = updatedBy;
    }

    public Date getUpdatedBatchAt() {
        return updatedBatchAt;
    }

    public void setUpdatedBatchAt(Date updatedBatchAt) {
        this.updatedBatchAt = updatedBatchAt;
    }

    public String getUpdatedBatchBy() {
        return updatedBatchBy;
    }

    public void setUpdatedBatchBy(String updatedBatchBy) {
        this.updatedBatchBy = updatedBatchBy;
    }

    public String getUriageEndFlg() {
        return uriageEndFlg;
    }

    public void setUriageEndFlg(String uriageEndFlg) {
        this.uriageEndFlg = uriageEndFlg;
    }

    public String getSabunHaneiFlg() {
        return sabunHaneiFlg;
    }

    public void setSabunHaneiFlg(String sabunHaneiFlg) {
        this.sabunHaneiFlg = sabunHaneiFlg;
    }

    public String getKoushinFlg() {
        return koushinFlg;
    }

    public void setKoushinFlg(String koushinFlg) {
        this.koushinFlg = koushinFlg;
    }

    public String getInputAnkenFlg() {
        return inputAnkenFlg;
    }

    public void setInputAnkenFlg(String inputAnkenFlg) {
        this.inputAnkenFlg = inputAnkenFlg;
    }

    public String getInputKiNetFlg() {
        return inputKiNetFlg;
    }

    public void setInputKiNetFlg(String inputKiNetFlg) {
        this.inputKiNetFlg = inputKiNetFlg;
    }

    public String getInputSaNetFlg() {
        return inputSaNetFlg;
    }

    public void setInputSaNetFlg(String inputSaNetFlg) {
        this.inputSaNetFlg = inputSaNetFlg;
    }

    public String getSaikeisanFlg() {
        return saikeisanFlg;
    }

    public void setSaikeisanFlg(String saikeisanFlg) {
        this.saikeisanFlg = saikeisanFlg;
    }

    public String getIspOrderNo() {
        return ispOrderNo;
    }

    public void setIspOrderNo(String ispOrderNo) {
        this.ispOrderNo = ispOrderNo;
    }

    public String getInputAnkenDisp() {
        return inputAnkenDisp;
    }

    public void setInputAnkenDisp(String inputAnkenDisp) {
        this.inputAnkenDisp = inputAnkenDisp;
    }

    public String getQuarterDispFlg() {
        return quarterDispFlg;
    }

    public void setQuarterDispFlg(String quarterDispFlg) {
        this.quarterDispFlg = quarterDispFlg;
    }

    /**
     * @return the maeruikeiDispFlg
     */
    public String getMaeruikeiDispFlg() {
        return maeruikeiDispFlg;
    }

    /**
     * @param maeruikeiDispFlg the maeruikeiDispFlg to set
     */
    public void setMaeruikeiDispFlg(String maeruikeiDispFlg) {
        this.maeruikeiDispFlg = maeruikeiDispFlg;
    }

    public String getShirajiFlg() {
        return shirajiFlg;
    }

    public void setShirajiFlg(String shirajiFlg) {
        this.shirajiFlg = shirajiFlg;
    }

    public String getSnKbn() {
        return snKbn;
    }

    public void setSnKbn(String snKbn) {
        this.snKbn = snKbn;
    }

    public String getToriatsuCd() {
        return toriatsuCd;
    }

    public void setToriatsuCd(String toriatsuCd) {
        this.toriatsuCd = toriatsuCd;
    }

    public String getEgTeamCd() {
        return egTeamCd;
    }

    public void setEgTeamCd(String egTeamCd) {
        this.egTeamCd = egTeamCd;
    }

    public String getSzTeamCd() {
        return szTeamCd;
    }

    public void setSzTeamCd(String szTeamCd) {
        this.szTeamCd = szTeamCd;
    }

    public String getHbCCd() {
        return hbCCd;
    }

    public void setHbCCd(String hbCCd) {
        this.hbCCd = hbCCd;
    }

    public String getHbSCd() {
        return hbSCd;
    }

    public void setHbSCd(String hbSCd) {
        this.hbSCd = hbSCd;
    }

    public String getHbECd() {
        return hbECd;
    }

    public void setHbECd(String hbECd) {
        this.hbECd = hbECd;
    }

    public String getSzCCd() {
        return szCCd;
    }

    public void setSzCCd(String szCCd) {
        this.szCCd = szCCd;
    }

    public String getSzSCd() {
        return szSCd;
    }

    public void setSzSCd(String szSCd) {
        this.szSCd = szSCd;
    }

    public String getSzECd() {
        return szECd;
    }

    public void setSzECd(String szECd) {
        this.szECd = szECd;
    }

    public Date getHatJyuchuDate() {
        return hatJyuchuDate;
    }

    public void setHatJyuchuDate(Date hatJyuchuDate) {
        this.hatJyuchuDate = hatJyuchuDate;
    }

    public Date getHatSyukkaNichigen() {
        return hatSyukkaNichigen;
    }

    public void setHatSyukkaNichigen(Date hatSyukkaNichigen) {
        this.hatSyukkaNichigen = hatSyukkaNichigen;
    }

    public Date getHatKaisyuYotei() {
        return hatKaisyuYotei;
    }

    public void setHatKaisyuYotei(Date hatKaisyuYotei) {
        this.hatKaisyuYotei = hatKaisyuYotei;
    }

    public String getKouOtsuKbn() {
        return kouOtsuKbn;
    }

    public void setKouOtsuKbn(String kouOtsuKbn) {
        this.kouOtsuKbn = kouOtsuKbn;
    }

    public String getGyotai() {
        return gyotai;
    }

    public void setGyotai(String gyotai) {
        this.gyotai = gyotai;
    }

    public Date getHatUriageYotei() {
        return hatUriageYotei;
    }

    public void setHatUriageYotei(Date hatUriageYotei) {
        this.hatUriageYotei = hatUriageYotei;
    }

    public String getToriatsuNm() {
        return toriatsuNm;
    }

    public void setToriatsuNm(String toriatsuNm) {
        this.toriatsuNm = toriatsuNm;
    }

    public BigDecimal getSaisyuSpGaika() {
        return saisyuSpGaika;
    }

    public void setSaisyuSpGaika(BigDecimal saisyuSpGaika) {
        this.saisyuSpGaika = saisyuSpGaika;
    }

    public BigDecimal getSaisyuJyuchuRate() {
        return saisyuJyuchuRate;
    }

    public void setSaisyuJyuchuRate(BigDecimal saisyuJyuchuRate) {
        this.saisyuJyuchuRate = saisyuJyuchuRate;
    }

    public BigDecimal getSaisyuUriageRate() {
        return saisyuUriageRate;
    }

    public void setSaisyuUriageRate(BigDecimal saisyuUriageRate) {
        this.saisyuUriageRate = saisyuUriageRate;
    }

    public BigInteger getSaisyuSp() {
        return saisyuSp;
    }

    public void setSaisyuSp(BigInteger saisyuSp) {
        this.saisyuSp = saisyuSp;
    }

    public BigInteger getSaisyuNet() {
        return saisyuNet;
    }

    public void setSaisyuNet(BigInteger saisyuNet) {
        this.saisyuNet = saisyuNet;
    }

    public BigDecimal getSaisyuMritu() {
        return saisyuMritu;
    }

    public void setSaisyuMritu(BigDecimal saisyuMritu) {
        this.saisyuMritu = saisyuMritu;
    }

    public Date getJyuchuEnd() {
        return jyuchuEnd;
    }

    public void setJyuchuEnd(Date jyuchuEnd) {
        this.jyuchuEnd = jyuchuEnd;
    }

    public Integer getYosanKanjyoYm() {
        return yosanKanjyoYm;
    }

    public void setYosanKanjyoYm(Integer yosanKanjyoYm) {
        this.yosanKanjyoYm = yosanKanjyoYm;
    }

    public BigDecimal getYosanSpGaika() {
        return yosanSpGaika;
    }

    public void setYosanSpGaika(BigDecimal yosanSpGaika) {
        this.yosanSpGaika = yosanSpGaika;
    }

    public BigInteger getYosanSp() {
        return yosanSp;
    }

    public void setYosanSp(BigInteger yosanSp) {
        this.yosanSp = yosanSp;
    }

    public BigInteger getYosanNet() {
        return yosanNet;
    }

    public void setYosanNet(BigInteger yosanNet) {
        this.yosanNet = yosanNet;
    }

    public BigInteger getHatSp() {
        return hatSp;
    }

    public void setHatSp(BigInteger hatSp) {
        this.hatSp = hatSp;
    }

    public BigInteger getHatNet() {
        return hatNet;
    }

    public void setHatNet(BigInteger hatNet) {
        this.hatNet = hatNet;
    }

    public BigDecimal getKeiyakuSpGaika() {
        return keiyakuSpGaika;
    }

    public void setKeiyakuSpGaika(BigDecimal keiyakuSpGaika) {
        this.keiyakuSpGaika = keiyakuSpGaika;
    }

    public String getKeiyakuRenbanMax() {
        return keiyakuRenbanMax;
    }

    public void setKeiyakuRenbanMax(String keiyakuRenbanMax) {
        this.keiyakuRenbanMax = keiyakuRenbanMax;
    }

    public String getKeiyakuCurCode() {
        return keiyakuCurCode;
    }

    public void setKeiyakuCurCode(String keiyakuCurCode) {
        this.keiyakuCurCode = keiyakuCurCode;
    }

    public BigDecimal getUriageSpGaika() {
        return uriageSpGaika;
    }

    public void setUriageSpGaika(BigDecimal uriageSpGaika) {
        this.uriageSpGaika = uriageSpGaika;
    }

    public BigInteger getUriageSp() {
        return uriageSp;
    }

    public void setUriageSp(BigInteger uriageSp) {
        this.uriageSp = uriageSp;
    }

    public BigInteger getJyuchuZanSp() {
        return jyuchuZanSp;
    }

    public void setJyuchuZanSp(BigInteger jyuchuZanSp) {
        this.jyuchuZanSp = jyuchuZanSp;
    }

    public BigInteger getJyuchuZanNet() {
        return jyuchuZanNet;
    }

    public void setJyuchuZanNet(BigInteger jyuchuZanNet) {
        this.jyuchuZanNet = jyuchuZanNet;
    }

    public String getJyuchuZanFlg() {
        return jyuchuZanFlg;
    }

    public void setJyuchuZanFlg(String jyuchuZanFlg) {
        this.jyuchuZanFlg = jyuchuZanFlg;
    }

    public BigInteger getChukeiSp() {
        return chukeiSp;
    }

    public void setChukeiSp(BigInteger chukeiSp) {
        this.chukeiSp = chukeiSp;
    }

    public BigInteger getChukeiNet() {
        return chukeiNet;
    }

    public void setChukeiNet(BigInteger chukeiNet) {
        this.chukeiNet = chukeiNet;
    }

    public String getInputIchiranFlg() {
        return inputIchiranFlg;
    }

    public void setInputIchiranFlg(String inputIchiranFlg) {
        this.inputIchiranFlg = inputIchiranFlg;
    }

    public String getAtsukaiTeamCode() {
        return atsukaiTeamCode;
    }

    public void setAtsukaiTeamCode(String atsukaiTeamCode) {
        this.atsukaiTeamCode = atsukaiTeamCode;
    }

    public String getAtsukaiCCode() {
        return atsukaiCCode;
    }

    public void setAtsukaiCCode(String atsukaiCCode) {
        this.atsukaiCCode = atsukaiCCode;
    }

    public String getSaikeisanEnddate() {
        return saikeisanEnddate;
    }

    public void setSaikeisanEnddate(String saikeisanEnddate) {
        this.saikeisanEnddate = saikeisanEnddate;
    }

    public String getHatEgEmpNo() {
        return hatEgEmpNo;
    }

    public void setHatEgEmpNo(String hatEgEmpNo) {
        this.hatEgEmpNo = hatEgEmpNo;
    }

    public String getHatEgEmpNm() {
        return hatEgEmpNm;
    }

    public void setHatEgEmpNm(String hatEgEmpNm) {
        this.hatEgEmpNm = hatEgEmpNm;
    }

    public String getHatlinkSpnetFlg() {
        return hatlinkSpnetFlg;
    }

    public void setHatlinkSpnetFlg(String hatlinkSpnetFlg) {
        this.hatlinkSpnetFlg = hatlinkSpnetFlg;
    }

    public String getHatlinkDateFlg() {
        return hatlinkDateFlg;
    }

    public void setHatlinkDateFlg(String hatlinkDateFlg) {
        this.hatlinkDateFlg = hatlinkDateFlg;
    }
    
    public String getAnkenRank() {
        return ankenRank;
    }

    public void setAnkenRank(String ankenRank) {
        this.ankenRank = ankenRank;
    }

    public String getPotentialFlg() {
        return potentialFlg;
    }

    public void setPotentialFlg(String potentialFlg) {
        this.potentialFlg = potentialFlg;
    }

    public String getMondaiFlg() {
        return mondaiFlg;
    }

    public void setMondaiFlg(String mondaiFlg) {
        this.mondaiFlg = mondaiFlg;
    }

    public String getMondaiComment() {
        return mondaiComment;
    }

    public void setMondaiComment(String mondaiComment) {
        this.mondaiComment = mondaiComment;
    }

    public String getSpKakuteiFlg() {
        return spKakuteiFlg;
    }

    public void setSpKakuteiFlg(String spKakuteiFlg) {
        this.spKakuteiFlg = spKakuteiFlg;
    }

    public String getNetKakuteiFlg() {
        return netKakuteiFlg;
    }

    public void setNetKakuteiFlg(String netKakuteiFlg) {
        this.netKakuteiFlg = netKakuteiFlg;
    }

    public Date getKaisyuEnd() {
        return kaisyuEnd;
    }

    public void setKaisyuEnd(Date kaisyuEnd) {
        this.kaisyuEnd = kaisyuEnd;
    }

    public Date getNoki() {
        return noki;
    }

    public void setNoki(Date noki) {
        this.noki = noki;
    }

    public String getKensyutuki() {
        return kensyutuki;
    }

    public void setKensyutuki(String kensyutuki) {
        this.kensyutuki = kensyutuki;
    }

    public String getaNo() {
        return aNo;
    }

    public void setaNo(String aNo) {
        this.aNo = aNo;
    }

    public String getKeiyakuKeitaiCd() {
        return keiyakuKeitaiCd;
    }

    public void setKeiyakuKeitaiCd(String keiyakuKeitaiCd) {
        this.keiyakuKeitaiCd = keiyakuKeitaiCd;
    }

    public BigInteger getAnkenSysId() {
        return ankenSysId;
    }

    public void setAnkenSysId(BigInteger ankenSysId) {
        this.ankenSysId = ankenSysId;
    }

    public String getHatEgBukaCd() {
        return hatEgBukaCd;
    }

    public void setHatEgBukaCd(String hatEgBukaCd) {
        this.hatEgBukaCd = hatEgBukaCd;
    }

    public String getHatEgBukaRnm() {
        return hatEgBukaRnm;
    }

    public void setHatEgBukaRnm(String hatEgBukaRnm) {
        this.hatEgBukaRnm = hatEgBukaRnm;
    }

    public String getSyuJobgrCd() {
        return syuJobgrCd;
    }

    public void setSyuJobgrCd(String syuJobgrCd) {
        this.syuJobgrCd = syuJobgrCd;
    }

    public String getSyuJobgrNm() {
        return syuJobgrNm;
    }

    public void setSyuJobgrNm(String syuJobgrNm) {
        this.syuJobgrNm = syuJobgrNm;
    }

    public String getSyuTantoId() {
        return syuTantoId;
    }

    public void setSyuTantoId(String syuTantoId) {
        this.syuTantoId = syuTantoId;
    }

    public String getSyuTantoNm() {
        return syuTantoNm;
    }

    public void setSyuTantoNm(String syuTantoNm) {
        this.syuTantoNm = syuTantoNm;
    }

    public String getEigJobgrCd() {
        return eigJobgrCd;
    }

    public void setEigJobgrCd(String eigJobgrCd) {
        this.eigJobgrCd = eigJobgrCd;
    }

    public String getEigJobgrNm() {
        return eigJobgrNm;
    }

    public void setEigJobgrNm(String eigJobgrNm) {
        this.eigJobgrNm = eigJobgrNm;
    }

    public String getEigTantoId() {
        return eigTantoId;
    }

    public void setEigTantoId(String eigTantoId) {
        this.eigTantoId = eigTantoId;
    }

    public String getEigTantoNm() {
        return eigTantoNm;
    }

    public void setEigTantoNm(String eigTantoNm) {
        this.eigTantoNm = eigTantoNm;
    }

    public String getSyukanJobgrCd() {
        return syukanJobgrCd;
    }

    public void setSyukanJobgrCd(String syukanJobgrCd) {
        this.syukanJobgrCd = syukanJobgrCd;
    }

    public String getSyukanJobgrNm() {
        return syukanJobgrNm;
    }

    public void setSyukanJobgrNm(String syukanJobgrNm) {
        this.syukanJobgrNm = syukanJobgrNm;
    }

    public String getSetuBunruiCd() {
        return setuBunruiCd;
    }

    public void setSetuBunruiCd(String setuBunruiCd) {
        this.setuBunruiCd = setuBunruiCd;
    }

    public BigInteger getJyuchuZanIsp() {
        return jyuchuZanIsp;
    }

    public void setJyuchuZanIsp(BigInteger jyuchuZanIsp) {
        this.jyuchuZanIsp = jyuchuZanIsp;
    }

    public BigInteger getJyuchuZanTenbai() {
        return jyuchuZanTenbai;
    }

    public void setJyuchuZanTenbai(BigInteger jyuchuZanTenbai) {
        this.jyuchuZanTenbai = jyuchuZanTenbai;
    }

    public String getBunkatsuFlg() {
        return bunkatsuFlg;
    }

    public void setBunkatsuFlg(String bunkatsuFlg) {
        this.bunkatsuFlg = bunkatsuFlg;
    }

    public String getUriageShijiFlg() {
        return uriageShijiFlg;
    }

    public void setUriageShijiFlg(String uriageShijiFlg) {
        this.uriageShijiFlg = uriageShijiFlg;
    }

    public String getUriSyusei() {
        return uriSyusei;
    }

    public void setUriSyusei(String uriSyusei) {
        this.uriSyusei = uriSyusei;
    }

    public String getMitKaitoFlg() {
        return mitKaitoFlg;
    }

    public void setMitKaitoFlg(String mitKaitoFlg) {
        this.mitKaitoFlg = mitKaitoFlg;
    }

    public String getMikomiFlg() {
        return mikomiFlg;
    }

    public void setMikomiFlg(String mikomiFlg) {
        this.mikomiFlg = mikomiFlg;
    }

    public String getChunyuTyokaFlg() {
        return chunyuTyokaFlg;
    }

    public void setChunyuTyokaFlg(String chunyuTyokaFlg) {
        this.chunyuTyokaFlg = chunyuTyokaFlg;
    }

    public String getKariSpFlg() {
        return kariSpFlg;
    }

    public void setKariSpFlg(String kariSpFlg) {
        this.kariSpFlg = kariSpFlg;
    }

    public String getKariNetFlg() {
        return kariNetFlg;
    }

    public void setKariNetFlg(String kariNetFlg) {
        this.kariNetFlg = kariNetFlg;
    }

    public String getChotatuKaitoFlg() {
        return chotatuKaitoFlg;
    }

    public void setChotatuKaitoFlg(String chotatuKaitoFlg) {
        this.chotatuKaitoFlg = chotatuKaitoFlg;
    }

    public String getIspDivisionNm() {
        return ispDivisionNm;
    }

    public void setIspDivisionNm(String ispDivisionNm) {
        this.ispDivisionNm = ispDivisionNm;
    }

    public String getIspRelateId() {
        return ispRelateId;
    }

    public void setIspRelateId(String ispRelateId) {
        this.ispRelateId = ispRelateId;
    }

    public int getZenkaiId() {
        return zenkaiId;
    }

    public void setZenkaiId(int zenkaiId) {
        this.zenkaiId = zenkaiId;
    }

    public Short getKaisyuKakuninFlg() {
        return kaisyuKakuninFlg;
    }

    public void setKaisyuKakuninFlg(Short kaisyuKakuninFlg) {
        this.kaisyuKakuninFlg = kaisyuKakuninFlg;
    }

    public BigInteger getUriageTov() {
        return uriageTov;
    }

    public void setUriageTov(BigInteger uriageTov) {
        this.uriageTov = uriageTov;
    }

    public String getKessaiStsNm() {
        return kessaiStsNm;
    }

    public void setKessaiStsNm(String kessaiStsNm) {
        this.kessaiStsNm = kessaiStsNm;
    }

    public String getKessaiId() {
        return kessaiId;
    }

    public void setKessaiId(String kessaiId) {
        this.kessaiId = kessaiId;
    }

    public String getSalesRouteNm() {
        return salesRouteNm;
    }

    public void setSalesRouteNm(String salesRouteNm) {
        this.salesRouteNm = salesRouteNm;
    }

    /**
     * @return the salesClassGenka
     */
    public String getSalesClassGenka() {
        return salesClassGenka;
    }

    /**
     * @param salesClassGenka the salesClassGenka to set
     */
    public void setSalesClassGenka(String salesClassGenka) {
        this.salesClassGenka = salesClassGenka;
    }

    public String getLossControlFlag() {
        return lossControlFlag;
    }

    public void setLossControlFlag(String lossControlFlag) {
        this.lossControlFlag = lossControlFlag;
    }

}
