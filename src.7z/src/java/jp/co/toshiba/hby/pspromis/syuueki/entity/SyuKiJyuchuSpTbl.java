package jp.co.toshiba.hby.pspromis.syuueki.entity;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/**
 *
 * @author ibayashi
 */
@Entity
@Table(name = "SYU_KI_JYUCHU_SP_TBL")
public class SyuKiJyuchuSpTbl implements Serializable {
    @Id
    @Column(name = "ANKEN_ID")
    private String ankenId;
    @Id
    @Column(name = "RIREKI_ID")
    private int rirekiId;
    @Id
    @Column(name = "DATA_KBN")
    private String dataKbn;
    @Id
    @Column(name = "CURRENCY_CODE")
    private String currencyCode;
    @Id
    @Column(name = "SYUEKI_YM")
    private String syuekiYm;
    @Column(name = "JYUCHU_RATE")
    private BigDecimal jyuchuRate;
    @Column(name = "JYUCHU_SP")
    private BigDecimal jyuchuSp;
    @Column(name = "JYUCHU_SP_ENKA")
    private Long jyuchuSpEnka;
    @Column(name = "CREATED_AT")
    @Temporal(TemporalType.TIMESTAMP)
    private Date createdAt;
    @Column(name = "CREATED_BY")
    private String createdBy;
    @Column(name = "UPDATED_AT")
    @Temporal(TemporalType.TIMESTAMP)
    private Date updatedAt;
    @Column(name = "UPDATED_BY")
    private String updatedBy;
    @Column(name = "UPDATED_BATCH_AT")
    @Temporal(TemporalType.TIMESTAMP)
    private Date updatedBatchAt;
    @Column(name = "UPDATED_BATCH_BY")
    private String updatedBatchBy;

    public SyuKiJyuchuSpTbl() {
    }

    public String getAnkenId() {
        return ankenId;
    }

    public void setAnkenId(String ankenId) {
        this.ankenId = ankenId;
    }

    public int getRirekiId() {
        return rirekiId;
    }

    public void setRirekiId(int rirekiId) {
        this.rirekiId = rirekiId;
    }

    public String getDataKbn() {
        return dataKbn;
    }

    public void setDataKbn(String dataKbn) {
        this.dataKbn = dataKbn;
    }

    public String getCurrencyCode() {
        return currencyCode;
    }

    public void setCurrencyCode(String currencyCode) {
        this.currencyCode = currencyCode;
    }

    public String getSyuekiYm() {
        return syuekiYm;
    }

    public void setSyuekiYm(String syuekiYm) {
        this.syuekiYm = syuekiYm;
    }

    public BigDecimal getJyuchuRate() {
        return jyuchuRate;
    }

    public void setJyuchuRate(BigDecimal jyuchuRate) {
        this.jyuchuRate = jyuchuRate;
    }

    public BigDecimal getJyuchuSp() {
        return jyuchuSp;
    }

    public void setJyuchuSp(BigDecimal jyuchuSp) {
        this.jyuchuSp = jyuchuSp;
    }

    public Long getJyuchuSpEnka() {
        return jyuchuSpEnka;
    }

    public void setJyuchuSpEnka(Long jyuchuSpEnka) {
        this.jyuchuSpEnka = jyuchuSpEnka;
    }

    public Date getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(Date createdAt) {
        this.createdAt = createdAt;
    }

    public String getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    public Date getUpdatedAt() {
        return updatedAt;
    }

    public void setUpdatedAt(Date updatedAt) {
        this.updatedAt = updatedAt;
    }

    public String getUpdatedBy() {
        return updatedBy;
    }

    public void setUpdatedBy(String updatedBy) {
        this.updatedBy = updatedBy;
    }

    public Date getUpdatedBatchAt() {
        return updatedBatchAt;
    }

    public void setUpdatedBatchAt(Date updatedBatchAt) {
        this.updatedBatchAt = updatedBatchAt;
    }

    public String getUpdatedBatchBy() {
        return updatedBatchBy;
    }

    public void setUpdatedBatchBy(String updatedBatchBy) {
        this.updatedBatchBy = updatedBatchBy;
    }
    
}
