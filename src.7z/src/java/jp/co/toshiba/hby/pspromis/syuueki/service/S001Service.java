package jp.co.toshiba.hby.pspromis.syuueki.service;

import java.io.PrintWriter;
import java.math.BigDecimal;
import java.sql.ResultSet;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import javax.ejb.Stateless;
import javax.inject.Inject;
import javax.interceptor.Interceptors;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import jp.co.toshiba.hby.pspromis.common.exception.PspRunTimeExceotion;
import jp.co.toshiba.hby.pspromis.common.util.StringUtil;
import jp.co.toshiba.hby.pspromis.syuueki.bean.S001Bean;
import jp.co.toshiba.hby.pspromis.syuueki.bean.S001MstBean;
import jp.co.toshiba.hby.pspromis.syuueki.entity.BuMst;
import jp.co.toshiba.hby.pspromis.syuueki.entity.JgrpMemberTbl;
import jp.co.toshiba.hby.pspromis.syuueki.entity.JgrpTbl;
import jp.co.toshiba.hby.pspromis.syuueki.entity.M0130BunruiOrg;
import jp.co.toshiba.hby.pspromis.syuueki.entity.OperationLog;
import jp.co.toshiba.hby.pspromis.syuueki.entity.PlantMst;
import jp.co.toshiba.hby.pspromis.syuueki.entity.StageMst;
import jp.co.toshiba.hby.pspromis.syuueki.entity.SyuGeBukkenInfoTblView;
import jp.co.toshiba.hby.pspromis.syuueki.dto.DivisionDto;
import jp.co.toshiba.hby.pspromis.syuueki.enums.Env;
import jp.co.toshiba.hby.pspromis.syuueki.enums.Label;
import jp.co.toshiba.hby.pspromis.syuueki.facade.BuMstFacade;
import jp.co.toshiba.hby.pspromis.syuueki.facade.JgrpMemberTblFacade;
import jp.co.toshiba.hby.pspromis.syuueki.facade.JgrpTblFacade;
import jp.co.toshiba.hby.pspromis.syuueki.facade.KanjyoMstFacade;
import jp.co.toshiba.hby.pspromis.syuueki.facade.M0130BunruiOrgFacade;
import jp.co.toshiba.hby.pspromis.syuueki.facade.PlantMstFacade;
import jp.co.toshiba.hby.pspromis.syuueki.facade.StageMstFacade;
import jp.co.toshiba.hby.pspromis.syuueki.facade.SysdateEntityFacade;
import jp.co.toshiba.hby.pspromis.syuueki.facade.SyuGeBukkenInfoTblViewFacade;
import jp.co.toshiba.hby.pspromis.syuueki.interceptor.TranceInterceptor;
import jp.co.toshiba.hby.pspromis.syuueki.jdbc.ResultSetManeger;
import jp.co.toshiba.hby.pspromis.common.jdbc.SqlExecutor;
import jp.co.toshiba.hby.pspromis.common.util.CollectionUtil;
import jp.co.toshiba.hby.pspromis.syuueki.dto.IppanBalanceMakerDto;
import jp.co.toshiba.hby.pspromis.syuueki.entity.EstContractTypeMst;
import jp.co.toshiba.hby.pspromis.syuueki.entity.SyuBatchLog;
import jp.co.toshiba.hby.pspromis.syuueki.entity.SyuGeBukkenInfoTbl;
import jp.co.toshiba.hby.pspromis.syuueki.entity.SyuGyotaiMst;
import jp.co.toshiba.hby.pspromis.syuueki.entity.TeamEntity;
import jp.co.toshiba.hby.pspromis.syuueki.entity.M0130LineEigJobgr;
import jp.co.toshiba.hby.pspromis.syuueki.facade.CategoryMapFacade;
import jp.co.toshiba.hby.pspromis.syuueki.facade.EstContractTypeMstFacade;
import jp.co.toshiba.hby.pspromis.syuueki.facade.SyuBatchLogFacade;
import jp.co.toshiba.hby.pspromis.syuueki.facade.SyuGeBukenInfoTblFacade;
import jp.co.toshiba.hby.pspromis.syuueki.facade.SyuGyotaiMstFacade;
import jp.co.toshiba.hby.pspromis.syuueki.facade.SyuKiJyuchuNetTblFacade;
import jp.co.toshiba.hby.pspromis.syuueki.facade.SyuKiJyuchuSpTblFacade;
import jp.co.toshiba.hby.pspromis.syuueki.facade.SyuKiNetCateTitleTblFacade;
import jp.co.toshiba.hby.pspromis.syuueki.facade.SyuKiNetCateTukiTblFacade;
import jp.co.toshiba.hby.pspromis.syuueki.facade.SyuKiSpCurTblFacade;
import jp.co.toshiba.hby.pspromis.syuueki.facade.SyuKiSpTukiITblFacade;
import jp.co.toshiba.hby.pspromis.syuueki.facade.SyuWfControlTblFacade;
import jp.co.toshiba.hby.pspromis.syuueki.facade.TeamMstFacade;
import jp.co.toshiba.hby.pspromis.syuueki.facade.M0130LineEigJobgrFacade;
import jp.co.toshiba.hby.pspromis.syuueki.pages.DivisonComponentPage;
//import jp.co.toshiba.hby.pspromis.syuueki.util.AuthorityCheck;
import jp.co.toshiba.hby.pspromis.syuueki.util.ConstantString;
import jp.co.toshiba.hby.pspromis.syuueki.util.LoginUserInfo;
import jp.co.toshiba.hby.pspromis.syuueki.util.SyuuekiUtils;
import jp.co.toshiba.hby.pspromis.syuueki.util.Utils;
import org.apache.commons.beanutils.BeanUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.ArrayUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
/**
 * PS-Promis収益管理システム
 * 案件検索 Service
 * @author (NPC)S.Ibayashi
 */
@Stateless
@Interceptors({TranceInterceptor.class})
public class S001Service {

    /**
     * ロガー
     */
    public static final Logger logger = LoggerFactory.getLogger(S001Service.class);

    @PersistenceContext(unitName = jp.co.toshiba.hby.pspromis.syuueki.util.ConstantString.syuuekiDataSourceName)
    private EntityManager em;

    /**
     * パラメータ格納クラスをinjection(CDI)<br>
     * InjectアノテーションよりAPサーバー(Glassfish)側で自動的にインスタンス作成(new)される。<br>
     */
    @Inject
    private S001Bean s001Bean;

    /**
     * マスタ情報格納クラスをinjection(CDI)<br>
     * InjectアノテーションよりAPサーバー(Glassfish)側で自動的にインスタンス作成(new)される。<br>
     */
    @Inject
    private S001MstBean s001MstBean;

    /**
     * Injection loginUserInfo
     * (ユーザー情報(ユーザーid,名称,所属部課名)を格納したオブジェクト)
     */
    @Inject
    private LoginUserInfo loginUserInfo;

    /**
     * Injection sqlExecutor
     */
    @Inject
    protected SqlExecutor sqlExecutor;

    /**
     * Injection SyuuekiUtils
     */
    @Inject
    private SyuuekiUtils syuuekiUtils;

    @Inject
    private Utils utils;

    @Inject
    private SyuGeBukkenInfoTblViewFacade syuGeBukkenInfoTblViewFacade;

    @Inject
    private BuMstFacade buMstFacade;

    @Inject
    private StageMstFacade stageMstFacade;
    
    @Inject
    private PlantMstFacade plantMstFacade;
    
    @Inject
    private M0130BunruiOrgFacade bunruiMstFacade;

    @Inject
    private SysdateEntityFacade sysdateFacade;

    @Inject
    private JgrpMemberTblFacade jgrpMemberTblFacade;

    @Inject
    private OperationLogService operationLogService;

    @Inject
    private KanjyoMstFacade kanjyoMstFacade;

    @Inject
    private JgrpTblFacade jgrpTblFacade;
    
    @Inject
    private SyuGyotaiMstFacade gyotaiMstFacade;

    @Inject
    private SyuWfControlTblFacade syuWfControlTblFacade;

    @Inject
    private SyuGeBukenInfoTblFacade syuGeBukenInfoTblFacade;

    @Inject
    private CategoryMapFacade categoryMapFacade;

    @Inject
    private SyuKiJyuchuSpTblFacade syuKiJyuchuSpTblFacade;

    @Inject
    private SyuKiJyuchuNetTblFacade syuKiJyuchuNetTblFacade;

    @Inject
    private SyuKiSpCurTblFacade syuKiSpCurTblFacade;

    @Inject
    private SyuKiSpTukiITblFacade syuKiSpTukiITblFacade;

    @Inject
    private SyuKiNetCateTitleTblFacade syuKiNetCateTitleTblFacade;

    @Inject
    private SyuKiNetCateTukiTblFacade syuKiNetCateTukiTblFacade;

    @Inject
    private StoredProceduresService storedProceduresService;

    @Inject
    private SyuuekiCommonService syuuekiCommonService;
    
    @Inject
    private TeamMstFacade teamMstFacade;

    @Inject
    private SyuBatchLogFacade syuBatchLogFacade;

    @Inject
    private EstContractTypeMstFacade estContractTypeMstFacade;
    
    @Inject
    private M0130LineEigJobgrFacade m0130LineEigJobgrFacade;

    @Inject
    private DivisonComponentPage divisionComponentPage;
    
    /**
     * 検索条件用Mapを作成
     * @return 
     */
    public Map<String, Object> getCondition() {
        //boolean isMyJobGr = false;
        List<String> memberJobGrList;

        // 受注年月(from to何れか)が入力されているか？
        int jyuchuInputFlg = 0;
        // 売上予定年月(from to何れか)が入力されているか？
        int uriageYoteiInputFlg = 0;
        int juInputFlg = 0;
        
        // 事業部コード:(原子力)であるかを判断
        boolean isNuclearDivision = divisionComponentPage.isNuclearDivision(s001Bean.getDivisionCode());

        Map<String, Object> condition = new LinkedHashMap<>();

        //// 検索条件をセット
        condition.put("tuid", loginUserInfo.getUserId());

        // My案件Flg(チェックボックス) 2014下追加
        condition.put("myAnkenFlg", s001Bean.getMyAnkenFlg());
        // My案件区分(JobGr or 個人) 2014下追加
        condition.put("myAnkenKbn", s001Bean.getMyAnkenKbn());

        /////// My案件JobGr 2014下追加
        if ("1".equals(s001Bean.getMyAnkenFlg())) {
            boolean isSearchMyJobGr = true;
            if ("K".equals(s001Bean.getMyAnkenKbn()) && StringUtil.isEmpty(s001Bean.getMyAnkenJobGr()) && StringUtil.isEmpty(s001Bean.getMyAnkenTanto())) {
                // [My案件検索 個人]を選択し、かつMy案件欄のJobGrと担当者の両方とも未選択の場合は、
                // ログイン者に参照権限のある物件のみを検索できるようにする。
                //   ※ややこしいが上記条件の参照方法はPS-PromisでのMy案件検索の共通ルールらしい。
                condition.put("myAnkenTuid", loginUserInfo.getUserId());
            } else {
    
                // My案件 JobGrが選択済の場合
                if (StringUtil.isNotEmpty(s001Bean.getMyAnkenJobGr())) {
                    memberJobGrList = new ArrayList();
                    memberJobGrList.add(s001Bean.getMyAnkenJobGr());
                    condition.put("memberJobGr", memberJobGrList);
                    
                    isSearchMyJobGr = false;
                }

                // My案件 担当者が選択済の場合
                if (StringUtil.isNotEmpty(s001Bean.getMyAnkenTanto())) {
                    condition.put("myAnkenTuid", s001Bean.getMyAnkenTanto());
                }
            }
            
            if (isSearchMyJobGr) {
                // My案件 JobGr,担当者何れも未指定の場合はログイン者所属JobGrが扱える案件のみを検索
                memberJobGrList = jgrpMemberTblFacade.getMemberJobGrList(loginUserInfo.getUserId());
                condition.put("memberJobGr", memberJobGrList);
            }
            
        }

        // 事業部
        //if (s001Bean.getDivisionCode() != null) {
        if (StringUtils.isNotEmpty(s001Bean.getDivisionCode())) {
            //condition.put("divisionCode", Arrays.asList(s001Bean.getDivisionCode()));
            condition.put("divisionCode", s001Bean.getDivisionCode());
        }

        // BU
        if (s001Bean.getSubBuId() != null) {
            condition.put("subBuId", Arrays.asList(s001Bean.getSubBuId()));
        }

        // 原価/バック営業JobGr(これは現在画面から指定されなくなったので無意味となった)
        condition.put("genkaJobgrCode", s001Bean.getGenkaJobgrCode());
        // 売上基準
        if (s001Bean.getSalesClass() != null) {
            condition.put("salesClass", Arrays.asList(s001Bean.getSalesClass()));
        }
        //20180302 原価回収基準対応　ADD START
        if (s001Bean.getSalesClassGenka() != null) {
            condition.put("salesClassGenka", s001Bean.getSalesClassGenka());
        }
        //20180302 原価回収基準対応　ADD END 
        
        // 売上開始月FROM Step2(2015上add)
        condition.put("uriageStartYmFrom", s001Bean.getUriageStartYmFrom());
        // 売上開始月TO Step2(2015上add)
        condition.put("uriageStartYmTo", s001Bean.getUriageStartYmTo());
   
        // 案件番号
        condition.put("ankenId", s001Bean.getAnkenId());
        // 注番
        condition.put("orderNo", s001Bean.getOrderNo());
        // 項番
        condition.put("koban", s001Bean.getKoban());
        // 見積番号
        condition.put("qno", s001Bean.getQno());
        // 案件名
        condition.put("ankenName", s001Bean.getAnkenName());
        // 注文主
        condition.put("tradeName", s001Bean.getTradeName());
        // 設置場所コード(SQL文では参照しなくなったが一応残しておく)
        condition.put("stchCode", s001Bean.getStchCode());
        // 設置場所名
        condition.put("stchName", s001Bean.getStchName());
        // ステージ
        // STEP3で改修
//        condition.put("stageId", s001Bean.getStageId());
        // 表示単位
        condition.put("dispKbn", s001Bean.getDispKbn());
        // 収益分類
        condition.put("bunruiCd", s001Bean.getBunruiCd());
        // 見積種類
        if (s001Bean.getMitumoriKbn() != null) {
            condition.put("mitumoriKbn", Arrays.asList(s001Bean.getMitumoriKbn()));
        }
        // サイト
        condition.put("site", s001Bean.getSite());
        // プラントコード
        condition.put("plantCode", s001Bean.getPlantCode());
        // 実施年度
        condition.put("jissiNendo", s001Bean.getJissiNendo());
        // 定件回数
        condition.put("teiken", s001Bean.getTeiken());
        // ISP区分
        if (s001Bean.getIspKbn() != null) {
            condition.put("ispKbn", Arrays.asList(s001Bean.getIspKbn()));
        }
        // 売上区分(未売上,売上中,完売)
        if (s001Bean.getUriageEndFlg() != null) {
            condition.put("uriageEndFlg", Arrays.asList(s001Bean.getUriageEndFlg()));
        }
        // 売上区分(当月完売 含む/含まない)
        if (s001Bean.getUriageTouKanbaiKbn() != null) {
            condition.put("uriageTouKanbaiKbn", s001Bean.getUriageTouKanbaiKbn());
        }
        
        
        ////////////////////////////////////////////////////////
        // STEP3改修 追加検索項目
        ////////////////////////////////////////////////////////
        // チームコード
        condition.put("myTeamFlg", s001Bean.getMyTeamFlg());
        // 検索条件でチームコードの所属チームが選択されており、
        // 且つプルダウンが選択されていない場合、全ての候補が選択条件となる
        if ("T".equals(s001Bean.getMyTeamFlg()) && StringUtils.isEmpty(s001Bean.getMyTeamCd())) {
            List<TeamEntity> teamMstList = s001MstBean.getTeamMstList();
            List<String> teamCdList = new ArrayList<>();
            for (TeamEntity rec : teamMstList) {
                teamCdList.add(rec.getTeamCd().trim());
            }
            condition.put("myTeamCd", teamCdList);
        } else {
            List<String> teamCdList = new ArrayList<>();
            if(StringUtils.isNotEmpty(s001Bean.getMyTeamCd())) {
                teamCdList.add(s001Bean.getMyTeamCd().trim());
            }else{
                teamCdList.add(s001Bean.getMyTeamCd());
            }
            condition.put("myTeamCd", teamCdList);
        }
        condition.put("ankenTeamCode", s001Bean.getTeamCode());
        condition.put("atsukaiCCode", s001Bean.getHanbaiCode());
        
        // データ種別
        condition.put("dataKbn", s001Bean.getDataKbn());
        // データ種別(対象月)
        // YYYYMM or 予算型 で保存されているため、スラッシュを取る
        if(StringUtils.isNotEmpty(s001Bean.getTaishoYm())) {
            condition.put("taishoYm", s001Bean.getTaishoYm().replace("/", ""));
        }
        // 履歴FLG(検索条件には存在しないが、SQLで利用している)
        condition.put("rirekiFlg", s001Bean.getRirekiFlg());
        // 受注年月
        // YYYYMM or 予算型 で保存されているため、スラッシュを取る
        if(StringUtils.isNotEmpty(s001Bean.getJuchuYmFrom())) {
            condition.put("juchuYmFrom", s001Bean.getJuchuYmFrom().replace("/", ""));
            jyuchuInputFlg = 1;
        }
        if(StringUtils.isNotEmpty(s001Bean.getJuchuYmTo())) {
            condition.put("juchuYmTo", s001Bean.getJuchuYmTo().replace("/", ""));
            jyuchuInputFlg = 1;
        }

        // 売上予定月
        // YYYYMM or 予算型 で保存されているため、スラッシュを取る
        if(StringUtils.isNotEmpty(s001Bean.getUriageYoteiYmFrom())) {
            condition.put("uriageYoteiYmFrom", s001Bean.getUriageYoteiYmFrom().replace("/", ""));
            uriageYoteiInputFlg = 1;
        }
        if(StringUtils.isNotEmpty(s001Bean.getUriageYoteiYmTo())) {
            condition.put("uriageYoteiYmTo", s001Bean.getUriageYoteiYmTo().replace("/", ""));
            uriageYoteiInputFlg = 1;
        }
        
        // 受注年月・売上予定年月(and or)
        if (StringUtils.isNotEmpty(s001Bean.getJuYmJoken())) {
            condition.put("juYmJoken", s001Bean.getJuYmJoken());
        }

        if (jyuchuInputFlg == 1 && uriageYoteiInputFlg == 1) {
            juInputFlg = 1;
        }
        condition.put("jyuchuInputFlg", jyuchuInputFlg);
        condition.put("uriageYoteiInputFlg", uriageYoteiInputFlg);
        condition.put("juInputFlg", juInputFlg);


        // 勘定年月
        condition.put("kanjyoYm", s001Bean.getKanjyoYm());

        ///////////////////////////////////////////////////////
        // 詳細検索
        ///////////////////////////////////////////////////////
        // 詳細検索フラグ
        // 白地調整案件だけはSQLの上部で判別
        condition.put("detailFlg", s001Bean.getDetailFlg());

        // 担当JobGr
        condition.put("eigyoTanJobgrCode", s001Bean.getEigyoTanJobgrCode());
        // 担当部門(組織)
        condition.put("tantoBumonCode", s001Bean.getTantoBumonCode());
        // 出荷日限
        condition.put("hatSyukkaNichigenFrom", s001Bean.getForwardTermYmFrom());
        condition.put("hatSyukkaNichigenTo", s001Bean.getForwardTermYmTo());
        // 回収予定
        condition.put("hatKaisyuYoteiFrom", s001Bean.getRecoveryYoteiYmFrom());
        condition.put("hatKaisyuYoteiTo", s001Bean.getRecoveryYoteiYmTo());
        // 売上区分(未売上,個別売,一括売)
        if (s001Bean.getSnHatsuban()!= null) {
            condition.put("snKbn", Arrays.asList(s001Bean.getSnHatsuban()));
        }
        // 甲乙区分
        if (s001Bean.getDiscrimination() != null) {
            condition.put("kouOtsuKbn", Arrays.asList(s001Bean.getDiscrimination()));
        }
        // 業態
        condition.put("gyotai", s001Bean.getGyotaiCd());
        // SP
        condition.put("spFrom", Utils.changeBigDecimal(s001Bean.getSpFrom()));
        condition.put("spTo", Utils.changeBigDecimal(s001Bean.getSpTo()));
        // NET
        condition.put("netFrom", Utils.changeBigDecimal(s001Bean.getNetFrom()));
        condition.put("netTo", Utils.changeBigDecimal(s001Bean.getNetTo()));
        // M率
        condition.put("mrituFrom", Utils.changeBigDecimal(s001Bean.getMrateFrom()));
        condition.put("mrituTo", Utils.changeBigDecimal(s001Bean.getMrateTo()));
        // 受注残
        condition.put("juchuZanFlg", s001Bean.getJuchuZan());
        // 白地調整案件
        condition.put("shirajiDelFlg", s001Bean.getShirajiDelFlg());
        // ステージ
        condition.put("stageId", s001Bean.getStageId());

        ///// STEP4(S) /////
        // 営業担当
        if (StringUtils.isNotEmpty(s001Bean.getEigyoJobGrId())) {
            List<String> eigCodeList = m0130LineEigJobgrFacade.findLineEigCodeList(s001Bean.getDivisionCode(), s001Bean.getEigyoJobGrId(), true);
            // 検索条件：営業担当は、事業部によりマッチさせる項目が異なる。そのため以下にその判断用パラメータを設定
            if (CollectionUtils.isNotEmpty(eigCodeList)) {
                //if (StringUtils.equals(s001Bean.getDivisionCode(), divNuclear)) {
                if (isNuclearDivision) {
                    // 事業部:(原子力)として営業担当を検索
                    condition.put("eigyoJobGrCodeList", eigCodeList);
                } else {
                    // 事業部:(原子力)以外として営業担当を検索(チームコード単位)
                    condition.put("eigyoTeamCodeList", eigCodeList);
                }
            }
        }

        boolean isKaishuTuki = false;
        // 回収月FROM
        if (StringUtils.isNotEmpty(s001Bean.getKaisyuYmFrom())) {
            condition.put("kaisyuYmFrom", s001Bean.getKaisyuYmFrom().replace("/", ""));
            isKaishuTuki = true;
        }
        // 回収月TO
        if (StringUtils.isNotEmpty(s001Bean.getKaisyuYmTo())) {
            condition.put("kaisyuYmTo", s001Bean.getKaisyuYmTo().replace("/", ""));
            isKaishuTuki = true;
        }
        if (isKaishuTuki) {
            condition.put("kaisyuYmFlg", "1");
        }

        // 売上指示状況
        if (s001Bean.getUriageShijiFlg() != null) {
            condition.put("uriageShijiFlg", s001Bean.getUriageShijiFlg());
        }
        // 売上修正対象
        if (StringUtils.isNotEmpty(s001Bean.getUriSyuseiFlg())) {
            condition.put("uriSyuseiFlg", s001Bean.getUriSyuseiFlg());
        }
        // 契約形態
        condition.put("keiyakuKeitaiCd", s001Bean.getKeiyakuKeitaiCd());
        // 案件状況(最新見積回答あり)
        condition.put("ankenJyokyoMitKaitoFlg", s001Bean.getAnkenJyokyoMitKaitoFlg());
        // 案件状況(最新調達回答あり)
        condition.put("ankenJyokyoSateiKaitoFlg", s001Bean.getAnkenJyokyoSateiKaitoFlg());
        // 案件状況(問題案件)
        condition.put("ankenJyokyoMondaiFlg", s001Bean.getAnkenJyokyoMondaiFlg());
        // 案件状況(ポテンシャル管理)
        condition.put("ankenJyokyoPotentialFlg", s001Bean.getAnkenJyokyoPotentialFlg());
        // 案件状況(見込未入力)
        condition.put("ankenJyokyoMikomiFlg", s001Bean.getAnkenJyokyoMikomiFlg());
        // 案件状況(仮売上あり)
        condition.put("ankenJyokyoKariUriFlg", s001Bean.getAnkenJyokyoKariUriFlg());

        // 見込金額　確定状況(SP未確定)
        if (StringUtils.isNotEmpty(s001Bean.getSpKakuteiFlg()) && StringUtils.isNotEmpty(s001Bean.getNetKakuteiFlg())) {
            condition.put("spNetKakuteiFlg", "0");
        } else {
            // 見込金額　確定状況(SP未確定)
            if (StringUtils.isNotEmpty(s001Bean.getSpKakuteiFlg())) {
                condition.put("spKakuteiFlg", "0");
            }
            // 見込金額　確定状況(NET未確定)
            if (StringUtils.isNotEmpty(s001Bean.getNetKakuteiFlg())) {
                condition.put("netKakuteiFlg", "0");
            }
        }

        // 収益管理対象
        logger.info("getCondition syuekiControlKbn=[{}]", s001Bean.getSyuekiControlKbn());
        if (StringUtils.isEmpty(s001Bean.getSyuekiControlKbn())) {
            logger.info("getCondition A set syuekiControlKbn=[1]");
            condition.put("syuekiControlKbn", "1");
        } else {
            if (!"ALL".equals(s001Bean.getSyuekiControlKbn())) {
                condition.put("syuekiControlKbn", s001Bean.getSyuekiControlKbn());
                logger.info("getCondition B set syuekiControlKbn=[1]");
            }
        }

        // 案件ランク
        if (s001Bean.getAnkenRank() != null) {
            condition.put("ankenRank", s001Bean.getAnkenRank());
        }
        // A/#
        condition.put("aNo", s001Bean.getANo());
        ///// STEP4(E) /////

        // ソート順(最優先)
        condition.put("sort1", s001Bean.getSort1());
        condition.put("sort1Kbn", s001Bean.getSort1Kbn());
 
        // ソート順(2番目)
        condition.put("sort2", s001Bean.getSort2());
        condition.put("sort2Kbn", s001Bean.getSort2Kbn());

        // BookMark検索(FLG)  Step2(2014下add)
        condition.put("bookMarkFlg", s001Bean.getBookMarkFlg());

        // 選択した案件ID
        // (出力：工事進行基準案件リスト or 一括ダウンロード の出力処理時、出力オプションダイアログ子画面から指定されてくる)
        if (s001Bean.getOptionTargetAnkenId() != null) {
            condition.put("targetAnkenId", Arrays.asList(s001Bean.getOptionTargetAnkenId()));
        }
        
        return condition;
    }

    /**
     * 検索条件初期化(画面初期表示時)
     */
    private void initCondition() throws Exception {
        // 売上予定日(From) 2014下add
        // ※現在の勘定月の期の最初の月(つまり4月か10月)をデフォルトセット
        initConditionRequired();
        
        // 事業部(案件検索で指定していた内容を引き継ぐ)
        if (StringUtils.isEmpty(s001Bean.getDivisionCode())) {
            s001Bean.setDivisionCode(loginUserInfo.getPriorityDivCode());
        }

        // 事業部コード:(原子力)
        boolean isNuclearDivision = divisionComponentPage.isNuclearDivision(s001Bean.getDivisionCode());
        
        // BU、SUBBU
        s001Bean.setBuId(null);
        s001Bean.setSubBuId(null);

        // 担当物件のみ(2014/10/20 ログイン者が企画/営業/原価(バック)の場合は全てをデフォルト)
        if (isSyokushuCheck()) {
            s001Bean.setTantoOnlyKbn("2");
            s001Bean.setShokushuFlg(1);
            s001Bean.setMyAnkenFlg("0");
        }else{
            s001Bean.setTantoOnlyKbn("0");
            s001Bean.setShokushuFlg(0);
            s001Bean.setMyAnkenFlg("1");
        }

        // 売上基準
        String[] salesClass = {"0", "1"};
        s001Bean.setSalesClass(salesClass);

        //20180302 原価回収基準対応　ADD START
        s001Bean.setSalesClassGenka("1");
        //20180302 原価回収基準対応　ADD END 
        
        // 現在の勘定期の年月配列を取得して、開始月(配列0番目)を条件のデフォルトとする。
        Date kanjoDate = Utils.parseDate(s001Bean.getKanjyoYm());
        String[] monthAry = syuuekiUtils.getKikanMonthAry(kanjoDate);

        // 売上予定月,受注年月
        //if (div.equals(s001Bean.getDivisionCode())) {
        if (isNuclearDivision) {
            // 事業部:(原子力)の場合(売上予定月のみ当月をデフォルト)
            s001Bean.setUriageYoteiYmFrom(syuuekiUtils.exeFormatYm(kanjoDate));
            s001Bean.setUriageYoteiYmTo(syuuekiUtils.exeFormatYm(kanjoDate));

        } else {
            // 事業部:(火水ジ)の場合(売上予定月,受注年月のデフォルトは当期開始月)
            s001Bean.setUriageYoteiYmFrom(syuuekiUtils.exeFormatYm(Utils.parseDate(monthAry[0])));
            s001Bean.setUriageYoteiYmTo(syuuekiUtils.exeFormatYm(Utils.parseDate(monthAry[5])));
            
            s001Bean.setJuchuYmFrom(syuuekiUtils.exeFormatYm(Utils.parseDate(monthAry[0])));
            s001Bean.setJuchuYmTo(syuuekiUtils.exeFormatYm(Utils.parseDate(monthAry[5])));
        }

        s001Bean.setDispKbn("1");

        // 見積種類
        String mitumoriKbn[] = new String[4];
        mitumoriKbn[0] = Env.getValue(Env.Mitumori_Yosan);
        mitumoriKbn[1] = Env.getValue(Env.Mitumori_Tehai);
        mitumoriKbn[2] = Env.getValue(Env.Mitumori_Sei);
        mitumoriKbn[3] = Env.getValue(Env.Mitumori_Seitehai);
        s001Bean.setMitumoriKbn(mitumoriKbn);

        // ISP区分(2014/10/20 デフォルトのISP区分は、ISPなし(0)に変更) →　Step2に全て選択をデフォルトに変更
        //String[] ispKbn = {"0", "1"};
        String[] ispKbn = {"0", "1", "2"};
        s001Bean.setIspKbn(ispKbn);
 
        // 売上区分 →　Step3に完売(2)もデフォルト選択するように変更
        String[] uriageEndFlg = {"0","1","2"};
        s001Bean.setUriageEndFlg(uriageEndFlg);

        // 売上区分(当月完売 含む/含まない)
        s001Bean.setUriageTouKanbaiKbn("1");

        // 収益管理対象(Step4)
        s001Bean.setSyuekiControlKbn("1");

        // ソート順1(2014下 案件番号→売上予定年月に変更)
        //s001Bean.setSort1("ankenCode");
        s001Bean.setSort1("uriageYoteiYm");
        s001Bean.setSort1Kbn("0");

        // ソート順2
        s001Bean.setSort2("orderNo");
        s001Bean.setSort2Kbn("0");

        // 編集フラグ
        s001Bean.setEditFlg("0");
        // 検索タイプ
        s001Bean.setListDispType("N");
        // 詳細検索
        s001Bean.setDetailFlg("0");
        // チームコード
        s001Bean.setMyTeamFlg("D");

        // My検索
        s001Bean.setMyAnkenKbn("J");
        // データ種別
        s001Bean.setDataKbn("O");

        // 詳細検索条件初期化
        // 詳細検索が有効でない時に検索された時も呼ばれるため別メソッド
        initDetailCondition();

        // S/N発
        String[] snHatsuban = {"S","N","X"};
        s001Bean.setSnHatsuban(snHatsuban);

        // 履歴ID
        s001Bean.setRirekiIdList("0");

        // 受注年月・売上予定年月(and/or)
        s001Bean.setJuYmJoken("or");
    }
    
    /**
     * 検索条件の初期化(画面食表示・パターン検索関わらず必ず行う処理)
     */
    private void initConditionRequired() {
        // 一覧検索FLG
        s001Bean.setListFlg("0");
        s001Bean.setConditionFlg("1");
        s001Bean.setCount(null);
        s001Bean.setPage(null);

        // 中計年度
        s001Bean.setChukeiNendo(this.getChukeiNendo());
        
        String kanjoYm = "";
        Date kanjoDate = null;
        try {
            kanjoYm = kanjyoMstFacade.getNowKanjoDate(ConstantString.salesClassI);   // Step3.一般案件用の勘定月を使用
            kanjoDate = Utils.parseDate(kanjoYm);
            s001Bean.setKanjyoYm(kanjoYm);

        } catch (Exception pe) {
            // 勘定年月が取得できない場合はエラー
            logger.error("error parse kanjo date [" + kanjoYm + "] program(S001)");

            String errorMessage = Label.getValue(Label.errorKanjoDate);
            kanjoYm = StringUtils.defaultString(kanjoYm);
            kanjoYm = StringUtils.replace(kanjoYm, "", " ");
            errorMessage = StringUtils.replace(errorMessage, "#kanjoDate#", kanjoYm);
            throw new PspRunTimeExceotion(errorMessage);
        }

        String[] monthAry = syuuekiUtils.getKikanMonthAry(kanjoDate);

        // 勘定月の翌月(Step4)   受注年月/売上予定年月の"翌月"ボタンで利用
        s001Bean.setNextKankyoYm(SyuuekiUtils.addMonth(kanjoYm, 1));

        if (monthAry != null) {
            // 勘定月の期初月(Step4)  受注年月/売上予定年月の"当期"ボタンで利用
            s001Bean.setStartKanjyoYm(monthAry[0]);

            // 勘定月の期末月(Step4)  受注年月/売上予定年月の"当期"ボタンで利用
            s001Bean.setEndKanjyoYm(monthAry[5]);
        }
    }

    /**
     * ログイン者のdivisionSubNameと検索条件指定のBUコードが等しいBU情報をデフォルトで選択状態にする
     * (検索条件:BUのデフォルト選択で利用)
     * @param buMstList buマスタ一覧(BU/SBU検索条件の候補となるリスト)
     */
    private void setInitLoginDefaultBuSelect(String[] divisionCodes, List<BuMst> buMstList) {
        String[] buArray = s001Bean.getBuId();
        String[] sbuArray = s001Bean.getSubBuId();

        for (String divisionCode: divisionCodes) {
            String[] defaultBuArray = getLoginDefaultBuSbuSelect(divisionCode, buMstList, 0);
            String[] defaultSbuArray = getLoginDefaultBuSbuSelect(divisionCode, buMstList, 1);
            
            buArray = ArrayUtils.addAll(defaultBuArray, buArray);
            sbuArray = ArrayUtils.addAll(defaultSbuArray, sbuArray);
        }

        s001Bean.setBuId(buArray);
        s001Bean.setSubBuId(sbuArray);
    }
    
    /**
     * ログイン者のdivisionSubNameと検索条件指定のBUコードが等しいBU情報をデフォルトで選択状態にする
     * (検索条件:BUのデフォルト選択で利用)
     * @param buMstList buマスタ一覧(BU/SBU検索条件の候補となるリスト)
     */
    private void setSearchAfterLoginDefaultBuSelect(List<BuMst> buMstList) {
        if (CollectionUtils.isEmpty(buMstList)) {
            return;
        }

        // 検索条件で選択している以外のBUを取得
        String[] targetDivisionCodes = loginUserInfo.getJobGrSyokusyuArrayInfo("division");
        List<String> oterDivisionCodeList = new ArrayList<>();
        for (String loginDivisionCode: targetDivisionCodes) {
            if (!loginDivisionCode.equals(s001Bean.getDivisionCode())) {
                oterDivisionCodeList.add(loginDivisionCode);
            }
        }
        
        targetDivisionCodes = (String[])oterDivisionCodeList.toArray(new String[0]);
        setInitLoginDefaultBuSelect(targetDivisionCodes, s001MstBean.getBuMstList());
    }

    /**
     * ログイン者のdivisionSubNameと検索条件指定のBUコードが等しいBU情報を配列で取得
     * @param buMstList buマスタ一覧(BU/SBU検索条件の候補となるリスト)
     * @kbn BU配列を取得するかSBU配列を取得するかを決定(0:BU配列 1:SBU配列)
     */
    private String[] getLoginDefaultBuSbuSelect(String divisionCode, List<BuMst> buMstList, int kbn) {
        String[] defaultBuSbuArray = syuuekiCommonService.getDefaultLoginSameBuArray(divisionCode, buMstList, kbn);
        logger.info("kbn=[{}], defaultBuSbuArray=[{}]", kbn, defaultBuSbuArray);
        return defaultBuSbuArray;
    }

    /**
     * 中計年度を取得
     * @return 
     */
    public String getChukeiNendo() {
        // 一般案件 受注残、進行基準案件 受注残
        Map<String, Object> condition = new HashMap<>();
        condition.put("result", "0");
        //condition.put("batchId", "SYU_JYUCHUZAN_UPDATE");
        condition.put("batchId", "SYU_CHUKEI_UPDATE"); //2017/05/15　修正
        
        SyuBatchLog batchLogEntityJyucyuZan = syuBatchLogFacade.getMaxEndDate(condition);
        return batchLogEntityJyucyuZan.getAttribute();
    }

    /**
     * 詳細検索条件初期化
     */
    public void initDetailCondition() {
        // S/N発(Step4で通常検索欄に移動したので、コメントアウト)
        //String[] snHatsuban = {"S","N","X"};
        //s001Bean.setSnHatsuban(snHatsuban);
        // 甲乙
        String[] discrimination = {"1","2"};
        s001Bean.setDiscrimination(discrimination);
        // 受注残
        s001Bean.setJuchuZan("0");
        // 案件ランク(Step4)
        String[] ankenRank = {"0", "1"};
        s001Bean.setAnkenRank(ankenRank);
    }

    /**
     * マスタデータを全て再取得
     */
    public void setMstDateAll() throws Exception {
        s001MstBean.setBuMstList(null);
        s001MstBean.setBunruiList(null);
        s001MstBean.setStageList(null);
        s001MstBean.setSiteList(null);
        s001MstBean.setMyJobGrList(null);
        s001MstBean.setMyJobGrMemberList(null);
        s001MstBean.setGyotaiList(null);
        s001MstBean.setTeamMstList(null);
        s001MstBean.setLineEigJobGrList(null);
        s001MstBean.setContraceTypeMstList(null);
        
        setDisplayData();
        
        taishoExecute();
    }

    /**
     * 画面表示を行うために必要なデータを取得する
     */
    private void setDisplayData() {
        // マスタデータを取得
        setMstDate();
        
        // My案件検索の利用有無を取得
        setDivisionMyAnkenFlg();
    }
    
    /**
     * マスタデータ取得
     */
    private void setMstDate() {
        // ログイン者の所属事業部コード(事業部兼務を考慮して配列で取得される)
        String[] loginDivisionCodes = loginUserInfo.getJobGrSyokusyuArrayInfo("division");
        
        // buマスタ
        if (s001MstBean.getBuMstList() == null) {
            // (電力ジ対応)
            // 事業部が増えることで、全てのBUを取得すると沢山とれてしまうことで、パフォーマンスやセキュリティに影響を与えたくないので、
            // ログイン者が所属している事業部のBU情報のみを取得するようにする
            //List<BuMst> buMstList = buMstFacade.findAll();
            Map<String, Object> buMstCondtion = new HashMap<>();
            buMstCondtion.put("divisionCode", loginDivisionCodes);
            List<BuMst> buMstList = buMstFacade.findConditionList(buMstCondtion);
            s001MstBean.setBuMstList(buMstList);
        }

        // 収益分類マスタ
        bunruiMstExecute();
        if (s001MstBean.getBunruiList() == null) {
            List<M0130BunruiOrg> bunruiList = bunruiMstFacade.getList(null);
            s001MstBean.setBunruiList(bunruiList);
        }
        

        // ステージマスタ
        if (s001MstBean.getStageList() == null) {
            List<StageMst> stageList = stageMstFacade.getList(null);
            s001MstBean.setStageList(stageList);
        }

        // サイトマスタ
        if (s001MstBean.getSiteList() == null) {
            List<PlantMst> siteList = plantMstFacade.getSiteList(null);
            s001MstBean.setSiteList(siteList);
        }

        // My案件検索・JobGr一覧(2014下追加)
        setMstMyJobGrList();
        //if (s001MstBean.getMyJobGrList() == null) {
        //    List<JgrpTbl> myJobGrList = jgrpTblFacade.findTuidJobGr(loginUserInfo.getUserId());
        //    s001MstBean.setMyJobGrList(myJobGrList);
        //}
        
        // My案件検索・JobGrメンバー一覧(2014下追加)
        setMstMyJobGrMemberList();
        
        // 業態マスタ
        if (s001MstBean.getGyotaiList() == null) {
            List<SyuGyotaiMst> gyotaiList = gyotaiMstFacade.getGyotaiList(null);
            s001MstBean.setGyotaiList(gyotaiList);
        }

        // チームコードマスタ
        if (s001MstBean.getTeamMstList() == null) {
            List<TeamEntity> teamMstList = teamMstFacade.findUserTeamList(loginUserInfo.getUserId());
            s001MstBean.setTeamMstList(teamMstList);
        }
        
        // 営業担当マスタ(Step4)
        if (s001MstBean.getLineEigJobGrList() == null) {
            Map<String, Object> lineEigCondition = new HashMap<>();
            lineEigCondition.put("divisionCode", loginDivisionCodes);

            List<M0130LineEigJobgr> lineEigJobGrList = m0130LineEigJobgrFacade.findLineEigNameList(lineEigCondition);
            s001MstBean.setLineEigJobGrList(lineEigJobGrList);
        }

        // 契約形態マスタ(Step4)
        if (s001MstBean.getContraceTypeMstList() == null) {
            List<EstContractTypeMst> contraceTypeMstList = estContractTypeMstFacade.selectContractTypeList(new HashMap<String, Object>());
            s001MstBean.setContraceTypeMstList(contraceTypeMstList);
        }
    }

    /**
     * My案件検索の利用有無を取得
     */
    private void setDivisionMyAnkenFlg() {
        Map<String, String> viewInfo = new HashMap<>();
        List<DivisionDto> divisionList = divisionComponentPage.getDivisionList();
        if (CollectionUtils.isNotEmpty(divisionList)) {
            for (DivisionDto dto: divisionList) {
                viewInfo.put(dto.getDivisionCode(), (syuuekiCommonService.isDivisionAnkenViewOk(dto.getDivisionCode()) ? "1" : "0"));
            }
        }

        s001Bean.setMyAnkenDivisionAuthFlgInfo(viewInfo);
    }
    
    /**
     * My案件検索・JobGr一覧を取得
     */
    private void setMstMyJobGrList() {
        // My案件検索・JobGr一覧(2014下追加)
        if (s001MstBean.getMyJobGrList() == null) {
            List<JgrpTbl> myJobGrList = jgrpTblFacade.findTuidJobGr(loginUserInfo.getUserId());
            s001MstBean.setMyJobGrList(myJobGrList);
        }
    }

    /**
     * My案件検索・JobGrメンバー一覧検索
     */
    private void setMstMyJobGrMemberList() {
        s001MstBean.setMyJobGrMemberList(null);
        
        List<JgrpMemberTbl> myJobGrMemberList;

        if (StringUtils.isNotEmpty(s001Bean.getMyAnkenJobGr())) {
            // プルダウンで選択したJobGrのメンバーを取得
            myJobGrMemberList = jgrpMemberTblFacade.getJobGrMemerInfoList(s001Bean.getMyAnkenJobGr());
        } else {
            // ログイン者が所属するJobGrの全メンバーを取得
            setMstMyJobGrList();
            List<JgrpTbl> myJobGrList = s001MstBean.getMyJobGrList();
            List<String> jobGrCodeList = new ArrayList<>();
            for (JgrpTbl en : myJobGrList) {
                jobGrCodeList.add(en.getJgrpId());
            }
            myJobGrMemberList = jgrpMemberTblFacade.getJobGrMemerInfoList(jobGrCodeList);
        }

        s001MstBean.setMyJobGrMemberList(myJobGrMemberList);
    }

    /**
     * 初期表示 ビジネスロジック
     */
    public void indexExecute() throws Exception {
        // 検索条件の各種候補のマスタデータ取得
        setDisplayData();

        // 検索条件の初期化
        initCondition();

        // ログイン者所属JobGrによるBU/SBU検索条件のデフォルト選択
        String[] loginDivisionCodes = loginUserInfo.getJobGrSyokusyuArrayInfo("division");
        setInitLoginDefaultBuSelect(loginDivisionCodes, s001MstBean.getBuMstList());
    }

    /**
     * 検索パターン選択からの表示 ビジネスロジック
     */
    public void patternIndexExecute() throws Exception {
        initConditionRequired();
    }

    /**
     * 収益分類絞り込み ビジネスロジック
     */
    public void bunruiMstExecute() {
        List<M0130BunruiOrg> bunruiList = new ArrayList<>();
        if (s001Bean.getSubBuId() != null) {
            Map<String, Object> condition = new HashMap<>();
            condition.put("buCd", s001Bean.getSubBuId());

            bunruiList = bunruiMstFacade.getList(condition);
        }
        s001MstBean.setBunruiList(bunruiList);
    }

    /**
     * JobGr所属メンバー絞り込み ビジネスロジック
     * @throws Exception 
     */
    public void jobGrMemberMstExecute() {
        setMstMyJobGrMemberList();
    }

    /**
     * 参照表示
     * @throws Exception
     */
    public void listExecute() throws Exception {
        // 編集フラグ
        s001Bean.setEditFlg("0");

        // 検索
        searchExecute();
    }

    /**
     * 編集表示
     * @throws Exception
     */
    public void editExecute() throws Exception {
        // 編集フラグ
        s001Bean.setEditFlg("1");

        // 検索
        searchExecute();
    }

    /**
     * 表示切替
     * @throws Exception
     */
    public void changeExecute() throws Exception {
        // 編集フラグ
        if("N".equals(s001Bean.getListDispType())){
            s001Bean.setListDispType("D");
        }else if("D".equals(s001Bean.getListDispType())){
            s001Bean.setListDispType("N");
        }

        // 参照表示
        listExecute();
    }

    /**
     * 一覧表示 ビジネスロジック
     * @throws Exception 
     */
    public void searchExecute() throws Exception {
        // ログイン者所属の職種をチェック
    //    if (!isSyokushuCheck()) {
   //         // 収益参照権限のない職種は件数0にして終了
   //         s001Bean.setCount(0);
   //         return;
   //     }

        long start;
        long end;
        
        if (isSyokushuCheck()) {
            s001Bean.setShokushuFlg(1);
        }else{
            s001Bean.setShokushuFlg(0);
        }
        
        // ページ切り替えか否かを判定
        boolean isPageing = true;
        if (s001Bean.getPage() == null || s001Bean.getPage() <= 0) {
            isPageing = false;
            s001Bean.setPage(1);
        }

        // 事業部が選択されていない場合
        if (s001Bean.getDivisionCode() == null) {
            // ログイン者の優先事業部を強制セット
            //String[] priorityDivCdAry = new String[]{loginUserInfo.getPriorityDivCode()};
            s001Bean.setDivisionCode(loginUserInfo.getPriorityDivCode());
        }

        // チームコードマスタ
        // 条件に使用することがあるためここで引き直す
        if (s001MstBean.getTeamMstList() == null) {
            start = System.currentTimeMillis();
            List<TeamEntity> teamMstList = teamMstFacade.findUserTeamList(loginUserInfo.getUserId());
            s001MstBean.setTeamMstList(teamMstList);
            end = System.currentTimeMillis();
            logger.info("find Login User TeamCode List [{}]msec", (end - start) + "msec");
        }

        // 検索条件をセット
        Map<String, Object> condition = this.getCondition();
        // [受注売上見込一覧]を検索する場合(検索条件:一覧表示タイプ=受注売上見込一覧)、前回値を取得するために前回値取得用の履歴idを条件に追加する。
        if ("D".equals(s001Bean.getListDispType())) {
            condition.put("listDispType", s001Bean.getListDispType());
            String oldRirekiId = this.getOldRirekiID(new HashMap<>(condition));
            if (StringUtils.isNotEmpty(oldRirekiId)) {
                condition.put("rirekiIdOld", Arrays.asList(oldRirekiId.split(",")));
                logger.info("[searchExecute] 前回値取得のため、条件追加 listDispType=[{}] rirekiIdOld=[{}]", condition.get("listDispType"), condition.get("rirekiIdOld"));
            }
        }
        
        // 一覧データの総件数を取得(ページ切り替え時は省略)
        Integer totalCount = s001Bean.getCount();
        SyuGeBukkenInfoTblView totalResultEntity = new SyuGeBukkenInfoTblView();
        
        if (!isPageing) {
            // 月次確定か予算だったら履歴IDを取得する
            if (!"R".equals(s001Bean.getRirekiFlg())) {
                s001Bean.setRirekiIdList("0");
            } else {
                s001Bean.setRirekiIdList(syuWfControlTblFacade.findRirekiId(condition));
            }
            condition.put("rirekiId", Arrays.asList(s001Bean.getRirekiIdList().split(",")));
            
            ////// 検索ボタン
            // 操作ログを出力(とりあえずの実装。マッピング確定したら修正予定)
            OperationLog operationLog = getOperationLogDto(condition);
            operationLogService.insertOperationLogSearch(operationLog);

            // データ総件数を取得
            condition.put("listFlg", "1");
            totalResultEntity = syuGeBukkenInfoTblViewFacade.getAnkenSum(condition);
            totalCount = totalResultEntity.getCount();
            
        } else {
            ////// ページング時
            condition.put("rirekiId", Arrays.asList(s001Bean.getRirekiIdList().split(",")));

            totalResultEntity.setSaisyuSp(s001Bean.getSumSp());
            totalResultEntity.setSaisyuNet(s001Bean.getSumNet());
        }
        
        // 一覧検索実行(データが存在する場合のみ実行)
        List<SyuGeBukkenInfoTblView> list = null;
        //SyuGeBukkenInfoTblView oldRec = null;
        if (totalCount != null && totalCount > 0) {
            condition.put("listFlg", "0");
            // 一覧データの検索
            list = syuGeBukkenInfoTblViewFacade.getAnkenList(condition, s001Bean.getPage());

            // 受注売上見込一覧(編集モード)の検索のみ以下の処理を実行
            if ("D".equals(s001Bean.getListDispType()) && "1".equals(s001Bean.getEditFlg())) {
                logger.info("受注売上見込一覧(編集モード)の権限設定");
                
                start = System.currentTimeMillis();
                list = CollectionUtil.createAndCopyList(SyuGeBukkenInfoTblView.class, list);
                end = System.currentTimeMillis();
                logger.info("Copy List Entity [{}}msec", (end - start) + "msec");
                
                // ログイン者の所属チームと案件チームコードを比較し、一致している場合に編集可能
                //List<TeamEntity> teamMstList = s001MstBean.getTeamMstList();
                boolean authEditFlg;

                s001Bean.setJpyOnlyFlg(true);
                start = System.currentTimeMillis();
                for (SyuGeBukkenInfoTblView entity : list) {
                    if (!(entity.getKeiyakuCurCode() == null || ConstantString.currencyCodeEn.equals(entity.getKeiyakuCurCode()))) {
                        s001Bean.setJpyOnlyFlg(false);
                    }
                    
                    authEditFlg = false;
                    // 案件の編集権限チェック
                    if("2".equals(entity.getIsDeleted()) || !"1".equals(entity.getSyuekiFlg())){ //白地削除案件 or 収益管理対象外(STEP4追加)ならば編集不可
                        entity.setAuthEditFlg("0");
                    } else if("1".equals(entity.getInputIchiranFlg())){
                        SyuGeBukkenInfoTbl geEntity = new SyuGeBukkenInfoTbl();
                        BeanUtils.copyProperties(geEntity, entity);
                        
                        // ログイン者が権限を保持している案件のみ編集可能(SPTE4で見方を変更)
                        //authEditFlg = loginUserInfo.isAnkenEdit(geEntity, teamMstList);
                        authEditFlg = syuuekiCommonService.isAnkenEditOk(geEntity);
                    }
                    entity.setAuthEditFlg(authEditFlg ? "1" : "0");
                }
                end = System.currentTimeMillis();
                logger.info("AuthCheck List Data [{}}msec", (end - start) + "msec");
            }
        }

        // 結果をbeanセット
        s001Bean.setCount(totalCount);
        s001Bean.setList(list);
        s001Bean.setSumSp(totalResultEntity.getSaisyuSp());
        s001Bean.setSumNet(totalResultEntity.getSaisyuNet());

        // 検索条件の各種候補のマスタデータ取得
        start = System.currentTimeMillis();
        setDisplayData();
        end = System.currentTimeMillis();
        logger.info("find Master Data [{}}msec", (end - start) + "msec");

        // (事業部を兼務している場合を考慮)
        // 検索条件で選択した事業部以外のBUデフォルト選択が外れてしまうため
        // 選択した事業部以外のBUデフォルト選択を元に戻す
        setSearchAfterLoginDefaultBuSelect(s001MstBean.getBuMstList());
        
        if(!"1".equals(s001Bean.getDetailFlg())) {
            // 詳細検索条件初期化
            start = System.currentTimeMillis();
            initDetailCondition();
            end = System.currentTimeMillis();
            logger.info("exec initDetailCondition [{}}msec", (end - start) + "msec");
        }
        if("Y".equals(s001Bean.getDataKbn())) {
            // 予算ベースの対象初期化
            start = System.currentTimeMillis();
            taishoExecute();
            end = System.currentTimeMillis();
            logger.info("exec taishoExecute [{}}msec", (end - start) + "msec");
        }
        // 円貨はデフォルト1(円)とする。
        if (this.s001Bean.getJpyUnit() == null) {
            this.s001Bean.setJpyUnit(1);
        }
        if (this.s001Bean.getJpyUnit() == 1000) {
            this.s001Bean.setJpyUnitKbn("2");
        } else if (this.s001Bean.getJpyUnit() == 1000000) {
            this.s001Bean.setJpyUnitKbn("3");
        } else {
            this.s001Bean.setJpyUnitKbn("1");
        }
    }
    
    /**
     * 予算期　前回取得判定
     * @param yosanki
     * @return 
     */
    public boolean isBeforeYosanBase(String yosanki) {
        if ("0".equals(StringUtils.substring(yosanki, 5, 6))) {
            // 決定回数が"0回目(例:2015K0,2015S0)"の場合は[最終見込 前回値]取得は行わない。
            return false;
        }
        return true;
    }
    
    /**
     * 前回分の履歴IDを取得する
     * @param condition
     * @return 
     * @throws java.lang.Exception 
     */
    public String getOldRirekiID(final Map<String, Object> condition) throws Exception {
        String concatRirekiId = "";
        String dataKbn = StringUtils.defaultString((String)condition.get("dataKbn"));
        String taishoYm = StringUtils.defaultString((String)condition.get("taishoYm"));

        if ("M".equals(dataKbn)) {
            // データ区分:月次確定 [最終見込 前回値]の履歴IDはSYU_WF_CONTROL_TBLの前月データを検索して取得。
            condition.put("taishoYm", SyuuekiUtils.addMonth(taishoYm, -1));
            concatRirekiId = syuWfControlTblFacade.findRirekiId(condition);

        } else if("Y".equals(dataKbn)) {
            // データ区分:予算 [最終見込 前回値]の履歴IDはSYU_WF_CONTROL_TBLの該当期の前回分を検索して取得。
            // ただし、決定回数が"0回目(例:2015K0,2015S0)"の場合は行わない。
            logger.info("Condition YosanKi=" + taishoYm);
            if (isBeforeYosanBase(taishoYm)) {
                logger.info("Before YosanKi=" + SyuuekiUtils.addYosanKi(taishoYm, -1));
                condition.put("taishoYm", SyuuekiUtils.addYosanKi(taishoYm, -1));
                concatRirekiId = syuWfControlTblFacade.findRirekiId(condition);
            }
        }
        
        // Step3改 データ区分:原案 の場合,履歴ID=1は正しいデータではないので、最新の前回確定の履歴(SYU_GE_BUKKEN_INFO_TBL.ZENKAI_IDで参照)する。
        // そのためここでは履歴IDは返さない(SQLでSYU_GE_BUKKEN_INFO_TBL.ZENKAI_IDを参照する)
//        } else {
//            // データ区分:原案  [最終見込 前回値]の履歴IDは1とする。
//            concatRirekiId = "1";
//
//        }

        return concatRirekiId;
    }

    /**
     * CSV出力
     * @param writer
     * @throws java.lang.Exception
     */
    public void csvExecute(PrintWriter writer) throws Exception {

        ResultSetManeger resultSetManeger = null;
        ResultSet rset = null;
        //EntityTransaction et = null;

        try {
            Object value;
            String strValue;
            BigDecimal keiyakuSpOrg = null;
            BigDecimal keiyakuSp = null;
            BigDecimal uriageNetOrg = null;
            BigDecimal uriageNet = null;
            BigDecimal arari = null;
            String mrate;
            String uriageEndFlg;

            SyuGeBukkenInfoTblView changeLabelEntity = new SyuGeBukkenInfoTblView();

            // 事業部コード(原子力)
            boolean isNuclearDivision = divisionComponentPage.isNuclearDivision(s001Bean.getDivisionCode());
            
            // 検索条件で指定した事業部コード
            //String targetDivCd = StringUtils.defaultString(s001Bean.getDivisionCode());
            
            // 事業部(原子力)の場合は出力項目数が多くなるので、その項目差分個数を定義
            int divPlusColCount = 0;
            //if (targetDivCd.equals(divGen)) {
            if (isNuclearDivision) {
                divPlusColCount = 6;
            }

            // CSV設定値を取得
            String sep = Env.getValue(Env.CsvSeparator);
            String lineBreak = Env.getValue(Env.CsvLineBreak);

            // 日時フォーマット
            SimpleDateFormat sdf1 = new SimpleDateFormat(syuuekiUtils.formatTimeStamp());

            // 検索条件をセット
            Map condition = getCondition();

            // 操作ログを出力
            OperationLog operationLog = getOperationLogDto(condition);
            operationLog.setOperationCode("DL_JOB");
            operationLog.setObjectId(10);
            operationLog.setRemarks("案件一覧CSV");
            operationLogService.insertOperationLogSearch(operationLog);

            condition.put("rirekiId", Arrays.asList(s001Bean.getRirekiIdList().split(",")));
            condition.put("kanrenOrderNoFlg", "1");

            // 一覧出力データを取得
            resultSetManeger = new ResultSetManeger(sqlExecutor);
            rset = resultSetManeger.getResultSet(em, "/sql/selectListSyuueki.sql", condition);
            
            ///// CSV作成 /////
            //////// 1行目(出力日、出力者) (S)
            writer.print(Label.getValue(Label.outputName) + sep);
            writer.print(loginUserInfo.getUserName() + sep);
            writer.print(Label.getValue(Label.outputDate) + sep);
            writer.print(sdf1.format(sysdateFacade.getSysdate()) + sep);
            for (int i=4; i<=(17 + divPlusColCount); i++) {
                writer.print(sep);
            }
            writer.print(Label.getValue(Label.unitLabel) + ":" + Label.getValue(Label.jpyUnit2));
            writer.print(lineBreak);
            //////// 1行目(S)


            //////// 2行目(合計行タイトル)
            for (int i = 0; i <= (18 + divPlusColCount); i++) {
                //if ((targetDivCd.equals(divGen) && i == 19) || (!targetDivCd.equals(divGen) && i == 15)) {
                if ((isNuclearDivision && i == 19) || (!isNuclearDivision && i == 15)) {
                    writer.print(Label.getValue(Label.last) + Label.getValue(Label.mikomi));
                }
                writer.print(sep);
            }
            writer.print(lineBreak);
            //////// 2行目(E)
            

            //////// 3行目(合計行データ)(S)
            for (int i = 0; i <= (18 + divPlusColCount); i++) {
                //if (((targetDivCd.equals(divGen) && i == 19) || (!targetDivCd.equals(divGen) && i == 15)) && s001Bean.getSumSp() != null) {
                if (((isNuclearDivision && i == 19) || (!isNuclearDivision && i == 15)) && s001Bean.getSumSp() != null) {
                    keiyakuSpOrg = new BigDecimal(s001Bean.getSumSp());
                    keiyakuSp = syuuekiUtils.changeUnit(keiyakuSpOrg, "2");
                    strValue = syuuekiUtils.exeFormatUnit(keiyakuSp);
                    writer.print(utils.stringCsv(strValue));
                }
                //if (((targetDivCd.equals(divGen) && i == 21) || (!targetDivCd.equals(divGen) && i == 16)) && s001Bean.getSumNet() != null) {
                if (((isNuclearDivision && i == 21) || (!isNuclearDivision && i == 16)) && s001Bean.getSumNet() != null) {
                    uriageNetOrg = new BigDecimal(s001Bean.getSumNet());
                    uriageNet = syuuekiUtils.changeUnit(uriageNetOrg, "2");
                    strValue = syuuekiUtils.exeFormatUnit(uriageNet);
                    writer.print(utils.stringCsv(strValue));
                }
                //if ((targetDivCd.equals(divGen) && i == 23) || (!targetDivCd.equals(divGen) && i == 17)) {
                if ((isNuclearDivision && i == 23) || (!isNuclearDivision && i == 17)) {
                    arari = syuuekiUtils.changeUnit(syuuekiUtils.arari(keiyakuSpOrg, uriageNetOrg), "2");
                    strValue = syuuekiUtils.exeFormatUnit(arari);
                    writer.print(utils.stringCsv(strValue));
                }
                //if ((targetDivCd.equals(divGen) && i == 24) || (!targetDivCd.equals(divGen) && i == 18)) {
                if ((isNuclearDivision && i == 24) || (!isNuclearDivision && i == 18)) {
                    mrate = syuuekiUtils.mrate(keiyakuSpOrg, uriageNetOrg);
                    writer.print(utils.stringCsv(mrate));
                }
                writer.print(sep);
            }
            writer.print(lineBreak);
            //////// 3行目(E)


            //////// 4行目(一覧タイトル) (S)
            writer.print(Label.getValue(Label.ankenCode) + sep);
            writer.print(Label.getValue(Label.oNo) + Label.getValue(Label.oNoRyaku) + sep);
            writer.print(Label.getValue(Label.kanrenOrderNo) + sep);
            writer.print(Label.renban.getLabel() + sep);        // Step4
            writer.print(Label.getValue(Label.mitsumoriNo) + Label.getValue(Label.mitsumoriNoRyaku) + sep);
            //if (targetDivCd.equals(divGen)) {
            if (isNuclearDivision) {
                writer.print(Label.mitumoriKbn.getLabel() + sep);   // Step4
            }
            writer.print(Label.getValue(Label.ankenName) + sep);
            writer.print(Label.getValue(Label.plantStchName) + sep);
            // Step4(S)
            writer.print(Label.plantCode.getLabel() + sep);
            // 下記項目は(原子力)データ検索の場合のみ出力
            //if (targetDivCd.equals(divGen)) {
            if (isNuclearDivision) {
                writer.print((Label.jisshiNendo.getLabel() + "/" + Label.kaisu.getLabel()) + sep);
                writer.print(Label.syuuekiBunrui.getLabel() + sep);
                writer.print(Label.ankenJyokyoMondai.getLabel() + sep);
            }

            writer.print((Label.anken.getLabel() + "/" + Label.rank.getLabel()) + sep);
            writer.print((Label.chunyu.getLabel() + Label.choka.getLabel()) + sep);
            // Step4(E)
            writer.print(Label.getValue(Label.subBu) + sep);
            writer.print(Label.getValue(Label.eigyoJobGroupId2) + sep);
            //writer.print(Label.getValue(Label.jisshiNendo) + "/" + Label.getValue(Label.kaisu) + sep);
            writer.print(Label.getValue(Label.uriageKijun) + sep);
            writer.print(Label.getValue(Label.uriageKbn) + sep);
            writer.print(Label.getValue(Label.uriageYoteiListLbl) + sep);
            writer.print(Label.getValue(Label.sp) + sep);
            //if (targetDivCd.equals(divGen)) {
            if (isNuclearDivision) {
                writer.print(sep);
            }
            writer.print(Label.getValue(Label.net) + sep);
            //if (targetDivCd.equals(divGen)) {
            if (isNuclearDivision) {
                writer.print(sep);
            }
            writer.print(Label.getValue(Label.arari) + sep);
            writer.print(Label.getValue(Label.mrate));
            writer.print(lineBreak);
            //////// 4行目(E)


            //////// 5行目以降(一覧データ)
            while(rset.next()) {
                // 案件番号
                value = resultSetManeger.getResultSetValue(rset, "ANKEN_ID");
                writer.print(utils.stringCsv(value) + sep);

                // 注番
                value = resultSetManeger.getResultSetValue(rset, "ORDER_NO");
                writer.print(utils.stringCsv(value) + sep);

                // 関連注番(Step2後半 CSVのみに項目追加) 取得はTSIS様作成パッケージを待ってSQLに組み込む
                value = resultSetManeger.getResultSetValue(rset, "KANREN_ORDER_NO");
                writer.print(utils.stringCsv(value) + sep);

                // 連番(Step4)
                value = resultSetManeger.getResultSetValue(rset, "KEIYAKU_RENBAN_MAX");
                writer.print(utils.stringCsv(value, 1) + sep);
                
                // 見積番号
                value = resultSetManeger.getResultSetValue(rset, "MITUMORI_NO");
                writer.print(utils.stringCsv(value) + sep);

                // 見積種類(Step4)
                //if (targetDivCd.equals(divGen)) {
                if (isNuclearDivision) {
                    changeLabelEntity.setMitumoriKbn(resultSetManeger.getResultSetValue(rset, "MITUMORI_KBN"));
                    value = changeLabelEntity.getMitumoriKbnRLabel();
                    writer.print(utils.stringCsv(value) + sep);
                }

                // 案件名称
                value = resultSetManeger.getResultSetValue(rset, "ANKEN_NAME");
                writer.print(utils.stringCsv(value) + sep);

                // プラント/設置場所名称(2014/10/20 設置先名称だけを出力するように修正)
                value = resultSetManeger.getResultSetValue(rset, "STCH_NAME");
                writer.print(utils.stringCsv(value) + sep);

                // プラントコード(Step4)
                value = resultSetManeger.getResultSetValue(rset, "PLANT_CODE");
                writer.print(utils.stringCsv(value) + sep);
                
                // 下記項目は(原子力)データ検索の場合のみ出力
                //if (targetDivCd.equals(divGen)) {
                if (isNuclearDivision) {
                    // 実施年度/回数(Step4)
                    value = syuuekiUtils.getJissiTeiken(resultSetManeger.getResultSetValue(rset, "JISSI_NENDO")
                            , resultSetManeger.getResultSetObjValue(rset, "TEIKEN"));
                    writer.print(utils.stringCsv(value) + sep);

                    // 収益分類(Step4)
                    value = resultSetManeger.getResultSetValue(rset, "BUNRUI_NM");
                    writer.print(utils.stringCsv(value) + sep);
                    
                    // 問題案件(Step4)
                    value = resultSetManeger.getResultSetValue(rset, "MONDAI_FLG");
                    if ("1".equals(value)) value = Label.mondai.getLabel();
                    else value = "";
                    writer.print(utils.stringCsv(value) + sep);
                }

                // 案件ランク(Step4)
                value = resultSetManeger.getResultSetValue(rset, "ANKEN_RANK");
                if ("1".equals(value)) value = Label.important.getLabel();
                else value = "";
                writer.print(utils.stringCsv(value) + sep);
                
                // 注入超過(Step4)
                value = resultSetManeger.getResultSetValue(rset, "CHUNYU_TYOKA_FLG");
                if ("1".equals(value)) value = Label.ari.getLabel();
                else value = "";
                writer.print(utils.stringCsv(value) + sep);

                // サブBU
                value = resultSetManeger.getResultSetValue(rset, "SUB_BU_NAME");
                writer.print(utils.stringCsv(value) + sep);

                // 営業JobGr
                value = resultSetManeger.getResultSetValue(rset, "EIGYO_TAN_JOBGP_NAME");
                writer.print(utils.stringCsv(value) + sep);

                // 実施年度/回数
//                value = syuuekiUtils.getJissiTeiken(resultSetManeger.getResultSetValue(rset, "JISSI_NENDO")
//                        , resultSetManeger.getResultSetObjValue(rset, "TEIKEN"));
//                writer.print(utils.stringCsv(value) + sep);

                // 売上基準
    //20180302 原価回収基準対応　REP START
//                value = syuuekiUtils.getSalesClassLabelFull(resultSetManeger.getResultSetValue(rset, "SALES_CLASS"));
                value = syuuekiUtils.getSalesClassLabelAddLoss(syuuekiUtils.getSalesClassLabelGenFull(resultSetManeger.getResultSetValue(rset, "SALES_CLASS"),resultSetManeger.getResultSetValue(rset, "SALES_CLASS_GENKA")), resultSetManeger.getResultSetValue(rset, "LOSS_CONTROL_FLAG"));
    //20180302 原価回収基準対応　REP START                        

                writer.print(utils.stringCsv(value) + sep);

                // 売上区分
                uriageEndFlg = StringUtils.defaultString(resultSetManeger.getResultSetValue(rset, "URIAGE_END_FLG"));
                value = syuuekiUtils.getUriageEndLabel(uriageEndFlg, 0);
                writer.print(utils.stringCsv(value) + sep);

                // 売上予定
                if ("2".equals(uriageEndFlg)) {
                    value = syuuekiUtils.exeFormatYm(rset.getDate("URIAGE_END_FIN"));
                } else {
                    value = syuuekiUtils.exeFormatYm(rset.getDate("URIAGE_END"));
                }
                writer.print(utils.stringCsv(value, 1) + sep);

                // SP
                strValue = resultSetManeger.getResultSetValue(rset, "SAISYU_SP");
                keiyakuSpOrg = null;
                keiyakuSp = null;
                if (StringUtil.isNotEmpty(strValue)) {
                    keiyakuSpOrg = new BigDecimal(strValue);
                    keiyakuSp = syuuekiUtils.changeUnit(keiyakuSpOrg, "2");
                    strValue = syuuekiUtils.exeFormatUnit(keiyakuSp);
                }
                writer.print(utils.stringCsv(strValue) + sep);

                // 下記項目は(原子力)データ検索の場合のみ出力
                //if (targetDivCd.equals(divGen)) {
                if (isNuclearDivision) {
                    // SP(確定) Step4
                    value = resultSetManeger.getResultSetValue(rset, "SP_KAKUTEI_FLG");
                    if ("1".equals(value)) value = Label.fixedLabel.getLabel();
                    else value = "";
                    writer.print(utils.stringCsv(value) + sep);
                }

                // NET
                strValue = resultSetManeger.getResultSetValue(rset, "SAISYU_NET");
                uriageNetOrg = null;
                uriageNet = null;
                if (StringUtil.isNotEmpty(strValue)) {
                    uriageNetOrg = new BigDecimal(strValue);
                    uriageNet = syuuekiUtils.changeUnit(uriageNetOrg, "2");
                    strValue = syuuekiUtils.exeFormatUnit(uriageNet);
                }
                writer.print(utils.stringCsv(strValue) + sep);

                // 下記項目は(原子力)データ検索の場合のみ出力
                //if (targetDivCd.equals(divGen)) {
                if (isNuclearDivision) {
                    // NET(確定) Step4
                    value = resultSetManeger.getResultSetValue(rset, "NET_KAKUTEI_FLG");
                    if ("1".equals(value)) value = Label.fixedLabel.getLabel();
                    else value = "";
                    writer.print(utils.stringCsv(value) + sep);
                }

                // 粗利
                strValue = null;
                arari = syuuekiUtils.arari(keiyakuSpOrg, uriageNetOrg);
                if (arari != null) {
                    arari = syuuekiUtils.changeUnit(arari, "2");
                    strValue = syuuekiUtils.exeFormatUnit(arari);
                }
                writer.print(utils.stringCsv(strValue) + sep);

                // M率
                mrate = syuuekiUtils.mrate(keiyakuSpOrg, uriageNetOrg);
                writer.print(utils.stringCsv(mrate) + sep);

                writer.print(lineBreak);
            }
            //////// 5行目以降(E)
 
        } catch (Exception e) {
            throw e;
        } finally {
            if (resultSetManeger != null) {
                resultSetManeger.close(rset);
            }
        }
    }

    /**
     * ログイン者職種チェック<br>
     * 営業(L),原価(M),企画(K)以外は検索できないようにする。
     * @return true:営業,原価,企画 false:左記以外の職種
     */
    private boolean isSyokushuCheck() {
        String divisionCode = s001Bean.getDivisionCode();
        boolean isCheck = false;
        if (syuuekiCommonService.isDivisionAnkenViewOk(divisionCode)) {
            isCheck = true;
        }
        return isCheck;
        //String[] syokusyuCdAry =  loginUserInfo.getJobGrSyokusyuArrayInfo("syokusyuCd");
        //return AuthorityCheck.isSyokushu(syokusyuCdAry);
    }

    /**
     * 操作ログ登録用dtoの取得
     */
    private OperationLog getOperationLogDto(Map<String, Object> condition) {
        OperationLog operationLog = operationLogService.getOperationLog();
        operationLog.setObjectType("ANKEN");

        // 操作ログに記録の必要がない情報をmapから削除。
        Map<String, Object> cloneCondtion = new LinkedHashMap<>(condition);
        cloneCondtion.remove("memberJobGr");
        cloneCondtion.remove("rirekiIdOld");
        cloneCondtion.remove("rirekiId");

        String stringConditon = syuuekiUtils.changeStringCondtion(cloneCondtion);
        operationLog.setRemarks(stringConditon);

        return operationLog;
    }
    
    /**
     * 一覧保存 ビジネスロジック
     * @throws java.lang.Exception
     */
    public void saveExecute() throws Exception {
        Map <String, Object> params;
        // カテゴリマスタ取得
        Map categoryMap = categoryMapFacade.findCategoryMap(ConstantString.ikkatsuCategoryCode);
        if (categoryMap == null) {
            throw new RuntimeException("SYU_N8_CATEGORY_MAPに一括見込NETのCATEGORY_CODE[" + ConstantString.ikkatsuCategoryCode + "]が設定されていません。");
        }

        // 操作ログへの備考欄の書き込み
        String concatAnkenId = "";
        for (int i = 0; i < s001Bean.getListAnkenId().length; i++) {
            if (!"1".equals(s001Bean.getListSaveFlg()[i])) {
                // 一覧で変更されていない案件は保存対象外。
                continue;
            }

            logger.debug("save date [AnkenId : " + s001Bean.getListAnkenId()[i] + "][RirekiId : " + s001Bean.getListRirekiId()[i] + "] saveExecute(S001)");
            concatAnkenId += "".equals(concatAnkenId) ? s001Bean.getListAnkenId()[i] : "," + s001Bean.getListAnkenId()[i];
            params = new HashMap<>();

            // 受注月・売上月・備考の保存
            params.put("ankenId", s001Bean.getListAnkenId()[i]);
            params.put("rirekiId", Integer.parseInt(s001Bean.getListRirekiId()[i]));
            params.put("uriageEnd", s001Bean.getListUriageEnd()[i]);
            params.put("jyuchuEnd", s001Bean.getListJyuchuEnd()[i]);
            params.put("bikou", s001Bean.getListBikou()[i]);
            syuGeBukenInfoTblFacade.updateEndMonth(params);

            // 受注SPの保存
            params.put("dataKbn", ConstantString.finalDataKbn);
            params.put("currencyCode", s001Bean.getListCurCode()[i]);
            params.put("syuekiYm", ConstantString.finalSyuekiYm);
            params.put("jyuchuRate", Utils.changeBigDecimal("1".equals(s001Bean.getListGaikaFlg()[i]) ? s001Bean.getListSaisyuJyuchuRate()[i] : "1"));
            params.put("jyuchuSp", Utils.changeBigDecimal("1".equals(s001Bean.getListGaikaFlg()[i]) ? s001Bean.getListSaisyuSpGaika()[i] : s001Bean.getListSaisyuSp()[i]));
            params.put("rateUpdateFlg", "1");
            syuKiJyuchuSpTblFacade.entryJyuchuSpRate(params);

            // 受注NETの保存
            params.put("categoryCode", ConstantString.ikkatsuCategoryCode);
            params.put("categoryKbn1", categoryMap.get("CATEGORY_KBN1"));
            params.put("categoryKbn2", categoryMap.get("CATEGORY_KBN2"));
            params.put("categoryName1", categoryMap.get("CATEGORY_NAME1"));
            params.put("categoryName2", categoryMap.get("CATEGORY_NAME2"));
            params.put("categorySeq", categoryMap.get("CATEGORY_SEQ"));
            params.put("jyuchuNet", Utils.changeBigDecimal(s001Bean.getListSaisyuNet()[i]));
            syuKiJyuchuNetTblFacade.entryJyuchuNet(params);

            // 売上SPの保存
            params.put("renban", ConstantString.finalRenban);
            params.put("renbanSeq", ConstantString.finalRenbanSeq);
            params.put("uriRate", Utils.changeBigDecimal("1".equals(s001Bean.getListGaikaFlg()[i]) ? s001Bean.getListSaisyuJyuchuRate()[i] : "1"));
            params.put("uriageAmount", Utils.changeBigDecimal("1".equals(s001Bean.getListGaikaFlg()[i]) ? s001Bean.getListSaisyuSpGaika()[i] : s001Bean.getListSaisyuSp()[i]));
            syuKiSpCurTblFacade.entrySyuKiSpCur(params);         // SYU_KI_SP_CUR_TBLの更新(新規登録) ※縦
            syuKiSpTukiITblFacade.entrySyuKiSpTukiITbl(params);  // SYU_KI_SP_TUKI_I_TBLの更新(新規登録) ※横

            // 売上NETの保存
            params.put("inputFlg", "1");
            params.put("net", Utils.changeBigDecimal(s001Bean.getListSaisyuNet()[i]));
            syuKiNetCateTitleTblFacade.entrySyuKiNetCateTitle(params);  // SYU_KI_NET_CATE_TITLE_TBLの更新(新規登録) ※縦
            syuKiNetCateTukiTblFacade.entrySyuKiNetCateTukiTbl(params); // SYU_KI_NET_CATE_TUKI_TBLの更新(新規登録) ※横

            // TODO 案分パッケージ呼出
            this.callIppanBalanceMaker(s001Bean.getListAnkenId()[i], s001Bean.getListRirekiId()[i]);

            // 再計算パッケージ呼出
            this.callAnken_I_Recal(s001Bean.getListAnkenId()[i], s001Bean.getListRirekiId()[i]);
        }

        // 操作ログ登録
        registOperationLog(concatAnkenId);
    }

    /**
     * 案分処理をcallする。
     */
    private void callIppanBalanceMaker(String ankenId, String rirekiId) throws Exception {
        IppanBalanceMakerDto dto = new IppanBalanceMakerDto();
        dto.setAnkenId(ankenId);
        dto.setRirekiId(rirekiId);
        dto.setSyoriFlg("1");   // 受注売上見込一覧保存用のパラメータを指定

        storedProceduresService.callIppanBalanceMaker(dto);
        
        if (!"0".equals(dto.getStatus())) {
            throw new Exception("案分パッケージ[SYU_P0_IPPAN_BALANCE_MAKE.anken_main]でエラーが発生しました。物件Key=" + ankenId + " 履歴ID=" + rirekiId + " 処理FLG=" + dto.getSyoriFlg());
        }
    }
    
    
    /**
     * 再計算処理をcallする(Step4見直し)。
     */
    private void callAnken_I_Recal(String ankenId, String rirekiId) throws Exception {
        storedProceduresService.callAnkenRecalAuto(ankenId, rirekiId, "0");
//        AnkenRecalIDto dto = new AnkenRecalIDto();
//        dto.setAnkenId(ankenId);
//        dto.setRirekiId(Integer.parseInt(rirekiId));
//
//        storedProceduresService.callAnken_I_Recal(dto);
//
//        if (!"0".equals(dto.getStatus())) {
//            throw new Exception("再計算処理[SYU_ANKEN_RECAL_I_MAIN.anken_main]でエラーが発生しました。物件Key=" + ankenId);
//        }
    }
    
    /**
     * 操作ログの登録
     * @param concatAnkenId
     * @throws Exception
     */
    public void registOperationLog(String concatAnkenId) throws Exception{
        OperationLog operationLog = this.operationLogService.getOperationLog();

        operationLog.setOperationCode("SAVE_ONLINE");
        operationLog.setObjectId(20);
        operationLog.setObjectType("ICHIRAN_I");
        //operationLog.setRemarks(trunc(concatAnkenId, 2000, "UTF-8"));
        operationLog.setRemarks(concatAnkenId);
        // TODO 要確認

        operationLogService.insertOperationLogSearch(operationLog);
    }

    /**
     * 予算ベースデータの勘定月一覧の選択候補絞り込み ビジネスロジック<br/>
     * 初期値では呼ばれない、初期で必要であれば画面からonload時に呼ばれる
     * @throws Exception 
     */
    public void taishoExecute() throws Exception {
        // 事業部(未指定の場合はログイン者が所属している事業部を指定)
        //if (s001Bean.getDivisionCode() == null) {
        if (StringUtils.isEmpty(s001Bean.getDivisionCode())) {
            //s001Bean.setDivisionCode(loginUserInfo.getJobGrSyokusyuArrayInfo("division"));
            s001Bean.setDivisionCode(loginUserInfo.getPriorityDivCode());
        }
        Map<String, Object> condition = getCondition();
        s001Bean.setTaishoList(syuWfControlTblFacade.findYosanTaisho(condition));
    }

    /**
     * ダウンロードオプション画面の期のデフォルトを設定
     */
    public void defaultDownloadOption() throws Exception {
        s001Bean.setOptionKiChangeFlg("1");

        // 年月or予算期(データ種別:月次確定or予算ベース)の場合、オプション画面デフォルトで指定する年と期を設定
        String baseYm = SyuuekiUtils.getChangeBaseYm(StringUtils.replace(s001Bean.getTaishoYm(), "/", ""));
        Date baseDate;
        String baseKi = "";
        if (StringUtils.isNotEmpty(baseYm)) {
            logger.info("[downloadOptionAction] taishoYm=[{}] baseYm=[{}]", s001Bean.getTaishoYm(), baseYm);
            baseDate = Utils.parseDate(baseYm);

        } else {
            // 年月or予算期が未指定の場合(原案)、当期をデフォルトとする。
            baseDate = Utils.parseDate(kanjyoMstFacade.getNowKanjoDate(ConstantString.salesClassI));
        }
        baseKi = SyuuekiUtils.dateToKikan(baseDate);
        baseKi = SyuuekiUtils.changeDecodeKikanLabel(baseKi);

        // 年月or予算期が指定されている場合、その期をデフォルト指定
        if (StringUtils.isNotEmpty(baseKi)) {
            String nendo = StringUtils.substring(baseKi, 0, 4);
            String ki = StringUtils.substring(baseKi, 4, 5);
            
            s001Bean.setTaishoY(nendo);
            s001Bean.setTaishoKi(ki);
            s001Bean.setOptionKiChangeFlg("0");
            logger.info("[downloadOptionAction] defaultNendo=[{}] defaultKi=[{}]", nendo, ki);
        }
    }

}
