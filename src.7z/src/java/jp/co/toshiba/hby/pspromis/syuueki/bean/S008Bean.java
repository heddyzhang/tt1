package jp.co.toshiba.hby.pspromis.syuueki.bean;

import java.util.List;
import javax.enterprise.context.RequestScoped;
import javax.inject.Named;
import jp.co.toshiba.hby.pspromis.syuueki.entity.BuMst;
import jp.co.toshiba.hby.pspromis.syuueki.entity.JgrpMemberTbl;
import jp.co.toshiba.hby.pspromis.syuueki.entity.JgrpTbl;
import jp.co.toshiba.hby.pspromis.syuueki.entity.M0130BunruiOrg;
import jp.co.toshiba.hby.pspromis.syuueki.entity.N7SetuBunruiMst;
import jp.co.toshiba.hby.pspromis.syuueki.entity.SyokusyuMstView;
import jp.co.toshiba.hby.pspromis.syuueki.entity.SyuGeBukkenInfoTbl;
import jp.co.toshiba.hby.pspromis.syuueki.entity.SyuGyotaiMst;
import jp.co.toshiba.hby.pspromis.syuueki.entity.SyuPatternMst;
import jp.co.toshiba.hby.pspromis.syuueki.entity.SyuTajigyobuMst;
import lombok.Getter;
import lombok.Setter;

/**
 *
 * @author sano
 */
@Named(value = "s008Bean")
@RequestScoped
@Getter
@Setter
public class S008Bean extends AbstractBean {

    /**
     * 処理元の画面ID(操作ログの登録で利用)
     */
    private String procId;

    /**
     * 注入パターンNO
     */
    private String chunyuPtnNo;
    /**
     * 注入開始年月
     */
    private String chunyuStartYm;
    /**
     * 【見込入力単位】案件
     */
    private String inputAnkenDisp;
    /**
     * 【見込入力単位】NET最終見込
     */
    private String inputSaNetFlg;
    /**
     * 【見込入力単位】NET期間損益
     */
    private String inputKiNetFlg;

    /**
     * 4半期入力FLG(1:あり 0:なし)
     */
    private String quarterDispFlg;

    /**
     * 累計表示フラグFLG(1:あり 0:なし)
     */
    private String maeruikeiDispFlg;

    /**
     * 注入パターンマスタ
     */
    private SyuGeBukkenInfoTbl syuGeBukkenInfoTbl;

    /**
     * 注入パターンマスタ
     */
    private List<SyuPatternMst> syuPatternMst;

    /**
     * 登録、編集、削除実行フラグ
     */
    private String registerFlg;

    /**
     * 受注通知実績登録件数
     */
    private Integer syuKiSpTukiSTblCount;

    /**
     * 期間損益TBL（原価）カテゴリ別－月別詳細の「注入パターン」以外、データ区分：Ｍ　の件数
     */
    private Integer syuKiNetCateTukiTblCount;

    /**
     * 編集FLG(0:参照モード 1:編集モード 2:編集モード(白地案件新規追加用))
     */
    private String editFlg = "0";

    /**
     * BUマスタ
     */
    private List<BuMst> buMstList;

    /**
     * 編集ボタン表示制御FLG(1:表示)
     */
    private String editBtnFlg;

    /**
     * 基本情報_編集FLG(1:編集可能)
     */
    private String baseEditFlg;

    /**
     * 進行基準情報_編集FLG(1:編集可能)
     */
    private String shinkoEditFlg;

    /**
     * 業態マスタ
     */
    private List<SyuGyotaiMst> gyotaiMstList;

    /**
     * 工事進行基準フラグ(一般：0、進行基準：1)
     */
    private String salesClass;

    /**
     * 白地調整案件の場合　1　案件から：0
     */
    private String shirajiFlg;

    /**
     * 事業部
     */
    private String divisionCode;

    /**
     * 案件名称
     */
    private String ankenName;

    /**
     * 注文主
     */
    private String tradeName;

    /**
     * 注文主コード
     */
    private String tradeCode;

    /**
     * 設置場所
     */
    private String stchName;

    /**
     * 設置場所コード
     */
    private String stchCode;

    /**
     * プラントコード
     */
    private String plantCode;

    /**
     * 取扱店コード
     */
    private String toriatsuCd;

    /**
     * サブBU
     */
    private String subBu;

    /**
     * 販売チーム
     */
    private String egTeamCd;

    /**
     * 販売C
     */
    private String hbCCd;

    /**
     * 販売S
     */
    private String hbSCd;

    /**
     * 販売E
     */
    private String hbECd;

    /**
     * 製造チーム
     */
    private String szTeamCd;

    /**
     * 製造C
     */
    private String szCCd;

    /**
     * 製造S
     */
    private String szSCd;

    /**
     * 製造E
     */
    private String szECd;

    /**
     * 営業担当ID
     */
    private String eigTantoId;

    /**
     * 営業担当
     */
    private String eigTantoNm;

    /**
     * 受注年月
     */
    private String hatJyuchuDateI;

    /**
     * 出荷日限
     */
    private String hatSyukkaNichigenI;

    /**
     * 売上予定
     */
    private String uriageEndI;

    /**
     * 売上予定(現状値)
     */
    private String uriageEndIDefault;

    /**
     * 回収予定
     */
    private String hatKaisyuYoteiI;

    /**
     * 甲乙区分
     */
    private String kouOtsuKbn;

    /**
     * 業態
     */
    private String gyotai;

    /**
     * 業態(参照時)
     */
    private String dispGyotai;

    /**
     * 最終更新者名(データ表示に利用)
     */
    private String updateByName;

    /**
     * 当年月(バリデーションチェックで使用)
     */
    private String nowYm;

    /**
     * 扱いチームコード
     */
    private String atsukaiTeamCode;

    /**
     * 扱いC
     */
    private String atsukaiCCode;

    /**
     * SP/NETフラグ
     */
    private String hatlinkSpnetFlg;

    /**
     * 売上予定フラグ
     */
    private String hatlinkDateFlg;

    /**
     * 案件Rev
     */
    private String ankenRev;

    /**
     * 案件ランク
     */
    private String ankenRank;

    /**
     * ポテンシャル管理
     */
    private String potentialFlg;

    /**
     * 問題案件
     */
    private String mondaiFlg;

    /**
     * 問題コメント
     */
    private String mondaiComment;

    /**
     * 2017/11/14 ADD #5 #12 #22 （収益）受注年月と（収益）売上予定を加える
     * （収益）受注年月
     */
    private String jyuchuEnd;

    /**
     * 2017/11/14 ADD #5 #12 #22 （収益）受注年月と（収益）売上予定を加える
     * （収益）売上予定
     */
    private String uriageEnd;

    /**
     * 回収月
     */
    private String kaisyuEnd;

    /**
     * 回収確認
     */
    private String kaisyuKakuninFlg;

    /**
     * 納期
     */
    private String noki;

    /**
     * 検収月
     */
    private String kensyutuki;

    /**
     * 契約形態名
     */
    private String keiyakuKeitaiName;

    /**
     * まとめ案件Flg(1:まとめ案件 0:子案件)
     */
    private String ankenFlg;
    
    private String mitumoriNo;

    private String jissiNendo;
    private String teiken;
    private String eigJobgrCd;
    private String eigJobgrNm;
    private String syuJobgrCd;
    private String syuJobgrNm;
    private String syuTantoId;
    private String syuTantoNm;
    private String ispDivisionNm;
    private String ispRelateId;
    private String ispKbn;
    private String bunruiCd;
    private String bunruiNm;
    private String setuBunruiCd;
    private String setuBunruiNm;
    private List<JgrpTbl> eigJobgrList;
    private List<JgrpTbl> syuJobgrList;
    private List<SyokusyuMstView> syokusyuMstList;
    //private List<JgrpMemberTbl> hatEgEmpNoList;
    private List<JgrpMemberTbl> eigTantoList;
    private List<JgrpMemberTbl> syuTantoIdList;
    private List<SyuTajigyobuMst> ispDivisionNmList;
    private List<M0130BunruiOrg> bunruiCdList;
    private List<N7SetuBunruiMst> setuBunruiCdList;
    private String syokusyuCd;
    private String spKakuteiFlg;
    private String netKakuteiFlg;

    // 2017/11/14 ADD #5 #12 #22 （収益）受注年月と（収益）売上予定を加える
    private String jyuchuEndEditFlg;
    private String uriageEndEditFlg;
    private String kaisyuEndEditFlg;
    private String nokiEditFlg;
    private String kensyutukiEditFlg;
    private String jyuchuSplitFlg;
    private String uriageSplitFlg;
    private String kaisyuSplitFlg;
    private String oldJyuchuEnd;
    private String oldUriageEnd;
    private String oldKaisyuEnd;
    
    // 処理対象案件の事業部が(原子力)タイプであるか?
    private boolean isNuclearDivision = false;
    
    /**
     * Creates a new instance of S001Bean
     */
    public S008Bean() {
    }

    public String getChunyuPtnNo() {
        return chunyuPtnNo;
    }

    public void setChunyuPtnNo(String chunyuPtnNo) {
        this.chunyuPtnNo = chunyuPtnNo;
    }

    public String getChunyuStartYm() {
        return chunyuStartYm;
    }

    public void setChunyuStartYm(String chunyuStartYm) {
        this.chunyuStartYm = chunyuStartYm;
    }

    public String getInputAnkenDisp() {
        return inputAnkenDisp;
    }

    public void setInputAnkenDisp(String inputAnkenDisp) {
        this.inputAnkenDisp = inputAnkenDisp;
    }

    public String getInputSaNetFlg() {
        return inputSaNetFlg;
    }

    public void setInputSaNetFlg(String inputSaNetFlg) {
        this.inputSaNetFlg = inputSaNetFlg;
    }

    public String getInputKiNetFlg() {
        return inputKiNetFlg;
    }

    public void setInputKiNetFlg(String inputKiNetFlg) {
        this.inputKiNetFlg = inputKiNetFlg;
    }

    public SyuGeBukkenInfoTbl getSyuGeBukkenInfoTbl() {
        return syuGeBukkenInfoTbl;
    }

    public void setSyuGeBukkenInfoTbl(SyuGeBukkenInfoTbl syuGeBukkenInfoTbl) {
        this.syuGeBukkenInfoTbl = syuGeBukkenInfoTbl;
    }

    public List<SyuPatternMst> getSyuPatternMstList() {
        return this.syuPatternMst;
    }

    public void setSyuPatternMstList(List<SyuPatternMst> syuPatternMst) {
        this.syuPatternMst = syuPatternMst;
    }

    public String getRegisterFlg() {
        return registerFlg;
    }

    public void setRegisterFlg(String registerFlg) {
        this.registerFlg = registerFlg;
    }

    public Integer getSyuKiSpTukiSTblCount() {
        return syuKiSpTukiSTblCount;
    }

    public void setSyuKiSpTukiSTblCount(Integer syuKiSpTukiSTblCount) {
        this.syuKiSpTukiSTblCount = syuKiSpTukiSTblCount;
    }

    public Integer getSyuKiNetCateTukiTblCount() {
        return syuKiNetCateTukiTblCount;
    }

    public void setSyuKiNetCateTukiTblCount(Integer syuKiNetCateTukiTblCount) {
        this.syuKiNetCateTukiTblCount = syuKiNetCateTukiTblCount;
    }

    public String getQuarterDispFlg() {
        return quarterDispFlg;
    }

    public void setQuarterDispFlg(String quarterDispFlg) {
        this.quarterDispFlg = quarterDispFlg;
    }

    /**
     * @return the maeruikeiDispFlg
     */
    public String getMaeruikeiDispFlg() {
        return maeruikeiDispFlg;
    }

    /**
     * @param maeruikeiDispFlg the maeruikeiDispFlg to set
     */
    public void setMaeruikeiDispFlg(String maeruikeiDispFlg) {
        this.maeruikeiDispFlg = maeruikeiDispFlg;
    }

    public String getEditFlg() {
        return editFlg;
    }

    public void setEditFlg(String editFlg) {
        this.editFlg = editFlg;
    }

    public List<BuMst> getBuMstList() {
        return buMstList;
    }

    public void setBuMstList(List<BuMst> buMstList) {
        this.buMstList = buMstList;
    }

    public String getEditBtnFlg() {
        return editBtnFlg;
    }

    public void setEditBtnFlg(String editBtnFlg) {
        this.editBtnFlg = editBtnFlg;
    }

    public String getBaseEditFlg() {
        return baseEditFlg;
    }

    public void setBaseEditFlg(String baseEditFlg) {
        this.baseEditFlg = baseEditFlg;
    }

    public String getShinkoEditFlg() {
        return shinkoEditFlg;
    }

    public void setShinkoEditFlg(String shinkoEditFlg) {
        this.shinkoEditFlg = shinkoEditFlg;
    }

    public List<SyuGyotaiMst> getGyotaiMstList() {
        return gyotaiMstList;
    }

    public void setGyotaiMstList(List<SyuGyotaiMst> gyotaiMstList) {
        this.gyotaiMstList = gyotaiMstList;
    }

    public String getSalesClass() {
        return salesClass;
    }

    public void setSalesClass(String salesClass) {
        this.salesClass = salesClass;
    }

    public String getShirajiFlg() {
        return shirajiFlg;
    }

    public void setShirajiFlg(String shirajiFlg) {
        this.shirajiFlg = shirajiFlg;
    }

    public String getDivisionCode() {
        return divisionCode;
    }

    public void setDivisionCode(String divisionCode) {
        this.divisionCode = divisionCode;
    }

    public String getAnkenName() {
        return ankenName;
    }

    public void setAnkenName(String ankenName) {
        this.ankenName = ankenName;
    }

    public String getTradeName() {
        return tradeName;
    }

    public void setTradeName(String tradeName) {
        this.tradeName = tradeName;
    }

    public String getTradeCode() {
        return tradeCode;
    }

    public void setTradeCode(String tradeCode) {
        this.tradeCode = tradeCode;
    }

    public String getStchName() {
        return stchName;
    }

    public void setStchName(String stchName) {
        this.stchName = stchName;
    }

    public String getStchCode() {
        return stchCode;
    }

    public void setStchCode(String stchCode) {
        this.stchCode = stchCode;
    }

    public String getPlantCode() {
        return plantCode;
    }

    public void setPlantCode(String plantCode) {
        this.plantCode = plantCode;
    }

    public String getToriatsuCd() {
        return toriatsuCd;
    }

    public void setToriatsuCd(String toriatsuCd) {
        this.toriatsuCd = toriatsuCd;
    }

    public String getSubBu() {
        return subBu;
    }

    public void setSubBu(String subBu) {
        this.subBu = subBu;
    }

    public String getEgTeamCd() {
        return egTeamCd;
    }

    public void setEgTeamCd(String egTeamCd) {
        this.egTeamCd = egTeamCd;
    }

    public String getHbCCd() {
        return hbCCd;
    }

    public void setHbCCd(String hbCCd) {
        this.hbCCd = hbCCd;
    }

    public String getHbSCd() {
        return hbSCd;
    }

    public void setHbSCd(String hbSCd) {
        this.hbSCd = hbSCd;
    }

    public String getHbECd() {
        return hbECd;
    }

    public void setHbECd(String hbECd) {
        this.hbECd = hbECd;
    }

    public String getSzTeamCd() {
        return szTeamCd;
    }

    public void setSzTeamCd(String szTeamCd) {
        this.szTeamCd = szTeamCd;
    }

    public String getSzCCd() {
        return szCCd;
    }

    public void setSzCCd(String szCCd) {
        this.szCCd = szCCd;
    }

    public String getSzSCd() {
        return szSCd;
    }

    public void setSzSCd(String szSCd) {
        this.szSCd = szSCd;
    }

    public String getSzECd() {
        return szECd;
    }

    public void setSzECd(String szECd) {
        this.szECd = szECd;
    }

    public String getHatJyuchuDateI() {
        return hatJyuchuDateI;
    }

    public void setHatJyuchuDateI(String hatJyuchuDateI) {
        this.hatJyuchuDateI = hatJyuchuDateI;
    }

    public String getHatSyukkaNichigenI() {
        return hatSyukkaNichigenI;
    }

    public void setHatSyukkaNichigenI(String hatSyukkaNichigenI) {
        this.hatSyukkaNichigenI = hatSyukkaNichigenI;
    }

    public String getUriageEndI() {
        return uriageEndI;
    }

    public void setUriageEndI(String uriageEndI) {
        this.uriageEndI = uriageEndI;
    }

    public String getHatKaisyuYoteiI() {
        return hatKaisyuYoteiI;
    }

    public void setHatKaisyuYoteiI(String hatKaisyuYoteiI) {
        this.hatKaisyuYoteiI = hatKaisyuYoteiI;
    }

    public String getKouOtsuKbn() {
        return kouOtsuKbn;
    }

    public void setKouOtsuKbn(String kouOtsuKbn) {
        this.kouOtsuKbn = kouOtsuKbn;
    }

    public String getGyotai() {
        return gyotai;
    }

    public void setGyotai(String gyotai) {
        this.gyotai = gyotai;
    }

    public String getDispGyotai() {
        return dispGyotai;
    }

    public void setDispGyotai(String dispGyotai) {
        this.dispGyotai = dispGyotai;
    }

    public String getNowYm() {
        return nowYm;
    }

    public void setNowYm(String nowYm) {
        this.nowYm = nowYm;
    }

    public String getProcId() {
        return procId;
    }

    public void setProcId(String procId) {
        this.procId = procId;
    }

    public String getUpdateByName() {
        return updateByName;
    }

    public void setUpdateByName(String updateByName) {
        this.updateByName = updateByName;
    }

//    public String getHatEgEmpNo() {
//        return hatEgEmpNo;
//    }
//
//    public void setHatEgEmpNo(String hatEgEmpNo) {
//        this.hatEgEmpNo = hatEgEmpNo;
//    }
//
//    public String getHatEgEmpNm() {
//        return hatEgEmpNm;
//    }
//
//    public void setHatEgEmpNm(String hatEgEmpNm) {
//        this.hatEgEmpNm = hatEgEmpNm;
//    }

    public String getAtsukaiTeamCode() {
        return atsukaiTeamCode;
    }

    public void setAtsukaiTeamCode(String atsukaiTeamCode) {
        this.atsukaiTeamCode = atsukaiTeamCode;
    }

    public String getAtsukaiCCode() {
        return atsukaiCCode;
    }

    public void setAtsukaiCCode(String atsukaiCCode) {
        this.atsukaiCCode = atsukaiCCode;
    }

    public String getHatlinkSpnetFlg() {
        return hatlinkSpnetFlg;
    }

    public void setHatlinkSpnetFlg(String hatlinkSpnetFlg) {
        this.hatlinkSpnetFlg = hatlinkSpnetFlg;
    }

    public String getHatlinkDateFlg() {
        return hatlinkDateFlg;
    }

    public void setHatlinkDateFlg(String hatlinkDateFlg) {
        this.hatlinkDateFlg = hatlinkDateFlg;
    }

    public String getAnkenRev() {
        return ankenRev;
    }

    public void setAnkenRev(String ankenRev) {
        this.ankenRev = ankenRev;
    }
    
    public int getDispSplitAlermFlg() {
        // 編集モード
        if (!"0".equals(editFlg)) {
            // (収益)受注予定年月 / (収益)売上予定年月 / (収益)回収予定年月 の何れかが分割されている場合、
            // 「分割見込は期間損益で編集してください」旨のメッセージを出力
            if (!"1".equals(uriageSplitFlg) || !"1".equals(jyuchuSplitFlg) || !"1".equals(kaisyuSplitFlg)) {
                return 1;
            }
        }
        return 0;
    }
}
