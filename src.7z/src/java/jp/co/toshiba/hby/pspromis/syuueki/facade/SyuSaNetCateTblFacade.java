package jp.co.toshiba.hby.pspromis.syuueki.facade;

import java.util.List;
import java.util.Map;
import javax.ejb.Stateless;
import javax.interceptor.Interceptors;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import jp.co.toshiba.hby.pspromis.common.util.BeanUtil;
import jp.co.toshiba.hby.pspromis.syuueki.entity.SyuSaNetCateTbl;
import jp.co.toshiba.hby.pspromis.syuueki.interceptor.TranceInterceptor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * 最終見込損益TBL(原価) カテゴリ別-詳細
 *
 * @author ganryu
 */
@Stateless
@Interceptors({TranceInterceptor.class})
public class SyuSaNetCateTblFacade extends AbstractFacade<SyuSaNetCateTbl> {
    private static final Logger logger = LoggerFactory.getLogger(SyuSaSonekiTitleTblFacade.class);

    @PersistenceContext(unitName = jp.co.toshiba.hby.pspromis.syuueki.util.ConstantString.syuuekiDataSourceName)
    private EntityManager em;

    @Override
    protected EntityManager getEntityManager() {
        return em;
    }

    public SyuSaNetCateTblFacade() {
        super(SyuSaNetCateTbl.class);
    }

    public void merge(SyuSaNetCateTbl facade) {
        this.em.merge(BeanUtil.createAndCopy(SyuSaNetCateTbl.class, facade));
    }

    /**
     * NET内訳更新
     *
     * @param entity
     */
    public void setNet(SyuSaNetCateTbl entity) {
        logger.info("SyuSaNetCateTblFacade#setNet");
        sqlExecutor.executeUpdateSql(em, "/sql/syuSaNetCateTbl/updateNet.sql", entity);
    }
    
    /**
     * コピー(複写)対象の通貨/レート/契約金額一覧を取得
     * @param _params
     * @return 
     */
    public List<SyuSaNetCateTbl> findCopyList(Map<String, Object> _params) {
        List<SyuSaNetCateTbl> list = sqlExecutor.getResultList(em, SyuSaNetCateTbl.class, "/sql/syuSaNetCateTbl/copyListSyuSaNetCateTbl.sql", _params);
        return list;
    }
    
    /**
     * カテゴリ区分の更新
     */
    public void updateCategory(Map<String, Object> condition){
        sqlExecutor.executeUpdateSql(em, "/sql/syuSaNetCateTbl/updateCategory.sql", condition);
    }
    
    /**
     * カテゴリの削除
     */
    public void deleteCategory(Map<String, Object> condition){
        sqlExecutor.executeUpdateSql(em, "/sql/syuSaNetCateTbl/deleteCategory.sql", condition);
    }
    
    /**
     * 対象カテゴリの各NET(アイテムで入力可能で積み上げ対象のNET)を削除
     */
    public void deleteMultiDataKbnCategory(Map<String, Object> condition){
        sqlExecutor.executeUpdateSql(em, "/sql/syuSaNetCateTbl/deleteMultiDataKbnCategory.sql", condition);
    }
}
