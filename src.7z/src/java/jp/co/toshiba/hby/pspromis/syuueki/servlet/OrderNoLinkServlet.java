/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package jp.co.toshiba.hby.pspromis.syuueki.servlet;


import javax.inject.Inject;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import jp.co.toshiba.hby.pspromis.syuueki.bean.OrderNoLinkBean;
import jp.co.toshiba.hby.pspromis.syuueki.service.OrderNoLinkService;
import jp.co.toshiba.hby.pspromis.syuueki.util.ParameterBinder;

/**
 *
 * 
 * @author watabe
 */
@WebServlet(name = "OrderNoLinkServlet", urlPatterns = {"/servlet/OrderNoLink","/servlet/OrderNoLink/*"})
public class OrderNoLinkServlet extends AbstractServlet {

    private static final String INDEX_JSP ="orderNoLink/orderNoLink.jsp" ;
    
    @Inject
    private OrderNoLinkBean orderNoLinkBean;
    
    @Inject
    private OrderNoLinkService orderNoLinkService;
    
    public String indexAction(HttpServletRequest req, HttpServletResponse resp)
    throws Exception {
        logger.info("OrderNoLink#indexAction");
        /* String a = req.getParameter("orderNo");String b = req.getParameter("rirekiId"); と同じことを行っている */
        //http://localhost.hby.toshiba.co.jp:18080/syuueki/OrderNoLinkServlet/?orderNo=N00001&rirekiId=0 の形式で出す
        ParameterBinder.Bind(orderNoLinkBean, req);

        //serviceの実行
        orderNoLinkService.getOrderNoList();
        return INDEX_JSP;
    }
}
