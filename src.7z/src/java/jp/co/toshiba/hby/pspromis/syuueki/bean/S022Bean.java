package jp.co.toshiba.hby.pspromis.syuueki.bean;

import java.util.List;
import java.util.Map;
import java.util.HashMap;
import javax.enterprise.context.RequestScoped;
import javax.inject.Named;
import lombok.Getter;
import lombok.Setter;

/**
 *
 * @author rnomura
 */
@Named(value = "s022Bean")
@RequestScoped
@Getter @Setter
public class S022Bean extends AbstractBean {
    
    /**
     * 一覧検索フラグ
     */
    private String listFlg = "0";
    
    /**
     * 一覧表示データ総件数
     */
    private Integer count;

    /**
     * 現在表示するページ番号
     */
    private Integer page;
    
    /**
     * リセットフラグ
     */
    private String resetFlg;
    
    /**
     * パターン検索用のパターンSEQ(パターン検索ボタンで利用)
     */
    private String searchPatternSeq;
    
    /**
     * 検索条件：予算確定リスト
     */
    private List<Map<String, Object>> yosanList;
    
    /**
     * 検索結果リスト
     */
    private List<Map<String, Object>> aggregateList;
    
    /**
     * ツリー展開FLG(0:デフォルト(通常の検索) 1:展開 2:非展開 10:全展開 20:全解除)
     */
    private String treeOpenCloseFlg = "0";
    
    /**
     * ツリー展開を実行した集計行の区分
     */
    private String treeOpenCloseTotalKbn;
    
    /**
     * ツリー展開を実行した集計行のkey情報
     */
    private String treeOpenCloseKey;
    
    /**
     * データ取得SQL用keyカウント 
     */
    private int keyCount;

    /**
     * 現在表示中のツリー展開ラベル
     */
    private String nowTreeLabel;

    /**
     * 総計行データの取得
     * @return 総計行データ
     */
    public Map<String, Object> getTotalData() {
        if (aggregateList != null && !aggregateList.isEmpty()) {
            // 総計行は必ず1行目にある
            return aggregateList.get(0);
        }
        return new HashMap<String, Object>();
    }
    
    public boolean getTreeDispFlg(String totalKbn) {
        int iTotalKbn = Integer.parseInt(totalKbn);
        if (iTotalKbn < keyCount) {
            return true;
        } else {
            return false;
        }
    }

    public String getTreeLabel(String totalKbn) {
        String treeLabel = "－";
        if ("2".equals(totalKbn)) {
            //if (keyCount == 3) {
                treeLabel = "＋";
            //}
        }
        return treeLabel;
    }

    public String getDisplayStyle(String totalKbn) {
        if ("3".equals(totalKbn)) {
            return "display:none";
        }
        return "";
    }

}
