package jp.co.toshiba.hby.pspromis.syuueki.service.download;

import java.math.BigDecimal;
import java.sql.ResultSet;
import java.util.ArrayList;
import jp.co.toshiba.hby.pspromis.syuueki.service.*;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.ejb.Stateless;
import javax.inject.Inject;
import javax.interceptor.Interceptors;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import jp.co.toshiba.hby.pspromis.syuueki.bean.AggregateConditionBean;
//import jp.co.toshiba.hby.pspromis.syuueki.bean.S023Bean;
//import jp.co.toshiba.hby.pspromis.syuueki.entity.OperationLog;
//import jp.co.toshiba.hby.pspromis.syuueki.entity.SyuGeBukkenInfoTbl;
//import jp.co.toshiba.hby.pspromis.syuueki.entity.SyuGeNetItemTblView;
import jp.co.toshiba.hby.pspromis.syuueki.enums.Label;
import jp.co.toshiba.hby.pspromis.syuueki.facade.SysdateEntityFacade;
//import jp.co.toshiba.hby.pspromis.syuueki.facade.SyuGeNetItemTblViewFacade;
import jp.co.toshiba.hby.pspromis.syuueki.interceptor.TranceInterceptor;
import jp.co.toshiba.hby.pspromis.syuueki.jdbc.ResultSetManeger;
import jp.co.toshiba.hby.pspromis.syuueki.pages.DetailHeader;
import jp.co.toshiba.hby.pspromis.syuueki.util.LoginUserInfo;
import jp.co.toshiba.hby.pspromis.syuueki.util.PoiUtil;
import jp.co.toshiba.hby.pspromis.syuueki.util.SyuuekiUtils;
import jp.co.toshiba.hby.pspromis.syuueki.util.Utils;
import org.apache.commons.lang3.StringUtils;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
/**
 * PS-Promis収益管理システム
 * 項番一覧（期間）Excelダウンロード Service
 * @author (NPC)Y.Kitajima
 */
@Stateless
@Interceptors({TranceInterceptor.class})
public class ShukeiAnkenListService {
    
    @PersistenceContext(unitName = jp.co.toshiba.hby.pspromis.syuueki.util.ConstantString.syuuekiDataSourceName)
    private EntityManager em;
    
    @Inject
    private LoginUserInfo loginUserInfo;
    
    //@Inject
    //private OperationLogService operationLogService;
    
    @Inject
    private SysdateEntityFacade sysdateFacade;
    
    //@Inject
    //private SyuGeNetItemTblViewFacade syuGeNetItemTblViewFacade;
    
    //@Inject
    //private S023Bean s023Bean;
    
    @Inject
    private AggregateConditionBean aggregateConditionBean;
    
    //@Inject
    //private DetailHeader dateilHeader;
    
    @Inject
    private S023Service s023Service;
    
    @Inject
    private SyuuekiUtils sUtils;

    
    /**
     * ロガー
     */
    public static final Logger logger = LoggerFactory.getLogger(ShukeiAnkenListService.class);
    
    /**
     * 操作ログの登録
     * @throws Exception
     */
//    public void registOperationLog() throws Exception{
//        OperationLog operationLog = this.operationLogService.getOperationLog();
//
//        operationLog.setOperationCode("DL_JOB");
//        operationLog.setObjectId(10);
//        operationLog.setObjectType("KOUBAN");
//        operationLog.setRemarks(s005Bean.getAnkenId());
//        //operationLogService.insertOperationLogSearch(operationLog);
//        
//        operationLogService.insertOperationLogSearch(operationLog);
//    }


    /**
     * Excelダウンロードのデータ埋め込み
     * @param workbook
     * @throws Exception
     */
    public void outputDownloadExcel(Workbook workbook) throws Exception {
        
        // シート取得
        Sheet sheet = workbook.getSheet("shukeiAnkenList");
        // スタイルコピー用シートを取得
        Sheet styleSheet = workbook.getSheet("shukeiList_style");
        
        // シート名の設定
        //final String sheetName = "集計案件リスト";
        //workbook.setSheetName(workbook.getSheetIndex(sheet), sheetName);
        
        //検索条件から各ラベルリストを作成する
        //s023Service.setResultSytlesetHeadData();
        
        // ヘッダ情報をセット
        setHeadData(sheet, styleSheet);
        
        // 一覧項目のセット
        Map<String, Object> totalInfo = setListData(sheet, styleSheet);
        
        if (totalInfo != null) {
            // ヘッダ部の合計値をセット
            setSumData(sheet, styleSheet, totalInfo);
        }

        // スタイルコピー用シートの削除
        //workbook.removeSheetAt(workbook.getSheetIndex(styleSheet));
        
        // 操作ログへの書き込み
        // (案件一覧の一括出力処理から出力した場合はここでのログ書き込みは行わない)
        //if (!s005Bean.isIsIkkatsuFlg()) {
        //    registOperationLog();
        //}
    }
    
    /**
     * ヘッダ情報のデータ埋め込み
     */
    private void setHeadData(Sheet sheet, Sheet styleSheet) throws Exception {
        int rowNum = 5;
        int headStart = 8;
        int comStart = headStart;
        int outputStart = headStart;
        
        Map<String, Integer> colspan = getColspan();
        // 「月」「期」表示部colspan
        Integer yokoSpan = colspan.get("month");
        // 「今回」「前回」表示部colspan
        Integer comSpan = colspan.get("com");
        // M率用のwidth
        int width = sheet.getColumnWidth(11);
        
        // 出力日時取得
        Date now = sysdateFacade.getSysdate();
        
        ////// ヘッダ情報セット
        //// ログイン者名
        PoiUtil.setCellValue(sheet, 0, 2, loginUserInfo.getUserName());
        //// 現在日時
        PoiUtil.setCellValue(sheet, 0, 4, now);
        
        // ヘッダー部円価単位のセット
        String unit = "";
        if(aggregateConditionBean.getJpyUnit().equals("3")){
            unit += Label.jpyUnit3.getLabel();
        } else if(aggregateConditionBean.getJpyUnit().equals("2")){
            unit += Label.jpyUnit2.getLabel();
        } else {
            unit += Label.jpyUnit1.getLabel();
        }
        PoiUtil.setCellValue(sheet, 0, 7, unit);
        
        // ヘッダー部対象データのセット
        PoiUtil.setCellValue(sheet, 2, 3, aggregateConditionBean.getHeadTargetData());

        // ヘッダー部出力項目のセット
        PoiUtil.setCellValue(sheet, 2, 8, aggregateConditionBean.getHeadOutputItems());
        
        // [回収は税込です]文言の出力
        PoiUtil.setCellValue(sheet, 8, 6, Label.kaisyuZeiKomi.getLabel());

        // 「月」「期」ラベル行
        Row yokozikuAggRow = PoiUtil.getRow(styleSheet, 3);
        List<Cell> yokozikuAggList = PoiUtil.getCellList(yokozikuAggRow, 3, yokoSpan);
        
        // 「今回」「前回」「差」ラベル行
        Row comLabelRow = PoiUtil.getRow(styleSheet, 5);
        List<Cell> comLabelList = PoiUtil.getCellList(comLabelRow, 3, comSpan);
        
        // 「受注」「売上」「回収」ラベル行
        Row outputLabelRow = PoiUtil.getRow(styleSheet, 7);
        
        // 「SP」「NET」「粗利」「M率」ラベル行
        Row headLabelRow = PoiUtil.getRow(styleSheet, 9);
         
 
        for(Map<String, Object> map : aggregateConditionBean.getYokozikuList()){
            // 「月」「期」ラベル行
            Row headMonthRow = PoiUtil.getRow(sheet, rowNum);
            PoiUtil.copyRowStyleValue(headMonthRow, yokozikuAggList, headStart, false, false);
            PoiUtil.setCellValue(sheet, rowNum, headStart, map.get("dispLabel"));
            PoiUtil.addMergedRegion(sheet, rowNum, headStart, rowNum, headStart + (yokoSpan-1));
            
            for(String comLabel: aggregateConditionBean.getComparisonLabelList()){
                // 「今回」「前回」ラベル行
                Row headComRow = PoiUtil.getRow(sheet, rowNum+1);
                PoiUtil.copyRowStyleValue(headComRow, comLabelList, comStart, false, false);
                PoiUtil.setCellValue(sheet, rowNum+1, comStart, comLabel);
                PoiUtil.addMergedRegion(sheet, rowNum+1, comStart, rowNum+1, comStart + (comSpan-1));
                
                for(String outLabel: aggregateConditionBean.getOutputLabelList()){
                    // 「受注」「売上」「回収」ラベル行
                    Row headOutRow = PoiUtil.getRow(sheet, rowNum+2);
                    Row headRow = PoiUtil.getRow(sheet, rowNum+4);
                    
                    List<Cell> outputLabelList;
                    List<Cell> headLabelList;
                    if(outLabel.equals(Label.kaisyu.getLabel())){
                        outputLabelList = PoiUtil.getCellList(outputLabelRow, 10, 1);
                        headLabelList = PoiUtil.getCellList(headLabelRow, 10, 1);
                    } else {
                        outputLabelList = PoiUtil.getCellList(outputLabelRow, 3, 4);
                        headLabelList = PoiUtil.getCellList(headLabelRow, 3, 4);
                    }
                    // ラベルセット
                    PoiUtil.copyRowStyleValue(headOutRow, outputLabelList, outputStart, false, false);
                    PoiUtil.setCellValue(sheet, rowNum+2, outputStart, outLabel);
                    PoiUtil.copyRowStyleValue(headRow, headLabelList, outputStart, true, false);
                    
                    if(outLabel.equals(Label.kaisyu.getLabel())){
                        outputStart += 1;
                    } else {
                        PoiUtil.addMergedRegion(sheet, rowNum+2, outputStart, rowNum+2, outputStart + 3);
                        sheet.setColumnWidth(outputStart + 3, width);
                        outputStart += 4;
                    }
                }
                
                comStart += comSpan;
            }
            
            headStart += yokoSpan;
        }

    }

    
    /**
     * 総計値のデータ埋め込み
     */
    private void setSumData(Sheet sheet, Sheet styleSheet, Map<String, Object> totalInfo) throws Exception {
        // 総計データ行
        int sumStartRow = 8;
        // 総計データスタートCol
        int startCol = 8;
        
        // 円価単位
        String jpyUnit = aggregateConditionBean.getJpyUnit();
        
        // 総合計データ
        Map<String, Object> result = totalInfo;
        // SQL実行
        //List<Map<String, Object>> list = s023Service.getAggregateData("1");
        //Map<String, Object> result = makeDataList(list.get(0));
        
        // 総計行
        Row sumRow = PoiUtil.getRow(sheet, sumStartRow);
        
        // 総計行スタイル
        Row sumStyleRow = PoiUtil.getRow(styleSheet, 1);
        
        int loopCount = 0;
        String comKey;
        String outputKey;
        // 横軸ラベルリストのループ(「月」「期」など)
        for(Map<String, Object> map : aggregateConditionBean.getYokozikuList()){
            // 比較データラベルリストのループ(「今回」「前回」「差」)
            for(String comLabel: aggregateConditionBean.getComparisonLabelList()){
                if(comLabel.equals(Label.now.getLabel())){
                    comKey = "NOW";
                } else if(comLabel.equals(Label.before.getLabel())){
                    comKey = "BEF";
                } else { 
                    comKey = "DIF";
                }
                comKey += String.valueOf(loopCount);
                
                for(String outputLabel: aggregateConditionBean.getOutputLabelList()){
                    if(outputLabel.equals(Label.jyuchu.getLabel())){
                        //outputKey = "J_";
                        outputKey = "SUM_J_";
                    } else if(outputLabel.equals(Label.uriage.getLabel())){
                        //outputKey = "U_";
                        outputKey = "SUM_U_";
                    } else {
                        //outputKey = "K_";
                        outputKey = "SUM_K_";
                    }
                    
                    List<Cell> styleList;
                    if(outputLabel.equals(Label.kaisyu.getLabel())){
                        styleList = PoiUtil.getCellList(sumStyleRow, 10, 1);
                    } else {
                        styleList = PoiUtil.getCellList(sumStyleRow, 3, 4);
                    }
                    // ラベルセット
                    PoiUtil.copyRowStyleValue(sumRow, styleList, startCol, false, false);
                    
                    
                    if(outputLabel.equals(Label.kaisyu.getLabel())){
                        PoiUtil.setCellValue(sheet, sumStartRow, startCol, result.get(outputKey + "SP_" + comKey));
                        startCol += 1;
                    } else {
                        PoiUtil.setCellValue(sheet, sumStartRow, startCol, sUtils.changeUnit(convBigDecimal(result.get(outputKey + "SP_" + comKey)), jpyUnit));
                        PoiUtil.setCellValue(sheet, sumStartRow, startCol+1, sUtils.changeUnit(convBigDecimal(result.get(outputKey + "NET_" + comKey)), jpyUnit));
                        PoiUtil.setCellValue(sheet, sumStartRow, startCol+2, sUtils.changeUnit(sUtils.arari(convBigDecimal(result.get(outputKey + "SP_" + comKey)), convBigDecimal(result.get(outputKey + "NET_" + comKey))), jpyUnit));
                        PoiUtil.setCellValue(sheet, sumStartRow, startCol+3, sUtils.mrate(convBigDecimal(result.get(outputKey + "SP_" + comKey)), convBigDecimal(result.get(outputKey + "NET_" + comKey))));
                        startCol += 4;
                    }
                }
            }
            
            loopCount++;
        }
            
    }
    
    /**
     * 一覧データの埋め込み
     * 戻り値は一行目(ここに総合計情報も含まれる)を返す
     */
    private Map<String, Object> setListData(Sheet sheet, Sheet styleSheet) throws Exception {
        
        // 一覧データ描画開始行
        int dataStartRow = 10;
        // 一覧データ描画開始列
        //int dataStartCol = 1;
        
        ResultSetManeger resultSetManeger = null;
        ResultSet rset = null;

        try {
            Map<String, Object> dataMap = new HashMap<>();
            resultSetManeger = new ResultSetManeger();
            Map<String, Object> condition = s023Service.getCondition();
            condition.put("sumFlg", "0");
            
            boolean isFirstData = true;
            Map<String, Object> totalInfo = null;
            rset = resultSetManeger.getResultSet(em, "/sql/syuGeBukkenInfoTbl/selectDetailAggregateList.sql", condition);
            while(rset.next()) {
                resultSetManeger.setResultMap(dataMap, rset);
                //logger.info("resultSetManeger map hash={} info={}", dataMap.hashCode(), dataMap);
                
                // 取得データをExcelにセット
                setExcelData(sheet, styleSheet, dataMap, dataStartRow);
                dataStartRow++;
                
                if (isFirstData) {
                    totalInfo = dataMap;
                    isFirstData = false;
                }
            }
            
            logger.info("dataCount = " + String.valueOf(dataStartRow - 10 - 1));
            return totalInfo;
            
        } catch (Exception e) {
            throw e;
        } finally {
            if (resultSetManeger != null) {
                resultSetManeger.close(rset);
            }
        }
    }
    
    /**
     * 取得データのセット
     */
    private void setExcelData(Sheet sheet, Sheet styleSheet, Map<String, Object> data, int startRow) throws Exception{
        // データ開始行
        int dataStartRow = startRow;
        // 総計データスタートCol
        int startCol = 1;
        
        // 円価単位
        String jpyUnit = aggregateConditionBean.getJpyUnit();
        
        // 対象データ
        Map<String, Object> result = makeDataList(data);
        
        // データ行
        Row dataRow = PoiUtil.getRow(sheet, dataStartRow, true);
        
        // データ行スタイル
        Row styleRow;
        List<Cell> styleList = new ArrayList<>();
        int loopCount = 0;
        String comKey = "";
        String outputKey = "";
        
        // 案件番号などのタイトル部スタイルセット
        Row titleRow = PoiUtil.getRow(styleSheet, 17);
        List<Cell> titleList = PoiUtil.getCellList(titleRow, 3, 7);
        PoiUtil.copyRowStyleValue(dataRow, titleList, startCol, false, false);
        
        String primaryKey = (String) result.get("KEY0_NAME");
        String secondaryKey = "";
        //if(aggregateConditionBean.getPrimaryUnit().equals("1") || aggregateConditionBean.getPrimaryUnit().equals("6")){
        //if(aggregateConditionBean.getPrimaryUnit().equals("0") || aggregateConditionBean.getPrimaryUnit().equals("2")){
        if(aggregateConditionBean.isPrimaryUnitBuka()){
            // 1次集計が営業課(0) or 主管課(2)の場合は部/課の2段階構成にする。
            if(StringUtils.isNotEmpty((CharSequence) result.get("KEY1_NAME"))){
                primaryKey += (String) result.get("KEY1_NAME");
            }
            secondaryKey = (String)result.get("KEY2_NAME");

        } else {
            // 1次集計が上記以外の場合は一段階構成
            if(StringUtils.isNotEmpty((CharSequence) result.get("KEY1_NAME"))){
                secondaryKey = (String) result.get("KEY1_NAME");
            }
        }

        // 1次集計キーセット
        PoiUtil.setCellValue(sheet, dataStartRow, startCol, primaryKey);
        startCol++;
        // 2次集計キーセット
        PoiUtil.setCellValue(sheet, dataStartRow, startCol, secondaryKey);
        startCol++;
        
        // 案件番号セット
        PoiUtil.setCellValue(sheet, dataStartRow, startCol, result.get("ANKEN_ID"));
        startCol++;
        // 注番セット
        PoiUtil.setCellValue(sheet, dataStartRow, startCol, result.get("ORDER_NO"));
        startCol++;
        // 案件名称セット
        PoiUtil.setCellValue(sheet, dataStartRow, startCol, result.get("ANKEN_NAME"));
        PoiUtil.addMergedRegion(sheet, dataStartRow, startCol, dataStartRow, startCol + 2);
        startCol += 3;
        
        // 横軸ラベルリストのループ(「月」「期」など)
        for(Map<String, Object> map : aggregateConditionBean.getYokozikuList()){
            // 比較データラベルリストのループ(「今回」「前回」「差」)
            for(String comLabel: aggregateConditionBean.getComparisonLabelList()){
                if(comLabel.equals(Label.now.getLabel())){
                    comKey = "NOW";
                    styleRow = PoiUtil.getRow(styleSheet, 15);
                } else if(comLabel.equals(Label.before.getLabel())){
                    comKey = "BEF";
                    styleRow = PoiUtil.getRow(styleSheet, 11);
                } else { 
                    comKey = "DIF";
                    styleRow = PoiUtil.getRow(styleSheet, 13);
                }
                comKey += String.valueOf(loopCount);
                
                for(String outputLabel: aggregateConditionBean.getOutputLabelList()){
                    if(outputLabel.equals(Label.jyuchu.getLabel())){
                        outputKey = "J_";
                    } else if(outputLabel.equals(Label.uriage.getLabel())){
                        outputKey = "U_";
                    } else {
                        outputKey = "K_";
                    }
                    
                    if(outputLabel.equals(Label.kaisyu.getLabel())){
                        styleList = PoiUtil.getCellList(styleRow, 10, 1);
                    } else {
                        styleList = PoiUtil.getCellList(styleRow, 3, 4);
                    }
                    // スタイルセット
                    PoiUtil.copyRowStyleValue(dataRow, styleList, startCol, false, false);
                    
                    
                    if(outputLabel.equals(Label.kaisyu.getLabel())){
                        PoiUtil.setCellValue(sheet, dataStartRow, startCol, sUtils.changeUnit(convBigDecimal(result.get(outputKey + "SP_" + comKey)), jpyUnit));
                        startCol += 1;
                    } else {
                        PoiUtil.setCellValue(sheet, dataStartRow, startCol, sUtils.changeUnit(convBigDecimal(result.get(outputKey + "SP_" + comKey)), jpyUnit));
                        PoiUtil.setCellValue(sheet, dataStartRow, startCol+1, sUtils.changeUnit(convBigDecimal(result.get(outputKey + "NET_" + comKey)), jpyUnit));
                        PoiUtil.setCellValue(sheet, dataStartRow, startCol+2, sUtils.changeUnit(sUtils.arari(convBigDecimal(result.get(outputKey + "SP_" + comKey)), convBigDecimal(result.get(outputKey + "NET_" + comKey))), jpyUnit));
                        PoiUtil.setCellValue(sheet, dataStartRow, startCol+3, sUtils.mrate(convBigDecimal(result.get(outputKey + "SP_" + comKey)), convBigDecimal(result.get(outputKey + "NET_" + comKey))));
                        startCol += 4;
                    }
                }
            }
            
            loopCount++;
        }
    }
    
    private Map<String, Integer> getColspan(){
        Map<String, Integer> colspan = new HashMap<>();
        
        Integer comCol = 0;
        Integer monthCol = 0;
        
        if(aggregateConditionBean.getOutputLabelList().contains(Label.jyuchu.getLabel())){
            comCol += 4;
        }
        if(aggregateConditionBean.getOutputLabelList().contains(Label.uriage.getLabel())){
            comCol += 4;
        }
        if(aggregateConditionBean.getOutputLabelList().contains(Label.kaisyu.getLabel())){
            comCol += 1;
        }
        
        if(aggregateConditionBean.getComparisonLabelList().contains(Label.before.getLabel())){
            monthCol = comCol * 3;
        } else {
            monthCol = comCol;
        }
        
        colspan.put("com", comCol);
        colspan.put("month", monthCol);
        
        return colspan;
    }
    
    /**
     * 「差」行用のデータリスト作成処理
     * @param map
     * @return 
     */
    private Map<String, Object> makeDataList(Map<String, Object> map){
        List<Map<String, Object>> list = new ArrayList<>();
        String jsKey = "J_SP_";
        String jnKey = "J_NET_";
        String usKey = "U_SP_";
        String unKey = "U_NET_";
        String ksKey = "K_SP_";
        
        int num = 0;
        for(Map<String, Object> yoko: aggregateConditionBean.getYokozikuList()){
            BigDecimal nowSpVal = (BigDecimal) map.get(jsKey + "NOW" + num);
            BigDecimal befSpVal = (BigDecimal) map.get(jsKey + "BEF" + num);
            BigDecimal difSpVal = sUtils.arari(nowSpVal, befSpVal);
            map.put(jsKey + "DIF" + num, difSpVal);
            
            nowSpVal = (BigDecimal) map.get(usKey + "NOW" + num);
            befSpVal = (BigDecimal) map.get(usKey + "BEF" + num);
            difSpVal = sUtils.arari(nowSpVal, befSpVal);
            map.put(usKey + "DIF" + num, difSpVal);
            
            nowSpVal = (BigDecimal) map.get(ksKey + "NOW" + num);
            befSpVal = (BigDecimal) map.get(ksKey + "BEF" + num);
            difSpVal = sUtils.arari(nowSpVal, befSpVal);
            map.put(ksKey + "DIF" + num, difSpVal);
            
            BigDecimal nowNetVal = (BigDecimal) map.get(jnKey + "NOW" + num);
            BigDecimal befNetVal = (BigDecimal) map.get(jnKey + "BEF" + num);
            BigDecimal difNetVal = sUtils.arari(nowNetVal, befNetVal);
            map.put(jnKey + "DIF" + num, difNetVal);
            
            nowNetVal = (BigDecimal) map.get(unKey + "NOW" + num);
            befNetVal = (BigDecimal) map.get(unKey + "BEF" + num);
            difNetVal = sUtils.arari(nowNetVal, befNetVal);
            map.put(unKey + "DIF" + num, difNetVal);
            
            num++;
        }
        
        return map;
    }
    
    
    /**
     * ObjectをBigDecimal型に変換
     * @param obj
     * @return
     * @throws Exception
     */
    private BigDecimal convBigDecimal(Object obj) throws Exception {
    
        return Utils.changeBigDecimal(Utils.getObjToStrValue(obj));
    
    }
    
    /**
     * ObjectをInteger型に変換
     * @param obj
     * @return
     * @throws Exception
     */
//    private Integer convInteger(Object obj) throws Exception {
//        
//        if (obj==null) {
//            return null;
//        }
//        return new Integer(obj.toString()).intValue();
//    }
//
}
