package jp.co.toshiba.hby.pspromis.syuueki.entity;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.Id;

/**
 *
 * @author rnomura
 */
@Entity
@Table(name = "SYU_GE_NET_ITEM_TBL")
public class SyuGeNetItemTbl implements Serializable {

    private static final long serialVersionUID = 1L;

    @Id
    @Column(name = "ANKEN_ID")
    private String ankenId;
    
    @Id
    @Column(name = "RIREKI_ID")
    private int rirekiId;
    
    @Id
    @Column(name = "ORDER_ITEM")
    private String orderItem;

    @Column(name = "ORDER_NO")
    private String orderNo;

    @Column(name = "SEIBAN")
    private String seiban;

    @Column(name = "HINMEI")
    private String hinmei;

    @Column(name = "SEIBAN_NOKI")
    @Temporal(TemporalType.DATE)
    private Date seibanNoki;

    @Column(name = "HAT_NET")
    private Long hatNet;

    @Column(name = "HAT_TANKA")
    private String hatTanka;

    @Column(name = "END_HAT_NET")
    private Long endHatNet;

    @Column(name = "END_HAT_NET_TANKA")
    private String endHatNetTanka;

    @Column(name = "CYUNYU_NET")
    private Long cyunyuNet;

    @Column(name = "URIAGE_NET")
    private Long uriageNet;

    @Column(name = "SEIBAN_SONEKI_NET")
    private Long seibanSonekiNet;

    @Column(name = "HAT_ZAN_NET")
    private Long hatZanNet;

    @Column(name = "FIXED_MIKOMI_NET")
    private Long fixedMikomiNet;

    @Column(name = "FIXED_MIKOMI_CURRENCY_CODE")
    private String fixedMikomiCurrecyCode;

    @Column(name = "FIXED_MIKOMI_RATE")
    private BigDecimal fixedMikomiRate;

    @Column(name = "FIXED_MIKOMI_NET_GAIKA")
    private BigDecimal fixedMikomiNetGaika;

    @Column(name = "HACHU_FLG")
    private String hachuFlg;

    @Column(name = "HACHU_CURRENCY_CODE")
    private String hachuCurrencyCode;

    @Column(name = "HACHU_RATE")
    private BigDecimal hachuRate;

    @Column(name = "HACHU_AMOUNT")
    private BigDecimal hachuAmount;

    @Column(name = "URIAGE_END_FLG")
    private String uriageEndFlg;

    @Column(name = "SEKKEI_SATEI_NET")
    private Long sekkeiSateiNet;

    @Column(name = "CHOTATU_SATEI_NET")
    private Long chotatuSateiNet;

    @Column(name = "KOJO_CD")
    private String kojoCd;

    @Column(name = "GI_BUKA_CD")
    private String giBukaCd;

    @Column(name = "GI_BUKA_NAME")
    private String giBukaName;

    @Column(name = "SEKKEI_BUKA_CD")
    private String sekkeiBukaCd;

    @Column(name = "SEKKEI_BUKA_NAME")
    private String sekkeiBukaName;

    @Column(name = "HAT_KBN")
    private String hatKbn;

    @Column(name = "MIKOMI_FLG")
    private String mikomiFlg;

    @Column(name = "NET_KAKUTEI_FLG")
    private String netKakuteiFlg;

    @Column(name = "KARI_NET_FLG")
    private String kariNetFlg;

    @Column(name = "KI_CATEGORY_CODE")
    private String kiCategoryCode;

    @Column(name = "SA_CATEGORY_CODE")
    private String saCategoryCode;

    @Column(name = "BIKOU")
    private String bikou;

    
    
    @Column(name = "SPURT_NO")
    private String spurtNo;

    @Column(name = "JOBGR_SEQ")
    private BigDecimal jobgrSeq;
    
    @Column(name = "REQ_SEQ")
    private BigDecimal reqSeq;

    @Column(name = "REQ_REV")
    private BigDecimal reqRev;
    
    @Column(name = "IRAI_KBN")
    private String iraiKbn;
    
    @Column(name = "BUNDLE_CODE")
    private String bundleCode;
    
    @Column(name = "QNO")
    private String qno;
    
    @Column(name = "KOUBAN_SEQ")
    private BigDecimal koubanSeq;
    
    @Column(name = "RENKEI_KEY")
    private String renkeiKey;

    @Column(name = "CREATED_AT")
    @Temporal(TemporalType.TIMESTAMP)
    private Date createdAt;

    @Column(name = "CREATED_BY")
    private String createdBy;

    @Column(name = "UPDATED_AT")
    @Temporal(TemporalType.TIMESTAMP)
    private Date updatedAt;

    @Column(name = "UPDATED_BY")
    private String updatedBy;

    @Column(name = "UPDATED_BATCH_AT")
    @Temporal(TemporalType.TIMESTAMP)
    private Date updatedBatchAt;

    @Column(name = "UPDATED_BATCH_BY")
    private String updatedBatchBy;

    public SyuGeNetItemTbl() {
    }

    public String getAnkenId() {
        return ankenId;
    }

    public void setAnkenId(String ankenId) {
        this.ankenId = ankenId;
    }

    public int getRirekiId() {
        return rirekiId;
    }

    public void setRirekiId(int rirekiId) {
        this.rirekiId = rirekiId;
    }

    public String getOrderItem() {
        return orderItem;
    }

    public void setOrderItem(String orderItem) {
        this.orderItem = orderItem;
    }

    public String getOrderNo() {
        return orderNo;
    }

    public void setOrderNo(String orderNo) {
        this.orderNo = orderNo;
    }

    public String getSeiban() {
        return seiban;
    }

    public void setSeiban(String seiban) {
        this.seiban = seiban;
    }

    public String getHinmei() {
        return hinmei;
    }

    public void setHinmei(String hinmei) {
        this.hinmei = hinmei;
    }

    public Date getSeibanNoki() {
        return seibanNoki;
    }

    public void setSeibanNoki(Date seibanNoki) {
        this.seibanNoki = seibanNoki;
    }

    public Long getHatNet() {
        return hatNet;
    }

    public void setHatNet(Long hatNet) {
        this.hatNet = hatNet;
    }

    public String getHatTanka() {
        return hatTanka;
    }

    public void setHatTanka(String hatTanka) {
        this.hatTanka = hatTanka;
    }

    public Long getEndHatNet() {
        return endHatNet;
    }

    public void setEndHatNet(Long endHatNet) {
        this.endHatNet = endHatNet;
    }

    public String getEndHatNetTanka() {
        return endHatNetTanka;
    }

    public void setEndHatNetTanka(String endHatNetTanka) {
        this.endHatNetTanka = endHatNetTanka;
    }

    public Long getCyunyuNet() {
        return cyunyuNet;
    }

    public void setCyunyuNet(Long cyunyuNet) {
        this.cyunyuNet = cyunyuNet;
    }

    public Long getUriageNet() {
        return uriageNet;
    }

    public void setUriageNet(Long uriageNet) {
        this.uriageNet = uriageNet;
    }

    public Long getSeibanSonekiNet() {
        return seibanSonekiNet;
    }

    public void setSeibanSonekiNet(Long seibanSonekiNet) {
        this.seibanSonekiNet = seibanSonekiNet;
    }

    public Long getHatZanNet() {
        return hatZanNet;
    }

    public void setHatZanNet(Long hatZanNet) {
        this.hatZanNet = hatZanNet;
    }

    public Long getFixedMikomiNet() {
        return fixedMikomiNet;
    }

    public void setFixedMikomiNet(Long fixedMikomiNet) {
        this.fixedMikomiNet = fixedMikomiNet;
    }

    public String getFixedMikomiNetCurrecyCode() {
        return fixedMikomiCurrecyCode;
    }

    public void setFixedMikomiCurrecyCode(String fixedMikomiCurrecyCode) {
        this.fixedMikomiCurrecyCode = fixedMikomiCurrecyCode;
    }

    public BigDecimal getFixedMikomiRate() {
        return fixedMikomiRate;
    }

    public void setFixedMikomiRate(BigDecimal fixedMikomiRate) {
        this.fixedMikomiRate = fixedMikomiRate;
    }

    public BigDecimal getFixedMikomiNetGaika() {
        return fixedMikomiNetGaika;
    }

    public void setFixedMikomiNetGaika(BigDecimal fixedMikomiNetGaika) {
        this.fixedMikomiNetGaika = fixedMikomiNetGaika;
    }
    
    public String getHachuFlg() {
        return hachuFlg;
    }

    public void setHachuFlg(String hachuFlg) {
        this.hachuFlg = hachuFlg;
    }

    public String getHachuCurrencyCode() {
        return hachuCurrencyCode;
    }

    public void setHachuCurrencyCode(String hachuCurrencyCode) {
        this.hachuCurrencyCode = hachuCurrencyCode;
    }

    public BigDecimal getHachuRate() {
        return hachuRate;
    }

    public void setHachuRate(BigDecimal hachuRate) {
        this.hachuRate = hachuRate;
    }

    public BigDecimal getHachuAmount() {
        return hachuAmount;
    }

    public void setHachuAmount(BigDecimal hachuAmount) {
        this.hachuAmount = hachuAmount;
    }

    public String getUriageEndFlg() {
        return uriageEndFlg;
    }

    public void setUriageEndFlg(String uriageEndFlg) {
        this.uriageEndFlg = uriageEndFlg;
    }

    public Long getSekkeiSateiNet() {
        return sekkeiSateiNet;
    }

    public void setSekkeiSateiNet(Long sekkeiSateiNet) {
        this.sekkeiSateiNet = sekkeiSateiNet;
    }

    public Long getChotatuSateiNet() {
        return chotatuSateiNet;
    }

    public void setChotatuSateiNet(Long chotatuSateiNet) {
        this.chotatuSateiNet = chotatuSateiNet;
    }

    public String getKojoCd() {
        return kojoCd;
    }

    public void setKojoCd(String kojoCd) {
        this.kojoCd = kojoCd;
    }

    public String getGiBukaCd() {
        return giBukaCd;
    }

    public void setGiBukaCd(String giBukaCd) {
        this.giBukaCd = giBukaCd;
    }

    public String getGiBukaName() {
        return giBukaName;
    }

    public void setGiBukaName(String giBukaName) {
        this.giBukaName = giBukaName;
    }

    public String getSekkeiBukaCd() {
        return sekkeiBukaCd;
    }

    public void setSekkeiBukaCd(String sekkeiBukaCd) {
        this.sekkeiBukaCd = sekkeiBukaCd;
    }

    public String getSekkeiBukaName() {
        return sekkeiBukaName;
    }

    public void setSekkeiBukaName(String sekkeiBukaName) {
        this.sekkeiBukaName = sekkeiBukaName;
    }

    public String getHatKbn() {
        return hatKbn;
    }

    public void setHatKbn(String hatKbn) {
        this.hatKbn = hatKbn;
    }

    public String getMikomiFlg() {
        return mikomiFlg;
    }

    public void setMikomiFlg(String mikomiFlg) {
        this.mikomiFlg = mikomiFlg;
    }

    public String getNetKakuteiFlg() {
        return netKakuteiFlg;
    }

    public void setNetKakuteiFlg(String netKakuteiFlg) {
        this.netKakuteiFlg = netKakuteiFlg;
    }

    public String getKariNetFlg() {
        return kariNetFlg;
    }

    public void setKariNetFlg(String kariNetFlg) {
        this.kariNetFlg = kariNetFlg;
    }

    public String getKiCategoryCode() {
        return kiCategoryCode;
    }

    public void setKiCategoryCode(String kiCategoryCode) {
        this.kiCategoryCode = kiCategoryCode;
    }

    public String getSaCategoryCode() {
        return saCategoryCode;
    }

    public void setSaCategoryCode(String saCategoryCode) {
        this.saCategoryCode = saCategoryCode;
    }

    public String getBikou() {
        return bikou;
    }

    public void setBikou(String bikou) {
        this.bikou = bikou;
    }

    public Date getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(Date createdAt) {
        this.createdAt = createdAt;
    }

    public String getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    public Date getUpdatedAt() {
        return updatedAt;
    }

    public void setUpdatedAt(Date updatedAt) {
        this.updatedAt = updatedAt;
    }

    public String getUpdatedBy() {
        return updatedBy;
    }

    public void setUpdatedBy(String updatedBy) {
        this.updatedBy = updatedBy;
    }

    public Date getUpdatedBatchAt() {
        return updatedBatchAt;
    }

    public void setUpdatedBatchAt(Date updatedBatchAt) {
        this.updatedBatchAt = updatedBatchAt;
    }

    public String getUpdatedBatchBy() {
        return updatedBatchBy;
    }

    public void setUpdatedBatchBy(String updatedBatchBy) {
        this.updatedBatchBy = updatedBatchBy;
    }

    public String getSpurtNo() {
        return spurtNo;
    }

    public void setSpurtNo(String spurtNo) {
        this.spurtNo = spurtNo;
    }

    public BigDecimal getJobgrSeq() {
        return jobgrSeq;
    }

    public void setJobgrSeq(BigDecimal jobgrSeq) {
        this.jobgrSeq = jobgrSeq;
    }

    public BigDecimal getReqSeq() {
        return reqSeq;
    }

    public void setReqSeq(BigDecimal reqSeq) {
        this.reqSeq = reqSeq;
    }

    public BigDecimal getReqRev() {
        return reqRev;
    }

    public void setReqRev(BigDecimal reqRev) {
        this.reqRev = reqRev;
    }

    public String getIraiKbn() {
        return iraiKbn;
    }

    public void setIraiKbn(String iraiKbn) {
        this.iraiKbn = iraiKbn;
    }

    public String getBundleCode() {
        return bundleCode;
    }

    public void setBundleCode(String bundleCode) {
        this.bundleCode = bundleCode;
    }

    public String getQno() {
        return qno;
    }

    public void setQno(String qno) {
        this.qno = qno;
    }

    public BigDecimal getKoubanSeq() {
        return koubanSeq;
    }

    public void setKoubanSeq(BigDecimal koubanSeq) {
        this.koubanSeq = koubanSeq;
    }

    public String getRenkeiKey() {
        return renkeiKey;
    }

    public void setRenkeiKey(String renkeiKey) {
        this.renkeiKey = renkeiKey;
    }
    
}
