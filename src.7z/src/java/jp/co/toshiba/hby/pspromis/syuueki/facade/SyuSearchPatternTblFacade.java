package jp.co.toshiba.hby.pspromis.syuueki.facade;

import java.util.List;
import java.util.Map;
import java.util.HashMap;
import javax.ejb.Stateless;
import javax.interceptor.Interceptors;
import jp.co.toshiba.hby.pspromis.syuueki.interceptor.TranceInterceptor;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import jp.co.toshiba.hby.pspromis.syuueki.entity.StringEntity;
import jp.co.toshiba.hby.pspromis.syuueki.entity.SyuSearchPatternTbl;
import jp.co.toshiba.hby.pspromis.syuueki.entity.SyuSearchPatternColTbl;
import org.apache.commons.collections.CollectionUtils;

/**
 *
 * @author ibayashi
 */
@Stateless
@Interceptors({TranceInterceptor.class})
public class SyuSearchPatternTblFacade extends AbstractFacade<SyuSearchPatternTbl> {

    @PersistenceContext(unitName = jp.co.toshiba.hby.pspromis.syuueki.util.ConstantString.syuuekiDataSourceName)
    private EntityManager em;

    @Override
    protected EntityManager getEntityManager() {
        return em;
    }

    public SyuSearchPatternTblFacade() {
        super(SyuSearchPatternTbl.class);
    }

    /**
     * 検索パターン名称の一覧を取得
     * @param idtuid
     * @param displayId
     * @return 
     */
    public List<SyuSearchPatternTbl> findSearchPatternList(String idtuid, String displayId) {
        Map<String, Object> condtion = new HashMap<>();
        condtion.put("idtuid", idtuid);
        condtion.put("displayId", displayId);
        
        List<SyuSearchPatternTbl> list 
                = sqlExecutor.getResultList(em, SyuSearchPatternTbl.class, "/sql/syuSearchPatternTbl/selectSearchPatternTbl.sql", condtion);
        
        return list;
    }

    /**
     * 検索パターン名称情報をパターン名から取得
     * @param idtuid
     * @param displayId
     * @param patternName
     * @return 
     */
    public SyuSearchPatternTbl findSearchPatternName(String idtuid, String displayId, String patternName) {
        Map<String, Object> condtion = new HashMap<>();
        condtion.put("idtuid", idtuid);
        condtion.put("displayId", displayId);
        condtion.put("matchPatternName", patternName);
        
        List<SyuSearchPatternTbl> list 
                = sqlExecutor.getResultList(em, SyuSearchPatternTbl.class, "/sql/syuSearchPatternTbl/selectSearchPatternTbl.sql", condtion);
        
        SyuSearchPatternTbl entity = null;
        if (CollectionUtils.isNotEmpty(list)) {
            entity = list.get(0);
        }
        
        return entity;
    }
        
    /**
     * 検索パターン名称の件数カウントを取得(重複チェック)
     * @param idtuid
     * @param displayId
     * @param matchPatterhName
     * @return 
     */
    public Integer countSearchPatternName(String idtuid, String displayId, String matchPatterhName) {
        Map<String, Object> condtion = new HashMap<>();
        condtion.put("idtuid", idtuid);
        condtion.put("displayId", displayId);
        condtion.put("matchPatternName", matchPatterhName);
        condtion.put("listFlg", "1");
        
        Integer count = sqlExecutor.getCount(em, "/sql/syuSearchPatternTbl/selectSearchPatternTbl.sql", condtion);

        return count;
    }

    /**
     * 新しい検索パターンSEQを取得
     * @param idtuid
     * @param displayId
     * @return 
     */
    public Integer getCreatePatternSeq(String idtuid, String displayId) {
        Map<String, Object> condtion = new HashMap<>();
        condtion.put("idtuid", idtuid);
        condtion.put("displayId", displayId);
        
        Integer newPatternSeq = 0;
        
        List<StringEntity> list 
                = sqlExecutor.getResultList(em, StringEntity.class, "/sql/syuSearchPatternTbl/selectNewPatternSeq.sql", condtion);

        if (CollectionUtils.isNotEmpty(list)) {
            String strPatternSeq = list.get(0).getString();
            newPatternSeq = Integer.parseInt(strPatternSeq);
            newPatternSeq = newPatternSeq + 1;
        }
        
        return newPatternSeq;
    }
    
    /**
     * 検索パターン名称を登録
     * @param _params
     * @return
     */
    public Integer insertSearchPattern(Map<String, Object> _params) {
        Integer count = sqlExecutor.executeUpdateSql(em, "/sql/syuSearchPatternTbl/insertSearchPatternTbl.sql", _params);
        return count;
    }

    /**
     * 検索パターン名称を更新
     * @param _params
     * @return
     */
    public Integer updateSearchPattern(Map<String, Object> _params) {
        Integer count = sqlExecutor.executeUpdateSql(em, "/sql/syuSearchPatternTbl/updateSearchPatternTbl.sql", _params);
        return count;
    }

    
    /**
     * 検索パターン名称の一覧を取得
     * @param idtuid
     * @param displayId
     * @param patternSeq
     * @return 
     */
    public List<SyuSearchPatternColTbl> findSearchPatternColList(String idtuid, String displayId, String patternSeq) {
        Map<String, Object> condtion = new HashMap<>();
        condtion.put("idtuid", idtuid);
        condtion.put("displayId", displayId);
        condtion.put("patternSeq", Integer.parseInt(patternSeq));
        
        List<SyuSearchPatternColTbl> list 
                = sqlExecutor.getResultList(em, SyuSearchPatternColTbl.class, "/sql/syuSearchPatternColTbl/selectSearchPatternColTbl.sql", condtion);
        
        return list;
    }

    /**
     * 検索パターン名称を削除
     * @param _params
     * @return
     */
    public Integer deleteSearchPattern(Map<String, Object> _params) {
        Integer count = sqlExecutor.executeUpdateSql(em, "/sql/syuSearchPatternTbl/deleteSearchPatternTbl.sql", _params);
        return count;
    }
    
    /**
     * 検索パターンの項目を登録
     * @param _params
     * @return
     */
    public Integer insertSearchPatternCol(Map<String, Object> _params) {
        Integer count = sqlExecutor.executeUpdateSql(em, "/sql/syuSearchPatternColTbl/insertSearchPatternColTbl.sql", _params);
        return count;
    }
    
    /**
     * 検索パターン名称を削除
     * @param _params
     * @return
     */
    public Integer deleteSearchPatternCol(Map<String, Object> _params) {
        Integer count = sqlExecutor.executeUpdateSql(em, "/sql/syuSearchPatternColTbl/deleteSearchPatternColTbl.sql", _params);
        return count;
    }
    
}
