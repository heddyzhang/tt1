package jp.co.toshiba.hby.pspromis.syuueki.bean;

import java.util.List;
import java.util.Map;
import javax.enterprise.context.RequestScoped;
import javax.inject.Named;
import jp.co.toshiba.hby.pspromis.syuueki.entity.SyuGeBukkenInfoTbl;
import jp.co.toshiba.hby.pspromis.syuueki.entity.SyuKiBikou;

/**
 *
 * @author masaki
 */
@Named(value = "s011Bean")
@RequestScoped
public class S011Bean extends AbstractBean {

    /**
     * 処理元の画面ID(操作ログの登録で利用)
     */
    private String procId;
    
    /**
     * 物件情報テーブル
     */
    private SyuGeBukkenInfoTbl syuGeBukkenInfoTbl;
    
    /**
     * 進行基準の備考テーブル
     */
    private SyuKiBikou syuKiBikou;

    /**
     * 編集モード
     */
    private int editFlg;
    
    /**
     * 年月
     */
    private String syuekiYm;
    
    /**
     * データ区分
     */
    private String dataKbn;
    
    /**
     * 項番
     */
    private String orderItem;

    /**
     * 備考
     */
    private String bikou;
    
    /**
     *  呼び出し元フラグ(0:期間損益, 1:最終見込損益,  2:項番一覧)
     */
    private String dispFlg;
    
    /**
     * 項番一覧備考用注番
     */
    private String orderNo;
    
    /**
     * 項番一覧備考用製番記号
     */
    private String seiban;

    
    public SyuKiBikou getSyuKiBikou() {
        return syuKiBikou;
    }

    public void setSyuKiBikou(SyuKiBikou syuKiBikou) {
        this.syuKiBikou = syuKiBikou;
    }

    public String getSyuekiYm() {
        return syuekiYm;
    }

    public void setSyuekiYm(String syuekiYm) {
        this.syuekiYm = syuekiYm;
    }

    public String getDataKbn() {
        return dataKbn;
    }

    public void setDataKbn(String dataKbn) {
        this.dataKbn = dataKbn;
    }

    public String getOrderItem() {
        return orderItem;
    }

    public void setOrderItem(String orderItem) {
        this.orderItem = orderItem;
    }
    
    public String getBikou() {
        return bikou;
    }

    public void setBikou(String bikou) {
        this.bikou = bikou;
    }

    public int getEditFlg() {
        return editFlg;
    }

    public void setEditFlg(int editFlg) {
        this.editFlg = editFlg;
    }

    public SyuGeBukkenInfoTbl getSyuGeBukkenInfoTbl() {
        return syuGeBukkenInfoTbl;
    }

    public void setSyuGeBukkenInfoTbl(SyuGeBukkenInfoTbl syuGeBukkenInfoTbl) {
        this.syuGeBukkenInfoTbl = syuGeBukkenInfoTbl;
    }    

    public String getProcId() {
        return procId;
    }

    public void setProcId(String procId) {
        this.procId = procId;
    }
    
    public String getDispFlg() {
        return dispFlg;
    }
    
    public void setDispFlg(String dispFlg) {
        this.dispFlg = dispFlg;
    }
    
    public String getOrderNo() {
        return orderNo;
    }
    
    public void setOrderNo(String orderNo) {
        this.orderNo = orderNo;
    }
    
    public String getSeiban() {
        return seiban;
    }
    
    public void setSeiban(String seiban) {
        this.seiban = seiban;
    }
}
