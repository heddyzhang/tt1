package jp.co.toshiba.hby.pspromis.syuueki.util;

import java.lang.reflect.InvocationTargetException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import javax.servlet.http.HttpServletRequest;
import jp.co.toshiba.hby.pspromis.common.util.BeanUtil;
import org.apache.commons.beanutils.PropertyUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * パラメータをbeanにバインドする
 * @author (NPC)S.Ibayashi
 */
public class ParameterBinder {
    public static final Logger logger = LoggerFactory.getLogger(ParameterBinder.class);
    /**
     * リクエストパラメータをbeanのプロパティに設定します
     * @param req HttpServletRequest
     * @param bean バインド対象JavaBeans
     * @throws java.lang.IllegalAccessException
     * @throws java.lang.reflect.InvocationTargetException
     */
    public static void Bind(Object bean, HttpServletRequest req)
    throws IllegalAccessException, InvocationTargetException, Exception {
        Map paramMap = null;

        // multipart/form-data形式(ファイルアップロード)で指定された場合のパラメータを取得
        paramMap = MultipartFormBinder.getParameterMap(req);

        if (paramMap == null) {
            // 通常リクエスト
            paramMap = req.getParameterMap();
        }

        MapBeanBind(bean, paramMap);
    }

    /**
     * Mapをbeanのプロパティに設定します
     * @param map パラメータ格納Map
     * @param bean バインド対象JavaBeans
     * @throws java.lang.IllegalAccessException
     * @throws java.lang.reflect.InvocationTargetException
     */
    public static void MapBeanBind(Object bean, Map map)
    throws IllegalAccessException, InvocationTargetException {
        //// ClassLoader脆弱性回避のチェックパターン
        String regex = "(.*\\.|^|.*|\\[('|\"))(c|C)lass(\\.|('|\")]|\\[).*";
        String regexList = "^.+\\-[0-9]+\\-.+$";
        String regexList2 = "^.+\\[[0-9]+\\]\\[.+\\]$";
        Pattern p;
        Pattern pList;
        Pattern pList2;
        boolean isString;

        if (map == null) {
            return;
        }

        p = Pattern.compile(regex);
        pList = Pattern.compile(regexList);
        pList2 = Pattern.compile(regexList2);

        Iterator ite = map.keySet().iterator();
        while(ite.hasNext()) {
            isString = false;
            String key = (String) ite.next();
            // パラメータ名がclassLoader脆弱性に引っかからないかをチェック
            Matcher match = p.matcher(key);
            if (!match.find()) {
                try {
                    Object value[] = (Object[])map.get(key);

                    ///// リスト変数名[変数名[index][key]]を、[変数名-index-key]に変換
                    Matcher matchList2 = pList2.matcher(key);
                    boolean isMatch2 = matchList2.find();
                    if (isMatch2) {
                        key = changeKey(key);
                    }
                    
                    Matcher matchList = pList.matcher(key);
                    if (matchList.find() || isMatch2) {
                        ///// リスト変数名[変数名-index-key] or [変数名[index][key]]のバインド
                        if (value != null) {
                            mapBeanListBind(bean, key, value[0]);
                        }
                        
                    } else {
                        ///// 通常変数名のバインド
                        //Object value[] = (Object[])map.get(key);
                        if (value != null) {
                            if (value.getClass() == String[].class) {
                                isString = true;
                            } else if (value.getClass() == Object[].class) {
                                isString = true;
                            } else {
                                isString = false;
                            }

                            if (value.length == 1 && "".equals(value[0])) {
                                value = null;
                            }

                        }

                        if (isString) {
                            BeanUtil.setProperty(bean, key, value);
                        } else {
                            if (value != null) {
                                try {
                                    BeanUtil.setProperty(bean, key, value);
                                } catch (Exception e) {
                                    BeanUtil.setProperty(bean, key, value[0]);
                                }
                            }
                        }

                    }
                    //BeanUtil.setProperty(bean, key, value);
                } catch(Exception e){}
            }
        }
    }

    private static void mapBeanListBind(Object bean, String key, Object value)
    throws IllegalAccessException, InvocationTargetException, NoSuchMethodException {
        String[] splits = StringUtils.split(key, "-");

        String beanDefineName = splits[0];
        String beanDefineKey = splits[2];
        int index = Integer.parseInt(splits[1]);

        List<Map<String, Object>> data = (List<Map<String, Object>>) (PropertyUtils.getProperty(bean, beanDefineName));
        if (data == null) {
            data = new ArrayList<>();
        }

        try {
            Map<String, Object> info = data.get(index);
            info.put(beanDefineKey, value);
        } catch(IndexOutOfBoundsException ioe){
            addListCapacity(data, index, beanDefineKey, value);
        }

        PropertyUtils.setProperty(bean, beanDefineName, data);
    }

    private static void addListCapacity(List<Map<String, Object>> data, int index, String key, Object value) {
        for (int i=0; i<=index; i++) {
            boolean isNull = false;
            Map<String, Object> indexInfo;
            try {
                indexInfo = data.get(i);
                if (indexInfo == null) {
                    isNull = true;
                }
            } catch(IndexOutOfBoundsException ioe2){
                isNull = true;
            }
            
            if (isNull) {
                indexInfo = new HashMap<>();
                data.add(indexInfo);
                if (i == index) {
                    indexInfo.put(key, value);
                }
            }
        }
    }

    private static String changeKey(String key) {
        String a = key.replace("[", "-");
        a = a.replace("]", "");
        return a;
    }

}
