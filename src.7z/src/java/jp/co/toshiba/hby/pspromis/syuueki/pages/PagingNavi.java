package jp.co.toshiba.hby.pspromis.syuueki.pages;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import javax.enterprise.context.RequestScoped;
import javax.inject.Inject;
import javax.inject.Named;
import jp.co.toshiba.hby.pspromis.syuueki.enums.Env;
import jp.co.toshiba.hby.pspromis.syuueki.util.Utils;

/**
 * ページング用コンポーネント管理bean
 * @author (NPC)S.Ibayashi
 */
@Named(value = "pagingNavi")
@RequestScoped
public class PagingNavi {

    @Inject
    private Utils util;

    /**
     * データ総件数
     */
    private Integer count;

    /**
     * 表示対象ページ番号
     */
    private Integer page;

    /**
     * 遷移可能なページ範囲を取得
     * @return 
     */
    public Integer getPageingRange() {
        Integer envStartPage = null;
        try {
            envStartPage = new Integer(Env.getValue(Env.PageingRange));
        } catch (NumberFormatException e){}
        return envStartPage;
    }

    /**
     * 最大表示ページ数を取得
     * @return 
     */
    public Integer getMaxPageCount() {
        //int limit = util.getPageLimit();
        int limit = util.getPageDataCount();

        List<Integer> list = new ArrayList<>();
        Double pageCount = (new Double(count)) / (new Double(limit));
        BigDecimal big = new BigDecimal(Math.ceil(pageCount));
        int intCount = big.intValue();

        return intCount;
    }

    public Integer getCount() {
        return count;
    }

    public void setCount(Integer count) {
        this.count = count;
    }

    public Integer getPage() {
        return page;
    }

    public void setPage(Integer page) {
        this.page = page;
    }

    public Boolean outputPageingNavi() {
        if (count != null && page != null) {
            return true;
        } else {
            return false;
        }
    }

    public List<Integer> getPageList() {
        List<Integer> list = new ArrayList<>();
        Integer intCount = getMaxPageCount();
        int startPage = 0;
        int endPage = intCount;
        int wEndPage;
        
        boolean isEnd = false;
 
        // 表示するページ範囲を取得。
        Integer envStartPage = getPageingRange();

        if (envStartPage != null) {
            int amari = envStartPage % 2;
            // 描画開始ページを取得
            startPage = page - ((envStartPage / 2) + amari);
            if (startPage < 0) {
                startPage = 0;
            }

            // 描画終了ページを取得
            endPage = startPage + envStartPage;
            if (endPage > intCount) {
                wEndPage = intCount;
                isEnd = true;
                
            } else {
                wEndPage = page + ((envStartPage / 2) - amari);
                if (wEndPage >= intCount) {
                    wEndPage = intCount;
                    isEnd = true;
                }
            
            }

            if (isEnd) {
                startPage = intCount - envStartPage;
                if (startPage < 0) {
                    startPage = 0;
                }
                endPage = wEndPage;
            }
        }

        for (int i = startPage; i < endPage; i++) {
            list.add(i + 1);
        }
        return list;
    }

    private Boolean isNowPage(Integer nowPage) {
        if (page.equals(nowPage)) {
            return true;
        } else {
            return false;
        }
    }

    public String getStyle(Integer nowPage) {
        if (isNowPage(nowPage)) {
            return "btn-primary";
        } else {
            return "btn-default";
        }
    }

    public boolean getDispRight() {
        if (getPageingRange() != null && page < getMaxPageCount()) {
            return true;
        } else {
            return false;
        }
    }
 
    public boolean getDispLeft() {
        if (getPageingRange() != null && page > 1) {
            return true;
        } else {
            return false;
        }
    }
    
    public Integer getRightPage() {
        Integer rightPage = page - 1;
        if (rightPage <= 0) {
            rightPage = page;
        }
        return rightPage;
    }
    
    public Integer getLeftPage() {
        Integer leftPage = page + 1;
        if (leftPage > getMaxPageCount()) {
            leftPage = page;
        }
        return leftPage;
    }
}
