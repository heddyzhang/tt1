package jp.co.toshiba.hby.pspromis.syuueki.service;

import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.ejb.Stateless;
import javax.inject.Inject;
import javax.interceptor.Interceptors;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import jp.co.toshiba.hby.pspromis.common.exception.PspRunTimeExceotion;
import jp.co.toshiba.hby.pspromis.syuueki.bean.S025Bean;
import jp.co.toshiba.hby.pspromis.syuueki.entity.SyuGeBukkenInfoTbl;
import jp.co.toshiba.hby.pspromis.syuueki.entity.SyuKiNetItemTukiTbl;
import jp.co.toshiba.hby.pspromis.syuueki.enums.Label;
import jp.co.toshiba.hby.pspromis.syuueki.facade.KanjyoMstFacade;
import jp.co.toshiba.hby.pspromis.syuueki.facade.SyuGeBukenInfoTblFacade;
import jp.co.toshiba.hby.pspromis.syuueki.facade.SyuKiNetItemTukiTblFacade;
import jp.co.toshiba.hby.pspromis.syuueki.interceptor.TranceInterceptor;
import jp.co.toshiba.hby.pspromis.syuueki.util.LoginUserInfo;
import jp.co.toshiba.hby.pspromis.syuueki.util.SyuuekiUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * PS-Promis収益管理システム
 * 設置場所選択 Service
 * @author (NPC)S.horie
 */
@Stateless
@Interceptors({TranceInterceptor.class})
public class S025Service {

    public static final Logger logger = LoggerFactory.getLogger(S025Service.class);

    @PersistenceContext(unitName = jp.co.toshiba.hby.pspromis.syuueki.util.ConstantString.syuuekiDataSourceName)
    private EntityManager em;

    /**
     * Injection loginUserInfo
     * (ユーザー情報(ユーザーid,名称,所属部課名)を格納したオブジェクト)
     */
    @Inject
    private LoginUserInfo loginUserInfo;

    @Inject
    private S025Bean s025Bean;

    @Inject
    private SyuGeBukenInfoTblFacade syuGeBukenInfoTblFacade;

    @Inject
    private KanjyoMstFacade kanjyoMstFacade;

    @Inject
    private SyuKiNetItemTukiTblFacade syuKiNetItemTukiTblFacade;

    @Inject
    private SyuuekiUtils syuuekiUtils;

    @Inject
    private StoredProceduresService storedProceduresService;

    /**
     * 初期表示時機能
     * @throws Exception
     */
    public void indexExecute() throws Exception {
        logger.info("S025Service#indexExecute");
//        SyuGeBukkenInfoTbl ankenEntity = getAnkenEntity();

        // カテゴリ設定対象の項番一覧の検索
        findTargetOrderItem();

        setDefaultYm();
    }

    /**
     * 共通の条件を作成して取得
     */
    private Map<String, Object> getBaseCondition() {
        Map<String, Object> condition = new HashMap<>();
        condition.put("ankenId", s025Bean.getAnkenId());
        condition.put("rirekiId", s025Bean.getRirekiId());
        return condition;
    }

    /**
     * 案件情報を取得
     */
    private SyuGeBukkenInfoTbl getAnkenEntity() {
        Map<String, Object> condition = getBaseCondition();
        SyuGeBukkenInfoTbl geEntity = syuGeBukenInfoTblFacade.findPk(condition);
        if (geEntity == null) {
            String errorMessage = Label.errorNoAnkenDate.getLabel();
            logger.error(errorMessage + " ankenId=" + s025Bean.getAnkenId() + " rirekiId=" + s025Bean.getRirekiId());
            throw new PspRunTimeExceotion(errorMessage);
        }
        return geEntity;
    }
    /**
     * カテゴリ設定対象の項番一覧の検索
     */
    private void findTargetOrderItem() {
        // 検索条件
        Map<String, Object> condition = getBaseCondition();
        condition.put("orderItemList", Arrays.asList(s025Bean.getOrderItems()));

        SyuGeBukkenInfoTbl ankenEntity = getAnkenEntity();
        s025Bean.setKanjyoYm(kanjyoMstFacade.getNowKanjoDate(ankenEntity.getSalesClass()));
        condition.put("kanjyoYm", s025Bean.getKanjyoYm());
        condition.put("dataKbn", "M");

        // 一覧を検索
        List<SyuKiNetItemTukiTbl> list = syuKiNetItemTukiTblFacade.selectTargetChangeYmItem(condition);

        s025Bean.setTargetItemList(list);
    }

    private void setDefaultYm() {
        s025Bean.setOldYm("");
        String defaultOldYm = "";
        // SQLのorder byでもよかった
        for (SyuKiNetItemTukiTbl record : s025Bean.getTargetItemList()) {
            if (StringUtils.isEmpty(defaultOldYm)) {
                defaultOldYm = record.getSyuekiYm();
            } else if (defaultOldYm.compareTo(record.getSyuekiYm()) > 0) {
                defaultOldYm = record.getSyuekiYm();
            }
        }
        if (StringUtils.isNotEmpty(defaultOldYm)) {
            s025Bean.setOldYm(syuuekiUtils.getLabelMonth(defaultOldYm));
        }
        if (StringUtils.isEmpty(s025Bean.getOldYm())) {
            s025Bean.setOldYm(syuuekiUtils.getLabelMonth(s025Bean.getKanjyoYm()));
        }
    }

    /**
     * 保存処理
     * @throws java.lang.Exception
     */
    public void saveExecute() throws Exception {
        logger.info("S025Service#saveExecute");

        Map<String, Object> condition = getBaseCondition();
        SyuGeBukkenInfoTbl ankenEntity = getAnkenEntity();
        s025Bean.setKanjyoYm(kanjyoMstFacade.getNowKanjoDate(ankenEntity.getSalesClass()));
        condition.put("kanjyoYm", s025Bean.getKanjyoYm());
        condition.put("oldYm", StringUtils.replace(s025Bean.getOldYm(), "/", ""));
        condition.put("newYm", StringUtils.replace(s025Bean.getNewYm(), "/", ""));
        condition.put("dataKbn", "M");
        condition.put("userId", loginUserInfo.getUserId());
        for (String orderItem : s025Bean.getOrderItems()) {
            condition.put("orderItem", orderItem);
            condition.put("befOrderItem", orderItem);
            // oldYmにレコードが存在しなかった場合、newYmがnullで更新、作成される
            syuKiNetItemTukiTblFacade.mergeTargetChangeYmItem(condition);
            condition.put("syuekiYm", StringUtils.replace(s025Bean.getOldYm(), "/", ""));
            // oldYmのURIAGE_NETをNULLで更新する
            syuKiNetItemTukiTblFacade.updateClearNetItem(condition);
        }
        // 再計算（集計）パッケージ呼出
        storedProceduresService.callAnkenRecalAuto(s025Bean.getAnkenId(), s025Bean.getRirekiId(), "1");

        condition.remove("orderItem");
        condition.remove("befOrderItem");
        // それをDELETE文で削除する
        syuKiNetItemTukiTblFacade.deleteNetItem(condition);
    }
}
