package jp.co.toshiba.hby.pspromis.syuueki.servlet;

import javax.inject.Inject;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpServletRequest;
import jp.co.toshiba.hby.pspromis.syuueki.bean.K001Bean;
import jp.co.toshiba.hby.pspromis.syuueki.service.K001Service;
import jp.co.toshiba.hby.pspromis.syuueki.util.ParameterBinder;

/**
 * PS-Promis収益管理システム
 * ジョブグループ選択 Servlet
 * @author (NPC)S.Ibayashi
 */
@WebServlet(name = "K001", urlPatterns = {"/servlet/K001", "/servlet/K001/*"})
public class K001Servlet extends AbstractServlet {

    /**
     * jsp
     */
    private static final String INDEX_JSP = "K001/k001.jsp";

    /**
     * 使用serviceクラスをinjection(CDI)<br>
     * InjectアノテーションよりAPサーバー(Glassfish)側で自動的にインスタンス作成(new)される。<br>
     * service側はステートレスセッションbeanにするため、Statelessアノテーションをつけておくこと。<br>
     */
    @Inject
    private K001Service k001Service;

    /**
     * パラメータ格納クラスをinjection(CDI)<br>
     * InjectアノテーションよりAPサーバー(Glassfish)側で自動的にインスタンス作成(new)される。<br>
     */
    @Inject
    private K001Bean k001Bean;
    
    /**
     * 初期表示(事業部・部課リスト取得)
     * @param req
     * @param resp
     * @return
     * @throws Exception 
     */
    public String indexAction(HttpServletRequest req, HttpServletResponse resp)
    throws Exception {
        logger.info("K001Servlet#indexAction");
        
        // リクエストパラメータをk001Beanの同名フィールドに一括コピー
        ParameterBinder.Bind(k001Bean, req);

        k001Service.indexExecute();

        return INDEX_JSP;
    }

    /**
     * 選択部課のJobGrを表示(ajax jsonレスポンス)
     * @param req
     * @param resp
     * @return
     * @throws Exception 
     */
    public String jobGrAction(HttpServletRequest req, HttpServletResponse resp)
    throws Exception {
        logger.info("K001Servlet#jobGrAction");

        // リクエストパラメータをk001Beanの同名フィールドに一括コピー
        logger.info("req deptCd=" + req.getParameter("deptCd"));
        ParameterBinder.Bind(k001Bean, req);
        
        k001Service.jobGrExecute();

        resopnseDecodeJson(resp, k001Bean.getJobGrList());
        return null;
    }

}