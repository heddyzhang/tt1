/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package jp.co.toshiba.hby.pspromis.syuueki.entity;

import java.io.Serializable;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;

/**
 *
 * @author watabe
 */
@Entity
public class IspJissekiData implements Serializable {
    private static final long serialVersionUID = 1L;

    //案件番号
    @Column(name = "ANKEN_ID")
    @Id
    private String ankenId;
    //履歴ID
    @Column(name = "RIREKI_ID")
    @Id
    private String rirekiId;
    //年月(YYYYMM)
    @Id
    @Column(name = "SYUEKI_YM")
    private String syuekiYm;
    //注番
    @Column(name = "ORDER_NO")
    private String orderNo;
    //ISP事業部
    @Column(name = "ISP_DIVISION_NM")
    private String ispDivisionNm;
    //案件名称
    @Column(name = "ANKEN_NAME")
    private String ankenName;
    //ISP
    @Column(name = "ISP")
    private String isp;
    @Column(name = "CURRENCY_CODE")
    private String currencyCode;
    //NET
    @Column(name = "NET")
    private String net;


    public String getAnkenId() {
        return ankenId;
    }

    public void setAnkenId(String ankenId) {
        this.ankenId = ankenId;
    }

    public String getRirekiId() {
        return rirekiId;
    }

    public void setRirekiId(String rirekiId) {
        this.rirekiId = rirekiId;
    }

    public String getOrderNo() {
        return orderNo;
    }

    public void setOrderNo(String orderNo) {
        this.orderNo = orderNo;
    }
    
    public String getSyuekiYm() {
        return syuekiYm;
    }

    public void setSyuekiYm(String syuekiYm) {
        this.syuekiYm = syuekiYm;
    }
    
    public String getIspDivisionNm() {
        return ispDivisionNm;
    }

    public void setIspDivisionNm(String ispDivisionNm) {
        this.ispDivisionNm = ispDivisionNm;
    }

    public String getAnkenName() {
        return ankenName;
    }

    public void setAnkenName(String ankenName) {
        this.ankenName = ankenName;
    }

    public String getIsp() {
        return isp;
    }

    public void setIsp(String isp) {
        this.isp = isp;
    }

    public String getNet() {
        return net;
    }

    public void setNet(String net) {
        this.net = net;
    }

    public String getCurrencyCode() {
        return currencyCode;
    }

    public void setCurrencyCode(String currencyCode) {
        this.currencyCode = currencyCode;
    }

}
