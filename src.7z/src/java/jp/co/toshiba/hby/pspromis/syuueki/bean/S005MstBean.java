package jp.co.toshiba.hby.pspromis.syuueki.bean;

import java.io.Serializable;
import java.util.List;
import javax.enterprise.context.SessionScoped;
import javax.inject.Named;
import jp.co.toshiba.hby.pspromis.syuueki.entity.SyuGeNetItemTblBuka;
import jp.co.toshiba.hby.pspromis.syuueki.entity.SyuKiNetCateTitleTbl;
import jp.co.toshiba.hby.pspromis.syuueki.entity.SyuKiNetCateTitleTblView;
import jp.co.toshiba.hby.pspromis.syuueki.entity.SyuSaNetCateTitleTbl;
import jp.co.toshiba.hby.pspromis.syuueki.entity.SyuSaNetCateTitleTblView;

/**
 *
 * @author wakamatsu
 */
@Named(value = "s005MstBean")
@SessionScoped
public class S005MstBean extends AbstractBean implements Serializable {

    /**
     * （技）/IEC(設計）部課マスタ
     */
    private List<SyuGeNetItemTblBuka> sekkeiBukaList;

    /**
     * （工場）設計　部課マスタ
     */
    private List<SyuGeNetItemTblBuka> kojoBukaList;

    /**
     * カテゴリ(最終) 選択候補
     */
    private List<SyuSaNetCateTitleTblView> cateSaList1;
    
    /**
     * カテゴリ(最終) 選択候補
     */
    private List<SyuSaNetCateTitleTblView> cateSaList2;
    
    /**
     * カテゴリ(期間) 選択候補
     */
    private List<SyuKiNetCateTitleTblView> cateKiList1;
    
    /**
     * カテゴリ(期間) 選択候補
     */
    private List<SyuKiNetCateTitleTblView> cateKiList2;

    public List<SyuGeNetItemTblBuka> getSekkeiBukaList() {
        return sekkeiBukaList;
    }

    public void setSekkeiBukaList(List<SyuGeNetItemTblBuka> sekkeiBukaList) {
        this.sekkeiBukaList = sekkeiBukaList;
    }

    public List<SyuGeNetItemTblBuka> getKojoBukaList() {
        return kojoBukaList;
    }

    public void setKojoBukaList(List<SyuGeNetItemTblBuka> kojoBukaList) {
        this.kojoBukaList = kojoBukaList;
    }

    public List<SyuSaNetCateTitleTblView> getCateSaList1() {
        return cateSaList1;
    }

    public void setCateSaList1(List<SyuSaNetCateTitleTblView> cateSaList1) {
        this.cateSaList1 = cateSaList1;
    }

    public List<SyuSaNetCateTitleTblView> getCateSaList2() {
        return cateSaList2;
    }

    public void setCateSaList2(List<SyuSaNetCateTitleTblView> cateSaList2) {
        this.cateSaList2 = cateSaList2;
    }

    public List<SyuKiNetCateTitleTblView> getCateKiList1() {
        return cateKiList1;
    }

    public void setCateKiList1(List<SyuKiNetCateTitleTblView> cateKiList1) {
        this.cateKiList1 = cateKiList1;
    }

    public List<SyuKiNetCateTitleTblView> getCateKiList2() {
        return cateKiList2;
    }

    public void setCateKiList2(List<SyuKiNetCateTitleTblView> cateKiList2) {
        this.cateKiList2 = cateKiList2;
    }

}
