package jp.co.toshiba.hby.pspromis.syuueki.entity;

import java.io.Serializable;
import java.math.BigDecimal;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.validation.constraints.NotNull;

/**
 *
 * @author sano
 */
@Entity
public class SonekiList implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @NotNull
    @Column(name = "ANKEN_ID")
    private String ankenId;
    @Column(name = "HAN_CHOKU_NET_JS")
    private BigDecimal hanChokuNetJs;
    @Column(name = "HAN_CHOKU_NET_JT")
    private BigDecimal hanChokuNetJt;
    @Column(name = "HAN_CHOKU_NET_MH")
    private BigDecimal hanChokuNetMh;
    @Column(name = "HAN_CHOKU_NET_SM")
    private BigDecimal hanChokuNetSm;
    @Column(name = "HAN_CHOKU_NET_ST")
    private BigDecimal hanChokuNetSt;
    @Column(name = "HAN_CHOKU_NET_HB")
    private BigDecimal hanChokuNetHb;
    @Column(name = "HAN_CHOKU_NET_TR")
    private BigDecimal hanChokuNetTr;
    @Column(name = "HAN_CHOKU_NET_FM")
    private BigDecimal hanChokuNetFm;
    @Column(name = "HAN_CHOKU_NET_DIFF")
    private BigDecimal hanChokuNetDiff;
    @Column(name = "HAN_CHOKU_NET_PD")
    private BigDecimal hanChokuNetPd;
    @Column(name = "HAN_CHOKU_NET_PT")
    private BigDecimal hanChokuNetPt;
    @Column(name = "HAN_CHOKU_NET_PS")
    private BigDecimal hanChokuNetPs;
    @Column(name = "HAN_CHOKU_NET_PREV")
    private BigDecimal hanChokuNetPrev;

    @Column(name = "ISP_NET_JS")
    private BigDecimal ispNetJs;
    @Column(name = "ISP_NET_JT")
    private BigDecimal ispNetJt;
    @Column(name = "ISP_NET_MH")
    private BigDecimal ispNetMh;
    @Column(name = "ISP_NET_SM")
    private BigDecimal ispNetSm;
    @Column(name = "ISP_NET_ST")
    private BigDecimal ispNetSt;
    @Column(name = "ISP_NET_HB")
    private BigDecimal ispNetHb;
    @Column(name = "ISP_NET_TR")
    private BigDecimal ispNetTr;
    @Column(name = "ISP_NET_FM")
    private BigDecimal ispNetFm;
    @Column(name = "ISP_NET_DIFF")
    private BigDecimal ispNetDiff;
    @Column(name = "ISP_NET_PD")
    private BigDecimal ispNetPd;
    @Column(name = "ISP_NET_PT")
    private BigDecimal ispNetPt;
    @Column(name = "ISP_NET_PS")
    private BigDecimal ispNetPs;
    @Column(name = "ISP_NET_PREV")
    private BigDecimal ispNetPrev;

    @Column(name = "HAN_KAN_NET_JS")
    private BigDecimal hanKanNetJs;
    @Column(name = "HAN_KAN_NET_JT")
    private BigDecimal hanKanNetJt;
    @Column(name = "HAN_KAN_NET_MH")
    private BigDecimal hanKanNetMh;
    @Column(name = "HAN_KAN_NET_SM")
    private BigDecimal hanKanNetSm;
    @Column(name = "HAN_KAN_NET_ST")
    private BigDecimal hanKanNetSt;
    @Column(name = "HAN_KAN_NET_HB")
    private BigDecimal hanKanNetHb;
    @Column(name = "HAN_KAN_NET_TR")
    private BigDecimal hanKanNetTr;
    @Column(name = "HAN_KAN_NET_FM")
    private BigDecimal hanKanNetFm;
    @Column(name = "HAN_KAN_NET_DIFF")
    private BigDecimal hanKanNetDiff;
    @Column(name = "HAN_KAN_NET_PD")
    private BigDecimal hanKanNetPd;
    @Column(name = "HAN_KAN_NET_PT")
    private BigDecimal hanKanNetPt;
    @Column(name = "HAN_KAN_NET_PS")
    private BigDecimal hanKanNetPs;
    @Column(name = "HAN_KAN_NET_PREV")
    private BigDecimal hanKanNetPrev;

    @Column(name = "KEIHI_NET_JS")
    private BigDecimal keihiNetJs;
    @Column(name = "KEIHI_NET_JT")
    private BigDecimal keihiNetJt;
    @Column(name = "KEIHI_NET_MH")
    private BigDecimal keihiNetMh;
    @Column(name = "KEIHI_NET_SM")
    private BigDecimal keihiNetSm;
    @Column(name = "KEIHI_NET_ST")
    private BigDecimal keihiNetSt;
    @Column(name = "KEIHI_NET_HB")
    private BigDecimal keihiNetHb;
    @Column(name = "KEIHI_NET_TR")
    private BigDecimal keihiNetTr;
    @Column(name = "KEIHI_NET_FM")
    private BigDecimal keihiNetFm;
    @Column(name = "KEIHI_NET_DIFF")
    private BigDecimal keihiNetDiff;
    @Column(name = "KEIHI_NET_PD")
    private BigDecimal keihiNetPd;
    @Column(name = "KEIHI_NET_PT")
    private BigDecimal keihiNetPt;
    @Column(name = "KEIHI_NET_PS")
    private BigDecimal keihiNetPs;
    @Column(name = "KEIHI_NET_PREV")
    private BigDecimal keihiNetPrev;

    @Column(name = "SOUGENKA_NET_JS")
    private BigDecimal sougenkaNetJs;
    @Column(name = "SOUGENKA_NET_JT")
    private BigDecimal sougenkaNetJt;
    @Column(name = "SOUGENKA_NET_MH")
    private BigDecimal sougenkaNetMh;
    @Column(name = "SOUGENKA_NET_SM")
    private BigDecimal sougenkaNetSm;
    @Column(name = "SOUGENKA_NET_ST")
    private BigDecimal sougenkaNetSt;
    @Column(name = "SOUGENKA_NET_HB")
    private BigDecimal sougenkaNetHb;
    @Column(name = "SOUGENKA_NET_TR")
    private BigDecimal sougenkaNetTr;
    @Column(name = "SOUGENKA_NET_FM")
    private BigDecimal sougenkaNetFm;
    @Column(name = "SOUGENKA_NET_DIFF")
    private BigDecimal sougenkaNetDiff;
    @Column(name = "SOUGENKA_NET_PD")
    private BigDecimal sougenkaNetPd;
    @Column(name = "SOUGENKA_NET_PT")
    private BigDecimal sougenkaNetPt;
    @Column(name = "SOUGENKA_NET_PS")
    private BigDecimal sougenkaNetPs;
    @Column(name = "SOUGENKA_NET_PREV")
    private BigDecimal sougenkaNetPrev;

    @Column(name = "KAWASE_YOYAKU_NET_JS")
    private BigDecimal kawaseYoyakuNetJs;
    @Column(name = "KAWASE_YOYAKU_NET_JT")
    private BigDecimal kawaseYoyakuNetJt;
    @Column(name = "KAWASE_YOYAKU_NET_MH")
    private BigDecimal kawaseYoyakuNetMh;
    @Column(name = "KAWASE_YOYAKU_NET_SM")
    private BigDecimal kawaseYoyakuNetSm;
    @Column(name = "KAWASE_YOYAKU_NET_ST")
    private BigDecimal kawaseYoyakuNetSt;
    @Column(name = "KAWASE_YOYAKU_NET_HB")
    private BigDecimal kawaseYoyakuNetHb;
    @Column(name = "KAWASE_YOYAKU_NET_TR")
    private BigDecimal kawaseYoyakuNetTr;
    @Column(name = "KAWASE_YOYAKU_NET_FM")
    private BigDecimal kawaseYoyakuNetFm;
    @Column(name = "KAWASE_YOYAKU_NET_DIFF")
    private BigDecimal kawaseYoyakuNetDiff;
    @Column(name = "KAWASE_YOYAKU_NET_PD")
    private BigDecimal kawaseYoyakuNetPd;
    @Column(name = "KAWASE_YOYAKU_NET_PT")
    private BigDecimal kawaseYoyakuNetPt;
    @Column(name = "KAWASE_YOYAKU_NET_PS")
    private BigDecimal kawaseYoyakuNetPs;
    @Column(name = "KAWASE_YOYAKU_NET_PREV")
    private BigDecimal kawaseYoyakuNetPrev;

    @Column(name = "SEIBAN_SONEKI_NET_JS")
    private BigDecimal seibanSonekiNetJs;
    @Column(name = "SEIBAN_SONEKI_NET_JT")
    private BigDecimal seibanSonekiNetJt;
    @Column(name = "SEIBAN_SONEKI_NET_MH")
    private BigDecimal seibanSonekiNetMh;
    @Column(name = "SEIBAN_SONEKI_NET_SM")
    private BigDecimal seibanSonekiNetSm;
    @Column(name = "SEIBAN_SONEKI_NET_ST")
    private BigDecimal seibanSonekiNetSt;
    @Column(name = "SEIBAN_SONEKI_NET_HB")
    private BigDecimal seibanSonekiNetHb;
    @Column(name = "SEIBAN_SONEKI_NET_TR")
    private BigDecimal seibanSonekiNetTr;
    @Column(name = "SEIBAN_SONEKI_NET_FM")
    private BigDecimal seibanSonekiNetFm;
    @Column(name = "SEIBAN_SONEKI_NET_DIFF")
    private BigDecimal seibanSonekiNetDiff;
    @Column(name = "SEIBAN_SONEKI_NET_PD")
    private BigDecimal seibanSonekiNetPd;
    @Column(name = "SEIBAN_SONEKI_NET_PT")
    private BigDecimal seibanSonekiNetPt;
    @Column(name = "SEIBAN_SONEKI_NET_PS")
    private BigDecimal seibanSonekiNetPs;
    @Column(name = "SEIBAN_SONEKI_NET_PREV")
    private BigDecimal seibanSonekiNetPrev;

    @Column(name = "KEIJOU_SONEKI_NET_JS")
    private BigDecimal keijousonekinetJs;
    @Column(name = "KEIJOU_SONEKI_NET_JT")
    private BigDecimal keijousonekinetJt;
    @Column(name = "KEIJOU_SONEKI_NET_MH")
    private BigDecimal keijousonekinetMh;
    @Column(name = "KEIJOU_SONEKI_NET_SM")
    private BigDecimal keijousonekinetSm;
    @Column(name = "KEIJOU_SONEKI_NET_ST")
    private BigDecimal keijousonekinetSt;
    @Column(name = "KEIJOU_SONEKI_NET_HB")
    private BigDecimal keijousonekinetHb;
    @Column(name = "KEIJOU_SONEKI_NET_TR")
    private BigDecimal keijousonekinetTr;
    @Column(name = "KEIJOU_SONEKI_NET_FM")
    private BigDecimal keijousonekinetFm;
    @Column(name = "KEIJOU_SONEKI_NET_DIFF")
    private BigDecimal keijousonekinetDiff;
    @Column(name = "KEIJOU_SONEKI_NET_PD")
    private BigDecimal keijousonekinetPd;
    @Column(name = "KEIJOU_SONEKI_NET_PT")
    private BigDecimal keijousonekinetPt;
    @Column(name = "KEIJOU_SONEKI_NET_PS")
    private BigDecimal keijousonekinetPs;
    @Column(name = "KEIJOU_SONEKI_NET_PREV")
    private BigDecimal keijousonekinetPrev;
    @Column(name = "EIGYOGAI_JS")
    private BigDecimal eigyogaiJs;
    @Column(name = "EIGYOGAI_JT")
    private BigDecimal eigyogaiJt;
    @Column(name = "EIGYOGAI_MH")
    private BigDecimal eigyogaiMh;
    @Column(name = "EIGYOGAI_SM")
    private BigDecimal eigyogaiSm;
    @Column(name = "EIGYOGAI_ST")
    private BigDecimal eigyogaiSt;
    @Column(name = "EIGYOGAI_HB")
    private BigDecimal eigyogaiHb;
    @Column(name = "EIGYOGAI_TR")
    private BigDecimal eigyogaiTr;
    @Column(name = "EIGYOGAI_FM")
    private BigDecimal eigyogaiFm;
    @Column(name = "EIGYOGAI_DIFF")
    private BigDecimal eigyogaiDiff;
    @Column(name = "EIGYOGAI_PD")
    private BigDecimal eigyogaiPd;
    @Column(name = "EIGYOGAI_PT")
    private BigDecimal eigyogaiPt;
    @Column(name = "EIGYOGAI_PS")
    private BigDecimal eigyogaiPs;
    @Column(name = "EIGYOGAI_PREV")
    private BigDecimal eigyogaiPrev;

    public SonekiList() {
    }

    public String getAnkenId() {
        return this.ankenId;
    }

    public void setAnkenId(String ankenId) {
        this.ankenId = ankenId;
    }

    public BigDecimal getHanChokuNetJs() {
        return this.hanChokuNetJs;
    }

    public void setHanChokuNetJs(BigDecimal hanChokuNetJs) {
        this.hanChokuNetJs = hanChokuNetJs;
    }

    public BigDecimal getHanChokuNetJt() {
        return this.hanChokuNetJt;
    }

    public void setHanChokuNetJt(BigDecimal hanChokuNetJt) {
        this.hanChokuNetJt = hanChokuNetJt;
    }

    public BigDecimal getHanChokuNetMh() {
        return this.hanChokuNetMh;
    }

    public void setHanChokuNetMh(BigDecimal hanChokuNetMh) {
        this.hanChokuNetMh = hanChokuNetMh;
    }

    public BigDecimal getHanChokuNetSm() {
        return this.hanChokuNetSm;
    }

    public void setHanChokuNetSm(BigDecimal hanChokuNetSm) {
        this.hanChokuNetSm = hanChokuNetSm;
    }

    public BigDecimal getHanChokuNetSt() {
        return this.hanChokuNetSt;
    }

    public void setHanChokuNetSt(BigDecimal hanChokuNetSt) {
        this.hanChokuNetSt = hanChokuNetSt;
    }

    public BigDecimal getHanChokuNetHb() {
        return this.hanChokuNetHb;
    }

    public void setHanChokuNetHb(BigDecimal hanChokuNetHb) {
        this.hanChokuNetHb = hanChokuNetHb;
    }

    public BigDecimal getHanChokuNetTr() {
        return this.hanChokuNetTr;
    }

    public void setHanChokuNetTr(BigDecimal hanChokuNetTr) {
        this.hanChokuNetTr = hanChokuNetTr;
    }

    public BigDecimal getHanChokuNetFm() {
        return this.hanChokuNetFm;
    }

    public void setHanChokuNetFm(BigDecimal hanChokuNetFm) {
        this.hanChokuNetFm = hanChokuNetFm;
    }

    public BigDecimal getHanChokuNetDiff() {
        return this.hanChokuNetDiff;
    }

    public void setHanChokuNetDiff(BigDecimal hanChokuNetDiff) {
        this.hanChokuNetDiff = hanChokuNetDiff;
    }

    public BigDecimal getIspNetJs() {
        return this.ispNetJs;
    }

    public void setIspNetJs(BigDecimal ispNetJs) {
        this.ispNetJs = ispNetJs;
    }

    public BigDecimal getIspNetJt() {
        return this.ispNetJt;
    }

    public void setIspNetJt(BigDecimal ispNetJt) {
        this.ispNetJt = ispNetJt;
    }

    public BigDecimal getIspNetMh() {
        return this.ispNetMh;
    }

    public void setIspNetMh(BigDecimal ispNetMh) {
        this.ispNetMh = ispNetMh;
    }

    public BigDecimal getIspNetSm() {
        return this.ispNetSm;
    }

    public void setIspNetSm(BigDecimal ispNetSm) {
        this.ispNetSm = ispNetSm;
    }

    public BigDecimal getIspNetSt() {
        return this.ispNetSt;
    }

    public void setIspNetSt(BigDecimal ispNetSt) {
        this.ispNetSt = ispNetSt;
    }

    public BigDecimal getIspNetHb() {
        return this.ispNetHb;
    }

    public void setIspNetHb(BigDecimal ispNetHb) {
        this.ispNetHb = ispNetHb;
    }

    public BigDecimal getIspNetTr() {
        return this.ispNetTr;
    }

    public void setIspNetTr(BigDecimal ispNetTr) {
        this.ispNetTr = ispNetTr;
    }

    public BigDecimal getIspNetFm() {
        return this.ispNetFm;
    }

    public void setIspNetFm(BigDecimal ispNetFm) {
        this.ispNetFm = ispNetFm;
    }

    public BigDecimal getIspNetDiff() {
        return this.ispNetDiff;
    }

    public void setIspNetDiff(BigDecimal ispNetDiff) {
        this.ispNetDiff = ispNetDiff;
    }

    public BigDecimal getHanKanNetJs() {
        return this.hanKanNetJs;
    }

    public void setHanKanNetJs(BigDecimal hanKanNetJs) {
        this.hanKanNetJs = hanKanNetJs;
    }

    public BigDecimal getHanKanNetJt() {
        return this.hanKanNetJt;
    }

    public void setHanKanNetJt(BigDecimal hanKanNetJt) {
        this.hanKanNetJt = hanKanNetJt;
    }

    public BigDecimal getHanKanNetMh() {
        return this.hanKanNetMh;
    }

    public void setHanKanNetMh(BigDecimal hanKanNetMh) {
        this.hanKanNetMh = hanKanNetMh;
    }

    public BigDecimal getHanKanNetSm() {
        return this.hanKanNetSm;
    }

    public void setHanKanNetSm(BigDecimal hanKanNetSm) {
        this.hanKanNetSm = hanKanNetSm;
    }

    public BigDecimal getHanKanNetSt() {
        return this.hanKanNetSt;
    }

    public void setHanKanNetSt(BigDecimal hanKanNetSt) {
        this.hanKanNetSt = hanKanNetSt;
    }

    public BigDecimal getHanKanNetHb() {
        return this.hanKanNetHb;
    }

    public void setHanKanNetHb(BigDecimal hanKanNetHb) {
        this.hanKanNetHb = hanKanNetHb;
    }

    public BigDecimal getHanKanNetTr() {
        return this.hanKanNetTr;
    }

    public void setHanKanNetTr(BigDecimal hanKanNetTr) {
        this.hanKanNetTr = hanKanNetTr;
    }

    public BigDecimal getHanKanNetFm() {
        return this.hanKanNetFm;
    }

    public void setHanKanNetFm(BigDecimal hanKanNetFm) {
        this.hanKanNetFm = hanKanNetFm;
    }

    public BigDecimal getHanKanNetDiff() {
        return this.hanKanNetDiff;
    }

    public void setHanKanNetDiff(BigDecimal hanKanNetDiff) {
        this.hanKanNetDiff = hanKanNetDiff;
    }

    public BigDecimal getKeihiNetJs() {
        return this.keihiNetJs;
    }

    public void setKeihiNetJs(BigDecimal keihiNetJs) {
        this.keihiNetJs = keihiNetJs;
    }

    public BigDecimal getKeihiNetJt() {
        return this.keihiNetJt;
    }

    public void setKeihiNetJt(BigDecimal keihiNetJt) {
        this.keihiNetJt = keihiNetJt;
    }

    public BigDecimal getKeihiNetMh() {
        return this.keihiNetMh;
    }

    public void setKeihiNetMh(BigDecimal keihiNetMh) {
        this.keihiNetMh = keihiNetMh;
    }

    public BigDecimal getKeihiNetSm() {
        return this.keihiNetSm;
    }

    public void setKeihiNetSm(BigDecimal keihiNetSm) {
        this.keihiNetSm = keihiNetSm;
    }

    public BigDecimal getKeihiNetSt() {
        return this.keihiNetSt;
    }

    public void setKeihiNetSt(BigDecimal keihiNetSt) {
        this.keihiNetSt = keihiNetSt;
    }

    public BigDecimal getKeihiNetHb() {
        return this.keihiNetHb;
    }

    public void setKeihiNetHb(BigDecimal keihiNetHb) {
        this.keihiNetHb = keihiNetHb;
    }

    public BigDecimal getKeihiNetTr() {
        return this.keihiNetTr;
    }

    public void setKeihiNetTr(BigDecimal keihiNetTr) {
        this.keihiNetTr = keihiNetTr;
    }

    public BigDecimal getKeihiNetFm() {
        return this.keihiNetFm;
    }

    public void setKeihiNetFm(BigDecimal keihiNetFm) {
        this.keihiNetFm = keihiNetFm;
    }

    public BigDecimal getKeihiNetDiff() {
        return this.keihiNetDiff;
    }

    public void setKeihiNetDiff(BigDecimal keihiNetDiff) {
        this.keihiNetDiff = keihiNetDiff;
    }

    public BigDecimal getSougenkaNetJs() {
        return this.sougenkaNetJs;
    }

    public void setSougenkaNetJs(BigDecimal sougenkaNetJs) {
        this.sougenkaNetJs = sougenkaNetJs;
    }

    public BigDecimal getSougenkaNetJt() {
        return this.sougenkaNetJt;
    }

    public void setSougenkaNetJt(BigDecimal sougenkaNetJt) {
        this.sougenkaNetJt = sougenkaNetJt;
    }

    public BigDecimal getSougenkaNetMh() {
        return this.sougenkaNetMh;
    }

    public void setSougenkaNetMh(BigDecimal sougenkaNetMh) {
        this.sougenkaNetMh = sougenkaNetMh;
    }

    public BigDecimal getSougenkaNetSm() {
        return this.sougenkaNetSm;
    }

    public void setSougenkaNetSm(BigDecimal sougenkaNetSm) {
        this.sougenkaNetSm = sougenkaNetSm;
    }

    public BigDecimal getSougenkaNetSt() {
        return this.sougenkaNetSt;
    }

    public void setSougenkaNetSt(BigDecimal sougenkaNetSt) {
        this.sougenkaNetSt = sougenkaNetSt;
    }

    public BigDecimal getSougenkaNetHb() {
        return this.sougenkaNetHb;
    }

    public void setSougenkaNetHb(BigDecimal sougenkaNetHb) {
        this.sougenkaNetHb = sougenkaNetHb;
    }

    public BigDecimal getSougenkaNetTr() {
        return this.sougenkaNetTr;
    }

    public void setSougenkaNetTr(BigDecimal sougenkaNetTr) {
        this.sougenkaNetTr = sougenkaNetTr;
    }

    public BigDecimal getSougenkaNetFm() {
        return this.sougenkaNetFm;
    }

    public void setSougenkaNetFm(BigDecimal sougenkaNetFm) {
        this.sougenkaNetFm = sougenkaNetFm;
    }

    public BigDecimal getSougenkaNetDiff() {
        return this.sougenkaNetDiff;
    }

    public void setSougenkaNetDiff(BigDecimal sougenkaNetDiff) {
        this.sougenkaNetDiff = sougenkaNetDiff;
    }

    public BigDecimal getKawaseYoyakuNetJs() {
        return this.kawaseYoyakuNetJs;
    }

    public void setKawaseYoyakuNetJs(BigDecimal kawaseYoyakuNetJs) {
        this.kawaseYoyakuNetJs = kawaseYoyakuNetJs;
    }

    public BigDecimal getKawaseYoyakuNetJt() {
        return this.kawaseYoyakuNetJt;
    }

    public void setKawaseYoyakuNetJt(BigDecimal kawaseYoyakuNetJt) {
        this.kawaseYoyakuNetJt = kawaseYoyakuNetJt;
    }

    public BigDecimal getKawaseYoyakuNetMh() {
        return this.kawaseYoyakuNetMh;
    }

    public void setKawaseYoyakuNetMh(BigDecimal kawaseYoyakuNetMh) {
        this.kawaseYoyakuNetMh = kawaseYoyakuNetMh;
    }

    public BigDecimal getKawaseYoyakuNetSm() {
        return this.kawaseYoyakuNetSm;
    }

    public void setKawaseYoyakuNetSm(BigDecimal kawaseYoyakuNetSm) {
        this.kawaseYoyakuNetSm = kawaseYoyakuNetSm;
    }

    public BigDecimal getKawaseYoyakuNetSt() {
        return this.kawaseYoyakuNetSt;
    }

    public void setKawaseYoyakuNetSt(BigDecimal kawaseYoyakuNetSt) {
        this.kawaseYoyakuNetSt = kawaseYoyakuNetSt;
    }

    public BigDecimal getKawaseYoyakuNetHb() {
        return this.kawaseYoyakuNetHb;
    }

    public void setKawaseYoyakuNetHb(BigDecimal kawaseYoyakuNetHb) {
        this.kawaseYoyakuNetHb = kawaseYoyakuNetHb;
    }

    public BigDecimal getKawaseYoyakuNetTr() {
        return this.kawaseYoyakuNetTr;
    }

    public void setKawaseYoyakuNetTr(BigDecimal kawaseYoyakuNetTr) {
        this.kawaseYoyakuNetTr = kawaseYoyakuNetTr;
    }

    public BigDecimal getKawaseYoyakuNetFm() {
        return this.kawaseYoyakuNetFm;
    }

    public void setKawaseYoyakuNetFm(BigDecimal kawaseYoyakuNetFm) {
        this.kawaseYoyakuNetFm = kawaseYoyakuNetFm;
    }

    public BigDecimal getKawaseYoyakuNetDiff() {
        return this.kawaseYoyakuNetDiff;
    }

    public void setKawaseYoyakuNetDiff(BigDecimal kawaseYoyakuNetDiff) {
        this.kawaseYoyakuNetDiff = kawaseYoyakuNetDiff;
    }

    public BigDecimal getSeibanSonekiNetJs() {
        return this.seibanSonekiNetJs;
    }

    public void setSeibanSonekiNetJs(BigDecimal seibanSonekiNetJs) {
        this.seibanSonekiNetJs = seibanSonekiNetJs;
    }

    public BigDecimal getSeibanSonekiNetJt() {
        return this.seibanSonekiNetJt;
    }

    public void setSeibanSonekiNetJt(BigDecimal seibanSonekiNetJt) {
        this.seibanSonekiNetJt = seibanSonekiNetJt;
    }

    public BigDecimal getSeibanSonekiNetMh() {
        return this.seibanSonekiNetMh;
    }

    public void setSeibanSonekiNetMh(BigDecimal seibanSonekiNetMh) {
        this.seibanSonekiNetMh = seibanSonekiNetMh;
    }

    public BigDecimal getSeibanSonekiNetSm() {
        return this.seibanSonekiNetSm;
    }

    public void setSeibanSonekiNetSm(BigDecimal seibanSonekiNetSm) {
        this.seibanSonekiNetSm = seibanSonekiNetSm;
    }

    public BigDecimal getSeibanSonekiNetSt() {
        return this.seibanSonekiNetSt;
    }

    public void setSeibanSonekiNetSt(BigDecimal seibanSonekiNetSt) {
        this.seibanSonekiNetSt = seibanSonekiNetSt;
    }

    public BigDecimal getSeibanSonekiNetHb() {
        return this.seibanSonekiNetHb;
    }

    public void setSeibanSonekiNetHb(BigDecimal seibanSonekiNetHb) {
        this.seibanSonekiNetHb = seibanSonekiNetHb;
    }

    public BigDecimal getSeibanSonekiNetTr() {
        return this.seibanSonekiNetTr;
    }

    public void setSeibanSonekiNetTr(BigDecimal seibanSonekiNetTr) {
        this.seibanSonekiNetTr = seibanSonekiNetTr;
    }

    public BigDecimal getSeibanSonekiNetFm() {
        return this.seibanSonekiNetFm;
    }

    public void setSeibanSonekiNetFm(BigDecimal seibanSonekiNetFm) {
        this.seibanSonekiNetFm = seibanSonekiNetFm;
    }

    public BigDecimal getSeibanSonekiNetDiff() {
        return this.seibanSonekiNetDiff;
    }

    public void setSeibanSonekiNetDiff(BigDecimal seibanSonekiNetDiff) {
        this.seibanSonekiNetDiff = seibanSonekiNetDiff;
    }

    public BigDecimal getKeijousonekinetJs() {
        return this.keijousonekinetJs;
    }

    public void setKeijousonekinetJs(BigDecimal keijousonekinetJs) {
        this.keijousonekinetJs = keijousonekinetJs;
    }

    public BigDecimal getKeijousonekinetJt() {
        return this.keijousonekinetJt;
    }

    public void setKeijousonekinetJt(BigDecimal keijousonekinetJt) {
        this.keijousonekinetJt = keijousonekinetJt;
    }

    public BigDecimal getKeijousonekinetMh() {
        return this.keijousonekinetMh;
    }

    public void setKeijousonekinetMh(BigDecimal keijousonekinetMh) {
        this.keijousonekinetMh = keijousonekinetMh;
    }

    public BigDecimal getKeijousonekinetSm() {
        return this.keijousonekinetSm;
    }

    public void setKeijousonekinetSm(BigDecimal keijousonekinetSm) {
        this.keijousonekinetSm = keijousonekinetSm;
    }

    public BigDecimal getKeijousonekinetSt() {
        return this.keijousonekinetSt;
    }

    public void setKeijousonekinetSt(BigDecimal keijousonekinetSt) {
        this.keijousonekinetSt = keijousonekinetSt;
    }

    public BigDecimal getKeijousonekinetHb() {
        return this.keijousonekinetHb;
    }

    public void setKeijousonekinetHb(BigDecimal keijousonekinetHb) {
        this.keijousonekinetHb = keijousonekinetHb;
    }

    public BigDecimal getKeijousonekinetTr() {
        return this.keijousonekinetTr;
    }

    public void setKeijousonekinetTr(BigDecimal keijousonekinetTr) {
        this.keijousonekinetTr = keijousonekinetTr;
    }

    public BigDecimal getKeijousonekinetFm() {
        return this.keijousonekinetFm;
    }

    public void setKeijousonekinetFm(BigDecimal keijousonekinetFm) {
        this.keijousonekinetFm = keijousonekinetFm;
    }

    public BigDecimal getKeijousonekinetDiff() {
        return this.keijousonekinetDiff;
    }

    public void setKeijousonekinetDiff(BigDecimal keijousonekinetDiff) {
        this.keijousonekinetDiff = keijousonekinetDiff;
    }

    public BigDecimal getHanChokuNetPd() {
        return hanChokuNetPd;
    }

    public void setHanChokuNetPd(BigDecimal hanChokuNetPd) {
        this.hanChokuNetPd = hanChokuNetPd;
    }

    public BigDecimal getHanChokuNetPt() {
        return hanChokuNetPt;
    }

    public void setHanChokuNetPt(BigDecimal hanChokuNetPt) {
        this.hanChokuNetPt = hanChokuNetPt;
    }

    public BigDecimal getHanChokuNetPs() {
        return hanChokuNetPs;
    }

    public void setHanChokuNetPs(BigDecimal hanChokuNetPs) {
        this.hanChokuNetPs = hanChokuNetPs;
    }

    public BigDecimal getIspNetPd() {
        return ispNetPd;
    }

    public void setIspNetPd(BigDecimal ispNetPd) {
        this.ispNetPd = ispNetPd;
    }

    public BigDecimal getIspNetPt() {
        return ispNetPt;
    }

    public void setIspNetPt(BigDecimal ispNetPt) {
        this.ispNetPt = ispNetPt;
    }

    public BigDecimal getIspNetPs() {
        return ispNetPs;
    }

    public void setIspNetPs(BigDecimal ispNetPs) {
        this.ispNetPs = ispNetPs;
    }

    public BigDecimal getHanKanNetPd() {
        return hanKanNetPd;
    }

    public void setHanKanNetPd(BigDecimal hanKanNetPd) {
        this.hanKanNetPd = hanKanNetPd;
    }

    public BigDecimal getHanKanNetPt() {
        return hanKanNetPt;
    }

    public void setHanKanNetPt(BigDecimal hanKanNetPt) {
        this.hanKanNetPt = hanKanNetPt;
    }

    public BigDecimal getHanKanNetPs() {
        return hanKanNetPs;
    }

    public void setHanKanNetPs(BigDecimal hanKanNetPs) {
        this.hanKanNetPs = hanKanNetPs;
    }

    public BigDecimal getKeihiNetPd() {
        return keihiNetPd;
    }

    public void setKeihiNetPd(BigDecimal keihiNetPd) {
        this.keihiNetPd = keihiNetPd;
    }

    public BigDecimal getKeihiNetPt() {
        return keihiNetPt;
    }

    public void setKeihiNetPt(BigDecimal keihiNetPt) {
        this.keihiNetPt = keihiNetPt;
    }

    public BigDecimal getKeihiNetPs() {
        return keihiNetPs;
    }

    public void setKeihiNetPs(BigDecimal keihiNetPs) {
        this.keihiNetPs = keihiNetPs;
    }

    public BigDecimal getSougenkaNetPd() {
        return sougenkaNetPd;
    }

    public void setSougenkaNetPd(BigDecimal sougenkaNetPd) {
        this.sougenkaNetPd = sougenkaNetPd;
    }

    public BigDecimal getSougenkaNetPt() {
        return sougenkaNetPt;
    }

    public void setSougenkaNetPt(BigDecimal sougenkaNetPt) {
        this.sougenkaNetPt = sougenkaNetPt;
    }

    public BigDecimal getSougenkaNetPs() {
        return sougenkaNetPs;
    }

    public void setSougenkaNetPs(BigDecimal sougenkaNetPs) {
        this.sougenkaNetPs = sougenkaNetPs;
    }

    public BigDecimal getKawaseYoyakuNetPd() {
        return kawaseYoyakuNetPd;
    }

    public void setKawaseYoyakuNetPd(BigDecimal kawaseYoyakuNetPd) {
        this.kawaseYoyakuNetPd = kawaseYoyakuNetPd;
    }

    public BigDecimal getKawaseYoyakuNetPt() {
        return kawaseYoyakuNetPt;
    }

    public void setKawaseYoyakuNetPt(BigDecimal kawaseYoyakuNetPt) {
        this.kawaseYoyakuNetPt = kawaseYoyakuNetPt;
    }

    public BigDecimal getKawaseYoyakuNetPs() {
        return kawaseYoyakuNetPs;
    }

    public void setKawaseYoyakuNetPs(BigDecimal kawaseYoyakuNetPs) {
        this.kawaseYoyakuNetPs = kawaseYoyakuNetPs;
    }

    public BigDecimal getSeibanSonekiNetPd() {
        return seibanSonekiNetPd;
    }

    public void setSeibanSonekiNetPd(BigDecimal seibanSonekiNetPd) {
        this.seibanSonekiNetPd = seibanSonekiNetPd;
    }

    public BigDecimal getSeibanSonekiNetPt() {
        return seibanSonekiNetPt;
    }

    public void setSeibanSonekiNetPt(BigDecimal seibanSonekiNetPt) {
        this.seibanSonekiNetPt = seibanSonekiNetPt;
    }

    public BigDecimal getSeibanSonekiNetPs() {
        return seibanSonekiNetPs;
    }

    public void setSeibanSonekiNetPs(BigDecimal seibanSonekiNetPs) {
        this.seibanSonekiNetPs = seibanSonekiNetPs;
    }

    public BigDecimal getKeijousonekinetPd() {
        return keijousonekinetPd;
    }

    public void setKeijousonekinetPd(BigDecimal keijousonekinetPd) {
        this.keijousonekinetPd = keijousonekinetPd;
    }

    public BigDecimal getKeijousonekinetPt() {
        return keijousonekinetPt;
    }

    public void setKeijousonekinetPt(BigDecimal keijousonekinetPt) {
        this.keijousonekinetPt = keijousonekinetPt;
    }

    public BigDecimal getKeijousonekinetPs() {
        return keijousonekinetPs;
    }

    public void setKeijousonekinetPs(BigDecimal keijousonekinetPs) {
        this.keijousonekinetPs = keijousonekinetPs;
    }

    public BigDecimal getHanChokuNetPrev() {
        return hanChokuNetPrev;
    }

    public void setHanChokuNetPrev(BigDecimal hanChokuNetPrev) {
        this.hanChokuNetPrev = hanChokuNetPrev;
    }

    public BigDecimal getIspNetPrev() {
        return ispNetPrev;
    }

    public void setIspNetPrev(BigDecimal ispNetPrev) {
        this.ispNetPrev = ispNetPrev;
    }

    public BigDecimal getHanKanNetPrev() {
        return hanKanNetPrev;
    }

    public void setHanKanNetPrev(BigDecimal hanKanNetPrev) {
        this.hanKanNetPrev = hanKanNetPrev;
    }

    public BigDecimal getKeihiNetPrev() {
        return keihiNetPrev;
    }

    public void setKeihiNetPrev(BigDecimal keihiNetPrev) {
        this.keihiNetPrev = keihiNetPrev;
    }

    public BigDecimal getSougenkaNetPrev() {
        return sougenkaNetPrev;
    }

    public void setSougenkaNetPrev(BigDecimal sougenkaNetPrev) {
        this.sougenkaNetPrev = sougenkaNetPrev;
    }

    public BigDecimal getKawaseYoyakuNetPrev() {
        return kawaseYoyakuNetPrev;
    }

    public void setKawaseYoyakuNetPrev(BigDecimal kawaseYoyakuNetPrev) {
        this.kawaseYoyakuNetPrev = kawaseYoyakuNetPrev;
    }

    public BigDecimal getSeibanSonekiNetPrev() {
        return seibanSonekiNetPrev;
    }

    public void setSeibanSonekiNetPrev(BigDecimal seibanSonekiNetPrev) {
        this.seibanSonekiNetPrev = seibanSonekiNetPrev;
    }

    public BigDecimal getKeijousonekinetPrev() {
        return keijousonekinetPrev;
    }

    public void setKeijousonekinetPrev(BigDecimal keijousonekinetPrev) {
        this.keijousonekinetPrev = keijousonekinetPrev;
    }

    public BigDecimal getEigyogaiJs() {
        return eigyogaiJs;
    }

    public void setEigyogaiJs(BigDecimal eigyogaiJs) {
        this.eigyogaiJs = eigyogaiJs;
    }

    public BigDecimal getEigyogaiJt() {
        return eigyogaiJt;
    }

    public void setEigyogaiJt(BigDecimal eigyogaiJt) {
        this.eigyogaiJt = eigyogaiJt;
    }

    public BigDecimal getEigyogaiMh() {
        return eigyogaiMh;
    }

    public void setEigyogaiMh(BigDecimal eigyogaiMh) {
        this.eigyogaiMh = eigyogaiMh;
    }

    public BigDecimal getEigyogaiSm() {
        return eigyogaiSm;
    }

    public void setEigyogaiSm(BigDecimal eigyogaiSm) {
        this.eigyogaiSm = eigyogaiSm;
    }

    public BigDecimal getEigyogaiSt() {
        return eigyogaiSt;
    }

    public void setEigyogaiSt(BigDecimal eigyogaiSt) {
        this.eigyogaiSt = eigyogaiSt;
    }

    public BigDecimal getEigyogaiHb() {
        return eigyogaiHb;
    }

    public void setEigyogaiHb(BigDecimal eigyogaiHb) {
        this.eigyogaiHb = eigyogaiHb;
    }

    public BigDecimal getEigyogaiTr() {
        return eigyogaiTr;
    }

    public void setEigyogaiTr(BigDecimal eigyogaiTr) {
        this.eigyogaiTr = eigyogaiTr;
    }

    public BigDecimal getEigyogaiFm() {
        return eigyogaiFm;
    }

    public void setEigyogaiFm(BigDecimal eigyogaiFm) {
        this.eigyogaiFm = eigyogaiFm;
    }

    public BigDecimal getEigyogaiPd() {
        return eigyogaiPd;
    }

    public void setEigyogaiPd(BigDecimal eigyogaiPd) {
        this.eigyogaiPd = eigyogaiPd;
    }

    public BigDecimal getEigyogaiPt() {
        return eigyogaiPt;
    }

    public void setEigyogaiPt(BigDecimal eigyogaiPt) {
        this.eigyogaiPt = eigyogaiPt;
    }

    public BigDecimal getEigyogaiPs() {
        return eigyogaiPs;
    }

    public void setEigyogaiPs(BigDecimal eigyogaiPs) {
        this.eigyogaiPs = eigyogaiPs;
    }

    public BigDecimal getEigyogaiPrev() {
        return eigyogaiPrev;
    }

    public void setEigyogaiPrev(BigDecimal eigyogaiPrev) {
        this.eigyogaiPrev = eigyogaiPrev;
    }

    public BigDecimal getEigyogaiDiff() {
        return eigyogaiDiff;
    }

    public void setEigyogaiDiff(BigDecimal eigyogaiDiff) {
        this.eigyogaiDiff = eigyogaiDiff;
    }

}
