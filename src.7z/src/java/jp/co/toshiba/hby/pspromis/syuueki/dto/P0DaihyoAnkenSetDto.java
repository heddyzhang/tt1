package jp.co.toshiba.hby.pspromis.syuueki.dto;

import lombok.Getter;
import lombok.Setter;

/**
 * ES-Promis収益管理システム
 * 収益対象FLG付け替え時の案件データ入れ替えパッケージのパラメータ
 * @author ibayashi
 */
@Getter @Setter
public class P0DaihyoAnkenSetDto {
   
    /**
     * 注番の代表案件
     */
    private String daihyoAnkenId;
    
    /**
     * 収益対象FLGを解除する案件
     */
    private String invaildAnkenId;
    
    /**
     * 対象の注番
     */
    private String ankenOrderNo;

    /**
     * 処理結果(0:成功、9:失敗)
     */
    private String errFlg;
    
    /**
     * エラー内容
     */
    private String errMsg;
    
    /**
     * 実行したパッケージ名
     */
    private String exeProcedureName;

}