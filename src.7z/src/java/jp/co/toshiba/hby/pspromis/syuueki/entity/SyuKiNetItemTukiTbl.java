/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package jp.co.toshiba.hby.pspromis.syuueki.entity;

import java.io.Serializable;
import java.util.Date;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

/**
 *
 * @author rnomura
 */
@Entity
@Table(name = "SYU_KI_NET_ITEM_TUKI_TBL")
public class SyuKiNetItemTukiTbl implements Serializable {

    private static final long serialVersionUID = 1L;
    @Basic(optional = false)
    @Id
    @NotNull
    @Size(min = 1, max = 32)
    @Column(name = "ANKEN_ID")
    private String ankenId;
    @Basic(optional = false)
    @Id
    @NotNull
    @Column(name = "RIREKI_ID")
    private int rirekiId;
    @Basic(optional = false)
    @Id
    @NotNull
    @Size(min = 1, max = 2)
    @Column(name = "DATA_KBN")
    private String dataKbn;
    @Basic(optional = false)
    @Id
    @NotNull
    @Size(min = 1, max = 12)
    @Column(name = "ORDER_NO")
    private String orderNo;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 15)
    @Column(name = "ORDER_ITEM")
    @Id
    private String orderItem;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 7)
    @Column(name = "SYUEKI_YM")
    @Id
    private String syuekiYm;
    @Column(name = "CYUNYU_NET")
    private Long cyunyuNet;
    @Column(name = "URIAGE_NET")
    private Long uriageNet;
    @Column(name = "SEIBAN_SONEKI_NET")
    private Long seibanSonekiNet;
    @Column(name = "FIXED_MIKOMI_NET")
    private Long fixedMikomiNet;
    @Column(name = "CREATED_AT")
    @Temporal(TemporalType.DATE)
    private Date createdAt;
    @Size(max = 32)
    @Column(name = "CREATED_BY")
    private String createdBy;
    @Column(name = "UPDATED_AT")
    @Temporal(TemporalType.DATE)
    private Date updatedAt;
    @Size(max = 32)
    @Column(name = "UPDATED_BY")
    private String updatedBy;
    @Column(name = "UPDATED_BATCH_AT")
    @Temporal(TemporalType.DATE)
    private Date updatedBatchAt;
    @Size(max = 32)
    @Column(name = "UPDATED_BATCH_BY")
    private String updatedBatchBy;

    public SyuKiNetItemTukiTbl() {
    }

    public String getAnkenId() {
        return ankenId;
    }

    public void setAnkenId(String ankenId) {
        this.ankenId = ankenId;
    }

    public int getRirekiId() {
        return rirekiId;
    }

    public void setRirekiId(int rirekiId) {
        this.rirekiId = rirekiId;
    }

    public String getDataKbn() {
        return dataKbn;
    }

    public void setDataKbn(String dataKbn) {
        this.dataKbn = dataKbn;
    }

    public String getOrderNo() {
        return orderNo;
    }

    public void setOrderNo(String orderNo) {
        this.orderNo = orderNo;
    }

    public String getOrderItem() {
        return orderItem;
    }

    public void setOrderItem(String orderItem) {
        this.orderItem = orderItem;
    }

    public String getSyuekiYm() {
        return syuekiYm;
    }

    public void setSyuekiYm(String syuekiYm) {
        this.syuekiYm = syuekiYm;
    }

    public Long getCyunyuNet() {
        return cyunyuNet;
    }

    public void setCyunyuNet(Long cyunyuNet) {
        this.cyunyuNet = cyunyuNet;
    }

    public Long getUriageNet() {
        return uriageNet;
    }

    public void setUriageNet(Long uriageNet) {
        this.uriageNet = uriageNet;
    }

    public Long getSeibanSonekiNet() {
        return seibanSonekiNet;
    }

    public void setSeibanSonekiNet(Long seibanSonekiNet) {
        this.seibanSonekiNet = seibanSonekiNet;
    }

    public Long getFixedMikomiNet() {
        return fixedMikomiNet;
    }

    public void setFixedMikomiNet(Long fixedMikomiNet) {
        this.fixedMikomiNet = fixedMikomiNet;
    }

    public Date getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(Date createdAt) {
        this.createdAt = createdAt;
    }

    public String getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    public Date getUpdatedAt() {
        return updatedAt;
    }

    public void setUpdatedAt(Date updatedAt) {
        this.updatedAt = updatedAt;
    }

    public String getUpdatedBy() {
        return updatedBy;
    }

    public void setUpdatedBy(String updatedBy) {
        this.updatedBy = updatedBy;
    }

    public Date getUpdatedBatchAt() {
        return updatedBatchAt;
    }

    public void setUpdatedBatchAt(Date updatedBatchAt) {
        this.updatedBatchAt = updatedBatchAt;
    }

    public String getUpdatedBatchBy() {
        return updatedBatchBy;
    }

    public void setUpdatedBatchBy(String updatedBatchBy) {
        this.updatedBatchBy = updatedBatchBy;
    }
    
}
