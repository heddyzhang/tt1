package jp.co.toshiba.hby.pspromis.syuueki.service.download;

import java.math.BigDecimal;
import java.util.ArrayList;
import jp.co.toshiba.hby.pspromis.syuueki.service.*;
import java.util.Date;
import java.util.List;
import java.util.Map;
import javax.ejb.Stateless;
import javax.inject.Inject;
import javax.interceptor.Interceptors;
import jp.co.toshiba.hby.pspromis.syuueki.bean.AggregateConditionBean;
import jp.co.toshiba.hby.pspromis.syuueki.bean.S022Bean;
//import jp.co.toshiba.hby.pspromis.syuueki.entity.OperationLog;
//import jp.co.toshiba.hby.pspromis.syuueki.entity.SyuGeBukkenInfoTbl;
//import jp.co.toshiba.hby.pspromis.syuueki.entity.SyuGeNetItemTblView;
import jp.co.toshiba.hby.pspromis.syuueki.enums.Label;
import jp.co.toshiba.hby.pspromis.syuueki.facade.SysdateEntityFacade;
import jp.co.toshiba.hby.pspromis.syuueki.facade.SyuGeNetItemTblViewFacade;
import jp.co.toshiba.hby.pspromis.syuueki.interceptor.TranceInterceptor;
import jp.co.toshiba.hby.pspromis.syuueki.pages.DetailHeader;
import jp.co.toshiba.hby.pspromis.syuueki.util.LoginUserInfo;
import jp.co.toshiba.hby.pspromis.syuueki.util.PoiUtil;
import jp.co.toshiba.hby.pspromis.syuueki.util.SyuuekiUtils;
import jp.co.toshiba.hby.pspromis.syuueki.util.Utils;
//import org.apache.commons.lang3.StringUtils;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
/**
 * PS-Promis収益管理システム
 * 項番一覧（期間）Excelダウンロード Service
 * @author (NPC)Y.Kitajima
 */
@Stateless
@Interceptors({TranceInterceptor.class})
public class ShukeiListService {
    
    @Inject
    private LoginUserInfo loginUserInfo;
    
    @Inject
    private OperationLogService operationLogService;
    
    @Inject
    private SysdateEntityFacade sysdateFacade;
    
    @Inject
    private SyuGeNetItemTblViewFacade syuGeNetItemTblViewFacade;
    
    @Inject
    private S022Bean s022Bean;
    
    @Inject
    private AggregateConditionBean aggregateConditionBean;
    
    //@Inject
    //private DetailHeader dateilHeader;
    
    @Inject
    private S022Service s022Service;
    
    @Inject
    private SyuuekiUtils sUtils;

    
    /**
     * ロガー
     */
    public static final Logger logger = LoggerFactory.getLogger(KobanListService.class);
    
    /**
     * 操作ログの登録
     * @throws Exception
     */
//    public void registOperationLog() throws Exception{
//        OperationLog operationLog = this.operationLogService.getOperationLog();
//
//        operationLog.setOperationCode("DL_JOB");
//        operationLog.setObjectId(10);
//        operationLog.setObjectType("KOUBAN");
//        operationLog.setRemarks(s005Bean.getAnkenId());
//        //operationLogService.insertOperationLogSearch(operationLog);
//        
//        operationLogService.insertOperationLogSearch(operationLog);
//    }


    /**
     * Excelダウンロードのデータ埋め込み
     * @param workbook
     * @throws Exception
     */
    public void outputDownloadExcel(Workbook workbook) throws Exception {
        
        // シート取得
        Sheet sheet = workbook.getSheet("shukeiList");
        // スタイルコピー用シートを取得
        Sheet styleSheet = workbook.getSheet("shukeiList_style");
        
        // シート名の設定
        //final String sheetName = "集計リスト";
        //workbook.setSheetName(workbook.getSheetIndex(sheet), sheetName);
        
        // データセット開始行
        int rowNum;
        
        //検索条件から各ラベルリストを作成する
        s022Service.setResultSytle();
        
        // ヘッダ情報をセット
        rowNum = setHeadData(sheet);
        
        s022Service.getSearchResult();
        
        // ヘッダ部の合計値をセット
        rowNum = setSumData(sheet, rowNum);
        
        // 一覧項目のタイトルセット
        setListDataTitle(sheet, styleSheet, rowNum);
        
        // 一覧項目のセット
        setListData(sheet, styleSheet, rowNum);
        
        // スタイルコピー用シートの削除
        //workbook.removeSheetAt(workbook.getSheetIndex(styleSheet));
        
        // 操作ログへの書き込み
        // (案件一覧の一括出力処理から出力した場合はここでのログ書き込みは行わない)
        //if (!s005Bean.isIsIkkatsuFlg()) {
        //    registOperationLog();
        //}
    }
    
    /**
     * ヘッダ情報のデータ埋め込み
     */
    private int setHeadData(Sheet sheet) throws Exception {
        int rowNum = 6;
        int headStart = 6;
        
        // 出力日時取得
        Date now = sysdateFacade.getSysdate();
        
        ////// ヘッダ情報セット
        //// ログイン者名
        PoiUtil.setCellValue(sheet, 0, 3, loginUserInfo.getUserName());
        //// 現在日時
        PoiUtil.setCellValue(sheet, 0, 5, now);
        PoiUtil.addMergedRegion(sheet, 0, 5, 0, 6);
        
        // ヘッダー部円価単位のセット
        String unit = "";
        if(aggregateConditionBean.getJpyUnit().equals("3")){
            unit = Label.jpyUnit3.getLabel();
        } else if(aggregateConditionBean.getJpyUnit().equals("2")){
            unit = Label.jpyUnit2.getLabel();
        } else {
            unit = Label.jpyUnit1.getLabel();
        }
        PoiUtil.setCellValue(sheet, 0, 8, unit);
        
        // ヘッダー部対象データのセット
        PoiUtil.setCellValue(sheet, 2, 4, aggregateConditionBean.getHeadTargetData());
        
        // ヘッダー部出力項目のセット
        PoiUtil.setCellValue(sheet, 2, 9, aggregateConditionBean.getHeadOutputItems());
        
        // [回収は税込です]文言の出力
        PoiUtil.setCellValue(sheet, 6, 4, Label.kaisyuZeiKomi.getLabel());
        
        // 「月」「期」ラベル行
        Row yokozikuAggRow = PoiUtil.getRow(sheet, rowNum);
        List<Cell> yokozikuAggList = PoiUtil.getCellList(yokozikuAggRow, headStart, 4);
        
        // 「SP」「NET」「粗利」「M率」ラベル行
        Row labelRow = PoiUtil.getRow(sheet, rowNum+1);
        List<Cell> labelList = PoiUtil.getCellList(labelRow, headStart, 4);
         
 
        for(Map<String, Object> map : aggregateConditionBean.getYokozikuList()){
            // 「月」「期」ラベル行スタイルコピー
            PoiUtil.copyRowStyleValue(yokozikuAggRow, yokozikuAggList, headStart, false, false);
            PoiUtil.setCellValue(sheet, rowNum, headStart, map.get("dispLabel"));
            PoiUtil.addMergedRegion(sheet, rowNum, headStart, rowNum, headStart+3);
            
            // 「SP」「NET」「粗利」「M率」ラベル行コピー
            PoiUtil.copyRowStyleValue(labelRow, labelList, headStart, true, false);
            
            headStart += 4;
        }
        
        rowNum += 2;
        
        return rowNum;

    }

    
    /**
     * 総計値のデータ埋め込み
     */
    private int setSumData(Sheet sheet, int rowNumber) throws Exception {
        // データ開始行number
        int rowNum = rowNumber;
        // 総計データスタートCol
        int startCol = 1;
        
        // 円価単位
        String jpyUnit = aggregateConditionBean.getJpyUnit();
        
        // 総計行スタイルリスト
        Row sumRow = PoiUtil.getRow(sheet, rowNum);
        List<Cell> sumHeadStyleList = PoiUtil.getCellList(sumRow, startCol, 5);
        List<Cell> sumDataStyleList = PoiUtil.getCellList(sumRow, startCol+5, 4);
        
        // 総計行の取得
        Map<String, Object> sumData = s022Bean.getAggregateList().get(0);
        
        // 「総計」ラベルセット
        PoiUtil.setCellValue(sheet, rowNum, startCol, Label.grandTotal.getLabel());
        // 「今回」ラベルセット
        PoiUtil.setCellValue(sheet, rowNum, startCol+3, Label.now.getLabel());
        
        for(String label : aggregateConditionBean.getOutputLabelList()){
            // データ埋め込み行
            Row dataRow = PoiUtil.getRow(sheet, rowNum, true);
            //　出力単位変更毎にタイトル部スタイルのコピー
            PoiUtil.copyRowStyleValue(dataRow, sumHeadStyleList, startCol, false, false);
            
            int sumDataStartCol = 6;

            // 出力項目ラベルセット
            PoiUtil.setCellValue(sheet, rowNum, startCol+4, label);

            // 横軸ラベルのループ
            int labelCol = 0;
            for(Map<String, Object> map : aggregateConditionBean.getYokozikuList()){
                String outputKey = "";
                if(label.equals(Label.jyuchu.getLabel())){
                    outputKey = "J_";
                } else if(label.equals(Label.uriage.getLabel())){
                    outputKey = "U_";
                } else {
                    outputKey = "K_";
                }
                
                PoiUtil.copyRowStyleValue(dataRow, sumDataStyleList, sumDataStartCol+(labelCol * 4), false, false);
                
                // 総計データSPセット
                PoiUtil.setCellValue(sheet, rowNum, sumDataStartCol+(labelCol * 4) , sUtils.changeUnit(convBigDecimal(sumData.get(outputKey + "SP_NOW"+String.valueOf(labelCol))), jpyUnit));
                // 総計データNETセット
                PoiUtil.setCellValue(sheet, rowNum, sumDataStartCol+(labelCol * 4)+1 , sUtils.changeUnit(convBigDecimal(sumData.get(outputKey + "NET_NOW"+String.valueOf(labelCol))), jpyUnit));
                // 総計データ粗利セット
                PoiUtil.setCellValue(sheet, rowNum, sumDataStartCol+(labelCol * 4)+2 , sUtils.changeUnit(sUtils.arari(convBigDecimal(sumData.get(outputKey + "SP_NOW"+String.valueOf(labelCol))), convBigDecimal(sumData.get(outputKey + "NET_NOW"+String.valueOf(labelCol)))), jpyUnit));
                // 総計データM率セット
                PoiUtil.setCellValue(sheet, rowNum, sumDataStartCol+(labelCol * 4)+3 , sUtils.mrate(convBigDecimal(sumData.get(outputKey + "SP_NOW"+String.valueOf(labelCol))), convBigDecimal(sumData.get(outputKey + "NET_NOW"+String.valueOf(labelCol)))));
                
                labelCol += 1;
            }
            rowNum += 1;
        }

        PoiUtil.addMergedRegion(sheet, rowNumber, startCol, rowNumber + (aggregateConditionBean.getOutputLabelList().size()-1), startCol+2);
        PoiUtil.addMergedRegion(sheet, rowNumber, startCol+3, rowNumber + (aggregateConditionBean.getOutputLabelList().size()-1), startCol+3);

        return rowNum;
    }
    
    
    
    /**
     * 一覧データのタイトル埋め込み
     */
    private void setListDataTitle(Sheet sheet, Sheet styleSheet, int rowNumber) throws Exception {
        
        // 一覧データ描画開始行
        int dataStartRow = rowNumber;
        // 一覧データ描画開始列
        int dataStartCol = 1;
        int colIdx = 0;
        
        int comSpan = aggregateConditionBean.getComparisonRowspan();
        int secSpan = aggregateConditionBean.getSecondaryRowspan();
        
        boolean firstFlg = true;
        // 取得データのループ
        for(Map<String, Object> aggData: s022Bean.getAggregateList()){
            //総計行はとばす
            if(String.valueOf(aggData.get("TOTAL_KBN")).equals("0")){
                continue;
            } else  if(String.valueOf(aggData.get("TOTAL_KBN")).equals("1")){
                // 0次集計ラベルセット
                PoiUtil.setCellValue(sheet, dataStartRow, dataStartCol, aggData.get("KEY0_NAME"));
                PoiUtil.addMergedRegion(sheet, dataStartRow, dataStartCol, dataStartRow + secSpan-1, dataStartCol + 2);
            } else if(String.valueOf(aggData.get("TOTAL_KBN")).equals("2")){
                // 1次集計ラベルセット
                PoiUtil.setCellValue(sheet, dataStartRow, dataStartCol + 1, aggData.get("KEY1_NAME"));
                PoiUtil.addMergedRegion(sheet, dataStartRow, dataStartCol + 1, dataStartRow + secSpan-1, dataStartCol + 2);
            } else {
                // 2次集計ラベルセット
                PoiUtil.setCellValue(sheet, dataStartRow, dataStartCol + 2, aggData.get("KEY2_NAME"));
                PoiUtil.addMergedRegion(sheet, dataStartRow, dataStartCol + 2, dataStartRow + secSpan-1, dataStartCol + 2);
            }

            // 比較データラベルのループ
            for(String comparisonLabel: aggregateConditionBean.getComparisonLabelList()){
                List<Cell> titleStyleList = getRowTitleStyle(styleSheet, aggData, comparisonLabel);
                // 「今回」「前回」「差」ラベルセット
                PoiUtil.setCellValue(sheet, dataStartRow, dataStartCol+3, comparisonLabel);
                PoiUtil.addMergedRegion(sheet, dataStartRow, dataStartCol+3, dataStartRow + comSpan-1, dataStartCol+3);
                
                // 出力項目ラベルのループ
                for(String output : aggregateConditionBean.getOutputLabelList()){
                    // データ埋め込み行
                    Row dataRow = PoiUtil.getRow(sheet, dataStartRow, true);
                    // 出力項目ラベルセット
                    PoiUtil.setCellValue(sheet, dataStartRow, dataStartCol+4, output);
                    //　出力単位変更毎にタイトル部スタイルのコピー
                    PoiUtil.copyRowStyleValue(dataRow, titleStyleList, dataStartCol, false, false);
                    
                    dataStartRow += 1;
                }
            
            }
            
            firstFlg = true;
        }

        
    }
    
    /**
     * 一覧データの埋め込み
     */
    private void setListData(Sheet sheet, Sheet styleSheet, int rowNumber) throws Exception {
        
        // 一覧データ描画開始行
        int dataStartRow = rowNumber;
        // 一覧データ描画開始列
        int dataStartCol = 6;
        
        String comparison = "";
        String outItem = "";
        
        // 円価単位
        String jpyUnit = aggregateConditionBean.getJpyUnit();
        
        boolean firstFlg = true;
        // 取得データのループ
        for(Map<String, Object> aggData: s022Bean.getAggregateList()){
            //総計行はとばす
            if(String.valueOf(aggData.get("TOTAL_KBN")).equals("0")){
                continue;
            }

            // 比較データラベルのループ
            for(String comparisonLabel: aggregateConditionBean.getComparisonLabelList()){
                List<Cell> dataStyleList = getRowDataStyle(styleSheet, aggData, comparisonLabel);
                
                // 取得用keyを判断
                if(comparisonLabel.equals(Label.now.getLabel())){
                    comparison = "NOW";
                } else if(comparisonLabel.equals(Label.before.getLabel())){
                    comparison = "BEF";
                } else {
                    comparison = "DIF";
                }
                
                // 出力項目ラベルのループ
                for(String output : aggregateConditionBean.getOutputLabelList()){
                    // データ埋め込み行
                    Row dataRow = PoiUtil.getRow(sheet, dataStartRow, true);
                    
                    // 取得用keyを判断
                    if(output.equals(Label.jyuchu.getLabel())){
                        outItem = "J_";
                    } else if(output.equals(Label.uriage.getLabel())){
                        outItem = "U_";
                    } else {
                        outItem = "K_";
                    }
                    
                    int colIdx = 0;
                    for(Map<String, Object> map : aggregateConditionBean.getYokozikuList()){
                        PoiUtil.copyRowStyleValue(dataRow, dataStyleList, dataStartCol+(colIdx * 4), false, false);

                        // 総計データSPセット
                        PoiUtil.setCellValue(sheet, dataStartRow, dataStartCol+(colIdx * 4) , sUtils.changeUnit(convBigDecimal(aggData.get(outItem + "SP_" + comparison + String.valueOf(colIdx))), jpyUnit));
                        // 総計データNETセット
                        PoiUtil.setCellValue(sheet, dataStartRow, dataStartCol+(colIdx * 4)+1 , sUtils.changeUnit(convBigDecimal(aggData.get(outItem + "NET_" + comparison + String.valueOf(colIdx))), jpyUnit));
                        // 総計データ粗利セット
                        PoiUtil.setCellValue(sheet, dataStartRow, dataStartCol+(colIdx * 4)+2 , sUtils.changeUnit(sUtils.arari(convBigDecimal(aggData.get(outItem + "SP_" + comparison + String.valueOf(colIdx))), convBigDecimal(aggData.get(outItem + "NET_" + comparison + String.valueOf(colIdx)))), jpyUnit));
                        // 総計データM率セット
                        PoiUtil.setCellValue(sheet, dataStartRow, dataStartCol+(colIdx * 4)+3 , sUtils.mrate(convBigDecimal(aggData.get(outItem + "SP_" + comparison + String.valueOf(colIdx))), convBigDecimal(aggData.get(outItem + "NET_" + comparison + String.valueOf(colIdx)))));

                        colIdx += 1;
                    }
                    
                    dataStartRow += 1;
                }
            }
        }

        //最終行用上ラインセット
        Row dataStyleRow = PoiUtil.getRow(styleSheet, 21, true);
        List<Cell> styleList = PoiUtil.getCellList(dataStyleRow, 1, 2);
        Row lineRow = PoiUtil.getRow(sheet, dataStartRow, true);
        PoiUtil.copyRowStyleValue(lineRow, styleList, 1, false, false);
    }
    
    /**
     * タイトル部スタイル取得処理
     * @param sheet
     * @param data
     * @param label
     * @return 
     */
    private List<Cell> getRowTitleStyle(Sheet sheet, Map<String, Object> data, String label) {
        int row;

        //if(aggregateConditionBean.getPrimaryUnit().equals("1")){
        //if (aggregateConditionBean.getPrimaryUnit().equals("0") || aggregateConditionBean.getPrimaryUnit().equals("2")) {
        if (aggregateConditionBean.isPrimaryUnitBuka()) {
            ////// 第1次集計が「営業課(0)」「主管課(2)」等が選択されて、部と課で集計欄を分ける場合
            // 0次集計データ(部)の場合
            if(String.valueOf(data.get("TOTAL_KBN")).equals("1")){
                if(label.equals(Label.now.getLabel())){
                    row = 3;
                } else if(label.equals(Label.before.getLabel())){
                    row = 4;
                } else {
                    row = 5;
                }
            } 
            // 1次集計データ(課)の場合
            else if(String.valueOf(data.get("TOTAL_KBN")).equals("2")){
                if(label.equals(Label.now.getLabel())){
                    row = 6;
                } else if(label.equals(Label.before.getLabel())){
                    row = 7;
                } else {
                    row = 8;
                }
            }
            // 2次集計データの場合
            else {
                if(label.equals(Label.now.getLabel())){
                    row = 9;
                } else if(label.equals(Label.before.getLabel())){
                    row = 10;
                } else {
                    row = 11;
                }
            }

        } else {

            // 1次集計データの場合
            if(String.valueOf(data.get("TOTAL_KBN")).equals("1")){
                if(label.equals(Label.now.getLabel())){
                    row = 14;
                } else if(label.equals(Label.before.getLabel())){
                    row = 15;
                } else {
                    row = 16;
                }
            } 
            // 2次集計データの場合
            else{
                if(label.equals(Label.now.getLabel())){
                    row = 17;
                } else if(label.equals(Label.before.getLabel())){
                    row = 18;
                } else {
                    row = 19;
                }
            }
            
        }

        Row dataRow = PoiUtil.getRow(sheet, row, true);
        List<Cell> styleList = PoiUtil.getCellList(dataRow, 1, 5);
    
        return styleList;
    }
    
    /**
     * データ部スタイル取得処理
     * @param sheet
     * @param data
     * @param label
     * @return 
     */
    private List<Cell> getRowDataStyle(Sheet sheet, Map<String, Object> data, String label) {
        int row;
    
        // 第1次集計が「サブBU」の場合
        //if(aggregateConditionBean.getPrimaryUnit().equals("1")){
        //if(aggregateConditionBean.getPrimaryUnit().equals("0") || aggregateConditionBean.getPrimaryUnit().equals("2")){
        if (aggregateConditionBean.isPrimaryUnitBuka()) {
            ////// 第1次集計が「営業課(0)」「主管課(2)」等が選択されて、部と課で集計欄を分ける場合
            // 0次集計データ(部)の場合
            if(String.valueOf(data.get("TOTAL_KBN")).equals("1")){
                row = 21;
            } 
            // 1次集計データ(課)の場合
            else if(String.valueOf(data.get("TOTAL_KBN")).equals("2")){
                row = 23;
            }
            // 2次集計データの場合
            else {
                row = 25;
            }

        } else {
            // 1次集計データの場合
            if(String.valueOf(data.get("TOTAL_KBN")).equals("1")){
                row = 23;
            } 
            // 2次集計データの場合
            else{
                row = 25;
            }
        }
        
        if(label.equals(Label.before.getLabel())){
            row = 27;
        }
        if(label.equals(Label.diff2.getLabel())){
            row = 29;
        }

        
        Row dataRow = PoiUtil.getRow(sheet, row, true);
        List<Cell> styleList = PoiUtil.getCellList(dataRow, 6, 4);
    
        return styleList;
    }
    
    
    /**
     * ObjectをBigDecimal型に変換
     * @param obj
     * @return
     * @throws Exception
     */
    private BigDecimal convBigDecimal(Object obj) throws Exception {
    
        return Utils.changeBigDecimal(Utils.getObjToStrValue(obj));
    
    }
    
    /**
     * ObjectをInteger型に変換
     * @param obj
     * @return
     * @throws Exception
     */
//    private Integer convInteger(Object obj) throws Exception {
//        
//        if (obj==null) {
//            return null;
//        }
//        return new Integer(obj.toString()).intValue();
//    }
//
}
