package jp.co.toshiba.hby.pspromis.syuueki.service;

import java.sql.SQLException;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Set;
import java.util.Map;
import java.util.HashMap;
import java.util.HashSet;
import javax.ejb.Stateless;
import javax.inject.Inject;
import javax.interceptor.Interceptors;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import jp.co.toshiba.hby.pspromis.common.entity.CountEntity;
import jp.co.toshiba.hby.pspromis.syuueki.bean.S013Bean;
import jp.co.toshiba.hby.pspromis.syuueki.entity.SyuWfControlTbl;
import jp.co.toshiba.hby.pspromis.syuueki.entity.BuMst;
import jp.co.toshiba.hby.pspromis.syuueki.entity.DivisionMst;
import jp.co.toshiba.hby.pspromis.syuueki.facade.KanjyoMstFacade;
import jp.co.toshiba.hby.pspromis.syuueki.facade.SyuWfControlTblFacade;
import jp.co.toshiba.hby.pspromis.syuueki.facade.BuMstFacade;
import jp.co.toshiba.hby.pspromis.syuueki.facade.DivisionMstFacade;
import jp.co.toshiba.hby.pspromis.syuueki.interceptor.TranceInterceptor;
import jp.co.toshiba.hby.pspromis.syuueki.jdbc.DbUtilsExecutor;
import jp.co.toshiba.hby.pspromis.common.jdbc.SqlExecutor;
import jp.co.toshiba.hby.pspromis.syuueki.jdbc.SqlFile;
import jp.co.toshiba.hby.pspromis.syuueki.util.ConstantString;
import jp.co.toshiba.hby.pspromis.syuueki.util.LoginUserInfo;
import jp.co.toshiba.hby.pspromis.syuueki.util.SyuuekiUtils;
import jp.co.toshiba.hby.pspromis.syuueki.util.Utils;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.ArrayUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
/**
 * PS-Promis収益管理システム
 * 月次確定検索 Service
 * @author (NPC)S.Ibayashi
 */
@Stateless
@Interceptors({TranceInterceptor.class})
public class S013Service {

    /**
     * ロガー
     */
    public static final Logger logger = LoggerFactory.getLogger(S013Service.class);

    @PersistenceContext(unitName = jp.co.toshiba.hby.pspromis.syuueki.util.ConstantString.syuuekiDataSourceName)
    private EntityManager em;

    /**
     * パラメータ格納クラスをinjection(CDI)<br>
     * InjectアノテーションよりAPサーバー(Glassfish)側で自動的にインスタンス作成(new)される。<br>
     */
    @Inject
    private S013Bean s013Bean;

    /**
     * Injection loginUserInfo
     * (ユーザー情報(ユーザーid,名称,所属部課名)を格納したオブジェクト)
     */
    @Inject
    private LoginUserInfo loginUserInfo;

    /**
     * Injection sqlExecutor
     */
    @Inject
    protected SqlExecutor sqlExecutor;

    /**
     * Injection dbUtilsExecutor
     */
    @Inject
    private DbUtilsExecutor dbUtilsExecutor;
    
    /**
     * Injection SyuuekiUtils
     */
    @Inject
    private SyuuekiUtils syuuekiUtils;

    @Inject
    private KanjyoMstFacade kanjyoMstFacade;

    @Inject
    private SyuWfControlTblFacade syuWfControlTblFacade;

    @Inject
    private BuMstFacade buMstFacade;
    
    @Inject
    private DivisionMstFacade divisionMstFacade;

    @Inject
    private SyuuekiCommonService syuuekiCommonService;
    
    /**
     * 検索条件用Mapを作成
     */
    private Map<String, Object> getCondition() {
        //List<String> memberJobGrList;

        Map<String, Object> condition = new LinkedHashMap<>();

        // 事業部
        if (s013Bean.getDivisionCode() != null) {
            condition.put("divisionCode", Arrays.asList(s013Bean.getDivisionCode()));
        }

        // 営業部門個コード
        condition.put("groupCode", s013Bean.getEigyoSectionCode());

        // データ種別
        condition.put("dataKbn", s013Bean.getSyubetsu());
        
        if ("G".equals(s013Bean.getSyubetsu())) {
            // 確定月FROM
            condition.put("fixedYmFrom", s013Bean.getFixedYmFrom());
            // 確定月TO
            condition.put("fixedYmTo", s013Bean.getFixedYmTo());
        } else if ("Y".equals(s013Bean.getSyubetsu())) {
            // 対象
            condition.put("taisho", s013Bean.getTaisho());
        }
        // 売上基準
        if (s013Bean.getSalesClass() != null) {
            condition.put("salesClass", Arrays.asList(s013Bean.getSalesClass()));
        }

        return condition;
    }

    /**
     * 検索条件初期化
     */
    private void initCondition() {
        // 一覧検索FLG
        s013Bean.setListFlg("0");
        s013Bean.setConditionFlg("1");
        s013Bean.setCount(null);
        s013Bean.setPage(null);
        
        // 事業部(案件検索で指定していた内容を引き継ぐ)
        if (s013Bean.getDivisionCode() == null) {
            s013Bean.setDivisionCode(loginUserInfo.getJobGrSyokusyuArrayInfo("division"));
        }

        s013Bean.setEigyoSectionCode(loginUserInfo.getDepartmentCd());

        // データ種別　Step3(2015下)add
        // 月次確定をデフォルトセット
        s013Bean.setSyubetsu("G");
        
        // 対象　Step3(2015下)add
        s013Bean.setTaisho(null);
        
        // 売上基準
        String[] salesClass = {"0", "1"};
        s013Bean.setSalesClass(salesClass);

        // BU情報(電力ジ対応で追加)
        s013Bean.setBuCode(null);
        
        // 売上予定日(From) 2014下add
        // ※現在の勘定月をデフォルトセット
        String kanjoYm = "";
        try {
            kanjoYm = kanjyoMstFacade.getNowKanjoDate(ConstantString.salesClassI);   // Step3.一般案件用の勘定月を使用
            Date kanjoDate = Utils.parseDate(kanjoYm);

            s013Bean.setFixedYmFrom(syuuekiUtils.exeFormatYm(kanjoDate));
        } catch (ParseException pe) {
            logger.error("error parse kanjo date [" + kanjoYm + "] program(S013)");
        }
    }

    /**
     * 営業部門選択候補の取得(履歴グループマスタから候補取得)
     */
    private List<Map<String, Object>> findRirekiGroupMst() throws SQLException {
        String sqlFilePath = "/sql/rirekiGroupMst/selectGroup.sql";

        Map<String, Object> condition = getCondition();

        // SQLを取得
        SqlFile sqlFile = new SqlFile();
        String sql = sqlFile.getSqlString(sqlFilePath, condition);
        Object[] params = sqlFile.getSqlParams(sqlFilePath, condition);

        // SQL実行
        List<Map<String, Object>> list = dbUtilsExecutor.dbUtilsGetSqlList(em, sql, params);
        
        return list;
    }
    
    /**
     * マスタデータ取得
     */
    private void setMstDate() throws Exception {
        // ログイン者の所属事業部コード(事業部兼務を考慮して配列で取得される)
        //String[] loginDivisionCodes = loginUserInfo.getJobGrSyokusyuArrayInfo("division");
        
        // 営業部門マスタ
        List<Map<String, Object>> eigyoSectionList = findRirekiGroupMst();
        s013Bean.setEigyoSectionList(eigyoSectionList);
        
        // (電力ジ対応)BU情報マスタからBUのみのデータを取得
        s013Bean.setBuDivisionCodes("");
        List<String> buDivisionList = findConditionBuDivisionList();
        if (CollectionUtils.isNotEmpty(buDivisionList)) {
            // 対象事業部のBU選択候補を取得
            Map<String, Object> buMstCondtion = new HashMap<>();
            buMstCondtion.put("divisionCode", buDivisionList);
            List<BuMst> buMstList = buMstFacade.findConditionBuList(buMstCondtion);
            s013Bean.setBuMstList(buMstList);

            // BUを出力する事業部コードをカンマ区切りの文字列にする(検索条件:事業部を切り替えたときのjavascriptコード用のための準備)
            String join = "";
            for (String str : buDivisionList) {
                join = join + str + ",";
            }
            join = join.substring(0, join.length()-1);
            s013Bean.setBuDivisionCodes(join);
        }
    }
    
    /**
     * 検索条件:BUを出力する事業部を取得
     */
    private List<String> findConditionBuDivisionList() {
        Set<String> buDivisionSet = new HashSet<>();
        
        // ログイン者の所属事業部コード(事業部兼務を考慮して配列で取得される)
        String[] loginDivisionCodes = loginUserInfo.getJobGrSyokusyuArrayInfo("division");

        // ログイン者の所属事業部に該当するサブ事業部(1.5段事業部)を取得
        Map<String, Object> divisionMstCondition = new HashMap<>();
        divisionMstCondition.put("divisionType", "2");
        divisionMstCondition.put("divisionCode", loginDivisionCodes);
        List<DivisionMst> divisionList = divisionMstFacade.findDivisionList(divisionMstCondition);
        
        // 各事業部のサブ事業部の件数を確認して、複数のサブ事業部が存在する事業部は対象とする。
        if (CollectionUtils.isNotEmpty(divisionList)) {
            Map<String, Integer> subDivisionCountMap = new HashMap<>();
            for (DivisionMst divisionMst: divisionList) {
                String divisionCode = divisionMst.getDivisionCode();
                Integer subDivisionCount = subDivisionCountMap.get(divisionCode);
                if (subDivisionCount == null) {
                    subDivisionCount = 1;
                } else {
                    subDivisionCount = subDivisionCount + 1;
                    
                    // 複数のサブ事業部が存在する事業部を対象にする。
                    buDivisionSet.add(divisionCode);
                }
                subDivisionCountMap.put(divisionCode, subDivisionCount);
            }
        }
        
        List<String> buDivisionList = new ArrayList<>(buDivisionSet);
        return buDivisionList;
    }
 
    /**
     * ログイン者のdivisionSubNameと検索条件指定のBUコードが等しいBU情報をデフォルトで選択状態にする
     * (検索条件:BUのデフォルト選択で利用)
     * @param buMstList buマスタ一覧(BU/SBU検索条件の候補となるリスト)
     */
    private void setInitLoginDefaultBuSelect(String[] divisionCodes, List<BuMst> buMstList) {
        String[] buArray = s013Bean.getBuCode();
        for (String divisionCode: divisionCodes) {
            String[] defaultBuArray = getLoginDefaultBuSbuSelect(divisionCode, buMstList, 0);
            buArray = ArrayUtils.addAll(defaultBuArray, buArray);
        }
        s013Bean.setBuCode(buArray);
    }
    
    /**
     * ログイン者のdivisionSubNameと検索条件指定のBUコードが等しいBU情報を配列で取得
     * @param buMstList buマスタ一覧(BU/SBU検索条件の候補となるリスト)
     * @kbn BU配列を取得するかSBU配列を取得するかを決定(0:BU配列 1:SBU配列)
     */
    private String[] getLoginDefaultBuSbuSelect(String divisionCode, List<BuMst> buMstList, int kbn) {
        String[] defaultBuSbuArray = syuuekiCommonService.getDefaultLoginSameBuArray(divisionCode, buMstList, kbn);
        logger.info("kbn=[{}], defaultBuSbuArray=[{}]", kbn, defaultBuSbuArray);
        return defaultBuSbuArray;
    }

    /**
     * ログイン者のdivisionSubNameと検索条件指定のBUコードが等しいBU情報をデフォルトで選択状態にする
     * (検索条件:BUのデフォルト選択で利用)
     * @param buMstList buマスタ一覧(BU/SBU検索条件の候補となるリスト)
     */
    private void setSearchAfterLoginDefaultBuSelect(List<BuMst> buMstList) {
        if (CollectionUtils.isEmpty(buMstList)) {
            return;
        }

        // 検索条件で選択している以外のBUを取得
        String[] targetDivisionCodes = loginUserInfo.getJobGrSyokusyuArrayInfo("division");
        List<String> oterDivisionCodeList = new ArrayList<>();
        for (String loginDivisionCode: targetDivisionCodes) {
            if (!loginDivisionCode.equals(s013Bean.getDivisionCode()[0])) {
                oterDivisionCodeList.add(loginDivisionCode);
            }
        }
        
        targetDivisionCodes = (String[])oterDivisionCodeList.toArray(new String[0]);
        setInitLoginDefaultBuSelect(targetDivisionCodes, s013Bean.getBuMstList());
    }
    
    /**
     * 営業部門の選択候補絞り込み ビジネスロジック
     * @throws Exception 
     */
    public void eigyoSectionExecute() throws Exception {
        // 事業部(未指定の場合はログイン者が所属している事業部を指定)
        if (s013Bean.getDivisionCode() == null) {
            s013Bean.setDivisionCode(loginUserInfo.getJobGrSyokusyuArrayInfo("division"));
        }

        // 営業部門マスタ
        List<Map<String, Object>> eigyoSectionList = findRirekiGroupMst();
        s013Bean.setEigyoSectionList(eigyoSectionList);
    }
    
    /**
     * 予算ベースデータの勘定月一覧を取得
     */
    private List<Map<String, Object>> findYosanKanjyoYMList() throws SQLException {
        String sqlFilePath = "/sql/syuWfControlTbl/selectYosanKanjyoYm.sql";

        Map<String, Object> condition = getCondition();

        // SQLを取得
        SqlFile sqlFile = new SqlFile();
        String sql = sqlFile.getSqlString(sqlFilePath, condition);
        Object[] params = sqlFile.getSqlParams(sqlFilePath, condition);

        // SQL実行
        List<Map<String, Object>> list = dbUtilsExecutor.dbUtilsGetSqlList(em, sql, params);
        
        return list;
    }

    /**
     * 予算ベースデータの勘定月一覧を取得
     */
    private void setTaishoData() throws Exception {
        List<Map<String, Object>> taishoList = findYosanKanjyoYMList();
        s013Bean.setTaishoList(taishoList);
    }
    
    /**
     * 予算ベースデータの勘定月一覧の選択候補絞り込み ビジネスロジック
     * @throws Exception 
     */
    public void taishoExecute() throws Exception {
        // 事業部(未指定の場合はログイン者が所属している事業部を指定)
        if (s013Bean.getDivisionCode() == null) {
            s013Bean.setDivisionCode(loginUserInfo.getJobGrSyokusyuArrayInfo("division"));
        }
        
        setTaishoData();
    }
    

    /**
     * 初期表示 ビジネスロジック
     */
    public void indexExecute() throws Exception {
        // 検索条件の各種候補のマスタデータ取得
        setMstDate();

        // 検索条件の初期化
        initCondition();
        
        // ログイン者所属JobGrによるBU/SBU検索条件のデフォルト選択
        String[] loginDivisionCodes = loginUserInfo.getJobGrSyokusyuArrayInfo("division");
        setInitLoginDefaultBuSelect(loginDivisionCodes,  s013Bean.getBuMstList());
    }

    /**
     * 一覧表示 ビジネスロジック
     * @throws Exception 
     */
    public void listExecute() throws Exception {
        // ページ切り替えか否かを判定
        boolean isPageing = true;
        if (s013Bean.getPage() == null || s013Bean.getPage() <= 0) {
            isPageing = false;
            s013Bean.setPage(1);
        }

        // 事業部が選択されていない場合
        if (s013Bean.getDivisionCode() == null) {
            // ログイン者の優先事業部を強制セット
            String[] priorityDivCdAry = new String[]{loginUserInfo.getPriorityDivCode()};
            s013Bean.setDivisionCode(priorityDivCdAry);
        }
        
        // 検索条件をセット
        Map<String, Object> condition = getCondition();

        // 一覧データの総件数を取得(ページ切り替え時は省略)
        Integer totalCount = s013Bean.getCount();
        CountEntity countEntity = new CountEntity();

        if (!isPageing) {
            ////// 検索ボタン
            // 操作ログを出力(とりあえずの実装。マッピング確定したら修正予定)
/*
            OperationLog operationLog = getOperationLogDto(condition);
            operationLogService.insertOperationLogSearch(operationLog);
*/
            // データ総件数を取得
            //condition.put("listFlg", "1");
            countEntity = syuWfControlTblFacade.findTotalCount(condition);
            totalCount = countEntity.getCount();
            
        } else {
            ////// ページング時
            countEntity.setCount(s013Bean.getCount());
        }
        
        // 一覧検索実行(データが存在する場合のみ実行)
        List<SyuWfControlTbl> list = null;
        if (totalCount != null && totalCount > 0) {
            list = syuWfControlTblFacade.findList(condition, s013Bean.getPage());
        }

        // 結果をbeanセット
        s013Bean.setCount(totalCount);
        s013Bean.setList(list);

        // 検索条件の各種候補のマスタデータ取得
        setMstDate();
        
        // データ種別が予算ベースのときは、対象リストボックスのデータを取得する
        if ("Y".equals(s013Bean.getSyubetsu())) {
            setTaishoData();
        }
        
        // (事業部を兼務している場合を考慮)
        // 検索条件で選択した事業部以外のBUデフォルト選択が外れてしまうため
        // 選択した事業部以外のBUデフォルト選択を元に戻す
        setSearchAfterLoginDefaultBuSelect(s013Bean.getBuMstList());
    }

}
