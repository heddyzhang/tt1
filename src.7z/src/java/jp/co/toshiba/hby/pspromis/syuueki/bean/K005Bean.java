package jp.co.toshiba.hby.pspromis.syuueki.bean;

import java.util.List;
import java.util.Map;
import javax.enterprise.context.RequestScoped;
import javax.inject.Named;
import jp.co.toshiba.hby.pspromis.syuueki.entity.TradeMst;

/**
 *
 * @author horie
 */
@Named(value = "k005Bean")
@RequestScoped
public class K005Bean {
    /**
     * 一覧検索フラグ
     */
    private String listFlg = "0";

    /**
     * 注文主一覧データ
     */
    private List<TradeMst> tradeList;

    /**
     * 検索条件・注文主名称
     */
    private String tradeName;
    
    /**
     * 検索条件・注文主コード
     */
    private String tradeCode;
    
    /**
     * 検索結果・検索件数
     */
    private Integer count;
 
    /**
     * 現在表示するページ番号
     */
    private Integer page;

    public List<TradeMst> getTradeList() {
        return tradeList;
    }
    
    public void setTradeList(List<TradeMst> tradeList) {
        this.tradeList = tradeList;
    }

    public Integer getCount() {
        return count;
    }

    public void setCount(Integer count) {
        this.count = count;
    }

    public Integer getPage() {
        return page;
    }

    public void setPage(Integer page) {
        this.page = page;
    }

    public String getListFlg() {
        return listFlg;
    }

    public void setListFlg(String listFlg) {
        this.listFlg = listFlg;
    }

    public String getTradeName() {
        return tradeName;
    }

    public void setTradeName(String tradeName) {
        this.tradeName = tradeName;
    }

    public String getTradeCode() {
        return tradeCode;
    }

    public void setTradeCode(String tradeCode) {
        this.tradeCode = tradeCode;
    }

}
