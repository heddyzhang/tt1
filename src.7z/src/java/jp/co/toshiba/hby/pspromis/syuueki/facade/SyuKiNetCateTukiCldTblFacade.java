/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package jp.co.toshiba.hby.pspromis.syuueki.facade;

import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import jp.co.toshiba.hby.pspromis.syuueki.entity.SyuKiNetCateTukiCldTbl;

/**
 *
 * @author sano
 */
@Stateless
public class SyuKiNetCateTukiCldTblFacade extends AbstractFacade<SyuKiNetCateTukiCldTbl> {
    @PersistenceContext(unitName = jp.co.toshiba.hby.pspromis.syuueki.util.ConstantString.syuuekiDataSourceName)
    private EntityManager em;

    @Override
    protected EntityManager getEntityManager() {
        return em;
    }

    public SyuKiNetCateTukiCldTblFacade() {
        super(SyuKiNetCateTukiCldTbl.class);
    }
    
    public SyuKiNetCateTukiCldTbl getPkInfo(String ankenId, String syuekiYm, String categoryCode, String categoryKbn1, String kbn) {
        Query q = em.createNamedQuery("KiNetCateTukiCldTbl.findPk", SyuKiNetCateTukiCldTbl.class);
        
        q.setParameter("ankenId", ankenId);
        q.setParameter("syuekiYm", syuekiYm);
        q.setParameter("categoryCode", categoryCode);
        q.setParameter("categoryKbn1", categoryKbn1);
        q.setParameter("kbn", kbn);

        SyuKiNetCateTukiCldTbl en;
        
        try {
            en = (SyuKiNetCateTukiCldTbl)q.getSingleResult();
        } catch(javax.persistence.NoResultException e){
            // 指定PKのデータが存在しない場合
            en = null;
        }

        return en;
    }
    /*
    public List<SyuKiNetCateTukiCldTbl> getSumYmNetList(Map<String, Object> condition) {
        List<SyuKiNetCateTukiCldTbl> list
                = sqlExecutor.getResultList(em, SyuKiNetCateTukiCldTbl.class, "/sql/syuKiNetCateTukiCldTbl/selectYmSumNet.sql", condition);

        return list;
    }
    */
    
}
