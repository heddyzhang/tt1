package jp.co.toshiba.hby.pspromis.syuueki.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.inject.Inject;
import javax.interceptor.Interceptors;
//import javax.persistence.EntityManager;
//import javax.persistence.PersistenceContext;
import jp.co.toshiba.hby.pspromis.common.exception.PspRunTimeExceotion;
import jp.co.toshiba.hby.pspromis.common.util.BeanUtil;
import jp.co.toshiba.hby.pspromis.syuueki.bean.S017Bean;
import jp.co.toshiba.hby.pspromis.syuueki.entity.EstViewList;
import jp.co.toshiba.hby.pspromis.syuueki.entity.SyuGeBukkenInfoTbl;
//import jp.co.toshiba.hby.pspromis.syuueki.entity.SyuSaNetCateTitleTbl;
import jp.co.toshiba.hby.pspromis.syuueki.enums.Label;
import jp.co.toshiba.hby.pspromis.syuueki.enums.ScreenMode;
import jp.co.toshiba.hby.pspromis.syuueki.facade.S017Facade;
import jp.co.toshiba.hby.pspromis.syuueki.facade.SyuGeBukenInfoTblFacade;
//import jp.co.toshiba.hby.pspromis.syuueki.facade.SyuSaNetCateTitleTblFacade;
import jp.co.toshiba.hby.pspromis.syuueki.interceptor.TranceInterceptor;
import jp.co.toshiba.hby.pspromis.syuueki.util.ConstantString;
import jp.co.toshiba.hby.pspromis.syuueki.util.EntityUtils;
import jp.co.toshiba.hby.pspromis.syuueki.util.LoginUserInfo;
import jp.co.toshiba.hby.pspromis.syuueki.util.AuthorityUtils;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 *
 * @author ganryu
 */
@Stateless
@Interceptors({TranceInterceptor.class})
public class S017Service {

    /**
     * ロガー
     */
    public static final Logger logger = LoggerFactory.getLogger(S017Service.class);

    //@PersistenceContext(unitName = jp.co.toshiba.hby.pspromis.syuueki.util.ConstantString.syuuekiDataSourceName)
    //private EntityManager em;
    
    /**
     * パラメータ格納クラスをinjection(CDI)<br>
     * InjectアノテーションよりAPサーバー(Glassfish)側で自動的にインスタンス作成(new)される。<br>
     */
    @Inject
    private S017Bean s017Bean;
    @Inject
    private SyuGeBukenInfoTblFacade syuGeBukenInfoTblFacade;
    @Inject
    private S017Facade s017Facade;
    @Inject
    private LoginUserInfo loginUserInfo;
    @Inject
    private StoredProceduresService storedProceduresService;
    @Inject
    private AuthorityUtils authorityUtils;


    /**
     *
     * @throws Exception
     */
    @TransactionAttribute(TransactionAttributeType.NOT_SUPPORTED)
    public void indexExecute() throws Exception {
        logger.error("S017Service#indexExecute");

        Map<String, Object> paramMap = getCondition();
        setDetail(paramMap);
    }

    /**
     *
     * @return
     */
    private Map<String, Object> getCondition() {
        Map<String, Object> paramMap = new HashMap<>();
        paramMap.put("rirekiFlg", s017Bean.getRirekiFlg());
        paramMap.put("ankenId", s017Bean.getAnkenId());
        //paramMap.put("rirekiId", s017Bean.getRirekiId());
        paramMap.put("rirekiId", Integer.valueOf(ConstantString.geRirekiId));

        return paramMap;
    }


    /**
     * データ取得処理
     * @param paramMap
     */
    private void setDetail(Map<String, Object> paramMap) {
        SyuGeBukkenInfoTbl entity = syuGeBukenInfoTblFacade.findPk(paramMap);

        if (entity == null) {
            String errorMessage = Label.errorNoAnkenDate.getLabel();
            logger.error(errorMessage + " ankenId=" + s017Bean.getAnkenId() + " rirekiId=" + s017Bean.getRirekiId());
            throw new PspRunTimeExceotion(errorMessage);
        }
        s017Bean.setDivisionCode(entity.getDivisionCode());
        s017Bean.setChuban(entity.getOrderNo());

        // 2018A 1199 ISP丸投げ案件は、対象案件とは無関係の案件も注番が"ISP"となってしまい巻き込んで表示しているため、注番がNULLとみなして検索する
        String conditionChuban  = "ISP".startsWith(StringUtils.trimToEmpty(entity.getOrderNo())) ? "" : entity.getOrderNo();

        // 2017/11/17 ADD #006 決裁/見積情報参照画面からP-Linkへ飛ぶ
        List<EstViewList> list = s017Facade.selectQnoList(conditionChuban, s017Bean.getAnkenId(), s017Bean.getDivisionCode(), entity.getAnkenFlg());
        s017Bean.setDispSelectItemList(list);
        
        setKengen();
    }
    
    /**
     * 各権限の取得
     */
    private void setKengen() {
        // 編集権限の取得
        if (authorityUtils.enableFlg("MITUMORI_EDIT", s017Bean.getDivisionCode(), "0") == 1) {
            s017Bean.setEditAction(true);
        }
        // 保存権限の取得
        if (authorityUtils.enableFlg("MITUMORI_SAVE", s017Bean.getDivisionCode(), "0") == 1) {
            s017Bean.setSaveAction(true);
        }
    }

    /**
     * バリデーション
     */
    public boolean validation() {
        return true;
    }
    
    /**
     * 保存処理
     */
    public void saveExecute() throws Exception {
        logger.info("S017Service#saveExecute");
        
        // 一覧データの保存(2017Bに原子力P-Linkデータ連携のために検収月の保存処理を追加)
        saveListData();
    }
    
    /**
     * 一覧データの保存
     */
    private void saveListData() throws Exception {
        List<Map<String, String>> estList = s017Bean.getEstList();
        
        if (CollectionUtils.isNotEmpty(estList)) {
            for (Map<String, String> info: estList) {
                saveTargetAnken(info);
            }
        }
    }
    
    /**
     * 案件一件別の検収月情報の更新
     */
    private void saveTargetAnken(Map<String, String> info) throws Exception {
        String ankenId = StringUtils.defaultString(info.get("ankenId"));
        String rirekiId = ConstantString.geRirekiId;
        String kensyutuki =  StringUtils.replace(StringUtils.defaultString(info.get("kensyutuki")), "/", "");
        String changeFlg = StringUtils.defaultString(info.get("changeFlg"));

        // 画面で変更した案件のみ更新する。
        if ("1".equals(changeFlg)) {
            // 更新対象の案件を取得
            SyuGeBukkenInfoTbl targetAnkenEntity = getTargetAnkenEntity(ankenId, rirekiId);

            // 設定した検収月をGEに登録
            targetAnkenEntity.setKensyutuki(kensyutuki);
            syuGeBukenInfoTblFacade.merge(targetAnkenEntity);

            // 再計算バッチを実行(検収月を(原子力)収益に連携する必要があるために実施する)
            // ※収益対象設定されている案件のみ連携する。収益対象設定されていなくとも、収益対象設定切り替えで有効にしたときに連携される。
            if ("1".equals(targetAnkenEntity.getSyuekiFlg())) {
                callRecalPackage(ankenId, rirekiId);
            }
        }
    }
    
    
    /**
     * 更新対象案件情報を取得する
     */
    private SyuGeBukkenInfoTbl getTargetAnkenEntity(String ankenId, String rirekiId) {
        Map<String, Object> condition = new HashMap<>();
        condition.put("ankenId", ankenId);
        condition.put("rirekiId", Integer.parseInt(rirekiId));
        SyuGeBukkenInfoTbl ankenEntity = syuGeBukenInfoTblFacade.findPk(condition);

        SyuGeBukkenInfoTbl syuGeBukkenInfoItem = BeanUtil.createAndCopy(SyuGeBukkenInfoTbl.class, ankenEntity);
        EntityUtils.setUpdatedInfo(syuGeBukkenInfoItem, loginUserInfo.getUserId());

        return syuGeBukkenInfoItem;
    }
    
    /**
     * 再計算パッケージを呼び出し
     */
    private void callRecalPackage(String ankenId, String rirekiId) throws Exception {
        // 再計算処理を実行
        storedProceduresService.callAnkenRecalAuto(ankenId, rirekiId, "4");
    }
    
}
