/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package jp.co.toshiba.hby.pspromis.syuueki.bean;

import java.io.Serializable;
import java.util.Map;
import java.util.Set;
import javax.enterprise.context.SessionScoped;
import javax.inject.Named;

/**
 *
 * @author ibayashi
 */
@Named(value = "authorityBean")
@SessionScoped
public class AuthorityBean implements Serializable {

    /**
     * ログイン者の権限を格納したMap(最新画面)<br>
     * MapのKeyは"事業部"(SYU_KENGEN_MST.DIVISION_CODE)単位<br>
     * valueは権限があるFUNC_CDを格納したSet<br>
     * 
     * (例)期間損益:編集機能(FUNC_CD='KIKAN_S_EDITALL'),機能ボタン(FUNC_CD='KIKAN_S_FUNC')
     *   所属事業部=火水ジ(N8)で最新画面で上記権限が存在する場合、以下の通りに保持される。
     *   key="N8", value={KIKAN_S_EDITALL, KIKAN_S_FUNC}
     */
    private Map<String, Set<String>> authorityKeyMap;

    /**
     * ログイン者の権限を格納したMap(履歴画面)<br>
     * MapのKeyは"事業部"(SYU_KENGEN_MST.DIVISION_CODE)単位<br>
     * valueは権限があるFUNC_CDを格納したSet<br>
     * 
     * (例)期間損益:編集機能(FUNC_CD='KIKAN_S_EDITALL'),機能ボタン(FUNC_CD='KIKAN_S_FUNC')
     *   所属事業部=火水ジ(N8)で最新画面で上記権限が存在する場合、以下の通りに保持される。
     *   key="N8", value={KIKAN_S_EDITALL, KIKAN_S_FUNC}
     */
    private Map<String, Set<String>> authorityRirekiKeyMap;

    public Map<String, Set<String>> getAuthorityKeyMap() {
        return authorityKeyMap;
    }

    public void setAuthorityKeyMap(Map<String, Set<String>> authorityKeyMap) {
        this.authorityKeyMap = authorityKeyMap;
    }

    public Map<String, Set<String>> getAuthorityRirekiKeyMap() {
        return authorityRirekiKeyMap;
    }

    public void setAuthorityRirekiKeyMap(Map<String, Set<String>> authorityRirekiKeyMap) {
        this.authorityRirekiKeyMap = authorityRirekiKeyMap;
    }

}
