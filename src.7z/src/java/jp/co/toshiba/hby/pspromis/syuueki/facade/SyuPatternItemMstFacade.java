package jp.co.toshiba.hby.pspromis.syuueki.facade;

import javax.ejb.Stateless;
import javax.interceptor.Interceptors;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import jp.co.toshiba.hby.pspromis.syuueki.entity.SyuPatternItemMst;
import jp.co.toshiba.hby.pspromis.syuueki.interceptor.TranceInterceptor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
/**
 *
 * @author sano
 */
@Stateless
@Interceptors({TranceInterceptor.class})
public class SyuPatternItemMstFacade extends AbstractFacade<SyuPatternItemMst> {
    
    private static final Logger logger = LoggerFactory.getLogger(SyuPatternItemMstFacade.class);
    
    @PersistenceContext(unitName = jp.co.toshiba.hby.pspromis.syuueki.util.ConstantString.syuuekiDataSourceName)
    private EntityManager em;

    @Override
    protected EntityManager getEntityManager() {
        return em;
    }
    
    public SyuPatternItemMstFacade() {
        super(SyuPatternItemMst.class);
    }

    /**
     * パターンマスタ内訳を取得
     * @param condition
     * @return
     * @throws Exception 
     */
    public SyuPatternItemMst getPatternItemMst(Object condition) throws Exception {
        SyuPatternItemMst syuPatternItemMst = sqlExecutor.getSingleResult(em, SyuPatternItemMst.class, "/sql/M001/selectSyuPatternItemMst.sql", condition);
        return syuPatternItemMst;
    }
}
