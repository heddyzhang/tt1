package jp.co.toshiba.hby.pspromis.syuueki.entity;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/**
 *
 * @author masaki
 */
@Entity
@Table(name = "SYU_KI_SP_CUR_TBL")
public class SyuKiSpCurTbl implements Serializable {

    private static final long serialVersionUID = 1L;
    @Column(name = "ANKEN_ID")
    @Id
    private String ankenId;
    @Column(name = "RIREKI_ID")
    @Id
    private int rirekiId;
    @Column(name = "CURRENCY_CODE")
    @Id
    private String currencyCode;
    @Column(name = "CURRENCY_CODE_SEQ")
    private String currencyCodeSeq;
    @Column(name = "ORDER_NO")
    private String orderNo;
    @Column(name = "RENBAN")
    @Id
    private String renban;
    @Column(name = "RENBAN_SEQ")
    private BigDecimal renbanSeq;
    @Column(name = "A_NO")
    private String a_no;
    @Column(name = "KEIYAKU_KENMEI")
    private String keiyaku_kenmei;
    @Column(name = "URIAGE_YM")
    private String uriageYm;
    @Column(name = "KEIYAKU_NOKI")
    @Temporal(TemporalType.DATE)
    private Date keiyakuNoki;
    @Column(name = "KEIYAKU_KAISYUTUKI")
    private String keiyakuKaisyutuki;
    @Column(name = "KINSYU_KBN")
    private String kinsyuKbn;
    @Column(name = "KAISYU_KBN")
    private String kaisyuKbn;
    @Column(name = "ZEI_KBN_NM")
    private String zeiKbnNm;
    @Column(name = "ISP_FLG")
    private String isp_flg;
    @Column(name = "ISP_JIGYOBU_CD")
    private String isp_jigyobu_cd;
    @Column(name = "KEIYAKU_RATE")
    private BigDecimal keiyaku_rate;
    @Column(name = "KARI_SP_FLG")
    private int kariSpFlg;
    @Column(name = "CREATED_AT")
    @Temporal(TemporalType.TIMESTAMP)
    private Date createdAt;
    @Column(name = "CREATED_BY")
    private String createdBy;
    @Column(name = "UPDATED_AT")
    @Temporal(TemporalType.TIMESTAMP)
    private Date updatedAt;
    @Column(name = "UPDATED_BY")
    private String updatedBy;

    public SyuKiSpCurTbl() {
    }

    public String getAnkenId() {
        return ankenId;
    }

    public void setAnkenId(String ankenId) {
        this.ankenId = ankenId;
    }

    public int getRirekiId() {
        return rirekiId;
    }

    public void setRirekiId(int rirekiId) {
        this.rirekiId = rirekiId;
    }

    public String getCurrencyCode() {
        return currencyCode;
    }

    public void setCurrencyCode(String currencyCode) {
        this.currencyCode = currencyCode;
    }

    public String getCurrencyCodeSeq() {
        return currencyCodeSeq;
    }

    public void setCurrencyCodeSeq(String currencyCodeSeq) {
        this.currencyCodeSeq = currencyCodeSeq;
    }

    public String getOrderNo() {
        return orderNo;
    }

    public void setOrderNo(String orderNo) {
        this.orderNo = orderNo;
    }

    public String getRenban() {
        return renban;
    }

    public void setRenban(String renban) {
        this.renban = renban;
    }

    public BigDecimal getRenbanSeq() {
        return renbanSeq;
    }

    public void setRenbanSeq(BigDecimal renbanSeq) {
        this.renbanSeq = renbanSeq;
    }

    public Date getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(Date createdAt) {
        this.createdAt = createdAt;
    }

    public String getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    public Date getUpdatedAt() {
        return updatedAt;
    }

    public void setUpdatedAt(Date updatedAt) {
        this.updatedAt = updatedAt;
    }

    public String getUpdatedBy() {
        return updatedBy;
    }

    public void setUpdatedBy(String updatedBy) {
        this.updatedBy = updatedBy;
    }

    public String getA_no() {
        return a_no;
    }

    public void setA_no(String a_no) {
        this.a_no = a_no;
    }

    public String getKeiyaku_kenmei() {
        return keiyaku_kenmei;
    }

    public void setKeiyaku_kenmei(String keiyaku_kenmei) {
        this.keiyaku_kenmei = keiyaku_kenmei;
    }

    public String getUriageYm() {
        return uriageYm;
    }

    public void setUriageYm(String uriageYm) {
        this.uriageYm = uriageYm;
    }

    public Date getKeiyakuNoki() {
        return keiyakuNoki;
    }

    public void setKeiyakuNoki(Date keiyakuNoki) {
        this.keiyakuNoki = keiyakuNoki;
    }

    public String getKeiyakuKaisyutuki() {
        return keiyakuKaisyutuki;
    }

    public void setKeiyakuKaisyutuki(String keiyakuKaisyutuki) {
        this.keiyakuKaisyutuki = keiyakuKaisyutuki;
    }

    public String getKinsyuKbn() {
        return kinsyuKbn;
    }

    public void setKinsyuKbn(String kinsyuKbn) {
        this.kinsyuKbn = kinsyuKbn;
    }

    public String getKaisyuKbn() {
        return kaisyuKbn;
    }

    public void setKaisyuKbn(String kaisyuKbn) {
        this.kaisyuKbn = kaisyuKbn;
    }

    public String getZeiKbnNm() {
        return zeiKbnNm;
    }

    public void setZeiKbnNm(String zeiKbnNm) {
        this.zeiKbnNm = zeiKbnNm;
    }

    public String getIsp_flg() {
        return isp_flg;
    }

    public void setIsp_flg(String isp_flg) {
        this.isp_flg = isp_flg;
    }

    public String getIsp_jigyobu_cd() {
        return isp_jigyobu_cd;
    }

    public void setIsp_jigyobu_cd(String isp_jigyobu_cd) {
        this.isp_jigyobu_cd = isp_jigyobu_cd;
    }

    public BigDecimal getKeiyaku_rate() {
        return keiyaku_rate;
    }

    public void setKeiyaku_rate(BigDecimal keiyaku_rate) {
        this.keiyaku_rate = keiyaku_rate;
    }

    public int getKariSpFlg() {
        return kariSpFlg;
    }

    public void setKariSpFlg(int kariSpFlg) {
        this.kariSpFlg = kariSpFlg;
    }

}
