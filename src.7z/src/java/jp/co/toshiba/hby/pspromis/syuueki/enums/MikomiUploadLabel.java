package jp.co.toshiba.hby.pspromis.syuueki.enums;

import java.util.ResourceBundle;
/**
 * プロパティファイル(appLabel)のキーを定義
 * @author ibayashi
 */
public enum MikomiUploadLabel {
    fileReadError, uploadFatalError, titleFormatError, projectError, monthBeforeError, monthFormatError,
    chunyuAmountFormatError, chunyuAmountKetaFormatError, seibanAmountFormatError, seibanAmountKetaFormatError,
    bukaError, categoryError, outputDateError, ankenFormatError, dataFormatError, mikomiAmountFormatError,
    mikomiAmountKetaFormatError;
    
    /**
     * プロパティファイルの取得
     * @param label
     * @return 
     */
    public static String getValue(MikomiUploadLabel label) {
        ResourceBundle rb = ResourceBundle.getBundle("label.mikomiUploadLabel");
        String value= rb.getString(label.name());
        return value;
    }
}
