/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package jp.co.toshiba.hby.pspromis.syuueki.facade;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import jp.co.toshiba.hby.pspromis.syuueki.entity.SyuGeNetItemTblBuka;
import jp.co.toshiba.hby.pspromis.syuueki.entity.SyuKiBikou;

/**
 *
 * @author ibayashi
 */
@Stateless
public class SyuKiBikouFacade extends AbstractFacade<SyuKiBikou> {
    @PersistenceContext(unitName = jp.co.toshiba.hby.pspromis.syuueki.util.ConstantString.syuuekiDataSourceName)
    private EntityManager em;

    @Override
    protected EntityManager getEntityManager() {
        return em;
    }

    public SyuKiBikouFacade() {
        super(SyuKiBikou.class);
    }
    
    public SyuKiBikou findPk(String ankenId, Integer rirekiId, String kbn, String rirekiFlg) {
        Map<String, Object> condition = new HashMap<>();
        condition.put("ankenId", ankenId);
        condition.put("rirekiId", rirekiId);
        condition.put("rirekiFlg", rirekiFlg);
        condition.put("kbn", kbn);

        SyuKiBikou entity = null;

        List<SyuKiBikou> list
                = sqlExecutor.getResultList(em, SyuKiBikou.class, "/sql/syuKiBikou/selectKiBikou.sql", condition);
        
        if (list.size() > 0) {
            entity = list.get(0);
        }
        
        return entity;
    }

    /**
     * 進行基準の備考の更新
     * @param condition
     */
    public int updateSyuKiBikou(Object condition) {
        return sqlExecutor.executeUpdateSql(em, "/sql/syuKiBikou/updateKiBikou.sql", condition);
    }
    
   /**
     * 進行基準の備考の登録
     * 
     * @param condition 
     */
    public int insertSyuKiBikou(Object condition){
        return sqlExecutor.executeUpdateSql(em, "/sql/syuKiBikou/insertKiBikou.sql", condition);
    }
}
