package jp.co.toshiba.hby.pspromis.syuueki.bean;

import java.util.List;
import java.util.ArrayList;
import java.util.Map;
import javax.enterprise.context.RequestScoped;
import javax.inject.Named;
import lombok.Getter;
import lombok.Setter;

/**
 *
 * @author ibayashi
 */
@Named(value = "syuekiFlgEditBean")
@RequestScoped
@Getter @Setter
public class SyuekiFlgEditBean {

    /**
     * 収益FLG設定(1:バリデーションのみ 0:バリデーション＋更新)
     */
    private String validationOnlyFlg = "0";

    /**
     * 案件一覧の選択index
     */
    private String[] checkData;

    /**
     * 案件一覧情報
     */
    private List<Map<String, String>> ankenList;

    /**
     * 処理結果FLG(1:成功 9:エラー)
     */
    private String resultFlg = "1";
    
    /**
     * 処理結果メッセージ(バリデーションチェックにひっかかかった場合、エラーメッセージ入る)
     */
    private String resultMessage;

    /**
     * 収益Flgを設定した案件ID(serviceでデータ生成・操作ログ登録用)
     */
    private List<String> editSyuekiFlgAnkenId;

    /**
     * 収益Flgを設定解除した案件ID(serviceでデータ生成・操作ログ登録用)
     */
    private List<String> relSyuekiFlgAnkenId;
    
    /**
     * 一般案件の収益FLG設定対象リスト(serviceでデータ生成)
     * keyは以下の通り
     *   newAnkenId:収益対象の付け替え先の案件ID
     *   orderNo:対象注番(注番が未設定の場合はなし)
     *   oldAnkenId:収益対象を解除する案件ID(対象が存在しない場合はなし)
     */
    private List<Map<String, String>> ippanAnkenChangeTargetList;

    /**
     * 進行基準まとめ案件の対象の設定(serviceでデータ生成)
     *   ankenId:進行基準まとめ案件ID
     *   orderNo:対象注番(注番が未設定の場合はなし)
     */
   //private List<String> shinkoMatomeAnkenTargetList;
    private List<Map<String, String>> shinkoMatomeAnkenTargetList;
    
    public void setEditSyuekiFlgAnkenId(List<String> ankenIdList) {
        if (editSyuekiFlgAnkenId == null) {
            editSyuekiFlgAnkenId = new ArrayList();
        }
        editSyuekiFlgAnkenId.addAll(ankenIdList);
    }
    
    public void setRelSyuekiFlgAnkenId(List<String> ankenIdList) {
        if (relSyuekiFlgAnkenId == null) {
            relSyuekiFlgAnkenId = new ArrayList();
        }
        relSyuekiFlgAnkenId.addAll(ankenIdList);
    }

    public void setIppanAnkenChangeTargetData(Map<String, String> data) {
        if (ippanAnkenChangeTargetList == null) {
            ippanAnkenChangeTargetList = new ArrayList<>();
        }
        ippanAnkenChangeTargetList.add(data);
    }

    public void setShinkoMatomeAnkenTargetData(Map<String, String> data) {
        if (shinkoMatomeAnkenTargetList == null) {
            shinkoMatomeAnkenTargetList = new ArrayList<>();
        }
        shinkoMatomeAnkenTargetList.add(data);
    }
    
}
