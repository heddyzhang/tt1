/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package jp.co.toshiba.hby.pspromis.syuueki.entity;

import java.io.Serializable;
import java.util.Date;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

/**
 *
 * @author ibayashi
 */
@Entity
@Table(name = "SYOKUSYU_MST")
public class SyokusyuMst implements Serializable {
    private static final long serialVersionUID = 1L;
    @Id
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 10)
    @Column(name = "JGRP_ID")
    private String jgrpId;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 2)
    @Column(name = "SYOKUSYU_CD")
    private String syokusyuCd;
    @Size(max = 60)
    @Column(name = "SYOKUSYU_NAME")
    private String syokusyuName;
    @Size(max = 5)
    @Column(name = "BU_CODE")
    private String buCode;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 2)
    @Column(name = "ATSUKAI_DIVISION")
    private String atsukaiDivision;
    @Column(name = "DIVISION_SUB_NAME")
    private String divisionSubName;
    @Column(name = "DIVISION_SUB_CODE")
    private String divisionSubCode;
    @Size(max = 256)
    @Column(name = "BIKO")
    private String biko;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 1)
    @Column(name = "IS_DELETED")
    private String isDeleted;
    @Column(name = "CREATED_AT")
    @Temporal(TemporalType.TIMESTAMP)
    private Date createdAt;
    @Size(max = 128)
    @Column(name = "CREATED_BY")
    private String createdBy;
    @Column(name = "UPDATED_AT")
    @Temporal(TemporalType.TIMESTAMP)
    private Date updatedAt;
    @Size(max = 128)
    @Column(name = "UPDATED_BY")
    private String updatedBy;

    @Column(name = "JGRP_PET_NAME")
    private String jgrpPetName;

    public SyokusyuMst() {
    }

    public SyokusyuMst(String jgrpId) {
        this.jgrpId = jgrpId;
    }

    public String getJgrpId() {
        return jgrpId;
    }

    public void setJgrpId(String jgrpId) {
        this.jgrpId = jgrpId;
    }

    public String getSyokusyuCd() {
        return syokusyuCd;
    }

    public void setSyokusyuCd(String syokusyuCd) {
        this.syokusyuCd = syokusyuCd;
    }

    public String getSyokusyuName() {
        return syokusyuName;
    }

    public void setSyokusyuName(String syokusyuName) {
        this.syokusyuName = syokusyuName;
    }

    public String getBuCode() {
        return buCode;
    }

    public void setBuCode(String buCode) {
        this.buCode = buCode;
    }

    public String getAtsukaiDivision() {
        return atsukaiDivision;
    }

    public void setAtsukaiDivision(String atsukaiDivision) {
        this.atsukaiDivision = atsukaiDivision;
    }

    public String getBiko() {
        return biko;
    }

    public void setBiko(String biko) {
        this.biko = biko;
    }

    public String getIsDeleted() {
        return isDeleted;
    }

    public void setIsDeleted(String isDeleted) {
        this.isDeleted = isDeleted;
    }

    public Date getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(Date createdAt) {
        this.createdAt = createdAt;
    }

    public String getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    public Date getUpdatedAt() {
        return updatedAt;
    }

    public void setUpdatedAt(Date updatedAt) {
        this.updatedAt = updatedAt;
    }

    public String getUpdatedBy() {
        return updatedBy;
    }

    public void setUpdatedBy(String updatedBy) {
        this.updatedBy = updatedBy;
    }

    public String getJgrpPetName() {
        return jgrpPetName;
    }

    public void setJgrpPetName(String jgrpPetName) {
        this.jgrpPetName = jgrpPetName;
    }

    public String getDivisionSubName() {
        return divisionSubName;
    }

    public void setDivisionSubName(String divisionSubName) {
        this.divisionSubName = divisionSubName;
    }

    public String getDivisionSubCode() {
        return divisionSubCode;
    }

    public void setDivisionSubCode(String divisionSubCode) {
        this.divisionSubCode = divisionSubCode;
    }
    
}
