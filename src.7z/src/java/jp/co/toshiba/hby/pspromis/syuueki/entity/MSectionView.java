/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package jp.co.toshiba.hby.pspromis.syuueki.entity;

import java.io.Serializable;
import java.util.Date;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
//import javax.persistence.Transient;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

/**
 *
 * @author ibayashi
 */
@Entity
public class MSectionView implements Serializable {
    private static final long serialVersionUID = 1L;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 12)
    @Column(name = "SECTION_ID")
    private String sectionId;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 3)
    @Column(name = "SEQ1")
    private String seq1;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 3)
    @Column(name = "SEQ2")
    private String seq2;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 3)
    @Column(name = "SEQ3")
    private String seq3;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 3)
    @Column(name = "SEQ4")
    private String seq4;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 3)
    @Column(name = "SEQ5")
    private String seq5;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 3)
    @Column(name = "SEQ6")
    private String seq6;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 3)
    @Column(name = "SEQ7")
    private String seq7;
    @Id
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 10)
    @Column(name = "DEPT_CD")
    private String deptCd;
    @Size(max = 90)
    @Column(name = "DEPT_NAME2")
    private String deptName2;
    @Size(max = 90)
    @Column(name = "DEPT_NAME3")
    private String deptName3;
    @Size(max = 45)
    @Column(name = "DEPT_ABB_NAME1")
    private String deptAbbName1;
    @Size(max = 45)
    @Column(name = "DEPT_ABB_NAME2")
    private String deptAbbName2;
    @Size(max = 45)
    @Column(name = "DEPT_ABB_NAME3")
    private String deptAbbName3;
    @Size(max = 135)
    @Column(name = "DEPT_ABB_NAME")
    private String deptAbbName;
    @Size(max = 60)
    @Column(name = "DEPT_NAME1_EN")
    private String deptName1En;
    @Size(max = 60)
    @Column(name = "DEPT_NAME2_EN")
    private String deptName2En;
    @Size(max = 60)
    @Column(name = "DEPT_NAME3_EN")
    private String deptName3En;
    @Size(max = 3)
    @Column(name = "CORP_CD")
    private String corpCd;
    @Size(max = 2)
    @Column(name = "DIV_CD")
    private String divCd;
    @Size(max = 2)
    @Column(name = "DIV_SUB_CD")
    private String divSubCd;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 10)
    @Column(name = "UPPER_DEPT_CD")
    private String upperDeptCd;
    @Basic(optional = false)
    @NotNull
    @Column(name = "AVAIL_FROM")
    @Temporal(TemporalType.TIMESTAMP)
    private Date availFrom;
    @Basic(optional = false)
    @NotNull
    @Column(name = "AVAIL_TO")
    @Temporal(TemporalType.TIMESTAMP)
    private Date availTo;
    @Column(name = "INSERT_DATE")
    @Temporal(TemporalType.TIMESTAMP)
    private Date insertDate;
    @Column(name = "UPDATE_DATE")
    @Temporal(TemporalType.TIMESTAMP)
    private Date updateDate;

    @Column(name = "DEPT_LEVEL")
    private String deptLevel;

    public MSectionView() {
    }

    public String getSectionId() {
        return sectionId;
    }

    public void setSectionId(String sectionId) {
        this.sectionId = sectionId;
    }

    public String getSeq1() {
        return seq1;
    }

    public void setSeq1(String seq1) {
        this.seq1 = seq1;
    }

    public String getSeq2() {
        return seq2;
    }

    public void setSeq2(String seq2) {
        this.seq2 = seq2;
    }

    public String getSeq3() {
        return seq3;
    }

    public void setSeq3(String seq3) {
        this.seq3 = seq3;
    }

    public String getSeq4() {
        return seq4;
    }

    public void setSeq4(String seq4) {
        this.seq4 = seq4;
    }

    public String getSeq5() {
        return seq5;
    }

    public void setSeq5(String seq5) {
        this.seq5 = seq5;
    }

    public String getSeq6() {
        return seq6;
    }

    public void setSeq6(String seq6) {
        this.seq6 = seq6;
    }

    public String getSeq7() {
        return seq7;
    }

    public void setSeq7(String seq7) {
        this.seq7 = seq7;
    }

    public String getDeptCd() {
        return deptCd;
    }

    public void setDeptCd(String deptCd) {
        this.deptCd = deptCd;
    }

    public String getDeptName2() {
        return deptName2;
    }

    public void setDeptName2(String deptName2) {
        this.deptName2 = deptName2;
    }

    public String getDeptName3() {
        return deptName3;
    }

    public void setDeptName3(String deptName3) {
        this.deptName3 = deptName3;
    }

    public String getDeptAbbName1() {
        return deptAbbName1;
    }

    public void setDeptAbbName1(String deptAbbName1) {
        this.deptAbbName1 = deptAbbName1;
    }

    public String getDeptAbbName2() {
        return deptAbbName2;
    }

    public void setDeptAbbName2(String deptAbbName2) {
        this.deptAbbName2 = deptAbbName2;
    }

    public String getDeptAbbName3() {
        return deptAbbName3;
    }

    public void setDeptAbbName3(String deptAbbName3) {
        this.deptAbbName3 = deptAbbName3;
    }

    public String getDeptAbbName() {
        return deptAbbName;
    }

    public void setDeptAbbName(String deptAbbName) {
        this.deptAbbName = deptAbbName;
    }

    public String getDeptName1En() {
        return deptName1En;
    }

    public void setDeptName1En(String deptName1En) {
        this.deptName1En = deptName1En;
    }

    public String getDeptName2En() {
        return deptName2En;
    }

    public void setDeptName2En(String deptName2En) {
        this.deptName2En = deptName2En;
    }

    public String getDeptName3En() {
        return deptName3En;
    }

    public void setDeptName3En(String deptName3En) {
        this.deptName3En = deptName3En;
    }

    public String getCorpCd() {
        return corpCd;
    }

    public void setCorpCd(String corpCd) {
        this.corpCd = corpCd;
    }

    public String getDivCd() {
        return divCd;
    }

    public void setDivCd(String divCd) {
        this.divCd = divCd;
    }

    public String getDivSubCd() {
        return divSubCd;
    }

    public void setDivSubCd(String divSubCd) {
        this.divSubCd = divSubCd;
    }

    public String getUpperDeptCd() {
        return upperDeptCd;
    }

    public void setUpperDeptCd(String upperDeptCd) {
        this.upperDeptCd = upperDeptCd;
    }

    public Date getAvailFrom() {
        return availFrom;
    }

    public void setAvailFrom(Date availFrom) {
        this.availFrom = availFrom;
    }

    public Date getAvailTo() {
        return availTo;
    }

    public void setAvailTo(Date availTo) {
        this.availTo = availTo;
    }

    public Date getInsertDate() {
        return insertDate;
    }

    public void setInsertDate(Date insertDate) {
        this.insertDate = insertDate;
    }

    public Date getUpdateDate() {
        return updateDate;
    }

    public void setUpdateDate(Date updateDate) {
        this.updateDate = updateDate;
    }

    public String getDeptLevel() {
        return deptLevel;
    }

    public void setDeptLevel(String deptLevel) {
        this.deptLevel = deptLevel;
    }

}
