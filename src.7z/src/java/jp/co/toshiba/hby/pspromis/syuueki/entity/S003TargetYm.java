package jp.co.toshiba.hby.pspromis.syuueki.entity;

import java.io.Serializable;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.validation.constraints.NotNull;

/**
 *
 * @author sano
 */
@Entity
public class S003TargetYm implements Serializable {
    private static final long serialVersionUID = 1L;
    @Id
    @NotNull
    @Column(name = "ANKEN_ID")
    private String ankenId;
    @Id
    @NotNull
    @Column(name = "RIREKI_ID")
    private String rirekiId;
    
    @Id
    @Column(name = "SYUEKI_YM")
    private String syuekiYm;
    
    @Column(name = "SYUEKI_YM_DATE")
    private String syuekiYmDate;

    @Id
    @Column(name = "DATA_KBN")
    private String dataKbn;
    
    @Column(name = "CLASS_NAME")
    private String className;

    @Column(name = "DISP_ADD_FLG")
    private String dispAddFlg;

    @Column(name = "KAISYU_KBN")
    private String kaisyuKbn;

    @Column(name = "DISP_BIKO_FLG")
    private String dispBikoFlg;
    
    @Column(name = "URIAGE_ITEM_FLG")
    private String uriageItemFlg;
    
    public S003TargetYm() {
    }

    public String getAnkenId() {
        return this.ankenId;
    }

    public void setAnkenId(String ankenId) {
        this.ankenId = ankenId;
    }

    public String getRirekiId() {
        return this.rirekiId;
    }

    public void setRirekiId(String rirekiId) {
        this.rirekiId = rirekiId;
    }

    public String getSyuekiYm() {
        return this.syuekiYm;
    }

    public void setSyuekiYm(String syuekiYm) {
        this.syuekiYm = syuekiYm;
    }
    
    public String getSyuekiYmDate() {
        return this.syuekiYmDate;
    }

    public void setSyuekiYmDate(String syuekiYmDate) {
        this.syuekiYmDate = syuekiYmDate;
    }

    public String getDispAddFlg() {
        return dispAddFlg;
    }

    public void setDispAddFlg(String dispAddFlg) {
        this.dispAddFlg = dispAddFlg;
    }

    public String getDataKbn() {
        return dataKbn;
    }

    public void setDataKbn(String dataKbn) {
        this.dataKbn = dataKbn;
    }

    public String getClassName() {
        return className;
    }

    public void setClassName(String className) {
        this.className = className;
    }

    public String getDispBikoFlg() {
        return dispBikoFlg;
    }

    public void setDispBikoFlg(String dispBikoFlg) {
        this.dispBikoFlg = dispBikoFlg;
    }

    public String getKaisyuKbn() {
        return kaisyuKbn;
    }

    public void setKaisyuKbn(String kaisyuKbn) {
        this.kaisyuKbn = kaisyuKbn;
    }

    public String getUriageItemFlg() {
        return uriageItemFlg;
    }

    public void setUriageItemFlg(String uriageItemFlg) {
        this.uriageItemFlg = uriageItemFlg;
    }

}

