package jp.co.toshiba.hby.pspromis.syuueki.facade;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.ejb.Stateless;
import javax.inject.Inject;
import javax.interceptor.Interceptors;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import jp.co.toshiba.hby.pspromis.syuueki.entity.SyuKiJyuchuSpTbl;
import jp.co.toshiba.hby.pspromis.syuueki.entity.StringEntity;
import jp.co.toshiba.hby.pspromis.syuueki.interceptor.TranceInterceptor;
import jp.co.toshiba.hby.pspromis.syuueki.util.LoginUserInfo;
import org.apache.commons.collections.CollectionUtils;

/**
 *
 * @author ibayashi
 */
@Stateless
@Interceptors({TranceInterceptor.class})
public class SyuKiJyuchuSpTblFacade extends AbstractFacade<SyuKiJyuchuSpTbl> {

    @PersistenceContext(unitName = jp.co.toshiba.hby.pspromis.syuueki.util.ConstantString.syuuekiDataSourceName)
    private EntityManager em;

    @Inject
    private LoginUserInfo loginUserInfo;

    @Override
    protected EntityManager getEntityManager() {
        return em;
    }

    public SyuKiJyuchuSpTblFacade() {
        super(SyuKiJyuchuSpTbl.class);
    }
    
    /**
     * パラメータにログイン者idをセット
     */
    private Map<String, Object> addParamLoginId(Map<String, Object> _params) {
        Map<String, Object> ret = _params;
        if (ret == null) {
            ret = new HashMap<>();
        }
        ret.put("userId", loginUserInfo.getUserId());
        return ret;
    }

    /**
     * 受注管理SP情報 通貨情報の取得
     * @param _params
     * @return 
     */
    public List<SyuKiJyuchuSpTbl> findCurrencyList(Map<String, Object> _params) {
        List<SyuKiJyuchuSpTbl> list
                = sqlExecutor.getResultList(em, SyuKiJyuchuSpTbl.class, "sql/syuKiJyuchuSpTbl/selectCurrencyList.sql", _params);
        
        return list;
    }
    
    /**
     * 受注管理/受注レート・SPの更新(更新/新規登録)
     * @param _params
     * @param isForceEntryFlg 受注SPが未登録(null)でも強制的にレコードを作成するFLG
     * @return 
     */
    public int entryJyuchuSpRate(Map<String, Object> _params) {
        return entryJyuchuSpRate(_params, false);
    }
    
    /**
     * 受注管理/受注レート・SPの更新(更新/新規登録)
     * @param _params
     * @param isForceEntryFlg 受注SPが未登録(null)でも強制的にレコードを作成するFLG
     * @return 
     */
    public int entryJyuchuSpRate(Map<String, Object> _params, boolean isForceEntryFlg) {
        int count = 0;
        Object amount = _params.get("jyuchuSp");
        
        if (amount == null && !isForceEntryFlg) {
            // 削除
            this.deleteJyuchuSpRate(_params);
        } else {
            // 更新
            count = this.updateJyuchuSpRate(_params);
            // 更新データ存在しない場合は新規登録
            if (count == 0 && (amount != null || isForceEntryFlg)) {
                count = this.insertJyuchuSpRate(_params);
            }
        }

        return count;
    }

    /**
     * 受注管理/受注レート・SPの更新(新規登録)
     * @param _params
     * @return 
     */
    public int insertJyuchuSpRate(Map<String, Object> _params) {
        Map<String, Object> params = addParamLoginId(_params);
        int count = sqlExecutor.executeUpdateSql(em, "/sql/syuKiJyuchuSpTbl/insertSyuKiJyuchuSpTbl.sql", params);
        return count;
    }
    
    /**
     * 受注管理/受注レート・SPの更新
     * @param _params
     * @return 
     */
    public int updateJyuchuSpRate(Map<String, Object> _params) {
        Map<String, Object> params = addParamLoginId(_params);
        int count = sqlExecutor.executeUpdateSql(em, "/sql/syuKiJyuchuSpTbl/updateSyuKiJyuchuSpTblSpRate.sql", params);
        return count;
    }

    /**
     * 受注管理 削除
     * @param _params
     * @return 
     */
    public int deleteJyuchuSpRate(Map<String, Object> _params) {
        int count= sqlExecutor.executeUpdateSql(em, "/sql/syuKiJyuchuSpTbl/deleteSyuKiJyuchuSpTbl.sql", _params);
        return count;
    }

    /**
     * 受注管理/通貨情報の件数を取得
     * @param _params
     * @return 
     */
    public Integer getCountJyuchuSp(Map<String, Object> _params) {
        Integer count = sqlExecutor.getCount(em, "/sql/syuKiJyuchuSpTbl/countCurrencyCode.sql", _params);
        return count;
    }
    
    /**
     * 最新の年月を取得
     * @param params
     * @return 
     */
    public String getMaxSyuekiYm(Map<String, Object> params){
        List<StringEntity> list = sqlExecutor.getResultList(em, StringEntity.class, "/sql/syuKiJyuchuSpTbl/selectMaxSyuekiYm.sql", params);
        
        if (CollectionUtils.isNotEmpty(list)) {
            return list.get(0).getString().trim();
        } else {
            return "";
        }
    }

    /**
     * 売上年月の更新
     * @param _params
     */
    public int changeSyuekiYm(Map<String, Object> _params){
        int count = sqlExecutor.executeUpdateSql(em, "/sql/syuKiJyuchuSpTbl/changeSyuekiYm.sql", _params);
        return count;
    }
    
}
