package jp.co.toshiba.hby.pspromis.syuueki.servlet;

import javax.inject.Inject;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import jp.co.toshiba.hby.pspromis.syuueki.bean.OpenDetailBean;
import jp.co.toshiba.hby.pspromis.syuueki.service.OpenDetailService;
import jp.co.toshiba.hby.pspromis.syuueki.util.ConstantString;
import jp.co.toshiba.hby.pspromis.syuueki.util.ParameterBinder;

/**
 * PS-Promis収益管理システム
 * 案件検索 開くボタン Servlet
 * @author koga
 */
@WebServlet(name = "OpenDetail", urlPatterns = {"/servlet/OpenDetail", "/servlet/OpenDetail/*"})
public class OpenDetailServlet extends AbstractServlet {

    @Inject
    private OpenDetailService openDetailService;
    
    @Inject
    private OpenDetailBean openDetailBean;

     /**
     * データ取得
     * @param req
     * @param resp
     * @return
     * @throws Exception 
     */
    public String indexAction(HttpServletRequest req, HttpServletResponse resp)
    throws Exception {
       logger.info("OpenDetailServlet#indexAction");
       
//       ParameterBinder.Bind(openDetailBean, req);
//       openDetailService.indexExecute();
//
//       String url = "";
//       if (ConstantString.salesClassS.equals(openDetailBean.getSalesClass())) {
//           url = "/servlet/S004";
//       } else {
//           url = "/servlet/S003";
//       }
//
//       resp.sendRedirect(req.getContextPath() + url + "?ankenId=" + openDetailBean.getAnkenId());
       
        commonLogic(req, resp);

        resp.sendRedirect(req.getContextPath() + openDetailBean.getRedirectUrl() + "?ankenId=" + openDetailBean.getAnkenId());
        return null;
    }
    
    /**
     * 他システムからのリンク
     * @param req
     * @param resp
     * @return
     * @throws Exception 
     */
    public String otherLinkAction(HttpServletRequest req, HttpServletResponse resp)
    throws Exception {
       logger.info("OpenDetailServlet#otherLinkAction");
       
       commonLogic(req, resp);

       return "OpenDetail/otherLink.jsp";
    }
    
    /**
     * 共通処理
     */
    private void commonLogic(HttpServletRequest req, HttpServletResponse resp)
    throws Exception { 
       logger.info("OpenDetailServlet#indexAction");
       
       ParameterBinder.Bind(openDetailBean, req);
       openDetailService.indexExecute();

       String url;
       if (ConstantString.salesClassS.equals(openDetailBean.getSalesClass())) {
           url = "/servlet/S004";
       } else {
           url = "/servlet/S003";
       }
       openDetailBean.setRedirectUrl(url);
       
    }
}
