/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package jp.co.toshiba.hby.pspromis.syuueki.service.mikomiupload;

import java.text.ParseException;
import java.util.Date;
import jp.co.toshiba.hby.pspromis.syuueki.enums.Env;
import jp.co.toshiba.hby.pspromis.syuueki.util.Utils;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.time.DateFormatUtils;

/**
 *
 * @author ibayashi
 */
public class UploadUtil {
    
    // ↓ (2018/01)未使用になるため削除
//    public static String getBukaCategoryCode(String bukaCd) {
//        boolean exchangeFlg = false;
//        String categoryCode = null;
//        
//        // 水技P/水技S に該当する部課コードを取得
//        String exchangeBukaCode = Env.getValue(Env.SuigiBukaCode);
//        
//        // 指定した部課が水技P/水技Sであれば、カテゴリコードを強制的に"SUIGI"に変換
//        if(StringUtils.isNotEmpty(exchangeBukaCode)){
//            if (exchangeBukaCode.equals(bukaCd)) {
//                exchangeFlg = true;
//                categoryCode = "SUIGI";
//            }
//        }
//
//        // 指定した部課が水技P/水技Sでない場合は、部課コード+'000'をカテゴリコードとする。
//        if (!exchangeFlg) {
//            categoryCode = bukaCd.concat("000");
//        }
//        
//        return categoryCode;
//    }
    
    public static String getCldFileKbn(String kbn, String title) {
        String fileKbn = "";

        if ("05".equals(kbn)) {
            fileKbn = "CHK";
        } else if ("06".equals(kbn) && title.equals("直課除くＢ項番")) {
            fileKbn = "BIT";
        } else if ("06".equals(kbn) && title.equals("完成図書")) {
            fileKbn = "LIB";
        } else if ("06".equals(kbn) && title.equals("派遣人件費")) {
            fileKbn = "HAK";
        }

        return fileKbn;
    }
    
    public static String nenAdd1(String ymLabel) {
        String retStr = ymLabel;
        
	String nen = retStr.substring(0,2);
	String nenHan = nen;
 
	nenHan = String.valueOf(Integer.parseInt(nen) + 1);
        retStr = StringUtils.replace(retStr, nen, nenHan);
        
        return retStr;
    }
    
    public static String changeAmountStrSub(String amount) {
        if (StringUtils.isEmpty(amount)) {
            return null;
        }
        
        String checkAmount = amount;
        checkAmount = StringUtils.replace(checkAmount, "-", "");
	int point = checkAmount.lastIndexOf('.');
        if (point > 0) {
            checkAmount = StringUtils.substring(checkAmount, 0, point);
        }

        return checkAmount;
    }
    
    public static Date changeStrToDate(String dateStr) throws ParseException {
        String retStr = dateStr;
        
        if (StringUtils.length(retStr) < 6) {
            retStr = "20" + retStr;
        }
        if (StringUtils.length(StringUtils.substring(retStr, 4)) == 1) {
            retStr = StringUtils.substring(retStr, 0, 4) + "0" + StringUtils.substring(retStr, 4);
        }

        Date date = Utils.parseDate(retStr);
            
        return date;
    }

    public static String changeDateToStr(Date date) {
        return DateFormatUtils.format(date, "yyyyMM");
    }
    
    public static boolean isTargetOrderNo(String orderNo) {
        if (StringUtils.length(orderNo) < 1) {
            return false;
        }
        return true;
    }
}
