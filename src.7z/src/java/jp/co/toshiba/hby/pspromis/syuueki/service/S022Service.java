package jp.co.toshiba.hby.pspromis.syuueki.service;

import java.math.BigDecimal;
import java.sql.SQLException;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.sql.ResultSet;
import javax.ejb.Stateless;
import javax.inject.Inject;
import javax.interceptor.Interceptors;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
//import jp.co.toshiba.hby.pspromis.common.util.CollectionUtil;
import jp.co.toshiba.hby.pspromis.syuueki.bean.AggregateConditionBean;
import jp.co.toshiba.hby.pspromis.syuueki.bean.S001MstBean;
import jp.co.toshiba.hby.pspromis.syuueki.bean.S022Bean;
//import jp.co.toshiba.hby.pspromis.syuueki.bean.ValidationInfoBean;
//import jp.co.toshiba.hby.pspromis.syuueki.bean.ValidationMessageBean;
//import jp.co.toshiba.hby.pspromis.syuueki.entity.M0130BunruiOrg;
import jp.co.toshiba.hby.pspromis.syuueki.entity.M0130LineEigJobgr;
//import jp.co.toshiba.hby.pspromis.syuueki.entity.SyuWfControlTbl;
import jp.co.toshiba.hby.pspromis.syuueki.entity.TeamEntity;
import jp.co.toshiba.hby.pspromis.syuueki.entity.BuMst;
import jp.co.toshiba.hby.pspromis.syuueki.enums.Env;
import jp.co.toshiba.hby.pspromis.syuueki.enums.Label;
//import jp.co.toshiba.hby.pspromis.syuueki.enums.ValidatorMessage;
import jp.co.toshiba.hby.pspromis.syuueki.facade.KanjyoMstFacade;
//import jp.co.toshiba.hby.pspromis.syuueki.facade.M0130BunruiOrgFacade;
import jp.co.toshiba.hby.pspromis.syuueki.facade.M0130LineEigJobgrFacade;
import jp.co.toshiba.hby.pspromis.syuueki.facade.BuMstFacade;
import jp.co.toshiba.hby.pspromis.syuueki.facade.SyuWfControlTblFacade;
import jp.co.toshiba.hby.pspromis.syuueki.facade.TeamMstFacade;
import jp.co.toshiba.hby.pspromis.syuueki.facade.JgrpTblFacade;
import jp.co.toshiba.hby.pspromis.syuueki.facade.MSectionFacade;
import jp.co.toshiba.hby.pspromis.syuueki.interceptor.TranceInterceptor;
import jp.co.toshiba.hby.pspromis.syuueki.jdbc.DbUtilsExecutor;
import jp.co.toshiba.hby.pspromis.syuueki.jdbc.SqlFile;
import jp.co.toshiba.hby.pspromis.syuueki.util.DateUtils;
import jp.co.toshiba.hby.pspromis.syuueki.util.LoginUserInfo;
import jp.co.toshiba.hby.pspromis.syuueki.util.SyuuekiUtils;
import jp.co.toshiba.hby.pspromis.syuueki.util.Utils;
import jp.co.toshiba.hby.pspromis.syuueki.jdbc.ResultSetManeger;
import jp.co.toshiba.hby.pspromis.syuueki.pages.DivisonComponentPage;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.ArrayUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 *
 * @author rnomura
 */
@Stateless
@Interceptors({TranceInterceptor.class})
public class S022Service {
    /**
     * ロガー
     */
    public static final Logger logger = LoggerFactory.getLogger(S022Service.class);
    
    @PersistenceContext(unitName = jp.co.toshiba.hby.pspromis.syuueki.util.ConstantString.syuuekiDataSourceName)
    private EntityManager em;

    @Inject
    private S022Bean s022Bean;
    
    @Inject
    private AggregateConditionBean aggregateConditionBean;
    /**
     * Injection loginUserInfo
     * (ユーザー情報(ユーザーid,名称,所属部課名)を格納したオブジェクト)
     */
    @Inject
    private LoginUserInfo loginUserInfo;

    //@Inject
    //private DetailHeader dateilHeader;

    //@Inject
    //private OperationLogService operationLogService;
    
    @Inject
    private KanjyoMstFacade kanjyoMstFacade;
    
    @Inject
    private S001MstBean s001MstBean;
    
    @Inject
    private M0130LineEigJobgrFacade m0130LineEigJobgrFacade;
    
    @Inject
    private TeamMstFacade teamMstFacade;
    
    @Inject
    private JgrpTblFacade jgrpTblFacade;
    
    @Inject
    private MSectionFacade mSectionFacade;
    
    @Inject
    private BuMstFacade buMstFacade;

    @Inject
    private SyuWfControlTblFacade syuWfControlTblFacade;
    
    @Inject
    private SyuuekiUtils sUtils;
    
    @Inject
    private Utils utils;
    
    @Inject
    private DbUtilsExecutor dbUtilsExecutor;

    @Inject
    private SyuuekiCommonService syuuekiCommonService;
    
    @Inject
    private DivisonComponentPage divisionComponentPage;
    
    /**
     * 画面表示　ビジネスロジック
     * @throws Exception 
     */
    public void indexExecute() throws Exception {
        logger.info("S022Service#indexExecute");
        
        // 検索条件の各種候補のマスタデータ取得
        setMstData();

        // 検索条件の初期化
        initCondition();

        // ログイン者所属JobGrによるBU/SBU検索条件のデフォルト選択
        String[] loginDivisionCodes = loginUserInfo.getJobGrSyokusyuArrayInfo("division");
        setInitLoginDefaultBuSelect(loginDivisionCodes, s001MstBean.getBuMstList());
    }

    /**
     * 主管JobGr取得ビジネスロジック
     * @throws Exception 
     */
    public void syukanJobGrMstExecute() throws Exception {
        // 主管JobGrは設計部門が属するので、職種"E"で取得
        //s001MstBean.setSyukanJobGrList(jgrpTblFacade.getJobGrList("E", aggregateConditionBean.getDivisionCode()));
        setBeanSyukanJobGrMst(aggregateConditionBean.getDivisionCode());
    }

    /**
     * 主管JobGrの取得して、Beanにセット
     */
    private void setBeanSyukanJobGrMst(String divisionCode) throws Exception {
        s001MstBean.setSyukanSectList(mSectionFacade.findDivisionSyokusyuList("E", divisionCode));
    }

    /**
     * 検索パターン選択からの表示 ビジネスロジック
     */
    public void patternIndexExecute() throws Exception {
        logger.info("S022Service#patternIndexExecute");
        initConditionRequired();
    }

    /**
     * 一覧検索処理
     */
    public void listExecute() throws Exception {
        logger.info("S022Service#listExecute");
        
        // 検索結果部のstyleセット
        setResultSytle();
        
        // 検索結果の取得
        getSearchResult();

        if(aggregateConditionBean.getComparison().equals("Y")){
            getYosanList();
        }
        
        setDefaultYm();
        
        // (事業部を兼務している場合)検索条件で選択した事業部以外のBUデフォルト選択が外れてしまうため
        // 選択した事業部以外のBUデフォルト選択を元に戻す
        setSearchAfterLoginDefaultBuSelect(s001MstBean.getBuMstList());

        s022Bean.setListFlg("1");
    }

    /**
     * 対象案件の事業部が(原子力)タイプであるかを確認するための情報をbeanにセット
     */
    public void setBeanIsNuclear() {
        boolean isNuclearDivision = divisionComponentPage.isNuclearDivision(aggregateConditionBean.getDivisionCode());
        aggregateConditionBean.setNuclearDivision(isNuclearDivision);
    }
    
    /**
     * マスタデータを全て再取得
     */
    public void setMstDataAll() throws Exception {
        s001MstBean.setTeamMstList(null);
        s001MstBean.setLineEigJobGrList(null);
        s001MstBean.setSyukanSectList(null);
        
        setMstData();
    }
    
    /**
     * マスタデータ取得
     */
    private void setMstData() throws Exception {
        // ログイン者所属事業部
        String[] loginDivisionCodes = loginUserInfo.getJobGrSyokusyuArrayInfo("division");
        
        // チームコードマスタ
        if (s001MstBean.getTeamMstList() == null) {
            List<TeamEntity> teamMstList = teamMstFacade.findUserTeamList(loginUserInfo.getUserId());
            s001MstBean.setTeamMstList(teamMstList);
        }
        
        // 営業担当マスタ(Step4)
        if (s001MstBean.getLineEigJobGrList() == null) {
            Map<String, Object> lineEigCondition = new HashMap<>();
            lineEigCondition.put("divisionCode", loginDivisionCodes);

            List<M0130LineEigJobgr> lineEigJobGrList = m0130LineEigJobgrFacade.findLineEigNameList(lineEigCondition);
            s001MstBean.setLineEigJobGrList(lineEigJobGrList);
        }
        
        // 主管JobGrマスタ(電力ジ対応で条件追加)
        // ログイン者が所属する(原子力)事業部コードを取得
        String targetDivisionCode = getTargetDivisionCode();
        // 主管部門は設計部門が属するので、職種"E"で取得
        setBeanSyukanJobGrMst(targetDivisionCode);
        //s001MstBean.setSyukanSectList(jgrpTblFacade.getJobGrList("E", targetDivisionCode));
        
        // BUマスタ(電力ジ対応で条件追加)
        if (s001MstBean.getBuMstList() == null) {
            Map<String, Object> buMstCondtion = new HashMap<>();
            buMstCondtion.put("divisionCode", loginDivisionCodes);
            List<BuMst> buMstList = buMstFacade.findConditionList(buMstCondtion);
            s001MstBean.setBuMstList(buMstList);
        }

    }
    
    /**
     * 事業部コードの取得
     */
    private String getTargetDivisionCode() {
        String divisionCode = aggregateConditionBean.getDivisionCode();
        if (StringUtils.isEmpty(divisionCode)) {
            divisionCode = loginUserInfo.getPriorityDivCode();
        }
        return divisionCode;
    }

    /**
     * 検索条件初期化
     */
    private void initCondition() throws SQLException, ParseException {
        initConditionRequired();

        // 事業部
        aggregateConditionBean.setDivisionCode(getTargetDivisionCode());

        // 売上基準
        String[] salesClass = {"0", "1"};
        aggregateConditionBean.setSalesClass(salesClass);

        //20180302 原価回収基準対応　ADD START
        aggregateConditionBean.setSalesClassGenka("1");
        //20180302 原価回収基準対応　ADD END 
        
        aggregateConditionBean.setDispKbn("1"); 

        // 見積種類
        String[] mitumoriKbn = new String[1];
        mitumoriKbn[0] = Env.getValue(Env.Mitumori_Seitehai);
        aggregateConditionBean.setMitumoriKbn(mitumoriKbn);

        // BU、SUBBU
        aggregateConditionBean.setBuId(null);
        aggregateConditionBean.setSubBuId(null);

        // チームコード
        aggregateConditionBean.setMyTeamFlg("D");

        // 1次集計単位
        aggregateConditionBean.setPrimaryUnit("0");
        
        // 2次集計単位
        aggregateConditionBean.setSecondaryUnit("5");

        // 横軸集計
        String[] yokozikuAgg = {"0", "2", "4"};
        aggregateConditionBean.setYokozikuAgg(yokozikuAgg);

        // 出力項目
        String[] outputItems = {"1"};
        aggregateConditionBean.setOutputItem(outputItems);
        
        // 出力単位
        //s022Bean.setOutputUnit("0");

        // 比較データ
        aggregateConditionBean.setComparison("N");
        
        setDefaultYm();
        
        // 表示単位
        aggregateConditionBean.setJpyUnit("2");
    }

    /**
     * 検索条件の初期化(画面食表示・パターン検索関わらず必ず行う処理)
     */
    private void initConditionRequired() {
        s022Bean.setListFlg("0");
        s022Bean.setConditionFlg("1");
        s022Bean.setCount(null);
        s022Bean.setPage(null);
    }
    
    /**
     * ログイン者のdivisionSubNameと検索条件指定のBUコードが等しいBU情報をデフォルトで選択状態にする
     * (検索条件:BUのデフォルト選択で利用)
     * @param buMstList buマスタ一覧(BU/SBU検索条件の候補となるリスト)
     */
    private void setInitLoginDefaultBuSelect(String[] divisionCodes, List<BuMst> buMstList) {
        String[] buArray = aggregateConditionBean.getBuId();
        String[] sbuArray = aggregateConditionBean.getSubBuId();

        for (String divisionCode: divisionCodes) {
            String[] defaultBuArray = getLoginDefaultBuSbuSelect(divisionCode, buMstList, 0);
            String[] defaultSbuArray = getLoginDefaultBuSbuSelect(divisionCode, buMstList, 1);
            
            buArray = ArrayUtils.addAll(defaultBuArray, buArray);
            sbuArray = ArrayUtils.addAll(defaultSbuArray, sbuArray);
        }

        aggregateConditionBean.setBuId(buArray);
        aggregateConditionBean.setSubBuId(sbuArray);
    }
    
    /**
     * ログイン者のdivisionSubNameと検索条件指定のBUコードが等しいBU情報をデフォルトで選択状態にする
     * (検索条件:BUのデフォルト選択で利用)
     * @param buMstList buマスタ一覧(BU/SBU検索条件の候補となるリスト)
     */
    private void setSearchAfterLoginDefaultBuSelect(List<BuMst> buMstList) {
        if (CollectionUtils.isEmpty(buMstList)) {
            return;
        }

        // 検索条件で選択している以外のBUを取得
        String[] targetDivisionCodes = loginUserInfo.getJobGrSyokusyuArrayInfo("division");
        List<String> oterDivisionCodeList = new ArrayList<>();
        for (String loginDivisionCode: targetDivisionCodes) {
            if (!loginDivisionCode.equals(aggregateConditionBean.getDivisionCode())) {
                oterDivisionCodeList.add(loginDivisionCode);
            }
        }
        
        targetDivisionCodes = (String[])oterDivisionCodeList.toArray(new String[0]);
        setInitLoginDefaultBuSelect(targetDivisionCodes, s001MstBean.getBuMstList());
    }

    /**
     * ログイン者のdivisionSubNameと検索条件指定のBUコードが等しいBU情報を配列で取得
     * @param buMstList buマスタ一覧(BU/SBU検索条件の候補となるリスト)
     * @kbn BU配列を取得するかSBU配列を取得するかを決定(0:BU配列 1:SBU配列)
     */
    private String[] getLoginDefaultBuSbuSelect(String divisionCode, List<BuMst> buMstList, int kbn) {
        String[] defaultBuSbuArray = syuuekiCommonService.getDefaultLoginSameBuArray(divisionCode, buMstList, kbn);
        logger.info("kbn=[{}], defaultBuSbuArray=[{}]", kbn, defaultBuSbuArray);
        return defaultBuSbuArray;
    }
    
    /**
     * 検索条件デフォルト年月関係
     */
    private void setDefaultYm() throws ParseException{
        Date now = new Date();
        String kanjo = kanjyoMstFacade.getNowKanjoDate("0");
        String nowKi = SyuuekiUtils.dateToKikan(DateUtils.parseDate(kanjo));
        
        // 対象データ(「月」選択用)
        if(StringUtils.isEmpty(aggregateConditionBean.getTargetFrom()) && StringUtils.isEmpty(aggregateConditionBean.getTargetTo())){
            String[] kikan = SyuuekiUtils.getKikanMonthAry(nowKi);
            if(kikan != null && kikan.length == 6){
                aggregateConditionBean.setTargetFrom(sUtils.getLabelMonth(kikan[0]));
                aggregateConditionBean.setTargetTo(sUtils.getLabelMonth(kikan[5]));
            }
        }
        
        // 対象データ(「4Q」「期」選択用)
        if(StringUtils.isEmpty(aggregateConditionBean.getTargetFromKiYm()) && StringUtils.isEmpty(aggregateConditionBean.getTargetToKiYm())){
            if(SyuuekiUtils.getIntegerMonth(kanjo) >= 1 && SyuuekiUtils.getIntegerMonth(kanjo) <= 3){
                aggregateConditionBean.setTargetFromKiYm(String.valueOf(SyuuekiUtils.getIntegerYear(nowKi.substring(0, 4))-1));
                aggregateConditionBean.setTargetToKiYm(String.valueOf(SyuuekiUtils.getIntegerYear(nowKi.substring(0, 4))-1));
            } else {
                aggregateConditionBean.setTargetFromKiYm(nowKi.substring(0, 4));
                aggregateConditionBean.setTargetToKiYm(nowKi.substring(0, 4));
            }
            aggregateConditionBean.setTargetFromKi(nowKi.substring(nowKi.length()-1));
            aggregateConditionBean.setTargetToKi(nowKi.substring(nowKi.length()-1));
        }
        
        //対象データ(「年度」選択用)
        if(StringUtils.isEmpty(aggregateConditionBean.getTargetFromNendo()) && StringUtils.isEmpty(aggregateConditionBean.getTargetToNendo())){
            if(SyuuekiUtils.getIntegerMonth(kanjo) >= 1 && SyuuekiUtils.getIntegerMonth(kanjo) <= 3){
                aggregateConditionBean.setTargetFromNendo(String.valueOf(Integer.valueOf(nowKi.substring(0, 4))-1));
                aggregateConditionBean.setTargetToNendo(String.valueOf(Integer.valueOf(nowKi.substring(0, 4))-1));
            } else {
                aggregateConditionBean.setTargetFromNendo(nowKi.substring(0, 4));
                aggregateConditionBean.setTargetToNendo(nowKi.substring(0, 4));
            }
        }
        
        // 確定月
        String befYm = "";
        String befMonth = SyuuekiUtils.addMonth(kanjo, -3);
        if(StringUtils.isEmpty(aggregateConditionBean.getComparisonData())){
            String[] befQuartArr = SyuuekiUtils.getQuarterMonthAry(sUtils.getTargetQuarterLabel(befMonth)); 
            if(befQuartArr != null && befQuartArr.length == 3){
                befYm = sUtils.getLabelMonth(befQuartArr[2]);
            }
            aggregateConditionBean.setComparisonData(befYm);
        }

    }
    
    /**
     * 検索結果部の表示スタイルをセット
     */
    public void setResultSytle() throws ParseException{
        setCellStyle();
        
        // 出力単位ラベル部分のリストを作成
        getOutputItemLabel();
        
        List<Map<String, Object>> kikanList = new ArrayList<>();
        if(Arrays.asList(aggregateConditionBean.getYokozikuAgg()).contains("0")){
            // 横軸集計で「月」が選択されている場合
            kikanList = getMonthList();
        } else if(Arrays.asList(aggregateConditionBean.getYokozikuAgg()).contains("1") || Arrays.asList(aggregateConditionBean.getYokozikuAgg()).contains("2")){
            // 横軸集計で「月」が選択されず、「4Q」または「期」が選択されている場合
            kikanList = getQuarterList();
        } else if(Arrays.asList(aggregateConditionBean.getYokozikuAgg()).contains("3")){
            // 横軸集計で「月」「4Q」「期」が選択されず、「年度」が選択されている場合
            kikanList = getNendoList();
        } else {
            kikanList = getSumList();
        }

//for (Map<String, Object> yokozikuInfo: kikanList) {
//    String syuekiYm = yokozikuInfo.get("syuekiYm").toString();
//    String dataKbn = yokozikuInfo.get("dataKbn").toString();
//    String dispLabel = yokozikuInfo.get("dispLabel").toString();
//    
//    System.out.println("syuekiYm=" + syuekiYm + " dataKbn=" + dataKbn + " dispLabel=" + dispLabel);
//}
        
        aggregateConditionBean.setYokozikuList(kikanList);

        
        // (電力ジ対応)で追加
        // Step4リリース現在、検索条件の「対象データ」指定の期間で案件を絞っていないためデータが多すぎて、Excel出力などで容量オーバーで落ちやすくなっている
        // そのため、指定期間内に受注/売上/回収のデータが存在する案件のみを絞って検索するように条件を追加する。
        // 以下のメソッドはその条件を作成している(上記で作ったkikanListを元に作成する)
        createConditionParameterKikan(kikanList);
    }
    
    // 検索結果部：ヘッダー部rowspanなどセット処理
    private void setCellStyle(){
        int secRowspan = 0;
        int comRowspan = 0;
        
        if(aggregateConditionBean.getOutputItem() != null){
            // 出力単位「受注展開」が選択されている場合
            if(Arrays.asList(aggregateConditionBean.getOutputItem()).contains("0")){
                comRowspan++;
            }
            // 出力単位「売上展開」が選択されている場合
            if(Arrays.asList(aggregateConditionBean.getOutputItem()).contains("1")){
                comRowspan++;
            }
            // 出力単位「回収展開」が選択されている場合
            if(Arrays.asList(aggregateConditionBean.getOutputItem()).contains("2")){
                comRowspan++;
            }
        }
        
        if(aggregateConditionBean.getComparison().equals("N")){
            // 比較データ「対象なし」の場合
            secRowspan = comRowspan;
        } else{
            // 比較データ「月次確定」or 「予算確定」の場合
            secRowspan = comRowspan * 3;
        }
        
        aggregateConditionBean.setComparisonRowspan(comRowspan);
        aggregateConditionBean.setSecondaryRowspan(secRowspan);
    }
    
    // 検索結果部：ヘッダー部ラベルリスト作成処理(「受注」「売上」「回収」、「今回値」「前回値」「差」)
    private void getOutputItemLabel(){
        List<String> outList = new ArrayList<>();
        if(aggregateConditionBean.getOutputItem() != null){
            if(Arrays.asList(aggregateConditionBean.getOutputItem()).contains("0")){
                outList.add(Label.jyuchu.getLabel());
            }
            if(Arrays.asList(aggregateConditionBean.getOutputItem()).contains("1")){
                outList.add(Label.uriage.getLabel());
            }
            if(Arrays.asList(aggregateConditionBean.getOutputItem()).contains("2")) {
                outList.add(Label.kaisyu.getLabel());
            }
        }
        aggregateConditionBean.setOutputLabelList(outList);
        
        List<String> comList = new ArrayList<>();
        comList.add(Label.now.getLabel());
        if(!aggregateConditionBean.getComparison().equals("N")){
            comList.add(Label.before.getLabel());
            comList.add(Label.diff2.getLabel());
        }
        aggregateConditionBean.setComparisonLabelList(comList);
    }
    
    // 横軸集計のラベル部分のリストを作成(「月」選択時)
    private List<Map<String, Object>> getMonthList() throws ParseException{
        String targetFrom = "";
        String targetTo = "";
        int targetYear = 0;
        int targetMonth = 0;
        
        if(StringUtils.isNotEmpty(aggregateConditionBean.getTargetFrom())){
            targetFrom = aggregateConditionBean.getTargetFrom().replace("/", "");
        }
        if(StringUtils.isNotEmpty(aggregateConditionBean.getTargetTo())){
            targetTo = aggregateConditionBean.getTargetTo().replace("/", "");
        }
        
        // 対象データのFromもしくはToが入力されていない場合、最大範囲でセットする
        if(StringUtils.isNotEmpty(targetFrom) && StringUtils.isEmpty(targetTo)){
            targetTo = SyuuekiUtils.addMonth(targetFrom, Integer.valueOf(Env.Aggregate_Max_Range_Month.getValue())-1);
            aggregateConditionBean.setTargetTo(targetTo.substring(0, 4) + "/" + targetTo.substring(4));
        } else if(StringUtils.isEmpty(targetFrom) && StringUtils.isNotEmpty(targetTo)){
            targetFrom = SyuuekiUtils.addMonth(targetTo, -(Integer.valueOf(Env.Aggregate_Max_Range_Month.getValue())-1));
            aggregateConditionBean.setTargetFrom(targetFrom.substring(0, 4) + "/" + targetFrom.substring(4));
        }
        
        List<Map<String, Object>> kikanList = new ArrayList<>();
        while(true) {
            Map<String, Object> monthMap = new HashMap<>();
            String target = targetFrom.substring(0, 4) + "/" + targetFrom.substring(4);
            targetYear =Integer.valueOf(targetFrom.substring(0, 4));
            targetMonth = Integer.valueOf(targetFrom.substring(4));
            monthMap.put("syuekiYm", targetFrom);
            monthMap.put("dataKbn", "J");
            monthMap.put("dispLabel", target);
            kikanList.add(monthMap);
            
            // 「4Q」が選択されている場合
            if(Arrays.asList(aggregateConditionBean.getYokozikuAgg()).contains("1")) {
                if (targetMonth % 3 == 0) {
                    Map<String, Object> quartMap = new HashMap<>();
                    quartMap.put("dataKbn", "Q");
                    quartMap.put("syuekiYm", SyuuekiUtils.getTargetQuarterLabel(targetFrom));
                    quartMap.put("dispLabel", SyuuekiUtils.getChangeQLabel(targetFrom));
                    kikanList.add(quartMap);
                }
            }
            
            // 「期」が選択されている場合
            if (Arrays.asList(aggregateConditionBean.getYokozikuAgg()).contains("2")) {
                if (targetMonth % 6 == 3) {
                    Map<String, Object> kiMap = new HashMap<>();
                    String dataKi = SyuuekiUtils.dateToKikan(DateUtils.parseDate(targetFrom));
                    String dispKi = sUtils.kikanLabel(dataKi);
                    kiMap.put("dataKbn", "K");
                    kiMap.put("syuekiYm", dataKi);
                    kiMap.put("dispLabel", dispKi);
                    kikanList.add(kiMap);
                }
            }
            
            // 「年度」が選択されている場合
            if (Arrays.asList(aggregateConditionBean.getYokozikuAgg()).contains("3")) {
                if (targetMonth == 3) {
                    Map<String, Object> nendoMap = new HashMap<>();
                    String nendo = String.valueOf(targetYear - 1) + Label.nendo.getLabel();
                    nendoMap.put("dataKbn", "Y");
                    nendoMap.put("dispLabel", nendo);
                    nendoMap.put("syuekiYm", targetFrom);
                    kikanList.add(nendoMap);
                }
            }
            
            targetFrom = SyuuekiUtils.addMonth(targetFrom, 1);
            
            if (Integer.valueOf(targetFrom) > Integer.valueOf(targetTo)) {
                break;
            }
        }
        
        // 「4Q」が選択されており対象月が途中で終わった場合
        if(Arrays.asList(aggregateConditionBean.getYokozikuAgg()).contains("1")){
            if(targetMonth % 3 != 0){
                Map<String, Object> quartMap = new HashMap<>();
                quartMap.put("dataKbn", "Q");
                quartMap.put("syuekiYm", SyuuekiUtils.getTargetQuarterLabel(targetFrom));
                quartMap.put("dispLabel", SyuuekiUtils.getChangeQLabel(targetFrom));
                kikanList.add(quartMap);
            }
            
        }
        
        // 「期」が選択されており対象月が途中で終わった場合
        if (Arrays.asList(aggregateConditionBean.getYokozikuAgg()).contains("2")) {
            if (targetMonth % 6 != 3) {
                Map<String, Object> kiMap = new HashMap<>();
                String dataKi = SyuuekiUtils.dateToKikan(DateUtils.parseDate(targetFrom));
                String dispKi = sUtils.kikanLabel(dataKi);
                kiMap.put("dataKbn", "K");
                kiMap.put("syuekiYm", dataKi);
                kiMap.put("dispLabel", dispKi);
                kikanList.add(kiMap);
            }
        }
        
        // 「年度」が選択されており対象月が途中で終わった場合
        if (Arrays.asList(aggregateConditionBean.getYokozikuAgg()).contains("3")) {
            if (targetMonth != 3) {
                Map<String, Object> nendoMap = new HashMap<>();
                String nendo = String.valueOf(targetYear) + Label.nendo.getLabel();
                nendoMap.put("dataKbn", "Y");
                nendoMap.put("dispLabel", nendo);
                nendoMap.put("syuekiYm", targetFrom);
                kikanList.add(nendoMap);
            }
        }
        
        // 「合計」が選択されている場合
        if(Arrays.asList(aggregateConditionBean.getYokozikuAgg()).contains("4")){
            Map<String, Object> sumMap = new HashMap<>();
            sumMap.put("dataKbn", "G");
            sumMap.put("syuekiYm", "999900G");
            sumMap.put("dispLabel", Label.total.getLabel());
            kikanList.add(sumMap);
        }
        
        // 「最終見込」が選択されている場合
        if(Arrays.asList(aggregateConditionBean.getYokozikuAgg()).contains("5")){
            Map<String, Object> saishuMap = new HashMap<>();
            saishuMap.put("dataKbn", "F");
            saishuMap.put("syuekiYm", "999900F");
            saishuMap.put("dispLabel", Label.lastMikomi.getLabel());
            kikanList.add(saishuMap);
        }
        
        return kikanList;
    }
    
    // 横軸集計のラベル部分のリストを作成(「4Q」「期」選択時)
    private List<Map<String, Object>> getQuarterList() throws ParseException{
        List<Map<String, Object>> kikanList = new ArrayList<>();
        String targetFrom = "";
        String targetTo = "";
        int targetYear = 0;
        int targetMonth = 0;
        
        if(StringUtils.isNotEmpty(aggregateConditionBean.getTargetFromKiYm())){
            targetFrom = SyuuekiUtils.labelKikan(aggregateConditionBean.getTargetFromKiYm() + aggregateConditionBean.getTargetFromKi());
        }
        if(StringUtils.isNotEmpty(aggregateConditionBean.getTargetToKiYm())){
            targetTo = SyuuekiUtils.labelKikan(aggregateConditionBean.getTargetToKiYm() + aggregateConditionBean.getTargetToKi());
        }
        
        if(StringUtils.isNotEmpty(targetFrom) && StringUtils.isEmpty(targetTo)){
            targetTo = SyuuekiUtils.calcKikan(targetFrom, Integer.valueOf(Env.Aggregate_Max_Range_Period.getValue())-1);
            if(targetTo.substring(4).equals("03S")){
                aggregateConditionBean.setTargetToKiYm(String.valueOf(Integer.valueOf(targetTo.substring(0, 4))-1));
                aggregateConditionBean.setTargetToKi("S");
            } else {
                aggregateConditionBean.setTargetToKiYm(targetTo.substring(0, 4));
                aggregateConditionBean.setTargetToKi("K");
            }
            
            
        } else if(StringUtils.isEmpty(targetFrom) && StringUtils.isNotEmpty(targetTo)){
            targetFrom = SyuuekiUtils.calcKikan(targetTo, -(Integer.valueOf(Env.Aggregate_Max_Range_Period.getValue())-1));
            if(targetFrom.substring(4).equals("03S")){
                aggregateConditionBean.setTargetFromKiYm(String.valueOf(Integer.valueOf(targetFrom.substring(0, 4))-1));
                aggregateConditionBean.setTargetFromKi("S");
            } else {
                aggregateConditionBean.setTargetFromKiYm(targetFrom.substring(0, 4));
                aggregateConditionBean.setTargetFromKi("K");
            }
        }
        
        while(true){
            targetYear = Integer.valueOf(targetFrom.substring(0, 4));
            targetMonth = Integer.valueOf(targetFrom.substring(4, 6));
            
            // 「4Q」が選択されている場合
            if(Arrays.asList(aggregateConditionBean.getYokozikuAgg()).contains("1")) {
                Map<String, Object> quartMap1 = new HashMap<>();
                Map<String, Object> quartMap2 = new HashMap<>();
                
                // 期間よりデータ取得用syuuekiYmを作成
                String syuekiYm1 = "";
                String syuekiYm2 = "";
                if(targetFrom.substring(4, 7).equals("09K")){
                    syuekiYm1 = SyuuekiUtils.getTargetQuarterLabel(targetFrom.substring(0, 4) + "04");
                    syuekiYm2 = SyuuekiUtils.getTargetQuarterLabel(targetFrom.substring(0, 4) + "07");
                } else if(targetFrom.substring(4, 7).equals("03S")){
                    syuekiYm1 = SyuuekiUtils.getTargetQuarterLabel(String.valueOf(targetYear - 1) + "10");
                    syuekiYm2 = SyuuekiUtils.getTargetQuarterLabel(String.valueOf(targetYear) + "01");
                }

                // 期間より画面用Quarterラベルを作成
                String dispLabel1 = "";
                String dispLabel2 = "";
                if(targetFrom.substring(4, 7).equals("09K")){
                    dispLabel1 = targetFrom.substring(0, 4) + "/1Q";
                    dispLabel2 = targetFrom.substring(0, 4) + "/2Q";
                }else if(targetFrom.substring(4, 7).equals("03S")){
                    dispLabel1 = String.valueOf(targetYear - 1) + "/3Q";
                    dispLabel2 = String.valueOf(targetYear - 1) + "/4Q";
                }
                
                quartMap1.put("dataKbn", "Q");
                quartMap1.put("syuekiYm", syuekiYm1);
                quartMap1.put("dispLabel", dispLabel1);
                kikanList.add(quartMap1);
                
                quartMap2.put("dataKbn", "Q");
                quartMap2.put("syuekiYm", syuekiYm2);
                quartMap2.put("dispLabel", dispLabel2);
                kikanList.add(quartMap2);
            }
            
            // 「期」が選択されている場合
            if (Arrays.asList(aggregateConditionBean.getYokozikuAgg()).contains("2")) {
                Map<String, Object> kiMap = new HashMap<>();
                String dispKi = sUtils.kikanLabel(targetFrom);
                kiMap.put("dataKbn", "K");
                kiMap.put("syuekiYm", targetFrom);
                kiMap.put("dispLabel", dispKi);
                kikanList.add(kiMap);
            }
            
            // 「年度」が選択されている場合
            if (Arrays.asList(aggregateConditionBean.getYokozikuAgg()).contains("3")) {
                if(targetMonth == 3){
                    Map<String, Object> nendoMap = new HashMap<>();
                    String nendo = String.valueOf(targetYear - 1) + Label.nendo.getLabel();
                    nendoMap.put("dataKbn", "Y");
                    nendoMap.put("dispLabel", nendo);
                    nendoMap.put("syuekiYm", targetFrom);
                    kikanList.add(nendoMap);
                }
                
            }
            
            targetFrom = sUtils.calcKikan(targetFrom, 1);
            
            if(targetFrom.compareTo(targetTo) > 0){
                break;
            }
        }
        
        // 「合計」が選択されている場合
        if(Arrays.asList(aggregateConditionBean.getYokozikuAgg()).contains("4")){
            Map<String, Object> sumMap = new HashMap<>();
            sumMap.put("dataKbn", "G");
            sumMap.put("syuekiYm", "999900G");
            sumMap.put("dispLabel", Label.total.getLabel());
            kikanList.add(sumMap);
        }
        
        // 「最終見込」が選択されている場合
        if(Arrays.asList(aggregateConditionBean.getYokozikuAgg()).contains("5")){
            Map<String, Object> saishuMap = new HashMap<>();
            saishuMap.put("dataKbn", "F");
            saishuMap.put("syuekiYm", "999900F");
            saishuMap.put("dispLabel", Label.lastMikomi.getLabel());
            kikanList.add(saishuMap);
        }
        
        return kikanList;
    }
    
    // 横軸集計のラベル部分のリストを作成(「年度」選択時)
    private List<Map<String, Object>> getNendoList() throws ParseException{
        List<Map<String, Object>> kikanList = new ArrayList<>();
        String targetFrom = "";
        String targetTo = "";
        int targetYear = 0;
        
        if(StringUtils.isNotEmpty(aggregateConditionBean.getTargetFromNendo())){
            targetFrom = aggregateConditionBean.getTargetFromNendo() + "04";
        }
        if(StringUtils.isNotEmpty(aggregateConditionBean.getTargetToNendo())){
            targetTo = aggregateConditionBean.getTargetToNendo() + "04";
        }
        
        if(StringUtils.isNotEmpty(targetFrom) && StringUtils.isEmpty(targetTo)){
            targetTo = SyuuekiUtils.addYear(targetFrom, Integer.valueOf(Env.Aggregate_Max_Range_Year.getValue())-1);
            aggregateConditionBean.setTargetToNendo(targetTo.substring(0, 4));
        }else if(StringUtils.isEmpty(targetFrom) && StringUtils.isNotEmpty(targetTo)){
            targetFrom = SyuuekiUtils.addYear(targetTo, -(Integer.valueOf(Env.Aggregate_Max_Range_Year.getValue())-1));
            aggregateConditionBean.setTargetFromNendo(targetFrom.substring(0, 4));
        }

        while(true){
            Map<String, Object> nendoMap = new HashMap<>();
            String nendo = targetFrom.substring(0, 4) + Label.nendo.getLabel();
            nendoMap.put("dataKbn", "Y");
            nendoMap.put("dispLabel", nendo);
            nendoMap.put("syuekiYm", targetFrom);
            kikanList.add(nendoMap);
            
            targetFrom = SyuuekiUtils.addYear(targetFrom, 1);
            
            if(Integer.valueOf(targetFrom) > Integer.valueOf(targetTo)){
                break;
            }
        }
        
        // 「合計」が選択されている場合
        if(Arrays.asList(aggregateConditionBean.getYokozikuAgg()).contains("4")){
            Map<String, Object> sumMap = new HashMap<>();
            sumMap.put("dataKbn", "G");
            sumMap.put("syuekiYm", "999900G");
            sumMap.put("dispLabel", Label.total.getLabel());
            kikanList.add(sumMap);
        }
        
        // 「最終見込」が選択されている場合
        if(Arrays.asList(aggregateConditionBean.getYokozikuAgg()).contains("5")){
            Map<String, Object> saishuMap = new HashMap<>();
            saishuMap.put("dataKbn", "F");
            saishuMap.put("syuekiYm", "999900F");
            saishuMap.put("dispLabel", Label.lastMikomi.getLabel());
            kikanList.add(saishuMap);
        }
        
        return kikanList;
    }
    
    // 横軸集計のラベル部分のリストを作成(「月」「4Q」「期」「年度」未選択時)
    private List<Map<String, Object>> getSumList() throws ParseException{
        List<Map<String, Object>> kikanList = new ArrayList<>();
        
        // 「合計」が選択されている場合
        if(Arrays.asList(aggregateConditionBean.getYokozikuAgg()).contains("4")){
            Map<String, Object> sumMap = new HashMap<>();
            sumMap.put("dataKbn", "G");
            sumMap.put("syuekiYm", "999900G");
            sumMap.put("dispLabel", Label.total.getLabel());
            kikanList.add(sumMap);
        }
        
        // 「最終見込」が選択されている場合
        if(Arrays.asList(aggregateConditionBean.getYokozikuAgg()).contains("5")){
            Map<String, Object> saishuMap = new HashMap<>();
            saishuMap.put("dataKbn", "F");
            saishuMap.put("syuekiYm", "999900F");
            saishuMap.put("dispLabel", Label.lastMikomi.getLabel());
            kikanList.add(saishuMap);
        }
        
        return kikanList;
    }
    
    /**
     * 検索結果の取得
     * @throws SQLException 
     */
    public void getSearchResult() throws Exception{
        String sqlFilePath = "/sql/syuGeBukkenInfoTbl/selectAggregateList.sql";
        
        String rirekiId = "";
        if(aggregateConditionBean.getComparison().equals("G") || aggregateConditionBean.getComparison().equals("Y")){
            Map<String, Object> param = new HashMap<>();
            param.put("divisionCode", aggregateConditionBean.getDivisionCode());
            if (aggregateConditionBean.getSalesClass() != null) {
                param.put("salesClass", Arrays.asList(aggregateConditionBean.getSalesClass()));
            }
            
            //20180302 原価回収基準対応　ADD START
            if (aggregateConditionBean.getSalesClassGenka() != null) {
                param.put("salesClassGenka", aggregateConditionBean.getSalesClassGenka());
            }
            //20180302 原価回収基準対応　ADD END 
        
            if(aggregateConditionBean.getComparison().equals("G")) {
                param.put("taishoYm", aggregateConditionBean.getComparisonData().replace("/", ""));
            } else {
                param.put("taishoYm", aggregateConditionBean.getSelComparisonData());
            }
            
            rirekiId = syuWfControlTblFacade.findRirekiId(param);
            if(StringUtils.isNotEmpty(rirekiId)){
                String[] ary = rirekiId.split(",");
                String rId = "";
                for(String id : ary){
                    rId = rId + "'" + id + "',";
                }
                rirekiId = rId.substring(0, rId.length()-1);
            }
        }

        // 一覧データの検索
        Map<String, Object> condition = getCondition(rirekiId);
        List<Map<String, Object>> list = getResultList(sqlFilePath, condition);

        s022Bean.setAggregateList(list);
    }

    /**
     * 一覧データを取得
     */
    private List<Map<String, Object>> getResultList(String sql, Map<String, Object> condition) throws Exception {
        ResultSetManeger resultSetManeger = new ResultSetManeger();
        ResultSet rset = null;

        try {
            boolean isFirstData = true;
            Integer allDataCount = 0;

            List<Map<String, Object>> list = new ArrayList<>();
            rset = resultSetManeger.getResultSet(em, sql, condition);

            long startTime = System.currentTimeMillis();
            while (rset.next()) {
                Map<String, Object> data = new HashMap<>();
                resultSetManeger.setResultMap(data, rset);

                // 「差」行用のデータリスト作成
                if(aggregateConditionBean.getComparison().equals("G") || aggregateConditionBean.getComparison().equals("Y")){
                    data = setDiffData(data);
                }
                list.add(data);
                
                // 一覧データの総件数を取得
                if (isFirstData) {
                    allDataCount = ((BigDecimal)(data.get("ALL_ANKEN_DATA_COUNT"))).intValue();
                }
                isFirstData = false;
            }
            long endTime = System.currentTimeMillis();
            logger.info("集計表 一覧データResultSet→list変換 時間=[{}]", ((endTime - startTime) + "msec"));

            s022Bean.setCount(allDataCount);
            logger.info("案件データの総件数=[{}]", allDataCount);

            return list;
        } catch (OutOfMemoryError e) {
            logger.error("集計表 取得データ量が多すぎるためエラーが発生しました。", e);
            throw e;
        } catch (Exception e) {
            throw e;
        } finally {
            resultSetManeger.close(rset);
        }
    }
 
    /**
     * 「差」行用のデータリスト作成処理
     * @param aggList
     * @return 
     */
    private Map<String, Object> setDiffData(Map<String, Object> map){
        String jsKey = "J_SP_";
        String jnKey = "J_NET_";
        String usKey = "U_SP_";
        String unKey = "U_NET_";
        String ksKey = "K_SP_";

        // 総計行は処理を行わない
        if (map.get("TOTAL_KBN").equals(BigDecimal.ZERO)) {
            return map;
        }

        int num = 0;
        for (Map<String, Object> yoko: aggregateConditionBean.getYokozikuList()) {
            BigDecimal nowSpVal = (BigDecimal) map.get(jsKey + "NOW" + num);
            BigDecimal befSpVal = (BigDecimal) map.get(jsKey + "BEF" + num);
            BigDecimal difSpVal = sUtils.arari(nowSpVal, befSpVal);
            if (difSpVal != null) {
                map.put(jsKey + "DIF" + num, difSpVal);
            }

            nowSpVal = (BigDecimal) map.get(usKey + "NOW" + num);
            befSpVal = (BigDecimal) map.get(usKey + "BEF" + num);
            difSpVal = sUtils.arari(nowSpVal, befSpVal);
            if (difSpVal != null) {
                map.put(usKey + "DIF" + num, difSpVal);
            }

            nowSpVal = (BigDecimal) map.get(ksKey + "NOW" + num);
            befSpVal = (BigDecimal) map.get(ksKey + "BEF" + num);
            difSpVal = sUtils.arari(nowSpVal, befSpVal);
            if (difSpVal != null) {
                map.put(ksKey + "DIF" + num, difSpVal);
            }

            BigDecimal nowNetVal = (BigDecimal) map.get(jnKey + "NOW" + num);
            BigDecimal befNetVal = (BigDecimal) map.get(jnKey + "BEF" + num);
            BigDecimal difNetVal = sUtils.arari(nowNetVal, befNetVal);
            if (difNetVal != null) {
                map.put(jnKey + "DIF" + num, difNetVal);
            }

            nowNetVal = (BigDecimal) map.get(unKey + "NOW" + num);
            befNetVal = (BigDecimal) map.get(unKey + "BEF" + num);
            difNetVal = sUtils.arari(nowNetVal, befNetVal);
            if (difNetVal != null) {
                map.put(unKey + "DIF" + num, difNetVal);
            }

            num++;
        }
        
        return map;
    }

    private Map<String, Object> getCondition(String rirekiId){
        // 検索条件をセット
        Map<String, Object> condition = getSearchCondition();
        
        // 集計単位からSQL生成
        StringBuilder key = getKeySql();
        
        condition.put("key", String.valueOf(key));
        condition.put("keyCount", s022Bean.getKeyCount());
        
        // 集計データ部SQL作成
        StringBuilder selectSumData = getSelectSumDataSql(rirekiId);
        condition.put("selectSumData", selectSumData);
        
        // 案件毎のSUMMARYデータ部作成
        StringBuilder selectData = getSelectDataSql(rirekiId);
        condition.put("selectData", selectData);
        
        return condition;
    }
    
    /**
     * 画面の検索条件をセット
     * @return 
     */
    private Map<String, Object> getSearchCondition(){
        Map<String, Object> condition = new HashMap<>();

        // 事業部コード:(原子力)であるかを判断
        boolean isNuclearDivision = divisionComponentPage.isNuclearDivision(aggregateConditionBean.getDivisionCode());
        
        // 事業部
        //if (s001Bean.getDivisionCode() != null) {
        if (StringUtils.isNotEmpty(aggregateConditionBean.getDivisionCode())) {
            //condition.put("divisionCode", Arrays.asList(s001Bean.getDivisionCode()));
            condition.put("divisionCode", aggregateConditionBean.getDivisionCode());
        }
        // 売上基準
        if (aggregateConditionBean.getSalesClass() != null && aggregateConditionBean.getSalesClass().length > 0) {
            condition.put("salesClass", Arrays.asList(aggregateConditionBean.getSalesClass()));
        }
        //20180302 原価回収基準対応　ADD START
        if (aggregateConditionBean.getSalesClassGenka() != null) {
            condition.put("salesClassGenka", aggregateConditionBean.getSalesClassGenka());
        }
        //20180302 原価回収基準対応　ADD END 
        
        // 表示単位
        condition.put("dispKbn", aggregateConditionBean.getDispKbn());
        // 見積種類
        if(StringUtils.isNotEmpty(aggregateConditionBean.getDivisionCode()) && isNuclearDivision){
            if (aggregateConditionBean.getMitumoriKbn() != null && aggregateConditionBean.getMitumoriKbn().length > 0) {
                condition.put("mitumoriKbn", Arrays.asList(aggregateConditionBean.getMitumoriKbn()));
            }
        }
        // (電力ジ対応追加)主管課
        if (StringUtils.isNotEmpty(aggregateConditionBean.getSyukanJobGrId())) {
            condition.put("syukanJobGrId", aggregateConditionBean.getSyukanJobGrId());
        }
        // (電力ジ対応追加)サブBU
        if (aggregateConditionBean.getSubBuId() != null && aggregateConditionBean.getSubBuId().length > 0) {
            // 元画面から、他事業部のBUが渡ってくる可能性があるため、対象の事業部に該当するBUのみに絞って検索する
            Map<String, Object> targetSbuCondition = new HashMap<>();
            targetSbuCondition.put("divisionCode", aggregateConditionBean.getDivisionCode());
            targetSbuCondition.put("sbuCodeList", aggregateConditionBean.getSubBuId());
            List<BuMst> targetDivisionSbuList = buMstFacade.findConditionList(targetSbuCondition);
            List<String> sbuList = new ArrayList<>();
            for (BuMst buMst: targetDivisionSbuList) {
                sbuList.add(buMst.getSbuCode());
            }
            if (CollectionUtils.isNotEmpty(sbuList)) {
                condition.put("subBuId", sbuList);
            }
        }
        // チームコード
        condition.put("myTeamFlg", aggregateConditionBean.getMyTeamFlg());
        // 検索条件でチームコードの所属チームが選択されており、
        // 且つプルダウンが選択されていない場合、全ての候補が選択条件となる
        if ("T".equals(aggregateConditionBean.getMyTeamFlg()) && StringUtils.isEmpty(aggregateConditionBean.getMyTeamCd())) {
            List<TeamEntity> teamMstList = s001MstBean.getTeamMstList();
            List<String> teamCdList = new ArrayList<>();
            for (TeamEntity rec : teamMstList) {
                teamCdList.add(rec.getTeamCd().trim());
            }
            condition.put("myTeamCd", teamCdList);
        } else {
            List<String> teamCdList = new ArrayList<>();
            if(StringUtils.isNotEmpty(aggregateConditionBean.getMyTeamCd())) {
                teamCdList.add(aggregateConditionBean.getMyTeamCd().trim());
            }else{
                teamCdList.add(aggregateConditionBean.getMyTeamCd());
            }
            condition.put("myTeamCd", teamCdList);
        }
        condition.put("ankenTeamCode", aggregateConditionBean.getTeamCode());
        condition.put("atsukaiCCode", aggregateConditionBean.getHanbaiCode());
        // 営業担当
        if (StringUtils.isNotEmpty(aggregateConditionBean.getEigyoJobGrId())) {
            List<String> eigCodeList = m0130LineEigJobgrFacade.findLineEigCodeList(aggregateConditionBean.getDivisionCode(), aggregateConditionBean.getEigyoJobGrId(), true);
            // 検索条件：営業担当は、事業部によりマッチさせる項目が異なる。そのため以下にその判断用パラメータを設定
            if (CollectionUtils.isNotEmpty(eigCodeList)) {
                //if (StringUtils.equals(aggregateConditionBean.getDivisionCode(), divNuclear)) {
                if (isNuclearDivision) {
                    // 事業部:(原子力)として営業担当を検索
                    condition.put("eigyoJobGrCodeList", eigCodeList);
                } else {
                    // 事業部:(原子力以外)として営業担当を検索
                    condition.put("eigyoTeamCodeList", eigCodeList);
                }
            }
        }
        
        //勘定年月のセット
        condition.put("ippanKanjyoYm", kanjyoMstFacade.getNowKanjoDate("0"));
        condition.put("shinkouKanjyoYm", kanjyoMstFacade.getNowKanjoDate("1"));
        if(aggregateConditionBean.getComparison().equals("G")) {
            condition.put("befKanjyoYm", aggregateConditionBean.getComparisonData().replace("/", ""));
        } else if(aggregateConditionBean.getComparison().equals("Y")){
            String[] ym = SyuuekiUtils.getKikanMonthAry(aggregateConditionBean.getSelComparisonData().substring(0, 5));
            condition.put("befKanjyoYm", ym[0]);
        }
        
        ////// 受注/売上/回収のどの情報を出力するか？
        condition.put("jyuchuDataFlg", aggregateConditionBean.getJyuchuDataFlg());  // 受注データを出力(1:出力 0:未出力)
        condition.put("uriageDataFlg", aggregateConditionBean.getUriageDataFlg());  // 売上データを出力(1:出力 0:未出力)
        condition.put("kaisyuDataFlg", aggregateConditionBean.getKaisyuDataFlg());  // 回収データを出力(1:出力 0:未出力)

        ////// [対象データ]の期間を絞り込む条件を設定
        // 年月from-to
        //condition.put("conditionSyuekiYmFlg", aggregateConditionBean.getConditionSyuekiYmFlg());
        condition.put("conditionSyuekiYmFrom", aggregateConditionBean.getConditionSyuekiYmFrom());
        condition.put("conditionSyuekiYmTo", aggregateConditionBean.getConditionSyuekiYmTo());
        // 期(Q)のfrom-to
        //condition.put("conditionQuarterFlg", aggregateConditionBean.getConditionQuarterFlg());
        //condition.put("conditionQuarterFrom", aggregateConditionBean.getConditionQuarterFrom());
        //condition.put("conditionQuarterTo", aggregateConditionBean.getConditionQuarterTo());
        // 上/下期のfrom-to
        //condition.put("conditionPeriodFlg", aggregateConditionBean.getConditionPeriodFlg());
        //condition.put("conditionPeriodFrom", aggregateConditionBean.getConditionPeriodFrom());
        //condition.put("conditionPeriodTo", aggregateConditionBean.getConditionPeriodTo());
//        // 総合計データを出力するか否か?
//        condition.put("conditionGokeiFlg", aggregateConditionBean.getConditionGokeiFlg());
//        // 最終見込データを出力するか否か？
//        condition.put("conditionFmFlg", aggregateConditionBean.getConditionFmFlg());

        // 年月で範囲限定を行うか？
        condition.put("conditionPeriodFlg", aggregateConditionBean.getConditionPeriodFlg());
        
        return condition;
    }
    
    /**
     * 集計条件に応じたKEYを作成
     */
    private StringBuilder getKeySql(){
        StringBuilder key = new StringBuilder();
        int count = 0;
        String kbn;
        
        ////////////// 第1次集計SQL作成(s) //////////////
        //if(aggregateConditionBean.getPrimaryUnit().equals("0") || aggregateConditionBean.getPrimaryUnit().equals("2")){
        if (aggregateConditionBean.isPrimaryUnitBuka()) {
            if(aggregateConditionBean.getPrimaryUnit().equals("0")){
                //　集計単位:営業課
                kbn = "1";
            } else {
                // 集計単位:主管課
                kbn = "2";
            }
            key.append(", NVL(" + getSelectBuka("B_CD", kbn) + ", '	') AS KEY").append(String.valueOf(count)).append(" ");
            key.append(", NVL(" + getSelectBuka("B_NM", kbn) + ", ' ') AS KEY").append(String.valueOf(count)).append("_NAME ");
            count++;
            
            key.append(", NVL(" + getSelectBuka("K_CD", kbn) + ", '	') AS KEY").append(String.valueOf(count)).append(" ");
            key.append(", NVL(" + getSelectBuka("K_NM", kbn) + ", ' ') AS KEY").append(String.valueOf(count)).append("_NAME ");
            count++;

        } else if(aggregateConditionBean.getPrimaryUnit().equals("1")){
            // 集計単位:サブBU
            key.append(", NVL(BI.SUB_BU_ID, '	') AS KEY").append(String.valueOf(count)).append(" ");
            key.append(", NVL(BI.SUB_BU_NAME, ' ') AS KEY").append(String.valueOf(count)).append("_NAME ");
            count++;
            
        } else if (aggregateConditionBean.getPrimaryUnit().equals("6")){
            // 集計単位:BU
            //key.append(", NVL(TO_CHAR(BI.BU_ID), '	') AS KEY").append(String.valueOf(count)).append(" ");
            //key.append(", NVL(BI.BU_NAME, ' ') AS KEY").append(String.valueOf(count)).append("_NAME "); 
            key.append(", NVL(GET_BU_NAME(BI.SUB_BU_ID, BI.DIVISION_CODE), '	') AS KEY").append(String.valueOf(count)).append(" ");
            key.append(", NVL(GET_BU_NAME(BI.SUB_BU_ID, BI.DIVISION_CODE), ' ') AS KEY").append(String.valueOf(count)).append("_NAME ");
            count++;
            
        }
        ////////////// 第1次集計SQL作成(e) //////////////


        ////////////// 第2次集計SQL作成(s) //////////////
        //「営業課」、「主管課」が選択されている場合
        //if(aggregateConditionBean.getSecondaryUnit().equals("0") || aggregateConditionBean.getSecondaryUnit().equals("2")){
        if (aggregateConditionBean.isSecondaryUnitBuka()) {
            if(aggregateConditionBean.getSecondaryUnit().equals("0")){
                kbn = "1";
            } else {
                kbn = "2";
            }
            key.append(", NVL(" + getSelectBuka("K_CD", kbn) + ", '	') AS KEY").append(String.valueOf(count)).append(" ");
            key.append(", NVL(" + getSelectBuka("BK_NM", kbn) + ", ' ') AS KEY").append(String.valueOf(count)).append("_NAME ");
            count++;

        } else {
            // サブBUが選択されている場合
            if(aggregateConditionBean.getSecondaryUnit().equals("1")){
                key.append(", NVL(BI.SUB_BU_ID, '	') AS KEY").append(String.valueOf(count)).append(" ");
                key.append(", NVL(BI.SUB_BU_NAME, ' ') AS KEY").append(String.valueOf(count)).append("_NAME ");
                count++;
            }
            // 設置場所が選択されている場合
            if(aggregateConditionBean.getSecondaryUnit().equals("3")){
                key.append(", NVL(BI.STCH_NAME, '	') AS KEY").append(String.valueOf(count)).append(" ");
                key.append(", NVL(BI.STCH_NAME, ' ') AS KEY").append(String.valueOf(count)).append("_NAME ");
                count++;
            }
            // プラントコード + 収益分類が選択されている場合
            if(aggregateConditionBean.getSecondaryUnit().equals("4")){
                key.append(", NVL(BI.PLANT_CODE || ' ' || BI.BUNRUI_CD, '	') AS KEY").append(String.valueOf(count)).append(" ");
                key.append(", BI.PLANT_CODE || ' ' || (SELECT M1.BUNRUI_NM FROM N7_BUNRUI_MST M1 WHERE M1.BUNRUI_CD = BI.BUNRUI_CD AND M1.BU_CD = BI.SUB_BU_ID) AS KEY").append(String.valueOf(count)).append("_NAME ");
                count++;
            }
        }
        ////////////// 第2次集計SQL作成(e) //////////////
        
        // key2までSQLが作られていない場合
        if(count < 3) {
            // key1までSQLが作られていない場合
            if(count < 2){
                key.append(", NULL AS KEY1 ");
                key.append(", NULL AS KEY1_NAME ");
            }
            key.append(", NULL AS KEY2 ");
            key.append(", NULL AS KEY2_NAME ");
            
        }
        
        s022Bean.setKeyCount(count);
        logger.info("keyCount=[{}]", count);
        
        return key;
    }

    /**
     * 営業課・主管課のSELECT句取得
     * @param bukaKbn 1:営業課 2:主管課
     * @param valueKbn 取得する値
     */
    private String getSelectBuka(String bukaKbn, String valueKbn) {
        String select = "";

        // 事業部コード:(原子力)であるかを判断
        boolean isNuclearDivision = divisionComponentPage.isNuclearDivision(aggregateConditionBean.getDivisionCode());

        //if (divNuclear.equals(aggregateConditionBean.getDivisionCode())) {
        if (isNuclearDivision) {
            // 原子力
            select = "GET_SUM_BUKA_CODE_GEN(BI.ANKEN_ID, '" + bukaKbn + "', '" + valueKbn + "')";
        } else {
            // 火水ジ
            select = "GET_SUM_BUKA_CODE_KA(BI.ANKEN_TEAM_CODE, '" + bukaKbn + "')";
        }

        return select;
    }

    /**
     *  集計データ部SQL作成
     **/
    private StringBuilder getSelectSumDataSql(String rirekiId){
        StringBuilder selectSumData = new StringBuilder();
        
        StringBuilder jutyu = new StringBuilder();
        StringBuilder uriage = new StringBuilder();
        StringBuilder kaishu = new StringBuilder();
        
        // 出力項目「受注」が選択されている場合
        if(Arrays.asList(aggregateConditionBean.getOutputItem()).contains("0")){
            jutyu = getJutyuSumSql(rirekiId);
        }
        // 出力項目「売上」が選択されている場合
        if(Arrays.asList(aggregateConditionBean.getOutputItem()).contains("1")){
            uriage = getUriageSumSql(rirekiId);
        }
        // 出力項目「回収」が選択されている場合
        if(Arrays.asList(aggregateConditionBean.getOutputItem()).contains("2")){
            kaishu = getKaishuSumSql(rirekiId);
        }
        
        selectSumData.append(jutyu);
        selectSumData.append(uriage);
        selectSumData.append(kaishu);

        return selectSumData;
    }
    
    private StringBuilder getJutyuSumSql(String rirekiId){
        StringBuilder sql = new StringBuilder();
        int num = 0;
        
        // 受注SP取得sql
        for(Map<String, Object> map: aggregateConditionBean.getYokozikuList()){
            sql.append(", SUM(T1.J_SP_NOW");
            sql.append(num);
            sql.append(") AS J_SP_NOW");
            sql.append(num);
            sql.append(" ");
            
            num++;
        }
        
        num = 0;
        
        // 受注SP取得sql
        for(Map<String, Object> map: aggregateConditionBean.getYokozikuList()){
            sql.append(", SUM(T1.J_NET_NOW");
            sql.append(num);
            sql.append(") AS J_NET_NOW");
            sql.append(num);
            sql.append(" ");
            
            num++;
        }
        
        if(StringUtils.isNotEmpty(rirekiId)){
            num = 0;
            // 受注SP取得sql
            for(Map<String, Object> map: aggregateConditionBean.getYokozikuList()){
                sql.append(", SUM(T1.J_SP_BEF");
                sql.append(num);
                sql.append(") AS J_SP_BEF");
                sql.append(num);
                sql.append(" ");

                num++;
            }

            num = 0;

            // 受注SP取得sql
            for(Map<String, Object> map: aggregateConditionBean.getYokozikuList()){
                sql.append(", SUM(T1.J_NET_BEF");
                sql.append(num);
                sql.append(") AS J_NET_BEF");
                sql.append(num);
                sql.append(" ");

                num++;
            }
        }
        
        return sql;
    }
    
    private StringBuilder getUriageSumSql(String rirekiId){
        StringBuilder sql = new StringBuilder();
        int num = 0;
        
        for(Map<String, Object> map: aggregateConditionBean.getYokozikuList()){
            sql.append(", SUM(T1.U_SP_NOW");
            sql.append(num);
            sql.append(") AS U_SP_NOW");
            sql.append(num);
            sql.append(" ");
                    
            num++;
        }
        
        num = 0;
        
        for(Map<String, Object> map: aggregateConditionBean.getYokozikuList()){
            sql.append(", SUM(T1.U_NET_NOW");
            sql.append(num);
            sql.append(") AS U_NET_NOW");
            sql.append(num);
            sql.append(" ");
            
            num++;
        }
        
        if(StringUtils.isNotEmpty(rirekiId)){
            num = 0;
            
            for(Map<String, Object> map: aggregateConditionBean.getYokozikuList()){
                sql.append(", SUM(T1.U_SP_BEF");
                sql.append(num);
                sql.append(") AS U_SP_BEF");
                sql.append(num);
                sql.append(" ");

                num++;
            }

            num = 0;

            for(Map<String, Object> map: aggregateConditionBean.getYokozikuList()){
                sql.append(", SUM(T1.U_NET_BEF");
                sql.append(num);
                sql.append(") AS U_NET_BEF");
                sql.append(num);
                sql.append(" ");

                num++;
            }
        }
        
        return sql;
    }
    
    private StringBuilder getKaishuSumSql(String rirekiId){
        StringBuilder sql = new StringBuilder();
        int num = 0;
        
        for(Map<String, Object> map: aggregateConditionBean.getYokozikuList()){
            sql.append(", SUM(T1.K_SP_NOW");
            sql.append(num);
            sql.append(") AS K_SP_NOW");
            sql.append(num);
            sql.append(" ");
            
            num++;
        }
        
        if(StringUtils.isNotEmpty(rirekiId)){
            num = 0;
            
            for(Map<String, Object> map: aggregateConditionBean.getYokozikuList()){
                sql.append(", SUM(T1.K_SP_BEF");
                sql.append(num);
                sql.append(") AS K_SP_BEF");
                sql.append(num);
                sql.append(" ");

                num++;
            }
        }
        
        return sql;
    }
    
    private StringBuilder getSelectDataSql(String rirekiId){
        StringBuilder selectData = new StringBuilder();
        
        StringBuilder jutyu = new StringBuilder();
        StringBuilder uriage = new StringBuilder();
        StringBuilder kaishu = new StringBuilder();
        
        // 出力項目「受注」が選択されている場合
        if(Arrays.asList(aggregateConditionBean.getOutputItem()).contains("0")){
            jutyu = getJutyuSql(rirekiId);
        }
        // 出力項目「売上」が選択されている場合
        if(Arrays.asList(aggregateConditionBean.getOutputItem()).contains("1")){
            uriage = getUriageSql(rirekiId);
        }
        // 出力項目「回収」が選択されている場合
        if(Arrays.asList(aggregateConditionBean.getOutputItem()).contains("2")){
            kaishu = getKaishuSql(rirekiId);
        }
        
        selectData.append(jutyu);
        selectData.append(uriage);
        selectData.append(kaishu);
        
        return selectData;
    }
    
    /**
     * 受注行データ取得SQL作成処理
     * @return 
     */
    private StringBuilder getJutyuSql(String rirekiId){
        StringBuilder sql = new StringBuilder();
        int num = 0;
        
        // SP取得sql作成
        for(Map<String, Object> map: aggregateConditionBean.getYokozikuList()){
            String kbn = (String) map.get("dataKbn");
            String syuekiYm = (String) map.get("syuekiYm");
            
            switch(kbn) {
                case "J":
                    sql.append(", (SELECT S.JYUCHU_SP FROM SYU_KI_JYUCHU_TOTAL_TBL S WHERE S.ANKEN_ID = A.ANKEN_ID AND S.RIREKI_ID = A.RIREKI_ID AND S.DATA_KBN = (CASE WHEN S.SYUEKI_YM < A.NOW_KANJYO_YM THEN 'J' ELSE 'M' END) AND S.SYUEKI_YM = '");
                    sql.append(syuekiYm);
                    sql.append("') AS J_SP_NOW");
                    sql.append(num);
                    sql.append(" ");

                    break;
                case "Y":
                    String[] ym = SyuuekiUtils.getKikanFromYm(syuekiYm);
                    sql.append(", (SELECT SUM(S.JYUCHU_SP) FROM SYU_KI_JYUCHU_TOTAL_TBL S WHERE S.ANKEN_ID = A.ANKEN_ID AND S.RIREKI_ID = A.RIREKI_ID AND S.DATA_KBN = 'K' AND S.SYUEKI_YM IN ('");
                    sql.append(ym[0]);
                    sql.append("', '");
                    sql.append(ym[1]);
                    sql.append("')) AS J_SP_NOW");
                    sql.append(num);
                    sql.append(" ");

                    break;
                default :
                    sql.append(", (SELECT S.JYUCHU_SP FROM SYU_KI_JYUCHU_TOTAL_TBL S WHERE S.ANKEN_ID = A.ANKEN_ID AND S.RIREKI_ID = A.RIREKI_ID AND S.DATA_KBN = '");
                    sql.append(kbn);
                    sql.append("' AND S.SYUEKI_YM = '");
                    sql.append(syuekiYm);
                    sql.append("') AS J_SP_NOW");
                    sql.append(num);
                    sql.append(" ");
                    break;
            }
            
            num++;
        }
        
        num = 0;
        // NET取得sql作成
        for(Map<String, Object> map: aggregateConditionBean.getYokozikuList()){
            String kbn = (String) map.get("dataKbn");
            String syuekiYm = (String) map.get("syuekiYm");

            switch(kbn) {
                case "J":
                    sql.append(", (SELECT S.JYUCHU_NET FROM SYU_KI_JYUCHU_TOTAL_TBL S WHERE S.ANKEN_ID = A.ANKEN_ID AND S.RIREKI_ID = A.RIREKI_ID AND S.DATA_KBN = (CASE WHEN S.SYUEKI_YM < A.NOW_KANJYO_YM THEN 'J' ELSE 'M' END) AND S.SYUEKI_YM = '");
                    sql.append(syuekiYm);
                    sql.append("') AS J_NET_NOW");
                    sql.append(num);
                    sql.append(" ");

                    break;
                case "Y":
                    String[] ym = SyuuekiUtils.getKikanFromYm(syuekiYm);
                    sql.append(", (SELECT SUM(S.JYUCHU_NET) FROM SYU_KI_JYUCHU_TOTAL_TBL S WHERE S.ANKEN_ID = A.ANKEN_ID AND S.RIREKI_ID = A.RIREKI_ID AND S.DATA_KBN = 'K' AND S.SYUEKI_YM IN ('");
                    sql.append(ym[0]);
                    sql.append("', '");
                    sql.append(ym[1]);
                    sql.append("')) AS J_NET_NOW");
                    sql.append(num);
                    sql.append(" ");

                    break;
                default :
                    sql.append(", (SELECT S.JYUCHU_NET FROM SYU_KI_JYUCHU_TOTAL_TBL S WHERE S.ANKEN_ID = A.ANKEN_ID AND S.RIREKI_ID = A.RIREKI_ID AND S.DATA_KBN = '");
                    sql.append(kbn);
                    sql.append("' AND S.SYUEKI_YM = '");
                    sql.append(syuekiYm);
                    sql.append("') AS J_NET_NOW");
                    sql.append(num);
                    sql.append(" ");
                    break;
            }
            
            num++;
        }
        
        // 前回確定が選択されている場合
        if(StringUtils.isNotEmpty(rirekiId)){
            num = 0;
            // SP取得sql作成
            for(Map<String, Object> map: aggregateConditionBean.getYokozikuList()){
                String kbn = (String) map.get("dataKbn");
                String syuekiYm = (String) map.get("syuekiYm");

                switch(kbn) {
                    case "J":
                        sql.append(", (SELECT SUM(S.JYUCHU_SP) FROM SYU_R_KI_JYUCHU_TOTAL_TBL S WHERE S.ANKEN_ID = A.ANKEN_ID AND S.RIREKI_ID IN (");
                        sql.append(rirekiId);
                        sql.append(") AND S.DATA_KBN = (CASE WHEN S.SYUEKI_YM < A.BEF_KANJYO_YM THEN 'J' ELSE 'M' END) AND S.SYUEKI_YM = '");
                        sql.append(syuekiYm);
                        sql.append("') AS J_SP_BEF");
                        sql.append(num);
                        sql.append(" ");

                        break;
                    case "Y":
                        String[] ym = SyuuekiUtils.getKikanFromYm(syuekiYm);
                        sql.append(", (SELECT SUM(S.JYUCHU_SP) FROM SYU_R_KI_JYUCHU_TOTAL_TBL S WHERE S.ANKEN_ID = A.ANKEN_ID AND S.RIREKI_ID IN (");
                        sql.append(rirekiId);
                        sql.append(") AND S.DATA_KBN = 'K' AND S.SYUEKI_YM IN ('");
                        sql.append(ym[0]);
                        sql.append("', '");
                        sql.append(ym[1]);
                        sql.append("')) AS J_SP_BEF");
                        sql.append(num);
                        sql.append(" ");

                        break;
                    default :
                        sql.append(", (SELECT SUM(S.JYUCHU_SP) FROM SYU_R_KI_JYUCHU_TOTAL_TBL S WHERE S.ANKEN_ID = A.ANKEN_ID AND S.RIREKI_ID IN (");
                        sql.append(rirekiId);
                        sql.append(") AND S.DATA_KBN = '");
                        sql.append(kbn);
                        sql.append("' AND S.SYUEKI_YM = '");
                        sql.append(syuekiYm);
                        sql.append("') AS J_SP_BEF");
                        sql.append(num);
                        sql.append(" ");
                        break;
                }

                num++;
            }

            num = 0;
            // NET取得sql作成
            for(Map<String, Object> map: aggregateConditionBean.getYokozikuList()){
                String kbn = (String) map.get("dataKbn");
                String syuekiYm = (String) map.get("syuekiYm");

                switch(kbn) {
                    case "J":
                        sql.append(", (SELECT SUM(S.JYUCHU_NET) FROM SYU_R_KI_JYUCHU_TOTAL_TBL S WHERE S.ANKEN_ID = A.ANKEN_ID AND S.RIREKI_ID IN (");
                        sql.append(rirekiId);
                        sql.append(") AND S.DATA_KBN = (CASE WHEN S.SYUEKI_YM < A.BEF_KANJYO_YM THEN 'J' ELSE 'M' END) AND S.SYUEKI_YM = '");
                        sql.append(syuekiYm);
                        sql.append("') AS J_NET_BEF");
                        sql.append(num);
                        sql.append(" ");

                        break;
                    case "Y":
                        String[] ym = SyuuekiUtils.getKikanFromYm(syuekiYm);
                        sql.append(", (SELECT SUM(S.JYUCHU_NET) FROM SYU_R_KI_JYUCHU_TOTAL_TBL S WHERE S.ANKEN_ID = A.ANKEN_ID AND S.RIREKI_ID IN (");
                        sql.append(rirekiId);
                        sql.append(") AND S.DATA_KBN = 'K' AND S.SYUEKI_YM IN ('");
                        sql.append(ym[0]);
                        sql.append("', '");
                        sql.append(ym[1]);
                        sql.append("')) AS J_NET_BEF");
                        sql.append(num);
                        sql.append(" ");

                        break;
                    default :
                        sql.append(", (SELECT SUM(S.JYUCHU_NET) FROM SYU_R_KI_JYUCHU_TOTAL_TBL S WHERE S.ANKEN_ID = A.ANKEN_ID AND S.RIREKI_ID IN (");
                        sql.append(rirekiId);
                        sql.append(") AND S.DATA_KBN = '");
                        sql.append(kbn);
                        sql.append("' AND S.SYUEKI_YM = '");
                        sql.append(syuekiYm);
                        sql.append("') AS J_NET_BEF");
                        sql.append(num);
                        sql.append(" ");
                        break;
                }

                num++;
            }
        }
        
        return sql;
    }
    
    /**
     * 売上行データ取得SQL作成処理
     * @return 
     */
    private StringBuilder getUriageSql(String rirekiId){
        StringBuilder sql = new StringBuilder();
        int num = 0;
        
        // SP取得sql作成
        for(Map<String, Object> map: aggregateConditionBean.getYokozikuList()){
            String kbn = (String) map.get("dataKbn");
            String syuekiYm = (String) map.get("syuekiYm");
            
            switch(kbn){
                case "J" :
                    sql.append(", (SELECT S.URIAGE_AMOUNT FROM SYU_KI_SP_TOTAL_TBL S WHERE S.ANKEN_ID = A.ANKEN_ID AND S.RIREKI_ID = A.RIREKI_ID AND S.DATA_KBN = (CASE WHEN S.SYUEKI_YM < A.NOW_KANJYO_YM THEN 'J' ELSE 'M' END) AND S.SYUEKI_YM = '");
                    sql.append(syuekiYm);
                    sql.append("') AS U_SP_NOW");
                    sql.append(num);
                    sql.append(" ");
                    break;
                case "Y" :
                    String[] ym = SyuuekiUtils.getKikanFromYm(syuekiYm);
                    sql.append(", (SELECT SUM(S.URIAGE_AMOUNT) FROM SYU_KI_SP_TOTAL_TBL S WHERE S.ANKEN_ID = A.ANKEN_ID AND S.RIREKI_ID = A.RIREKI_ID AND S.DATA_KBN = 'K' AND S.SYUEKI_YM IN ('");
                    sql.append(ym[0]);
                    sql.append("', '");
                    sql.append(ym[1]);
                    sql.append("')) AS U_SP_NOW");
                    sql.append(num);
                    sql.append(" ");
                    break;
                default :
                    sql.append(", (SELECT S.URIAGE_AMOUNT FROM SYU_KI_SP_TOTAL_TBL S WHERE S.ANKEN_ID = A.ANKEN_ID AND S.RIREKI_ID = A.RIREKI_ID AND S.DATA_KBN = '");
                    sql.append(kbn);
                    sql.append("' AND S.SYUEKI_YM = '");
                    sql.append(syuekiYm);
                    sql.append("') AS U_SP_NOW");
                    sql.append(num);
                    sql.append(" ");
                    break;
            }

            num++;
        }
        
        num = 0;
        // NET取得sql作成
        for(Map<String, Object> map: aggregateConditionBean.getYokozikuList()){
            String kbn = (String) map.get("dataKbn");
            String syuekiYm = (String) map.get("syuekiYm");
            
            switch(kbn) {
                case "J" :
                    sql.append(", (SELECT N.URIAGE_GENKA FROM SYU_KI_NET_TOTAL_TBL N WHERE N.ANKEN_ID = A.ANKEN_ID AND N.RIREKI_ID = A.RIREKI_ID AND N.DATA_KBN = (CASE WHEN N.SYUEKI_YM < A.NOW_KANJYO_YM THEN 'J' ELSE 'M' END) AND N.SYUEKI_YM = '");
                    sql.append(syuekiYm);
                    sql.append("') AS U_NET_NOW");
                    sql.append(num);
                    sql.append(" ");
                    break;
                case "Y" :
                    String[] ym = SyuuekiUtils.getKikanFromYm(syuekiYm);
                    sql.append(", (SELECT SUM(N.URIAGE_GENKA) FROM SYU_KI_NET_TOTAL_TBL N WHERE N.ANKEN_ID = A.ANKEN_ID AND N.RIREKI_ID = A.RIREKI_ID AND N.DATA_KBN = 'K' AND N.SYUEKI_YM IN ('");
                    sql.append(ym[0]);
                    sql.append("', '");
                    sql.append(ym[1]);
                    sql.append("')) AS U_NET_NOW");
                    sql.append(num);
                    sql.append(" ");
                    break;
                default :
                    sql.append(", (SELECT N.URIAGE_GENKA FROM SYU_KI_NET_TOTAL_TBL N WHERE N.ANKEN_ID = A.ANKEN_ID AND N.RIREKI_ID = A.RIREKI_ID AND N.DATA_KBN = '");
                    sql.append(kbn);
                    sql.append("' AND N.SYUEKI_YM = '");
                    sql.append(syuekiYm);
                    sql.append("') AS U_NET_NOW");
                    sql.append(num);
                    sql.append(" ");
                    break;
            }

            num++;
        }
        
        // 前回確定が選択されている場合
        if(StringUtils.isNotEmpty(rirekiId)){
            num = 0;
            
            // SP取得sql作成
            for(Map<String, Object> map: aggregateConditionBean.getYokozikuList()){
                String kbn = (String) map.get("dataKbn");
                String syuekiYm = (String) map.get("syuekiYm");

                switch(kbn){
                    case "J" :
                        sql.append(", (SELECT SUM(S.URIAGE_AMOUNT) FROM SYU_R_KI_SP_TOTAL_TBL S WHERE S.ANKEN_ID = A.ANKEN_ID AND S.RIREKI_ID IN ( ");
                        sql.append(rirekiId);
                        sql.append(") AND S.DATA_KBN = (CASE WHEN S.SYUEKI_YM < A.BEF_KANJYO_YM THEN 'J' ELSE 'M' END) AND S.SYUEKI_YM = '");
                        sql.append(syuekiYm);
                        sql.append("') AS U_SP_BEF");
                        sql.append(num);
                        sql.append(" ");
                        break;
                    case "Y" :
                        String[] ym = SyuuekiUtils.getKikanFromYm(syuekiYm);
                        sql.append(", (SELECT SUM(S.URIAGE_AMOUNT) FROM SYU_R_KI_SP_TOTAL_TBL S WHERE S.ANKEN_ID = A.ANKEN_ID AND S.RIREKI_ID IN ( ");
                        sql.append(rirekiId);
                        sql.append(") AND S.DATA_KBN = 'K' AND S.SYUEKI_YM IN ('");
                        sql.append(ym[0]);
                        sql.append("', '");
                        sql.append(ym[1]);
                        sql.append("')) AS U_SP_BEF");
                        sql.append(num);
                        sql.append(" ");
                        break;
                    default :
                        sql.append(", (SELECT SUM(S.URIAGE_AMOUNT) FROM SYU_R_KI_SP_TOTAL_TBL S WHERE S.ANKEN_ID = A.ANKEN_ID AND S.RIREKI_ID IN ( ");
                        sql.append(rirekiId);
                        sql.append(") AND S.DATA_KBN = '");
                        sql.append(kbn);
                        sql.append("' AND S.SYUEKI_YM = '");
                        sql.append(syuekiYm);
                        sql.append("') AS U_SP_BEF");
                        sql.append(num);
                        sql.append(" ");
                        break;
                }

                num++;
            }

            num = 0;
            // NET取得sql作成
            for(Map<String, Object> map: aggregateConditionBean.getYokozikuList()){
                String kbn = (String) map.get("dataKbn");
                String syuekiYm = (String) map.get("syuekiYm");

                switch(kbn) {
                    case "J" :
                        sql.append(", (SELECT SUM(N.URIAGE_GENKA) FROM SYU_R_KI_NET_TOTAL_TBL N WHERE N.ANKEN_ID = A.ANKEN_ID AND N.RIREKI_ID IN (");
                        sql.append(rirekiId);
                        sql.append(") AND N.DATA_KBN = (CASE WHEN N.SYUEKI_YM < A.BEF_KANJYO_YM THEN 'J' ELSE 'M' END) AND N.SYUEKI_YM = '");
                        sql.append(syuekiYm);
                        sql.append("') AS U_NET_BEF");
                        sql.append(num);
                        sql.append(" ");
                        break;
                    case "Y" :
                        String[] ym = SyuuekiUtils.getKikanFromYm(syuekiYm);
                        sql.append(", (SELECT SUM(N.URIAGE_GENKA) FROM SYU_R_KI_NET_TOTAL_TBL N WHERE N.ANKEN_ID = A.ANKEN_ID AND N.RIREKI_ID IN (");
                        sql.append(rirekiId);
                        sql.append(") AND N.DATA_KBN = 'K' AND N.SYUEKI_YM IN ('");
                        sql.append(ym[0]);
                        sql.append("', '");
                        sql.append(ym[1]);
                        sql.append("')) AS U_NET_BEF");
                        sql.append(num);
                        sql.append(" ");
                        break;
                    default :
                        sql.append(", (SELECT SUM(N.URIAGE_GENKA) FROM SYU_R_KI_NET_TOTAL_TBL N WHERE N.ANKEN_ID = A.ANKEN_ID AND N.RIREKI_ID IN (");
                        sql.append(rirekiId);
                        sql.append(") AND N.DATA_KBN = '");
                        sql.append(kbn);
                        sql.append("' AND N.SYUEKI_YM = '");
                        sql.append(syuekiYm);
                        sql.append("') AS U_NET_BEF");
                        sql.append(num);
                        sql.append(" ");
                        break;
                }

                num++;
            }
        }
        
        return sql;
    }
    
    /**
     * 回収行データ取得SQL作成処理
     * @return 
     */
    private StringBuilder getKaishuSql(String rirekiId){
        StringBuilder sql = new StringBuilder();
        int num = 0;
        
        // (電力ジ対応で変更)回収額は"回収円貨＋回収円貨税率"で出力
        String selectKaisyuAmount = "SUM(CASE WHEN (S.KAISYU_ENKA_AMOUNT IS NOT NULL or S.KAISYU_ENKA_ZEI IS NOT NULL) THEN (NVL(S.KAISYU_ENKA_AMOUNT, 0) + NVL(S.KAISYU_ENKA_ZEI, 0)) END)";
        
        // SP取得sql作成
        for(Map<String, Object> map: aggregateConditionBean.getYokozikuList()){
            String kbn = (String) map.get("dataKbn");
            String syuekiYm = (String) map.get("syuekiYm");
            
            switch(kbn) {
                case "J" :
                    //sql.append(", (SELECT SUM(S.KAISYU_ENKA_AMOUNT) FROM SYU_KI_KAISYU_TBL S WHERE S.ANKEN_ID = A.ANKEN_ID AND S.RIREKI_ID = A.RIREKI_ID AND S.DATA_KBN = (CASE WHEN S.SYUEKI_YM < A.NOW_KANJYO_YM THEN 'J' ELSE 'M' END) AND S.SYUEKI_YM = '");
                    sql.append(", (SELECT " + selectKaisyuAmount + " FROM SYU_KI_KAISYU_TBL S WHERE S.ANKEN_ID = A.ANKEN_ID AND S.RIREKI_ID = A.RIREKI_ID AND S.DATA_KBN = (CASE WHEN S.SYUEKI_YM < A.NOW_KANJYO_YM THEN 'J' ELSE 'M' END) AND S.SYUEKI_YM = '");
                    sql.append(syuekiYm);
                    sql.append("') AS K_SP_NOW");
                    sql.append(num);
                    sql.append(" ");
                    break;
                case "Y" :
                    String[] ym = SyuuekiUtils.getKikanFromYm(syuekiYm);
                    sql.append(", (SELECT " + selectKaisyuAmount + " FROM SYU_KI_KAISYU_TBL S WHERE S.ANKEN_ID = A.ANKEN_ID AND S.RIREKI_ID = A.RIREKI_ID AND S.DATA_KBN = 'K' AND S.SYUEKI_YM IN ('");
                    sql.append(ym[0]);
                    sql.append("', '");
                    sql.append(ym[1]);
                    sql.append("')) AS K_SP_NOW");
                    sql.append(num);
                    sql.append(" ");
                    break;
                default :
                    sql.append(", (SELECT " + selectKaisyuAmount + " FROM SYU_KI_KAISYU_TBL S WHERE S.ANKEN_ID = A.ANKEN_ID AND S.RIREKI_ID = A.RIREKI_ID AND S.DATA_KBN = '");
                    sql.append(kbn);
                    sql.append("' AND S.SYUEKI_YM = '");
                    sql.append(syuekiYm);
                    sql.append("') AS K_SP_NOW");
                    sql.append(num);
                    sql.append(" ");
                    break;
            }

            num++;
        }
        
        if(StringUtils.isNotEmpty(rirekiId)){
            num = 0;

            // SP取得sql作成
            for(Map<String, Object> map: aggregateConditionBean.getYokozikuList()){
                String kbn = (String) map.get("dataKbn");
                String syuekiYm = (String) map.get("syuekiYm");

                switch(kbn) {
                    case "J" :
                        sql.append(", (SELECT " + selectKaisyuAmount + " FROM SYU_R_KI_KAISYU_TBL S WHERE S.ANKEN_ID = A.ANKEN_ID AND S.RIREKI_ID IN (");
                        sql.append(rirekiId);
                        sql.append(") AND S.DATA_KBN = (CASE WHEN S.SYUEKI_YM < A.BEF_KANJYO_YM THEN 'J' ELSE 'M' END) AND S.SYUEKI_YM = '");
                        sql.append(syuekiYm);
                        sql.append("') AS K_SP_BEF");
                        sql.append(num);
                        sql.append(" ");
                        break;
                    case "Y" :
                        String[] ym = SyuuekiUtils.getKikanFromYm(syuekiYm);
                        sql.append(", (SELECT " + selectKaisyuAmount + " FROM SYU_R_KI_KAISYU_TBL S WHERE S.ANKEN_ID = A.ANKEN_ID AND S.RIREKI_ID IN (");
                        sql.append(rirekiId);
                        sql.append(") AND S.DATA_KBN = 'K' AND S.SYUEKI_YM IN ('");
                        sql.append(ym[0]);
                        sql.append("', '");
                        sql.append(ym[1]);
                        sql.append("')) AS K_SP_BEF");
                        sql.append(num);
                        sql.append(" ");
                        break;
                    default :
                        sql.append(", (SELECT " + selectKaisyuAmount + " FROM SYU_R_KI_KAISYU_TBL S WHERE S.ANKEN_ID = A.ANKEN_ID AND S.RIREKI_ID IN (");
                        sql.append(rirekiId);
                        sql.append(") AND S.DATA_KBN = '");
                        sql.append(kbn);
                        sql.append("' AND S.SYUEKI_YM = '");
                        sql.append(syuekiYm);
                        sql.append("') AS K_SP_BEF");
                        sql.append(num);
                        sql.append(" ");
                        break;
                }

                num++;
            }
        }
        
        return sql;
    }
    
    /**
     * 検索条件用予算確定月取得
     */
    public void taishoExecute() throws SQLException{
        // 予算ベース 勘定月を取得
        getYosanList();
    }
    
    /**
     * 予算ベースデータの勘定月一覧を取得
     * @throws java.sql.SQLException
     */
    public void getYosanList() throws SQLException {
        String sqlFilePath = "/sql/syuWfControlTbl/selectYosanKanjyoYm.sql";

        Map<String, Object> condition = new HashMap<>();
        condition.put("divisionCode", aggregateConditionBean.getDivisionCode());
        condition.put("dataKbn", "Y");
        if (aggregateConditionBean.getSalesClass() != null) {
            condition.put("salesClass", Arrays.asList(aggregateConditionBean.getSalesClass()));
        }

        // SQLを取得
        SqlFile sqlFile = new SqlFile();
        String sql = sqlFile.getSqlString(sqlFilePath, condition);
        Object[] params = sqlFile.getSqlParams(sqlFilePath, condition);

        // SQL実行
        List<Map<String, Object>> list = dbUtilsExecutor.dbUtilsGetSqlList(em, sql, params);
        
        s022Bean.setYosanList(list);
    }
    
    /**
     * 検索条件[対象データ]での案件絞り込みのための条件を作成する
     */
    private void  createConditionParameterKikan(List<Map<String, Object>> kikanList ) {
        boolean isFirstCreateMonth = true;
        boolean isFirstCreateQuarter = true;
        boolean isFirstCreatePeriod = true;
        boolean isFirstCreateYear = true;
        
//        boolean isGokeiFlg = false;
//        boolean isFmFlg = false;
        
        int searchKbn = 0;
        
        // 指定した条件で作成した期間の横軸情報を回しながら作成
        for (Map<String, Object> yokozikuInfo: kikanList) {
            String syuekiYm = yokozikuInfo.get("syuekiYm").toString();
            String dataKbn = yokozikuInfo.get("dataKbn").toString();
            
            // 年月の条件を作成
            if (searchKbn <= 4) {
                if ("J".equals(dataKbn)) {
                    if (isFirstCreateMonth) {
                        // 年月fromを作成
                        aggregateConditionBean.setConditionSyuekiYmFrom(syuekiYm);
                        isFirstCreateMonth = false;
                    }
                    aggregateConditionBean.setConditionSyuekiYmTo(syuekiYm);
                    aggregateConditionBean.setConditionSyuekiYmFlg("1");
                    searchKbn = 4;
                }
            }
 
            // 4半期の条件を作成
             if (searchKbn <= 3) {      //  年月の条件を既に参照している場合、この条件を聞かないようにする
                if ("Q".equals(dataKbn)) {
                    String[] ym = SyuuekiUtils.getQuarterMonthAry(syuekiYm);
                    if (isFirstCreateQuarter) {
                        // 期fromを作成
                        //aggregateConditionBean.setConditionQuarterFrom(syuekiYm);
                        aggregateConditionBean.setConditionSyuekiYmFrom(ym[0]);
                        isFirstCreateQuarter = false;
                    }
                    //aggregateConditionBean.setConditionQuarterTo(syuekiYm);
                    //aggregateConditionBean.setConditionQuarterFlg("1");
                    aggregateConditionBean.setConditionSyuekiYmTo(ym[ym.length-1]);
                    aggregateConditionBean.setConditionSyuekiYmFlg("1");
                    searchKbn = 3;
                }
             }
            
            // 期の条件を作成
            if (searchKbn <=2) {  // 4半期以下の条件を既に参照している場合、この条件を聞かないようにする
                if ("K".equals(dataKbn)) {
                    String[] ym = SyuuekiUtils.getKikanMonthAry(syuekiYm);
                    if (isFirstCreatePeriod) {
                        // 年期fromを作成
                        //aggregateConditionBean.setConditionPeriodFrom(syuekiYm);
                        aggregateConditionBean.setConditionSyuekiYmFrom(ym[0]);
                        isFirstCreatePeriod = false;
                    }
                    //aggregateConditionBean.setConditionPeriodTo(syuekiYm);
                    //aggregateConditionBean.setConditionPeriodFlg("1");
                    aggregateConditionBean.setConditionSyuekiYmTo(ym[ym.length-1]);
                    aggregateConditionBean.setConditionSyuekiYmFlg("1");
                    searchKbn = 2;
                }
            }

            // 年度の条件を作成
            if (searchKbn <= 1) {  // 期以下の条件を既に参照している場合、この条件を聞かないようにする
                if ("Y".equals(dataKbn)) {
                    String[] kikanAry = SyuuekiUtils.getKikanFromYm(syuekiYm);
                    String[] ymFrom = SyuuekiUtils.getKikanMonthAry(kikanAry[0]);
                    String[] ymTo = SyuuekiUtils.getKikanMonthAry(kikanAry[kikanAry.length-1]);
                    if (isFirstCreateYear) {
                        // 年fromを作成
                        //aggregateConditionBean.setConditionPeriodFrom(ym[0]);
                        aggregateConditionBean.setConditionSyuekiYmFrom(ymFrom[0]);
                        isFirstCreateYear = false;
                    }
                    //aggregateConditionBean.setConditionPeriodTo(ym[1]);
                    //aggregateConditionBean.setConditionPeriodFlg("1");
                    aggregateConditionBean.setConditionSyuekiYmTo(ymTo[ymTo.length-1]);
                    aggregateConditionBean.setConditionSyuekiYmFlg("1");
                    searchKbn = 1;
                }
            }

//            // 総合計の条件を作成
//            if ("G".equals(dataKbn)) {
//                isGokeiFlg = true;
//            }
//            
//            // 最終見込の条件を作成
//            if ("F".equals(dataKbn)) {
//                isFmFlg = false;
//            }
        }

        if (StringUtils.isNotEmpty(aggregateConditionBean.getConditionSyuekiYmFrom()) && StringUtils.isNotEmpty(aggregateConditionBean.getConditionSyuekiYmTo())) {
            // 年月の範囲でデータを絞り込み
            aggregateConditionBean.setConditionPeriodFlg("1");
        } 
//        else {
//            if (isGokeiFlg) {
//                aggregateConditionBean.setConditionGokeiFlg("1");
//            }
//            if (isFmFlg) {
//                aggregateConditionBean.setConditionFmFlg("1");
//            }
//        }

        logger.info("createConditionParameterKikan kikan from=[{}], to=[{}]", aggregateConditionBean.getConditionSyuekiYmFrom(), aggregateConditionBean.getConditionSyuekiYmTo());
    }

}
