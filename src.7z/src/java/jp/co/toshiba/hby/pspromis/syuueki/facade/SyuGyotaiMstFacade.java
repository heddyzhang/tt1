/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package jp.co.toshiba.hby.pspromis.syuueki.facade;

import java.util.List;
import javax.ejb.Stateless;
import javax.interceptor.Interceptors;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import jp.co.toshiba.hby.pspromis.syuueki.entity.SyuGyotaiMst;
import jp.co.toshiba.hby.pspromis.syuueki.interceptor.TranceInterceptor;

/**
 *
 * @author ibayashi
 */
@Stateless
@Interceptors({TranceInterceptor.class})
public class SyuGyotaiMstFacade extends AbstractFacade<SyuGyotaiMst> {
    @PersistenceContext(unitName = jp.co.toshiba.hby.pspromis.syuueki.util.ConstantString.syuuekiDataSourceName)
    private EntityManager em;

    @Override
    protected EntityManager getEntityManager() {
        return em;
    }

    public SyuGyotaiMstFacade() {
        super(SyuGyotaiMst.class);
    }

    /**
     * 業態マスタの一覧を取得
     * @param condition
     * @return 
     */
    public List<SyuGyotaiMst> getGyotaiList(Object condition) {
        List<SyuGyotaiMst> list
                = sqlExecutor.getResultList(em, SyuGyotaiMst.class, "/sql/syuGyotaiMst/selectSyuGyotaiMst.sql", condition);

        return list;
    }

    /**
     * 業態名を取得
     * @param gyotaiCd
     * @return 
     */
    public String getName(String gyotaiCd) {
        SyuGyotaiMst entity = find(gyotaiCd);
        if (entity != null) {
            return entity.getGyotaiNm();
        } else {
            return null;
        }
    }
}
