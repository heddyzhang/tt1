package jp.co.toshiba.hby.pspromis.syuueki.servlet;

import java.util.HashMap;
import java.util.Map;
import javax.inject.Inject;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpServletRequest;
import jp.co.toshiba.hby.pspromis.syuueki.bean.ResultMessageBean;
import jp.co.toshiba.hby.pspromis.syuueki.bean.S012Bean;
import jp.co.toshiba.hby.pspromis.syuueki.service.S012Service;
import jp.co.toshiba.hby.pspromis.syuueki.service.StoredProceduresService;
import jp.co.toshiba.hby.pspromis.syuueki.util.CdiUtils;
import jp.co.toshiba.hby.pspromis.syuueki.util.ParameterBinder;

/**
 * PS-Promis収益管理システム
 * 見込SP（通貨）編集 子画面 Servlet
 * @author horie
 */
@WebServlet(name = "S012", urlPatterns = {"/servlet/S012", "/servlet/S012/*"})
public class S012Servlet extends AbstractServlet {

    /**
     * jsp
     */
    private static final String INDEX_JSP = "S012/s012.jsp";

    /**
     * 使用serviceクラスをinjection(CDI)<br>
     * InjectアノテーションよりAPサーバー(Glassfish)側で自動的にインスタンス作成(new)される。<br>
     * service側はステートレスセッションbeanにするため、Statelessアノテーションをつけておくこと。<br>
     */
    @Inject
    private S012Service s012Service;

    @Inject
    private StoredProceduresService storedProceduresService;
    
    /**
     * パラメータ格納クラスをinjection(CDI)<br>
     * InjectアノテーションよりAPサーバー(Glassfish)側で自動的にインスタンス作成(new)される。<br>
     */
    @Inject
    private S012Bean s012Bean;
    
    /**
     * 初期表示(調整口の取得)
     * @param req
     * @param resp
     * @return
     * @throws Exception 
     */
    public String indexAction(HttpServletRequest req, HttpServletResponse resp)
    throws Exception {
        logger.info("S012Servlet#indexAction");
        
        // リクエストパラメータをs012Beanの同名フィールドに一括コピー
        ParameterBinder.Bind(s012Bean, req);

        s012Service.indexExecute();

        return INDEX_JSP;
    }

    /**
     * 調整口データの保存/削除
     * @param req
     * @param resp
     * @return
     * @throws Exception 
     */
    public String execAction(HttpServletRequest req, HttpServletResponse resp)
    throws Exception {
        logger.info("S012Servlet#execAction");

        // リクエストパラメータをs012Beanの同名フィールドに一括コピー
        ParameterBinder.Bind(s012Bean, req);
        
        s012Service.updateExecute();

        // (原子力)連携バッチを実行
        //storedProceduresService.callN7RenkeiBatchJudge(s012Bean.getAnkenId(), s012Bean.getRirekiId());
        
        // 処理結果を戻す。
        Map<String, Object> jsonMap = new HashMap<>();
        ResultMessageBean resultMessageBean = CdiUtils.getBean(ResultMessageBean.class);
        resultMessageBean.createResultMessage(jsonMap);
        resopnseDecodeJson(resp, jsonMap);
        
        return null;
    }

}