package jp.co.toshiba.hby.pspromis.syuueki.facade;

import java.util.HashMap;
import java.util.Map;
import javax.ejb.Stateless;
import javax.interceptor.Interceptors;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import jp.co.toshiba.hby.pspromis.syuueki.entity.S003TargetYm;
import jp.co.toshiba.hby.pspromis.syuueki.interceptor.TranceInterceptor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 *
 * @author sano
 */
@Stateless
@Interceptors({TranceInterceptor.class})
public class M001Facade extends AbstractFacade<S003TargetYm> {

    /**
     * ロガ－
     */
    private static final Logger logger = LoggerFactory.getLogger(M001Facade.class);

    @PersistenceContext(unitName = jp.co.toshiba.hby.pspromis.syuueki.util.ConstantString.syuuekiDataSourceName)
    private EntityManager em;

    public M001Facade() {
        super(S003TargetYm.class);
    }

    @Override
    protected EntityManager getEntityManager() {
        return em;
    }

    /**
     * 注入パターンマスタの更新
     * 
     * @param condition 
     */
    public int updatePatternMst(Object condition){
        logger.info("M001Facade#updatePatternMst");

        return sqlExecutor.executeUpdateSql(em, "/sql/M001/updateSyuPatternMst.sql", condition);
    }
    
    /**
     * 注入パターンマスタ内訳の更新
     * 
     * @param condition 
     */
    public int updatePatternItemMst(Object condition){
        logger.info("M001Facade#updatePatternItemMst");

        return sqlExecutor.executeUpdateSql(em, "/sql/M001/updateSyuPatternItemMst.sql", condition);
    }
    
    /**
     * 注入パターンマスタの登録
     * 
     * @param condition 
     */
    public int insertPatternMst(Object condition){
        logger.info("M001Facade#insertPatternMst");

        return sqlExecutor.executeUpdateSql(em, "/sql/M001/insertSyuPatternMst.sql", condition);
    }
    
    /**
     * 注入パターンマスタ内訳の登録
     * 
     * @param condition 
     */
    public int insertPatternItemMst(Object condition){
        logger.info("M001Facade#insertPatternItemMst");

        return sqlExecutor.executeUpdateSql(em, "/sql/M001/insertSyuPatternItemMst.sql", condition);
    }
    
    /**
     * 複写している注入パターンの名称を更新
     * @param data
     * @return  
     */
    public int updateCopyPatternMst(Map<String, Object> data) {
        logger.info("M001Facade#insertPatternItemMst");

        return sqlExecutor.executeUpdateSql(em, "/sql/M001/updateCopyPattern.sql", data);
    }
    
    /**
     * 注入パターンマスタの削除
     * 
     * @param condition 
     */
    public int deletePatternMst(Object condition){
        logger.info("M001Facade#deletePatternMst");

        return sqlExecutor.executeUpdateSql(em, "/sql/M001/deleteSyuPatternMst.sql", condition);
    }
    
    /**
     * 注入パターンマスタ内訳の削除
     * 
     * @param condition 
     */
    public int deletePatternItemMst(Object condition){
        logger.info("M001Facade#deletePatternItemMst");

        return sqlExecutor.executeUpdateSql(em, "/sql/M001/deleteSyuPatternItemMst.sql", condition);
    }

    /**
     * 指定注入パターンの使用済み物件件数を取得
     */
    public int findUserdPatternCount(String ptnNo) {
        logger.info("M001Facade#checkPattern");
        
        Map<String, Object> condition = new HashMap<>();
        condition.put("chunyuPtnNo", ptnNo);
        
        Integer count = sqlExecutor.getCount(em, "/sql/M001/checkUsePattern.sql", condition);
        
        return count;
    }
    
}
