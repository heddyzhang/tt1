package jp.co.toshiba.hby.pspromis.syuueki.bean;

import javax.enterprise.context.RequestScoped;
import javax.inject.Named;
import java.util.List;
import lombok.Getter;
import lombok.Setter;
/**
 *
 * @autho
 */
@Named(value = "downloadOptBean")
@RequestScoped
@Getter @Setter
public class DownloadOptBean {
    
    /**
     * 工事進行基準リスト 年リスト
     */
    private List<String> optionShinkoYearList;
    
    /**
     * 工事進行基準リスト 外貨出力
     */
    private String optionShinkoOutputAnkenKbn;
    
    /**
     * 工事進行基準リスト 外貨出力
     */
    private String optionShinkoOutputForginKbn;
    
    /**
     * 工事進行基準リスト 出力実績年
     */
    private String optionShinkoOutputYearNow;
    
    /**
     * 工事進行基準リスト 出力実績月
     */
    private String optionShikoOutputMonthNow;
    
    /**
     * 工事進行基準リスト 比較対象年
     */
    private String optionShinkoOutputYearBefore;
    
    /**
     * 工事進行基準リスト 比較対象月
     */
    private String optionShinkoOutputMonthBefore;

    
    /**
     * 一括案件リスト 出力帳票種類
     */
    private String[] optionIkkatsuOutPutSheetKbn;
    
    /**
     * ダウンロードファイル名
     */
    private String downloadFileName;

}
