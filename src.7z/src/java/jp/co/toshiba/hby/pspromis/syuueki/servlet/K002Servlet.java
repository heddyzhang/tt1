package jp.co.toshiba.hby.pspromis.syuueki.servlet;

import javax.inject.Inject;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import jp.co.toshiba.hby.pspromis.syuueki.bean.K002Bean;
import jp.co.toshiba.hby.pspromis.syuueki.service.K002Service;
import jp.co.toshiba.hby.pspromis.syuueki.util.ParameterBinder;

/**
 * PS-Promis収益管理システム
 * 設置場所選択 Servlet
 * @author (NPC)S.horie
 */
@WebServlet(name="K002", urlPatterns={"/servlet/K002", "/servlet/K002/*"})
public class K002Servlet extends AbstractServlet {

    /**
     * jsp
     */
    private static final String INDEX_JSP = "K002/k002.jsp";

    /**
     * 使用serviceクラスをinjection(CDI)<br>
     * InjectアノテーションよりAPサーバー(Glassfish)側で自動的にインスタンス作成(new)される。<br>
     * service側はステートレスセッションbeanにするため、Statelessアノテーションをつけておくこと。<br>
     */
    @Inject
    private K002Service k002Service;

    /**
     * パラメータ格納クラスをinjection(CDI)<br>
     * InjectアノテーションよりAPサーバー(Glassfish)側で自動的にインスタンス作成(new)される。<br>
     */
    @Inject
    private K002Bean k002Bean;

    /**
     * 初期表示
     * @param req
     * @param resp
     * @return
     * @throws Exception 
     */
    public String indexAction(HttpServletRequest req, HttpServletResponse resp)
    throws Exception {
        logger.info("K002Servlet#indexAction");
        
        k002Service.indexExecute();
        
        return INDEX_JSP;
    }

    /**
     * 一覧データ取得
     * @param req
     * @param resp
     * @return
     * @throws Exception 
     */
    public String searchAction(HttpServletRequest req, HttpServletResponse resp)
    throws Exception {
        logger.info("K002Servlet#searchAction");

        // リクエストパラメータをk002Beanの同名フィールドに一括コピー
        ParameterBinder.Bind(k002Bean, req);

        // 必要あらばリクエストパラメータのバリデーションチェックを入れる予定
        // (Beans Validation(＋独自バリデーション))

        // サービスの実行(トランザクションの単位にもなる)
        // ※バリデーションチェックに通った場合のみサービス実行。
        k002Service.searchExecute();

        // jspをforward
        return INDEX_JSP;
    }
}
