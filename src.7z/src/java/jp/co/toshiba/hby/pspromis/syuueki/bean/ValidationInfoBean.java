package jp.co.toshiba.hby.pspromis.syuueki.bean;

import java.util.Map;
import javax.enterprise.context.RequestScoped;
import javax.inject.Named;

/**
 *
 * @author ibayashi
 */
@Named(value = "validationInfoBean")
@RequestScoped
public class ValidationInfoBean {

    /**
     * バリデーション成否
     */
    private boolean success = true;

    /**
     * バリデーションエラーメッセージリスト
     * key:エラー項目のエレメント名 value:メッセージ
     */
    private Map<String, String> messages;
    
    public boolean isSuccess() {
        return success;
    }

    public void setSuccess(boolean success) {
        this.success = success;
    }

    public Map<String, String> getMessages() {
        return messages;
    }

    public void setMessages(Map<String, String> messages) {
        if (messages != null && messages.size() > 0) {
            this.success = false;
        }
        this.messages = messages;
    }

}
