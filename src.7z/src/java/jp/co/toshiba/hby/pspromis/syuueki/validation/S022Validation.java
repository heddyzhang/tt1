package jp.co.toshiba.hby.pspromis.syuueki.validation;

import java.math.BigDecimal;
import java.util.Arrays;
import java.util.Map;
import jp.co.toshiba.hby.pspromis.common.util.StringUtil;
import jp.co.toshiba.hby.pspromis.syuueki.bean.AggregateConditionBean;
import jp.co.toshiba.hby.pspromis.syuueki.bean.S022Bean;
import jp.co.toshiba.hby.pspromis.syuueki.bean.ValidationInfoBean;
import jp.co.toshiba.hby.pspromis.syuueki.enums.Env;
import jp.co.toshiba.hby.pspromis.syuueki.enums.Label;
import jp.co.toshiba.hby.pspromis.syuueki.enums.ValidatorMessage;
import jp.co.toshiba.hby.pspromis.syuueki.util.SyuuekiUtils;
import jp.co.toshiba.hby.pspromis.syuueki.util.Utils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 *
 * @author rnomura
 */
public class S022Validation extends AbstractValidation<AggregateConditionBean> {
    public static final Logger logger = LoggerFactory.getLogger(S001Validation.class);
    
    /**
     * コンストラクタ
     */
    public S022Validation(AggregateConditionBean bean) {
        super(bean);
    }

    /**
     * 検索処理時のバリデーション
     * @param vBean
     */
    public void execListValidation(ValidationInfoBean vBean) {
        annotationValidate();
        
        Map<String, String> messages = getValidateMessagess();
        AggregateConditionBean bean = getBean();
        String message;

        // 1次集計単位、2次集計単位の重複チェック
        if(bean.getPrimaryUnit().equals(bean.getSecondaryUnit())){
            message = ValidatorMessage.SAME_AGGREGATE.getMessae();
            messages.put("secondaryCountingUnit", message);
        } 
        // 火水ジの場合、主管課が選択されていないかチェック
        // →(電力ジ対応)原子力以外の場合、主管課が選択されていないことをチェック
        else if(!bean.isNuclearDivision()){
            // 1次集計のチェック
            if(bean.getPrimaryUnit().equals("2")){
                message = ValidatorMessage.NO_SELECT_KASUIZI.getMessae();
                messages.put("primaryCountingUnit", message);
            }
            // 2次集計のチェック
            if(bean.getSecondaryUnit().equals("2")){
                message = ValidatorMessage.NO_SELECT_KASUIZI.getMessae();
                messages.put("secondaryCountingUnit", message);
            }
        }
        
        // 横軸集計の選択チェック
        if(bean.getYokozikuAgg() == null){
            message = ValidatorMessage.REQUIRED_SELECTED.getMessae().replace("{0}", Label.yokozikuAggregate.getLabel());
            messages.put("yokozikuAggregate", message);
        }
        
        // 出力項目の選択チェック
        if(bean.getOutputItem() == null){
            message = ValidatorMessage.REQUIRED_SELECTED.getMessae().replace("{0}", Label.outputItem.getLabel());
            messages.put("outputItem", message);
        }
        
        // 比較データ　確定月の必須チェック
        if(bean.getComparison().equals("G")){
            if(StringUtil.isEmpty(bean.getComparisonData())){
                message = ValidatorMessage.REQUIRED.getMessae().replace("{0}", Label.fixedYm.getLabel());
                messages.put("comparisonDataG", message);
            } else {
                boolean isYm = isValidYm(bean.getComparisonData());
                if(!isYm){
                    message = StringUtils.replace(getValidationMessage("ymError"), "{0}", Label.fixedYm.getLabel());
                    messages.put("comparisonDataG", message);
                }
            
            }
        } else if(bean.getComparison().equals("Y")){
            if(StringUtil.isEmpty(bean.getSelComparisonData())){
                message = ValidatorMessage.REQUIRED_SELECT.getMessae().replace("{0}", Label.taisho.getLabel());
                messages.put("comparisonDataY", message);
            }
        }
        
        // 対象データの入力データチェック
        if(bean.getYokozikuAgg() != null){
            // 横軸集計で「月」が選択されている場合
            if(Arrays.asList(bean.getYokozikuAgg()).contains("0")){
                boolean isYmFrom = true;
                boolean isYmTo = true;
                if(StringUtil.isNotEmpty(bean.getTargetFrom())){
                    // 有効な年月かチェック
                    isYmFrom = isValidYm(bean.getTargetFrom());
                    if(!isYmFrom){
                        message = StringUtils.replace(getValidationMessage("ymError"), "{0}", Label.taishoData.getLabel());
                        messages.put("taishoDataM", message);
                    }
                }
                if(StringUtil.isNotEmpty(bean.getTargetTo())){
                    // 有効な年月かチェック
                    isYmTo = isValidYm(bean.getTargetTo());
                    if(!isYmTo){
                        message = StringUtils.replace(getValidationMessage("ymError"), "{0}", Label.taishoData.getLabel());
                        messages.put("taishoDataM", message);
                    }
                }
                
                int max = Integer.valueOf(Env.Aggregate_Max_Range_Month.getValue());
                String from = bean.getTargetFrom();
                String to = bean.getTargetTo();
                
                // 必須チェック
                if(isYmFrom && isYmTo && StringUtil.isEmpty(from) && StringUtil.isEmpty(to)){
                    message = ValidatorMessage.REQUIRED.getMessae().replace("{0}", Label.taishoData.getLabel());
                    messages.put("taishoDataM", message);
                }
                if(isYmFrom && isYmTo && StringUtil.isNotEmpty(from) && StringUtil.isNotEmpty(to)){
                    // 期間の逆転チェック
                    if(from.compareTo(to) > 0){
                        message = ValidatorMessage.KIKAN_FALSE.getMessae();
                        messages.put("taishoDataM", message);
                    }
                    // 期間が最大指定範囲内かチェック
                    else if(SyuuekiUtils.addMonth(from.replace("/", ""), max-1).compareTo(to.replace("/", "")) < 0){
                        message = ValidatorMessage.KIKAN_OVER.getMessae().replace("{0}", String.valueOf(max) + Label.kagetu.getLabel());
                        messages.put("taishoDataM", message);
                    }
                }
            } 
            // 横軸集計で「4Q」「期」が選択されている場合
            else if(Arrays.asList(bean.getYokozikuAgg()).contains("1") || Arrays.asList(bean.getYokozikuAgg()).contains("2")){
                boolean isYmFrom = true;
                boolean isYmTo = true;
                if(StringUtil.isNotEmpty(bean.getTargetFromKiYm())){
                    // 有効な年かチェック
                    isYmFrom = isValidYear(bean.getTargetFromKiYm());
                    if(!isYmFrom){
                        message = StringUtils.replace(getValidationMessage("integerError"), "{0}", Label.taishoData.getLabel());
                        messages.put("taishoDataP", message);
                    }
                }
                if(StringUtil.isNotEmpty(bean.getTargetToKiYm())){
                    // 有効な年かチェック
                    isYmTo = isValidYear(bean.getTargetToKiYm());
                    if(!isYmTo){
                        message = StringUtils.replace(getValidationMessage("integerError"), "{0}", Label.taishoData.getLabel());
                        messages.put("taishoDataP", message);
                    }
                }
                
                int max = Integer.valueOf(Env.Aggregate_Max_Range_Period.getValue());
                String from = SyuuekiUtils.labelKikan(bean.getTargetFromKiYm() + bean.getTargetFromKi());
                String to = SyuuekiUtils.labelKikan(bean.getTargetToKiYm() + bean.getTargetToKi());
                
                // 必須チェック
                if(isYmFrom && isYmTo && StringUtil.isEmpty(bean.getTargetFromKiYm()) && StringUtil.isEmpty(bean.getTargetToKiYm())){
                    message = ValidatorMessage.REQUIRED.getMessae().replace("{0}", Label.taishoData.getLabel());
                    messages.put("taishoDataP", message);
                }
                if(isYmFrom && isYmTo && StringUtil.isNotEmpty(bean.getTargetFromKiYm()) && StringUtil.isNotEmpty(bean.getTargetToKiYm())){
                    // 期間の逆転チェック
                    if(from.compareTo(to) > 0){
                        message = ValidatorMessage.KIKAN_FALSE.getMessae();
                        messages.put("taishoDataP", message);
                    }
                    // 期間が最大範囲内かチェック
                    else if(SyuuekiUtils.calcKikan(from, max-1).compareTo(to) < 0){
                        message = ValidatorMessage.KIKAN_OVER.getMessae().replace("{0}", String.valueOf(max) + Label.kibun.getLabel());
                        messages.put("taishoDataP", message);
                    }
                    
                }
            }
            // 横軸集計で「年度」が選択されている場合
            else if(Arrays.asList(bean.getYokozikuAgg()).contains("3")){
                boolean isYmFrom = true;
                boolean isYmTo = true;
                if(StringUtil.isNotEmpty(bean.getTargetFromNendo())){
                    // 有効な年かチェック
                    isYmFrom = isValidYear(bean.getTargetFromNendo());
                    if(!isYmFrom){
                        message = StringUtils.replace(getValidationMessage("integerError"), "{0}", Label.taishoData.getLabel());
                        messages.put("taishoDataY", message);
                    }
                }
                if(StringUtil.isNotEmpty(bean.getTargetToNendo())){
                    // 有効な年かチェック
                    isYmTo = isValidYear(bean.getTargetToNendo());
                    if(!isYmTo){
                        message = StringUtils.replace(getValidationMessage("integerError"), "{0}", Label.taishoData.getLabel());
                        messages.put("taishoDataY", message);
                    }
                }
                
                int max = Integer.valueOf(Env.Aggregate_Max_Range_Year.getValue());
                String from = bean.getTargetFromNendo();
                String to = bean.getTargetToNendo();
                
                // 必須チェック
                if(isYmFrom && isYmTo && StringUtil.isEmpty(from) && StringUtil.isEmpty(to)){
                    message = ValidatorMessage.REQUIRED.getMessae().replace("{0}", Label.taishoData.getLabel());
                    messages.put("taishoDataY", message);
                }
                if(isYmFrom && isYmTo && StringUtil.isNotEmpty(from) && StringUtil.isNotEmpty(to)){
                    //期間の逆転チェック
                    if(from.compareTo(to) > 0){
                        message = ValidatorMessage.KIKAN_FALSE.getMessae();
                        messages.put("taishoDataY", message);
                    }
                    //期間が最大範囲内かチェック
                    else if(SyuuekiUtils.addYear(from + "01", max-1).compareTo(to + "01") < 0){
                        message = ValidatorMessage.KIKAN_OVER.getMessae().replace("{0}", String.valueOf(max) + Label.nendobun.getLabel());
                        messages.put("taishoDataY", message);
                    }
                }
            }
        }

        vBean.setMessages(messages);
    }
    
    /**
     * 数値チェック
     *
     * @param value
     * @return true:数値 false:数値でない
     */
    public boolean isValidYear(String value) {
        boolean isValid = true;

        if (StringUtil.isNotEmpty(value)) {
            isValid = Utils.isNumeric(value);
            if (isValid) {
                // 4桁かチェック
                if (value.length() != 4) {
                    isValid = false;
                } 
            }
        }
        return isValid;
    }
}
