/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package jp.co.toshiba.hby.pspromis.syuueki.util;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import javax.servlet.http.HttpServletResponse;
import org.apache.poi.ss.usermodel.Workbook;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * ファイル操作用ユーティリティ
 * @author ibayashi
 */
public class FileUtils{
    
    /**
     * ロガー
     */
    public static final Logger logger = LoggerFactory.getLogger(FileUtils.class);
    
    /**
     * ファイルをレスポンスに返す(元ファイルは残す)
     * @param fname	ファイルパス
     * @param dlfname	ダウンロードファイル名
     * @param response	HttpServletResponse
     * @throws java.io.IOException
     */
    public static void httpDownloadResponse(String fname, String dlfname, HttpServletResponse response)
    throws IOException {
        httpDownloadResponse(fname, dlfname, response, false);
    }

    /**
     * ファイルをレスポンスに返す
     * @param fname	ファイルパス
     * @param dlfname	ダウンロードファイル名
     * @param response	HttpServletResponse
     * @param deleteFlg	 ファイル削除フラグ
     * @throws java.io.IOException
     */
    public static void httpDownloadResponse(String fname, String dlfname, HttpServletResponse response, boolean deleteFlg)
    throws IOException {
        //ServletOutputStream out = null;
        //OutputStream out = null;
        InputStream in = null;
        File f = null;

        try{
            f = new File( fname );

            String contentFileName = new String(dlfname.getBytes("Windows-31J"), "ISO8859_1");
            response.setContentType("application/octet-stream");
            response.setHeader("Content-Disposition", "attachment; filename=" + contentFileName);

            OutputStream out = response.getOutputStream();
            in = new FileInputStream(f);
            byte [] buffer = new byte[4096];
            int readbyte;
            while ((readbyte = in.read(buffer)) != -1) {
                out.write(buffer, 0, readbyte);
            }
        
        } finally {
            // ファイル削除
            if (deleteFlg && f != null) f.delete();

            try{
                if (in != null) in.close();
            } catch (IOException e){}

/*
            try{
                if (out != null) out.close();
            } catch( Exception eee ){}
*/
            // HttpServletResponseをクリア
	}
    }
    
    /**
     * Excelファイルのダウンロード
     * @param workbook Excelワークブック
     * @param dlfname	ダウンロードファイル名
     * @param response	HttpServletResponse
     * @throws java.io.IOException
     */
    public static void httpDownloadExcelResponse(Workbook workbook, String dlfname, HttpServletResponse response)
    throws IOException {
        String contentFileName = new String(dlfname.getBytes("Windows-31J"), "ISO8859_1");
        response.setContentType("application/octet-stream");
        response.setHeader("Content-Disposition", "attachment; filename=" + contentFileName);
        
        workbook.write(response.getOutputStream());
    }
    
    /**
     * ファイルorフォルダを削除
     * @param f
     * @throws java.io.IOException
     */
    public static void deleteAll(File f) throws IOException {
       	if (f.exists()==false){
            return ;
    	}

        if(f.isFile()){
            f.delete();
        }

    	if(f.isDirectory()){
            File[] files=f.listFiles();
            for (int i=0; i<files.length; i++) {
                deleteAll( files[i] );
            }
            f.delete();
            
    	}
    }
    
    /**
     * 指定ディレクトリを削除
     * @param dir
     * @throws java.io.IOException
     */
    public static void deleteDir(File dir) throws IOException {
       	if (dir == null || dir.isFile()){
            return;
    	}
        logger.info("Delete Directory=[{}]", dir.getAbsolutePath());
        org.apache.commons.io.FileUtils.deleteDirectory(dir);
    }
    
    /**
    * ファイルを削除する
    * @param fname ファイル名
    */
    public static void deleteFile( String fname ){
        File f = new File( fname );
        if (f.isFile()) {
            String path = f.getAbsolutePath();
            boolean isSuccess = false;
            try {
                f.delete();
                isSuccess = true;
            } catch (Exception e){}
            logger.info("Delete file=[{}] is {}", path, isSuccess);
        }
    }

}
