package jp.co.toshiba.hby.pspromis.syuueki.bean;

import java.util.List;
import java.util.Map;
import javax.enterprise.context.RequestScoped;
import javax.inject.Named;
import jp.co.toshiba.hby.pspromis.syuueki.entity.EstViewList;
import lombok.Getter;
import lombok.Setter;

/**
 *
 * @author ganryu
 */
@Named(value = "s017Bean")
@RequestScoped
@Getter
@Setter
public class S017Bean extends AbstractBean {

    private List<EstViewList> dispSelectItemList;
    private String chuban;
    private String divisionCode;
    private boolean isEditAction = false;
    private boolean isSaveAction = false;
    private List<Map<String, String>> estList;
   
}
