package jp.co.toshiba.hby.pspromis.syuueki.servlet;

import javax.inject.Inject;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpServletRequest;
import jp.co.toshiba.hby.pspromis.syuueki.bean.MikomiUploadBean;
import jp.co.toshiba.hby.pspromis.syuueki.bean.MikomiUploadErrorBean;
import jp.co.toshiba.hby.pspromis.syuueki.enums.MikomiUploadLabel;
import jp.co.toshiba.hby.pspromis.syuueki.service.MikomiUploadService;
import jp.co.toshiba.hby.pspromis.syuueki.util.ParameterBinder;
/**
 * PS-Promis収益管理システム
 * 注入見込Upload Servlet
 * @author sano
 */
@WebServlet(name="MikomiUpload", urlPatterns={"/servlet/MikomiUpload"})
public class MikomiUploadServlet extends AbstractServlet {

    /**
     * jsp
     */
    private static final String INDEX_JSP = "mikomiUpload/uploadResult.jsp";

    /**
     * 使用serviceクラスをinjection(CDI)<br>
     */
    @Inject
    private MikomiUploadService mikomiUploadService;

    /**
     * パラメータ格納クラスをinjection(CDI)<br>
     */
    @Inject
    private MikomiUploadBean mikomiUploadBean;
    
    /**
     * 処理結果クラスをinjection(CDI)<br>
     */
    @Inject
    private MikomiUploadErrorBean mikomiUploadErrorBean;

    /**
     * 初期表示
     * @param req
     * @param resp
     * @return
     * @throws Exception 
     */
    public String indexAction(HttpServletRequest req, HttpServletResponse resp)
    throws Exception {
        logger.info("MikomiUploadServlet#indexAction");

        try {
            // アップロード処理結果メッセージの初期化
            // (セッションにしているため、前回の結果をクリアする)
            if (mikomiUploadErrorBean != null) {
                mikomiUploadErrorBean.setTitleInfo(null);
                mikomiUploadErrorBean.setIsSuccess(true);
                mikomiUploadErrorBean.clearMessage();
            }

            ParameterBinder.Bind(mikomiUploadBean, req);

            // サービスの実行
            mikomiUploadService.executeUpload();

        } catch (Throwable e) {
            // アップロード中の致命的エラー補足(log出力＋結果子画面に出力するメッセージを登録)
            //String message = MikomiUploadLabel.getValue(MikomiUploadLabel.uploadFatalError);
            String message = MikomiUploadLabel.getValue(MikomiUploadLabel.fileReadError);

            logger.error(message, e);
            
            mikomiUploadErrorBean.clearMessage();
            mikomiUploadErrorBean.addErrorMessage(message);
            mikomiUploadErrorBean.setIsSuccess(false);
        }

        return INDEX_JSP;
    }
}
