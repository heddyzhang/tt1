package jp.co.toshiba.hby.pspromis.syuueki.dto;

import lombok.Getter;
import lombok.Setter;

/**
 * ES-Promis収益管理システム
 * (原子力)収益管理システムへのデータ連携パッケージのパラメータ
 * @author ibayashi
 */
@Getter @Setter
public class NuclearRenkeiBatchDto {
   
    /**
     * 対象案件id
     */
    private String ankenId;
    
    /**
     * 対象履歴id
     */
    private String rirekiId;

    /**
     * 連携モード(0:更新対象データのみ連携 9:全データ連携)
     */
    private String renkeiType;
    
    /**
     * 処理結果(0:成功、9:失敗)
     */
    private Integer status;
    
    /**
     * エラー内容
     */
    private String errMsg;
    
    /**
     * 実行したパッケージ名
     */
    private String exeProcedureName;

}