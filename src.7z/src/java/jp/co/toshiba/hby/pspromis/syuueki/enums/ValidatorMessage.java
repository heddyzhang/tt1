package jp.co.toshiba.hby.pspromis.syuueki.enums;

import java.util.Locale;
import java.util.ResourceBundle;
//import jp.co.toshiba.hby.pspromis.sonpi.bean.LocaleBean;
//import jp.co.toshiba.hby.pspromis.sonpi.util.CdiUtils;
import org.apache.commons.lang3.StringUtils;

/**
 * プロパティファイル(validatorMessage)のキーを定義する列挙型<br>
 * バリデーションエラーメッセージ関連
 *
 * @author ibayashi
 */
public enum ValidatorMessage {
    
    PROCESS_ERROR("cmn.process.error"),
    REQUIRED("required"),
    REQUIRED_SELECT("requiredSelect"),
    BYTE_OVER_HAN_ONLY("byteOverHanOnly"),
    BYTE_OVER_HAN_ZEN("byteOverHanZen"),
    SAME_DATA_ERROR("sameDataError"),
    REPEAT_DATA_ERROR("repeatDataError"),
    CATEGORY_OVERLAP("categoryOverlap"),
    CATEGORY_EXISTS("categoryExists"),
    SAME_AGGREGATE("sameAggregate"),
    KIKAN_FALSE("kikanFalse"),
    KIKAN_OVER("kikanOver"),
    NO_SELECT_KASUIZI("noSelectKasuizi")
    ,KAISYU_EDIT_OVERLAP("kaisyuEditOverlap")
    ,HBN_ERROR("stringHanError") //2017/05/18 ADD
    ,FORM_ERROR("formError")     //2017/05/18 ADD
    ,REQUIRED_SELECTED("requiredSelected"),//2017/05/18 ADD
    ;

    private final String mesageKey;

    private ValidatorMessage(final String key) {
        this.mesageKey = key;
    }

    public String getMessae() {
        //Locale locale = getLocale();
        //ResourceBundle rb = ResourceBundle.getBundle("validatorMessage", locale);
        ResourceBundle rb = ResourceBundle.getBundle("ValidationMessages");
        String value = rb.getString(mesageKey);
        return value;
    }

    public String getMessae(Object... changeValues) {
        String message = getMessae();
        if (changeValues != null && changeValues.length > 0) {
            int no = 0;
            for (Object changeValue : changeValues) {
                String sChangeValue = "";
                if (changeValue != null) {
                    sChangeValue = String.valueOf(changeValue);
                }
                message = StringUtils.replace(message, "{" + no + "}", sChangeValue);
                no++;
            }
        }
        return message;
    }

//    private static Locale getLocale() {
//        Locale locale;
//
//        try {
//            LocaleBean localeBean = CdiUtils.getBean(LocaleBean.class);
//            locale = localeBean.getLocale();
//        } catch (Exception e) {
//            locale = Locale.getDefault();
//        }
//
//        return locale;
//    }
}
