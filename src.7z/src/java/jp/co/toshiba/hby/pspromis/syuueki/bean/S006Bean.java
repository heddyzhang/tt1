package jp.co.toshiba.hby.pspromis.syuueki.bean;

import java.util.Date;
import java.util.List;
import javax.enterprise.context.RequestScoped;
import javax.inject.Named;
import jp.co.toshiba.hby.pspromis.syuueki.entity.SyuGeRirekiInfoTbl;
import lombok.Getter;
import lombok.Setter;

/**
 *
 * @author wakamatsu
 */
@Named(value = "s006Bean")
@RequestScoped
@Getter @Setter
public class S006Bean extends AbstractBean{
    
    /**
     * 前回選択Flg
     */
    private String zenkaiFlg;
    
    /**
     * 確定日
     */
    private Date fixedDate;
    
    /**
     * 履歴タイトル
     */
    private String rirekititle;
    
    /**
     * 案件種別
    */
    private String ankenKbn;
    
    /**
     * 確定者
     */    
    private String fixedBy;

    /**
     * 履歴一覧
     */
    private List<SyuGeRirekiInfoTbl> rirekiList;

    /**
     * 事業部コード
     */
    private String divisionCode;

    /**
     * Creates a new instance of S001Bean
     */
    public S006Bean() {
    }
    
    public Date getFixedDate() {
        return fixedDate;
    }

    public void setFixedDate(Date fixedDate) {
        this.fixedDate = fixedDate;
    }

    public String getRirekititle() {
        return rirekititle;
    }

    public void setRirekititle(String rirekititle) {
        this.rirekititle = rirekititle;
    }

    public String getAnkenKbn() {
        return ankenKbn;
    }

    public void setAnkenKbn(String ankenKbn) {
        this.ankenKbn = ankenKbn;
    }

    public String getFixedBy() {
        return fixedBy;
    }

    public void setFixedBy(String fixedBy) {
        this.fixedBy = fixedBy;
    }

    public List<SyuGeRirekiInfoTbl> getRirekiList() {
        return rirekiList;
    }

    public void setRirekiList(List<SyuGeRirekiInfoTbl> rirekiList) {
        this.rirekiList = rirekiList;
    }

}
