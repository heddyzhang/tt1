package jp.co.toshiba.hby.pspromis.syuueki.facade;

import java.util.Map;
import java.util.HashMap;
import java.util.List;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.ejb.Stateless;
import javax.inject.Inject;
import javax.interceptor.Interceptors;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import jp.co.toshiba.hby.pspromis.common.jdbc.SqlExecutor;
import jp.co.toshiba.hby.pspromis.syuueki.entity.EstContractTypeMst;
import jp.co.toshiba.hby.pspromis.syuueki.interceptor.TranceInterceptor;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;

/**
 * 契約形態マスタを操作するfacadeクラス
 */
@Stateless
@Interceptors({TranceInterceptor.class})
public class EstContractTypeMstFacade {

    @PersistenceContext(unitName = jp.co.toshiba.hby.pspromis.syuueki.util.ConstantString.syuuekiDataSourceName)
    private EntityManager entityManager;

    @Inject
    private SqlExecutor sqlExecutor;

    /**
     * 有効なデータを取得する
     * @param divisionCode
     * @return List<EstContractTypeMst> 有効データ
     */
    @TransactionAttribute(TransactionAttributeType.NOT_SUPPORTED)
    public List<EstContractTypeMst> selectContractTypeList(String divisionCode){
        Map<String, Object> condition = new HashMap<>();
        condition.put("divisionCode", divisionCode);

        return selectContractTypeList(condition);
    }

    /**
     * 有効なデータを取得する
     * @param condition
     * @return List<EstContractTypeMst> 有効データ
     */
    @TransactionAttribute(TransactionAttributeType.NOT_SUPPORTED)
    public List<EstContractTypeMst> selectContractTypeList(Map<String, Object> condition){
        return sqlExecutor.getResultList(entityManager, EstContractTypeMst.class, "/sql/contractTypeMst/getEstContractType.sql", condition);
    }

    /**
     * コード指定で取得
     * @param contractCode 契約形態コード
     * @return EstContractTypeMstFacade 契約形態マスタ
     */
    @TransactionAttribute(TransactionAttributeType.NOT_SUPPORTED)
    public EstContractTypeMst selectContractType(String contractCode) {
        if (StringUtils.isEmpty(contractCode)) {
            return null;
        }
        
        Map<String, Object> condition = new HashMap<>();
        condition.put("contractCode", contractCode);
        
        List<EstContractTypeMst> list
                = sqlExecutor.getResultList(entityManager, EstContractTypeMst.class, "/sql/contractTypeMst/getEstContractType.sql", condition);

        EstContractTypeMst entity = null;
        if (CollectionUtils.isNotEmpty(list)) {
            entity = list.get(0);
        }

        return entity;
    }

}