package jp.co.toshiba.hby.pspromis.syuueki.validation;

import java.util.Map;
import jp.co.toshiba.hby.pspromis.syuueki.bean.S009Bean;
import jp.co.toshiba.hby.pspromis.syuueki.bean.ValidationInfoBean;
import jp.co.toshiba.hby.pspromis.syuueki.enums.Label;
import jp.co.toshiba.hby.pspromis.syuueki.util.Utils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 *
 * @author ibayashi
 */
public class S009Validation extends AbstractValidation<S009Bean> {
    public static final Logger logger = LoggerFactory.getLogger(S009Validation.class);
    
    /**
     * コンストラクタ
     */
    public S009Validation(S009Bean bean) {
        super(bean);
    }

    /**
     * 検索処理時のバリデーション
     */
    public void execListValidation(ValidationInfoBean vBean) {
        annotationValidate();
        
        Map<String, String> messages = getValidateMessagess();
        S009Bean bean = getBean();
        String message;

        //// 独自チェック
        // メニュー選択の必須チェック
        if (StringUtils.isEmpty(bean.getSelMenu())) {
            message = StringUtils.replace(getValidationMessage("requiredSelect"), "{0}", Label.getValue(Label.selMenu));
            messages.put("selMenu", message);
        }

        // 見込レートマスタ種類(メニュー：見込レートを選択している場合のみチェック)
        if ("RATE".equals(bean.getSelMenu())) {
            if (StringUtils.isEmpty(bean.getMikomiRateType())) {
                message = StringUtils.replace(getValidationMessage("requiredSelect"), "{0}", Label.getValue(Label.mikomiRateType));
                messages.put("mikomiRateType", message);
            }
        }
        
        vBean.setMessages(messages);
    }
}
