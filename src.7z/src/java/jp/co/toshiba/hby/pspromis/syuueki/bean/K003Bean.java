/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package jp.co.toshiba.hby.pspromis.syuueki.bean;

import java.util.List;
import javax.enterprise.context.RequestScoped;
import javax.inject.Named;
import jp.co.toshiba.hby.pspromis.syuueki.entity.PlantMst;

/**
 *
 * @author horie
 */
@Named(value = "k003Bean")
@RequestScoped
public class K003Bean {
    /**
     * 一覧検索フラグ
     */
    private String listFlg = "0";

    /**
     * プラント一覧データ
     */
    private List<PlantMst> plantList;

    /**
     * 検索条件・事業部
     */
    private String[] divisionCode;
    
    /**
     * 検索条件・プラントコード
     */
    private String plantCode;
    
    /**
     * 検索結果・検索件数
     */
    private Integer count;
 
    /**
     * 現在表示するページ番号
     */
    private Integer page;
 
    
    public List<PlantMst> getPlantList() {
        return plantList;
    }
    
    public void setPlantList(List<PlantMst> plantList) {
        this.plantList = plantList;
    }

    public String getPlantCode() {
        return plantCode;
    }

    public void setPlantCode(String plantCode) {
        this.plantCode = plantCode;
    }

    public Integer getCount() {
        return count;
    }

    public void setCount(Integer count) {
        this.count = count;
    }

    public Integer getPage() {
        return page;
    }

    public void setPage(Integer page) {
        this.page = page;
    }

    public String getListFlg() {
        return listFlg;
    }

    public void setListFlg(String listFlg) {
        this.listFlg = listFlg;
    }

    public String[] getDivisionCode() {
        return divisionCode;
    }

    public void setDivisionCode(String[] divisionCode) {
        this.divisionCode = divisionCode;
    }

}
