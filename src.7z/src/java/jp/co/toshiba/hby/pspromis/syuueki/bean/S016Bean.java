package jp.co.toshiba.hby.pspromis.syuueki.bean;

import javax.enterprise.context.RequestScoped;
import javax.inject.Named;
import lombok.Getter;
import lombok.Setter;

/**
 * 見込列複写
 * @author 
 */
@Named(value = "s016Bean")
@RequestScoped
@Getter @Setter
public class S016Bean extends AbstractBean {

    /**
     * 処理元の画面ID(操作ログの登録で利用)
     */
    private String procId;

    /**
     * 事業部コード
     */
    private String divisionCode;
    
    /**
     * 前回の履歴ID
     */
    private String zenkaiId;
    
    /**
     * 前回の勘定月
     */
    private String zenkaiKanjyoYm;
    
    /**
     * ポテンシャル管理Flg
     */
    private String potentialFlg = "0";

    /**
     * 複写元 データ区分
     */
    private String copyFromCol;

    /**
     * 複写先 データ区分
     */
    private String[] copyToCol;

    /**
     * 複写先データ有無区分(客先予算・最新見積)
     */
    private int dataSmAmountCount = 0;
    
    /**
     * 複写先データ有無区分(当初見込(受政))
     */
    private int dataJsAmountCount = 0;
    
    /**
     * 複写先データ有無区分(受注(契約時))
     */
    private int dataJtAmountCount = 0;
    
    /**
     * 複写先データ有無区分(目標)
     */
    private int dataMhAmountCount = 0;
    
    /**
     * 複写先データ有無区分(最終見込)
     */
    private int dataFmAmountCount = 0;
    
    /**
     * 複写先データ有無区分(見込大)
     */
    private int dataPdAmountCount = 0;
    
    /**
     * 複写先データ有無区分(見込中)
     */
    private int dataPtAmountCount = 0;
    
    /**
     * 複写先データ有無区分(見込小)
     */
    private int dataPsAmountCount = 0;
    
}
