package jp.co.toshiba.hby.pspromis.syuueki.servlet;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.Date;
import javax.inject.Inject;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpServletRequest;
import jp.co.toshiba.hby.pspromis.syuueki.bean.S014Bean;
import jp.co.toshiba.hby.pspromis.syuueki.service.S014Service;
import jp.co.toshiba.hby.pspromis.syuueki.util.FileUtils;
import jp.co.toshiba.hby.pspromis.syuueki.util.ParameterBinder;
import jp.co.toshiba.hby.pspromis.syuueki.util.PoiUtil;
import org.apache.poi.ss.usermodel.Workbook;

/**
 * PS-Promis収益管理システム
 * 月次確定詳細 Servlet 
 * @author ibayashi
 */
@WebServlet(name="S014", urlPatterns={"/servlet/S014", "/servlet/S014/*"})
public class S014Servlet extends AbstractServlet {

    /**
     * jsp
     */
    private static final String INDEX_JSP = "S014/s014.jsp";

    /**
     * コメントjsp
     */
    private static final String COMMENT_JSP = "S014/comment.jsp";
    
    @Inject
    private S014Bean s014Bean;
    
    /**
     * 使用serviceクラスをinjection(CDI)<br>
     */
    @Inject
    private S014Service s014Service;

    /**
     * 初期表示
     * @param req
     * @param resp
     * @return
     * @throws Exception 
     */
    public String indexAction(HttpServletRequest req, HttpServletResponse resp)
    throws Exception {
        logger.info("S014Servlet#indexAction");
        
        // リクエストパラメータをS013Beanの同名フィールドに一括コピー
        ParameterBinder.Bind(s014Bean, req);
        
        // サービスの実行(トランザクションの単位にもなる)
        s014Service.indexExecute();

        return INDEX_JSP;
    }

    /**
     * コメント入力ダイアログ表示
     * @param req
     * @param resp
     * @return
     * @throws Exception 
     */
    public String commentAction(HttpServletRequest req, HttpServletResponse resp)
    throws Exception {
        logger.info("S014Servlet#commentAction");
        
        // リクエストパラメータをS013Beanの同名フィールドに一括コピー
        ParameterBinder.Bind(s014Bean, req);
        
        // サービスの実行
        s014Service.commentxExecute();

        return COMMENT_JSP;
    }
    
    /**
     * ワークフロー実行
     * @param req
     * @param resp
     * @return
     * @throws Exception 
     */
    public String workFlowAction(HttpServletRequest req, HttpServletResponse resp)
    throws Exception {
        logger.info("S014Servlet#workFlowAction");
        
        // リクエストパラメータをS013Beanの同名フィールドに一括コピー
        ParameterBinder.Bind(s014Bean, req);
        
        // サービスの実行(トランザクションの単位にもなる)
        s014Service.workFlowExecute();

        return null;
    }
    
    /**
     * Excelダウンロード処理
     * @param req
     * @param resp
     * @return
     * @throws Exception 
     */
    public String downloadAction(HttpServletRequest req, HttpServletResponse resp) throws Exception {
        ParameterBinder.Bind(s014Bean, req);
        
        // テンプレートファイルの読み込み
        String filePath = req.getServletContext().getRealPath("WEB-INF/template/workFlowList_template.xlsx");
        Workbook workbook = PoiUtil.getWorkbook(new File(filePath));

        // テンプレートにデータ埋め込み
        s014Service.outputDownloadExcel(workbook);
        
        // テンプレート出力
        FileUtils.httpDownloadExcelResponse(workbook, "月次確定案件一覧" + (new SimpleDateFormat("yyyyMMddHHmm")).format(new Date()) + ".xlsx", resp);

        return null;
    }
    
}
