/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package jp.co.toshiba.hby.pspromis.syuueki.entity;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.NotNull;

/**
 *
 * @author ibayashi
 */
@Entity
public class EstViewList implements Serializable {
    private static final long serialVersionUID = 1L;
    @Id
    @Basic(optional = false)
    @NotNull
    @Column(name = "SALES_EST_REQ_ID")
    private BigDecimal salesEstReqId;
    @Id
    @Column(name = "SALES_EST_REQ_REV")
    private BigDecimal salesEstReqRev;
    @Column(name = "MITUMORI_NO")
    private String mitumoriNo;
    @Column(name = "ESTIMATE_TYPE_NAME")
    private String estimateTypeName;
    @Column(name = "ESTIMATE_TITLE")
    private String estimateTitle;
    @Column(name = "REQUEST_DATE")
    @Temporal(TemporalType.TIMESTAMP)
    private Date requestDate;
    @Column(name = "KESSAI_STS_NM")
    private String kessaiStsNm;
    @Column(name = "ANKEN_ID")
    private String ankenId;
    @Column(name = "SPURT_NO")
    private String spurtNo;
    @Column(name = "TPSC_IHI_DATA_FLG")
    private String tpscIhiDataFlg;
    @Column(name = "NOKI")
    @Temporal(TemporalType.DATE)
    private Date noki;
    @Column(name = "KENSYUTUKI")
    private String kensyutuki;


    public EstViewList() {
    }

    public BigDecimal getSalesEstReqId() {
        return salesEstReqId;
    }

    public void setSalesEstReqId(BigDecimal salesEstReqId) {
        this.salesEstReqId = salesEstReqId;
    }

    public BigDecimal getSalesEstReqRev() {
        return salesEstReqRev;
    }

    public void setSalesEstReqRev(BigDecimal salesEstReqRev) {
        this.salesEstReqRev = salesEstReqRev;
    }

    public String getMitumoriNo() {
        return mitumoriNo;
    }

    public void setMitumoriNo(String mitumoriNo) {
        this.mitumoriNo = mitumoriNo;
    }

    public String getEstimateTypeName() {
        return estimateTypeName;
    }

    public void setEstimateTypeName(String estimateTypeName) {
        this.estimateTypeName = estimateTypeName;
    }

    public String getEstimateTitle() {
        return estimateTitle;
    }

    public void setEstimateTitle(String estimateTitle) {
        this.estimateTitle = estimateTitle;
    }

    public Date getRequestDate() {
        return requestDate;
    }

    public void setRequestDate(Date requestDate) {
        this.requestDate = requestDate;
    }

    public String getKessaiStsNm() {
        return kessaiStsNm;
    }

    public void setKessaiStsNm(String kessaiStsNm) {
        this.kessaiStsNm = kessaiStsNm;
    }

    public String getAnkenId() {
        return ankenId;
    }

    public void setAnkenId(String ankenId) {
        this.ankenId = ankenId;
    }

    public String getSpurtNo() {
        return spurtNo;
    }

    public void setSpurtNo(String spurtNo) {
        this.spurtNo = spurtNo;
    }

    public String getTpscIhiDataFlg() {
        return tpscIhiDataFlg;
    }

    public void setTpscIhiDataFlg(String tpscIhiDataFlg) {
        this.tpscIhiDataFlg = tpscIhiDataFlg;
    }

    public Date getNoki() {
        return noki;
    }

    public void setNoki(Date noki) {
        this.noki = noki;
    }

    public String getKensyutuki() {
        return kensyutuki;
    }

    public void setKensyutuki(String kensyutuki) {
        this.kensyutuki = kensyutuki;
    }

}
