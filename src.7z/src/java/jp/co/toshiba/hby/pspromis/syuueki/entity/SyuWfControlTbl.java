/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package jp.co.toshiba.hby.pspromis.syuueki.entity;

import java.io.Serializable;
import java.util.Date;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/**
 *
 * @author ibayashi
 */
@Entity
@Table(name = "SYU_WF_CONTROL_TBL")
public class SyuWfControlTbl implements Serializable {
    private static final long serialVersionUID = 1L;
    
    @Id
    @Column(name = "DIVISION_CODE")
    private String divisionCode;

    @Id
    @Column(name = "GROUP_CODE")
    private String groupCode;

    @Column(name = "C_BUKA_CODE")
    private String cBukaCode;

    @Column(name = "DISP_FLG")
    private String dispFlg;

    @Id
    @Column(name = "SALES_CLASS")
    private String salesClass;

    @Column(name = "SYUBETSU")
    private String syubetsu;
    
    @Id
    @Column(name = "KANJYO_YM")
    private String kanjyoYm;

    @Id
    @Column(name = "HONSYA_SHISYA_KBN")
    private String honsyaShisyaKbn;

    @Id
    @Column(name = "TEAM_CODE")
    private String teamCode;

    @Column(name = "TANTO_NM")
    private String tantoNm;
    
    @Column(name = "STATUS")
    private String status;

    @Column(name = "RIREKI_ID")
    private long rirekiId;

    @Column(name = "JOBID")
    private String jobid;

    @Column(name = "RIREKI_TITLE")
    private String rirekiTitle;
    
    @Column(name = "KISO_AT")
    @Temporal(TemporalType.TIMESTAMP)
    private Date kisoAt;

    @Column(name = "KISO_BY")
    private String kisoBy;

    @Column(name = "KISO_NAME")
    private String kisoName;

    @Column(name = "KISO_COMMENT")
    private String kisoComment;
    
    @Column(name = "CHOSA_AT")
    @Temporal(TemporalType.TIMESTAMP)
    private Date chosaAt;

    @Column(name = "CHOSA_BY")
    private String chosaBy;

    @Column(name = "CHOSA_NAME")
    private String chosaName;

    @Column(name = "CHOSA_COMMENT")
    private String chosaComment;

    @Column(name = "SYONIN_AT")
    @Temporal(TemporalType.TIMESTAMP)
    private Date syoninAt;
    
    @Column(name = "SYONIN_BY")
    private String syoninBy;

    @Column(name = "SYONIN_NAME")
    private String syoninName;

    @Column(name = "SYONIN_COMMENT")
    private String syoninComment;

    @Column(name = "HININ_AT")
    @Temporal(TemporalType.TIMESTAMP)
    private Date hininAt;

    @Column(name = "HININ_BY")
    private String hininBy;

    @Column(name = "HININ_NAME")
    private String hininName;

    @Column(name = "HININ_COMMENT")
    private String hininComment;

    @Column(name = "KANJYO_1Q")
    private String kanjyo1q;

    @Column(name = "SP_1Q")
    private Long sp1q;

    @Column(name = "NET_1Q")
    private Long net1q;

    @Column(name = "KANJYO_2Q")
    private String kanjyo2q;

    @Column(name = "SP_2Q")
    private Long sp2q;

    @Column(name = "NET_2Q")
    private Long net2q;

    @Column(name = "KANJYO_3Q")
    private String kanjyo3q;

    @Column(name = "SP_3Q")
    private Long sp3q;

    @Column(name = "NET_3Q")
    private Long net3q;

    @Column(name = "KANJYO_4Q")
    private String kanjyo4q;

    @Column(name = "SP_4Q")
    private Long sp4q;

    @Column(name = "NET_4Q")
    private Long net4q;

    @Column(name = "SP_TOTAL")
    private Long spTotal;

    @Column(name = "NET_TOTAL")
    private Long netTotal;

    @Column(name = "CREATED_AT")
    @Temporal(TemporalType.TIMESTAMP)
    private Date createdAt;

    @Column(name = "CREATED_BY")
    private String createdBy;

    @Column(name = "UPDATED_AT")
    @Temporal(TemporalType.TIMESTAMP)
    private Date updatedAt;

    @Column(name = "UPDATED_BY")
    private String updatedBy;

    @Column(name = "UPDATED_BATCH_AT")
    @Temporal(TemporalType.TIMESTAMP)
    private Date updatedBatchAt;

    @Column(name = "UPDATED_BATCH_BY")
    private String updatedBatchBy;


        
    public SyuWfControlTbl() {
    }

    public String getTantoNm() {
        return tantoNm;
    }

    public void setTantoNm(String tantoNm) {
        this.tantoNm = tantoNm;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public long getRirekiId() {
        return rirekiId;
    }

    public void setRirekiId(long rirekiId) {
        this.rirekiId = rirekiId;
    }

    public String getJobid() {
        return jobid;
    }

    public void setJobid(String jobid) {
        this.jobid = jobid;
    }

    public String getRirekiTitle() {
        return rirekiTitle;
    }

    public void setRirekiTitle(String rirekiTitle) {
        this.rirekiTitle = rirekiTitle;
    }

    public Date getKisoAt() {
        return kisoAt;
    }

    public void setKisoAt(Date kisoAt) {
        this.kisoAt = kisoAt;
    }

    public String getKisoBy() {
        return kisoBy;
    }

    public void setKisoBy(String kisoBy) {
        this.kisoBy = kisoBy;
    }

    public String getKisoName() {
        return kisoName;
    }

    public void setKisoName(String kisoName) {
        this.kisoName = kisoName;
    }

    public String getKisoComment() {
        return kisoComment;
    }

    public void setKisoComment(String kisoComment) {
        this.kisoComment = kisoComment;
    }

    public Date getChosaAt() {
        return chosaAt;
    }

    public void setChosaAt(Date chosaAt) {
        this.chosaAt = chosaAt;
    }

    public String getChosaBy() {
        return chosaBy;
    }

    public void setChosaBy(String chosaBy) {
        this.chosaBy = chosaBy;
    }

    public String getChosaName() {
        return chosaName;
    }

    public void setChosaName(String chosaName) {
        this.chosaName = chosaName;
    }

    public String getChosaComment() {
        return chosaComment;
    }

    public void setChosaComment(String chosaComment) {
        this.chosaComment = chosaComment;
    }

    public Date getSyoninAt() {
        return syoninAt;
    }

    public void setSyoninAt(Date syoninAt) {
        this.syoninAt = syoninAt;
    }

    public String getSyoninBy() {
        return syoninBy;
    }

    public void setSyoninBy(String syoninBy) {
        this.syoninBy = syoninBy;
    }

    public String getSyoninName() {
        return syoninName;
    }

    public void setSyoninName(String syoninName) {
        this.syoninName = syoninName;
    }

    public String getSyoninComment() {
        return syoninComment;
    }

    public void setSyoninComment(String syoninComment) {
        this.syoninComment = syoninComment;
    }

    public Date getHininAt() {
        return hininAt;
    }

    public void setHininAt(Date hininAt) {
        this.hininAt = hininAt;
    }

    public String getHininBy() {
        return hininBy;
    }

    public void setHininBy(String hininBy) {
        this.hininBy = hininBy;
    }

    public String getHininName() {
        return hininName;
    }

    public void setHininName(String hininName) {
        this.hininName = hininName;
    }

    public String getHininComment() {
        return hininComment;
    }

    public void setHininComment(String hininComment) {
        this.hininComment = hininComment;
    }

    public String getKanjyo1q() {
        return kanjyo1q;
    }

    public void setKanjyo1q(String kanjyo1q) {
        this.kanjyo1q = kanjyo1q;
    }

    public Long getSp1q() {
        return sp1q;
    }

    public void setSp1q(Long sp1q) {
        this.sp1q = sp1q;
    }

    public Long getNet1q() {
        return net1q;
    }

    public void setNet1q(Long net1q) {
        this.net1q = net1q;
    }

    public String getKanjyo2q() {
        return kanjyo2q;
    }

    public void setKanjyo2q(String kanjyo2q) {
        this.kanjyo2q = kanjyo2q;
    }

    public Long getSp2q() {
        return sp2q;
    }

    public void setSp2q(Long sp2q) {
        this.sp2q = sp2q;
    }

    public Long getNet2q() {
        return net2q;
    }

    public void setNet2q(Long net2q) {
        this.net2q = net2q;
    }

    public String getKanjyo3q() {
        return kanjyo3q;
    }

    public void setKanjyo3q(String kanjyo3q) {
        this.kanjyo3q = kanjyo3q;
    }

    public Long getSp3q() {
        return sp3q;
    }

    public void setSp3q(Long sp3q) {
        this.sp3q = sp3q;
    }

    public Long getNet3q() {
        return net3q;
    }

    public void setNet3q(Long net3q) {
        this.net3q = net3q;
    }

    public String getKanjyo4q() {
        return kanjyo4q;
    }

    public void setKanjyo4q(String kanjyo4q) {
        this.kanjyo4q = kanjyo4q;
    }

    public Long getSp4q() {
        return sp4q;
    }

    public void setSp4q(Long sp4q) {
        this.sp4q = sp4q;
    }

    public Long getNet4q() {
        return net4q;
    }

    public void setNet4q(Long net4q) {
        this.net4q = net4q;
    }

    public Long getSpTotal() {
        return spTotal;
    }

    public void setSpTotal(Long spTotal) {
        this.spTotal = spTotal;
    }

    public Long getNetTotal() {
        return netTotal;
    }

    public void setNetTotal(Long netTotal) {
        this.netTotal = netTotal;
    }

    public Date getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(Date createdAt) {
        this.createdAt = createdAt;
    }

    public String getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    public Date getUpdatedAt() {
        return updatedAt;
    }

    public void setUpdatedAt(Date updatedAt) {
        this.updatedAt = updatedAt;
    }

    public String getUpdatedBy() {
        return updatedBy;
    }

    public void setUpdatedBy(String updatedBy) {
        this.updatedBy = updatedBy;
    }

    public Date getUpdatedBatchAt() {
        return updatedBatchAt;
    }

    public void setUpdatedBatchAt(Date updatedBatchAt) {
        this.updatedBatchAt = updatedBatchAt;
    }

    public String getUpdatedBatchBy() {
        return updatedBatchBy;
    }

    public void setUpdatedBatchBy(String updatedBatchBy) {
        this.updatedBatchBy = updatedBatchBy;
    }

    public String getDivisionCode() {
        return divisionCode;
    }

    public void setDivisionCode(String divisionCode) {
        this.divisionCode = divisionCode;
    }

    public String getGroupCode() {
        return groupCode;
    }

    public void setGroupCode(String groupCode) {
        this.groupCode = groupCode;
    }

    public String getcBukaCode() {
        return cBukaCode;
    }

    public void setcBukaCode(String cBukaCode) {
        this.cBukaCode = cBukaCode;
    }

    public String getSalesClass() {
        return salesClass;
    }

    public void setSalesClass(String salesClass) {
        this.salesClass = salesClass;
    }

    public String getSyubetsu() {
        return syubetsu;
    }

    public void setSyubetsu(String syubetsu) {
        this.syubetsu = syubetsu;
    }
   
    public String getKanjyoYm() {
        return kanjyoYm;
    }

    public void setKanjyoYm(String kanjyoYm) {
        this.kanjyoYm = kanjyoYm;
    }

    public String getHonsyaShisyaKbn() {
        return honsyaShisyaKbn;
    }

    public void setHonsyaShisyaKbn(String honsyaShisyaKbn) {
        this.honsyaShisyaKbn = honsyaShisyaKbn;
    }

    public String getTeamCode() {
        return teamCode;
    }

    public void setTeamCode(String teamCode) {
        this.teamCode = teamCode;
    }

    public String getDispFlg() {
        return dispFlg;
    }

    public void setDispFlg(String dispFlg) {
        this.dispFlg = dispFlg;
    }

 
}
