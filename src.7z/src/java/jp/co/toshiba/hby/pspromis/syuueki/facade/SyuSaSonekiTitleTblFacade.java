package jp.co.toshiba.hby.pspromis.syuueki.facade;

import java.util.List;
import java.util.Map;
import javax.ejb.Stateless;
import javax.interceptor.Interceptors;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import jp.co.toshiba.hby.pspromis.common.util.BeanUtil;
import jp.co.toshiba.hby.pspromis.syuueki.entity.SyuSaSonekiTitleTbl;
import jp.co.toshiba.hby.pspromis.syuueki.interceptor.TranceInterceptor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * 最終見込損益TBL(原価) 損益項目タイトル
 *
 * @author ganryu
 */
@Stateless
@Interceptors({TranceInterceptor.class})
public class SyuSaSonekiTitleTblFacade extends AbstractFacade<SyuSaSonekiTitleTbl> {
    private static final Logger logger = LoggerFactory.getLogger(SyuSaSonekiTitleTblFacade.class);

    @PersistenceContext(unitName = jp.co.toshiba.hby.pspromis.syuueki.util.ConstantString.syuuekiDataSourceName)
    private EntityManager em;

    @Override
    protected EntityManager getEntityManager() {
        return em;
    }

    public SyuSaSonekiTitleTblFacade() {
        super(SyuSaSonekiTitleTbl.class);
    }

    public void merge(SyuSaSonekiTitleTbl facade) {
        this.em.merge(BeanUtil.createAndCopy(SyuSaSonekiTitleTbl.class, facade));
    }

    /**
     * ISP損益,販売間接費,為替予約損益の更新
     *
     * @param entity
     */
    public void setSonekiNet(SyuSaSonekiTitleTbl entity) {
        logger.info("SyuSaSonekiTitleTblFacade#setSonekiNet");
        sqlExecutor.executeUpdateSql(em, "/sql/syuSaSonekiTitleTbl/updateSonekiNet.sql", entity);
    }
    
    /**
     * コピー(複写)対象の通貨/レート/契約金額一覧を取得
     * @param _params
     * @return 
     */
    public List<SyuSaSonekiTitleTbl> findCopyList(Map<String, Object> _params) {
        List<SyuSaSonekiTitleTbl> list = sqlExecutor.getResultList(em, SyuSaSonekiTitleTbl.class, "/sql/syuSaSonekiTitleTbl/copyListSyuSaSonekiTitleTbl.sql", _params);
        return list;
    }

    /**
     * 指定したデータ区分の項目に金額が登録されているかをチェック
     * @param _params
     * @return 
     */
    public Integer getDataKbnSpNetFlg(Map<String, Object> _params) {
        Integer count = sqlExecutor.getCount(em, "/sql/syuSaSonekiTitleTbl/checkDataKbnAmount.sql", _params);
        return count;
    }

}
