/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package jp.co.toshiba.hby.pspromis.syuueki.util;

import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import jp.co.toshiba.hby.pspromis.syuueki.enums.Env;
import org.apache.commons.fileupload.FileItem;
import org.apache.commons.fileupload.FileUploadException;
import org.apache.commons.fileupload.disk.DiskFileItemFactory;
import org.apache.commons.fileupload.servlet.ServletFileUpload;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * パラメータをバインドする(multipart/form-data用)
 * @author (NPC)S.Ibayashi
 */
public class MultipartFormBinder {
    
    /**
     * ロガー
     */
    public static final Logger logger = LoggerFactory.getLogger(MultipartFormBinder.class);
    
    public static Map<String, Object> getParameterMap(HttpServletRequest req) throws Exception {
        Map<String, Object> paramFields = null;
        String charSet = null;
        String tempDir = null;

        if (ServletFileUpload.isMultipartContent(req)) {
            paramFields = new HashMap<>();

            tempDir = Env.getValue(Env.Upload_Temp_Dir_Work);

            DiskFileItemFactory factory = new DiskFileItemFactory();
            factory.setSizeThreshold(1426);
            factory.setRepository(new File(tempDir)); 

            ServletFileUpload upload = new ServletFileUpload(factory);
            //upload.setSizeMax(20 * 1024);
            //upload.setFileSizeMax(10 * 1024);

            List<FileItem> items;
            try {
                items = upload.parseRequest(req);
            } catch (FileUploadException e) {
                throw new ServletException(e);
            }

            charSet = Env.getValue(Env.Charset);
            
            // 全フィールドに対するループ
            for (FileItem item : items) {
                String key = item.getFieldName();

                if (item.isFormField()) {
                    /////////////////////////////////////////////
                    // type="file"以外のフィールド
                    /////////////////////////////////////////////
                    String[] strs = new String[1];
                    strs[0] = (String)item.getString(charSet);
                    if (!paramFields.containsKey(key)) {
                        paramFields.put(key, strs);
                    } else {
                        List<String> values = new ArrayList<>();
                        if (paramFields.get(key) instanceof String[]) {
                            String[] valueAry = (String[])paramFields.get(key);
                            for (String v : valueAry) {
                                values.add(v);
                            }

                        } else {
                            values.add((String)paramFields.get(key));
                        }
                        
                        values.add(strs[0]);
                        paramFields.put(key, (String[])values.toArray(new String[0]));
                    }

                } else {
                    /////////////////////////////////////////////
                    // type="file"のフィールド
                    ////////////////////////////////////////////
                    FileItem[] itemary = new FileItem[1];
                    itemary[0] = item;
                    if (!paramFields.containsKey(key)) {
                        paramFields.put(key, itemary);

                    } else {
                        List<FileItem> fItems = new ArrayList<>();
                        if (paramFields.get(key) instanceof FileItem[]) {
                            FileItem[] fItemsAry = (FileItem[])paramFields.get(key);
                            for (FileItem v : fItemsAry) {
                                fItems.add(v);
                            }

                        } else {
                            fItems.add((FileItem)paramFields.get(key));
                        }
                        
                        fItems.add(item);
                        paramFields.put(key, (FileItem[])fItems.toArray(new FileItem[0]));
                    }
                }
                
                
                
                
//                String key = item.getFieldName();
//                FileItem[] itemary;
//                String str;
//                String[] strs;
//                //boolean isString = false;
//                
//                if (item.isFormField()) {
//                    // type="file"以外のフィールド
//                    //isString = true;
//                    //value = item.getString(charSet);
//                    
//                    strs = new String[1];
//                    strs[0] = (String)item.getString(charSet);
//                    paramFields.put(key, strs);
//                    //System.out.println("FormField key=" + key + " value=" + value );
//                } else {
//                    // type="file"のフィールド
//                    //File f = new File(item.getName());
//                    //item.write(new File(tempDir, f.getName()));
//
//                    //File upFile = new File(tempDir + "/" + f.getName());
//                    //isString = false;
//                    
//                    //values = new Object[1];
//                    itemary = new FileItem[1];
//                    itemary[0] = item;
//                    paramFields.put(key, itemary);
//                    //System.out.println("UploadField key=" + key + " value=" + value );
//                }

                
            }

        }
        
        return paramFields;
    }

}
