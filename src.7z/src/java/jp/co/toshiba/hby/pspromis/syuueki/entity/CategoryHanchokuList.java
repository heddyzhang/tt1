package jp.co.toshiba.hby.pspromis.syuueki.entity;

import java.io.Serializable;
import java.math.BigDecimal;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.validation.constraints.NotNull;

/**
 *
 * @author sano
 */
@Entity
public class CategoryHanchokuList implements Serializable {
    private static final long serialVersionUID = 1L;
    @Id
    @NotNull
    @Column(name = "ANKEN_ID")
    private String ankenId;
    
    @Id
    @Column(name = "CATEGORY_CODE")
    private String categoryCode;
    
    @Column(name = "CATEGORY_NAME")
    private String categoryName;
    
    @Column(name = "HAN_CHOKU_NET_JS")
    private BigDecimal hanchokuNetJs;
    @Column(name = "HAN_CHOKU_NET_JT")
    private BigDecimal hanchokuNetJt;
    @Column(name = "HAN_CHOKU_NET_MH")
    private BigDecimal hanchokuNetMh;
    @Column(name = "HAN_CHOKU_NET_SM")
    private BigDecimal hanchokuNetSm;
    @Column(name = "HAN_CHOKU_NET_ST")
    private BigDecimal hanchokuNetSt;
    @Column(name = "HAN_CHOKU_NET_HB")
    private BigDecimal hanchokuNetHb;
    @Column(name = "HAN_CHOKU_NET_TR")
    private BigDecimal hanchokuNetTr;
    @Column(name = "HAN_CHOKU_NET_FM")
    private BigDecimal hanchokuNetFm;
    @Column(name = "HAN_CHOKU_NET_DIFF")
    private BigDecimal hanchokuNetDiff;
    @Column(name = "HAN_CHOKU_NET_PD")
    private BigDecimal hanchokuNetPd;
    @Column(name = "HAN_CHOKU_NET_PT")
    private BigDecimal hanchokuNetPt;
    @Column(name = "HAN_CHOKU_NET_PS")
    private BigDecimal hanchokuNetPs;
    @Column(name = "HAN_CHOKU_NET_PREV")
    private BigDecimal hanchokuNetPrev;

    public CategoryHanchokuList() {
    }

    public String getAnkenId() {
        return this.ankenId;
    }

    public void setAnkenId(String ankenId) {
        this.ankenId = ankenId;
    }

    public String getCategoryCode() {
        return this.categoryCode;
    }

    public void setCategoryCode(String categoryCode) {
        this.categoryCode = categoryCode;
    }

    public String getCategoryName() {
        return this.categoryName;
    }

    public void setCategoryName(String categoryName) {
        this.categoryName = categoryName;
    }

    public BigDecimal getHanchokuNetJs() {
        return this.hanchokuNetJs;
    }

    public void setHanchokuNetJs(BigDecimal hanchokuNetJs) {
        this.hanchokuNetJs = hanchokuNetJs;
    }

    public BigDecimal getHanchokuNetJt() {
        return this.hanchokuNetJt;
    }

    public void setHanchokuNetJt(BigDecimal hanchokuNetJt) {
        this.hanchokuNetJt = hanchokuNetJt;
    }

    public BigDecimal getHanchokuNetMh() {
        return this.hanchokuNetMh;
    }

    public void setHanchokuNetMh(BigDecimal hanchokuNetMh) {
        this.hanchokuNetMh = hanchokuNetMh;
    }

    public BigDecimal getHanchokuNetSm() {
        return this.hanchokuNetSm;
    }

    public void setHanchokuNetSm(BigDecimal hanchokuNetSm) {
        this.hanchokuNetSm = hanchokuNetSm;
    }

    public BigDecimal getHanchokuNetSt() {
        return this.hanchokuNetSt;
    }

    public void setHanchokuNetSt(BigDecimal hanchokuNetSt) {
        this.hanchokuNetSt = hanchokuNetSt;
    }

    public BigDecimal getHanchokuNetHb() {
        return this.hanchokuNetHb;
    }

    public void setHanchokuNetHb(BigDecimal hanchokuNetHb) {
        this.hanchokuNetHb = hanchokuNetHb;
    }

    public BigDecimal getHanchokuNetTr() {
        return this.hanchokuNetTr;
    }

    public void setHanchokuNetTr(BigDecimal hanchokuNetTr) {
        this.hanchokuNetTr = hanchokuNetTr;
    }

    public BigDecimal getHanchokuNetFm() {
        return this.hanchokuNetFm;
    }

    public void setHanchokuNetFm(BigDecimal hanchokuNetFm) {
        this.hanchokuNetFm = hanchokuNetFm;
    }

    public BigDecimal getHanchokuNetDiff() {
        return this.hanchokuNetDiff;
    }

    public void setHanchokuNetDiff(BigDecimal hanchokuNetDiff) {
        this.hanchokuNetDiff = hanchokuNetDiff;
    }

    public BigDecimal getHanchokuNetPd() {
        return hanchokuNetPd;
    }

    public void setHanchokuNetPd(BigDecimal hanchokuNetPd) {
        this.hanchokuNetPd = hanchokuNetPd;
    }

    public BigDecimal getHanchokuNetPt() {
        return hanchokuNetPt;
    }

    public void setHanchokuNetPt(BigDecimal hanchokuNetPt) {
        this.hanchokuNetPt = hanchokuNetPt;
    }

    public BigDecimal getHanchokuNetPs() {
        return hanchokuNetPs;
    }

    public void setHanchokuNetPs(BigDecimal hanchokuNetPs) {
        this.hanchokuNetPs = hanchokuNetPs;
    }

    public BigDecimal getHanchokuNetPrev() {
        return hanchokuNetPrev;
    }

    public void setHanchokuNetPrev(BigDecimal hanchokuNetPrev) {
        this.hanchokuNetPrev = hanchokuNetPrev;
    }
    
}
