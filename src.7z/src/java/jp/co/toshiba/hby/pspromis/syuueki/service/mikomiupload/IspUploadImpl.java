/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package jp.co.toshiba.hby.pspromis.syuueki.service.mikomiupload;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import javax.ejb.Stateless;
import javax.inject.Inject;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import jp.co.toshiba.hby.pspromis.common.util.StringUtil;
import jp.co.toshiba.hby.pspromis.syuueki.bean.MikomiUploadBean;
import jp.co.toshiba.hby.pspromis.syuueki.bean.MikomiUploadErrorBean;
import jp.co.toshiba.hby.pspromis.syuueki.entity.SyuGeBukkenInfoTbl;
import jp.co.toshiba.hby.pspromis.syuueki.enums.MikomiUploadLabel;
//import jp.co.toshiba.hby.pspromis.syuueki.util.LoginUserInfo;
import jp.co.toshiba.hby.pspromis.syuueki.util.PoiUtil;
import jp.co.toshiba.hby.pspromis.syuueki.util.Utils;
import org.apache.commons.lang3.StringUtils;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * PS-Promis収益管理システム
 * 見込アップロード処理「（電力ジ）ISP」
 * @author (NPC)S.Ibayashi
 */
@Stateless
public class IspUploadImpl implements UploadComponent {

    @PersistenceContext(unitName = jp.co.toshiba.hby.pspromis.syuueki.util.ConstantString.syuuekiDataSourceName)
    private EntityManager em;

    // タイトル
    private final String THIS_SHEET_TITLE = "（電力ジ）ＩＳＰ案件 工事進行基準 売上高見込";
    // 案件フラグ
    private final String MATOME_ANKEN_FLG = "1";
    // データの開始行
    private final int DATA_START_ROW = 3;
    // ISPのカテゴリー区分
    private final String ISP_CATEGORY_KBN = "ISP";
    // ISPのカテゴリー区分
    private final String ISP_CATEGORY_KBN2 = "0000000000";
    /**
     * ロガー
     */
    public static final Logger logger = LoggerFactory.getLogger(IspUploadImpl.class);

    @Inject
    private MikomiUploadBean mikomiUploadBean;

    @Inject
    private MikomiUploadErrorBean mikomiUploadErrorBean;

    @Inject
    private UploadDataAccess uploadDataAccess;

    /**
     * 入力内容のデータチェック
     * @return
     * @throws java.lang.Exception
     */
    @Override
    public boolean isDataCheck() throws Exception {
        logger.info("IspUploadImpl isDataCheck");

        boolean isCheck;

        // 作業対象シートを取得
        Sheet targetSheet = getTargetSheet();

        // Excelのタイトル(工場名)チェック
        isCheck = isCheckTitile(targetSheet);

        if (isCheck) {
            // Excel上の一覧を読み取って、DBに登録する値の取得/エラーチェックを行う。
            isCheck = exeGetData(targetSheet);
        }

        // beanに成功/失敗FLGをセット
        mikomiUploadErrorBean.setIsSuccess(isCheck);

        return isCheck;
    }

    /**
     * アップロード処理の実行
     * @throws java.lang.Exception
     */
    @Override
    public void executeUpload() throws Exception {
        logger.info("IspUploadImpl executeUpload");

        // データの登録
        List<Map<String, Object>> dataList = mikomiUploadBean.getDataList();
        
        if (dataList == null) {
            return;
        }

        // データを登録
        String ankenId = "";
        String befAnkenId = "";

        for (Map<String, Object> data : dataList) {
            ankenId = (String)data.get("ankenId");

            // SYU_KI_NET_CATE_TITLE_TBLの新規登録
            if (!befAnkenId.equals(ankenId)) {
                uploadDataAccess.insertKiNetCateTitleTbl(data);
                
                // 指定案件に対して再計算FLGを立てる(進行基準画面の再計算ボタン用)。
                uploadDataAccess.setSaikeisanFlg(ankenId, (Integer)data.get("rirekiId"));
            }

            // SYU_KI_NET_CATE_TUKI_TBLの更新(or新規登録)
            uploadDataAccess.updateKiNetCateTukiTbl(data);
            
            befAnkenId = ankenId;
        }
    }

    /**
     * 処理対象ワークシートの取得
     */
    private Sheet getTargetSheet() {
        Sheet sheet = (mikomiUploadBean.getWorkBook()).getSheetAt(0);
        return sheet;
    }

    /**
     * Excelのタイトルチェック(京浜,府などのタイトルと画面指定のファイル区分一致のチェック)
     */
    private boolean isCheckTitile(Sheet sheet) {
        String errorMessage = MikomiUploadLabel.getValue(MikomiUploadLabel.titleFormatError);

        Cell titleCell = PoiUtil.getCell(sheet, 1, 1);

        String title = (String)PoiUtil.getCellValue(titleCell);

        boolean isSuccess = false;

        String kbn = StringUtils.defaultString(mikomiUploadBean.getUploadKbn());

        if (!StringUtil.isEmpty(title)) {
            if (title.equals(this.THIS_SHEET_TITLE) && kbn.equals("04")) {
                isSuccess = true;
            }
        }

        if (!isSuccess) {
            mikomiUploadErrorBean.addErrorMessage(errorMessage);
        }

        return isSuccess;
    }

    /**
     * Excel上の一覧を読み取って、DBに登録する値の取得/エラーチェックを行う
     */
    private boolean exeGetData(Sheet sheet) throws Exception {
        Row row;
        int errorRow;

        String orderNo;

        SyuGeBukkenInfoTbl bukkenEn = null;
        Map<String, Object> categoryMstInfo = null;

        String amount;
        ArrayList<Map<String, Object>> dataList = new ArrayList<>();

        // 対象年月を取得
        Map<String, Integer> ymMap = getCheckYm(sheet);

        // Excelを行ループしてデータ取得
        // 行ループを行い年月を取得
        for (int cnt = DATA_START_ROW + 1; cnt<=sheet.getLastRowNum(); cnt++) {
            row = PoiUtil.getRow(sheet, cnt);
            if (row == null) {
                continue;
            }

            orderNo = Utils.getObjToStrValue(PoiUtil.getCellValue(row, 2));
            
            if (StringUtils.isEmpty(orderNo)) {
                continue;
            }
            if (!UploadUtil.isTargetOrderNo(orderNo)) {
                continue;
            }
            
            ////////// 注番データの取得 ///////////
            
            // 案件情報の検索
            bukkenEn = uploadDataAccess.findOnoBuken(orderNo, this.MATOME_ANKEN_FLG);
            if (bukkenEn == null || !bukkenEn.getDivisionCode().equals(mikomiUploadBean.getUploadDivisionCode())) {
                errorRow = cnt + 1;
                mikomiUploadErrorBean.addErrorMessage("(" + errorRow + ")行目：" + MikomiUploadLabel.getValue(MikomiUploadLabel.projectError) + "(" + orderNo + ")");
                continue;
            } 

            if (ymMap.size() > 0) {
                // 正常終了時のため、結果子画面に出力するメッセージ(案件番号/注番)を登録
                mikomiUploadErrorBean.addMessage("■" + bukkenEn.getAnkenId() + "/" + bukkenEn.getMainOrderNo());
            }

            // 年月ループ
            Set<String> keys = ymMap.keySet();
            Iterator<String> ite = keys.iterator();
            while (ite.hasNext()) {
                // 処理対象年月を取得
                String ym = ite.next();
                // 処理対象年月の列indexを取得
                int cellIndex = ymMap.get(ym);
                
                // データセット作成
                Map<String, Object> dataMap = new HashMap<>();
                dataMap.put("chuban", orderNo);
                dataMap.put("ankenId", bukkenEn.getAnkenId());
                dataMap.put("syuekiYm", convCellValToDate(ym, ""));
                
                String rawData = Utils.getObjToStrValue(PoiUtil.getCellValue(row, cellIndex));

                // 注入金額の入力チェック
                amount = changeAmountStr(rawData);

                if ("formatError".equals(amount)) {
                    errorRow = row.getRowNum() + 1;
                    mikomiUploadErrorBean.addErrorMessage(orderNo + "(" + errorRow + ")行目：" + ym + "：" + MikomiUploadLabel.getValue(MikomiUploadLabel.chunyuAmountFormatError) + "(" + rawData + ")");

                } else if ("ketaOverError".equals(amount)) {
                    errorRow = row.getRowNum() + 1;
                    mikomiUploadErrorBean.addErrorMessage(orderNo + "(" + errorRow + ")行目：" + ym + "：" + MikomiUploadLabel.getValue(MikomiUploadLabel.chunyuAmountKetaFormatError) + "(" + rawData + ")");
                }

                dataMap.put("chunyuAmount", amount);
                dataList.add(dataMap);
            }
        }

        // エラーが存在しない場合
        if (mikomiUploadErrorBean.getErrorMessage() == null || mikomiUploadErrorBean.getErrorMessage().isEmpty()) {
            // カテゴリマスタからCATEGORY_CODE,CATEGORY_CODE1,CATEGORY_CODE2等を取得(1回のみ)
            if (categoryMstInfo == null) {
                categoryMstInfo = uploadDataAccess.categoryMstInfo(this.ISP_CATEGORY_KBN, this.ISP_CATEGORY_KBN2);
            }

            for (int i=0; i<dataList.size(); i++) {
                Map<String, Object> dataMap = new HashMap<>();
                Map<String, Object> dataSet = dataList.get(i);

                dataMap.put("orderNo", dataSet.get("chuban"));
                dataMap.put("ankenId", dataSet.get("ankenId"));
                dataMap.put("rirekiId", 0);
                dataMap.put("dataKbn", "M");
                dataMap.put("syuekiYm", dataSet.get("syuekiYm"));
                dataMap.put("categoryCode", categoryMstInfo.get("CATEGORY_CODE"));
                dataMap.put("categoryKbn1", categoryMstInfo.get("CATEGORY_KBN1"));
                dataMap.put("categoryKbn2", categoryMstInfo.get("CATEGORY_KBN2"));
                dataMap.put("categoryName1", categoryMstInfo.get("CATEGORY_NAME1"));
                dataMap.put("categoryName2", categoryMstInfo.get("CATEGORY_NAME2"));
                dataMap.put("categorySeq", categoryMstInfo.get("CATEGORY_SEQ"));
                dataMap.put("net", Utils.changeBigDecimal((String)dataSet.get("chunyuAmount")));

                mikomiUploadBean.addDataList(dataMap);
            }
            
            return true;
        }

        return false;
    }

    /**
     * シート上の年月をチェック<br>
     * 取得した年月はMap(年月, 年月列位置)で取得する。
     */
    private Map<String, Integer> getCheckYm(Sheet sheet) {
        Map<String, Integer> ymMap = new HashMap<>();
        Row row;

        int errorRow;

        String orderNo;

        // エラーメッセージ
        String monthBeforeError = MikomiUploadLabel.getValue(MikomiUploadLabel.monthBeforeError);
        String monthFormatError = MikomiUploadLabel.getValue(MikomiUploadLabel.monthFormatError);
        
        // Excelを行ループしてデータ取得
        // 行ループを行い年月を取得
        for (int cnt = DATA_START_ROW; cnt<=sheet.getLastRowNum(); cnt++) {
            row = PoiUtil.getRow(sheet, cnt);
            if (row == null) {
                continue;
            }

            orderNo = Utils.getObjToStrValue(PoiUtil.getCellValue(row, 2));

            String beforeMonth = "";

            if (StringUtils.isNotEmpty(orderNo) && orderNo.equals("代表注番")) {
                ////////// 日付データの取得 ///////////
                // 列ループ
                for ( int cnt2 = 7; cnt2 <= 100; cnt2++ ) {
                    Cell dateCell = PoiUtil.getCell(row, cnt2);
                    String rawData = Utils.getObjToStrValue(PoiUtil.getCellValue(dateCell));

                    // 日付セルが計算式の場合はスルー
                    if (dateCell.getCellType() == Cell.CELL_TYPE_FORMULA) {
                        continue;
                    }
                    
                    if (rawData == null) {
                        mikomiUploadErrorBean.addErrorMessage(monthBeforeError);
                        break;
                    }

                    if(rawData.equals("案件合計")){
                        break;
                    }

                    String dataMonth = convCellValToDate(rawData, beforeMonth);

                    // 日付エラーチェック
                    if (dataMonth.equals("noUpdate")) {
                        continue;
                    } else if (dataMonth.equals(monthBeforeError) || dataMonth.equals(monthFormatError)) {
                        errorRow = row.getRowNum() + 1;
                        mikomiUploadErrorBean.addErrorMessage(rawData + "(" + errorRow + ")行目" + "：" + dataMonth + "(" + rawData + ")");
                    } else {
                        beforeMonth = dataMonth;
                        ymMap.put(rawData, cnt2);
                    }
                }

                break;
            }
        }
        
        return ymMap;
    }
        
    /**
     * セルの日付データの読込み
     * @param cellValue
     * @return
     */
    private String convCellValToDate(String cellValue, String beforeMonth) {
        String retStr;
        String BeforeFormMonthError = "noUpdate";

        if (StringUtils.isEmpty(cellValue)) {
            return null;
        }

        try {
            retStr = cellValue;
            retStr = Utils.convertToHankaku(retStr);
            retStr = StringUtils.replace(retStr, "/", "");
/*
            if (retStr.matches(".*実績.*")) {
                retStr = BeforeFormMonthError;
                return retStr;
            }
*/
            if (retStr.endsWith("年1Q計画")
                    || retStr.endsWith("年2Q計画")
                    || retStr.endsWith("年3Q計画")
                ) {
                retStr = StringUtils.replace(retStr, "年1Q計画", "06");
                retStr = StringUtils.replace(retStr, "年2Q計画", "09");
                retStr = StringUtils.replace(retStr, "年3Q計画", "12");
 
            } else if( retStr.endsWith("年4Q計画")
                    || retStr.endsWith("年計画")
                    || retStr.endsWith("年度実績")) {
                retStr = StringUtils.replace(retStr, "～", "");
                retStr = StringUtils.replace(retStr, "年4Q計画", "");
                retStr = StringUtils.replace(retStr, "年計画", "");
                retStr = StringUtils.replace(retStr, "年度実績", "");
                retStr = String.valueOf(Integer.parseInt(retStr) + 1);
                retStr = retStr + "03";
            } else if (retStr.matches(".*実績.*")) {
                retStr = BeforeFormMonthError;
                return retStr;
            }
            
            Date date = UploadUtil.changeStrToDate(retStr);
            retStr = UploadUtil.changeDateToStr(date);
            
            // セルの年月が画面で指定した開始年月より前であれば読み飛ばす。
            Date startYm = mikomiUploadBean.getStartYm();
            if (date.before(startYm)) {
                retStr = BeforeFormMonthError;
                return retStr;
            }

            // 取得した年月が前のセルより前年月(時系列になっていない)場合はエラーとする。
            if (StringUtil.isNotEmpty(beforeMonth)) {
                Date beforeDate = Utils.parseDate(beforeMonth);
                if (date.before(beforeDate)) {
                    retStr = MikomiUploadLabel.getValue(MikomiUploadLabel.monthBeforeError);
                }
            }

        } catch (Exception e) {
            retStr = MikomiUploadLabel.getValue(MikomiUploadLabel.monthFormatError);
        }

        return retStr;
    }

    private String changeAmountStr(String str) {
        String amount = str;

        logger.info("amount=" + amount + " isNum=" + Utils.isNumeric(amount));

        if (!Utils.isNumeric(amount)) {
            return "formatError";
        } else {
            BigDecimal dAmount = Utils.changeBigDecimal(amount);
            if (dAmount != null) {
                amount = dAmount.setScale(3, BigDecimal.ROUND_HALF_UP).multiply(new BigDecimal(1000000)).toString();
                amount = UploadUtil.changeAmountStrSub(amount);
                if (StringUtils.length(amount) > 16) {
                    return "ketaOverError";
                }
            }
        }

        return amount;
    }

/*
    private String changeAmountStrSub(String amount) {
        if (StringUtils.isEmpty(amount)) {
            return null;
        }

        String checkAmount = amount;
        checkAmount = StringUtils.replace(checkAmount, "-", "");
        int point = checkAmount.lastIndexOf('.');
        if (point > 0) {
            checkAmount = StringUtils.substring(checkAmount, 0, point);
        }

        return checkAmount;
    }
*/
}
