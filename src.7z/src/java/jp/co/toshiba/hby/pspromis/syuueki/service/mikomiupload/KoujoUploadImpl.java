/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package jp.co.toshiba.hby.pspromis.syuueki.service.mikomiupload;

import java.math.BigDecimal;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.ejb.Stateless;
import javax.inject.Inject;
import javax.interceptor.Interceptors;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import jp.co.toshiba.hby.pspromis.common.util.StringUtil;
import jp.co.toshiba.hby.pspromis.syuueki.bean.MikomiUploadBean;
import jp.co.toshiba.hby.pspromis.syuueki.bean.MikomiUploadErrorBean;
import jp.co.toshiba.hby.pspromis.syuueki.entity.SyuGeBukkenInfoTbl;
import jp.co.toshiba.hby.pspromis.syuueki.enums.MikomiUploadLabel;
import jp.co.toshiba.hby.pspromis.syuueki.interceptor.TranceInterceptor;
import jp.co.toshiba.hby.pspromis.syuueki.util.PoiUtil;
import jp.co.toshiba.hby.pspromis.syuueki.util.Utils;
import org.apache.commons.lang3.StringUtils;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * PS-Promis収益管理システム
 * 見込アップロード処理「工場（京浜）(府)（浜）(三)」
 * @author (NPC)K.Sano
 */
@Stateless
@Interceptors({TranceInterceptor.class})
public class KoujoUploadImpl implements UploadComponent {

    @PersistenceContext(unitName = jp.co.toshiba.hby.pspromis.syuueki.util.ConstantString.syuuekiDataSourceName)
    private EntityManager em;
    
    /**
     * ロガー
     */
    public static final Logger logger = LoggerFactory.getLogger(KoujoUploadImpl.class);
    
    @Inject
    private MikomiUploadBean mikomiUploadBean;
    
    @Inject
    private MikomiUploadErrorBean mikomiUploadErrorBean;

    @Inject
    private UploadDataAccess uploadDataAccess;
    
    /**
     * 処理対象ワークシートの取得
     */
    private Sheet getTargetSheet() {
        Sheet sheet = (mikomiUploadBean.getWorkBook()).getSheetAt(1);
        return sheet;
    }
    
    /**
     * 入力内容のデータチェック
     * @return 
     * @throws java.lang.Exception
     */
    @Override
    public boolean isDataCheck() throws Exception {
        logger.info("kojo isDataCheck");
        
        boolean isCheck;
        
        // 作業対象シートを取得
        Sheet targetSheet = getTargetSheet();

        // Excelのタイトル(工場名)チェック
        isCheck = isCheckTitile(targetSheet);

        if (isCheck) {
            // Excel上の一覧を読み取って、DBに登録する値の取得/エラーチェックを行う。
            isCheck = exeGetData(targetSheet);
        }

        // beanに成功/失敗FLGをセット
        mikomiUploadErrorBean.setIsSuccess(isCheck);

        return isCheck;
    }

    /**
     * アップロード処理の実行
     * @throws java.lang.Exception
     */
    @Override
    public void executeUpload() throws Exception {
        logger.info("kojo executeUpload");
        
        // データの登録
        List<Map<String, Object>> dataList = mikomiUploadBean.getDataList();
        
        if (dataList == null) {
            return;
        }

        // データを登録
        String ankenId = "";
        String befAnkenId = "";

        for (Map<String, Object> data : dataList) {
            ankenId = (String)data.get("ankenId");
            
            // SYU_KI_NET_CATE_TITLE_TBLの新規登録
            if (!befAnkenId.equals(ankenId)) {
                uploadDataAccess.insertKiNetCateTitleTbl(data);
                
                // 指定案件に対して再計算FLGを立てる(進行基準画面の再計算ボタン用)。
                uploadDataAccess.setSaikeisanFlg(ankenId, (Integer)data.get("rirekiId"));
            }

            // SYU_KI_NET_CATE_TUKI_TBLの更新(or新規登録)
            uploadDataAccess.updateKiNetCateTukiTbl(data);
            
            befAnkenId = ankenId;
        }
    }

    /**
     * Excelのタイトルチェック(京浜,府などのタイトルと画面指定のファイル区分一致のチェック)
     */
    private boolean isCheckTitile(Sheet sheet) {
        String errorMessage = MikomiUploadLabel.getValue(MikomiUploadLabel.titleFormatError);
        
        Cell titleCell = PoiUtil.getCell(sheet, 0, 8);

        String title = (String)PoiUtil.getCellValue(titleCell);
        String trimTitle;

        boolean isSuccess = false;

        String kbn = StringUtils.defaultString(mikomiUploadBean.getUploadKbn());
        
        if (!StringUtil.isEmpty(title)) {
            trimTitle = StringUtils.trim(title);
            trimTitle = StringUtils.replace(trimTitle, "（", "(");
            trimTitle = StringUtils.replace(trimTitle, "）", ")");

            if (trimTitle.indexOf("(京浜)") >= 0 && kbn.equals("00")) {
                isSuccess = true;
            } else if (trimTitle.indexOf("(府)") >= 0 && kbn.equals("01")) {
                isSuccess = true;
            } else if (trimTitle.indexOf("(浜)") >= 0 && kbn.equals("02")) {
                isSuccess = true;
            } else if (trimTitle.indexOf("(三)") >= 0 && kbn.equals("03")) {
                isSuccess = true;
            }
        }
 
        if (!isSuccess) {
            mikomiUploadErrorBean.addErrorMessage(errorMessage);
        }

        return isSuccess;
    }

    /**
     * Excel上の一覧を読み取って、DBに登録する値の取得/エラーチェックを行う
     */
    private boolean exeGetData(Sheet sheet) throws Exception {
        boolean isSuccess = true;
        Row row;
        int errorRow;
        
        String orderNoTitle;
        String daihyoLabel;
        String cellOrderNo;
        
        String orderNo;
        String ankenId;

        String ankenFlg;
        
        SyuGeBukkenInfoTbl bukkenEn;
        Map<String, Object> categoryMstInfo = null;
 
        // エラーメッセージ
        String monthBeforeError = MikomiUploadLabel.getValue(MikomiUploadLabel.monthBeforeError);
        String monthFormatError = MikomiUploadLabel.getValue(MikomiUploadLabel.monthFormatError);
        
        String amount;
        boolean isAmount;
        String seibanSAmount;
        boolean isSeibanSAmount;

        // Excelを行ループしてデータ取得
        for (int cnt=7; cnt <= sheet.getLastRowNum(); cnt++) {
            row = PoiUtil.getRow(sheet, cnt);

            if (row == null) {
                continue;
            }

            // 対象行の注番値、"注番"タイトル，代表注番の判定文字列 を取得
            //orderNo = Utils.getObjToStrValue(PoiUtil.getCellValue(row, 5));
            cellOrderNo = Utils.getObjToStrValue(PoiUtil.getCellValue(row, 5));
            orderNoTitle = Utils.getObjToStrValue(PoiUtil.getCellValue(row, 2));
            daihyoLabel = Utils.getObjToStrValue(PoiUtil.getCellValue(row, 6));

            //logger.info(cnt + "行目 orderNo=" + orderNo + " daihyoLabel=" + daihyoLabel + " orderNoTitle=" + orderNoTitle);
            
            if (StringUtil.isEmpty(cellOrderNo) || cellOrderNo.equals("SKIP")) {
                continue;
            }

            if (daihyoLabel.equals("代表")) {
                ankenFlg = "1";
            } else {
                ankenFlg = "0";
            }

            // 注番行の場合
            if (!orderNoTitle.equals("注番")) {
                continue;
            }

            if (!UploadUtil.isTargetOrderNo(cellOrderNo)) {
                continue;
            }
            
            // 注番より収益物件TBLを検索し、案件情報を取得
            bukkenEn = uploadDataAccess.findOnoBuken(cellOrderNo, ankenFlg);
            if (bukkenEn == null || !bukkenEn.getDivisionCode().equals(mikomiUploadBean.getUploadDivisionCode())) {
                isSuccess = false;
                errorRow = row.getRowNum() + 1;
                mikomiUploadErrorBean.addErrorMessage("(" + errorRow + ")行目：" + MikomiUploadLabel.getValue(MikomiUploadLabel.projectError) + "(" + cellOrderNo + ")");

                continue;
            }

            // 対象注番の年月行を読み込み
            String bforeMonth = "";
            cnt = cnt + 1;
            row = PoiUtil.getRow(sheet, cnt);

            // 正常終了時のため、結果子画面に出力するメッセージ(案件番号/注番)を登録
            orderNo = ankenFlg.equals("1") ? bukkenEn.getMainOrderNo() : bukkenEn.getOrderNo();
            ankenId = bukkenEn.getAnkenId();

            mikomiUploadErrorBean.addMessage("■" + ankenId + "/" + orderNo);
            
            for (int cnt2 = 5; cnt2 <= 100; cnt2++) {
                // 更新データを入れ込むMapを生成
                Map<String, Object> dataMap = new HashMap<>();

                // 日付セルが計算式の場合はスルー
                Cell dateCell = PoiUtil.getCell(row, cnt2);
                if (dateCell.getCellType() == Cell.CELL_TYPE_FORMULA) {
                    continue;
                }

                // 日付取得
                String cellVal = Utils.getObjToStrValue(PoiUtil.getCellValue(row, cnt2));

                // 合計行なら終了
		if (StringUtils.isEmpty(cellVal) || cellVal.equals("合計")){
                    break;
                }

                String dataMonth = convCellValToDate(cellVal, bforeMonth);
                if (dataMonth.equals("noUpdate")) {
                    continue;
                }

		// 日付エラーチェック
		if (dataMonth.equals(monthBeforeError) || dataMonth.equals(monthFormatError)) {
                    isSuccess = false;
                    errorRow = row.getRowNum() + 1;
                    mikomiUploadErrorBean.addErrorMessage(cellOrderNo + "(" + errorRow + ")行目" + "：" + cellVal + "：" + dataMonth + "(" + cellVal + ")");
                } else {
                    bforeMonth = dataMonth;
		}

                // 注入金額取得
                int cellint = cnt + 2;
                Row row2 = PoiUtil.getRow(sheet, cellint);
                String chunyuAmount = Utils.getObjToStrValue(PoiUtil.getCellValue(row2, cnt2));
                
                // 注入金額チェック
                isAmount = true;
                amount = changeAmountStr(chunyuAmount);
                if ("formatError".equals(amount)) {
                    isSuccess = false;
                    isAmount = false;
                    errorRow = row2.getRowNum() + 1;
                    mikomiUploadErrorBean.addErrorMessage(cellOrderNo + "(" + errorRow + ")行目"+"：" + cellVal + "：" + MikomiUploadLabel.getValue(MikomiUploadLabel.chunyuAmountFormatError) + "(" + chunyuAmount + ")");

                } else if ("ketaOverError".equals(amount)) {
                    isSuccess = false;
                    isAmount = false;
                    errorRow = row2.getRowNum() + 1;
                    mikomiUploadErrorBean.addErrorMessage(cellOrderNo + "(" + errorRow + ")行目" + "：" +cellVal + "：" + MikomiUploadLabel.getValue(MikomiUploadLabel.chunyuAmountKetaFormatError) + "(" + chunyuAmount + ")");
                }
                
                // 製番損益額取得
                cellint = cellint + 2;
                row2 = PoiUtil.getRow(sheet, cellint);
                String seibanSonekiAmount = Utils.getObjToStrValue(PoiUtil.getCellValue(row2, cnt2));
                
                // 製番損益チェック
                isSeibanSAmount = true;
                seibanSAmount = changeAmountStr(seibanSonekiAmount);
                if ("formatError".equals(seibanSAmount)) {
                    isSuccess = false;
                    isSeibanSAmount = false;
                    errorRow = row2.getRowNum() + 1;
                    mikomiUploadErrorBean.addErrorMessage(cellOrderNo + "(" + errorRow + ")行目"+"：" + cellVal + "：" + MikomiUploadLabel.getValue(MikomiUploadLabel.seibanAmountFormatError) + "(" + seibanSonekiAmount + ")");

                } else if ("ketaOverError".equals(seibanSAmount)) {
                    isSuccess = false;
                    isSeibanSAmount = false;
                    errorRow = row2.getRowNum() + 1;
                    mikomiUploadErrorBean.addErrorMessage(cellOrderNo + "(" + errorRow + ")行目" + "：" +cellVal + "：" + MikomiUploadLabel.getValue(MikomiUploadLabel.seibanAmountKetaFormatError) + "(" + seibanSonekiAmount + ")");
                }

                // カテゴリマスタからCATEGORY_CODE,CATEGORY_CODE1,CATEGORY_CODE2等を取得(1回のみ)
                if (categoryMstInfo == null) {
                    categoryMstInfo = uploadDataAccess.categoryMstInfo(getCategoryKbn());
                }

                // 登録対象のデータをセット
                //dataMap.put("orderNo", orderNo);
                dataMap.put("ankenId", bukkenEn.getAnkenId());
                dataMap.put("rirekiId", 0);
                dataMap.put("dataKbn", "M");
                dataMap.put("syuekiYm", dataMonth);
                dataMap.put("categoryCode", categoryMstInfo.get("CATEGORY_CODE"));
                dataMap.put("categoryKbn1", categoryMstInfo.get("CATEGORY_KBN1"));
                dataMap.put("categoryKbn2", categoryMstInfo.get("CATEGORY_KBN2"));
                dataMap.put("categoryName1", categoryMstInfo.get("CATEGORY_NAME1"));
                dataMap.put("categoryName2", categoryMstInfo.get("CATEGORY_NAME2"));
                dataMap.put("categorySeq", categoryMstInfo.get("CATEGORY_SEQ"));
                if (isAmount) {
                    dataMap.put("net", Utils.changeBigDecimal(amount));
                }
                if (isSeibanSAmount) {
                    dataMap.put("seibanSonekiNet", Utils.changeBigDecimal(seibanSAmount));
                }
                mikomiUploadBean.addDataList(dataMap);
            }
            
        }

        return isSuccess;
    }

    /**
     * 工場のカテゴリ区分を取得
     */
    private String getCategoryKbn() {
        // 画面で選択したファイル種別区分を取得
        String kbn = StringUtils.defaultString(mikomiUploadBean.getUploadKbn());
        
        String categoryKbn = "";
        
        if (kbn.equals("00")) {
            categoryKbn = "67";
        } else if (kbn.equals("01")) {
            categoryKbn = "62";
        } else if (kbn.equals("02")) {
            categoryKbn = "63";
        } else if (kbn.equals("03")) {
            categoryKbn = "76";
        }

        return categoryKbn;
    }
    
    
    /**
     * セルの日付データの読込み
     * @param cellValue
     * @return
     */
    private String convCellValToDate(String cellValue, String beforeMonth) {
        String retStr;
        String BeforeFormMonthError = "noUpdate";
		
        if (StringUtils.isEmpty(cellValue)) {
            return null;
        }

        try {
            retStr = cellValue;
            retStr = Utils.convertToHankaku(retStr);
            retStr = StringUtils.replace(retStr, "/", "");

            if (retStr.matches(".*実績.*")) {
                retStr = BeforeFormMonthError;
                return retStr;
            }

            retStr = Utils.convertToHankaku(retStr);

            if (retStr.endsWith("年下期")
                    || retStr.endsWith("下以前")
                    || retStr.endsWith("年度～")
                    || retStr.endsWith("下期")
                    || retStr.endsWith("年度")
                    || retStr.endsWith("～")
                    || retStr.endsWith("4Q")
                ) {
		retStr = UploadUtil.nenAdd1(retStr);
                retStr = StringUtils.replace(retStr, "年下期", "03");
                retStr = StringUtils.replace(retStr, "下以前", "03");
                retStr = StringUtils.replace(retStr, "年度～", "03");
                retStr = StringUtils.replace(retStr, "下期", "03");
		retStr = StringUtils.replace(retStr, "年度", "03");
                retStr = StringUtils.replace(retStr, "～", "03");
                retStr = StringUtils.replace(retStr, "4Q", "03");
            }

            if (retStr.startsWith("～") && retStr.endsWith("上")) {
                retStr = StringUtils.replace(retStr, "～", "");
                retStr = StringUtils.replace(retStr, "上", "09");

            } else if (retStr.startsWith("～") && retStr.endsWith("下")) {
                String nen = retStr.substring(1, 3);
                String nenHan = nen;
                nenHan = String.valueOf(Integer.parseInt(nenHan) + 1);
                retStr = StringUtils.replace(retStr, nen, nenHan);
                
                retStr = StringUtils.replace(retStr, "～", "");
                retStr = StringUtils.replace(retStr, "下", "03");
			
            } else if (retStr.endsWith("1Q")) {
		retStr = StringUtils.replace(retStr, "1Q", "06");
				
            } else if (retStr.endsWith("2Q")) {	
		retStr = StringUtils.replace(retStr, "2Q", "09");

            } else if (retStr.endsWith("3Q")) {
                retStr = StringUtils.replace(retStr, "3Q", "12");

            } else if (retStr.endsWith("年上期")) {
		retStr = StringUtils.replace(retStr, "年上期", "09");
				
            } else if (retStr.endsWith("上期")) {
		retStr = StringUtils.replace(retStr, "上期", "09");

            } else if (retStr.endsWith("上以前")) {
		retStr = StringUtils.replace(retStr, "上以前", "09");

            }

            Date date = UploadUtil.changeStrToDate(retStr);
            retStr = UploadUtil.changeDateToStr(date);

            // セルの年月が画面で指定した開始年月より前であれば読み飛ばす。
            Date startYm = mikomiUploadBean.getStartYm();
            if (date.before(startYm)) {
                retStr = BeforeFormMonthError;
                return retStr;
            }

            // 取得した年月が前のセルより前年月(時系列になっていない)場合はエラーとする。
            if (StringUtil.isNotEmpty(beforeMonth)) {
                Date beforeDate = Utils.parseDate(beforeMonth);
                if (date.before(beforeDate)) {
                    retStr = MikomiUploadLabel.getValue(MikomiUploadLabel.monthBeforeError);
                }
            }

	} catch (Exception e) {
            retStr = MikomiUploadLabel.getValue(MikomiUploadLabel.monthFormatError);
	}

	return retStr;
    }

    private String changeAmountStr(String str) {
        String amount = str;

        if (!Utils.isNumeric(amount)) {
            return "formatError";
        } else {
            BigDecimal dAmount = Utils.changeBigDecimal(amount);
            if (dAmount != null) {
                amount = dAmount.setScale(3, BigDecimal.ROUND_HALF_UP).multiply(new BigDecimal(1000)).toString();
                amount = UploadUtil.changeAmountStrSub(amount);
                if (StringUtils.length(amount) > 13) {
                    return "ketaOverError";
		}
            }
        }
        
        return amount;
    }

}
