package jp.co.toshiba.hby.pspromis.syuueki.validation;

import java.util.Map;
import jp.co.toshiba.hby.pspromis.syuueki.bean.S013Bean;
import jp.co.toshiba.hby.pspromis.syuueki.bean.ValidationInfoBean;
import jp.co.toshiba.hby.pspromis.syuueki.enums.Label;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 *
 * @author ibayashi
 */
public class S013Validation extends AbstractValidation<S013Bean> {
    public static final Logger logger = LoggerFactory.getLogger(S013Validation.class);
    
    /**
     * コンストラクタ
     */
    public S013Validation(S013Bean bean) {
        super(bean);
    }

    /**
     * 検索処理時のバリデーション
     */
    public void execListValidation(ValidationInfoBean vBean) {
        annotationValidate();
        
        Map<String, String> messages = getValidateMessagess();
        S013Bean bean = getBean();
        String message;

        boolean isFixedYmFrom = true;
        boolean isFixedYmTo = true;
        
        //// 独自チェック
        // 確定月from
        isFixedYmFrom = isValidYm(bean.getFixedYmFrom());
        // 確定月to
        isFixedYmTo = isValidYm(bean.getFixedYmTo());
        if (!isFixedYmFrom || !isFixedYmTo) {
            message = StringUtils.replace(getValidationMessage("ymError"), "{0}", Label.getValue(Label.fixedYm));
            messages.put("fixedYm", message);
        }

        vBean.setMessages(messages);
    }
}
