package jp.co.toshiba.hby.pspromis.syuueki.service;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.inject.Inject;
import javax.interceptor.Interceptors;
import jp.co.toshiba.hby.pspromis.common.exception.PspRunTimeExceotion;
import jp.co.toshiba.hby.pspromis.common.util.StringUtil;
import jp.co.toshiba.hby.pspromis.syuueki.bean.S002Bean;
import jp.co.toshiba.hby.pspromis.syuueki.entity.CategoryHanchokuList;
import jp.co.toshiba.hby.pspromis.syuueki.entity.CostList;
import jp.co.toshiba.hby.pspromis.syuueki.entity.CurrencyRateList;
import jp.co.toshiba.hby.pspromis.syuueki.entity.IspDivisionList;
import jp.co.toshiba.hby.pspromis.syuueki.entity.ProductSonekiList;
import jp.co.toshiba.hby.pspromis.syuueki.entity.SonekiList;
import jp.co.toshiba.hby.pspromis.syuueki.entity.SyuGeBukkenInfoTbl;
import jp.co.toshiba.hby.pspromis.syuueki.entity.KaisyuList;
import jp.co.toshiba.hby.pspromis.syuueki.entity.OperationLog;
import jp.co.toshiba.hby.pspromis.syuueki.entity.TeamEntity;
import jp.co.toshiba.hby.pspromis.syuueki.enums.Label;
import jp.co.toshiba.hby.pspromis.syuueki.enums.ScreenMode;
import jp.co.toshiba.hby.pspromis.syuueki.facade.CategoryHanchokuListFacade;
import jp.co.toshiba.hby.pspromis.syuueki.facade.ContractAmountListFacade;
import jp.co.toshiba.hby.pspromis.syuueki.facade.CostListFacade;
import jp.co.toshiba.hby.pspromis.syuueki.facade.CurrencyRateListFacade;
import jp.co.toshiba.hby.pspromis.syuueki.facade.ProductSonekiListFacade;
import jp.co.toshiba.hby.pspromis.syuueki.facade.S002Facade;
import jp.co.toshiba.hby.pspromis.syuueki.facade.SonekiListFacade;
import jp.co.toshiba.hby.pspromis.syuueki.facade.SyuGeBukenInfoTblFacade;
import jp.co.toshiba.hby.pspromis.syuueki.facade.SyuuekiFlgFacade;
//import jp.co.toshiba.hby.pspromis.syuueki.facade.TeamMstFacade;
import jp.co.toshiba.hby.pspromis.syuueki.interceptor.TranceInterceptor;
import jp.co.toshiba.hby.pspromis.syuueki.pages.DetailHeader;
import jp.co.toshiba.hby.pspromis.syuueki.pages.DivisonComponentPage;
import jp.co.toshiba.hby.pspromis.syuueki.util.EntityUtils;
import jp.co.toshiba.hby.pspromis.syuueki.util.LoginUserInfo;
import jp.co.toshiba.hby.pspromis.syuueki.util.SyuuekiUtils;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import jp.co.toshiba.hby.pspromis.syuueki.entity.SyuSaSpCurTbl;
import jp.co.toshiba.hby.pspromis.syuueki.entity.SyuSaNetCateTbl;
import jp.co.toshiba.hby.pspromis.syuueki.entity.SyuSaHanCateTbl;
import jp.co.toshiba.hby.pspromis.syuueki.entity.SyuSaSonekiTitleTbl;
import jp.co.toshiba.hby.pspromis.syuueki.facade.SyuSaHanCateTblFacade;
import jp.co.toshiba.hby.pspromis.syuueki.facade.SyuSaNetCateTblFacade;
import jp.co.toshiba.hby.pspromis.syuueki.facade.SyuSaSonekiTitleTblFacade;
import jp.co.toshiba.hby.pspromis.syuueki.facade.SyuSaSpCurTblFacade;
import jp.co.toshiba.hby.pspromis.syuueki.util.NumberUtils;
import jp.co.toshiba.hby.pspromis.syuueki.util.AuthorityUtils;
import jp.co.toshiba.hby.pspromis.syuueki.util.ConstantString;
import jp.co.toshiba.hby.pspromis.syuueki.facade.AnkenSyokusyuRoleTblFacade;
import jp.co.toshiba.hby.pspromis.syuueki.facade.SyuKiBikouFacade;
import jp.co.toshiba.hby.pspromis.syuueki.entity.SyuKiBikou;
import jp.co.toshiba.hby.pspromis.syuueki.enums.Env;
import jp.co.toshiba.hby.pspromis.syuueki.util.DateUtils;
//import lombok.val;

/**
 * PS-Promis収益管理システム 最終見込損益 Service
 *
 * @author (NPC)K.Sano
 */
@Stateless
@Interceptors({TranceInterceptor.class})
public class S002Service {

    /**
     * ロガー
     */
    public static final Logger logger = LoggerFactory.getLogger(S002Service.class);

    /**
     * パラメータ格納クラスをinjection(CDI)<br>
     * InjectアノテーションよりAPサーバー(Glassfish)側で自動的にインスタンス作成(new)される。<br>
     */
    @Inject
    private S002Bean s002Bean;

    /**
     * Injection DetailHeader
     */
    @Inject
    private DetailHeader detailHeader;

    /**
     * Injection currencyRateListFacade
     */
    @Inject
    private CurrencyRateListFacade currencyRateListFacade;
    /**
     * Injection syuuekiFlgFacade
     */
    @Inject
    private SyuuekiFlgFacade syuuekiFlgFacade;

    /**
     * Injection contractAmountListFacade
     */
    @Inject
    private ContractAmountListFacade contractAmountListFacade;

    /**
     * Injection costListFacade
     */
    @Inject
    private CostListFacade costListFacade;

    /**
     * Injection sonekiListFacade
     */
    @Inject
    private SonekiListFacade sonekiListFacade;

    //@Inject
    //private TeamMstFacade teamMstFacade;

    /**
     * Injection productSonekiListFacade
     */
    @Inject
    private ProductSonekiListFacade productSonekiListFacade;
    /**
     * Injection syuGeBukenInfoTblFacade
     */
    @Inject
    private SyuGeBukenInfoTblFacade syuGeBukenInfoTblFacade;
    /**
     * Injection categoryHanchokuListFacade
     */
    @Inject
    private CategoryHanchokuListFacade categoryHanchokuListFacade;

    /**
     * Injection SyuuekiUtils
     */
    @Inject
    private SyuuekiUtils sUtils;

    @Inject
    private S002Facade s002Facade;

    @Inject
    private LoginUserInfo loginUserInfo;

    @Inject
    private SyuSaHanCateTblFacade syuSaHanCateTblFacade;
    @Inject
    private SyuSaNetCateTblFacade syuSaNetCateTblFacade;
//    @Inject
//    private SyuSaSeibansonekiTblFacade syuSaSeibansonekiTblFacade;
    @Inject
    private SyuSaSonekiTitleTblFacade syuSaSonekiTitleTblFacade;
    @Inject
    private SyuSaSpCurTblFacade syuSaSpCurTblFacade;
//    @Inject
//    private JgrpMemberTblFacade jgrpMemberTblFacade;
    @Inject
    private OperationLogService operationLogService;
    @Inject
    private AnkenSyokusyuRoleTblFacade ankenSyokusyuRoleTblFacade;
    @Inject
    private SyuKiBikouFacade syuKiBikouFacade;
    @Inject
    private StoredProceduresService storedProceduresService;
    @Inject
    private AuthorityUtils authorityUtils;
    @Inject
    private DivisonComponentPage divisionComponentPage;
    @Inject
    private SyuuekiCommonService syuuekiCommonService;

    /**
     * インスタンス変数を全て初期化 (本当はstatress
     * serviceでインスタンス変数利用したくないが、今から修正は工数かかるためクリアすることで対応
     */
    private void initInstanceValue() {
//        this.currencyRateList = null;
//        this.totalContractAmount = null;
//        this.totalCost = null;
//        this.costList = null;
//        this.sonekiList = null;
//        this.productSonekiList = null;
//        this.categoryHanchokuList = null;
        logger.info("all instance clear");
    }

    /**
     * 一覧表示　ビジネスロジック
     *
     * @throws Exception
     */
    @TransactionAttribute(TransactionAttributeType.NOT_SUPPORTED)
    public void indexExecute() throws Exception {
        logger.error("S002Service#indexExecute");
        logger.error("jpyUnit=" + s002Bean.getJpyUnit());

        // ヘッダー情報(案件基本情報 等)の取得
        editDispHeader();
        
        // 検索条件セット
        Map<String, Object> paramMap = getCondition();

        int cnt = syuuekiFlgFacade.getSyokusyuRole(paramMap);
        if (cnt == 0) {
            // 収益管理対象外
            String errorMessage = Label.getValue(Label.alertNoSyuueki);
            logger.error(errorMessage);
            throw new PspRunTimeExceotion(errorMessage);
        }
        // 主管課
        String anken = ankenSyokusyuRoleTblFacade.getDeptName(paramMap);
        s002Bean.setDeptName(StringUtils.defaultString(anken));

        // レート表の情報を取得
        List<CurrencyRateList> currencyRateList = currencyRateListFacade.findList(paramMap);
        s002Bean.setCurrencyRateList(currencyRateList);

        // 契約金額合計の情報を取得
        CurrencyRateList totalContractAmount = contractAmountListFacade.findTotalList(paramMap);

        // 売上原価合計の情報を取得
        CostList totalCost = costListFacade.findTotalList(paramMap);

        // 売上原価一覧の情報を取得
        List<CostList> costList = costListFacade.findList(paramMap);

        // 損益表を取得
        SonekiList sonekiList = sonekiListFacade.findList(paramMap);

        // 工場別製番損益表を取得
        List<ProductSonekiList> productSonekiList = productSonekiListFacade.findList(paramMap);

        // 工場別製番損益表を取得
        List<CategoryHanchokuList> categoryHanchokuList = categoryHanchokuListFacade.findList(paramMap);

        // 粗利の計算
        this.calcArari(totalContractAmount, totalCost);

        // M率の計算
        this.calcMrate(totalContractAmount, totalCost);

        // 経常損益の計算
        this.calcOrdinary(sonekiList);

        // ROSの計算
        this.calcRos(sonekiList, totalContractAmount);

        // 回収
        kaisyuAmount(paramMap);

        // 関連案件
        // *SALES_CLASS→ANKEN_FLG→ISP_KBNの順にチェック
        if (s002Bean.getSalesClass().equals(ConstantString.salesClassS)) {
            // 進行基準案件のまとめ案件
            if (s002Bean.getAnkenFlg().equals("1")) {
                setMatomeChildAnkenList(paramMap);
            }

            // 進行基準案件の子案件
            if (s002Bean.getAnkenFlg().equals("0")) {
                setParentMatomeAnkenInfo();
            }
        } else if (s002Bean.getSalesClass().equals(ConstantString.salesClassI)) {
            // 他事業部ＩＳＰ案件の自事業部案件
            if ((s002Bean.getAnkenFlg().equals("0")) && (s002Bean.getIspKbn().equals(ConstantString.ispKbn1))) {
                setIspDivisionList();
            }
        }

        this.switchingUnit(totalContractAmount, totalCost, currencyRateList, costList, productSonekiList, sonekiList, categoryHanchokuList);

        HashMap<String, String> bikoFlg = setBikoFlg();
        s002Bean.setBikoFlg((bikoFlg));
    }

    /**
     * 検索条件の取得
     */
    private Map<String, Object> getCondition() {
        Map<String, Object> paramMap = new HashMap<>();
        paramMap.put("ankenId", s002Bean.getAnkenId());
        paramMap.put("rirekiId", (new Integer(s002Bean.getRirekiId())));
        paramMap.put("calcDiffFlg", s002Bean.getCalcDiffFlg());
        paramMap.put("rirekiFlg", s002Bean.getRirekiFlg());
        paramMap.put("zenkaiRirekiId", s002Bean.getZenkaiRirekiId());
        return paramMap;
    }

    /**
     * 検索条件の取得
     *
     * @param ankenId
     * @param rirekiId
     * @return
     */
    private Map<String, Object> getCondition(String ankenId, String rirekiId) {
        return getCondition(ankenId, rirekiId, false);
    }

    /**
     * 検索条件の取得
     *
     * @param ankenId
     * @param rirekiId
     * @param ankenFlg
     * @return
     */
    private Map<String, Object> getCondition(String ankenId, String rirekiId, boolean ankenFlg) {
        Map<String, Object> paramMap = new HashMap<>();
        paramMap.put("ankenId", ankenId);
        paramMap.put("rirekiId", Integer.parseInt(rirekiId));
        paramMap.put("calcDiffFlg", s002Bean.getCalcDiffFlg());
        paramMap.put("rirekiFlg", s002Bean.getRirekiFlg());
        //        List<String> memberJobGrList = jgrpMemberTblFacade.getMemberJobGrList(loginUserInfo.getUserId());
        //        paramMap.put("memberJobGr", memberJobGrList);
        if (!ankenFlg) {
            SyuGeBukkenInfoTbl ankenEntity = syuGeBukenInfoTblFacade.findPk(paramMap);
            // 前回履歴IDを取得
            if (!ConstantString.geRirekiId.equals(StringUtils.defaultString(String.valueOf(ankenEntity.getZenkaiId()), ConstantString.geRirekiId))) {
                String zenkaiId = String.valueOf(ankenEntity.getZenkaiId());
                paramMap.put("zenkaiRirekiId", zenkaiId);
            }
        } else {
            paramMap.put("zenkaiRirekiId", "");
        }
        return paramMap;
    }
    
    /**
     * ヘッダー情報関連の取得処理
     */
    private void editDispHeader() {
        initInstanceValue();
        
        // 円貨はデフォルト1(円)とする。
        //if (s002Bean.getJpyUnit() == null) {
        if (s002Bean.getJpyUnit() == null) {
            s002Bean.setJpyUnit(1);
        }
        // 差分はデフォルト今回値-前回値とする
        //if (s002Bean.getCalcDiffFlg() == null) {
        if (StringUtils.isEmpty(s002Bean.getCalcDiffFlg())) {
            s002Bean.setCalcDiffFlg("6");
        }
        //if (s002Bean.getAnkenId()==null || s002Bean.getAnkenId().equals("") ){
        if (StringUtils.isEmpty(s002Bean.getAnkenId())) {
            s002Bean.setAnkenId(s002Bean.getAnkenMatomeId());
        }

        logger.error("flg=" + s002Bean.getRirekiFlg());
        // 物件基本情報を取得(ヘッダ部＋履歴管理・備考部＋勘定月の取得)
        detailHeader.setAnkenId(s002Bean.getAnkenId());
        detailHeader.setRirekiId(s002Bean.getRirekiId());
        detailHeader.setRirekiFlg(s002Bean.getRirekiFlg());
        detailHeader.setId("S002");
        detailHeader.findPk();
        logger.error("end");

        ////// 「最終見込 前回値」の関連情報を取得
//        Map<String, Object> zenkaiCondition = getCondition(s002Bean.getAnkenId(), s002Bean.getRirekiId());
        String zenkaiRirekiId = s002Bean.getZenkaiRirekiId();
        if (StringUtils.isEmpty(zenkaiRirekiId)) {
            zenkaiRirekiId = detailHeader.getZenkaiId();
        }
        if (StringUtils.isNotEmpty(zenkaiRirekiId)) {
            logger.info("前回履歴情報の取得 ankenId=[{}], zenkaiId=[{}]", s002Bean.getAnkenId(), zenkaiRirekiId);
            Map<String, Object> zenkaiCondition = new HashMap<>();
            zenkaiCondition.put("ankenId", s002Bean.getAnkenId());
            zenkaiCondition.put("rirekiId", Integer.parseInt(zenkaiRirekiId));

            SyuGeBukkenInfoTbl zenkaiEntity = syuGeBukenInfoTblFacade.findZenkaiRirekiInfo(zenkaiCondition);
            if (zenkaiEntity != null) {
                s002Bean.setZenkaiKanjyoYm(zenkaiEntity.getKanjoYm());
            }
        }
        s002Bean.setZenkaiRirekiId(zenkaiRirekiId);

        setEditFlg();

        // リストの全表示設定
        if (StringUtils.isEmpty(s002Bean.getSpListOpenFlg())) {
            s002Bean.setSpListOpenFlg("1");
        }
        if (StringUtils.isEmpty(s002Bean.getNetListOpenFlg())) {
            s002Bean.setNetListOpenFlg("1");
        }
        if (StringUtils.isEmpty(s002Bean.getKeihiListOpenFlg())) {
            if (s002Bean.getScreenMode().equals(ScreenMode.READ.getValue())) {
                s002Bean.setKeihiListOpenFlg("0");
            } else {
                s002Bean.setKeihiListOpenFlg("1");
            }
        }
        if (StringUtils.isEmpty(s002Bean.getEigyogaiSonekiListOpenFlg())) {
            if (s002Bean.getScreenMode().equals(ScreenMode.READ.getValue())) {
                s002Bean.setEigyogaiSonekiListOpenFlg("0");
            } else {
                s002Bean.setEigyogaiSonekiListOpenFlg("1");
            }
        }
        // 廃止？
//        if (StringUtils.isEmpty(s002Bean.getSonekiListOpenFlg())) {
//            if (s002Bean.getScreenMode().equals(ScreenMode.READ.getValue())) {
//                s002Bean.setSonekiListOpenFlg("0");
//            } else {
//                s002Bean.setSonekiListOpenFlg("1");
//            }
//        }
//        if (StringUtils.isEmpty(s002Bean.getHanchokuListOpenFlg())) {
//            if (s002Bean.getScreenMode().equals(ScreenMode.READ.getValue())) {
//                s002Bean.setHanchokuListOpenFlg("0");
//            } else {
//                s002Bean.setHanchokuListOpenFlg("1");
//            }
//        }
        s002Bean.setBikouOpenFlg("0");  // 備考欄はデフォルト最小化でいい？

        s002Bean.setSalesClass(StringUtils.defaultString(detailHeader.getAnkenEntity().getSalesClass()));
        s002Bean.setAnkenFlg(StringUtils.defaultString(detailHeader.getAnkenEntity().getAnkenFlg()));
        s002Bean.setIspKbn(StringUtils.defaultString(detailHeader.getAnkenEntity().getIspKbn()));
        s002Bean.setPotentialFlg(StringUtils.defaultString(detailHeader.getAnkenEntity().getPotentialFlg()));
    }

    /**
     * データ編集可否FLGを取得
     */
    private void setEditFlg() {
        String editBtnFlg = "0";
        String editNetFlg = "0";
        String saisyuUpdeteBtnFlg = "0";

        SyuGeBukkenInfoTbl geEntity = detailHeader.getAnkenEntity();
        
        // 事業部:原子力か？
        boolean isNuclearDivision = divisionComponentPage.isNuclearDivision(geEntity.getDivisionCode());

        // ログイン者の権限を取得
        //List<TeamEntity> teamMstList = teamMstFacade.findUserTeamList(loginUserInfo.getUserId());
        //boolean isEdit = loginUserInfo.isAnkenEdit(geEntity, teamMstList);
        boolean isEdit = syuuekiCommonService.isAnkenEditOk(geEntity);
        
        // ログイン者が対象案件の権限がある場合
        if (isEdit) {
            //////// 編集ボタン権限(S)
            if (isNuclearDivision && ConstantString.salesClassS.equals(geEntity.getSalesClass())) {
                //// 原子力＋進行基準案件
                if (!"1".equals(geEntity.getAnkenFlg())) {
                    // 子案件の場合は利用可能
                    editBtnFlg = "1";
                }
            } else {
                //// 上記以外の案件の場合
                if ("1".equals(geEntity.getInputAnkenFlg())) {
                    // 案件の編集可能設定をしている場合に利用可能
                    editBtnFlg = "1";
                }
            }
            //////// 編集ボタン権限(E)
            
            //////// 最新値更新ボタン権限(S)
//            if (!ConstantString.salesClassS.equals(geEntity.getSalesClass())) {
//                //// 進行基準案件でない場合(一般案件の場合)利用可能
//                saisyuUpdeteBtnFlg = "1";
//            }
            
            if (ConstantString.salesClassS.equals(geEntity.getSalesClass())) {
                //// 進行基準案件(基本は利用不可)
                if (isNuclearDivision && !"1".equals(geEntity.getAnkenFlg())) {
                    // 原子力+子案件の場合、利用可能
                    saisyuUpdeteBtnFlg = "1";
                }
            } else {
                //// 進行基準案件でない場合(一般案件の場合)利用可能
                saisyuUpdeteBtnFlg = "1";
            }
            //////// 最新値更新ボタン権限(E)
        }
        
        // 　(1)　権限マスタ（KENGEN_MST)で設定された制御に基づいて，［編集］ボタンやその他編集機能のボタンを表示する
        // 　(2)　NET以外の項目の編集制御
        // (1)の権限で常に編集可能
        //　(3)　NETカテゴリの各項目の編集制御
        // 案件詳細画面で設定された見込入力単位のNET最終見込が「カテゴリ」の場合は編集可
        if (s002Bean.isEdit()) {
//            if ((StringUtil.isNotBlank(detailHeader.getAnkenEntity().getInputSaNetFlg())
//                    && (detailHeader.getAnkenEntity().getInputSaNetFlg().equals("1")))) {
            editNetFlg = "1";
//            }
        }

        s002Bean.setEditBtnFlg(editBtnFlg);
        s002Bean.setSaisyuUpdeteBtnFlg(saisyuUpdeteBtnFlg);
        s002Bean.setEditNetFlg(editNetFlg);
    }

    /**
     * 粗利の計算
     */
    private void calcArari(CurrencyRateList totalContractAmount, CostList totalCost) {
        // 受政
        s002Bean.setArariJs(sUtils.exeFormatUnit(sUtils.switchingCurrencyUnit(sUtils.arari(totalContractAmount.getKeiyakuAmountJs(), totalCost.getUriageNetJs()), s002Bean.getJpyUnit())));
        // 受注
        s002Bean.setArariJt(sUtils.exeFormatUnit(sUtils.switchingCurrencyUnit(sUtils.arari(totalContractAmount.getKeiyakuAmountJt(), totalCost.getUriageNetJt()), s002Bean.getJpyUnit())));
        // 目標
        s002Bean.setArariMh(sUtils.exeFormatUnit(sUtils.switchingCurrencyUnit(sUtils.arari(totalContractAmount.getKeiyakuAmountMh(), totalCost.getUriageNetMh()), s002Bean.getJpyUnit())));
        // 最新見積
        s002Bean.setArariSm(sUtils.exeFormatUnit(sUtils.switchingCurrencyUnit(sUtils.arari(totalContractAmount.getKeiyakuAmountSm(), totalCost.getUriageNetSm()), s002Bean.getJpyUnit())));
        // 査定
        s002Bean.setArariSt(sUtils.exeFormatUnit(sUtils.switchingCurrencyUnit(sUtils.arari(totalContractAmount.getKeiyakuAmountSt(), totalCost.getUriageNetSt()), s002Bean.getJpyUnit())));
        // 発番
        s002Bean.setArariHb(sUtils.exeFormatUnit(sUtils.switchingCurrencyUnit(sUtils.arari(totalContractAmount.getKeiyakuAmountHb(), totalCost.getUriageNetHb()), s002Bean.getJpyUnit())));
        // 注入累計
        s002Bean.setArariTr(sUtils.exeFormatUnit(sUtils.switchingCurrencyUnit(sUtils.arari(totalContractAmount.getKeiyakuAmountTr(), totalCost.getUriageNetTr()), s002Bean.getJpyUnit())));
        // 最終見込
        s002Bean.setArariFm(sUtils.exeFormatUnit(sUtils.switchingCurrencyUnit(sUtils.arari(totalContractAmount.getKeiyakuAmountFm(), totalCost.getUriageNetFm()), s002Bean.getJpyUnit())));
        // 差分
        s002Bean.setArariDiff(sUtils.exeFormatUnit(sUtils.switchingCurrencyUnit(sUtils.arari(totalContractAmount.getKeiyakuAmountDiff(), totalCost.getUriageNetDiff()), s002Bean.getJpyUnit())));
        // 見込_大
        s002Bean.setArariPd(sUtils.exeFormatUnit(sUtils.switchingCurrencyUnit(sUtils.arari(totalContractAmount.getKeiyakuAmountPd(), totalCost.getUriageNetPd()), s002Bean.getJpyUnit())));
        // 見込_中
        s002Bean.setArariPt(sUtils.exeFormatUnit(sUtils.switchingCurrencyUnit(sUtils.arari(totalContractAmount.getKeiyakuAmountPt(), totalCost.getUriageNetPt()), s002Bean.getJpyUnit())));
        // 見込_小
        s002Bean.setArariPs(sUtils.exeFormatUnit(sUtils.switchingCurrencyUnit(sUtils.arari(totalContractAmount.getKeiyakuAmountPs(), totalCost.getUriageNetPs()), s002Bean.getJpyUnit())));
        // 見込_前回値
        s002Bean.setArariPrev(sUtils.exeFormatUnit(sUtils.switchingCurrencyUnit(sUtils.arari(totalContractAmount.getKeiyakuAmountPrev(), totalCost.getUriageNetPrev()), s002Bean.getJpyUnit())));
    }

    /**
     * M率の計算
     */
    private void calcMrate(CurrencyRateList totalContractAmount, CostList totalCost) {
        // 受政
        s002Bean.setMrateJs(sUtils.mrate(totalContractAmount.getKeiyakuAmountJs(), totalCost.getUriageNetJs()));
        // 受注
        s002Bean.setMrateJt(sUtils.mrate(totalContractAmount.getKeiyakuAmountJt(), totalCost.getUriageNetJt()));
        // 目標
        s002Bean.setMrateMh(sUtils.mrate(totalContractAmount.getKeiyakuAmountMh(), totalCost.getUriageNetMh()));
        // 最新見積
        s002Bean.setMrateSm(sUtils.mrate(totalContractAmount.getKeiyakuAmountSm(), totalCost.getUriageNetSm()));
        // 査定
        s002Bean.setMrateSt(sUtils.mrate(totalContractAmount.getKeiyakuAmountSt(), totalCost.getUriageNetSt()));
        // 発番
        s002Bean.setMrateHb(sUtils.mrate(totalContractAmount.getKeiyakuAmountHb(), totalCost.getUriageNetHb()));
        // 注入累計
        s002Bean.setMrateTr(sUtils.mrate(totalContractAmount.getKeiyakuAmountTr(), totalCost.getUriageNetTr()));
        // 最終見込
        s002Bean.setMrateFm(sUtils.mrate(totalContractAmount.getKeiyakuAmountFm(), totalCost.getUriageNetFm()));
        // 差分
        s002Bean.setMrateDiff(sUtils.mrate(totalContractAmount.getKeiyakuAmountDiff(), totalCost.getUriageNetDiff()));
        // 見込_大
        s002Bean.setMratePd(sUtils.mrate(totalContractAmount.getKeiyakuAmountPd(), totalCost.getUriageNetPd()));
        // 見込_中
        s002Bean.setMratePt(sUtils.mrate(totalContractAmount.getKeiyakuAmountPt(), totalCost.getUriageNetPt()));
        // 見込_小
        s002Bean.setMratePs(sUtils.mrate(totalContractAmount.getKeiyakuAmountPs(), totalCost.getUriageNetPs()));
        // 見込_前回値
        s002Bean.setMratePrev(sUtils.mrate(totalContractAmount.getKeiyakuAmountPrev(), totalCost.getUriageNetPrev()));
    }

    /**
     * 経常損益の計算
     */
    private void calcOrdinary(SonekiList sonekiList) {
        // 受政
        s002Bean.setOrdinaryJs(sUtils.exeFormatUnit(sUtils.switchingCurrencyUnit(sonekiList.getKeijousonekinetJs(), s002Bean.getJpyUnit())));
        // 受注
        s002Bean.setOrdinaryJt(sUtils.exeFormatUnit(sUtils.switchingCurrencyUnit(sonekiList.getKeijousonekinetJt(), s002Bean.getJpyUnit())));
        // 目標
        s002Bean.setOrdinaryMh(sUtils.exeFormatUnit(sUtils.switchingCurrencyUnit(sonekiList.getKeijousonekinetMh(), s002Bean.getJpyUnit())));
        // 最新見積
        s002Bean.setOrdinarySm(sUtils.exeFormatUnit(sUtils.switchingCurrencyUnit(sonekiList.getKeijousonekinetSm(), s002Bean.getJpyUnit())));
        // 査定
        s002Bean.setOrdinarySt(sUtils.exeFormatUnit(sUtils.switchingCurrencyUnit(sonekiList.getKeijousonekinetSt(), s002Bean.getJpyUnit())));
        // 発番
        s002Bean.setOrdinaryHb(sUtils.exeFormatUnit(sUtils.switchingCurrencyUnit(sonekiList.getKeijousonekinetHb(), s002Bean.getJpyUnit())));
        // 注入累計
        s002Bean.setOrdinaryTr(sUtils.exeFormatUnit(sUtils.switchingCurrencyUnit(sonekiList.getKeijousonekinetTr(), s002Bean.getJpyUnit())));
        // 最終見込
        s002Bean.setOrdinaryFm(sUtils.exeFormatUnit(sUtils.switchingCurrencyUnit(sonekiList.getKeijousonekinetFm(), s002Bean.getJpyUnit())));
        // 差分
        s002Bean.setOrdinaryDiff(sUtils.exeFormatUnit(sUtils.switchingCurrencyUnit(sonekiList.getKeijousonekinetDiff(), s002Bean.getJpyUnit())));
        // 見込_大
        s002Bean.setOrdinaryPd(sUtils.exeFormatUnit(sUtils.switchingCurrencyUnit(sonekiList.getKeijousonekinetPd(), s002Bean.getJpyUnit())));
        // 見込_中
        s002Bean.setOrdinaryPt(sUtils.exeFormatUnit(sUtils.switchingCurrencyUnit(sonekiList.getKeijousonekinetPt(), s002Bean.getJpyUnit())));
        // 見込_小
        s002Bean.setOrdinaryPs(sUtils.exeFormatUnit(sUtils.switchingCurrencyUnit(sonekiList.getKeijousonekinetPs(), s002Bean.getJpyUnit())));
        // 見込_前回値
        s002Bean.setOrdinaryPrev(sUtils.exeFormatUnit(sUtils.switchingCurrencyUnit(sonekiList.getKeijousonekinetPrev(), s002Bean.getJpyUnit())));
    }

    /**
     * Rosの計算
     */
    private void calcRos(SonekiList sonekiList, CurrencyRateList totalContractAmount) {
        // 受政
        if (s002Bean.getOrdinaryJs() != null) {
            s002Bean.setRosJs(sUtils.mrate(sonekiList.getKeijousonekinetJs(), totalContractAmount.getKeiyakuAmountJs()));
        }
        // 受注
        if (s002Bean.getOrdinaryJt() != null) {
            s002Bean.setRosJt(sUtils.mrate(sonekiList.getKeijousonekinetJt(), totalContractAmount.getKeiyakuAmountJt()));
        }
        // 目標
        if (s002Bean.getOrdinaryMh() != null) {
            s002Bean.setRosMh(sUtils.mrate(sonekiList.getKeijousonekinetMh(), totalContractAmount.getKeiyakuAmountMh()));
        }
        // 最新見積
        if (s002Bean.getOrdinarySm() != null) {
            s002Bean.setRosSm(sUtils.mrate(sonekiList.getKeijousonekinetSm(), totalContractAmount.getKeiyakuAmountSm()));
        }
        // 査定
        if (s002Bean.getOrdinarySt() != null) {
            s002Bean.setRosSt(sUtils.mrate(sonekiList.getKeijousonekinetSt(), totalContractAmount.getKeiyakuAmountSt()));
        }
        // 発番
        if (s002Bean.getOrdinaryHb() != null) {
            s002Bean.setRosHb(sUtils.mrate(sonekiList.getKeijousonekinetHb(), totalContractAmount.getKeiyakuAmountHb()));
        }
        // 注入累計
        if (s002Bean.getOrdinaryTr() != null) {
            s002Bean.setRosTr(sUtils.mrate(sonekiList.getKeijousonekinetTr(), totalContractAmount.getKeiyakuAmountTr()));
        }
        // 最終見込
        if (s002Bean.getOrdinaryFm() != null) {
            s002Bean.setRosFm(sUtils.mrate(sonekiList.getKeijousonekinetFm(), totalContractAmount.getKeiyakuAmountFm()));
        }
        // 差分
        if (s002Bean.getOrdinaryDiff() != null) {
            s002Bean.setRosDiff(sUtils.mrate(sonekiList.getKeijousonekinetDiff(), totalContractAmount.getKeiyakuAmountDiff()));
        }
        // 見込_大
        if (s002Bean.getOrdinaryPd() != null) {
            s002Bean.setRosPd(sUtils.mrate(sonekiList.getKeijousonekinetPd(), totalContractAmount.getKeiyakuAmountPd()));
        }
        // 見込_中
        if (s002Bean.getOrdinaryPt() != null) {
            s002Bean.setRosPt(sUtils.mrate(sonekiList.getKeijousonekinetPt(), totalContractAmount.getKeiyakuAmountPt()));
        }
        // 見込_小
        if (s002Bean.getOrdinaryPs() != null) {
            s002Bean.setRosPs(sUtils.mrate(sonekiList.getKeijousonekinetPs(), totalContractAmount.getKeiyakuAmountPs()));
        }
        // 見込_前回値
        if (s002Bean.getOrdinaryPrev() != null) {
            s002Bean.setRosPrev(sUtils.mrate(sonekiList.getKeijousonekinetPrev(), totalContractAmount.getKeiyakuAmountPrev()));
        }
    }

    /**
     * 進行基準案件のまとめ案件<br>
     * まとめ案件に紐付されている子案件の一覧を取得
     */
    private void setMatomeChildAnkenList(final Map<String, Object> condition) {
        logger.info("まとめ案件に紐付されている子案件の一覧を取得");

        s002Bean.setMatomeParentFlg(false);
        Map<String, Object> paramMap = new HashMap<>(condition);

        List<SyuGeBukkenInfoTbl> syuGeBukkenInfoTblList = syuGeBukenInfoTblFacade.findChildAnken(paramMap);

        // 取れなければ以降は処理しない
        if (CollectionUtils.isNotEmpty(syuGeBukkenInfoTblList)) {
            ArrayList<HashMap<String, String>> list = new ArrayList<>();

            String[] ankenAry = new String[syuGeBukkenInfoTblList.size()];
            for (int i = 0; i < syuGeBukkenInfoTblList.size(); i++) {
                ankenAry[i] = syuGeBukkenInfoTblList.get(i).getAnkenId();

                HashMap<String, String> map = new HashMap<>();
                map.put("ankenId", syuGeBukkenInfoTblList.get(i).getAnkenId());
                map.put("ankenRev", String.valueOf(syuGeBukkenInfoTblList.get(i).getAnkenRev()));
                map.put("rirekiId", String.valueOf(syuGeBukkenInfoTblList.get(i).getRirekiId()));
                map.put("orderNo", syuGeBukkenInfoTblList.get(i).getOrderNo());
                map.put("ankenName", syuGeBukkenInfoTblList.get(i).getAnkenName());
                list.add(map);
            }
            paramMap.put("ankenId", ankenAry);

            if (CollectionUtils.isNotEmpty(list)) {
                // 契約金額合計の情報を取得
                List<CurrencyRateList> childContractAmount = contractAmountListFacade.findChildTotalList(paramMap);
                // 売上原価合計の情報を取得
                List<CostList> childCost = costListFacade.findChildTotalList(paramMap);

                for (Map<String, String> data: list) {
                    // 契約金額合計の情報を一覧データに追加
                    if (CollectionUtils.isNotEmpty(childContractAmount)) {
                        for (int i=0; i<childContractAmount.size(); i++) {
                            if ((data.get("ankenId")).equals(childContractAmount.get(i).getAnkenId())) {
                                data.put("keiyakuAmountFm", sUtils.exeFormatUnit(sUtils.switchingCurrencyUnit(childContractAmount.get(i).getKeiyakuAmountFm(), s002Bean.getJpyUnit())));
                                //list.get(i).put("keiyakuAmountFm", sUtils.exeFormatUnit(sUtils.switchingCurrencyUnit(childContractAmount.get(i).getKeiyakuAmountFm(), s002Bean.getJpyUnit())));
                            }
                        }
                    }

                    // 売上原価合計の情報を取得を一覧データに追加
                    if (CollectionUtils.isNotEmpty(childCost)) {
                        for (int i=0; i<childCost.size(); i++) {
                            if ((data.get("ankenId")).equals(childCost.get(i).getAnkenId())) {
                                data.put("uriageNetHb", sUtils.exeFormatUnit(sUtils.switchingCurrencyUnit(childCost.get(i).getUriageNetHb(), s002Bean.getJpyUnit())));
                                data.put("uriageNetFm", sUtils.exeFormatUnit(sUtils.switchingCurrencyUnit(childCost.get(i).getUriageNetFm(), s002Bean.getJpyUnit())));
                            }
                        }
                    }

                    // 粗利、M率
                    String keiyakuAmountFm = StringUtils.defaultString(data.get("keiyakuAmountFm")).replace(",", "");
                    BigDecimal bigKeiyakuAmountFm = null;
                    if (StringUtils.isNotEmpty(keiyakuAmountFm)) {
                        bigKeiyakuAmountFm = new BigDecimal(keiyakuAmountFm);
                    }

                    String uriageNetFm = StringUtils.defaultString(data.get("uriageNetFm")).replace(",", "");
                    BigDecimal bigUriageNetFm = null;
                    if (StringUtils.isNotEmpty(uriageNetFm)) {
                        bigUriageNetFm = new BigDecimal(uriageNetFm);
                    }

                    BigDecimal arari = sUtils.arari(bigKeiyakuAmountFm, bigUriageNetFm);
//                    data.put("arari", sUtils.exeFormatUnit(sUtils.switchingCurrencyUnit(arari, s002Bean.getJpyUnit()))); //2017/05/08 修正
                    data.put("arari", sUtils.exeFormatUnit(arari));
                    data.put("mrate", sUtils.mrate(bigKeiyakuAmountFm, bigUriageNetFm));

                }

            }

//            // 契約金額合計の情報を取得
//            List<CurrencyRateList> childContractAmount = contractAmountListFacade.findChildTotalList(paramMap);
//            if (childContractAmount != null && childContractAmount.size() > 0) {
//                //if (CollectionUtils.isNotEmpty(childContractAmount)) {
//                for (int i = 0; i < childContractAmount.size(); i++) {
//                    if (((String) list.get(i).get("ankenId")).equals(childContractAmount.get(i).getAnkenId())) {
//                        list.get(i).put("keiyakuAmountFm", sUtils.exeFormatUnit(sUtils.switchingCurrencyUnit(childContractAmount.get(i).getKeiyakuAmountFm(), s002Bean.getJpyUnit())));
//                    }
//                }
//            }
//            // 売上原価合計の情報を取得
//            List<CostList> childCost = costListFacade.findChildTotalList(paramMap);
//            if (childCost != null && childCost.size() > 0) {
//                //if (CollectionUtils.isNotEmpty(childCost)){
//                for (int i = 0; i < childCost.size(); i++) {
//                    if (((String) list.get(i).get("ankenId")).equals(childCost.get(i).getAnkenId())) {
//                        list.get(i).put("uriageNetHb", sUtils.exeFormatUnit(sUtils.switchingCurrencyUnit(childCost.get(i).getUriageNetHb(), s002Bean.getJpyUnit())));
//                        list.get(i).put("uriageNetFm", sUtils.exeFormatUnit(sUtils.switchingCurrencyUnit(childCost.get(i).getUriageNetFm(), s002Bean.getJpyUnit())));
//                    }
//                }
//            }

//            // 粗利、M率
//            BigDecimal arari = null;
//            for (int i = 0; i < list.size(); i++) {
//                if (list.get(i).get("keiyakuAmountFm") != null && list.get(i).get("uriageNetFm") != null) {
//                    arari = sUtils.arari(new BigDecimal(list.get(i).get("keiyakuAmountFm").replace(",", "")), new BigDecimal(list.get(i).get("uriageNetFm").replace(",", "")));
//                    list.get(i).put("arari", sUtils.exeFormatUnit(sUtils.switchingCurrencyUnit(arari, s002Bean.getJpyUnit())));
//                    list.get(i).put("mrate", sUtils.mrate(new BigDecimal(list.get(i).get("keiyakuAmountFm").replace(",", "")), new BigDecimal(list.get(i).get("uriageNetFm").replace(",", ""))));
//                }
//            }

            logger.info("matomeChildAnkenList Count=[{}]", list.size());
            this.s002Bean.setChildAnkenList(list);
            s002Bean.setMatomeParentFlg(true);
        }
    }

    /**
     * 進行基準案件の子案件<br>
     * 対象案件の親となるまとめ案件情報を取得
     */
    private void setParentMatomeAnkenInfo() {
        logger.info("親となるまとめ案件情報を取得 ankenMatomeNo=[{}]", detailHeader.getAnkenEntity().getAnkenMatomeNo());

        s002Bean.setMatomeChildFlg(false);
        if (StringUtils.isEmpty(detailHeader.getAnkenEntity().getAnkenMatomeNo())) {
            return;
        }

        this.s002Bean.setAnkenMatomeNo(detailHeader.getAnkenEntity().getAnkenMatomeNo());
        this.s002Bean.setAnkenMatomeOrderNo(detailHeader.getAnkenEntity().getMainOrderNo());
        Map<String, Object> paramMap = getCondition(detailHeader.getAnkenEntity().getAnkenMatomeNo(), s002Bean.getRirekiId(), true);

        // 契約金額合計の情報を取得
        CurrencyRateList parentContractAmount = contractAmountListFacade.findTotalList(paramMap);
        // 売上原価合計の情報を取得
        CostList parentCost = costListFacade.findTotalList(paramMap);
        // 損益表を取得
        SonekiList parentSonekiList = sonekiListFacade.findList(paramMap);

//        SyuGeBukkenInfoTbl ankenEntity = syuGeBukenInfoTblFacade.findPk(paramMap);
//        s002Bean.setParentPotentialFlg(ankenEntity.getPotentialFlg());
        s002Bean.setParentPotentialFlg("0");

        HashMap<String, String> map = new HashMap<>();
        // 契約金額の設定
        if (parentContractAmount != null) {
            map.put("keiyakuAmountJs", sUtils.exeFormatUnit(sUtils.switchingCurrencyUnit(parentContractAmount.getKeiyakuAmountJs(), s002Bean.getJpyUnit())));
            map.put("keiyakuAmountJt", sUtils.exeFormatUnit(sUtils.switchingCurrencyUnit(parentContractAmount.getKeiyakuAmountJt(), s002Bean.getJpyUnit())));
            map.put("keiyakuAmountMh", sUtils.exeFormatUnit(sUtils.switchingCurrencyUnit(parentContractAmount.getKeiyakuAmountMh(), s002Bean.getJpyUnit())));
            map.put("keiyakuAmountSm", sUtils.exeFormatUnit(sUtils.switchingCurrencyUnit(parentContractAmount.getKeiyakuAmountSm(), s002Bean.getJpyUnit())));
            map.put("keiyakuAmountSt", sUtils.exeFormatUnit(sUtils.switchingCurrencyUnit(parentContractAmount.getKeiyakuAmountSt(), s002Bean.getJpyUnit())));
            map.put("keiyakuAmountHb", sUtils.exeFormatUnit(sUtils.switchingCurrencyUnit(parentContractAmount.getKeiyakuAmountHb(), s002Bean.getJpyUnit())));
            map.put("keiyakuAmountTr", sUtils.exeFormatUnit(sUtils.switchingCurrencyUnit(parentContractAmount.getKeiyakuAmountTr(), s002Bean.getJpyUnit())));
            map.put("keiyakuAmountFm", sUtils.exeFormatUnit(sUtils.switchingCurrencyUnit(parentContractAmount.getKeiyakuAmountFm(), s002Bean.getJpyUnit())));
            map.put("keiyakuAmountDiff", sUtils.exeFormatUnit(sUtils.switchingCurrencyUnit(parentContractAmount.getKeiyakuAmountDiff(), s002Bean.getJpyUnit())));
            map.put("keiyakuAmountPd", sUtils.exeFormatUnit(sUtils.switchingCurrencyUnit(parentContractAmount.getKeiyakuAmountPd(), s002Bean.getJpyUnit())));
            map.put("keiyakuAmountPt", sUtils.exeFormatUnit(sUtils.switchingCurrencyUnit(parentContractAmount.getKeiyakuAmountPt(), s002Bean.getJpyUnit())));
            map.put("keiyakuAmountPs", sUtils.exeFormatUnit(sUtils.switchingCurrencyUnit(parentContractAmount.getKeiyakuAmountPs(), s002Bean.getJpyUnit())));
            map.put("keiyakuAmountPrev", sUtils.exeFormatUnit(sUtils.switchingCurrencyUnit(parentContractAmount.getKeiyakuAmountPrev(), s002Bean.getJpyUnit())));
        }

        // 売上原価の設定
        if (parentCost != null) {
            map.put("uriageNetJs", sUtils.exeFormatUnit(sUtils.switchingCurrencyUnit(parentCost.getUriageNetJs(), s002Bean.getJpyUnit())));
            map.put("uriageNetJt", sUtils.exeFormatUnit(sUtils.switchingCurrencyUnit(parentCost.getUriageNetJt(), s002Bean.getJpyUnit())));
            map.put("uriageNetMh", sUtils.exeFormatUnit(sUtils.switchingCurrencyUnit(parentCost.getUriageNetMh(), s002Bean.getJpyUnit())));
            map.put("uriageNetSm", sUtils.exeFormatUnit(sUtils.switchingCurrencyUnit(parentCost.getUriageNetSm(), s002Bean.getJpyUnit())));
            map.put("uriageNetSt", sUtils.exeFormatUnit(sUtils.switchingCurrencyUnit(parentCost.getUriageNetSt(), s002Bean.getJpyUnit())));
            map.put("uriageNetHb", sUtils.exeFormatUnit(sUtils.switchingCurrencyUnit(parentCost.getUriageNetHb(), s002Bean.getJpyUnit())));
            map.put("uriageNetTr", sUtils.exeFormatUnit(sUtils.switchingCurrencyUnit(parentCost.getUriageNetTr(), s002Bean.getJpyUnit())));
            map.put("uriageNetFm", sUtils.exeFormatUnit(sUtils.switchingCurrencyUnit(parentCost.getUriageNetFm(), s002Bean.getJpyUnit())));
            map.put("uriageNetDiff", sUtils.exeFormatUnit(sUtils.switchingCurrencyUnit(parentCost.getUriageNetDiff(), s002Bean.getJpyUnit())));
            map.put("uriageNetPd", sUtils.exeFormatUnit(sUtils.switchingCurrencyUnit(parentCost.getUriageNetPd(), s002Bean.getJpyUnit())));
            map.put("uriageNetPt", sUtils.exeFormatUnit(sUtils.switchingCurrencyUnit(parentCost.getUriageNetPt(), s002Bean.getJpyUnit())));
            map.put("uriageNetPs", sUtils.exeFormatUnit(sUtils.switchingCurrencyUnit(parentCost.getUriageNetPs(), s002Bean.getJpyUnit())));
            map.put("uriageNetPrev", sUtils.exeFormatUnit(sUtils.switchingCurrencyUnit(parentCost.getUriageNetPrev(), s002Bean.getJpyUnit())));
        }

        // 総原価、製番損益の設定
        if (parentSonekiList != null) {
            // 経費
            map.put("keihiNetJs", sUtils.exeFormatUnit(sUtils.switchingCurrencyUnit(parentSonekiList.getKeihiNetJs(), s002Bean.getJpyUnit())));
            map.put("keihiNetJt", sUtils.exeFormatUnit(sUtils.switchingCurrencyUnit(parentSonekiList.getKeihiNetJt(), s002Bean.getJpyUnit())));
            map.put("keihiNetMh", sUtils.exeFormatUnit(sUtils.switchingCurrencyUnit(parentSonekiList.getKeihiNetMh(), s002Bean.getJpyUnit())));
            map.put("keihiNetSm", sUtils.exeFormatUnit(sUtils.switchingCurrencyUnit(parentSonekiList.getKeihiNetSm(), s002Bean.getJpyUnit())));
            map.put("keihiNetSt", sUtils.exeFormatUnit(sUtils.switchingCurrencyUnit(parentSonekiList.getKeihiNetSt(), s002Bean.getJpyUnit())));
            map.put("keihiNetHb", sUtils.exeFormatUnit(sUtils.switchingCurrencyUnit(parentSonekiList.getKeihiNetHb(), s002Bean.getJpyUnit())));
            map.put("keihiNetTr", sUtils.exeFormatUnit(sUtils.switchingCurrencyUnit(parentSonekiList.getKeihiNetTr(), s002Bean.getJpyUnit())));
            map.put("keihiNetFm", sUtils.exeFormatUnit(sUtils.switchingCurrencyUnit(parentSonekiList.getKeihiNetFm(), s002Bean.getJpyUnit())));
            map.put("keihiNetDiff", sUtils.exeFormatUnit(sUtils.switchingCurrencyUnit(parentSonekiList.getKeihiNetDiff(), s002Bean.getJpyUnit())));
            map.put("keihiNetPd", sUtils.exeFormatUnit(sUtils.switchingCurrencyUnit(parentSonekiList.getKeihiNetPd(), s002Bean.getJpyUnit())));
            map.put("keihiNetPt", sUtils.exeFormatUnit(sUtils.switchingCurrencyUnit(parentSonekiList.getKeihiNetPt(), s002Bean.getJpyUnit())));
            map.put("keihiNetPs", sUtils.exeFormatUnit(sUtils.switchingCurrencyUnit(parentSonekiList.getKeihiNetPs(), s002Bean.getJpyUnit())));
            map.put("keihiNetPrev", sUtils.exeFormatUnit(sUtils.switchingCurrencyUnit(parentSonekiList.getKeihiNetPrev(), s002Bean.getJpyUnit())));

            //総原価(NET+経費)
            map.put("sougenkaNetJs", sUtils.exeFormatUnit(sUtils.switchingCurrencyUnit(parentSonekiList.getSougenkaNetJs(), s002Bean.getJpyUnit())));
            map.put("sougenkaNetJt", sUtils.exeFormatUnit(sUtils.switchingCurrencyUnit(parentSonekiList.getSougenkaNetJt(), s002Bean.getJpyUnit())));
            map.put("sougenkaNetMh", sUtils.exeFormatUnit(sUtils.switchingCurrencyUnit(parentSonekiList.getSougenkaNetMh(), s002Bean.getJpyUnit())));
            map.put("sougenkaNetSm", sUtils.exeFormatUnit(sUtils.switchingCurrencyUnit(parentSonekiList.getSougenkaNetSm(), s002Bean.getJpyUnit())));
            map.put("sougenkaNetSt", sUtils.exeFormatUnit(sUtils.switchingCurrencyUnit(parentSonekiList.getSougenkaNetSt(), s002Bean.getJpyUnit())));
            map.put("sougenkaNetHb", sUtils.exeFormatUnit(sUtils.switchingCurrencyUnit(parentSonekiList.getSougenkaNetHb(), s002Bean.getJpyUnit())));
            map.put("sougenkaNetTr", sUtils.exeFormatUnit(sUtils.switchingCurrencyUnit(parentSonekiList.getSougenkaNetTr(), s002Bean.getJpyUnit())));
            map.put("sougenkaNetFm", sUtils.exeFormatUnit(sUtils.switchingCurrencyUnit(parentSonekiList.getSougenkaNetFm(), s002Bean.getJpyUnit())));
            map.put("sougenkaNetDiff", sUtils.exeFormatUnit(sUtils.switchingCurrencyUnit(parentSonekiList.getSougenkaNetDiff(), s002Bean.getJpyUnit())));
            map.put("sougenkaNetPd", sUtils.exeFormatUnit(sUtils.switchingCurrencyUnit(parentSonekiList.getSougenkaNetPd(), s002Bean.getJpyUnit())));
            map.put("sougenkaNetPt", sUtils.exeFormatUnit(sUtils.switchingCurrencyUnit(parentSonekiList.getSougenkaNetPt(), s002Bean.getJpyUnit())));
            map.put("sougenkaNetPs", sUtils.exeFormatUnit(sUtils.switchingCurrencyUnit(parentSonekiList.getSougenkaNetPs(), s002Bean.getJpyUnit())));
            map.put("sougenkaNetPrev", sUtils.exeFormatUnit(sUtils.switchingCurrencyUnit(parentSonekiList.getSougenkaNetPrev(), s002Bean.getJpyUnit())));

            //営業外損益
            map.put("eigyogaiJs", sUtils.exeFormatUnit(sUtils.switchingCurrencyUnit(parentSonekiList.getEigyogaiJs(), s002Bean.getJpyUnit())));
            map.put("eigyogaiJt", sUtils.exeFormatUnit(sUtils.switchingCurrencyUnit(parentSonekiList.getEigyogaiJt(), s002Bean.getJpyUnit())));
            map.put("eigyogaiMh", sUtils.exeFormatUnit(sUtils.switchingCurrencyUnit(parentSonekiList.getEigyogaiMh(), s002Bean.getJpyUnit())));
            map.put("eigyogaiSm", sUtils.exeFormatUnit(sUtils.switchingCurrencyUnit(parentSonekiList.getEigyogaiSm(), s002Bean.getJpyUnit())));
            map.put("eigyogaiSt", sUtils.exeFormatUnit(sUtils.switchingCurrencyUnit(parentSonekiList.getEigyogaiSt(), s002Bean.getJpyUnit())));
            map.put("eigyogaiHb", sUtils.exeFormatUnit(sUtils.switchingCurrencyUnit(parentSonekiList.getEigyogaiHb(), s002Bean.getJpyUnit())));
            map.put("eigyogaiTr", sUtils.exeFormatUnit(sUtils.switchingCurrencyUnit(parentSonekiList.getEigyogaiTr(), s002Bean.getJpyUnit())));
            map.put("eigyogaiFm", sUtils.exeFormatUnit(sUtils.switchingCurrencyUnit(parentSonekiList.getEigyogaiFm(), s002Bean.getJpyUnit())));
            map.put("eigyogaiDiff", sUtils.exeFormatUnit(sUtils.switchingCurrencyUnit(parentSonekiList.getEigyogaiDiff(), s002Bean.getJpyUnit())));
            map.put("eigyogaiPd", sUtils.exeFormatUnit(sUtils.switchingCurrencyUnit(parentSonekiList.getEigyogaiPd(), s002Bean.getJpyUnit())));
            map.put("eigyogaiPt", sUtils.exeFormatUnit(sUtils.switchingCurrencyUnit(parentSonekiList.getEigyogaiPt(), s002Bean.getJpyUnit())));
            map.put("eigyogaiPs", sUtils.exeFormatUnit(sUtils.switchingCurrencyUnit(parentSonekiList.getEigyogaiPs(), s002Bean.getJpyUnit())));
            map.put("eigyogaiPrev", sUtils.exeFormatUnit(sUtils.switchingCurrencyUnit(parentSonekiList.getEigyogaiPrev(), s002Bean.getJpyUnit())));

            // 経常損益合計
            map.put("seibanSonekiNetJs", sUtils.exeFormatUnit(sUtils.switchingCurrencyUnit(parentSonekiList.getKeijousonekinetJs(), s002Bean.getJpyUnit())));
            map.put("seibanSonekiNetJt", sUtils.exeFormatUnit(sUtils.switchingCurrencyUnit(parentSonekiList.getKeijousonekinetJt(), s002Bean.getJpyUnit())));
            map.put("seibanSonekiNetMh", sUtils.exeFormatUnit(sUtils.switchingCurrencyUnit(parentSonekiList.getKeijousonekinetMh(), s002Bean.getJpyUnit())));
            map.put("seibanSonekiNetSm", sUtils.exeFormatUnit(sUtils.switchingCurrencyUnit(parentSonekiList.getKeijousonekinetSm(), s002Bean.getJpyUnit())));
            map.put("seibanSonekiNetSt", sUtils.exeFormatUnit(sUtils.switchingCurrencyUnit(parentSonekiList.getKeijousonekinetSt(), s002Bean.getJpyUnit())));
            map.put("seibanSonekiNetHb", sUtils.exeFormatUnit(sUtils.switchingCurrencyUnit(parentSonekiList.getKeijousonekinetHb(), s002Bean.getJpyUnit())));
            map.put("seibanSonekiNetTr", sUtils.exeFormatUnit(sUtils.switchingCurrencyUnit(parentSonekiList.getKeijousonekinetTr(), s002Bean.getJpyUnit())));
            map.put("seibanSonekiNetFm", sUtils.exeFormatUnit(sUtils.switchingCurrencyUnit(parentSonekiList.getKeijousonekinetFm(), s002Bean.getJpyUnit())));
            map.put("seibanSonekiNetDiff", sUtils.exeFormatUnit(sUtils.switchingCurrencyUnit(parentSonekiList.getKeijousonekinetDiff(), s002Bean.getJpyUnit())));
            map.put("seibanSonekiNetPd", sUtils.exeFormatUnit(sUtils.switchingCurrencyUnit(parentSonekiList.getKeijousonekinetPd(), s002Bean.getJpyUnit())));
            map.put("seibanSonekiNetPt", sUtils.exeFormatUnit(sUtils.switchingCurrencyUnit(parentSonekiList.getKeijousonekinetPt(), s002Bean.getJpyUnit())));
            map.put("seibanSonekiNetPs", sUtils.exeFormatUnit(sUtils.switchingCurrencyUnit(parentSonekiList.getKeijousonekinetPs(), s002Bean.getJpyUnit())));
            map.put("seibanSonekiNetPrev", sUtils.exeFormatUnit(sUtils.switchingCurrencyUnit(parentSonekiList.getKeijousonekinetPrev(), s002Bean.getJpyUnit())));
        }

        // 粗利の計算
        map.put("arariJs", sUtils.exeFormatUnit(sUtils.switchingCurrencyUnit(sUtils.arari(parentContractAmount.getKeiyakuAmountJs(), parentCost.getUriageNetJs()), s002Bean.getJpyUnit())));
        map.put("arariJt", sUtils.exeFormatUnit(sUtils.switchingCurrencyUnit(sUtils.arari(parentContractAmount.getKeiyakuAmountJt(), parentCost.getUriageNetJt()), s002Bean.getJpyUnit())));
        map.put("arariMh", sUtils.exeFormatUnit(sUtils.switchingCurrencyUnit(sUtils.arari(parentContractAmount.getKeiyakuAmountMh(), parentCost.getUriageNetMh()), s002Bean.getJpyUnit())));
        map.put("arariSm", sUtils.exeFormatUnit(sUtils.switchingCurrencyUnit(sUtils.arari(parentContractAmount.getKeiyakuAmountSm(), parentCost.getUriageNetSm()), s002Bean.getJpyUnit())));
        map.put("arariSt", sUtils.exeFormatUnit(sUtils.switchingCurrencyUnit(sUtils.arari(parentContractAmount.getKeiyakuAmountSt(), parentCost.getUriageNetSt()), s002Bean.getJpyUnit())));
        map.put("arariHb", sUtils.exeFormatUnit(sUtils.switchingCurrencyUnit(sUtils.arari(parentContractAmount.getKeiyakuAmountHb(), parentCost.getUriageNetHb()), s002Bean.getJpyUnit())));
        map.put("arariTr", sUtils.exeFormatUnit(sUtils.switchingCurrencyUnit(sUtils.arari(parentContractAmount.getKeiyakuAmountTr(), parentCost.getUriageNetTr()), s002Bean.getJpyUnit())));
        map.put("arariFm", sUtils.exeFormatUnit(sUtils.switchingCurrencyUnit(sUtils.arari(parentContractAmount.getKeiyakuAmountFm(), parentCost.getUriageNetFm()), s002Bean.getJpyUnit())));
        map.put("arariDiff", sUtils.exeFormatUnit(sUtils.switchingCurrencyUnit(sUtils.arari(parentContractAmount.getKeiyakuAmountDiff(), parentCost.getUriageNetDiff()), s002Bean.getJpyUnit())));
        map.put("arariPd", sUtils.exeFormatUnit(sUtils.switchingCurrencyUnit(sUtils.arari(parentContractAmount.getKeiyakuAmountPd(), parentCost.getUriageNetPd()), s002Bean.getJpyUnit())));
        map.put("arariPt", sUtils.exeFormatUnit(sUtils.switchingCurrencyUnit(sUtils.arari(parentContractAmount.getKeiyakuAmountPt(), parentCost.getUriageNetPt()), s002Bean.getJpyUnit())));
        map.put("arariPs", sUtils.exeFormatUnit(sUtils.switchingCurrencyUnit(sUtils.arari(parentContractAmount.getKeiyakuAmountPs(), parentCost.getUriageNetPs()), s002Bean.getJpyUnit())));
        map.put("arariPrev", sUtils.exeFormatUnit(sUtils.switchingCurrencyUnit(sUtils.arari(parentContractAmount.getKeiyakuAmountPrev(), parentCost.getUriageNetPrev()), s002Bean.getJpyUnit())));

        // M率の計算
        map.put("mrateJs", sUtils.mrate(parentContractAmount.getKeiyakuAmountJs(), parentCost.getUriageNetJs()));
        map.put("mrateJt", sUtils.mrate(parentContractAmount.getKeiyakuAmountJt(), parentCost.getUriageNetJt()));
        map.put("mrateMh", sUtils.mrate(parentContractAmount.getKeiyakuAmountMh(), parentCost.getUriageNetMh()));
        map.put("mrateSm", sUtils.mrate(parentContractAmount.getKeiyakuAmountSm(), parentCost.getUriageNetSm()));
        map.put("mrateSt", sUtils.mrate(parentContractAmount.getKeiyakuAmountSt(), parentCost.getUriageNetSt()));
        map.put("mrateHb", sUtils.mrate(parentContractAmount.getKeiyakuAmountHb(), parentCost.getUriageNetHb()));
        map.put("mrateTr", sUtils.mrate(parentContractAmount.getKeiyakuAmountTr(), parentCost.getUriageNetTr()));
        map.put("mrateFm", sUtils.mrate(parentContractAmount.getKeiyakuAmountFm(), parentCost.getUriageNetFm()));
        map.put("mrateDiff", sUtils.mrate(parentContractAmount.getKeiyakuAmountDiff(), parentCost.getUriageNetDiff()));
        map.put("mratePd", sUtils.mrate(parentContractAmount.getKeiyakuAmountPd(), parentCost.getUriageNetPd()));
        map.put("mratePt", sUtils.mrate(parentContractAmount.getKeiyakuAmountPt(), parentCost.getUriageNetPt()));
        map.put("mratePs", sUtils.mrate(parentContractAmount.getKeiyakuAmountPs(), parentCost.getUriageNetPs()));
        map.put("mratePrev", sUtils.mrate(parentContractAmount.getKeiyakuAmountPrev(), parentCost.getUriageNetPrev()));

        // 経常損益とROSの計算
        map.put("rosJs", sUtils.mrate(parentSonekiList.getKeijousonekinetJs(), parentContractAmount.getKeiyakuAmountJs()));
        map.put("rosJt", sUtils.mrate(parentSonekiList.getKeijousonekinetJt(), parentContractAmount.getKeiyakuAmountJt()));
        map.put("rosMh", sUtils.mrate(parentSonekiList.getKeijousonekinetMh(), parentContractAmount.getKeiyakuAmountMh()));
        map.put("rosSm", sUtils.mrate(parentSonekiList.getKeijousonekinetSm(), parentContractAmount.getKeiyakuAmountSm()));
        map.put("rosSt", sUtils.mrate(parentSonekiList.getKeijousonekinetSt(), parentContractAmount.getKeiyakuAmountSt()));
        map.put("rosHb", sUtils.mrate(parentSonekiList.getKeijousonekinetHb(), parentContractAmount.getKeiyakuAmountHb()));
        map.put("rosTr", sUtils.mrate(parentSonekiList.getKeijousonekinetTr(), parentContractAmount.getKeiyakuAmountTr()));
        map.put("rosFm", sUtils.mrate(parentSonekiList.getKeijousonekinetFm(), parentContractAmount.getKeiyakuAmountFm()));
        map.put("rosDiff", sUtils.mrate(parentSonekiList.getKeijousonekinetDiff(), parentContractAmount.getKeiyakuAmountDiff()));
        map.put("rosPd", sUtils.mrate(parentSonekiList.getKeijousonekinetPd(), parentContractAmount.getKeiyakuAmountPd()));
        map.put("rosPt", sUtils.mrate(parentSonekiList.getKeijousonekinetPt(), parentContractAmount.getKeiyakuAmountPt()));
        map.put("rosPs", sUtils.mrate(parentSonekiList.getKeijousonekinetPs(), parentContractAmount.getKeiyakuAmountPs()));
        map.put("rosPrev", sUtils.mrate(parentSonekiList.getKeijousonekinetPrev(), parentContractAmount.getKeiyakuAmountPrev()));

        this.s002Bean.setParentAnken(map);
        s002Bean.setMatomeChildFlg(s002Bean.getParentAnken() != null);
    }

    /**
     * 他事業部ISP案件の自事業部案件
     */
    private void setIspDivisionList() {
        logger.info("他事業部ＩＳＰ案件の自事業部案件を取得");

        s002Bean.setIspDivisionFlg(false);
        Map<String, Object> paramMap = new HashMap<>();
        paramMap.put("ispRelateId", s002Bean.getAnkenId());
        paramMap.put("ispKbn", ConstantString.ispKbn1);
        paramMap.put("rirekiId", s002Bean.getRirekiId());
        paramMap.put("rirekiFlg", s002Bean.getRirekiFlg());
        List<SyuGeBukkenInfoTbl> ispDivisionList = s002Facade.findIspDivisionList(paramMap);
        // 取れなければ以降は処理しない
        if (CollectionUtils.isNotEmpty(ispDivisionList)) {
            BigInteger[] saisyuSp = new BigInteger[ispDivisionList.size()];
            BigInteger[] saisyuNet = new BigInteger[ispDivisionList.size()];
            BigInteger[] uriageSp = new BigInteger[ispDivisionList.size()];
            BigInteger[] uriageNet = new BigInteger[ispDivisionList.size()];
//            BigInteger[] uriageTov = new BigInteger[ispDivisionList.size()];

            int i = 0;
            List<IspDivisionList> ispList = new ArrayList<>();
            for (SyuGeBukkenInfoTbl dtl : ispDivisionList) {
                IspDivisionList ispDtl = new IspDivisionList();
                ispDtl.setAnkenId(dtl.getAnkenId());
                ispDtl.setAnkenRev(dtl.getAnkenRev());
                ispDtl.setOrderNo(dtl.getOrderNo());
                ispDtl.setIspDivisionNm(dtl.getIspDivisionNm());
                ispDtl.setAnkenName(dtl.getAnkenName());
                ispDtl.setShirajiFlg(StringUtils.defaultString(dtl.getShirajiFlg(), "0"));
                ispDtl.setSaisyuSp(sUtils.exeFormatUnit(sUtils.switchingCurrencyUnit(NumberUtils.changeBigDecimal(dtl.getSaisyuSp()), s002Bean.getJpyUnit())));
                ispDtl.setSaisyuNet(sUtils.exeFormatUnit(sUtils.switchingCurrencyUnit(NumberUtils.changeBigDecimal(dtl.getSaisyuNet()), s002Bean.getJpyUnit())));
                BigDecimal arari = sUtils.arari(NumberUtils.changeBigDecimal(dtl.getSaisyuSp()), NumberUtils.changeBigDecimal(dtl.getSaisyuNet()));
                ispDtl.setArari(sUtils.exeFormatUnit(sUtils.switchingCurrencyUnit(arari, s002Bean.getJpyUnit())));
                ispDtl.setMrate(sUtils.mrate(NumberUtils.changeBigDecimal(dtl.getSaisyuSp()), NumberUtils.changeBigDecimal(dtl.getSaisyuNet())));
                ispDtl.setUriageSp(sUtils.exeFormatUnit(sUtils.switchingCurrencyUnit(NumberUtils.changeBigDecimal(dtl.getUriageSp()), s002Bean.getJpyUnit())));
                ispDtl.setUriageNet(sUtils.exeFormatUnit(sUtils.switchingCurrencyUnit(NumberUtils.changeBigDecimal(dtl.getUriageNet()), s002Bean.getJpyUnit())));
                ispDtl.setUriageTov(sUtils.exeFormatUnit(sUtils.switchingCurrencyUnit(NumberUtils.changeBigDecimal(dtl.getUriageTov()), s002Bean.getJpyUnit())));
                ispList.add(ispDtl);

                saisyuSp[i] = dtl.getSaisyuSp();
                saisyuNet[i] = dtl.getSaisyuNet();
                uriageSp[i] = dtl.getUriageSp();
                uriageNet[i] = dtl.getUriageNet();
//                uriageTov[i] = dtl.getUriageTov();
                i++;
            }

            logger.info("ispDivisionList Count=[{}]", ispDivisionList.size());
            s002Bean.setIspDivisionList(ispList);

            IspDivisionList ispDivisionTotal = new IspDivisionList();
            ispDivisionTotal.setSaisyuSp(sUtils.exeFormatUnit(sUtils.switchingCurrencyUnit(NumberUtils.changeBigDecimal(NumberUtils.add(saisyuSp)), s002Bean.getJpyUnit())));
            ispDivisionTotal.setSaisyuNet(sUtils.exeFormatUnit(sUtils.switchingCurrencyUnit(NumberUtils.changeBigDecimal(NumberUtils.add(saisyuNet)), s002Bean.getJpyUnit())));
            BigDecimal arari = sUtils.arari(NumberUtils.changeBigDecimal(ispDivisionTotal.getSaisyuSp()), NumberUtils.changeBigDecimal(ispDivisionTotal.getSaisyuNet()));
            ispDivisionTotal.setArari(sUtils.exeFormatUnit(sUtils.switchingCurrencyUnit(arari, s002Bean.getJpyUnit())));
            ispDivisionTotal.setMrate(sUtils.mrate(NumberUtils.changeBigDecimal(ispDivisionTotal.getSaisyuSp()), NumberUtils.changeBigDecimal(ispDivisionTotal.getSaisyuNet())));
            ispDivisionTotal.setUriageSp(sUtils.exeFormatUnit(sUtils.switchingCurrencyUnit(NumberUtils.changeBigDecimal(NumberUtils.add(uriageSp)), s002Bean.getJpyUnit())));
            ispDivisionTotal.setUriageNet(sUtils.exeFormatUnit(sUtils.switchingCurrencyUnit(NumberUtils.changeBigDecimal(NumberUtils.add(uriageNet)), s002Bean.getJpyUnit())));
//            ispDivisionTotal.setUriageTov(sUtils.exeFormatUnit(sUtils.switchingCurrencyUnit(NumberUtils.changeBigDecimal(NumberUtils.add(uriageTov)), s002Bean.getJpyUnit())));
            s002Bean.setIspDivisionTotal(ispDivisionTotal);
            s002Bean.setIspDivisionFlg(true);
        }
    }

    /**
     * 取得した各リストの通貨単位切り替え、カンマ編集を行う
     */
    private void switchingUnit(CurrencyRateList totalContractAmount, CostList totalCost, List<CurrencyRateList> currencyRateList, List<CostList> costList, List<ProductSonekiList> productSonekiList, SonekiList sonekiList, List<CategoryHanchokuList> categoryHanchokuList) {
        // 契約金額合計
        HashMap<String, String> totalContractAmountMap = new HashMap<>();
        totalContractAmountMap.put("KeiyakuAmountJs", sUtils.exeFormatUnit(sUtils.switchingCurrencyUnit(totalContractAmount.getKeiyakuAmountJs(), s002Bean.getJpyUnit())));
        totalContractAmountMap.put("KeiyakuAmountJt", sUtils.exeFormatUnit(sUtils.switchingCurrencyUnit(totalContractAmount.getKeiyakuAmountJt(), s002Bean.getJpyUnit())));
        totalContractAmountMap.put("KeiyakuAmountMh", sUtils.exeFormatUnit(sUtils.switchingCurrencyUnit(totalContractAmount.getKeiyakuAmountMh(), s002Bean.getJpyUnit())));
        totalContractAmountMap.put("KeiyakuAmountSm", sUtils.exeFormatUnit(sUtils.switchingCurrencyUnit(totalContractAmount.getKeiyakuAmountSm(), s002Bean.getJpyUnit())));
        totalContractAmountMap.put("KeiyakuAmountSt", sUtils.exeFormatUnit(sUtils.switchingCurrencyUnit(totalContractAmount.getKeiyakuAmountSt(), s002Bean.getJpyUnit())));
        totalContractAmountMap.put("KeiyakuAmountHb", sUtils.exeFormatUnit(sUtils.switchingCurrencyUnit(totalContractAmount.getKeiyakuAmountHb(), s002Bean.getJpyUnit())));
        totalContractAmountMap.put("KeiyakuAmountTr", sUtils.exeFormatUnit(sUtils.switchingCurrencyUnit(totalContractAmount.getKeiyakuAmountTr(), s002Bean.getJpyUnit())));
        totalContractAmountMap.put("KeiyakuAmountFm", sUtils.exeFormatUnit(sUtils.switchingCurrencyUnit(totalContractAmount.getKeiyakuAmountFm(), s002Bean.getJpyUnit())));
        totalContractAmountMap.put("KeiyakuAmountDiff", sUtils.exeFormatUnit(sUtils.switchingCurrencyUnit(totalContractAmount.getKeiyakuAmountDiff(), s002Bean.getJpyUnit())));
        totalContractAmountMap.put("KeiyakuAmountPd", sUtils.exeFormatUnit(sUtils.switchingCurrencyUnit(totalContractAmount.getKeiyakuAmountPd(), s002Bean.getJpyUnit())));
        totalContractAmountMap.put("KeiyakuAmountPt", sUtils.exeFormatUnit(sUtils.switchingCurrencyUnit(totalContractAmount.getKeiyakuAmountPt(), s002Bean.getJpyUnit())));
        totalContractAmountMap.put("KeiyakuAmountPs", sUtils.exeFormatUnit(sUtils.switchingCurrencyUnit(totalContractAmount.getKeiyakuAmountPs(), s002Bean.getJpyUnit())));
        totalContractAmountMap.put("KeiyakuAmountPrev", sUtils.exeFormatUnit(sUtils.switchingCurrencyUnit(totalContractAmount.getKeiyakuAmountPrev(), s002Bean.getJpyUnit())));
        s002Bean.setTotalContractAmount(totalContractAmountMap);

        // 売上原価合計
        HashMap<String, String> totalCostMap = new HashMap<>();
        totalCostMap.put("UriageNetJs", sUtils.exeFormatUnit(sUtils.switchingCurrencyUnit(totalCost.getUriageNetJs(), s002Bean.getJpyUnit())));
        totalCostMap.put("UriageNetJt", sUtils.exeFormatUnit(sUtils.switchingCurrencyUnit(totalCost.getUriageNetJt(), s002Bean.getJpyUnit())));
        totalCostMap.put("UriageNetMh", sUtils.exeFormatUnit(sUtils.switchingCurrencyUnit(totalCost.getUriageNetMh(), s002Bean.getJpyUnit())));
        totalCostMap.put("UriageNetSm", sUtils.exeFormatUnit(sUtils.switchingCurrencyUnit(totalCost.getUriageNetSm(), s002Bean.getJpyUnit())));
        totalCostMap.put("UriageNetSt", sUtils.exeFormatUnit(sUtils.switchingCurrencyUnit(totalCost.getUriageNetSt(), s002Bean.getJpyUnit())));
        totalCostMap.put("UriageNetHb", sUtils.exeFormatUnit(sUtils.switchingCurrencyUnit(totalCost.getUriageNetHb(), s002Bean.getJpyUnit())));
        totalCostMap.put("UriageNetTr", sUtils.exeFormatUnit(sUtils.switchingCurrencyUnit(totalCost.getUriageNetTr(), s002Bean.getJpyUnit())));
        totalCostMap.put("UriageNetFm", sUtils.exeFormatUnit(sUtils.switchingCurrencyUnit(totalCost.getUriageNetFm(), s002Bean.getJpyUnit())));
        totalCostMap.put("UriageNetDiff", sUtils.exeFormatUnit(sUtils.switchingCurrencyUnit(totalCost.getUriageNetDiff(), s002Bean.getJpyUnit())));
        totalCostMap.put("UriageNetPd", sUtils.exeFormatUnit(sUtils.switchingCurrencyUnit(totalCost.getUriageNetPd(), s002Bean.getJpyUnit())));
        totalCostMap.put("UriageNetPt", sUtils.exeFormatUnit(sUtils.switchingCurrencyUnit(totalCost.getUriageNetPt(), s002Bean.getJpyUnit())));
        totalCostMap.put("UriageNetPs", sUtils.exeFormatUnit(sUtils.switchingCurrencyUnit(totalCost.getUriageNetPs(), s002Bean.getJpyUnit())));
        totalCostMap.put("UriageNetPrev", sUtils.exeFormatUnit(sUtils.switchingCurrencyUnit(totalCost.getUriageNetPrev(), s002Bean.getJpyUnit())));
        s002Bean.setTotalCost(totalCostMap);

        // 契約金額内訳
        List<HashMap<String, String>> currencyRateMapList = new ArrayList<>();
        if (currencyRateList != null) {
            int unit = 1;
            for (int i = 0; i < currencyRateList.size(); i++) {
                if (currencyRateList.get(i).getCurrencyCode().equals(ConstantString.currencyCodeEn)) {
                    unit = s002Bean.getJpyUnit();
                } else {
                    unit = 1;
                }
                HashMap<String, String> currencyRateMap = new HashMap<>();
                currencyRateMap.put("currencyCode", currencyRateList.get(i).getCurrencyCode());
                currencyRateMap.put("KeiyakuRateJs", sUtils.exeFormatUnitRate(sUtils.switchingCurrencyUnit(currencyRateList.get(i).getKeiyakuRateJs(), unit, currencyRateList.get(i).getCurrencyCode()), currencyRateList.get(i).getCurrencyCode()));
                currencyRateMap.put("KeiyakuRateJt", sUtils.exeFormatUnitRate(sUtils.switchingCurrencyUnit(currencyRateList.get(i).getKeiyakuRateJt(), unit, currencyRateList.get(i).getCurrencyCode()), currencyRateList.get(i).getCurrencyCode()));
                currencyRateMap.put("KeiyakuRateMh", sUtils.exeFormatUnitRate(sUtils.switchingCurrencyUnit(currencyRateList.get(i).getKeiyakuRateMh(), unit, currencyRateList.get(i).getCurrencyCode()), currencyRateList.get(i).getCurrencyCode()));
                currencyRateMap.put("KeiyakuRateSm", sUtils.exeFormatUnitRate(sUtils.switchingCurrencyUnit(currencyRateList.get(i).getKeiyakuRateSm(), unit, currencyRateList.get(i).getCurrencyCode()), currencyRateList.get(i).getCurrencyCode()));
                currencyRateMap.put("KeiyakuRateSt", sUtils.exeFormatUnitRate(sUtils.switchingCurrencyUnit(currencyRateList.get(i).getKeiyakuRateSt(), unit, currencyRateList.get(i).getCurrencyCode()), currencyRateList.get(i).getCurrencyCode()));
                currencyRateMap.put("KeiyakuRateHb", sUtils.exeFormatUnitRate(sUtils.switchingCurrencyUnit(currencyRateList.get(i).getKeiyakuRateHb(), unit, currencyRateList.get(i).getCurrencyCode()), currencyRateList.get(i).getCurrencyCode()));
                currencyRateMap.put("KeiyakuRateTr", sUtils.exeFormatUnitRate(sUtils.switchingCurrencyUnit(currencyRateList.get(i).getKeiyakuRateTr(), unit, currencyRateList.get(i).getCurrencyCode()), currencyRateList.get(i).getCurrencyCode()));
                currencyRateMap.put("KeiyakuRateFm", sUtils.exeFormatUnitRate(sUtils.switchingCurrencyUnit(currencyRateList.get(i).getKeiyakuRateFm(), unit, currencyRateList.get(i).getCurrencyCode()), currencyRateList.get(i).getCurrencyCode()));
                currencyRateMap.put("KeiyakuRateDiff", sUtils.exeFormatUnitRate(sUtils.switchingCurrencyUnit(currencyRateList.get(i).getKeiyakuRateDiff(), unit, currencyRateList.get(i).getCurrencyCode()), currencyRateList.get(i).getCurrencyCode()));
                currencyRateMap.put("KeiyakuRatePd", sUtils.exeFormatUnitRate(sUtils.switchingCurrencyUnit(currencyRateList.get(i).getKeiyakuRatePd(), unit, currencyRateList.get(i).getCurrencyCode()), currencyRateList.get(i).getCurrencyCode()));
                currencyRateMap.put("KeiyakuRatePt", sUtils.exeFormatUnitRate(sUtils.switchingCurrencyUnit(currencyRateList.get(i).getKeiyakuRatePt(), unit, currencyRateList.get(i).getCurrencyCode()), currencyRateList.get(i).getCurrencyCode()));
                currencyRateMap.put("KeiyakuRatePs", sUtils.exeFormatUnitRate(sUtils.switchingCurrencyUnit(currencyRateList.get(i).getKeiyakuRatePs(), unit, currencyRateList.get(i).getCurrencyCode()), currencyRateList.get(i).getCurrencyCode()));
                currencyRateMap.put("KeiyakuRatePrev", sUtils.exeFormatUnitRate(sUtils.switchingCurrencyUnit(currencyRateList.get(i).getKeiyakuRatePrev(), unit, currencyRateList.get(i).getCurrencyCode()), currencyRateList.get(i).getCurrencyCode()));
                currencyRateMap.put("KeiyakuAmountJs", sUtils.exeFormatUnitRate(sUtils.switchingCurrencyUnit(currencyRateList.get(i).getKeiyakuAmountJs(), unit, currencyRateList.get(i).getCurrencyCode()), currencyRateList.get(i).getCurrencyCode()));
                currencyRateMap.put("KeiyakuAmountJt", sUtils.exeFormatUnitRate(sUtils.switchingCurrencyUnit(currencyRateList.get(i).getKeiyakuAmountJt(), unit, currencyRateList.get(i).getCurrencyCode()), currencyRateList.get(i).getCurrencyCode()));
                currencyRateMap.put("KeiyakuAmountMh", sUtils.exeFormatUnitRate(sUtils.switchingCurrencyUnit(currencyRateList.get(i).getKeiyakuAmountMh(), unit, currencyRateList.get(i).getCurrencyCode()), currencyRateList.get(i).getCurrencyCode()));
                currencyRateMap.put("KeiyakuAmountSm", sUtils.exeFormatUnitRate(sUtils.switchingCurrencyUnit(currencyRateList.get(i).getKeiyakuAmountSm(), unit, currencyRateList.get(i).getCurrencyCode()), currencyRateList.get(i).getCurrencyCode()));
                currencyRateMap.put("KeiyakuAmountSt", sUtils.exeFormatUnitRate(sUtils.switchingCurrencyUnit(currencyRateList.get(i).getKeiyakuAmountSt(), unit, currencyRateList.get(i).getCurrencyCode()), currencyRateList.get(i).getCurrencyCode()));
                currencyRateMap.put("KeiyakuAmountHb", sUtils.exeFormatUnitRate(sUtils.switchingCurrencyUnit(currencyRateList.get(i).getKeiyakuAmountHb(), unit, currencyRateList.get(i).getCurrencyCode()), currencyRateList.get(i).getCurrencyCode()));
                currencyRateMap.put("KeiyakuAmountTr", sUtils.exeFormatUnitRate(sUtils.switchingCurrencyUnit(currencyRateList.get(i).getKeiyakuAmountTr(), unit, currencyRateList.get(i).getCurrencyCode()), currencyRateList.get(i).getCurrencyCode()));
                currencyRateMap.put("KeiyakuAmountFm", sUtils.exeFormatUnitRate(sUtils.switchingCurrencyUnit(currencyRateList.get(i).getKeiyakuAmountFm(), unit, currencyRateList.get(i).getCurrencyCode()), currencyRateList.get(i).getCurrencyCode()));
                currencyRateMap.put("KeiyakuAmountDiff", sUtils.exeFormatUnitRate(sUtils.switchingCurrencyUnit(currencyRateList.get(i).getKeiyakuAmountDiff(), unit, currencyRateList.get(i).getCurrencyCode()), currencyRateList.get(i).getCurrencyCode()));
                currencyRateMap.put("KeiyakuAmountPd", sUtils.exeFormatUnitRate(sUtils.switchingCurrencyUnit(currencyRateList.get(i).getKeiyakuAmountPd(), unit, currencyRateList.get(i).getCurrencyCode()), currencyRateList.get(i).getCurrencyCode()));
                currencyRateMap.put("KeiyakuAmountPt", sUtils.exeFormatUnitRate(sUtils.switchingCurrencyUnit(currencyRateList.get(i).getKeiyakuAmountPt(), unit, currencyRateList.get(i).getCurrencyCode()), currencyRateList.get(i).getCurrencyCode()));
                currencyRateMap.put("KeiyakuAmountPs", sUtils.exeFormatUnitRate(sUtils.switchingCurrencyUnit(currencyRateList.get(i).getKeiyakuAmountPs(), unit, currencyRateList.get(i).getCurrencyCode()), currencyRateList.get(i).getCurrencyCode()));
                currencyRateMap.put("KeiyakuAmountPrev", sUtils.exeFormatUnitRate(sUtils.switchingCurrencyUnit(currencyRateList.get(i).getKeiyakuAmountPrev(), unit, currencyRateList.get(i).getCurrencyCode()), currencyRateList.get(i).getCurrencyCode()));
                currencyRateMapList.add(currencyRateMap);
            }
        }
        s002Bean.setCurrencyRateMapList(currencyRateMapList);

        // 売上原価内訳
        List<HashMap<String, String>> costMapList = new ArrayList<>();
        if (costList != null) {
            for (int i = 0; i < costList.size(); i++) {
                HashMap<String, String> costMap = new HashMap<>();
                costMap.put("categoryCode", costList.get(i).getCategoryCode());
                costMap.put("categoryName1", costList.get(i).getCategoryName1());
                costMap.put("categoryName2", costList.get(i).getCategoryName2());
                costMap.put("categoryKbn1", costList.get(i).getCategoryKbn1());
                costMap.put("categoryKbn2", costList.get(i).getCategoryKbn2());
                costMap.put("UriageNetJs", sUtils.exeFormatUnit(sUtils.switchingCurrencyUnit(costList.get(i).getUriageNetJs(), s002Bean.getJpyUnit())));
                //costMap.put("UriageNetJs", sUtils.exeFormatUnit(sUtils.switchingCurrencyUnit(costList.get(i).getUriageNetJs(), s002Bean.getJpyUnit())));
                costMap.put("UriageNetJt", sUtils.exeFormatUnit(sUtils.switchingCurrencyUnit(costList.get(i).getUriageNetJt(), s002Bean.getJpyUnit())));
                costMap.put("UriageNetMh", sUtils.exeFormatUnit(sUtils.switchingCurrencyUnit(costList.get(i).getUriageNetMh(), s002Bean.getJpyUnit())));
                costMap.put("UriageNetSm", sUtils.exeFormatUnit(sUtils.switchingCurrencyUnit(costList.get(i).getUriageNetSm(), s002Bean.getJpyUnit())));
                costMap.put("UriageNetSt", sUtils.exeFormatUnit(sUtils.switchingCurrencyUnit(costList.get(i).getUriageNetSt(), s002Bean.getJpyUnit())));
                costMap.put("UriageNetHb", sUtils.exeFormatUnit(sUtils.switchingCurrencyUnit(costList.get(i).getUriageNetHb(), s002Bean.getJpyUnit())));
                costMap.put("UriageNetTr", sUtils.exeFormatUnit(sUtils.switchingCurrencyUnit(costList.get(i).getUriageNetTr(), s002Bean.getJpyUnit())));
                costMap.put("UriageNetFm", sUtils.exeFormatUnit(sUtils.switchingCurrencyUnit(costList.get(i).getUriageNetFm(), s002Bean.getJpyUnit())));
                costMap.put("UriageNetDiff", sUtils.exeFormatUnit(sUtils.switchingCurrencyUnit(costList.get(i).getUriageNetDiff(), s002Bean.getJpyUnit())));
                costMap.put("UriageNetPd", sUtils.exeFormatUnit(sUtils.switchingCurrencyUnit(costList.get(i).getUriageNetPd(), s002Bean.getJpyUnit())));
                costMap.put("UriageNetPt", sUtils.exeFormatUnit(sUtils.switchingCurrencyUnit(costList.get(i).getUriageNetPt(), s002Bean.getJpyUnit())));
                costMap.put("UriageNetPs", sUtils.exeFormatUnit(sUtils.switchingCurrencyUnit(costList.get(i).getUriageNetPs(), s002Bean.getJpyUnit())));
                costMap.put("UriageNetPrev", sUtils.exeFormatUnit(sUtils.switchingCurrencyUnit(costList.get(i).getUriageNetPrev(), s002Bean.getJpyUnit())));

                // 2017/11/28 #071 ADD 項番優先で計算された値のセルに色付けをする
                costMap.put("itemFlgJs", costList.get(i).getItemFlgJs());
                costMap.put("itemFlgJt", costList.get(i).getItemFlgJt());
                costMap.put("itemFlgMh", costList.get(i).getItemFlgMh());
                costMap.put("itemFlgSm", costList.get(i).getItemFlgSm());
                costMap.put("itemFlgSt", costList.get(i).getItemFlgSt());
                costMap.put("itemFlgHb", costList.get(i).getItemFlgHb());
                costMap.put("itemFlgTr", costList.get(i).getItemFlgTr());
                costMap.put("itemFlgFm", costList.get(i).getItemFlgFm());
                costMap.put("itemFlgDiff", costList.get(i).getItemFlgDiff());
                costMap.put("itemFlgPd", costList.get(i).getItemFlgPd());
                costMap.put("itemFlgPt", costList.get(i).getItemFlgPt());
                costMap.put("itemFlgPs", costList.get(i).getItemFlgPs());
                costMap.put("itemFlgPrev", costList.get(i).getItemFlgPrev());

                costMap.put("mitFlg",costList.get(i).getMitFlg());
                costMapList.add(costMap);
            }
        }
        s002Bean.setCostList(costMapList);

//        // 工場別製番損益表内訳
//        List<HashMap<String, String>> productSonekiMapList = new ArrayList<>();
//        if (productSonekiList != null) {
//            for (int i = 0; i < productSonekiList.size(); i++) {
//                HashMap<String, String> productSonekiMap = new HashMap<>();
//                productSonekiMap.put("kojoName", productSonekiList.get(i).getKojoName());
//                productSonekiMap.put("kojoCode", productSonekiList.get(i).getKojoCode());
//                productSonekiMap.put("SeibanSonekiNetJs", sUtils.exeFormatUnit(sUtils.switchingCurrencyUnit(productSonekiList.get(i).getSeibanSonekiNetJs(), s002Bean.getJpyUnit())));
//                productSonekiMap.put("SeibanSonekiNetJt", sUtils.exeFormatUnit(sUtils.switchingCurrencyUnit(productSonekiList.get(i).getSeibanSonekiNetJt(), s002Bean.getJpyUnit())));
//                productSonekiMap.put("SeibanSonekiNetMh", sUtils.exeFormatUnit(sUtils.switchingCurrencyUnit(productSonekiList.get(i).getSeibanSonekiNetMh(), s002Bean.getJpyUnit())));
//                productSonekiMap.put("SeibanSonekiNetSm", sUtils.exeFormatUnit(sUtils.switchingCurrencyUnit(productSonekiList.get(i).getSeibanSonekiNetSm(), s002Bean.getJpyUnit())));
//                productSonekiMap.put("SeibanSonekiNetSt", sUtils.exeFormatUnit(sUtils.switchingCurrencyUnit(productSonekiList.get(i).getSeibanSonekiNetSt(), s002Bean.getJpyUnit())));
//                productSonekiMap.put("SeibanSonekiNetHb", sUtils.exeFormatUnit(sUtils.switchingCurrencyUnit(productSonekiList.get(i).getSeibanSonekiNetHb(), s002Bean.getJpyUnit())));
//                productSonekiMap.put("SeibanSonekiNetTr", sUtils.exeFormatUnit(sUtils.switchingCurrencyUnit(productSonekiList.get(i).getSeibanSonekiNetTr(), s002Bean.getJpyUnit())));
//                productSonekiMap.put("SeibanSonekiNetFm", sUtils.exeFormatUnit(sUtils.switchingCurrencyUnit(productSonekiList.get(i).getSeibanSonekiNetFm(), s002Bean.getJpyUnit())));
//                productSonekiMap.put("SeibanSonekiNetDiff", sUtils.exeFormatUnit(sUtils.switchingCurrencyUnit(productSonekiList.get(i).getSeibanSonekiNetDiff(), s002Bean.getJpyUnit())));
//                productSonekiMap.put("SeibanSonekiNetPd", sUtils.exeFormatUnit(sUtils.switchingCurrencyUnit(productSonekiList.get(i).getSeibanSonekiNetPd(), s002Bean.getJpyUnit())));
//                productSonekiMap.put("SeibanSonekiNetPt", sUtils.exeFormatUnit(sUtils.switchingCurrencyUnit(productSonekiList.get(i).getSeibanSonekiNetPt(), s002Bean.getJpyUnit())));
//                productSonekiMap.put("SeibanSonekiNetPs", sUtils.exeFormatUnit(sUtils.switchingCurrencyUnit(productSonekiList.get(i).getSeibanSonekiNetPs(), s002Bean.getJpyUnit())));
//                productSonekiMap.put("SeibanSonekiNetPrev", sUtils.exeFormatUnit(sUtils.switchingCurrencyUnit(productSonekiList.get(i).getSeibanSonekiNetPrev(), s002Bean.getJpyUnit())));
//                productSonekiMapList.add(productSonekiMap);
//            }
//        }
//        s002Bean.setProductSonekiList(productSonekiMapList);
        // 損益表
        // 販売直接費
        HashMap<String, String> sonekiMap = new HashMap<>();
        sonekiMap.put("HanChokuNetJs", sUtils.exeFormatUnit(sUtils.switchingCurrencyUnit(sonekiList.getHanChokuNetJs(), s002Bean.getJpyUnit())));
        sonekiMap.put("HanChokuNetJt", sUtils.exeFormatUnit(sUtils.switchingCurrencyUnit(sonekiList.getHanChokuNetJt(), s002Bean.getJpyUnit())));
        sonekiMap.put("HanChokuNetMh", sUtils.exeFormatUnit(sUtils.switchingCurrencyUnit(sonekiList.getHanChokuNetMh(), s002Bean.getJpyUnit())));
        sonekiMap.put("HanChokuNetSm", sUtils.exeFormatUnit(sUtils.switchingCurrencyUnit(sonekiList.getHanChokuNetSm(), s002Bean.getJpyUnit())));
        sonekiMap.put("HanChokuNetSt", sUtils.exeFormatUnit(sUtils.switchingCurrencyUnit(sonekiList.getHanChokuNetSt(), s002Bean.getJpyUnit())));
        sonekiMap.put("HanChokuNetHb", sUtils.exeFormatUnit(sUtils.switchingCurrencyUnit(sonekiList.getHanChokuNetHb(), s002Bean.getJpyUnit())));
        sonekiMap.put("HanChokuNetTr", sUtils.exeFormatUnit(sUtils.switchingCurrencyUnit(sonekiList.getHanChokuNetTr(), s002Bean.getJpyUnit())));
        sonekiMap.put("HanChokuNetFm", sUtils.exeFormatUnit(sUtils.switchingCurrencyUnit(sonekiList.getHanChokuNetFm(), s002Bean.getJpyUnit())));
        sonekiMap.put("HanChokuNetDiff", sUtils.exeFormatUnit(sUtils.switchingCurrencyUnit(sonekiList.getHanChokuNetDiff(), s002Bean.getJpyUnit())));
        sonekiMap.put("HanChokuNetPd", sUtils.exeFormatUnit(sUtils.switchingCurrencyUnit(sonekiList.getHanChokuNetPd(), s002Bean.getJpyUnit())));
        sonekiMap.put("HanChokuNetPt", sUtils.exeFormatUnit(sUtils.switchingCurrencyUnit(sonekiList.getHanChokuNetPt(), s002Bean.getJpyUnit())));
        sonekiMap.put("HanChokuNetPs", sUtils.exeFormatUnit(sUtils.switchingCurrencyUnit(sonekiList.getHanChokuNetPs(), s002Bean.getJpyUnit())));
        sonekiMap.put("HanChokuNetPrev", sUtils.exeFormatUnit(sUtils.switchingCurrencyUnit(sonekiList.getHanChokuNetPrev(), s002Bean.getJpyUnit())));

        // 販売間接費
        sonekiMap.put("HanKanNetJs", sUtils.exeFormatUnit(sUtils.switchingCurrencyUnit(sonekiList.getHanKanNetJs(), s002Bean.getJpyUnit())));
        sonekiMap.put("HanKanNetJt", sUtils.exeFormatUnit(sUtils.switchingCurrencyUnit(sonekiList.getHanKanNetJt(), s002Bean.getJpyUnit())));
        sonekiMap.put("HanKanNetMh", sUtils.exeFormatUnit(sUtils.switchingCurrencyUnit(sonekiList.getHanKanNetMh(), s002Bean.getJpyUnit())));
        sonekiMap.put("HanKanNetSm", sUtils.exeFormatUnit(sUtils.switchingCurrencyUnit(sonekiList.getHanKanNetSm(), s002Bean.getJpyUnit())));
        sonekiMap.put("HanKanNetSt", sUtils.exeFormatUnit(sUtils.switchingCurrencyUnit(sonekiList.getHanKanNetSt(), s002Bean.getJpyUnit())));
        sonekiMap.put("HanKanNetHb", sUtils.exeFormatUnit(sUtils.switchingCurrencyUnit(sonekiList.getHanKanNetHb(), s002Bean.getJpyUnit())));
        sonekiMap.put("HanKanNetTr", sUtils.exeFormatUnit(sUtils.switchingCurrencyUnit(sonekiList.getHanKanNetTr(), s002Bean.getJpyUnit())));
        sonekiMap.put("HanKanNetFm", sUtils.exeFormatUnit(sUtils.switchingCurrencyUnit(sonekiList.getHanKanNetFm(), s002Bean.getJpyUnit())));
        sonekiMap.put("HanKanNetDiff", sUtils.exeFormatUnit(sUtils.switchingCurrencyUnit(sonekiList.getHanKanNetDiff(), s002Bean.getJpyUnit())));
        sonekiMap.put("HanKanNetPd", sUtils.exeFormatUnit(sUtils.switchingCurrencyUnit(sonekiList.getHanKanNetPd(), s002Bean.getJpyUnit())));
        sonekiMap.put("HanKanNetPt", sUtils.exeFormatUnit(sUtils.switchingCurrencyUnit(sonekiList.getHanKanNetPt(), s002Bean.getJpyUnit())));
        sonekiMap.put("HanKanNetPs", sUtils.exeFormatUnit(sUtils.switchingCurrencyUnit(sonekiList.getHanKanNetPs(), s002Bean.getJpyUnit())));
        sonekiMap.put("HanKanNetPrev", sUtils.exeFormatUnit(sUtils.switchingCurrencyUnit(sonekiList.getHanKanNetPrev(), s002Bean.getJpyUnit())));

        // 経費
        sonekiMap.put("KeihiNetJs", sUtils.exeFormatUnit(sUtils.switchingCurrencyUnit(sonekiList.getKeihiNetJs(), s002Bean.getJpyUnit())));
        sonekiMap.put("KeihiNetJt", sUtils.exeFormatUnit(sUtils.switchingCurrencyUnit(sonekiList.getKeihiNetJt(), s002Bean.getJpyUnit())));
        sonekiMap.put("KeihiNetMh", sUtils.exeFormatUnit(sUtils.switchingCurrencyUnit(sonekiList.getKeihiNetMh(), s002Bean.getJpyUnit())));
        sonekiMap.put("KeihiNetSm", sUtils.exeFormatUnit(sUtils.switchingCurrencyUnit(sonekiList.getKeihiNetSm(), s002Bean.getJpyUnit())));
        sonekiMap.put("KeihiNetSt", sUtils.exeFormatUnit(sUtils.switchingCurrencyUnit(sonekiList.getKeihiNetSt(), s002Bean.getJpyUnit())));
        sonekiMap.put("KeihiNetHb", sUtils.exeFormatUnit(sUtils.switchingCurrencyUnit(sonekiList.getKeihiNetHb(), s002Bean.getJpyUnit())));
        sonekiMap.put("KeihiNetTr", sUtils.exeFormatUnit(sUtils.switchingCurrencyUnit(sonekiList.getKeihiNetTr(), s002Bean.getJpyUnit())));
        sonekiMap.put("KeihiNetFm", sUtils.exeFormatUnit(sUtils.switchingCurrencyUnit(sonekiList.getKeihiNetFm(), s002Bean.getJpyUnit())));
        sonekiMap.put("KeihiNetDiff", sUtils.exeFormatUnit(sUtils.switchingCurrencyUnit(sonekiList.getKeihiNetDiff(), s002Bean.getJpyUnit())));
        sonekiMap.put("KeihiNetPd", sUtils.exeFormatUnit(sUtils.switchingCurrencyUnit(sonekiList.getKeihiNetPd(), s002Bean.getJpyUnit())));
        sonekiMap.put("KeihiNetPt", sUtils.exeFormatUnit(sUtils.switchingCurrencyUnit(sonekiList.getKeihiNetPt(), s002Bean.getJpyUnit())));
        sonekiMap.put("KeihiNetPs", sUtils.exeFormatUnit(sUtils.switchingCurrencyUnit(sonekiList.getKeihiNetPs(), s002Bean.getJpyUnit())));
        sonekiMap.put("KeihiNetPrev", sUtils.exeFormatUnit(sUtils.switchingCurrencyUnit(sonekiList.getKeihiNetPrev(), s002Bean.getJpyUnit())));

        // 為替予約
        sonekiMap.put("KawaseYoyakuNetJs", sUtils.exeFormatUnit(sUtils.switchingCurrencyUnit(sonekiList.getKawaseYoyakuNetJs(), s002Bean.getJpyUnit())));
        sonekiMap.put("KawaseYoyakuNetJt", sUtils.exeFormatUnit(sUtils.switchingCurrencyUnit(sonekiList.getKawaseYoyakuNetJt(), s002Bean.getJpyUnit())));
        sonekiMap.put("KawaseYoyakuNetMh", sUtils.exeFormatUnit(sUtils.switchingCurrencyUnit(sonekiList.getKawaseYoyakuNetMh(), s002Bean.getJpyUnit())));
        sonekiMap.put("KawaseYoyakuNetSm", sUtils.exeFormatUnit(sUtils.switchingCurrencyUnit(sonekiList.getKawaseYoyakuNetSm(), s002Bean.getJpyUnit())));
        sonekiMap.put("KawaseYoyakuNetSt", sUtils.exeFormatUnit(sUtils.switchingCurrencyUnit(sonekiList.getKawaseYoyakuNetSt(), s002Bean.getJpyUnit())));
        sonekiMap.put("KawaseYoyakuNetHb", sUtils.exeFormatUnit(sUtils.switchingCurrencyUnit(sonekiList.getKawaseYoyakuNetHb(), s002Bean.getJpyUnit())));
        sonekiMap.put("KawaseYoyakuNetTr", sUtils.exeFormatUnit(sUtils.switchingCurrencyUnit(sonekiList.getKawaseYoyakuNetTr(), s002Bean.getJpyUnit())));
        sonekiMap.put("KawaseYoyakuNetFm", sUtils.exeFormatUnit(sUtils.switchingCurrencyUnit(sonekiList.getKawaseYoyakuNetFm(), s002Bean.getJpyUnit())));
        sonekiMap.put("KawaseYoyakuNetDiff", sUtils.exeFormatUnit(sUtils.switchingCurrencyUnit(sonekiList.getKawaseYoyakuNetDiff(), s002Bean.getJpyUnit())));
        sonekiMap.put("KawaseYoyakuNetPd", sUtils.exeFormatUnit(sUtils.switchingCurrencyUnit(sonekiList.getKawaseYoyakuNetPd(), s002Bean.getJpyUnit())));
        sonekiMap.put("KawaseYoyakuNetPt", sUtils.exeFormatUnit(sUtils.switchingCurrencyUnit(sonekiList.getKawaseYoyakuNetPt(), s002Bean.getJpyUnit())));
        sonekiMap.put("KawaseYoyakuNetPs", sUtils.exeFormatUnit(sUtils.switchingCurrencyUnit(sonekiList.getKawaseYoyakuNetPs(), s002Bean.getJpyUnit())));
        sonekiMap.put("KawaseYoyakuNetPrev", sUtils.exeFormatUnit(sUtils.switchingCurrencyUnit(sonekiList.getKawaseYoyakuNetPrev(), s002Bean.getJpyUnit())));

        // ISP
        sonekiMap.put("IspNetJs", sUtils.exeFormatUnit(sUtils.switchingCurrencyUnit(sonekiList.getIspNetJs(), s002Bean.getJpyUnit())));
        sonekiMap.put("IspNetJt", sUtils.exeFormatUnit(sUtils.switchingCurrencyUnit(sonekiList.getIspNetJt(), s002Bean.getJpyUnit())));
        sonekiMap.put("IspNetMh", sUtils.exeFormatUnit(sUtils.switchingCurrencyUnit(sonekiList.getIspNetMh(), s002Bean.getJpyUnit())));
        sonekiMap.put("IspNetSm", sUtils.exeFormatUnit(sUtils.switchingCurrencyUnit(sonekiList.getIspNetSm(), s002Bean.getJpyUnit())));
        sonekiMap.put("IspNetSt", sUtils.exeFormatUnit(sUtils.switchingCurrencyUnit(sonekiList.getIspNetSt(), s002Bean.getJpyUnit())));
        sonekiMap.put("IspNetHb", sUtils.exeFormatUnit(sUtils.switchingCurrencyUnit(sonekiList.getIspNetHb(), s002Bean.getJpyUnit())));
        sonekiMap.put("IspNetTr", sUtils.exeFormatUnit(sUtils.switchingCurrencyUnit(sonekiList.getIspNetTr(), s002Bean.getJpyUnit())));
        sonekiMap.put("IspNetFm", sUtils.exeFormatUnit(sUtils.switchingCurrencyUnit(sonekiList.getIspNetFm(), s002Bean.getJpyUnit())));
        sonekiMap.put("IspNetDiff", sUtils.exeFormatUnit(sUtils.switchingCurrencyUnit(sonekiList.getIspNetDiff(), s002Bean.getJpyUnit())));
        sonekiMap.put("IspNetPd", sUtils.exeFormatUnit(sUtils.switchingCurrencyUnit(sonekiList.getIspNetPd(), s002Bean.getJpyUnit())));
        sonekiMap.put("IspNetPt", sUtils.exeFormatUnit(sUtils.switchingCurrencyUnit(sonekiList.getIspNetPt(), s002Bean.getJpyUnit())));
        sonekiMap.put("IspNetPs", sUtils.exeFormatUnit(sUtils.switchingCurrencyUnit(sonekiList.getIspNetPs(), s002Bean.getJpyUnit())));
        sonekiMap.put("IspNetPrev", sUtils.exeFormatUnit(sUtils.switchingCurrencyUnit(sonekiList.getIspNetPrev(), s002Bean.getJpyUnit())));

//        // 製番損益
//        sonekiMap.put("SeibanSonekiNetJs", sUtils.exeFormatUnit(sUtils.switchingCurrencyUnit(sonekiList.getSeibanSonekiNetJs(), s002Bean.getJpyUnit())));
//        sonekiMap.put("SeibanSonekiNetJt", sUtils.exeFormatUnit(sUtils.switchingCurrencyUnit(sonekiList.getSeibanSonekiNetJt(), s002Bean.getJpyUnit())));
//        sonekiMap.put("SeibanSonekiNetMh", sUtils.exeFormatUnit(sUtils.switchingCurrencyUnit(sonekiList.getSeibanSonekiNetMh(), s002Bean.getJpyUnit())));
//        sonekiMap.put("SeibanSonekiNetSm", sUtils.exeFormatUnit(sUtils.switchingCurrencyUnit(sonekiList.getSeibanSonekiNetSm(), s002Bean.getJpyUnit())));
//        sonekiMap.put("SeibanSonekiNetSt", sUtils.exeFormatUnit(sUtils.switchingCurrencyUnit(sonekiList.getSeibanSonekiNetSt(), s002Bean.getJpyUnit())));
//        sonekiMap.put("SeibanSonekiNetHb", sUtils.exeFormatUnit(sUtils.switchingCurrencyUnit(sonekiList.getSeibanSonekiNetHb(), s002Bean.getJpyUnit())));
//        sonekiMap.put("SeibanSonekiNetTr", sUtils.exeFormatUnit(sUtils.switchingCurrencyUnit(sonekiList.getSeibanSonekiNetTr(), s002Bean.getJpyUnit())));
//        sonekiMap.put("SeibanSonekiNetFm", sUtils.exeFormatUnit(sUtils.switchingCurrencyUnit(sonekiList.getSeibanSonekiNetFm(), s002Bean.getJpyUnit())));
//        sonekiMap.put("SeibanSonekiNetDiff", sUtils.exeFormatUnit(sUtils.switchingCurrencyUnit(sonekiList.getSeibanSonekiNetDiff(), s002Bean.getJpyUnit())));
//        sonekiMap.put("SeibanSonekiNetPd", sUtils.exeFormatUnit(sUtils.switchingCurrencyUnit(sonekiList.getSeibanSonekiNetPd(), s002Bean.getJpyUnit())));
//        sonekiMap.put("SeibanSonekiNetPt", sUtils.exeFormatUnit(sUtils.switchingCurrencyUnit(sonekiList.getSeibanSonekiNetPt(), s002Bean.getJpyUnit())));
//        sonekiMap.put("SeibanSonekiNetPs", sUtils.exeFormatUnit(sUtils.switchingCurrencyUnit(sonekiList.getSeibanSonekiNetPs(), s002Bean.getJpyUnit())));
//        sonekiMap.put("SeibanSonekiNetPrev", sUtils.exeFormatUnit(sUtils.switchingCurrencyUnit(sonekiList.getSeibanSonekiNetPrev(), s002Bean.getJpyUnit())));
        // 総原価
        sonekiMap.put("SougenkaNetJs", sUtils.exeFormatUnit(sUtils.switchingCurrencyUnit(sonekiList.getSougenkaNetJs(), s002Bean.getJpyUnit())));
        sonekiMap.put("SougenkaNetJt", sUtils.exeFormatUnit(sUtils.switchingCurrencyUnit(sonekiList.getSougenkaNetJt(), s002Bean.getJpyUnit())));
        sonekiMap.put("SougenkaNetMh", sUtils.exeFormatUnit(sUtils.switchingCurrencyUnit(sonekiList.getSougenkaNetMh(), s002Bean.getJpyUnit())));
        sonekiMap.put("SougenkaNetSm", sUtils.exeFormatUnit(sUtils.switchingCurrencyUnit(sonekiList.getSougenkaNetSm(), s002Bean.getJpyUnit())));
        sonekiMap.put("SougenkaNetSt", sUtils.exeFormatUnit(sUtils.switchingCurrencyUnit(sonekiList.getSougenkaNetSt(), s002Bean.getJpyUnit())));
        sonekiMap.put("SougenkaNetHb", sUtils.exeFormatUnit(sUtils.switchingCurrencyUnit(sonekiList.getSougenkaNetHb(), s002Bean.getJpyUnit())));
        sonekiMap.put("SougenkaNetTr", sUtils.exeFormatUnit(sUtils.switchingCurrencyUnit(sonekiList.getSougenkaNetTr(), s002Bean.getJpyUnit())));
        sonekiMap.put("SougenkaNetFm", sUtils.exeFormatUnit(sUtils.switchingCurrencyUnit(sonekiList.getSougenkaNetFm(), s002Bean.getJpyUnit())));
        sonekiMap.put("SougenkaNetDiff", sUtils.exeFormatUnit(sUtils.switchingCurrencyUnit(sonekiList.getSougenkaNetDiff(), s002Bean.getJpyUnit())));
        sonekiMap.put("SougenkaNetPd", sUtils.exeFormatUnit(sUtils.switchingCurrencyUnit(sonekiList.getSougenkaNetPd(), s002Bean.getJpyUnit())));
        sonekiMap.put("SougenkaNetPt", sUtils.exeFormatUnit(sUtils.switchingCurrencyUnit(sonekiList.getSougenkaNetPt(), s002Bean.getJpyUnit())));
        sonekiMap.put("SougenkaNetPs", sUtils.exeFormatUnit(sUtils.switchingCurrencyUnit(sonekiList.getSougenkaNetPs(), s002Bean.getJpyUnit())));
        sonekiMap.put("SougenkaNetPrev", sUtils.exeFormatUnit(sUtils.switchingCurrencyUnit(sonekiList.getSougenkaNetPrev(), s002Bean.getJpyUnit())));
        s002Bean.setSonekiList(sonekiMap);

        //営業外損益
        sonekiMap.put("EigyogaiJs", sUtils.exeFormatUnit(sUtils.switchingCurrencyUnit(sonekiList.getEigyogaiJs(), s002Bean.getJpyUnit())));
        sonekiMap.put("EigyogaiJt", sUtils.exeFormatUnit(sUtils.switchingCurrencyUnit(sonekiList.getEigyogaiJt(), s002Bean.getJpyUnit())));
        sonekiMap.put("EigyogaiMh", sUtils.exeFormatUnit(sUtils.switchingCurrencyUnit(sonekiList.getEigyogaiMh(), s002Bean.getJpyUnit())));
        sonekiMap.put("EigyogaiSm", sUtils.exeFormatUnit(sUtils.switchingCurrencyUnit(sonekiList.getEigyogaiSm(), s002Bean.getJpyUnit())));
        sonekiMap.put("EigyogaiSt", sUtils.exeFormatUnit(sUtils.switchingCurrencyUnit(sonekiList.getEigyogaiSt(), s002Bean.getJpyUnit())));
        sonekiMap.put("EigyogaiHb", sUtils.exeFormatUnit(sUtils.switchingCurrencyUnit(sonekiList.getEigyogaiHb(), s002Bean.getJpyUnit())));
        sonekiMap.put("EigyogaiTr", sUtils.exeFormatUnit(sUtils.switchingCurrencyUnit(sonekiList.getEigyogaiTr(), s002Bean.getJpyUnit())));
        sonekiMap.put("EigyogaiFm", sUtils.exeFormatUnit(sUtils.switchingCurrencyUnit(sonekiList.getEigyogaiFm(), s002Bean.getJpyUnit())));
        sonekiMap.put("EigyogaiDiff", sUtils.exeFormatUnit(sUtils.switchingCurrencyUnit(sonekiList.getEigyogaiDiff(), s002Bean.getJpyUnit())));
        sonekiMap.put("EigyogaiPd", sUtils.exeFormatUnit(sUtils.switchingCurrencyUnit(sonekiList.getEigyogaiPd(), s002Bean.getJpyUnit())));
        sonekiMap.put("EigyogaiPt", sUtils.exeFormatUnit(sUtils.switchingCurrencyUnit(sonekiList.getEigyogaiPt(), s002Bean.getJpyUnit())));
        sonekiMap.put("EigyogaiPs", sUtils.exeFormatUnit(sUtils.switchingCurrencyUnit(sonekiList.getEigyogaiPs(), s002Bean.getJpyUnit())));
        sonekiMap.put("EigyogaiPrev", sUtils.exeFormatUnit(sUtils.switchingCurrencyUnit(sonekiList.getEigyogaiPrev(), s002Bean.getJpyUnit())));
        s002Bean.setSonekiList(sonekiMap);

        // 販直費カテゴリー別内訳
        List<HashMap<String, String>> categoryHanchokuMapList = new ArrayList<>();
        if (categoryHanchokuList != null) {
            for (int i = 0; i < categoryHanchokuList.size(); i++) {
                HashMap<String, String> categoryHanchokuMap = new HashMap<>();
                categoryHanchokuMap.put("categoryName", categoryHanchokuList.get(i).getCategoryName());
                categoryHanchokuMap.put("categoryCode", categoryHanchokuList.get(i).getCategoryCode());
                categoryHanchokuMap.put("HanChokuNetJs", sUtils.exeFormatUnit(sUtils.switchingCurrencyUnit(categoryHanchokuList.get(i).getHanchokuNetJs(), s002Bean.getJpyUnit())));
                categoryHanchokuMap.put("HanChokuNetJt", sUtils.exeFormatUnit(sUtils.switchingCurrencyUnit(categoryHanchokuList.get(i).getHanchokuNetJt(), s002Bean.getJpyUnit())));
                categoryHanchokuMap.put("HanChokuNetMh", sUtils.exeFormatUnit(sUtils.switchingCurrencyUnit(categoryHanchokuList.get(i).getHanchokuNetMh(), s002Bean.getJpyUnit())));
                categoryHanchokuMap.put("HanChokuNetSm", sUtils.exeFormatUnit(sUtils.switchingCurrencyUnit(categoryHanchokuList.get(i).getHanchokuNetSm(), s002Bean.getJpyUnit())));
                categoryHanchokuMap.put("HanChokuNetSt", sUtils.exeFormatUnit(sUtils.switchingCurrencyUnit(categoryHanchokuList.get(i).getHanchokuNetSt(), s002Bean.getJpyUnit())));
                categoryHanchokuMap.put("HanChokuNetHb", sUtils.exeFormatUnit(sUtils.switchingCurrencyUnit(categoryHanchokuList.get(i).getHanchokuNetHb(), s002Bean.getJpyUnit())));
                categoryHanchokuMap.put("HanChokuNetTr", sUtils.exeFormatUnit(sUtils.switchingCurrencyUnit(categoryHanchokuList.get(i).getHanchokuNetTr(), s002Bean.getJpyUnit())));
                categoryHanchokuMap.put("HanChokuNetFm", sUtils.exeFormatUnit(sUtils.switchingCurrencyUnit(categoryHanchokuList.get(i).getHanchokuNetFm(), s002Bean.getJpyUnit())));
                categoryHanchokuMap.put("HanChokuNetDiff", sUtils.exeFormatUnit(sUtils.switchingCurrencyUnit(categoryHanchokuList.get(i).getHanchokuNetDiff(), s002Bean.getJpyUnit())));
                categoryHanchokuMap.put("HanChokuNetPd", sUtils.exeFormatUnit(sUtils.switchingCurrencyUnit(categoryHanchokuList.get(i).getHanchokuNetPd(), s002Bean.getJpyUnit())));
                categoryHanchokuMap.put("HanChokuNetPt", sUtils.exeFormatUnit(sUtils.switchingCurrencyUnit(categoryHanchokuList.get(i).getHanchokuNetPt(), s002Bean.getJpyUnit())));
                categoryHanchokuMap.put("HanChokuNetPs", sUtils.exeFormatUnit(sUtils.switchingCurrencyUnit(categoryHanchokuList.get(i).getHanchokuNetPs(), s002Bean.getJpyUnit())));
                categoryHanchokuMap.put("HanChokuNetPrev", sUtils.exeFormatUnit(sUtils.switchingCurrencyUnit(categoryHanchokuList.get(i).getHanchokuNetPrev(), s002Bean.getJpyUnit())));
                categoryHanchokuMapList.add(categoryHanchokuMap);
            }
        }
        s002Bean.setCategoryHanchokuList(categoryHanchokuMapList);
    }

    /**
     * 回収
     *
     * @param condition
     */
    private void kaisyuAmount(final Map<String, Object> condition) {
        ArrayList<HashMap<String, String>> kaisyuList = new ArrayList();
        Map<String, Object> paramMap = new HashMap<>(condition);

        String kanjyoYm = DateUtils.getString(detailHeader.getKanjoDate(), DateUtils.getMONTH_MEDIUM_SIMPLE_PATTERN());
        paramMap.put("kanjyoYm", kanjyoYm);

        List<KaisyuList> list = s002Facade.findKaisyuList(paramMap);
        for (int i = 0; i < list.size(); i++) {
            HashMap<String, String> kaisyuMap = new HashMap<>();
            Integer unit;
            if (list.get(i).getCurrencyCode().equals(ConstantString.currencyCodeEn)) {
                unit = s002Bean.getJpyUnit();
            } else {
                unit = 1;
            }
            kaisyuMap.put("ankenId", list.get(i).getAnkenId());
            kaisyuMap.put("rirekiId", Integer.toString(list.get(i).getRirekiId()));
            kaisyuMap.put("currencyCode", list.get(i).getCurrencyCode());
            kaisyuMap.put("ruikeiKaisyuAmount", sUtils.exeFormatUnitRate(sUtils.switchingCurrencyUnit(list.get(i).getRuikeiKaisyuAmount(), unit, list.get(i).getCurrencyCode()), list.get(i).getCurrencyCode()));
            kaisyuMap.put("kaisyuAmount", sUtils.exeFormatUnitRate(sUtils.switchingCurrencyUnit(list.get(i).getKaisyuAmount(), unit, list.get(i).getCurrencyCode()), list.get(i).getCurrencyCode()));
            kaisyuMap.put("miKaisyuAmount", sUtils.exeFormatUnitRate(sUtils.switchingCurrencyUnit(list.get(i).getMiKaisyuAmount(), unit, list.get(i).getCurrencyCode()), list.get(i).getCurrencyCode()));
            kaisyuMap.put("kaisyuRate", sUtils.mrate(list.get(i).getKaisyuAmount(), list.get(i).getRuikeiKaisyuAmount()));
            kaisyuList.add(kaisyuMap);
        }
        s002Bean.setKaisyuList(kaisyuList);
    }

    /**
     * 備考有無チェック
     *
     * @return
     */
    private HashMap<String, String> setBikoFlg() {
        HashMap<String, String> ret = new HashMap<>();
        String[] dataKbn = new String[]{"SM", "JS", "JT", "MH", "ST", "HB", "TR", "PREV", "FM", "DIFF", "PD", "PT", "PS"};

        for (String dataKbn1 : dataKbn) {
            // 前回値と差分は備考ボタンを表示しない
            if ((dataKbn1.equals("PREV")) || (dataKbn1.equals("DIFF"))) {
                ret.put(dataKbn1, "0");
            } else if (authorityUtils.enableFlg("TUKIBIKO_DISP", detailHeader.getDivisionCode(), s002Bean.getRirekiFlg()) != 1) { // 備考ボタン表示権限がない場合は、常に非表示
                ret.put(dataKbn1, "0");
            } else if (s002Bean.isEdit()) { // 編集モードでは備考を入力可能にするため、常に表示
                ret.put(dataKbn1, "1");
            } else {
                SyuKiBikou entity = syuKiBikouFacade.findPk(s002Bean.getAnkenId(), new Integer(s002Bean.getRirekiId()), dataKbn1, s002Bean.getRirekiFlg());
                if (entity != null && StringUtils.isNotEmpty(entity.getBikou())) {
                    ret.put(dataKbn1, "1");
                } else {
                    ret.put(dataKbn1, "0");
                }
            }
        }
        return ret;
    }

    /**
     * 保存処理
     * @param processFlg 処理区分(0:通常の保存処理 1:最新値更新)
     */
    public void saveExecute(int processFlg) throws Exception {
        // ヘッダー情報(案件基本情報 等)の取得
        editDispHeader();

        // 案件データ
        updateSyuGeBukenInfoTbl();

        // 損益表
        updateSyuSaSpCurTbl();
        updateSyuSaNetCateTitleTbl();
        updateSyuSaHanCateTitleTbl();
        updateSyuSaSonekiTitleTbl();
//        updateSyuSaSeibansonekiTbl();

        // 集計処理API
        // 各SP、NET等の合計行の集計値を計算/保存するAPIを実行する（APIの存在＋I/Oは別途TSIS様に確認(Q/A)）。
        // (原子力)収益管理システム連携API
        // 対象案件が原子力案件(SYU_GE_BUKKEN_INFO_TBL.DIVISION_CODE=’N7’)の場合、対象データの備考を(原子力)収益管理システムに連携する。
        // ankenEntity.getDivisionCode()
        // 詳細は(原子力)収益管理システム連携APIの基本設計書＋詳細設計書を参照
        // 操作ログ
        registOperationLog();

        // 再計算パッケージ(TSIS様作成)呼び出し
        callUpdateDataProcedureExecute(processFlg);
    }

    /**
     * データ更新用のパッケージを実行
     * @param processFlg 処理区分(0:通常の保存処理 1:最新値更新)
     */
    public void callUpdateDataProcedureExecute(int processFlg) throws Exception {
        String recalProcFlg = "2";

        if (processFlg == 1) {
            // 最新値更新パッケージ(TSIS様作成)呼出し
            storedProceduresService.callUpdateNewData(s002Bean.getAnkenId(), s002Bean.getRirekiId(), s002Bean.getUpdateNewDataKbn());
            recalProcFlg = "4";   // 最新値更新パッケージ実行の場合、後続の再計算処理の処理フラグ(PROC_FLG)は"4"にする。
        }

        // 再計算パッケージ(TSIS様作成)呼び出し
        storedProceduresService.callAnkenRecalAuto(s002Bean.getAnkenId(), s002Bean.getRirekiId(), recalProcFlg);
    }

    /**
     * 収益物件TBL更新
     */
    private void updateSyuGeBukenInfoTbl() {
        SyuGeBukkenInfoTbl entity = new SyuGeBukkenInfoTbl();
        entity.setAnkenId(s002Bean.getAnkenId());
        entity.setAnkenRev(Long.parseLong(s002Bean.getAnkenRev()));
        entity.setRirekiId(Integer.parseInt(s002Bean.getRirekiId()));
        entity.setSpKakuteiFlg((StringUtils.defaultString(s002Bean.getSpKakuteiFlg(), "0").equals("1") ? "1" : "0"));
        entity.setNetKakuteiFlg((StringUtils.defaultString(s002Bean.getNetKakuteiFlg(), "0").equals("1") ? "1" : "0"));
        entity.setBikouFixedMikomi(s002Bean.getBikou());
        EntityUtils.setCreatedInfo(entity, loginUserInfo.getUserId());
        syuGeBukenInfoTblFacade.setSpKakuteiFlg(entity);
    }

    /**
     * 最終見込損益TBL 通貨詳細更新
     */
    private void updateSyuSaSpCurTbl() {
        if (s002Bean.getCurrencyRateMapList() == null) {
            return;
        }

        // 画面からレートと金額を取得(レート&金額がNULLの場合はSQL側ではじく)
        for (HashMap<String, String> currencyRateMap : s002Bean.getCurrencyRateMapList()) {
            // 通貨コード,データ区分ごとに更新
            SyuSaSpCurTbl entity = new SyuSaSpCurTbl();
            entity.setAnkenId(s002Bean.getAnkenId());
            entity.setRirekiId(Integer.parseInt(s002Bean.getRirekiId()));
            entity.setDataKbn("SM");
            entity.setCurrencyCode(currencyRateMap.get("CurrencyCode"));
            if (currencyRateMap.get("CurrencyCode").equals(ConstantString.currencyCodeEn)) {
                if (StringUtil.isNotEmpty(currencyRateMap.get("KeiyakuAmountSm"))) {
                    entity.setKeiyakuRate(BigDecimal.ONE);
                }
            } else {
                entity.setKeiyakuRate(NumberUtils.changeBigDecimal(currencyRateMap.get("KeiyakuRateSm")));
            }
            entity.setKeiyakuAmount(NumberUtils.changeBigDecimal(currencyRateMap.get("KeiyakuAmountSm")));
            EntityUtils.setCreatedInfo(entity, loginUserInfo.getUserId());
            syuSaSpCurTblFacade.setKeiyakuAmount(entity);

            entity = new SyuSaSpCurTbl();
            entity.setAnkenId(s002Bean.getAnkenId());
            entity.setRirekiId(Integer.parseInt(s002Bean.getRirekiId()));
            entity.setDataKbn("JS");
            entity.setCurrencyCode(currencyRateMap.get("CurrencyCode"));
            if (currencyRateMap.get("CurrencyCode").equals(ConstantString.currencyCodeEn)) {
                if (StringUtil.isNotEmpty(currencyRateMap.get("KeiyakuAmountJs"))) {
                    entity.setKeiyakuRate(BigDecimal.ONE);
                }
            } else {
                entity.setKeiyakuRate(NumberUtils.changeBigDecimal(currencyRateMap.get("KeiyakuRateJs")));
            }
            entity.setKeiyakuAmount(NumberUtils.changeBigDecimal(currencyRateMap.get("KeiyakuAmountJs")));
            EntityUtils.setCreatedInfo(entity, loginUserInfo.getUserId());
            syuSaSpCurTblFacade.setKeiyakuAmount(entity);

            entity = new SyuSaSpCurTbl();
            entity.setAnkenId(s002Bean.getAnkenId());
            entity.setRirekiId(Integer.parseInt(s002Bean.getRirekiId()));
            entity.setDataKbn("JT");
            entity.setCurrencyCode(currencyRateMap.get("CurrencyCode"));
            if (currencyRateMap.get("CurrencyCode").equals(ConstantString.currencyCodeEn)) {
                if (StringUtil.isNotEmpty(currencyRateMap.get("KeiyakuAmountJt"))) {
                    entity.setKeiyakuRate(BigDecimal.ONE);
                }
            } else {
                entity.setKeiyakuRate(NumberUtils.changeBigDecimal(currencyRateMap.get("KeiyakuRateJt")));
            }
            entity.setKeiyakuAmount(NumberUtils.changeBigDecimal(currencyRateMap.get("KeiyakuAmountJt")));
            EntityUtils.setCreatedInfo(entity, loginUserInfo.getUserId());
            syuSaSpCurTblFacade.setKeiyakuAmount(entity);

            entity = new SyuSaSpCurTbl();
            entity.setAnkenId(s002Bean.getAnkenId());
            entity.setRirekiId(Integer.parseInt(s002Bean.getRirekiId()));
            entity.setDataKbn("MH");
            entity.setCurrencyCode(currencyRateMap.get("CurrencyCode"));
            if (currencyRateMap.get("CurrencyCode").equals(ConstantString.currencyCodeEn)) {
                if (StringUtil.isNotEmpty(currencyRateMap.get("KeiyakuAmountMh"))) {
                    entity.setKeiyakuRate(BigDecimal.ONE);
                }
            } else {
                entity.setKeiyakuRate(NumberUtils.changeBigDecimal(currencyRateMap.get("KeiyakuRateMh")));
            }
            entity.setKeiyakuAmount(NumberUtils.changeBigDecimal(currencyRateMap.get("KeiyakuAmountMh")));
            EntityUtils.setCreatedInfo(entity, loginUserInfo.getUserId());
            syuSaSpCurTblFacade.setKeiyakuAmount(entity);

            entity = new SyuSaSpCurTbl();
            entity.setAnkenId(s002Bean.getAnkenId());
            entity.setRirekiId(Integer.parseInt(s002Bean.getRirekiId()));
            entity.setDataKbn("FM");
            entity.setCurrencyCode(currencyRateMap.get("CurrencyCode"));
            if (currencyRateMap.get("CurrencyCode").equals(ConstantString.currencyCodeEn)) {
                if (StringUtil.isNotEmpty(currencyRateMap.get("KeiyakuAmountFm"))) {
                    entity.setKeiyakuRate(BigDecimal.ONE);
                }
            } else {
                entity.setKeiyakuRate(NumberUtils.changeBigDecimal(currencyRateMap.get("KeiyakuRateFm")));
            }
            entity.setKeiyakuAmount(NumberUtils.changeBigDecimal(currencyRateMap.get("KeiyakuAmountFm")));
            EntityUtils.setCreatedInfo(entity, loginUserInfo.getUserId());
            syuSaSpCurTblFacade.setKeiyakuAmount(entity);

            if (s002Bean.getPotentialFlg().equals("1")) {
                entity = new SyuSaSpCurTbl();
                entity.setAnkenId(s002Bean.getAnkenId());
                entity.setRirekiId(Integer.parseInt(s002Bean.getRirekiId()));
                entity.setDataKbn("PD");
                entity.setCurrencyCode(currencyRateMap.get("CurrencyCode"));
                if (currencyRateMap.get("CurrencyCode").equals(ConstantString.currencyCodeEn)) {
                    if (StringUtil.isNotEmpty(currencyRateMap.get("KeiyakuAmountPd"))) {
                        entity.setKeiyakuRate(BigDecimal.ONE);
                    }
                } else {
                    entity.setKeiyakuRate(NumberUtils.changeBigDecimal(currencyRateMap.get("KeiyakuRatePd")));
                }
                entity.setKeiyakuAmount(NumberUtils.changeBigDecimal(currencyRateMap.get("KeiyakuAmountPd")));
                EntityUtils.setCreatedInfo(entity, loginUserInfo.getUserId());
                syuSaSpCurTblFacade.setKeiyakuAmount(entity);

                entity = new SyuSaSpCurTbl();
                entity.setAnkenId(s002Bean.getAnkenId());
                entity.setRirekiId(Integer.parseInt(s002Bean.getRirekiId()));
                entity.setDataKbn("PT");
                entity.setCurrencyCode(currencyRateMap.get("CurrencyCode"));
                if (currencyRateMap.get("CurrencyCode").equals(ConstantString.currencyCodeEn)) {
                    if (StringUtil.isNotEmpty(currencyRateMap.get("KeiyakuAmountPt"))) {
                        entity.setKeiyakuRate(BigDecimal.ONE);

                    }
                } else {
                    entity.setKeiyakuRate(NumberUtils.changeBigDecimal(currencyRateMap.get("KeiyakuRatePt")));
                }
                entity.setKeiyakuAmount(NumberUtils.changeBigDecimal(currencyRateMap.get("KeiyakuAmountPt")));
                EntityUtils.setCreatedInfo(entity, loginUserInfo.getUserId());
                syuSaSpCurTblFacade.setKeiyakuAmount(entity);

                entity = new SyuSaSpCurTbl();
                entity.setAnkenId(s002Bean.getAnkenId());
                entity.setRirekiId(Integer.parseInt(s002Bean.getRirekiId()));
                entity.setDataKbn("PS");
                entity.setCurrencyCode(currencyRateMap.get("CurrencyCode"));
                if (currencyRateMap.get("CurrencyCode").equals(ConstantString.currencyCodeEn)) {
                    if (StringUtil.isNotEmpty(currencyRateMap.get("KeiyakuAmountPs"))) {
                        entity.setKeiyakuRate(BigDecimal.ONE);
                    }
                } else {
                    entity.setKeiyakuRate(NumberUtils.changeBigDecimal(currencyRateMap.get("KeiyakuRatePs")));
                }
                entity.setKeiyakuAmount(NumberUtils.changeBigDecimal(currencyRateMap.get("KeiyakuAmountPs")));
                EntityUtils.setCreatedInfo(entity, loginUserInfo.getUserId());
                syuSaSpCurTblFacade.setKeiyakuAmount(entity);
            }
        }
    }

    /**
     * 最終見込損益TBL(原価) カテゴリ別-詳細
     */
    private void updateSyuSaNetCateTitleTbl() {
        if (s002Bean.getCostList() == null) {
            return;
        }

        for (HashMap<String, String> costMap : s002Bean.getCostList()) {
            SyuSaNetCateTbl entity = new SyuSaNetCateTbl();
            entity.setAnkenId(s002Bean.getAnkenId());
            entity.setRirekiId(Integer.parseInt(s002Bean.getRirekiId()));
            entity.setDataKbn("SM");
            entity.setCategoryCode(costMap.get("CategoryCode"));
            entity.setCategoryKbn1(costMap.get("CategoryKbn1"));
            entity.setCategoryKbn2(costMap.get("CategoryKbn2"));
            entity.setNet(NumberUtils.convLong(costMap.get("UriageNetSm")));
            EntityUtils.setCreatedInfo(entity, loginUserInfo.getUserId());
            syuSaNetCateTblFacade.setNet(entity);

            entity = new SyuSaNetCateTbl();
            entity.setAnkenId(s002Bean.getAnkenId());
            entity.setRirekiId(Integer.parseInt(s002Bean.getRirekiId()));
            entity.setDataKbn("JS");
            entity.setCategoryCode(costMap.get("CategoryCode"));
            entity.setCategoryKbn1(costMap.get("CategoryKbn1"));
            entity.setCategoryKbn2(costMap.get("CategoryKbn2"));
            entity.setNet(NumberUtils.convLong(costMap.get("UriageNetJs")));
            EntityUtils.setCreatedInfo(entity, loginUserInfo.getUserId());
            syuSaNetCateTblFacade.setNet(entity);

            entity = new SyuSaNetCateTbl();
            entity.setAnkenId(s002Bean.getAnkenId());
            entity.setRirekiId(Integer.parseInt(s002Bean.getRirekiId()));
            entity.setDataKbn("JT");
            entity.setCategoryCode(costMap.get("CategoryCode"));
            entity.setCategoryKbn1(costMap.get("CategoryKbn1"));
            entity.setCategoryKbn2(costMap.get("CategoryKbn2"));
            entity.setNet(NumberUtils.convLong(costMap.get("UriageNetJt")));
            EntityUtils.setCreatedInfo(entity, loginUserInfo.getUserId());
            syuSaNetCateTblFacade.setNet(entity);

            entity = new SyuSaNetCateTbl();
            entity.setAnkenId(s002Bean.getAnkenId());
            entity.setRirekiId(Integer.parseInt(s002Bean.getRirekiId()));
            entity.setDataKbn("MH");
            entity.setCategoryCode(costMap.get("CategoryCode"));
            entity.setCategoryKbn1(costMap.get("CategoryKbn1"));
            entity.setCategoryKbn2(costMap.get("CategoryKbn2"));
            entity.setNet(NumberUtils.convLong(costMap.get("UriageNetMh")));
            EntityUtils.setCreatedInfo(entity, loginUserInfo.getUserId());
            syuSaNetCateTblFacade.setNet(entity);

            entity = new SyuSaNetCateTbl();
            entity.setAnkenId(s002Bean.getAnkenId());
            entity.setRirekiId(Integer.parseInt(s002Bean.getRirekiId()));
            entity.setDataKbn("FM");
            entity.setCategoryCode(costMap.get("CategoryCode"));
            entity.setCategoryKbn1(costMap.get("CategoryKbn1"));
            entity.setCategoryKbn2(costMap.get("CategoryKbn2"));
            entity.setNet(NumberUtils.convLong(costMap.get("UriageNetFm")));
            EntityUtils.setCreatedInfo(entity, loginUserInfo.getUserId());
            syuSaNetCateTblFacade.setNet(entity);

            if (s002Bean.getPotentialFlg().equals("1")) {
                entity = new SyuSaNetCateTbl();
                entity.setAnkenId(s002Bean.getAnkenId());
                entity.setRirekiId(Integer.parseInt(s002Bean.getRirekiId()));
                entity.setDataKbn("PD");
                entity.setCategoryCode(costMap.get("CategoryCode"));
                entity.setCategoryKbn1(costMap.get("CategoryKbn1"));
                entity.setCategoryKbn2(costMap.get("CategoryKbn2"));
                entity.setNet(NumberUtils.convLong(costMap.get("UriageNetPd")));
                EntityUtils.setCreatedInfo(entity, loginUserInfo.getUserId());
                syuSaNetCateTblFacade.setNet(entity);

                entity = new SyuSaNetCateTbl();
                entity.setAnkenId(s002Bean.getAnkenId());
                entity.setRirekiId(Integer.parseInt(s002Bean.getRirekiId()));
                entity.setDataKbn("PT");
                entity.setCategoryCode(costMap.get("CategoryCode"));
                entity.setCategoryKbn1(costMap.get("CategoryKbn1"));
                entity.setCategoryKbn2(costMap.get("CategoryKbn2"));
                entity.setNet(NumberUtils.convLong(costMap.get("UriageNetPt")));
                EntityUtils.setCreatedInfo(entity, loginUserInfo.getUserId());
                syuSaNetCateTblFacade.setNet(entity);

                entity = new SyuSaNetCateTbl();
                entity.setAnkenId(s002Bean.getAnkenId());
                entity.setRirekiId(Integer.parseInt(s002Bean.getRirekiId()));
                entity.setDataKbn("PS");
                entity.setCategoryCode(costMap.get("CategoryCode"));
                entity.setCategoryKbn1(costMap.get("CategoryKbn1"));
                entity.setCategoryKbn2(costMap.get("CategoryKbn2"));
                entity.setNet(NumberUtils.convLong(costMap.get("UriageNetPs")));
                EntityUtils.setCreatedInfo(entity, loginUserInfo.getUserId());
                syuSaNetCateTblFacade.setNet(entity);
            }
        }
    }

    /**
     * 最終見込損益TBL(原価) 販直費-カテゴリ別-詳細
     */
    private void updateSyuSaHanCateTitleTbl() {
        if (s002Bean.getCategoryHanchokuList() == null) {
            return;
        }

        for (HashMap<String, String> hanchokuMap : s002Bean.getCategoryHanchokuList()) {
            SyuSaHanCateTbl entity = new SyuSaHanCateTbl();
            entity.setAnkenId(s002Bean.getAnkenId());
            entity.setRirekiId(Integer.parseInt(s002Bean.getRirekiId()));
            entity.setDataKbn("SM");
            entity.setCategoryCode(hanchokuMap.get("CategoryCode"));
            entity.setHanChokuNet(NumberUtils.changeBigDecimal(hanchokuMap.get("HanChokuNetSm")));
            EntityUtils.setCreatedInfo(entity, loginUserInfo.getUserId());
            syuSaHanCateTblFacade.setHanChokuNet(entity);

            entity = new SyuSaHanCateTbl();
            entity.setAnkenId(s002Bean.getAnkenId());
            entity.setRirekiId(Integer.parseInt(s002Bean.getRirekiId()));
            entity.setDataKbn("JS");
            entity.setCategoryCode(hanchokuMap.get("CategoryCode"));
            entity.setHanChokuNet(NumberUtils.changeBigDecimal(hanchokuMap.get("HanChokuNetJs")));
            EntityUtils.setCreatedInfo(entity, loginUserInfo.getUserId());
            syuSaHanCateTblFacade.setHanChokuNet(entity);

            entity = new SyuSaHanCateTbl();
            entity.setAnkenId(s002Bean.getAnkenId());
            entity.setRirekiId(Integer.parseInt(s002Bean.getRirekiId()));
            entity.setDataKbn("JT");
            entity.setCategoryCode(hanchokuMap.get("CategoryCode"));
            entity.setHanChokuNet(NumberUtils.changeBigDecimal(hanchokuMap.get("HanChokuNetJt")));
            EntityUtils.setCreatedInfo(entity, loginUserInfo.getUserId());
            syuSaHanCateTblFacade.setHanChokuNet(entity);

            entity = new SyuSaHanCateTbl();
            entity.setAnkenId(s002Bean.getAnkenId());
            entity.setRirekiId(Integer.parseInt(s002Bean.getRirekiId()));
            entity.setDataKbn("MH");
            entity.setCategoryCode(hanchokuMap.get("CategoryCode"));
            entity.setHanChokuNet(NumberUtils.changeBigDecimal(hanchokuMap.get("HanChokuNetMh")));
            EntityUtils.setCreatedInfo(entity, loginUserInfo.getUserId());
            syuSaHanCateTblFacade.setHanChokuNet(entity);

            entity = new SyuSaHanCateTbl();
            entity.setAnkenId(s002Bean.getAnkenId());
            entity.setRirekiId(Integer.parseInt(s002Bean.getRirekiId()));
            entity.setDataKbn("FM");
            entity.setCategoryCode(hanchokuMap.get("CategoryCode"));
            entity.setHanChokuNet(NumberUtils.changeBigDecimal(hanchokuMap.get("HanChokuNetFm")));
            EntityUtils.setCreatedInfo(entity, loginUserInfo.getUserId());
            syuSaHanCateTblFacade.setHanChokuNet(entity);

            if (s002Bean.getPotentialFlg().equals("1")) {
                entity = new SyuSaHanCateTbl();
                entity.setAnkenId(s002Bean.getAnkenId());
                entity.setRirekiId(Integer.parseInt(s002Bean.getRirekiId()));
                entity.setDataKbn("PD");
                entity.setCategoryCode(hanchokuMap.get("CategoryCode"));
                entity.setHanChokuNet(NumberUtils.changeBigDecimal(hanchokuMap.get("HanChokuNetPd")));
                EntityUtils.setCreatedInfo(entity, loginUserInfo.getUserId());
                syuSaHanCateTblFacade.setHanChokuNet(entity);

                entity = new SyuSaHanCateTbl();
                entity.setAnkenId(s002Bean.getAnkenId());
                entity.setRirekiId(Integer.parseInt(s002Bean.getRirekiId()));
                entity.setDataKbn("PT");
                entity.setCategoryCode(hanchokuMap.get("CategoryCode"));
                entity.setHanChokuNet(NumberUtils.changeBigDecimal(hanchokuMap.get("HanChokuNetPt")));
                EntityUtils.setCreatedInfo(entity, loginUserInfo.getUserId());
                syuSaHanCateTblFacade.setHanChokuNet(entity);

                entity = new SyuSaHanCateTbl();
                entity.setAnkenId(s002Bean.getAnkenId());
                entity.setRirekiId(Integer.parseInt(s002Bean.getRirekiId()));
                entity.setDataKbn("PS");
                entity.setCategoryCode(hanchokuMap.get("CategoryCode"));
                entity.setHanChokuNet(NumberUtils.changeBigDecimal(hanchokuMap.get("HanChokuNetPs")));
                EntityUtils.setCreatedInfo(entity, loginUserInfo.getUserId());
                syuSaHanCateTblFacade.setHanChokuNet(entity);
            }
        }
    }

    /**
     * 最終見込損益TBL(原価) 損益項目タイトル
     */
    private void updateSyuSaSonekiTitleTbl() {
        if (s002Bean.getSonekiEditList() == null) {
            return;
        }

        for (HashMap<String, String> sonekiMap : s002Bean.getSonekiEditList()) {
            SyuSaSonekiTitleTbl entity = new SyuSaSonekiTitleTbl();
            entity.setAnkenId(s002Bean.getAnkenId());
            entity.setRirekiId(Integer.parseInt(s002Bean.getRirekiId()));
            entity.setDataKbn("SM");
            entity.setIspNet(NumberUtils.convLong(sonekiMap.get("IspNetSm")));
            entity.setHanKanNet(NumberUtils.convLong(sonekiMap.get("HanKanNetSm")));
            entity.setKawaseYoyakuNet(NumberUtils.convLong(sonekiMap.get("KawaseYoyakuNetSm")));
            EntityUtils.setCreatedInfo(entity, loginUserInfo.getUserId());
            syuSaSonekiTitleTblFacade.setSonekiNet(entity);

            entity = new SyuSaSonekiTitleTbl();
            entity.setAnkenId(s002Bean.getAnkenId());
            entity.setRirekiId(Integer.parseInt(s002Bean.getRirekiId()));
            entity.setDataKbn("JS");
            entity.setIspNet(NumberUtils.convLong(sonekiMap.get("IspNetJs")));
            entity.setHanKanNet(NumberUtils.convLong(sonekiMap.get("HanKanNetJs")));
            entity.setKawaseYoyakuNet(NumberUtils.convLong(sonekiMap.get("KawaseYoyakuNetJs")));
            EntityUtils.setCreatedInfo(entity, loginUserInfo.getUserId());
            syuSaSonekiTitleTblFacade.setSonekiNet(entity);

            entity = new SyuSaSonekiTitleTbl();
            entity.setAnkenId(s002Bean.getAnkenId());
            entity.setRirekiId(Integer.parseInt(s002Bean.getRirekiId()));
            entity.setDataKbn("JT");
            entity.setIspNet(NumberUtils.convLong(sonekiMap.get("IspNetJt")));
            entity.setHanKanNet(NumberUtils.convLong(sonekiMap.get("HanKanNetJt")));
            entity.setKawaseYoyakuNet(NumberUtils.convLong(sonekiMap.get("KawaseYoyakuNetJt")));
            EntityUtils.setCreatedInfo(entity, loginUserInfo.getUserId());
            syuSaSonekiTitleTblFacade.setSonekiNet(entity);

            entity = new SyuSaSonekiTitleTbl();
            entity.setAnkenId(s002Bean.getAnkenId());
            entity.setRirekiId(Integer.parseInt(s002Bean.getRirekiId()));
            entity.setDataKbn("MH");
            entity.setIspNet(NumberUtils.convLong(sonekiMap.get("IspNetMh")));
            entity.setHanKanNet(NumberUtils.convLong(sonekiMap.get("HanKanNetMh")));
            entity.setKawaseYoyakuNet(NumberUtils.convLong(sonekiMap.get("KawaseYoyakuNetMh")));
            EntityUtils.setCreatedInfo(entity, loginUserInfo.getUserId());
            syuSaSonekiTitleTblFacade.setSonekiNet(entity);

            entity = new SyuSaSonekiTitleTbl();
            entity.setAnkenId(s002Bean.getAnkenId());
            entity.setRirekiId(Integer.parseInt(s002Bean.getRirekiId()));
            entity.setDataKbn("FM");
            entity.setIspNet(NumberUtils.convLong(sonekiMap.get("IspNetFm")));
            entity.setHanKanNet(NumberUtils.convLong(sonekiMap.get("HanKanNetFm")));
            entity.setKawaseYoyakuNet(NumberUtils.convLong(sonekiMap.get("KawaseYoyakuNetFm")));
            EntityUtils.setCreatedInfo(entity, loginUserInfo.getUserId());
            syuSaSonekiTitleTblFacade.setSonekiNet(entity);

            if (s002Bean.getPotentialFlg().equals("1")) {
                entity = new SyuSaSonekiTitleTbl();
                entity.setAnkenId(s002Bean.getAnkenId());
                entity.setRirekiId(Integer.parseInt(s002Bean.getRirekiId()));
                entity.setDataKbn("PD");
                entity.setIspNet(NumberUtils.convLong(sonekiMap.get("IspNetPd")));
                entity.setHanKanNet(NumberUtils.convLong(sonekiMap.get("HanKanNetPd")));
                entity.setKawaseYoyakuNet(NumberUtils.convLong(sonekiMap.get("KawaseYoyakuNetPd")));
                EntityUtils.setCreatedInfo(entity, loginUserInfo.getUserId());
                syuSaSonekiTitleTblFacade.setSonekiNet(entity);

                entity = new SyuSaSonekiTitleTbl();
                entity.setAnkenId(s002Bean.getAnkenId());
                entity.setRirekiId(Integer.parseInt(s002Bean.getRirekiId()));
                entity.setDataKbn("PT");
                entity.setIspNet(NumberUtils.convLong(sonekiMap.get("IspNetPt")));
                entity.setHanKanNet(NumberUtils.convLong(sonekiMap.get("HanKanNetPt")));
                entity.setKawaseYoyakuNet(NumberUtils.convLong(sonekiMap.get("KawaseYoyakuNetPt")));
                EntityUtils.setCreatedInfo(entity, loginUserInfo.getUserId());
                syuSaSonekiTitleTblFacade.setSonekiNet(entity);

                entity = new SyuSaSonekiTitleTbl();
                entity.setAnkenId(s002Bean.getAnkenId());
                entity.setRirekiId(Integer.parseInt(s002Bean.getRirekiId()));
                entity.setDataKbn("PS");
                entity.setIspNet(NumberUtils.convLong(sonekiMap.get("IspNetPs")));
                entity.setHanKanNet(NumberUtils.convLong(sonekiMap.get("HanKanNetPs")));
                entity.setKawaseYoyakuNet(NumberUtils.convLong(sonekiMap.get("KawaseYoyakuNetPs")));
                EntityUtils.setCreatedInfo(entity, loginUserInfo.getUserId());
                syuSaSonekiTitleTblFacade.setSonekiNet(entity);
            }
        }
    }

    /**
     * 最終見込損益TBL(原価) 製番損益-工場別
     */
    private void updateSyuSaSeibansonekiTbl() {
//        if (s002Bean.getProductSonekiList() == null) {
//            return;
//        }
//
//        for (HashMap<String, String> productSonekiMap : s002Bean.getProductSonekiList()) {
//            SyuSaSeibansonekiTbl entity = new SyuSaSeibansonekiTbl();
//            entity.setAnkenId(s002Bean.getAnkenId());
//            entity.setRirekiId(Integer.parseInt(s002Bean.getRirekiId()));
//            entity.setDataKbn("SM");
//            entity.setKojoCode(productSonekiMap.get("KojoCode"));
//            entity.setSeibanSonekiNet(NumberUtils.changeBigDecimal(productSonekiMap.get("SeibanSonekiNetSm")));
//            EntityUtils.setCreatedInfo(entity, loginUserInfo.getUserId());
//            syuSaSeibansonekiTblFacade.setSeibanSonekiNet(entity);
//
//            entity = new SyuSaSeibansonekiTbl();
//            entity.setAnkenId(s002Bean.getAnkenId());
//            entity.setRirekiId(Integer.parseInt(s002Bean.getRirekiId()));
//            entity.setDataKbn("JS");
//            entity.setKojoCode(productSonekiMap.get("KojoCode"));
//            entity.setSeibanSonekiNet(NumberUtils.changeBigDecimal(productSonekiMap.get("SeibanSonekiNetJs")));
//            EntityUtils.setCreatedInfo(entity, loginUserInfo.getUserId());
//            syuSaSeibansonekiTblFacade.setSeibanSonekiNet(entity);
//
//            entity = new SyuSaSeibansonekiTbl();
//            entity.setAnkenId(s002Bean.getAnkenId());
//            entity.setRirekiId(Integer.parseInt(s002Bean.getRirekiId()));
//            entity.setDataKbn("JT");
//            entity.setKojoCode(productSonekiMap.get("KojoCode"));
//            entity.setSeibanSonekiNet(NumberUtils.changeBigDecimal(productSonekiMap.get("SeibanSonekiNetJt")));
//            EntityUtils.setCreatedInfo(entity, loginUserInfo.getUserId());
//            syuSaSeibansonekiTblFacade.setSeibanSonekiNet(entity);
//
//            entity = new SyuSaSeibansonekiTbl();
//            entity.setAnkenId(s002Bean.getAnkenId());
//            entity.setRirekiId(Integer.parseInt(s002Bean.getRirekiId()));
//            entity.setDataKbn("MH");
//            entity.setKojoCode(productSonekiMap.get("KojoCode"));
//            entity.setSeibanSonekiNet(NumberUtils.changeBigDecimal(productSonekiMap.get("SeibanSonekiNetMh")));
//            EntityUtils.setCreatedInfo(entity, loginUserInfo.getUserId());
//            syuSaSeibansonekiTblFacade.setSeibanSonekiNet(entity);
//
//            entity = new SyuSaSeibansonekiTbl();
//            entity.setAnkenId(s002Bean.getAnkenId());
//            entity.setRirekiId(Integer.parseInt(s002Bean.getRirekiId()));
//            entity.setDataKbn("FM");
//            entity.setKojoCode(productSonekiMap.get("KojoCode"));
//            entity.setSeibanSonekiNet(NumberUtils.changeBigDecimal(productSonekiMap.get("SeibanSonekiNetFm")));
//            EntityUtils.setCreatedInfo(entity, loginUserInfo.getUserId());
//            syuSaSeibansonekiTblFacade.setSeibanSonekiNet(entity);
//
//            if (s002Bean.getPotentialFlg().equals("1")) {
//                entity = new SyuSaSeibansonekiTbl();
//                entity.setAnkenId(s002Bean.getAnkenId());
//                entity.setRirekiId(Integer.parseInt(s002Bean.getRirekiId()));
//                entity.setDataKbn("PD");
//                entity.setKojoCode(productSonekiMap.get("KojoCode"));
//                entity.setSeibanSonekiNet(NumberUtils.changeBigDecimal(productSonekiMap.get("SeibanSonekiNetPd")));
//                EntityUtils.setCreatedInfo(entity, loginUserInfo.getUserId());
//                syuSaSeibansonekiTblFacade.setSeibanSonekiNet(entity);
//
//                entity = new SyuSaSeibansonekiTbl();
//                entity.setAnkenId(s002Bean.getAnkenId());
//                entity.setRirekiId(Integer.parseInt(s002Bean.getRirekiId()));
//                entity.setDataKbn("PT");
//                entity.setKojoCode(productSonekiMap.get("KojoCode"));
//                entity.setSeibanSonekiNet(NumberUtils.changeBigDecimal(productSonekiMap.get("SeibanSonekiNetPt")));
//                EntityUtils.setCreatedInfo(entity, loginUserInfo.getUserId());
//                syuSaSeibansonekiTblFacade.setSeibanSonekiNet(entity);
//
//                entity = new SyuSaSeibansonekiTbl();
//                entity.setAnkenId(s002Bean.getAnkenId());
//                entity.setRirekiId(Integer.parseInt(s002Bean.getRirekiId()));
//                entity.setDataKbn("PS");
//                entity.setKojoCode(productSonekiMap.get("KojoCode"));
//                entity.setSeibanSonekiNet(NumberUtils.changeBigDecimal(productSonekiMap.get("SeibanSonekiNetPs")));
//                EntityUtils.setCreatedInfo(entity, loginUserInfo.getUserId());
//                syuSaSeibansonekiTblFacade.setSeibanSonekiNet(entity);
//            }
//        }
    }

    /**
     * ログ出力
     */
    private void registOperationLog() throws Exception {
        OperationLog operationLog = operationLogService.getOperationLog();

        String objectType = operationLogService.getObjectType(s002Bean.getProcId());

        operationLog.setOperationCode("SAVE_ONLINE");
        operationLog.setObjectId(20);
        operationLog.setObjectType(objectType);
        operationLog.setRemarks(s002Bean.getAnkenId());

        operationLogService.insertOperationLogSearch(operationLog);
    }
}
