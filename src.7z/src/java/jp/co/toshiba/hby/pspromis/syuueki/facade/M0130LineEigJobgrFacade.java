package jp.co.toshiba.hby.pspromis.syuueki.facade;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.inject.Inject;
import javax.ejb.Stateless;
import javax.interceptor.Interceptors;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import jp.co.toshiba.hby.pspromis.syuueki.interceptor.TranceInterceptor;
import jp.co.toshiba.hby.pspromis.syuueki.entity.M0130LineEigJobgr;
import jp.co.toshiba.hby.pspromis.syuueki.enums.Env;
import jp.co.toshiba.hby.pspromis.syuueki.pages.DivisonComponentPage;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;

/**
 *
 * @author ibayashi
 */
@Stateless
@Interceptors({TranceInterceptor.class})
public class M0130LineEigJobgrFacade extends AbstractFacade<M0130LineEigJobgr> {

    @PersistenceContext(unitName = jp.co.toshiba.hby.pspromis.syuueki.util.ConstantString.syuuekiDataSourceName)
    private EntityManager em;

    @Inject
    private DivisonComponentPage divisionComponentPage;
    
    @Override
    protected EntityManager getEntityManager() {
        return em;
    }

    public M0130LineEigJobgrFacade() {
        super(M0130LineEigJobgr.class);
    }

    public List<M0130LineEigJobgr> findLineEigNameList(Map<String, Object> condition) {
        List<M0130LineEigJobgr> list = sqlExecutor.getResultList(em, M0130LineEigJobgr.class, "/sql/lineEigJobGr/selectLineEigNameList.sql", condition);
        return list;
    }

    public List<String> findLineEigCodeList(String divisionCode, String lineTantoNm, boolean isTeamCodeAddBlank) {
        // 事業部コード:(原子力)であるかを判断
        String divisionNuclearFlg = "0";
        boolean isNuclearDivision = divisionComponentPage.isNuclearDivision(divisionCode);
        if (isNuclearDivision) {
            divisionNuclearFlg = "1";
        }
        
        Map<String, Object> condition = new HashMap<>();
        condition.put("divisionCode", divisionCode);
        condition.put("lineTantoNm", lineTantoNm);
        //condition.put("divNuclear", divNuclear);
        condition.put("divisionNuclearFlg", divisionNuclearFlg);

        List<M0130LineEigJobgr> list = sqlExecutor.getResultList(em, M0130LineEigJobgr.class, "/sql/lineEigJobGr/selectLineEigCodeList.sql", condition);
        
        List<String> resultList = null;
        if (CollectionUtils.isNotEmpty(list)) {
            resultList = new ArrayList<>();
            for (M0130LineEigJobgr entity: list) {
                String code = entity.getEigJobgrCd();

                if (StringUtils.isNotEmpty(code)) {
                    resultList.add(code);
                }
                
                // チームコードを取得する場合((原子力)以外)、支社チームコード(3桁チーム)の場合、頭ブランク2桁埋めしたものも取得するようにする
                // (GEのANKEN_TEAM_CODEにブランク2桁あるデータとないデータが混在する可能性があるため、両方を当てられるようにするための対策。trimはindex効かなくなるためやめたい)
                //if (!divNuclear.equals(divisionCode) && isTeamCodeAddBlank) {
                if ("0".equals(divisionNuclearFlg) && isTeamCodeAddBlank) {
                    if (StringUtils.length(code) == 3) {
                        resultList.add("  " + code);
                    }
                }
            }
        }

        return resultList;
    }

}
