/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package jp.co.toshiba.hby.pspromis.syuueki.bean;

import java.util.List;
import javax.inject.Named;
import javax.enterprise.context.RequestScoped;
import jp.co.toshiba.hby.pspromis.syuueki.entity.TeamEntity;
import lombok.Getter;
import lombok.Setter;

/**
 *
 * @author ibayashi
 */
@Named(value = "syuuekiCommonBean")
@RequestScoped
@Getter @Setter
public class SyuuekiCommonBean {

    /**
     * ログイン者保有のチームコード
     */
    List<TeamEntity> myTeamList;

}
