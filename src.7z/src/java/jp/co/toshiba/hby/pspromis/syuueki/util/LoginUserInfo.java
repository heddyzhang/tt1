package jp.co.toshiba.hby.pspromis.syuueki.util;

import java.io.Serializable;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
//import javax.enterprise.context.RequestScoped;
import javax.enterprise.context.SessionScoped;
import javax.inject.Named;
import javax.inject.Inject;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import jp.co.toshiba.hby.pspromis.common.auth.PSPromisSessionInfo;
import jp.co.toshiba.hby.pspromis.common.util.StringUtil;
import jp.co.toshiba.hby.pspromis.syuueki.dto.DivisionDto;
import jp.co.toshiba.hby.pspromis.syuueki.entity.BuMst;
import jp.co.toshiba.hby.pspromis.syuueki.entity.SyuGeBukkenInfoTbl;
import jp.co.toshiba.hby.pspromis.syuueki.entity.TeamEntity;
import jp.co.toshiba.hby.pspromis.syuueki.enums.Env;
//import jp.co.toshiba.hby.pspromis.syuueki.pages.DivisonComponentPage;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
/**
 * PS-Promis収益管理システム<br>
 * ログインユーザー情報を取得する<br>
 * PS-Promis共通セッションよりログイン者情報を取得してこのオブジェクトにセットする<br>
 * 
 * 各処理では、DI(Injectアノテーション)で参照可能となる。
 * @author ibayashi
 */
@Named(value = "loginUserInfo")
@SessionScoped
public class LoginUserInfo implements Serializable {
    private static final Logger log = LoggerFactory.getLogger(LoginUserInfo.class);
    
    //@Inject
    //private DivisonComponentPage divisionComponentPage;
    
    /**
     * ログイン者id
     */
    private String userId;

    /**
     * ログイン者氏名
     */
    private String userName;

    /**
     * ログイン者所属部課名
     */
    private String deptName;

    /**
     * ログイン者情報格納セッションid
     */
    private String sessionId;

    /**
     * ログイン者所属部課コード(セッションtbl)
     */
    private String departmentCd;
    
    /**
     * ログイン者所属部課コード(セッションtbl)
     */
    private String departmentName;

    /**
     * セッションテーブル情報取得FLG
     */
    private boolean isSessionTblInfo = false;

    /**
     * JobGr職種取得状況FLG
     */
    private boolean isJgrpSyokusyuInfo = false;
    
    /**
     * ログイン者所属事業部で、(表示上の)一番優先順位が高い事業部コード
     */
    private String priorityDivCode;

    /**
     * ログイン者JobGr情報<br>
     * key:division=事業部コード,JgrpId=所属JobGr,syokusyuCd=所属JobGrの職種
     */
    private List<Map<String, Object>> jobGrList;

    /**
     * PS-Promis共通セッションからログイン者の情報を取得(Filterからcall)
     * @param request 
     */
    public void setUserInfo(HttpServletRequest request) {
        String sessionName = Env.getValue(Env.LoginSessionName);
        HttpSession session = ((HttpServletRequest)request).getSession();
        PSPromisSessionInfo pspSessionInfo = (PSPromisSessionInfo)(session.getAttribute(sessionName));

        // セッションが異なる場合、再度取得
        if (pspSessionInfo != null) {
            //if (!StringUtils.defaultString(this.sessionId).equals(pspSessionInfo.getSessionId())) {
                this.userId = pspSessionInfo.getUserId();
                this.userName = pspSessionInfo.getUserName();
                this.deptName = pspSessionInfo.getDeptName();
                this.sessionId = pspSessionInfo.getSessionId();

                // PS-Promisポータルを介していない場合、プロパティに設定した仮セッションidをセットする(ローカル環境用)。
                if (StringUtil.isEmpty(this.sessionId)) {
                    String debugSessionId = Env.getValue(Env.DebugSessionId);
                    if (!StringUtil.isEmpty(debugSessionId)) {
                        this.sessionId = debugSessionId;
                    }
                }

                //this.isSessionTblInfo = false;
                //this.isJgrpSyokusyuInfo = false;
            //}
        }
    }

    public String getUserId() {
        return userId;
    }

    public String getUserName() {
        return userName;
    }

    public String getDeptName() {
        return deptName;
    }

    public String getSessionId() {
        return sessionId;
    }

    public boolean isIsSessionTblInfo() {
        return isSessionTblInfo;
    }

    public void setIsSessionTblInfo(boolean isSessionTblInfo) {
        this.isSessionTblInfo = isSessionTblInfo;
    }

    public List<Map<String, Object>> getJobGrList() {
        return jobGrList;
    }

    public void setJobGrList(List<Map<String, Object>> jobGrList) {
        this.jobGrList = jobGrList;
    }

    public boolean isIsJgrpSyokusyuInfo() {
        return isJgrpSyokusyuInfo;
    }

    public void setIsJgrpSyokusyuInfo(boolean isJgrpSyokusyuInfo) {
        this.isJgrpSyokusyuInfo = isJgrpSyokusyuInfo;
    }

    public String getDepartmentCd() {
        return departmentCd;
    }

    public void setDepartmentCd(String departmentCd) {
        this.departmentCd = departmentCd;
    }

    public String getDepartmentName() {
        return departmentName;
    }

    public void setDepartmentName(String departmentName) {
        this.departmentName = departmentName;
    }

    public String getPriorityDivCode() {
        return priorityDivCode;
    }

    public void setPriorityDivCode(String priorityDivCode) {
        this.priorityDivCode = priorityDivCode;
    }

    /**
     * ログイン者のJobGr職種情報の指定コードを配列で取得
     * @param key:<br>
     *     division=事業部コード,<br>
     *     JgrpId=所属JobGr,<br>
     *     syokusyuCd=所属JobGrの職種,<br>
     *     jgrpPetName=所属JobGrの名称,<br>
     *     divisionSubName=サブ事業部名称,<br>
     *     divisionSubCode=サブ事業部コード
     * @return 
     */
    public String[] getJobGrSyokusyuArrayInfo(String key) {
        if (jobGrList == null) {
            return null;
        }

        Set<String> codeList = new HashSet<>();
        for (Map<String, Object> entity : jobGrList) {
            String code = (String)entity.get(key);
            if (StringUtil.isNotEmpty(code)) {
                codeList.add(code);
            }
        }

        return (String[])codeList.toArray(new String[0]);
    }

    /**
     * ログイン者のJobGr職種情報の指定コードを配列で取得(指定した事業部のみ)
     * @param key:<br>
     *     division=事業部コード,<br>
     *     JgrpId=所属JobGr,<br>
     *     syokusyuCd=所属JobGrの職種,<br>
     *     jgrpPetName=所属JobGrの名称,<br>
     *     divisionSubName=サブ事業部名称,<br>
     *     divisionSubCode=サブ事業部コード
     * @param divisionCode この事業部に属するJobGrデータに限る
     * @return 
     */
    public String[] getJobGrSyokusyuArrayInfo(String key, String divisionCode) {
        if (jobGrList == null) {
            return null;
        }

        Set<String> codeList = new HashSet<>();
        for (Map<String, Object> entity : jobGrList) {
            String code = (String)entity.get(key);
            String dataDivisionCode = StringUtils.defaultString((String)entity.get("division"));
            if (dataDivisionCode.equals(divisionCode)) {
                if (StringUtil.isNotEmpty(code)) {
                    codeList.add(code);
                }
            }
        }

        return (String[])codeList.toArray(new String[0]);
    }
    
    /**
     * ログインユーザーの所属事業部を取得<br>
     * (原子力/火水ジ両方に所属する場合は火水ジ優先で取得)
     * @return 
     */
//    public String getPriorityDivCode() {
//        //String[] divCdAry = getJobGrSyokusyuArrayInfo("division");
//        String priorityDiv = "";
//        DivisionDto priorityDivisionDto = divisionComponentPage.getPriorityDivision();
//        if (priorityDivisionDto != null) {
//            priorityDiv = priorityDivisionDto.getDivisionCode();
//        }
//
//        return priorityDiv;
//    }
    
    /**
     * 対象案件の編集権限チェック
     * @param geBukkenEntity
     * @param myTeamList
     * @return 
     */
//    public boolean isAnkenEdit(SyuGeBukkenInfoTbl geBukkenEntity, List<TeamEntity> myTeamList) {
//        // 事業部:(火水ジ)コードを取得(N8のはず)
//        //String divKa = StringUtils.defaultString(Env.Div_Ka.getValue());
//        // 案件の事業部コード
//        //String divisionCode = StringUtils.defaultString(geBukkenEntity.getDivisionCode());
//        // 事業部:(原子力)であるかを判断
//        //boolean isNuclearDivision = divisionComponentPage.isNuclearDivision(divisionCode);
//
////        if (isNuclearDivision) {
////            // 事業部:(原子力)の場合
////            return isAnkenEditGen(geBukkenEntity);
////        } else {
////            // 事業部:(火水ジ)の場合
////            return isAnkenEditKa(geBukkenEntity, myTeamList);
////        }
//        
////        if (divKa.equals(divisionCode)) {
////            // 事業部:(火水ジ)の場合
////            return isAnkenEditKa(geBukkenEntity, myTeamList);
////
////        } else {
////            // 事業部:(原子力)の場合
////            return isAnkenEditGen(geBukkenEntity);
////        }
//
//        boolean isEditFlg = true;
//        return isAnkenEditTeamCode(geBukkenEntity, myTeamList);
//    }

    /**
     * 案件の権限チェック(原子力) → 原子力の職種L,Mの権限チェックは権限マスタに統一でき、ロジック的にふようになりそうなのでコメントアウト
     */
//    private boolean isAnkenEditGen(SyuGeBukkenInfoTbl geBukkenEntity) {
//        // 案件の事業部コード
//        String divisionCode = StringUtils.defaultString(geBukkenEntity.getDivisionCode());
//
//        for (Map<String, Object> info: jobGrList) {
//            String userDivisionCode = StringUtils.defaultString((String)info.get("division"));
//            String syokusyuCd = StringUtils.defaultString((String)info.get("syokusyuCd"));
//
//            log.info("isAnkenEditGen ankenId=[{}] divisionCode=[{}] userJobGr=[{}] userDivisionCode=[{}] syokusyuCd=[{}]",
//                geBukkenEntity.getAnkenId(), divisionCode, StringUtils.defaultString((String)info.get("JgrpId")), userDivisionCode, syokusyuCd
//            );
//
//            if (!divisionCode.equals(userDivisionCode)) {
//                continue;
//            }
//
//            if ("L".equals(syokusyuCd) || "M".equals(syokusyuCd)) {
//                return true;
//            }
//        }
//        
//        return false;
//    }
    
     /**
     * 案件の権限チェック(原子力) 企画用→権限マスタに原子力企画の期間損益画面用権限が存在するのでロジック的に不要になりそうなのでコメント
     */
//    public boolean isAnkenEditKikakuGen(SyuGeBukkenInfoTbl geBukkenEntity) {
//        // 案件の事業部コード
//        String divisionCode = StringUtils.defaultString(geBukkenEntity.getDivisionCode());
//
//        for (Map<String, Object> info: jobGrList) {
//            String userDivisionCode = StringUtils.defaultString((String)info.get("division"));
//            String syokusyuCd = StringUtils.defaultString((String)info.get("syokusyuCd"));
//
//            log.info("isAnkenEditGen ankenId=[{}] divisionCode=[{}] userJobGr=[{}] userDivisionCode=[{}] syokusyuCd=[{}]",
//                geBukkenEntity.getAnkenId(), divisionCode, StringUtils.defaultString((String)info.get("JgrpId")), userDivisionCode, syokusyuCd
//            );
//
//            if (!divisionCode.equals(userDivisionCode)) {
//                continue;
//            }
//
//            if ("K".equals(syokusyuCd)) {
//                return true;
//            }
//        }
//        
//        return false;
//    }
    
    
    
    /**
     * 案件の権限チェック(発番チームコードでのチェック)
     */
//    private boolean isAnkenEditTeamCode(SyuGeBukkenInfoTbl geBukkenEntity, List<TeamEntity> myTeamList) {
//        // 案件の事業部コード
//        String divisionCode = StringUtils.defaultString(geBukkenEntity.getDivisionCode());
//        // 案件の売上基準
//        String salesClass = StringUtils.defaultString(geBukkenEntity.getSalesClass());
//        // 扱いCコード
//        String targetTeamCode = StringUtils.defaultString(geBukkenEntity.getAtsukaiCCode());
//
//        for (Map<String, Object> info: jobGrList) {
//            String userDivisionCode = StringUtils.defaultString((String)info.get("division"));
//            String syokusyuCd = StringUtils.defaultString((String)info.get("syokusyuCd"));
//
//            log.info("isAnkenEditTeamCode ankenId=[{}] divisionCode=[{}] userJobGr=[{}] userDivisionCode=[{}] syokusyuCd=[{}]",
//                geBukkenEntity.getAnkenId(), divisionCode, StringUtils.defaultString((String)info.get("JgrpId")), userDivisionCode, syokusyuCd
//            );
//
//            if (!divisionCode.equals(userDivisionCode)) {
//                continue;
//            }
//
//            if (ConstantString.salesClassS.equals(salesClass)) {
//                // 進行基準案件(職種M)
//                if ("M".equals(syokusyuCd)) {
//                    return true;
//                }
//            } else {
//                // 一般案件(ログイン者の保有チームコードと案件の扱いCコードが一致)
//                if (CollectionUtils.isNotEmpty(myTeamList)) {
//                    for (TeamEntity tEntity : myTeamList) {
//                        String myTeamCd = StringUtils.defaultString(tEntity.getTeamCd());
//                        myTeamCd = StringUtils.substring(myTeamCd, 2);
//                        log.info("isAnkenEditTeamCode targetTeamCode=[{}] myTeamCd=[{}]", targetTeamCode, myTeamCd);
//
//                        if (targetTeamCode.equals(myTeamCd)) {
//                            return true;
//                        }
//                    }
//                }
//            }
//        }
//
//        return false;
//    }
    
    /**
     * BUマスタ候補から、ログイン者所属JobGrのdivisionSubName(兼務先のDivisionSubName全て)と一致するSBU(or BU)を配列で取得
     * 1件でも不一致があれば一致していないと見なす
     * @param targetDivisionCode 対象の事業部コード
     * @param list　BUマスタ候補
     * @param kbn 返却する情報(0:BUコード 1:SBUコード)
     * @return 
     */
//    public String[] getDefaultLoginSameBuArray(String targetDivisionCode, List<BuMst> list, int kbn) {
//        if (CollectionUtils.isEmpty(list)) {
//            return null;
//        }
//
//        List<BuMst> changeList = list;
//        String[] loginSubDivisionNames = getJobGrSyokusyuArrayInfo("divisionSubName", targetDivisionCode);
//        //String preDivisionCode = "";
//        if (loginSubDivisionNames == null) {
//            return null;
//        }
//
//        Set<String> sameDataList = new HashSet<>();
//        for (String loginSubDivisionName: loginSubDivisionNames) {
//            int sameSubDivisionNameCount = 0;
//            for (BuMst buMst: changeList) {
//                String buDivisionCode = StringUtils.defaultString(buMst.getDivisionCode());
//                if (!buDivisionCode.equals(targetDivisionCode)) {
//                    continue;
//                }
//
//                log.info("#getDefaultLoginSameBuArray kbn=[{}], buCode=[{}] sbuCode=[{}] loginSubDivisionNames count=[{}] arrays=[{}]", kbn, buMst.getBuCode(), buMst.getSbuCode(), loginSubDivisionNames.length, loginSubDivisionNames);
//
//                if (isSameSubDivisionName(buMst, loginSubDivisionName)) {
//                    String data;
//                    if (kbn == 0) {
//                        data = buMst.getBuCode();
//                    } else {
//                        data = buMst.getSbuCode();
//                    }
//                    sameDataList.add(data);
//                    sameSubDivisionNameCount++;
//                }
//            }
//            
//            // 対象のDIVISION_SUB_NAMEに一致するBUが存在しない場合、BU条件のデフォルトは1件も選択してはならないのでこれまでため込みしたBUデフォルト条件は全てクリアする
//            if (sameSubDivisionNameCount == 0) {
//                sameDataList.clear();
//                break;
//            }
//        }
//
//        return (String[])sameDataList.toArray(new String[0]);
//    }
    
//    /**
//     * BUマスタからログイン者所属JobGrのdivisionSubName(兼務先のDivisionSubName全て)と一致するかを確認
//     * 1件でも不一致があれば一致していないと見なす
//     * @param buMst
//     * @param divisionSubNames
//     * @return 
//     */
//    public boolean isSameSubDivisionName(BuMst buMst, String[] divisionSubNames) {
//        if (buMst == null || divisionSubNames == null) {
//            return false;
//        }
//
//        int sameCount = 0;
//        for (String divisionSubName: divisionSubNames) {
//            if (isSameSubDivisionName(buMst, divisionSubName)) {
//                //sameCount = sameCount + 1;
//                return true;
//            }
//        }
//
//        //return (divisionSubNames.length == sameCount);
//        return false;
//    }
//
//    public boolean isSameSubDivisionName(BuMst buMst, String divisionSubName) {
//        if (buMst == null || StringUtils.isEmpty(divisionSubName)) {
//            return false;
//        }
//
//        boolean isSame = divisionSubName.equals(buMst.getBuName());
//        return isSame;
//    }

}