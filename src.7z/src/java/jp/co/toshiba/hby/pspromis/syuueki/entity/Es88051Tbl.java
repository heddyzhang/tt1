package jp.co.toshiba.hby.pspromis.syuueki.entity;

import java.io.Serializable;
import java.util.Date;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

/**
 *
 * @author ibayashi
 */
@Entity
@Table(name = "ES88051_TBL")
public class Es88051Tbl implements Serializable {
    private static final long serialVersionUID = 1L;
    @Id
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 99)
    @Column(name = "NEW_STCH_CD")
    private String newStchCd;
    @Size(max = 72)
    @Column(name = "STCH_CD")
    private String stchCd;
    @Size(max = 720)
    @Column(name = "STCH_NAME_J")
    private String stchNameJ;
    @Size(max = 720)
    @Column(name = "STCH_NAME_KANA")
    private String stchNameKana;
    @Size(max = 540)
    @Column(name = "STCH_NAME_E")
    private String stchNameE;
    @Size(max = 72)
    @Column(name = "ADDRESS_CD")
    private String addressCd;
    @Size(max = 1260)
    @Column(name = "ADDRESS_J")
    private String addressJ;
    @Size(max = 1620)
    @Column(name = "ADDRESS_KANA")
    private String addressKana;
    @Size(max = 1260)
    @Column(name = "ADDRESS_E")
    private String addressE;
    @Size(max = 27)
    @Column(name = "KUNI_CD_MITI")
    private String kuniCdMiti;
    @Size(max = 558)
    @Column(name = "KUNI_FORMAL_NAME_JP")
    private String kuniFormalNameJp;
    @Size(max = 540)
    @Column(name = "KUNI_FORMAL_NAME")
    private String kuniFormalName;
    @Size(max = 198)
    @Column(name = "KUNI_NAME_JP")
    private String kuniNameJp;
    @Size(max = 360)
    @Column(name = "KUNI_NAME")
    private String kuniName;
    @Size(max = 72)
    @Column(name = "KEN_NAME")
    private String kenName;
    @Size(max = 63)
    @Column(name = "NEW_POST")
    private String newPost;
    @Size(max = 45)
    @Column(name = "POST")
    private String post;
    @Size(max = 18)
    @Column(name = "UNIT")
    private String unit;
    @Size(max = 99)
    @Column(name = "TOKUISAKI_CD")
    private String tokuisakiCd;
    @Size(max = 27)
    @Column(name = "SANBETSU_CD")
    private String sanbetsuCd;
    @Size(max = 18)
    @Column(name = "JIGYOBU_CD")
    private String jigyobuCd;
    @Size(max = 9)
    @Column(name = "TOSCAP_CD")
    private String toscapCd;
    @Size(max = 9)
    @Column(name = "SHISYA")
    private String shisya;
    @Size(max = 9)
    @Column(name = "KARI_STCH_FLG")
    private String kariStchFlg;
    @Size(max = 9)
    @Column(name = "DEL_FLG")
    private String delFlg;
    @Column(name = "ENTRY_DATE")
    @Temporal(TemporalType.TIMESTAMP)
    private Date entryDate;
    @Column(name = "UPDATE_DATE")
    @Temporal(TemporalType.TIMESTAMP)
    private Date updateDate;
    @Column(name = "ACTION_DATE")
    @Temporal(TemporalType.TIMESTAMP)
    private Date actionDate;
    @Size(max = 90)
    @Column(name = "BU_NAME")
    private String buName;
    @Size(max = 90)
    @Column(name = "KA_NAME")
    private String kaName;
    @Size(max = 72)
    @Column(name = "REVISED_EMP_NUM")
    private String revisedEmpNum;
    @Size(max = 90)
    @Column(name = "FMLY_NAME")
    private String fmlyName;
    @Size(max = 90)
    @Column(name = "NAME")
    private String name;

    public Es88051Tbl() {
    }

    public Es88051Tbl(String newStchCd) {
        this.newStchCd = newStchCd;
    }

    public String getNewStchCd() {
        return newStchCd;
    }

    public void setNewStchCd(String newStchCd) {
        this.newStchCd = newStchCd;
    }

    public String getStchCd() {
        return stchCd;
    }

    public void setStchCd(String stchCd) {
        this.stchCd = stchCd;
    }

    public String getStchNameJ() {
        return stchNameJ;
    }

    public void setStchNameJ(String stchNameJ) {
        this.stchNameJ = stchNameJ;
    }

    public String getStchNameKana() {
        return stchNameKana;
    }

    public void setStchNameKana(String stchNameKana) {
        this.stchNameKana = stchNameKana;
    }

    public String getStchNameE() {
        return stchNameE;
    }

    public void setStchNameE(String stchNameE) {
        this.stchNameE = stchNameE;
    }

    public String getAddressCd() {
        return addressCd;
    }

    public void setAddressCd(String addressCd) {
        this.addressCd = addressCd;
    }

    public String getAddressJ() {
        return addressJ;
    }

    public void setAddressJ(String addressJ) {
        this.addressJ = addressJ;
    }

    public String getAddressKana() {
        return addressKana;
    }

    public void setAddressKana(String addressKana) {
        this.addressKana = addressKana;
    }

    public String getAddressE() {
        return addressE;
    }

    public void setAddressE(String addressE) {
        this.addressE = addressE;
    }

    public String getKuniCdMiti() {
        return kuniCdMiti;
    }

    public void setKuniCdMiti(String kuniCdMiti) {
        this.kuniCdMiti = kuniCdMiti;
    }

    public String getKuniFormalNameJp() {
        return kuniFormalNameJp;
    }

    public void setKuniFormalNameJp(String kuniFormalNameJp) {
        this.kuniFormalNameJp = kuniFormalNameJp;
    }

    public String getKuniFormalName() {
        return kuniFormalName;
    }

    public void setKuniFormalName(String kuniFormalName) {
        this.kuniFormalName = kuniFormalName;
    }

    public String getKuniNameJp() {
        return kuniNameJp;
    }

    public void setKuniNameJp(String kuniNameJp) {
        this.kuniNameJp = kuniNameJp;
    }

    public String getKuniName() {
        return kuniName;
    }

    public void setKuniName(String kuniName) {
        this.kuniName = kuniName;
    }

    public String getKenName() {
        return kenName;
    }

    public void setKenName(String kenName) {
        this.kenName = kenName;
    }

    public String getNewPost() {
        return newPost;
    }

    public void setNewPost(String newPost) {
        this.newPost = newPost;
    }

    public String getPost() {
        return post;
    }

    public void setPost(String post) {
        this.post = post;
    }

    public String getUnit() {
        return unit;
    }

    public void setUnit(String unit) {
        this.unit = unit;
    }

    public String getTokuisakiCd() {
        return tokuisakiCd;
    }

    public void setTokuisakiCd(String tokuisakiCd) {
        this.tokuisakiCd = tokuisakiCd;
    }

    public String getSanbetsuCd() {
        return sanbetsuCd;
    }

    public void setSanbetsuCd(String sanbetsuCd) {
        this.sanbetsuCd = sanbetsuCd;
    }

    public String getJigyobuCd() {
        return jigyobuCd;
    }

    public void setJigyobuCd(String jigyobuCd) {
        this.jigyobuCd = jigyobuCd;
    }

    public String getToscapCd() {
        return toscapCd;
    }

    public void setToscapCd(String toscapCd) {
        this.toscapCd = toscapCd;
    }

    public String getShisya() {
        return shisya;
    }

    public void setShisya(String shisya) {
        this.shisya = shisya;
    }

    public String getKariStchFlg() {
        return kariStchFlg;
    }

    public void setKariStchFlg(String kariStchFlg) {
        this.kariStchFlg = kariStchFlg;
    }

    public String getDelFlg() {
        return delFlg;
    }

    public void setDelFlg(String delFlg) {
        this.delFlg = delFlg;
    }

    public Date getEntryDate() {
        return entryDate;
    }

    public void setEntryDate(Date entryDate) {
        this.entryDate = entryDate;
    }

    public Date getUpdateDate() {
        return updateDate;
    }

    public void setUpdateDate(Date updateDate) {
        this.updateDate = updateDate;
    }

    public Date getActionDate() {
        return actionDate;
    }

    public void setActionDate(Date actionDate) {
        this.actionDate = actionDate;
    }

    public String getBuName() {
        return buName;
    }

    public void setBuName(String buName) {
        this.buName = buName;
    }

    public String getKaName() {
        return kaName;
    }

    public void setKaName(String kaName) {
        this.kaName = kaName;
    }

    public String getRevisedEmpNum() {
        return revisedEmpNum;
    }

    public void setRevisedEmpNum(String revisedEmpNum) {
        this.revisedEmpNum = revisedEmpNum;
    }

    public String getFmlyName() {
        return fmlyName;
    }

    public void setFmlyName(String fmlyName) {
        this.fmlyName = fmlyName;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
    
}
