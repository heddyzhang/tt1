package jp.co.toshiba.hby.pspromis.syuueki.facade;

import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import java.util.List;
import javax.ejb.Stateless;
import javax.interceptor.Interceptors;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import jp.co.toshiba.hby.pspromis.syuueki.entity.StringEntity;
import jp.co.toshiba.hby.pspromis.syuueki.interceptor.TranceInterceptor;

/**
 *
 * @author ganryu
 */
@Stateless
@Interceptors({TranceInterceptor.class})
public class AnkenSyokusyuRoleTblFacade extends AbstractFacade<StringEntity> {

    @PersistenceContext(unitName = jp.co.toshiba.hby.pspromis.syuueki.util.ConstantString.syuuekiDataSourceName)
    private EntityManager em;

    @Override
    protected EntityManager getEntityManager() {
        return em;
    }

    public AnkenSyokusyuRoleTblFacade() {
        super(StringEntity.class);
    }

    /**
     *
     * @param condition
     * @return
     */
    public String getDeptName(Object condition) {
        String ret = "";
        List<StringEntity> list = sqlExecutor.getResultList(em, StringEntity.class, "/sql/S002/selectDeptName.sql", condition);
        if (CollectionUtils.isNotEmpty(list)) {
            ret = StringUtils.defaultString(list.get(0).getString());
        }
        return ret;
    }
}
