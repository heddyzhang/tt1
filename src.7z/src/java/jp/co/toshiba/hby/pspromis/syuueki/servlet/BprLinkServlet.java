package jp.co.toshiba.hby.pspromis.syuueki.servlet;

import java.util.HashMap;
import java.util.Map;
import javax.inject.Inject;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import jp.co.toshiba.hby.pspromis.syuueki.bean.BprLinkBean;
import jp.co.toshiba.hby.pspromis.syuueki.service.BprLinkService;
import jp.co.toshiba.hby.pspromis.syuueki.util.ParameterBinder;

/**
 *
 * @author ibayashi
 */
@WebServlet(name = "BprLink", urlPatterns = {"/servlet/bprLink", "/servlet/bprLink/*"})
public class BprLinkServlet extends AbstractServlet {

    @Inject
    private BprLinkBean bprLinkBean;

    @Inject
    private BprLinkService bprLinkService;

    /**
     * 初期表示
     * @param req
     * @param resp
     * @return
     * @throws Exception 
     */
    public String indexAction(HttpServletRequest req, HttpServletResponse resp)
    throws Exception {
        ParameterBinder.Bind(bprLinkBean, req);

        // 更新処理を実行
        bprLinkService.indexGetUrl();

        // 結果セットをjson出力
        Map<String, Object> jsonMap = new HashMap<>();
        jsonMap.put("targetUrl", bprLinkBean.getTargetUrl());
        jsonMap.put("errorMessage", bprLinkBean.getErrorMessage());

        resopnseDecodeJson(resp, jsonMap);
 
        return null;
    }

}
