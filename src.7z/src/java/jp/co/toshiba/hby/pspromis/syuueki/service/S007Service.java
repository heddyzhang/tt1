package jp.co.toshiba.hby.pspromis.syuueki.service;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.ejb.Stateless;
import javax.inject.Inject;
import javax.interceptor.Interceptors;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import jp.co.toshiba.hby.pspromis.common.util.StringUtil;
import jp.co.toshiba.hby.pspromis.syuueki.bean.S007Bean;
import jp.co.toshiba.hby.pspromis.syuueki.dto.AnkenRecalDto;
import jp.co.toshiba.hby.pspromis.syuueki.entity.OperationLog;
import jp.co.toshiba.hby.pspromis.syuueki.entity.SyuGeBukkenInfoTbl;
import jp.co.toshiba.hby.pspromis.syuueki.entity.SyuKiNetCateTitleTbl;
import jp.co.toshiba.hby.pspromis.syuueki.enums.Env;
import jp.co.toshiba.hby.pspromis.syuueki.facade.SyuGeBukenInfoTblFacade;
import jp.co.toshiba.hby.pspromis.syuueki.facade.SyuKiNetCateTitleTblFacade;
import jp.co.toshiba.hby.pspromis.syuueki.interceptor.TranceInterceptor;
import jp.co.toshiba.hby.pspromis.common.jdbc.SqlExecutor;
import jp.co.toshiba.hby.pspromis.syuueki.bean.ValidationMessageBean;
import jp.co.toshiba.hby.pspromis.syuueki.entity.StringEntity;
import jp.co.toshiba.hby.pspromis.syuueki.entity.SyuGeCategoryMapView;
import jp.co.toshiba.hby.pspromis.syuueki.entity.SyuGeNetItemTbl;
import jp.co.toshiba.hby.pspromis.syuueki.entity.SyuKiNetCateTukiTbl;
import jp.co.toshiba.hby.pspromis.syuueki.enums.Label;
import jp.co.toshiba.hby.pspromis.syuueki.enums.ValidatorMessage;
import jp.co.toshiba.hby.pspromis.syuueki.facade.CategoryMapFacade;
import jp.co.toshiba.hby.pspromis.syuueki.facade.SyuGeNetItemTblViewFacade;
import jp.co.toshiba.hby.pspromis.syuueki.facade.SyuKiNetCateTukiTblFacade;
import jp.co.toshiba.hby.pspromis.syuueki.facade.SyuSaNetCateTblFacade;
import jp.co.toshiba.hby.pspromis.syuueki.facade.SyuSaNetCateTitleTblFacade;
import jp.co.toshiba.hby.pspromis.syuueki.util.ConstantString;
import jp.co.toshiba.hby.pspromis.syuueki.util.EntityUtils;
import jp.co.toshiba.hby.pspromis.syuueki.util.LoginUserInfo;
import jp.co.toshiba.hby.pspromis.syuueki.util.Utils;
import jp.co.toshiba.hby.pspromis.syuueki.util.ValidationUtils;
import org.apache.commons.beanutils.PropertyUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * NETカテゴリ編集
 * @author sano
 */
@Stateless
@Interceptors({TranceInterceptor.class})
public class S007Service {
    public static final Logger logger = LoggerFactory.getLogger(S007Service.class);

    @PersistenceContext(unitName = jp.co.toshiba.hby.pspromis.syuueki.util.ConstantString.syuuekiDataSourceName)
    private EntityManager em;
    
    @Inject
    private S007Bean s007Bean;

    @Inject
    private LoginUserInfo loginUserInfo;

    @Inject
    protected SqlExecutor sqlExecutor;
    
    @Inject
    private SyuKiNetCateTitleTblFacade syuKiNetCateTitleTblFacade;
    
    @Inject
    private SyuGeBukenInfoTblFacade syuGeBukenInfoTblFacade;
    
    @Inject
    private SyuGeNetItemTblViewFacade syuGeNetItemTblViewFacade;

    @Inject
    private SyuKiNetCateTukiTblFacade syuKiNetCateTukiTblFacade;
    
    @Inject
    private CategoryMapFacade categoryMapFacade;
    
    @Inject
    private SyuSaNetCateTitleTblFacade syuSaNetCateTitleTblFacade;
    
    @Inject
    private SyuSaNetCateTblFacade syuSaNetCateTblFacade;
    
    @Inject
    private StoredProceduresService storedProceduresService;

    @Inject
    private OperationLogService operationLogService;
    
    @Inject
    private ValidationMessageBean validationMessageBean;
    
    @Inject
    private Utils utils;
    
    // 手動追加 分類1
    private static final String categoryKbn1 = "CHOUSEI";
    
    // 手動追加 分類2
    private static final String categoryKbn2 = "0000000000";
    
    /**
     * 初期表示時機能
     * @throws Exception
     */
    public void indexExecute() throws Exception {
        Map<String, Object> condition1 = new HashMap<>();
        condition1.put("ankenId", s007Bean.getAnkenId());
        condition1.put("rirekiId", s007Bean.getRirekiId());

        Integer delLabelFlg = 0;
        
        // GEテーブルから収益案件基本情報の取得
        SyuGeBukkenInfoTbl syuGeBukkenItem = syuGeBukenInfoTblFacade.findPk(condition1);
        
        int choseiNewCount = 0;
        choseiNewCount = Integer.parseInt(Env.getValue(Env.Chosei_New_Input_Count));
        
        // 手動追加済み期間損益データを取得
        Map<String, Object> conditionChosei = new HashMap<>(condition1);
        //conditionChosei.put("categoryKbn1", this.categoryKbn1);
        //List<SyuKiNetCateTitleTbl> choseiList = syuKiNetCateTitleTblFacade.selectChoseiList(conditionChosei);
        conditionChosei.put("inputFlg", "1");
        List<SyuKiNetCateTitleTbl> choseiList = syuKiNetCateTitleTblFacade.getCategoryList(conditionChosei);
        

        List<Map<String, Object>> rtnList = new ArrayList<>();
               
        for (SyuKiNetCateTitleTbl netCateTitle : choseiList) {
            Map<String, Object> entity = new HashMap<>(PropertyUtils.describe(netCateTitle));
            //Map<String, Object> entity = PropertyUtils.describe(netCateTitle);
            
            // Step3 一般案件で、最終見込NETが入力済みの場合は削除不可とする(受注/売上バランスが崩れるのを防いでいる)
            // Step4 項番に紐づくカテゴリを削除不可にした(Step3条件は削除)。
            if ("0".equals(syuGeBukkenItem.getSalesClass())) {
                SyuGeNetItemTbl en = syuGeNetItemTblViewFacade.checkCateCode(
                    s007Bean.getAnkenId(), 
                    new Integer(s007Bean.getRirekiId()),
                    netCateTitle.getCategoryCode()
                );
                
                if (en != null) {
                    entity.put("noDeleteFlg", "1");
                    delLabelFlg = 1;
                }
            }
            
            entity.put("createdFlg", "1");
            rtnList.add(entity);
        }
        
        // 新規登録用　○件分の空データを追加
        for (int i=0; i<choseiNewCount; i++) {
            SyuKiNetCateTitleTbl newItem = new SyuKiNetCateTitleTbl();
            Map<String, Object> entity = PropertyUtils.describe(newItem);
            entity.put("categoryName1", "");
            entity.put("categoryName2", "");
            entity.put("noDeleteFlg", "1");   // 新規登録行データは削除不可としておく。
            entity.put("createdFlg", "0");
            rtnList.add(entity);
        }
        
        s007Bean.setChoseiList(rtnList);
        
        // カテゴリ選択候補の取得(全件取得)
// (2017B)初期表示でこの情報は利用せず、かつ遅いため処理をやめる
//        condition1.put("divisionCode", syuGeBukkenItem.getDivisionCode());
//        condition1.put("salesClass", syuGeBukkenItem.getSalesClass());
//        List<SyuGeCategoryMapView> list = categoryMapFacade.getCategoryList(condition1);
//        s007Bean.setCateList(list);
        
        s007Bean.setMainOrderNo(syuGeBukkenItem.getMainOrderNo());
        s007Bean.setOrderNo(syuGeBukkenItem.getOrderNo());
        s007Bean.setAnkenFlg(syuGeBukkenItem.getAnkenFlg());
        s007Bean.setDivisionCode(syuGeBukkenItem.getDivisionCode());
        s007Bean.setSalesClass(syuGeBukkenItem.getSalesClass());
        s007Bean.setDelLabelFlg(delLabelFlg);
    }
    
    
    /**
     * 登録・更新・削除
     * @throws Exception
     */
    public void updateExecute() throws Exception {
        // GEテーブルから収益案件基本情報の取得
        Map<String, Object> conditionGe = new HashMap<>();
        conditionGe.put("ankenId", s007Bean.getAnkenId());
        conditionGe.put("rirekiId", s007Bean.getRirekiId());
        //SyuGeBukkenInfoTbl syuGeBukkenItem = syuGeBukenInfoTblFacade.findPk(conditionGe);
        
        // カテゴリ削除処理
        deleteCategory();
        
        for(int idx=0;idx<s007Bean.getDelFlg().length;idx++){
            Date now = new Date();
            
            if(checkEscape(idx)){
                continue;
            }
            
            Map<String, Object> condition = checkCategory(idx);
            EntityUtils.setCreatedInfo(condition, loginUserInfo.getUserId());
            //condition.put("ankenId", entity.getAnkenId());
            //condition.put("rirekiId", s007Bean.getRirekiId());
            
            // 更新処理
            updateCategory(condition);

        }

        // 操作ログの登録
        registOperationLog();
        // 再計算（集計）パッケージ呼出
        storedProceduresService.callAnkenRecalAuto(s007Bean.getAnkenId(), s007Bean.getRirekiId(), "0");
        
    }
    
    public boolean validation() throws Exception {
        String message;
        
        // 更新行のためこみ
        Map<String, Integer> nameMapCount = new HashMap<>();
        for(int i=0; i<s007Bean.getDelFlg().length; i++){
            if(checkEscape(i)){
                continue;
            }
            String patternName = storedProceduresService.getSearchStr(s007Bean.getCategoryName1()[i]) + "	" + storedProceduresService.getSearchStr(s007Bean.getCategoryName2()[i]);
            if (StringUtils.isNotEmpty(patternName)) {
                Utils.setNameMapCount(nameMapCount, patternName);
            }
        }
        logger.info("nameMapCount=[{}]", nameMapCount);
        
        // 更新データを既存データと比較する
        for(int i=0; i<s007Bean.getDelFlg().length; i++){
            // チェックが必要か確認
            if(checkEscape(i)){
                continue;
            }
            
            message = "";
            String errorCategory = "errorCategory-" + i + "-kbn";
            String target = storedProceduresService.getSearchStr(s007Bean.getCategoryName1()[i]) + "	" + storedProceduresService.getSearchStr(s007Bean.getCategoryName2()[i]);
            
            if (!ValidationUtils.isRequired(s007Bean.getCategoryName1()[i])) {
                // 必須チェックエラー
                message = ValidatorMessage.REQUIRED.getMessae(Label.labelCategory1.getLabel());
            } else if(checkOverlap(nameMapCount, target)){
                // 画面重複エラー
                message = ValidatorMessage.CATEGORY_OVERLAP.getMessae();
            } else if(checkData(i)){
                // 登録済checkエラー
                message = ValidatorMessage.CATEGORY_EXISTS.getMessae();
            }
                
            if (StringUtils.isNotEmpty(message)) {
                validationMessageBean.setErrorInfo(errorCategory, message);
            }
        }
        
        return validationMessageBean.isSuccess();
    }
    
    /**
     * 該当行の処理中断チェック
     */
    private boolean checkEscape(int idx){
        boolean flg = false;
        String createFlg = s007Bean.getCreatedFlg()[idx];
        String delFlg = s007Bean.getDelFlg()[idx];
        
        String befName1 = s007Bean.getBefCategoryName1()[idx];
        String befName2 = s007Bean.getBefCategoryName2()[idx];
        String name1 = s007Bean.getCategoryName1()[idx];
        String name2 = s007Bean.getCategoryName2()[idx];
        
        
        // 削除行のチェックは行わない
        if("1".equals(delFlg)){
            flg = true;
        }
        // 更新行でデータに変更がない場合
        if("1".equals(createFlg) && befName1.equals(name1) && befName2.equals(name2)){
            flg = true;
        }
        // 新規行で入力がない場合
        if("0".equals(createFlg) && StringUtils.isEmpty(name1) && StringUtils.isEmpty(name2)){
            flg = true;
        }
        
        return flg;
    }
    
    /**
     *  画面入力重複チェック
     * @param nameMapCount
     * @param target
     * @return 
     */
    private boolean checkOverlap(Map<String, Integer> nameMapCount, String target){
        boolean flg = false;
        Integer count = nameMapCount.get(target);
        if(count != null && count > 0){
            flg = true;
        }
        
        return flg;
    }
    
    /**
     * 入力値登録済チェック
     */
    private boolean checkData(int idx){
        boolean flg = false;
        Map<String, Object> condition = new HashMap<>();
        condition.put("ankenId", s007Bean.getAnkenId());
        condition.put("rirekiid", s007Bean.getRirekiId());
        condition.put("notCategoryCode", s007Bean.getCategoryCode()[idx]);
        condition.put("categoryName1", s007Bean.getCategoryName1()[idx]);
        condition.put("categoryName2", s007Bean.getCategoryName2()[idx]);
        condition.put("cateFlg", "0");
        SyuKiNetCateTitleTbl en = syuKiNetCateTitleTblFacade.getCategoryInfo(condition);
        if(en != null){
            flg = true;
        }
        
        return flg;
    }
    
    /**
     * 選択カテゴリの削除処理
     */
    private void deleteCategory(){
        Map<String, Object> condition = new HashMap<>();
        condition.put("ankenId", s007Bean.getAnkenId());
        condition.put("rirekiId", s007Bean.getRirekiId());
        
        for(int i=0; i<s007Bean.getDelFlg().length; i++){
            if(!"1".equals(s007Bean.getDelFlg()[i])){
                continue;
            }
            
            condition.put("categoryCode", s007Bean.getCategoryCode()[i]);
            
            // SYU_KI_NET_CATE_TITLE_TBLのデータ削除
            syuKiNetCateTitleTblFacade.deleteCategory(condition);
            // SYU_KI_NET_CATE_TUKI_TBLのデータ削除
            syuKiNetCateTukiTblFacade.deleteSyuKiNetCateTukiTbl(condition);
            // SYU_SA_NET_CATE_TITLE_TBLのデータ削除
            syuSaNetCateTitleTblFacade.deleteCategory(condition);
            // SYU_SA_NET_CATE_TBLのデータ削除
            syuSaNetCateTblFacade.deleteCategory(condition);
            
        }
    }
    
    /**
     * 入力カテゴリのチェック処理
     */
    private Map<String, Object> checkCategory(int idx){
        String categoryCode = s007Bean.getCategoryCode()[idx];
        String categoryName1 = "";
        String categoryName2 = "";
        String categoryKbn1 = "";
        String categoryKbn2 = "";
        
        Map<String, Object> cateInfo = new HashMap<>();
        cateInfo.put("ankenId", s007Bean.getAnkenId());
        cateInfo.put("rirekiId", s007Bean.getRirekiId());
        
        
        Map<String, Object> condition = new HashMap<>();
        condition.put("ankenId", s007Bean.getAnkenId());
        condition.put("rirekiId", s007Bean.getRirekiId());
        
        // 案件内の利用済み区分1取得
        SyuKiNetCateTitleTbl en = getCateKbn(condition, 1, s007Bean.getCategoryName1()[idx]);
        if(en != null){
            categoryKbn1 = en.getCategoryKbn1();
            categoryName1 = en.getCategoryName1();
        }
        
        // 案件内の利用済み区分2取得
        en = getCateKbn(condition, 2, s007Bean.getCategoryName2()[idx]);
        if(en != null){
            categoryKbn2 = en.getCategoryKbn2();
            categoryName2 = en.getCategoryName2();
        }
        
        if(StringUtils.isNotEmpty(categoryCode) && StringUtils.isNotEmpty(categoryKbn1) && StringUtils.isNotEmpty(categoryKbn2)){
            cateInfo.put("categoryCode", categoryCode);
            cateInfo.put("categoryKbn1", categoryKbn1);
            cateInfo.put("categoryKbn2", categoryKbn2);
            cateInfo.put("categoryName1", categoryName1);
            cateInfo.put("categoryName2", categoryName2);
            cateInfo.put("categorySeq", categoryCode);
            
            return cateInfo;
        }
        
        // マスタからカテゴリコード、区分1、区分2の組合せを取得(データがカテゴリコードを持ってない場合)
        if(StringUtils.isEmpty(categoryCode)){
            SyuGeCategoryMapView entity = checkCombination(s007Bean.getCategoryName1()[idx], s007Bean.getCategoryName2()[idx]);
            if(entity != null){
                // 取得したカテゴリコードが使用できるかチェック
                SyuKiNetCateTitleTbl chk = checkCategoryCode(entity.getCategoryCode());
                if(chk == null){
                    categoryCode = entity.getCategoryCode();
                }
            }
        }
        
        // カテゴリコード、区分1、区分2が取得できている場合
        if(StringUtils.isNotEmpty(categoryCode) && StringUtils.isNotEmpty(categoryKbn1) && StringUtils.isNotEmpty(categoryKbn2)){
            cateInfo.put("categoryCode", categoryCode);
            cateInfo.put("categoryKbn1", categoryKbn1);
            cateInfo.put("categoryKbn2", categoryKbn2);
            cateInfo.put("categoryName1", categoryName1);
            cateInfo.put("categoryName2", categoryName2);
            cateInfo.put("categorySeq", categoryCode);
            
            return cateInfo;
        }
        
        //区分1が取得できていない場合、マスタから取得
        if(StringUtils.isEmpty(categoryKbn1)){
            SyuGeCategoryMapView kbn1 = getCategoryKbn(s007Bean.getCategoryName1()[idx], 1);
            if(kbn1 != null){
                categoryKbn1 = kbn1.getCategoryKbn1();
                categoryName1 = kbn1.getCategoryName1();
            }
        }
        
        //区分2が取得できていない場合、マスタから取得
        if(StringUtils.isEmpty(categoryKbn2)){
            SyuGeCategoryMapView kbn2 = getCategoryKbn(s007Bean.getCategoryName2()[idx], 2);
            if(kbn2 != null){
                categoryKbn2 = kbn2.getCategoryKbn2();
                categoryName2 = kbn2.getCategoryName2();
            }
        }
        
        // カテゴリコード、区分1、区分2が取得できている場合
        if(StringUtils.isNotEmpty(categoryCode) && StringUtils.isNotEmpty(categoryKbn1) && StringUtils.isNotEmpty(categoryKbn2)){
            cateInfo.put("categoryCode", categoryCode);
            cateInfo.put("categoryKbn1", categoryKbn1);
            cateInfo.put("categoryKbn2", categoryKbn2);
            cateInfo.put("categoryName1", categoryName1);
            cateInfo.put("categoryName2", categoryName2);
            cateInfo.put("categorySeq", categoryCode);
            
            return cateInfo;
        }
        
        //区分1の採番処理
        if(StringUtils.isEmpty(categoryKbn1)){
            categoryKbn1 = categoryMapFacade.getCategoryKbn("1");
        }

        //区分2の採番処理
        if(StringUtils.isEmpty(categoryKbn2)){
            categoryKbn2 = categoryMapFacade.getCategoryKbn("2");
        }
        
        //カテゴリコードの新規発番
        if(StringUtils.isEmpty(categoryCode)){
            categoryCode = newCatCode();
        }
        
        cateInfo.put("categoryCode", categoryCode);
        cateInfo.put("categoryKbn1", categoryKbn1);
        cateInfo.put("categoryKbn2", categoryKbn2);
        cateInfo.put("categoryName1", s007Bean.getCategoryName1()[idx]);
        cateInfo.put("categoryName2", s007Bean.getCategoryName2()[idx]);
        cateInfo.put("categorySeq", categoryCode);
        
        return cateInfo;
    }
    
    /**
     * category更新処理
     */
    private void updateCategory(Map<String, Object> condition){
        // カテゴリ関連テーブルの更新を行う
        condition.put("inputFlg", "1");
        
        // SYU_KI_NET_CATE_TITLE_TBLの更新
        int cnt = syuKiNetCateTitleTblFacade.updateSyuKiNetCateTitleTbl(condition);
        if(cnt == 0){
            // 対象データがないため、新規登録
            syuKiNetCateTitleTblFacade.insertSyuKiNetCateTitleTbl(condition);
        } else {
            // 更新した場合、SYU_KI_NET_CATE_TUKI_TBLも更新
            syuKiNetCateTukiTblFacade.updateCategory(condition);
        }
        
        // SYU_SA_NET_CATE_TITLE_TBLの更新
        cnt = syuSaNetCateTitleTblFacade.updateSyuSaNetCateTitleTbl(condition);
        if(cnt == 0){
            //対象データがないため、新規登録
            syuSaNetCateTitleTblFacade.insertSyuSaNetCateTitleTbl(condition);
        } else {
            // 更新した場合、SYU_SA_NET_CATE_TBLも更新
            syuSaNetCateTblFacade.updateCategory(condition);
        }
    }
    
    /**
     * 案件内の利用済み区分取得
     * @param condition
     * @param flg
     * @param categoryName
     * @return 
     */
    private SyuKiNetCateTitleTbl getCateKbn(Map<String, Object> condition, int flg, String categoryName){
        SyuKiNetCateTitleTbl entity = null;
        if(flg == 1){
            condition.put("cateFlg", "1");
            condition.put("categoryName", categoryName);
        } else if(flg == 2){
            condition.put("cateFlg", "2");
            condition.put("categoryName", categoryName);
        }
        entity = syuKiNetCateTitleTblFacade.getCategoryInfo(condition);
        
        return entity;
    }
    
    /**
     * カテゴリコード、区分1、区分2の組合せを取得
     * @param name1
     * @param name2
     * @return 
     */
    private SyuGeCategoryMapView checkCombination(String name1, String name2){
        SyuGeCategoryMapView entity = null;
        Map<String, Object> condition = new HashMap<>();
        condition.put("divisionCode", s007Bean.getDivisionCode());
        condition.put("salesClass", s007Bean.getSalesClass());
        condition.put("categoryName1", name1);
        condition.put("categoryName2", name2);
        //String[] ary = {"1", "2"};
        //condition.put("cateFlg", ary);
        
        entity = categoryMapFacade.getConmbination(condition);
        return entity;
    }
    
    /**
     * 取得したカテゴリコードが使えるかチェック
     */
    private SyuKiNetCateTitleTbl checkCategoryCode(String code){
        SyuKiNetCateTitleTbl entity = null;
        
        Map<String, Object> param = new HashMap<>();
        param.put("ankenId", s007Bean.getAnkenId());
        param.put("rirekiId", s007Bean.getRirekiId());
        param.put("categoryCode", code);
        
        entity =syuKiNetCateTitleTblFacade.getCategoryInfo(param);
        return entity;
    }
    
    /**
     * カテゴリ名からカテゴリ区分の取得
     */
    private SyuGeCategoryMapView getCategoryKbn(String name, int flg){
        SyuGeCategoryMapView entity = null;
        Map<String, Object> condition = new HashMap<>();
        condition.put("divisionCode", s007Bean.getDivisionCode());
        condition.put("salesClass", s007Bean.getSalesClass());
        if(flg == 1){
            condition.put("cateFlg", "1");
            condition.put("categoryName1", name);
        } else if(flg == 2){
            condition.put("cateFlg", "2");
            condition.put("categoryName2", name);
        }
        entity = categoryMapFacade.getCategoryKbnFromName(condition);
        return entity;
    }
    
    /**
     * カテゴリコードの新規発番
     */
    private String newCatCode(){
        String code = "";
        
        Map<String, Object> condition = new HashMap<>();
        condition.put("ankenId", s007Bean.getAnkenId());
        condition.put("rirekiId", s007Bean.getRirekiId());
        condition.put("notCategoryCode", ConstantString.ikkatsuCategoryCode);
        
        SyuKiNetCateTitleTbl entity = syuKiNetCateTitleTblFacade.selectMaxCateCode(condition);
        if(entity != null){
            code = entity.getCategoryCode();
        }
        
        return code;
    }
    
    /**
     * 
     */
    public String getChoiceList(){
        Map<String, Object> condition = new HashMap<>();
        condition.put("choiceFlg", s007Bean.getCateListFlg());
        condition.put("ankenId", s007Bean.getAnkenId());
        condition.put("rirekiId", s007Bean.getRirekiId());
        condition.put("divisionCode", s007Bean.getDivisionCode());
        condition.put("salesClass", s007Bean.getSalesClass());
        if("1".equals(s007Bean.getCateListFlg())){
            condition.put("categoryName", s007Bean.getChoiceName1());
        } else {
            condition.put("categoryName", s007Bean.getChoiceName2());
        }
        
        List<StringEntity> list = categoryMapFacade.getCateCoiceList(condition);
        List<String> choiceList = new ArrayList<>();
        for(StringEntity entity: list){
            if(!choiceList.contains(entity.getString())){
                choiceList.add(entity.getString());
            }
        }
        
        s007Bean.setCateChoiceList(choiceList);
        
        return null;
    }

    /**
     * SyuGeBookmarkTblエンティティを作成
     */
//    private SyuKiNetCateTitleTbl createSyuKiNetCateTitleTbl(int idx) throws Exception{
//        SyuKiNetCateTitleTbl entity = new SyuKiNetCateTitleTbl();
//        
//        int rirekiFlg = 0;
//        if (!"".equals(s007Bean.getRirekiId()) && null!=s007Bean.getRirekiId() ) {
//            rirekiFlg = Integer.parseInt(s007Bean.getRirekiId());
//        }
//        
//        entity.setAnkenId(s007Bean.getAnkenId());
//        entity.setRirekiId(rirekiFlg);
//        entity.setCategoryCode(s007Bean.getCategoryCode()[idx]);
//        entity.setCategoryKbn1(s007Bean.getCategoryKbn1()[idx]);
//        entity.setCategoryKbn2(s007Bean.getCategoryKbn2()[idx]);
//        entity.setCategorySeq(s007Bean.getCategorySeq()[idx]);
//        entity.setUpdatedBy(loginUserInfo.getUserId());
//        entity.setInputFlg("1");
//        
//        entity.setCategoryName1(s007Bean.getCategoryName1()[idx]);
//
//        return entity;
//    }

    /**
     * 再計算処理をcallする。
     */
//    private void callAnkenRecal() throws Exception {
//        AnkenRecalDto dto = new AnkenRecalDto();
//        dto.setAnkenId(s007Bean.getAnkenId());
//        dto.setRirekiId(new Integer(s007Bean.getRirekiId()));
//        //dto.setKbn("0");
//        
//        storedProceduresService.callAnkenRecal(dto);
//        
//        if (!"0".equals(dto.getStatus())) {
//            throw new Exception("再計算処理[SYU_ANKEN_RECAL_MAIN]でエラーが発生しました。物件Key=" + s007Bean.getAnkenId());
//        }
//    }

    /**
     * 操作ログの登録
     * @param operationCode
     * @throws Exception
     */
    public void registOperationLog() throws Exception{
        OperationLog operationLog = operationLogService.getOperationLog();
        
        String objectType = operationLogService.getObjectType(s007Bean.getProcId());

        operationLog.setOperationCode("ADD_CHOUSEI");
        operationLog.setObjectId(20);
        operationLog.setObjectType(objectType);
        operationLog.setRemarks(s007Bean.getAnkenId());

        operationLogService.insertOperationLogSearch(operationLog);
    }

}
