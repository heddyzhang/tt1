/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package jp.co.toshiba.hby.pspromis.syuueki.entity;

import java.io.Serializable;
import java.math.BigDecimal;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;

/**
 *
 * @author sano
 */
@Entity
public class S004Cost implements Serializable {
    private static final long serialVersionUID = 1L;
    
    @Id
    @Column(name = "CATEGORY_CODE")
    private String categoryCode;
    
    @Column(name = "HAT_NET_1")
    private BigDecimal hatNet1;
    @Column(name = "HAT_NET_2")
    private BigDecimal hatNet2;
    @Column(name = "HAT_NET_3")
    private BigDecimal hatNet3;
    @Column(name = "HAT_NET_4")
    private BigDecimal hatNet4;
    @Column(name = "HAT_NET_5")
    private BigDecimal hatNet5;
    @Column(name = "HAT_NET_6")
    private BigDecimal hatNet6;
    @Column(name = "HAT_NET_7")
    private BigDecimal hatNet7;
    @Column(name = "HAT_NET_8")
    private BigDecimal hatNet8;
    @Column(name = "HAT_NET_9")
    private BigDecimal hatNet9;
    @Column(name = "HAT_NET_10")
    private BigDecimal hatNet10;
    @Column(name = "HAT_NET_11")
    private BigDecimal hatNet11;
    @Column(name = "HAT_NET_12")
    private BigDecimal hatNet12;;
    @Column(name = "HAT_NET_TM")
    private BigDecimal hatNetTm;
    @Column(name = "HAT_NET_K1")
    private BigDecimal hatNetK1;
    @Column(name = "HAT_NET_K2")
    private BigDecimal hatNetK2;
    @Column(name = "HAT_NET_G")
    private BigDecimal hatNetG;
    @Column(name = "HAT_NET_F")
    private BigDecimal hatNetF;
    @Column(name = "HAT_NET_K1_DIFF")
    private BigDecimal hatNetK1Diff;
    @Column(name = "HAT_NET_K2_DIFF")
    private BigDecimal hatNetK2Diff;
    @Column(name = "HAT_NET_G_DIFF")
    private BigDecimal hatNetGDiff;
    @Column(name = "HAT_NET_DIFF")
    private BigDecimal hatNetDiff;
    @Column(name = "MI_NET_1")
    private BigDecimal miNet1;
    @Column(name = "MI_NET_2")
    private BigDecimal miNet2;
    @Column(name = "MI_NET_3")
    private BigDecimal miNet3;
    @Column(name = "MI_NET_4")
    private BigDecimal miNet4;
    @Column(name = "MI_NET_5")
    private BigDecimal miNet5;
    @Column(name = "MI_NET_6")
    private BigDecimal miNet6;
    @Column(name = "MI_NET_7")
    private BigDecimal miNet7;
    @Column(name = "MI_NET_8")
    private BigDecimal miNet8;
    @Column(name = "MI_NET_9")
    private BigDecimal miNet9;
    @Column(name = "MI_NET_10")
    private BigDecimal miNet10;
    @Column(name = "MI_NET_11")
    private BigDecimal miNet11;
    @Column(name = "MI_NET_12")
    private BigDecimal miNet12;;
    @Column(name = "MI_NET_TM")
    private BigDecimal miNetTm;
    @Column(name = "MI_NET_K1")
    private BigDecimal miNetK1;
    @Column(name = "MI_NET_K2")
    private BigDecimal miNetK2;
    @Column(name = "MI_NET_G")
    private BigDecimal miNetG;
    @Column(name = "MI_NET_F")
    private BigDecimal miNetF;
    @Column(name = "MI_NET_K1_DIFF")
    private BigDecimal miNetK1Diff;
    @Column(name = "MI_NET_K2_DIFF")
    private BigDecimal miNetK2Diff;
    @Column(name = "MI_NET_G_DIFF")
    private BigDecimal miNetGDiff;
    @Column(name = "MI_NET_DIFF")
    private BigDecimal miNetDiff;
    @Column(name = "SEIBAN_SONEKI_NET_1")
    private BigDecimal seibanSonekiNet1;
    @Column(name = "SEIBAN_SONEKI_NET_2")
    private BigDecimal seibanSonekiNet2;
    @Column(name = "SEIBAN_SONEKI_NET_3")
    private BigDecimal seibanSonekiNet3;
    @Column(name = "SEIBAN_SONEKI_NET_4")
    private BigDecimal seibanSonekiNet4;
    @Column(name = "SEIBAN_SONEKI_NET_5")
    private BigDecimal seibanSonekiNet5;
    @Column(name = "SEIBAN_SONEKI_NET_6")
    private BigDecimal seibanSonekiNet6;
    @Column(name = "SEIBAN_SONEKI_NET_7")
    private BigDecimal seibanSonekiNet7;
    @Column(name = "SEIBAN_SONEKI_NET_8")
    private BigDecimal seibanSonekiNet8;
    @Column(name = "SEIBAN_SONEKI_NET_9")
    private BigDecimal seibanSonekiNet9;
    @Column(name = "SEIBAN_SONEKI_NET_10")
    private BigDecimal seibanSonekiNet10;
    @Column(name = "SEIBAN_SONEKI_NET_11")
    private BigDecimal seibanSonekiNet11;
    @Column(name = "SEIBAN_SONEKI_NET_12")
    private BigDecimal seibanSonekiNet12;;
    @Column(name = "SEIBAN_SONEKI_NET_TM")
    private BigDecimal seibanSonekiNetTm;
    @Column(name = "SEIBAN_SONEKI_NET_K1")
    private BigDecimal seibanSonekiNetK1;
    @Column(name = "SEIBAN_SONEKI_NET_K2")
    private BigDecimal seibanSonekiNetK2;
    @Column(name = "SEIBAN_SONEKI_NET_G")
    private BigDecimal seibanSonekiNetG;
    @Column(name = "SEIBAN_SONEKI_NET_F")
    private BigDecimal seibanSonekiNetF;
    @Column(name = "SEIBAN_SONEKI_NET_K1_DIFF")
    private BigDecimal seibanSonekiNetK1Diff;
    @Column(name = "SEIBAN_SONEKI_NET_K2_DIFF")
    private BigDecimal seibanSonekiNetK2Diff;
    @Column(name = "SEIBAN_SONEKI_NET_G_DIFF")
    private BigDecimal seibanSonekiNetGDiff;
    @Column(name = "SEIBAN_SONEKI_NET_DIFF")
    private BigDecimal seibanSonekiNetDiff;
    @Column(name = "KAWASE_EIKYO_1")
    private BigDecimal kawaseEikyo1;
    @Column(name = "KAWASE_EIKYO_2")
    private BigDecimal kawaseEikyo2;
    @Column(name = "KAWASE_EIKYO_3")
    private BigDecimal kawaseEikyo3;
    @Column(name = "KAWASE_EIKYO_4")
    private BigDecimal kawaseEikyo4;
    @Column(name = "KAWASE_EIKYO_5")
    private BigDecimal kawaseEikyo5;
    @Column(name = "KAWASE_EIKYO_6")
    private BigDecimal kawaseEikyo6;
    @Column(name = "KAWASE_EIKYO_7")
    private BigDecimal kawaseEikyo7;
    @Column(name = "KAWASE_EIKYO_8")
    private BigDecimal kawaseEikyo8;
    @Column(name = "KAWASE_EIKYO_9")
    private BigDecimal kawaseEikyo9;
    @Column(name = "KAWASE_EIKYO_10")
    private BigDecimal kawaseEikyo10;
    @Column(name = "KAWASE_EIKYO_11")
    private BigDecimal kawaseEikyo11;
    @Column(name = "KAWASE_EIKYO_12")
    private BigDecimal kawaseEikyo12;;
    @Column(name = "KAWASE_EIKYO_TM")
    private BigDecimal kawaseEikyoTm;
    @Column(name = "KAWASE_EIKYO_K1")
    private BigDecimal kawaseEikyoK1;
    @Column(name = "KAWASE_EIKYO_K2")
    private BigDecimal kawaseEikyoK2;
    @Column(name = "KAWASE_EIKYO_G")
    private BigDecimal kawaseEikyoG;
    @Column(name = "KAWASE_EIKYO_F")
    private BigDecimal kawaseEikyoF;
    @Column(name = "KAWASE_EIKYO_K1_DIFF")
    private BigDecimal kawaseEikyoK1Diff;
    @Column(name = "KAWASE_EIKYO_K2_DIFF")
    private BigDecimal kawaseEikyoK2Diff;
    @Column(name = "KAWASE_EIKYO_G_DIFF")
    private BigDecimal kawaseEikyoGDiff;
    @Column(name = "KAWASE_EIKYO_DIFF")
    private BigDecimal kawaseEikyoDiff;
    
    @Column(name = "HAT_NET_1Q")
    private BigDecimal hatNet1Q;
    @Column(name = "HAT_NET_2Q")
    private BigDecimal hatNet2Q;
    @Column(name = "HAT_NET_3Q")
    private BigDecimal hatNet3Q;
    @Column(name = "HAT_NET_4Q")
    private BigDecimal hatNet4Q;
    @Column(name = "HAT_NET_1Q_DIFF")
    private BigDecimal hatNet1QDiff;
    @Column(name = "HAT_NET_2Q_DIFF")
    private BigDecimal hatNet2QDiff;
    @Column(name = "HAT_NET_3Q_DIFF")
    private BigDecimal hatNet3QDiff;
    @Column(name = "HAT_NET_4Q_DIFF")
    private BigDecimal hatNet4QDiff;

    @Column(name = "MI_NET_1Q")
    private BigDecimal miNet1Q;
    @Column(name = "MI_NET_2Q")
    private BigDecimal miNet2Q;
    @Column(name = "MI_NET_3Q")
    private BigDecimal miNet3Q;
    @Column(name = "MI_NET_4Q")
    private BigDecimal miNet4Q;
    @Column(name = "MI_NET_1Q_DIFF")
    private BigDecimal miNet1QDiff;
    @Column(name = "MI_NET_2Q_DIFF")
    private BigDecimal miNet2QDiff;
    @Column(name = "MI_NET_3Q_DIFF")
    private BigDecimal miNet3QDiff;
    @Column(name = "MI_NET_4Q_DIFF")
    private BigDecimal miNet4QDiff;

    @Column(name = "SEIBAN_SONEKI_NET_1Q")
    private BigDecimal seibanSonekiNet1Q;
    @Column(name = "SEIBAN_SONEKI_NET_2Q")
    private BigDecimal seibanSonekiNet2Q;
    @Column(name = "SEIBAN_SONEKI_NET_3Q")
    private BigDecimal seibanSonekiNet3Q;
    @Column(name = "SEIBAN_SONEKI_NET_4Q")
    private BigDecimal seibanSonekiNet4Q;
    @Column(name = "SEIBAN_SONEKI_NET_1Q_DIFF")
    private BigDecimal seibanSonekiNet1QDiff;
    @Column(name = "SEIBAN_SONEKI_NET_2Q_DIFF")
    private BigDecimal seibanSonekiNet2QDiff;
    @Column(name = "SEIBAN_SONEKI_NET_3Q_DIFF")
    private BigDecimal seibanSonekiNet3QDiff;
    @Column(name = "SEIBAN_SONEKI_NET_4Q_DIFF")
    private BigDecimal seibanSonekiNet4QDiff;

    @Column(name = "KAWASE_EIKYO_1Q")
    private BigDecimal kawaseEikyo1Q;
    @Column(name = "KAWASE_EIKYO_2Q")
    private BigDecimal kawaseEikyo2Q;
    @Column(name = "KAWASE_EIKYO_3Q")
    private BigDecimal kawaseEikyo3Q;
    @Column(name = "KAWASE_EIKYO_4Q")
    private BigDecimal kawaseEikyo4Q;
    @Column(name = "KAWASE_EIKYO_1Q_DIFF")
    private BigDecimal kawaseEikyo1QDiff;
    @Column(name = "KAWASE_EIKYO_2Q_DIFF")
    private BigDecimal kawaseEikyo2QDiff;
    @Column(name = "KAWASE_EIKYO_3Q_DIFF")
    private BigDecimal kawaseEikyo3QDiff;
    @Column(name = "KAWASE_EIKYO_4Q_DIFF")
    private BigDecimal kawaseEikyo4QDiff;
    
    public S004Cost() {
    }

    public String getCategoryCode() {
        return this.categoryCode;
    }

    public void setCategoryCode(String categoryCode) {
        this.categoryCode = categoryCode;
    }

    public BigDecimal getHatNet1() {
        return this.hatNet1;
    }

    public void setHatNet1(BigDecimal hatNet1) {
        this.hatNet1 = hatNet1;
    }
    
    public BigDecimal getHatNet2() {
        return this.hatNet2;
    }

    public void setHatNet2(BigDecimal hatNet2) {
        this.hatNet2 = hatNet2;
    }
    
    public BigDecimal getHatNet3() {
        return this.hatNet3;
    }

    public void setHatNet3(BigDecimal hatNet3) {
        this.hatNet3 = hatNet3;
    }
    
    public BigDecimal getHatNet4() {
        return this.hatNet4;
    }

    public void setHatNet4(BigDecimal hatNet4) {
        this.hatNet4 = hatNet4;
    }
    
    public BigDecimal getHatNet5() {
        return this.hatNet5;
    }

    public void setHatNet5(BigDecimal hatNet5) {
        this.hatNet5 = hatNet5;
    }
    
    public BigDecimal getHatNet6() {
        return this.hatNet6;
    }

    public void setHatNet6(BigDecimal hatNet6) {
        this.hatNet6 = hatNet6;
    }
    
    public BigDecimal getHatNet7() {
        return this.hatNet7;
    }

    public void setHatNet7(BigDecimal hatNet7) {
        this.hatNet7 = hatNet7;
    }
    
    public BigDecimal getHatNet8() {
        return this.hatNet8;
    }

    public void setHatNet8(BigDecimal hatNet8) {
        this.hatNet8 = hatNet8;
    }
    
    public BigDecimal getHatNet9() {
        return this.hatNet9;
    }

    public void setHatNet9(BigDecimal hatNet9) {
        this.hatNet9 = hatNet9;
    }
    
    public BigDecimal getHatNet10() {
        return this.hatNet10;
    }

    public void setHatNet10(BigDecimal hatNet10) {
        this.hatNet10 = hatNet10;
    }
    
    public BigDecimal getHatNet11() {
        return this.hatNet11;
    }

    public void setHatNet11(BigDecimal hatNet11) {
        this.hatNet11 = hatNet11;
    }
    
    public BigDecimal getHatNet12() {
        return this.hatNet12;
    }

    public void setHatNet12(BigDecimal hatNet12) {
        this.hatNet12 = hatNet12;
    }
    
    public BigDecimal getHatNetTm() {
        return this.hatNetTm;
    }

    public void setHatNetTm(BigDecimal hatNetTm) {
        this.hatNetTm = hatNetTm;
    }
    
    public BigDecimal getHatNetK1() {
        return this.hatNetK1;
    }

    public void setHatNetK1(BigDecimal hatNetK1) {
        this.hatNetK1 = hatNetK1;
    }
    
    public BigDecimal getHatNetK2() {
        return this.hatNetK2;
    }

    public void setHatNetK2(BigDecimal hatNetK2) {
        this.hatNetK2 = hatNetK2;
    }
    
    public BigDecimal getHatNetG() {
        return this.hatNetG;
    }

    public void setHatNetG(BigDecimal hatNetG) {
        this.hatNetG = hatNetG;
    }

    public BigDecimal getHatNetF() {
        return this.hatNetF;
    }

    public void setHatNetF(BigDecimal hatNetF) {
        this.hatNetF = hatNetF;
    }
    
    public BigDecimal getHatNetK1Diff() {
        return this.hatNetK1Diff;
    }

    public void setHatNetK1Diff(BigDecimal hatNetK1Diff) {
        this.hatNetK1Diff = hatNetK1Diff;
    }
    
    public BigDecimal getHatNetK2Diff() {
        return this.hatNetK2Diff;
    }

    public void setHatNetK2Diff(BigDecimal hatNetK2Diff) {
        this.hatNetK2Diff = hatNetK2Diff;
    }
    
    public BigDecimal getHatNetGDiff() {
        return this.hatNetGDiff;
    }

    public void setHatNetGDiff(BigDecimal hatNetGDiff) {
        this.hatNetGDiff = hatNetGDiff;
    }
    
    public BigDecimal getHatNetDiff() {
        return this.hatNetDiff;
    }

    public void setHatNetDiff(BigDecimal hatNetDiff) {
        this.hatNetDiff = hatNetDiff;
    }

    public BigDecimal getMiNet1() {
        return this.miNet1;
    }

    public void setMiNet1(BigDecimal miNet1) {
        this.miNet1 = miNet1;
    }
    
    public BigDecimal getMiNet2() {
        return this.miNet2;
    }

    public void setMiNet2(BigDecimal miNet2) {
        this.miNet2 = miNet2;
    }
    
    public BigDecimal getMiNet3() {
        return this.miNet3;
    }

    public void setMiNet3(BigDecimal miNet3) {
        this.miNet3 = miNet3;
    }
    
    public BigDecimal getMiNet4() {
        return this.miNet4;
    }

    public void setMiNet4(BigDecimal miNet4) {
        this.miNet4 = miNet4;
    }
    
    public BigDecimal getMiNet5() {
        return this.miNet5;
    }

    public void setMiNet5(BigDecimal miNet5) {
        this.miNet5 = miNet5;
    }
    
    public BigDecimal getMiNet6() {
        return this.miNet6;
    }

    public void setMiNet6(BigDecimal miNet6) {
        this.miNet6 = miNet6;
    }
    
    public BigDecimal getMiNet7() {
        return this.miNet7;
    }

    public void setMiNet7(BigDecimal miNet7) {
        this.miNet7 = miNet7;
    }
    
    public BigDecimal getMiNet8() {
        return this.miNet8;
    }

    public void setMiNet8(BigDecimal miNet8) {
        this.miNet8 = miNet8;
    }
    
    public BigDecimal getMiNet9() {
        return this.miNet9;
    }

    public void setMiNet9(BigDecimal miNet9) {
        this.miNet9 = miNet9;
    }
    
    public BigDecimal getMiNet10() {
        return this.miNet10;
    }

    public void setMiNet10(BigDecimal miNet10) {
        this.miNet10 = miNet10;
    }
    
    public BigDecimal getMiNet11() {
        return this.miNet11;
    }

    public void setMiNet11(BigDecimal miNet11) {
        this.miNet11 = miNet11;
    }
    
    public BigDecimal getMiNet12() {
        return this.miNet12;
    }

    public void setMiNet12(BigDecimal miNet12) {
        this.miNet12 = miNet12;
    }
    
    public BigDecimal getMiNetTm() {
        return this.miNetTm;
    }

    public void setMiNetTm(BigDecimal miNetTm) {
        this.miNetTm = miNetTm;
    }
    
    public BigDecimal getMiNetK1() {
        return this.miNetK1;
    }

    public void setMiNetK1(BigDecimal miNetK1) {
        this.miNetK1 = miNetK1;
    }
    
    public BigDecimal getMiNetK2() {
        return this.miNetK2;
    }

    public void setMiNetK2(BigDecimal miNetK2) {
        this.miNetK2 = miNetK2;
    }
    
    public BigDecimal getMiNetG() {
        return this.miNetG;
    }

    public void setMiNetG(BigDecimal miNetG) {
        this.miNetG = miNetG;
    }

    public BigDecimal getMiNetF() {
        return this.miNetF;
    }

    public void setMiNetF(BigDecimal miNetF) {
        this.miNetF = miNetF;
    }
    
    public BigDecimal getMiNetK1Diff() {
        return this.miNetK1Diff;
    }

    public void setMiNetK1Diff(BigDecimal miNetK1Diff) {
        this.miNetK1Diff = miNetK1Diff;
    }
    
    public BigDecimal getMiNetK2Diff() {
        return this.miNetK2Diff;
    }

    public void setMiNetK2Diff(BigDecimal miNetK2Diff) {
        this.miNetK2Diff = miNetK2Diff;
    }
    
    public BigDecimal getMiNetGDiff() {
        return this.miNetGDiff;
    }

    public void setMiNetGDiff(BigDecimal miNetGDiff) {
        this.miNetGDiff = miNetGDiff;
    }
    
    public BigDecimal getMiNetDiff() {
        return this.miNetDiff;
    }

    public void setMiNetDiff(BigDecimal miNetDiff) {
        this.miNetDiff = miNetDiff;
    }

    public BigDecimal getSeibanSonekiNet1() {
        return this.seibanSonekiNet1;
    }

    public void setSeibanSonekiNet1(BigDecimal seibanSonekiNet1) {
        this.seibanSonekiNet1 = seibanSonekiNet1;
    }
    
    public BigDecimal getSeibanSonekiNet2() {
        return this.seibanSonekiNet2;
    }

    public void setSeibanSonekiNet2(BigDecimal seibanSonekiNet2) {
        this.seibanSonekiNet2 = seibanSonekiNet2;
    }
    
    public BigDecimal getSeibanSonekiNet3() {
        return this.seibanSonekiNet3;
    }

    public void setSeibanSonekiNet3(BigDecimal seibanSonekiNet3) {
        this.seibanSonekiNet3 = seibanSonekiNet3;
    }
    
    public BigDecimal getSeibanSonekiNet4() {
        return this.seibanSonekiNet4;
    }

    public void setSeibanSonekiNet4(BigDecimal seibanSonekiNet4) {
        this.seibanSonekiNet4 = seibanSonekiNet4;
    }
    
    public BigDecimal getSeibanSonekiNet5() {
        return this.seibanSonekiNet5;
    }

    public void setSeibanSonekiNet5(BigDecimal seibanSonekiNet5) {
        this.seibanSonekiNet5 = seibanSonekiNet5;
    }
    
    public BigDecimal getSeibanSonekiNet6() {
        return this.seibanSonekiNet6;
    }

    public void setSeibanSonekiNet6(BigDecimal seibanSonekiNet6) {
        this.seibanSonekiNet6 = seibanSonekiNet6;
    }
    
    public BigDecimal getSeibanSonekiNet7() {
        return this.seibanSonekiNet7;
    }

    public void setSeibanSonekiNet7(BigDecimal seibanSonekiNet7) {
        this.seibanSonekiNet7 = seibanSonekiNet7;
    }
    
    public BigDecimal getSeibanSonekiNet8() {
        return this.seibanSonekiNet8;
    }

    public void setSeibanSonekiNet8(BigDecimal seibanSonekiNet8) {
        this.seibanSonekiNet8 = seibanSonekiNet8;
    }
    
    public BigDecimal getSeibanSonekiNet9() {
        return this.seibanSonekiNet9;
    }

    public void setSeibanSonekiNet9(BigDecimal seibanSonekiNet9) {
        this.seibanSonekiNet9 = seibanSonekiNet9;
    }
    
    public BigDecimal getSeibanSonekiNet10() {
        return this.seibanSonekiNet10;
    }

    public void setSeibanSonekiNet10(BigDecimal seibanSonekiNet10) {
        this.seibanSonekiNet10 = seibanSonekiNet10;
    }
    
    public BigDecimal getSeibanSonekiNet11() {
        return this.seibanSonekiNet11;
    }

    public void setSeibanSonekiNet11(BigDecimal seibanSonekiNet11) {
        this.seibanSonekiNet11 = seibanSonekiNet11;
    }
    
    public BigDecimal getSeibanSonekiNet12() {
        return this.seibanSonekiNet12;
    }

    public void setSeibanSonekiNet12(BigDecimal seibanSonekiNet12) {
        this.seibanSonekiNet12 = seibanSonekiNet12;
    }
    
    public BigDecimal getSeibanSonekiNetTm() {
        return this.seibanSonekiNetTm;
    }

    public void setSeibanSonekiNetTm(BigDecimal seibanSonekiNetTm) {
        this.seibanSonekiNetTm = seibanSonekiNetTm;
    }
    
    public BigDecimal getSeibanSonekiNetK1() {
        return this.seibanSonekiNetK1;
    }

    public void setSeibanSonekiNetK1(BigDecimal seibanSonekiNetK1) {
        this.seibanSonekiNetK1 = seibanSonekiNetK1;
    }
    
    public BigDecimal getSeibanSonekiNetK2() {
        return this.seibanSonekiNetK2;
    }

    public void setSeibanSonekiNetK2(BigDecimal seibanSonekiNetK2) {
        this.seibanSonekiNetK2 = seibanSonekiNetK2;
    }
    
    public BigDecimal getSeibanSonekiNetG() {
        return this.seibanSonekiNetG;
    }

    public void setSeibanSonekiNetG(BigDecimal seibanSonekiNetG) {
        this.seibanSonekiNetG = seibanSonekiNetG;
    }

    public BigDecimal getSeibanSonekiNetF() {
        return this.seibanSonekiNetF;
    }

    public void setSeibanSonekiNetF(BigDecimal seibanSonekiNetF) {
        this.seibanSonekiNetF = seibanSonekiNetF;
    }
    
    public BigDecimal getSeibanSonekiNetK1Diff() {
        return this.seibanSonekiNetK1Diff;
    }

    public void setSeibanSonekiNetK1Diff(BigDecimal seibanSonekiNetK1Diff) {
        this.seibanSonekiNetK1Diff = seibanSonekiNetK1Diff;
    }
    
    public BigDecimal getSeibanSonekiNetK2Diff() {
        return this.seibanSonekiNetK2Diff;
    }

    public void setSeibanSonekiNetK2Diff(BigDecimal seibanSonekiNetK2Diff) {
        this.seibanSonekiNetK2Diff = seibanSonekiNetK2Diff;
    }
    
    public BigDecimal getSeibanSonekiNetGDiff() {
        return this.seibanSonekiNetGDiff;
    }

    public void setSeibanSonekiNetGDiff(BigDecimal seibanSonekiNetGDiff) {
        this.seibanSonekiNetGDiff = seibanSonekiNetGDiff;
    }
    
    public BigDecimal getSeibanSonekiNetDiff() {
        return this.seibanSonekiNetDiff;
    }

    public void setSeibanSonekiNetDiff(BigDecimal seibanSonekiNetDiff) {
        this.seibanSonekiNetDiff = seibanSonekiNetDiff;
    }

    public BigDecimal getHatNet1Q() {
        return hatNet1Q;
    }

    public void setHatNet1Q(BigDecimal hatNet1Q) {
        this.hatNet1Q = hatNet1Q;
    }

    public BigDecimal getHatNet2Q() {
        return hatNet2Q;
    }

    public void setHatNet2Q(BigDecimal hatNet2Q) {
        this.hatNet2Q = hatNet2Q;
    }

    public BigDecimal getHatNet3Q() {
        return hatNet3Q;
    }

    public void setHatNet3Q(BigDecimal hatNet3Q) {
        this.hatNet3Q = hatNet3Q;
    }

    public BigDecimal getHatNet4Q() {
        return hatNet4Q;
    }

    public void setHatNet4Q(BigDecimal hatNet4Q) {
        this.hatNet4Q = hatNet4Q;
    }

    public BigDecimal getHatNet1QDiff() {
        return hatNet1QDiff;
    }

    public void setHatNet1QDiff(BigDecimal hatNet1QDiff) {
        this.hatNet1QDiff = hatNet1QDiff;
    }

    public BigDecimal getHatNet2QDiff() {
        return hatNet2QDiff;
    }

    public void setHatNet2QDiff(BigDecimal hatNet2QDiff) {
        this.hatNet2QDiff = hatNet2QDiff;
    }

    public BigDecimal getHatNet3QDiff() {
        return hatNet3QDiff;
    }

    public void setHatNet3QDiff(BigDecimal hatNet3QDiff) {
        this.hatNet3QDiff = hatNet3QDiff;
    }

    public BigDecimal getHatNet4QDiff() {
        return hatNet4QDiff;
    }

    public void setHatNet4QDiff(BigDecimal hatNet4QDiff) {
        this.hatNet4QDiff = hatNet4QDiff;
    }

    public BigDecimal getMiNet1Q() {
        return miNet1Q;
    }

    public void setMiNet1Q(BigDecimal miNet1Q) {
        this.miNet1Q = miNet1Q;
    }

    public BigDecimal getMiNet2Q() {
        return miNet2Q;
    }

    public void setMiNet2Q(BigDecimal miNet2Q) {
        this.miNet2Q = miNet2Q;
    }

    public BigDecimal getMiNet3Q() {
        return miNet3Q;
    }

    public void setMiNet3Q(BigDecimal miNet3Q) {
        this.miNet3Q = miNet3Q;
    }

    public BigDecimal getMiNet4Q() {
        return miNet4Q;
    }

    public void setMiNet4Q(BigDecimal miNet4Q) {
        this.miNet4Q = miNet4Q;
    }

    public BigDecimal getMiNet1QDiff() {
        return miNet1QDiff;
    }

    public void setMiNet1QDiff(BigDecimal miNet1QDiff) {
        this.miNet1QDiff = miNet1QDiff;
    }

    public BigDecimal getMiNet2QDiff() {
        return miNet2QDiff;
    }

    public void setMiNet2QDiff(BigDecimal miNet2QDiff) {
        this.miNet2QDiff = miNet2QDiff;
    }

    public BigDecimal getMiNet3QDiff() {
        return miNet3QDiff;
    }

    public void setMiNet3QDiff(BigDecimal miNet3QDiff) {
        this.miNet3QDiff = miNet3QDiff;
    }

    public BigDecimal getMiNet4QDiff() {
        return miNet4QDiff;
    }

    public void setMiNet4QDiff(BigDecimal miNet4QDiff) {
        this.miNet4QDiff = miNet4QDiff;
    }

    public BigDecimal getSeibanSonekiNet1Q() {
        return seibanSonekiNet1Q;
    }

    public void setSeibanSonekiNet1Q(BigDecimal seibanSonekiNet1Q) {
        this.seibanSonekiNet1Q = seibanSonekiNet1Q;
    }

    public BigDecimal getSeibanSonekiNet2Q() {
        return seibanSonekiNet2Q;
    }

    public void setSeibanSonekiNet2Q(BigDecimal seibanSonekiNet2Q) {
        this.seibanSonekiNet2Q = seibanSonekiNet2Q;
    }

    public BigDecimal getSeibanSonekiNet3Q() {
        return seibanSonekiNet3Q;
    }

    public void setSeibanSonekiNet3Q(BigDecimal seibanSonekiNet3Q) {
        this.seibanSonekiNet3Q = seibanSonekiNet3Q;
    }

    public BigDecimal getSeibanSonekiNet4Q() {
        return seibanSonekiNet4Q;
    }

    public void setSeibanSonekiNet4Q(BigDecimal seibanSonekiNet4Q) {
        this.seibanSonekiNet4Q = seibanSonekiNet4Q;
    }

    public BigDecimal getSeibanSonekiNet1QDiff() {
        return seibanSonekiNet1QDiff;
    }

    public void setSeibanSonekiNet1QDiff(BigDecimal seibanSonekiNet1QDiff) {
        this.seibanSonekiNet1QDiff = seibanSonekiNet1QDiff;
    }

    public BigDecimal getSeibanSonekiNet2QDiff() {
        return seibanSonekiNet2QDiff;
    }

    public void setSeibanSonekiNet2QDiff(BigDecimal seibanSonekiNet2QDiff) {
        this.seibanSonekiNet2QDiff = seibanSonekiNet2QDiff;
    }

    public BigDecimal getSeibanSonekiNet3QDiff() {
        return seibanSonekiNet3QDiff;
    }

    public void setSeibanSonekiNet3QDiff(BigDecimal seibanSonekiNet3QDiff) {
        this.seibanSonekiNet3QDiff = seibanSonekiNet3QDiff;
    }

    public BigDecimal getSeibanSonekiNet4QDiff() {
        return seibanSonekiNet4QDiff;
    }

    public void setSeibanSonekiNet4QDiff(BigDecimal seibanSonekiNet4QDiff) {
        this.seibanSonekiNet4QDiff = seibanSonekiNet4QDiff;
    }

    /**
     * @return the kawaseEikyo1
     */
    public BigDecimal getKawaseEikyo1() {
        return kawaseEikyo1;
    }

    /**
     * @param kawaseEikyo1 the kawaseEikyo1 to set
     */
    public void setKawaseEikyo1(BigDecimal kawaseEikyo1) {
        this.kawaseEikyo1 = kawaseEikyo1;
    }

    /**
     * @return the kawaseEikyo2
     */
    public BigDecimal getKawaseEikyo2() {
        return kawaseEikyo2;
    }

    /**
     * @param kawaseEikyo2 the kawaseEikyo2 to set
     */
    public void setKawaseEikyo2(BigDecimal kawaseEikyo2) {
        this.kawaseEikyo2 = kawaseEikyo2;
    }

    /**
     * @return the kawaseEikyo3
     */
    public BigDecimal getKawaseEikyo3() {
        return kawaseEikyo3;
    }

    /**
     * @param kawaseEikyo3 the kawaseEikyo3 to set
     */
    public void setKawaseEikyo3(BigDecimal kawaseEikyo3) {
        this.kawaseEikyo3 = kawaseEikyo3;
    }

    /**
     * @return the kawaseEikyo4
     */
    public BigDecimal getKawaseEikyo4() {
        return kawaseEikyo4;
    }

    /**
     * @param kawaseEikyo4 the kawaseEikyo4 to set
     */
    public void setKawaseEikyo4(BigDecimal kawaseEikyo4) {
        this.kawaseEikyo4 = kawaseEikyo4;
    }

    /**
     * @return the kawaseEikyo5
     */
    public BigDecimal getKawaseEikyo5() {
        return kawaseEikyo5;
    }

    /**
     * @param kawaseEikyo5 the kawaseEikyo5 to set
     */
    public void setKawaseEikyo5(BigDecimal kawaseEikyo5) {
        this.kawaseEikyo5 = kawaseEikyo5;
    }

    /**
     * @return the kawaseEikyo6
     */
    public BigDecimal getKawaseEikyo6() {
        return kawaseEikyo6;
    }

    /**
     * @param kawaseEikyo6 the kawaseEikyo6 to set
     */
    public void setKawaseEikyo6(BigDecimal kawaseEikyo6) {
        this.kawaseEikyo6 = kawaseEikyo6;
    }

    /**
     * @return the kawaseEikyo7
     */
    public BigDecimal getKawaseEikyo7() {
        return kawaseEikyo7;
    }

    /**
     * @param kawaseEikyo7 the kawaseEikyo7 to set
     */
    public void setKawaseEikyo7(BigDecimal kawaseEikyo7) {
        this.kawaseEikyo7 = kawaseEikyo7;
    }

    /**
     * @return the kawaseEikyo8
     */
    public BigDecimal getKawaseEikyo8() {
        return kawaseEikyo8;
    }

    /**
     * @param kawaseEikyo8 the kawaseEikyo8 to set
     */
    public void setKawaseEikyo8(BigDecimal kawaseEikyo8) {
        this.kawaseEikyo8 = kawaseEikyo8;
    }

    /**
     * @return the kawaseEikyo9
     */
    public BigDecimal getKawaseEikyo9() {
        return kawaseEikyo9;
    }

    /**
     * @param kawaseEikyo9 the kawaseEikyo9 to set
     */
    public void setKawaseEikyo9(BigDecimal kawaseEikyo9) {
        this.kawaseEikyo9 = kawaseEikyo9;
    }

    /**
     * @return the kawaseEikyo10
     */
    public BigDecimal getKawaseEikyo10() {
        return kawaseEikyo10;
    }

    /**
     * @param kawaseEikyo10 the kawaseEikyo10 to set
     */
    public void setKawaseEikyo10(BigDecimal kawaseEikyo10) {
        this.kawaseEikyo10 = kawaseEikyo10;
    }

    /**
     * @return the kawaseEikyo11
     */
    public BigDecimal getKawaseEikyo11() {
        return kawaseEikyo11;
    }

    /**
     * @param kawaseEikyo11 the kawaseEikyo11 to set
     */
    public void setKawaseEikyo11(BigDecimal kawaseEikyo11) {
        this.kawaseEikyo11 = kawaseEikyo11;
    }

    /**
     * @return the kawaseEikyo12
     */
    public BigDecimal getKawaseEikyo12() {
        return kawaseEikyo12;
    }

    /**
     * @param kawaseEikyo12 the kawaseEikyo12 to set
     */
    public void setKawaseEikyo12(BigDecimal kawaseEikyo12) {
        this.kawaseEikyo12 = kawaseEikyo12;
    }

    /**
     * @return the kawaseEikyoTm
     */
    public BigDecimal getKawaseEikyoTm() {
        return kawaseEikyoTm;
    }

    /**
     * @param kawaseEikyoTm the kawaseEikyoTm to set
     */
    public void setKawaseEikyoTm(BigDecimal kawaseEikyoTm) {
        this.kawaseEikyoTm = kawaseEikyoTm;
    }

    /**
     * @return the kawaseEikyoK1
     */
    public BigDecimal getKawaseEikyoK1() {
        return kawaseEikyoK1;
    }

    /**
     * @param kawaseEikyoK1 the kawaseEikyoK1 to set
     */
    public void setKawaseEikyoK1(BigDecimal kawaseEikyoK1) {
        this.kawaseEikyoK1 = kawaseEikyoK1;
    }

    /**
     * @return the kawaseEikyoK2
     */
    public BigDecimal getKawaseEikyoK2() {
        return kawaseEikyoK2;
    }

    /**
     * @param kawaseEikyoK2 the kawaseEikyoK2 to set
     */
    public void setKawaseEikyoK2(BigDecimal kawaseEikyoK2) {
        this.kawaseEikyoK2 = kawaseEikyoK2;
    }

    /**
     * @return the kawaseEikyoG
     */
    public BigDecimal getKawaseEikyoG() {
        return kawaseEikyoG;
    }

    /**
     * @param kawaseEikyoG the kawaseEikyoG to set
     */
    public void setKawaseEikyoG(BigDecimal kawaseEikyoG) {
        this.kawaseEikyoG = kawaseEikyoG;
    }

    /**
     * @return the kawaseEikyoF
     */
    public BigDecimal getKawaseEikyoF() {
        return kawaseEikyoF;
    }

    /**
     * @param kawaseEikyoF the kawaseEikyoF to set
     */
    public void setKawaseEikyoF(BigDecimal kawaseEikyoF) {
        this.kawaseEikyoF = kawaseEikyoF;
    }

    /**
     * @return the kawaseEikyoK1Diff
     */
    public BigDecimal getKawaseEikyoK1Diff() {
        return kawaseEikyoK1Diff;
    }

    /**
     * @param kawaseEikyoK1Diff the kawaseEikyoK1Diff to set
     */
    public void setKawaseEikyoK1Diff(BigDecimal kawaseEikyoK1Diff) {
        this.kawaseEikyoK1Diff = kawaseEikyoK1Diff;
    }

    /**
     * @return the kawaseEikyoK2Diff
     */
    public BigDecimal getKawaseEikyoK2Diff() {
        return kawaseEikyoK2Diff;
    }

    /**
     * @param kawaseEikyoK2Diff the kawaseEikyoK2Diff to set
     */
    public void setKawaseEikyoK2Diff(BigDecimal kawaseEikyoK2Diff) {
        this.kawaseEikyoK2Diff = kawaseEikyoK2Diff;
    }

    /**
     * @return the kawaseEikyoGDiff
     */
    public BigDecimal getKawaseEikyoGDiff() {
        return kawaseEikyoGDiff;
    }

    /**
     * @param kawaseEikyoGDiff the kawaseEikyoGDiff to set
     */
    public void setKawaseEikyoGDiff(BigDecimal kawaseEikyoGDiff) {
        this.kawaseEikyoGDiff = kawaseEikyoGDiff;
    }

    /**
     * @return the kawaseEikyoDiff
     */
    public BigDecimal getKawaseEikyoDiff() {
        return kawaseEikyoDiff;
    }

    /**
     * @param kawaseEikyoDiff the kawaseEikyoDiff to set
     */
    public void setKawaseEikyoDiff(BigDecimal kawaseEikyoDiff) {
        this.kawaseEikyoDiff = kawaseEikyoDiff;
    }

    /**
     * @return the kawaseEikyo1Q
     */
    public BigDecimal getKawaseEikyo1Q() {
        return kawaseEikyo1Q;
    }

    /**
     * @param kawaseEikyo1Q the kawaseEikyo1Q to set
     */
    public void setKawaseEikyo1Q(BigDecimal kawaseEikyo1Q) {
        this.kawaseEikyo1Q = kawaseEikyo1Q;
    }

    /**
     * @return the kawaseEikyo2Q
     */
    public BigDecimal getKawaseEikyo2Q() {
        return kawaseEikyo2Q;
    }

    /**
     * @param kawaseEikyo2Q the kawaseEikyo2Q to set
     */
    public void setKawaseEikyo2Q(BigDecimal kawaseEikyo2Q) {
        this.kawaseEikyo2Q = kawaseEikyo2Q;
    }

    /**
     * @return the kawaseEikyo3Q
     */
    public BigDecimal getKawaseEikyo3Q() {
        return kawaseEikyo3Q;
    }

    /**
     * @param kawaseEikyo3Q the kawaseEikyo3Q to set
     */
    public void setKawaseEikyo3Q(BigDecimal kawaseEikyo3Q) {
        this.kawaseEikyo3Q = kawaseEikyo3Q;
    }

    /**
     * @return the kawaseEikyo4Q
     */
    public BigDecimal getKawaseEikyo4Q() {
        return kawaseEikyo4Q;
    }

    /**
     * @param kawaseEikyo4Q the kawaseEikyo4Q to set
     */
    public void setKawaseEikyo4Q(BigDecimal kawaseEikyo4Q) {
        this.kawaseEikyo4Q = kawaseEikyo4Q;
    }

    /**
     * @return the kawaseEikyo1QDiff
     */
    public BigDecimal getKawaseEikyo1QDiff() {
        return kawaseEikyo1QDiff;
    }

    /**
     * @param kawaseEikyo1QDiff the kawaseEikyo1QDiff to set
     */
    public void setKawaseEikyo1QDiff(BigDecimal kawaseEikyo1QDiff) {
        this.kawaseEikyo1QDiff = kawaseEikyo1QDiff;
    }

    /**
     * @return the kawaseEikyo2QDiff
     */
    public BigDecimal getKawaseEikyo2QDiff() {
        return kawaseEikyo2QDiff;
    }

    /**
     * @param kawaseEikyo2QDiff the kawaseEikyo2QDiff to set
     */
    public void setKawaseEikyo2QDiff(BigDecimal kawaseEikyo2QDiff) {
        this.kawaseEikyo2QDiff = kawaseEikyo2QDiff;
    }

    /**
     * @return the kawaseEikyo3QDiff
     */
    public BigDecimal getKawaseEikyo3QDiff() {
        return kawaseEikyo3QDiff;
    }

    /**
     * @param kawaseEikyo3QDiff the kawaseEikyo3QDiff to set
     */
    public void setKawaseEikyo3QDiff(BigDecimal kawaseEikyo3QDiff) {
        this.kawaseEikyo3QDiff = kawaseEikyo3QDiff;
    }

    /**
     * @return the kawaseEikyo4QDiff
     */
    public BigDecimal getKawaseEikyo4QDiff() {
        return kawaseEikyo4QDiff;
    }

    /**
     * @param kawaseEikyo4QDiff the kawaseEikyo4QDiff to set
     */
    public void setKawaseEikyo4QDiff(BigDecimal kawaseEikyo4QDiff) {
        this.kawaseEikyo4QDiff = kawaseEikyo4QDiff;
    }

}
