/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package jp.co.toshiba.hby.pspromis.syuueki.service.mikomiupload;

import java.math.BigDecimal;
import java.sql.SQLException;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import javax.ejb.Stateless;
import javax.inject.Inject;
import javax.interceptor.Interceptors;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import jp.co.toshiba.hby.pspromis.common.util.StringUtil;
import jp.co.toshiba.hby.pspromis.syuueki.bean.MikomiUploadBean;
import jp.co.toshiba.hby.pspromis.syuueki.bean.MikomiUploadErrorBean;
import jp.co.toshiba.hby.pspromis.syuueki.entity.SyuGeBukkenInfoTbl;
import jp.co.toshiba.hby.pspromis.syuueki.enums.MikomiUploadLabel;
import jp.co.toshiba.hby.pspromis.syuueki.interceptor.TranceInterceptor;
import jp.co.toshiba.hby.pspromis.syuueki.util.PoiUtil;
import jp.co.toshiba.hby.pspromis.syuueki.util.Utils;
import org.apache.commons.lang3.StringUtils;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * PS-Promis収益管理システム
 * 見込アップロード処理「（技）直課除くＢ項番」「（営業）販直費」
 * @author (NPC)S.Ibayashi
 */
@Stateless
@Interceptors({TranceInterceptor.class})
public class EtcUploadImpl implements UploadComponent {
 
    @PersistenceContext(unitName = jp.co.toshiba.hby.pspromis.syuueki.util.ConstantString.syuuekiDataSourceName)
    private EntityManager em;

    /**
     * ロガー
     */
    public static final Logger logger = LoggerFactory.getLogger(EtcUploadImpl.class);
    
    @Inject
    private MikomiUploadBean mikomiUploadBean;
    
    @Inject
    private MikomiUploadErrorBean mikomiUploadErrorBean;
    
    @Inject
    private UploadDataAccess uploadDataAccess;

    private static final int START_ROW = 6;

    /**
     * 入力内容のデータチェック
     * @return 
     * @throws java.lang.Exception
     */
    @Override
    public boolean isDataCheck() throws Exception {
        logger.info("EtcUploadImpl isDataCheck");

        boolean isCheck;
        String titleInfo = "";
        String sheetName = "";
        Sheet sheet;
        List<String> errorMessageList;
        Workbook book = mikomiUploadBean.getWorkBook();

        // ファイルの全シートに対して処理を行う。
        for (int i=0; i<book.getNumberOfSheets(); i++) {
            sheet = book.getSheetAt(i);
            // シート名のチェック
            isCheck = isCheckTitile(sheet);
            
            if (isCheck) {
                sheetName = StringUtils.trimToEmpty(sheet.getSheetName());
                titleInfo = titleInfo.equals("") ? sheetName : titleInfo + ":" + sheetName;
            }
        }
        
        mikomiUploadErrorBean.setTitleInfo(titleInfo);

        // シート名が正常の場合、各シートからデータを取得/チェック
        errorMessageList = mikomiUploadErrorBean.getErrorMessage();
        if (errorMessageList == null) {
            for (int i=0; i<book.getNumberOfSheets(); i++) {
                sheet = book.getSheetAt(i);
                exeGetData(sheet);
            }
        }

        errorMessageList = mikomiUploadErrorBean.getErrorMessage();
        if (errorMessageList == null) {
            mikomiUploadErrorBean.setIsSuccess(true);
        } else {
            mikomiUploadErrorBean.setIsSuccess(false);
        }

        return mikomiUploadErrorBean.isIsSuccess();
    }

    /**
     * アップロード処理の実行
     * @throws java.lang.Exception
     */
    @Override
    public void executeUpload() throws Exception {
        logger.info("EtcUploadImpl executeUpload");
        
        String kbn = StringUtils.defaultString(mikomiUploadBean.getUploadKbn());
        int cldSumFlg = 0;
        
        // データの登録
        List<Map<String, Object>> dataList = mikomiUploadBean.getDataList();
        
        if (dataList == null) {
            return;
        }
        
        // データを登録
        String ankenId = "";
        String befAnkenId = "";
        Set<String> ankenIdSet = new HashSet<>();
        String minSyuekiYm = "";

        for (Map<String, Object> data : dataList) {
            ankenId = (String)data.get("ankenId");
            
            // SYU_KI_NET_CATE_TITLE_TBLの新規登録
            if (!befAnkenId.equals(ankenId)) {
                uploadDataAccess.insertKiNetCateTitleTbl(data);
                ankenIdSet.add(ankenId);
                //callProcTest(data);
                
                // 指定案件に対して再計算FLGを立てる(進行基準画面の再計算ボタン用)。
                uploadDataAccess.setSaikeisanFlg(ankenId, (Integer)data.get("rirekiId"));
            }

            if (kbn.equals("06")) {
                /////// （技）直課除くＢ項番 の場合
                // SYU_KI_NET_CATE_TUKI_CLD_TBLの更新(or新規登録)
                uploadDataAccess.updateKiNetCateTukiCdlTbl(data);
                cldSumFlg = 1;

            } else if (kbn.equals("07")) {
                /////// （営業）販直費
                // SYU_KI_NET_CATE_TUKI_TBLの更新(or新規登録)
                uploadDataAccess.updateKiNetCateTukiTbl(data);

            }

            // 登録データ内で最小の年月を取得
            if (StringUtils.isEmpty(minSyuekiYm) || minSyuekiYm.compareTo((String)data.get("syuekiYm")) >= 0) {
                minSyuekiYm = (String)data.get("syuekiYm");
            }
            
            befAnkenId = ankenId;
        }

        // （技）直課除くＢ項番 の場合
        // SYU_KI_NET_CATE_TUKI_CLD_TBLからSYU_KI_NET_CATE_TUKI_TBLへ集計値を登録する。
        if (cldSumFlg == 1) {
            String[] ankenIdList = ankenIdSet.toArray(new String[0]);
            List<Map<String, Object>> sumYmList = uploadDataAccess.getSumYmList(ankenIdList, minSyuekiYm);
            
            for (Map<String, Object> info : sumYmList) {
                Map<String, Object> cateTukiInfo = new HashMap<>();
                cateTukiInfo.put("ankenId", info.get("ANKEN_ID"));
                cateTukiInfo.put("rirekiId", 0);
                cateTukiInfo.put("dataKbn", "M");
                cateTukiInfo.put("syuekiYm", info.get("SYUEKI_YM"));
                cateTukiInfo.put("categoryCode", info.get("CATEGORY_CODE"));
                cateTukiInfo.put("categoryKbn1", info.get("CATEGORY_KBN1"));
                cateTukiInfo.put("categoryKbn2", info.get("CATEGORY_KBN2"));
                cateTukiInfo.put("net", info.get("NET"));

                uploadDataAccess.updateKiNetCateTukiTbl(cateTukiInfo);
            }
        }

    }

    /**
     * Excelのシート名チェック<br>
     */
    private boolean isCheckTitile(Sheet sheet) {
        String kbn = StringUtils.defaultString(mikomiUploadBean.getUploadKbn());
        String errorMessage = MikomiUploadLabel.getValue(MikomiUploadLabel.titleFormatError);
        boolean isSuccess = false;
     
        String sheetName = StringUtils.trimToEmpty(sheet.getSheetName());

        if (StringUtils.isNotEmpty(sheetName)) {
            if (sheetName.equals("直課除くＢ項番") && kbn.equals("06")) {
                isSuccess = true;
            } else if (sheetName.equals("完成図書") && kbn.equals("06")) {
                isSuccess = true;
            } else if (sheetName.equals("派遣人件費") && kbn.equals("06")) {
                isSuccess = true;
            } else if (sheetName.equals("販直費") && kbn.equals("07")) {
                isSuccess = true;
            }
        }
        
        if (!isSuccess) {
            mikomiUploadErrorBean.addErrorMessage(errorMessage + "(" + sheetName + ")");
        }
        
        return isSuccess;
    }
    
    /**getBukaCategoryCode
     * シート内の部課コードから、カテゴリマスタの情報を取得
     * @param sheet
     * @return 
     * @throws java.sql.SQLException 
     */
    public Map<String, Object> getCategoryMap(Sheet sheet) throws SQLException {
        Map<String, Object> categoryMstInfo = null;
        
        String kbn = StringUtils.defaultString(mikomiUploadBean.getUploadKbn());
        String bukaCd;
        String categoryCode;
        Row row;
        
        String sheetName = StringUtils.trimToEmpty(sheet.getSheetName());
        
        if (kbn.equals("06")) {
            /////// （技）直課除くＢ項番 の場合
            // C4セルから部課コードを取得
            row = PoiUtil.getRow(sheet, 3);
            // (2018/01)直課Excelには部課コードを入れるのをやめて、カテゴリコードを直接入れるようにするので、それでマスタを検索する。
            //bukaCd = Utils.getObjToStrValue(PoiUtil.getCellValue(row, 2));
            //categoryCode = UploadUtil.getBukaCategoryCode(bukaCd);
            //categoryMstInfo = uploadDataAccess.categoryMstInfo(categoryCode);
            categoryCode = Utils.getObjToStrValue(PoiUtil.getCellValue(row, 2));
            categoryMstInfo = uploadDataAccess.categoryMstInfoFromCateCode(categoryCode);
            if (categoryMstInfo == null) {
                //mikomiUploadErrorBean.addErrorMessage("■" + sheetName + ":" + MikomiUploadLabel.getValue(MikomiUploadLabel.bukaError) + "(" + bukaCd + ")");
                mikomiUploadErrorBean.addErrorMessage("■" + sheetName + ":" + MikomiUploadLabel.getValue(MikomiUploadLabel.categoryError) + "(" + categoryCode + ")");
            }

        } else if (kbn.equals("07")) {
            /////// （営業）販直費
            categoryMstInfo = uploadDataAccess.categoryMstInfo("HANCHOKU");
            if (categoryMstInfo == null) {
                mikomiUploadErrorBean.addErrorMessage("■" + sheetName + ":" + MikomiUploadLabel.getValue(MikomiUploadLabel.categoryError));
            }

        }

        return categoryMstInfo;
    }

    /**
     * Excel上の一覧を読み取って、DBに登録する値の取得/エラーチェックを行う
     */
    private boolean exeGetData(Sheet sheet) throws Exception {
        Row row;
        Cell cell;
        boolean isSuccess = true;
        boolean isAmount;
        int errorRow;
        String chunyuAmount;
        String amount;
        
        String titleOrderNo;
        String ankenId;
        String orderNo;
        
        SyuGeBukkenInfoTbl bukkenEn;
        Map<String, Object> categoryMstInfo = null;

        // シート名
        String sheetName = StringUtils.trimToEmpty(sheet.getSheetName());
        
        // ファイル種別
        String fileKbn = UploadUtil.getCldFileKbn(mikomiUploadBean.getUploadKbn(), sheetName);

        // エラーメッセージ
        String chunyuAmountFormatError  = MikomiUploadLabel.getValue(MikomiUploadLabel.chunyuAmountFormatError);
        String chunyuAmountKetaFormatError = MikomiUploadLabel.getValue(MikomiUploadLabel.chunyuAmountKetaFormatError);
        
        // カテゴリコードの取得
        categoryMstInfo = getCategoryMap(sheet);
        // カテゴリコード取得でエラーがある場合は終了
        if (categoryMstInfo == null) {
            return false;
        }

        // 年月データ取得/チェック
        Map<String, Integer> ymMap = getCheckYm(sheet);
        // 年月データ取得で1件でもエラーがある場合は終了
        if (ymMap == null) {
            return false;
        }

        for (int cnt=START_ROW + 1; cnt<=sheet.getLastRowNum(); cnt++) {
            // 注番タイトル取得
            row = sheet.getRow(cnt);
            cell = PoiUtil.getCell(row, 2);
            titleOrderNo = Utils.getObjToStrValue(PoiUtil.getCellValue(cell));
            
            if (StringUtils.isNotEmpty(titleOrderNo) && titleOrderNo.equals("合計")) {
                break;
            }

            if (!UploadUtil.isTargetOrderNo(titleOrderNo)) {
                continue;
            }

            // 注番の取得/データチェック(事業部が検索条件を異なる場合もNGとする)
            bukkenEn = uploadDataAccess.findOnoBuken(titleOrderNo, "1");
            if (bukkenEn == null || !bukkenEn.getDivisionCode().equals(mikomiUploadBean.getUploadDivisionCode())) {
                errorRow = row.getRowNum() + 1;
                isSuccess = false;
                mikomiUploadErrorBean.addErrorMessage("■" + sheetName + ":(" + errorRow + ")行目：" + MikomiUploadLabel.getValue(MikomiUploadLabel.projectError) + "(" + titleOrderNo + ")");

                continue;
            }

            // 正常終了時のため、結果子画面に出力するメッセージ(案件番号/注番)を登録
            orderNo = bukkenEn.getMainOrderNo();
            ankenId = bukkenEn.getAnkenId();
            mikomiUploadErrorBean.addMessage("■" + sheetName + ":" + ankenId + "/" + orderNo);

            // 取得した注番の各年月の金額を取得
            if (StringUtils.isNotEmpty(titleOrderNo)) {
                Set<String> keys = ymMap.keySet();
                Iterator<String> ite = keys.iterator();
                while (ite.hasNext()) {
                    Map<String, Object> dataMap = new HashMap<>();

                    // 処理対象年月を取得
                    String cellYm = ite.next();
                    String ym = convCellValToDate(cellYm, "");
                    // 処理対象年月の列indexを取得
                    int cellIndex = ymMap.get(cellYm);

                    // 処理対象月の金額取得
                    chunyuAmount = Utils.getObjToStrValue(PoiUtil.getCellValue(row, cellIndex));
                    
                    isAmount = true;
                    amount = changeAmountStr(chunyuAmount);
                    
                    if ("formatError".equals(amount)) {
                        isAmount = false;
                        isSuccess = false;
                        errorRow = row.getRowNum() + 1;
                        mikomiUploadErrorBean.addErrorMessage("■" + sheetName + ":" + titleOrderNo + "(" + errorRow + ")行目：" + cellYm + "：" + chunyuAmountFormatError + "(" + chunyuAmount + ")");

                    } else if ("ketaOverError".equals(amount)) {
                        isAmount = false;
                        isSuccess = false;
                        errorRow = row.getRowNum() + 1;
                        mikomiUploadErrorBean.addErrorMessage("■" + sheetName + ":" + titleOrderNo + "(" + errorRow + ")行目：" + cellYm + "：" + chunyuAmountKetaFormatError + "(" + chunyuAmount + ")");
                    }

                    // 登録データをMapに格納。
                    dataMap.put("ankenId", ankenId);
                    dataMap.put("rirekiId", 0);
                    dataMap.put("dataKbn", "M");
                    dataMap.put("syuekiYm", ym);
                    dataMap.put("categoryCode", categoryMstInfo.get("CATEGORY_CODE"));
                    dataMap.put("categoryKbn1", categoryMstInfo.get("CATEGORY_KBN1"));
                    dataMap.put("categoryKbn2", categoryMstInfo.get("CATEGORY_KBN2"));
                    dataMap.put("categoryName1", categoryMstInfo.get("CATEGORY_NAME1"));
                    dataMap.put("categoryName2", categoryMstInfo.get("CATEGORY_NAME2"));
                    dataMap.put("categorySeq", categoryMstInfo.get("CATEGORY_SEQ"));
                    dataMap.put("kbn", fileKbn);
                    if (isAmount) {
                        dataMap.put("net", Utils.changeBigDecimal(amount));
                    }

                    mikomiUploadBean.addDataList(dataMap);
                }

            }
        }

        return isSuccess;
    }
    
    /**
     * シート上の年月をチェック<br>
     * 取得した年月はMap(年月, 年月列位置)で取得する。
     */
    private Map<String, Integer> getCheckYm(Sheet sheet) {
        String sheetName = StringUtils.trimToEmpty(sheet.getSheetName());
        Row row;
        Cell cell;
        String bforeMonth = "";
        int errorRow = 0;
        boolean isSuccess = true;

        Map<String, Integer> ymMap = new LinkedHashMap<>();
        
        // エラーメッセージ
        String monthBeforeError = MikomiUploadLabel.getValue(MikomiUploadLabel.monthBeforeError);
        String monthFormatError = MikomiUploadLabel.getValue(MikomiUploadLabel.monthFormatError);
        
        for (int cnt=START_ROW; cnt<=sheet.getLastRowNum(); cnt++) {
            // 注番タイトル取得
            row = sheet.getRow(cnt);
            String titleOrderNo = Utils.getObjToStrValue(PoiUtil.getCellValue(row, 2));
            
             if (StringUtils.isNotEmpty(titleOrderNo) && titleOrderNo.equals("代表注番")) {
                bforeMonth = "";
                for (int cnt2=4; cnt2<=100; cnt2++) {
                    cell = PoiUtil.getCell(row, cnt2);
                    String rawData = Utils.getObjToStrValue(cell);

                    if (StringUtils.isEmpty(rawData) || rawData.equals("備　　　　　　　考")) {
                        break;
                    }

                    if (cell.getCellType() == Cell.CELL_TYPE_FORMULA) {
                        continue;
                    }
                    
                    String dataMonth = convCellValToDate(rawData, bforeMonth);

                    if (dataMonth.equals("noUpdate")) {
                        continue;
                    }

                    // 日付エラーチェック
                    if (dataMonth.equals(monthBeforeError) || dataMonth.equals(monthFormatError)) {
                        errorRow = row.getRowNum() + 1;
                        isSuccess = false;
                        mikomiUploadErrorBean.addErrorMessage("■" + sheetName + "(" + errorRow + ")行目" + "：" + dataMonth + "(" + rawData + ")");
                    } else {
                        // 日付が正常の場合
                        ymMap.put(rawData, cnt2);
                        bforeMonth = dataMonth;
                    }
                }
                
                break;
            }
        }

        if (!isSuccess) {
            ymMap = null;
        }
        
        return ymMap;
    }

    /**
     * 日付データの読込み<BR>
     * セルの値が「YYYY年MM月DD日」のとき使用
     * @param cell
     * @return
     */
    private String convCellValToDate(String cellValue, String beforeMonth) {
        String retStr = cellValue;	
        String BeforeFormMonthError = "noUpdate";

        try {
            retStr = Utils.convertToHankaku(retStr);
            retStr = StringUtils.replace(retStr, "/", "");
            retStr = StringUtils.replace(retStr, ",", "");

            if (retStr.endsWith("上期計") || retStr.endsWith("下期計") || retStr.endsWith("期計") || retStr.endsWith("年度計")) {
                retStr = BeforeFormMonthError;
                return retStr;
            }

            if (retStr.startsWith("～") && retStr.endsWith("年度実績")) {
                retStr = StringUtils.replace(retStr, "～", "");
                retStr = UploadUtil.nenAdd1(retStr);
                retStr = StringUtils.replace(retStr, "年度実績", "03");

            } else if (retStr.endsWith("年上期")) {
                retStr = StringUtils.replace(retStr, "年上期", "09");
				
            } else if (retStr.endsWith("年下期")) {
                retStr = UploadUtil.nenAdd1(retStr);
                retStr = StringUtils.replace(retStr, "年下期", "03");

            } else if (retStr.endsWith("年1Q計画")) {
                retStr = StringUtils.replace(retStr, "年1Q計画", "06");

            } else if (retStr.endsWith("年2Q計画")) {
                retStr = StringUtils.replace(retStr, "年2Q計画", "09");

            } else if (retStr.endsWith("年3Q計画")) {
                retStr = StringUtils.replace(retStr, "年3Q計画", "12");

            } else if (retStr.endsWith("年4Q計画")) {
                retStr = UploadUtil.nenAdd1(retStr);
                retStr = StringUtils.replace(retStr, "年4Q計画", "03");

            } else if (retStr.endsWith("1Q")) {
                retStr = StringUtils.replace(retStr, "1Q", "06");
            
            } else if (retStr.endsWith("2Q")) {
                retStr = StringUtils.replace(retStr, "2Q", "09");

            } else if (retStr.endsWith("3Q")) {
                retStr = StringUtils.replace(retStr, "3Q", "12");
            
            } else if (retStr.endsWith("4Q")) {
                retStr = UploadUtil.nenAdd1(retStr);
                retStr = StringUtils.replace(retStr, "4Q", "03");

            } else if (retStr.endsWith("上期")) {	
                retStr = StringUtils.replace(retStr, "上期", "09");
            
            } else if (retStr.endsWith("下期")) {
                retStr = UploadUtil.nenAdd1(retStr);
                retStr = StringUtils.replace(retStr, "下期", "03");

            } else if (retStr.endsWith("年計画")) {
                retStr = UploadUtil.nenAdd1(retStr);
                retStr = StringUtils.replace(retStr, "年計画", "03");

            } else if (retStr.endsWith("年度")) {
                retStr = UploadUtil.nenAdd1(retStr);
                retStr = StringUtils.replace(retStr, "年度", "03");
            } else if (retStr.matches(".*実績.*")) {
                retStr = BeforeFormMonthError;
                return retStr;
            }
            
            Date date = UploadUtil.changeStrToDate(retStr);
            retStr = UploadUtil.changeDateToStr(date);
            
            // セルの年月が画面で指定した開始年月より前であれば読み飛ばす。
            Date startYm = mikomiUploadBean.getStartYm();
            if (date.before(startYm)) {
                retStr = BeforeFormMonthError;
                return retStr;
            }
            
            // 取得した年月が前のセルより前年月(時系列になっていない)場合はエラーとする。
            if (StringUtil.isNotEmpty(beforeMonth)) {
                Date beforeDate = Utils.parseDate(beforeMonth);
                if (date.before(beforeDate)) {
                    retStr = MikomiUploadLabel.getValue(MikomiUploadLabel.monthBeforeError);
                }
            }

        } catch (Exception e) {
            retStr = MikomiUploadLabel.getValue(MikomiUploadLabel.monthFormatError);
        }

        return retStr;
    }

    private String changeAmountStr(String str) {
        String amount = str;

        if (!Utils.isNumeric(amount)) {
            return "formatError";
        } else {
            BigDecimal dAmount = Utils.changeBigDecimal(amount);
            if (dAmount != null) {
                amount = dAmount.setScale(3, BigDecimal.ROUND_HALF_UP).multiply(new BigDecimal(1000)).toString();
                amount = UploadUtil.changeAmountStrSub(amount);
                if (StringUtils.length(amount) > 13) {
                    return "ketaOverError";
		}
            }
        }
        
        return amount;
    }

}
