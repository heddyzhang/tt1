/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package jp.co.toshiba.hby.pspromis.syuueki.bean;

import java.util.List;
import java.util.Map;
import javax.enterprise.context.RequestScoped;
import javax.inject.Named;
import jp.co.toshiba.hby.pspromis.syuueki.entity.JgrpTbl;
import jp.co.toshiba.hby.pspromis.syuueki.entity.MSectionView;

/**
 *
 * @author kitajima
 */
@Named(value = "k004Bean")
@RequestScoped
public class K004Bean {
    /**
     * 事業部・部リスト
     */
    List<Map<String, Object>> jigyobuList;

    /**
     * 担当部門(組織)リスト
     */
    List<MSectionView> kaList;
    
    /**
     * 検索条件・部課コード
     */
    private String deptCd;

    /**
     * 検索条件・事業部(元画面から取得)
     */
    private String[] divisionCode;

    public List<Map<String, Object>> getJigyobuList() {
        return jigyobuList;
    }

    public void setJigyobuList(List<Map<String, Object>> jigyobuList) {
        this.jigyobuList = jigyobuList;
    }

    public List<MSectionView> getKaList() {
        return kaList;
    }

    public void setKaList(List<MSectionView> kaList) {
        this.kaList = kaList;
    }

    
    /**
     * 親事業部 or 部のid文字列を取得
     * @param map
     * @return 
     */
    public Object perentTreeIdStr(Map<String, Object> map) {
        Object perentId = map.get("parentId");
        if (perentId != null) {
            perentId = "data-tt-parent-id='" + perentId + "'";
        }
        return perentId;
    }

    public String getDeptCd() {
        return deptCd;
    }

    public void setDeptCd(String deptCd) {
        this.deptCd = deptCd;
    }

    public String[] getDivisionCode() {
        return divisionCode;
    }

    public void setDivisionCode(String[] divisionCode) {
        this.divisionCode = divisionCode;
    }

}
