/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package jp.co.toshiba.hby.pspromis.syuueki.facade;

import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import jp.co.toshiba.hby.pspromis.syuueki.entity.SyuBatchLog;

/**
 *
 * @author ibayashi
 */
@Stateless
public class SyuBatchLogFacade extends AbstractFacade<SyuBatchLog> {
    @PersistenceContext(unitName = jp.co.toshiba.hby.pspromis.syuueki.util.ConstantString.syuuekiDataSourceName)
    private EntityManager em;

    @Override
    protected EntityManager getEntityManager() {
        return em;
    }

    public SyuBatchLogFacade() {
        super(SyuBatchLog.class);
    }

    /**
     * 条件に合致する最新日付を取得
     * @param condition 検索条件
     * @return 最新日付
     */
    public SyuBatchLog getMaxEndDate(Object condition) {
        SyuBatchLog entity = sqlExecutor.getSingleResult(em, SyuBatchLog.class, "/sql/batchLog/selectMaxLog.sql", condition);
        return entity;
    }
}
