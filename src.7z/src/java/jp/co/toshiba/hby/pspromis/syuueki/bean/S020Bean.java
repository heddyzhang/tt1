package jp.co.toshiba.hby.pspromis.syuueki.bean;

import java.util.List;
import javax.enterprise.context.RequestScoped;
import javax.inject.Named;
import jp.co.toshiba.hby.pspromis.syuueki.entity.SyuKiNetCateTitleTbl;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

/**
 *
 * @author 
 */
@Named(value = "s020Bean")
@RequestScoped
@Getter @Setter
@ToString
public class S020Bean extends AbstractBean {

    /**
     * 処理元の画面ID(操作ログの登録で利用)
     */
    private String procId;

    /**
     * 事業部コード
     */
    private String divisionCode;

    /**
     * 注番
     */
    private String orderNo;
    
    /**
     * 製番記号
     */
    private String seiban;
     
    /**
     * 項番
     */
    private String orderItem;

    /**
     * 品名
     */
    private String hinmei;

    /**
     * 共通カテゴリ一覧
     */
    private List<SyuKiNetCateTitleTbl> dispSelectItemList;

    /**
     * 選択したカテゴリのコード
     */
    private String category;
    
}
