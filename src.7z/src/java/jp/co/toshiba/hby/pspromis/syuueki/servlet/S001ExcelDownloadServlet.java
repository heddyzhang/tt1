package jp.co.toshiba.hby.pspromis.syuueki.servlet;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.Date;
import javax.inject.Inject;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpServletRequest;
import jp.co.toshiba.hby.pspromis.syuueki.bean.S001Bean;
import jp.co.toshiba.hby.pspromis.syuueki.bean.S014Bean;
import jp.co.toshiba.hby.pspromis.syuueki.facade.SysdateEntityFacade;
import jp.co.toshiba.hby.pspromis.syuueki.service.download.DownloadBaseService;
import jp.co.toshiba.hby.pspromis.syuueki.service.download.DownloadIfc;
import jp.co.toshiba.hby.pspromis.syuueki.util.FileUtils;
import jp.co.toshiba.hby.pspromis.syuueki.util.ParameterBinder;
import jp.co.toshiba.hby.pspromis.syuueki.util.PoiUtil;
import org.apache.commons.lang3.StringUtils;
import org.apache.poi.ss.usermodel.Workbook;

/**
 * PS-Promis収益管理システム
 * 受注売上見込一覧Excelダウンロード Servlet
 * @author (NPC)S.Ibayashi
 */
@WebServlet(name="S001ExcelDownload", urlPatterns={"/servlet/S001ExcelDownload", "/servlet/S001ExcelDownload/*"})
public class S001ExcelDownloadServlet extends AbstractServlet {

    /**
     * 使用serviceクラスをinjection(CDI)<br>
     * InjectアノテーションよりAPサーバー(Glassfish)側で自動的にインスタンス作成(new)される。<br>
     * service側はステートレスセッションbeanにするため、Statelessアノテーションをつけておくこと。<br>
     */
    @Inject
    private DownloadBaseService downloadBaseService;

//    @Inject
//    private AnkenListService ankenListService;
//
//    @Inject
//    private JyuchuZanListService jyuchuZanListService;

    @Inject
    private SysdateEntityFacade sysdateFacade;

    /**
     * パラメータ格納クラスをinjection(CDI)<br>
     * InjectアノテーションよりAPサーバー(Glassfish)側で自動的にインスタンス作成(new)される。<br>
     */
    @Inject
    private S001Bean s001Bean;

    @Inject
    private S014Bean s014Bean;

    public String downloadAction(HttpServletRequest req, HttpServletResponse resp)
    throws Exception {
        logger.info("S001ExcelDownloadServlet#downloadAction");

        ParameterBinder.Bind(s001Bean, req);
        ParameterBinder.Bind(s014Bean, req);

        Date now = sysdateFacade.getSysdate();
        SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMddHHmm");

        // テンプレートファイルの読み込み
        String templateFileName = "";
        String downloadFileName = "";
        String outPutKbn = StringUtils.defaultString(s001Bean.getOutputKbn());
        switch (outPutKbn) {
            case "1":
                templateFileName = "ankenList_template.xlsx";
                downloadFileName = "案件一覧(月別)";
                break;
            case "2":
                templateFileName = "summaryList_template.xlsx";
                downloadFileName = "サマリ表(月別)";
                break;
            case "3":
                templateFileName = "jyuchuZanList_template.xlsx";
                downloadFileName = "受注残一覧";
                break;
        }

        // 案件一覧(月別)でも、回収展開の場合はテンプレート変える(見た目フォーマットは同じようになっている　各月のSP,NET,粗利,M率が 前受,売掛,合計 になっている)
        if (outPutKbn.equals("1") && "K".equals(s001Bean.getTenkaiKbn())) {
            templateFileName = "ankenList_kaisyu_template.xlsx";
        } else if (outPutKbn.equals("1") && "G".equals(s001Bean.getTenkaiKbn())) {
            templateFileName = "ankenList_kaisyu_gaika_template.xlsx";
        }

        String filePath = req.getServletContext().getRealPath("WEB-INF/template/" + templateFileName);
        logger.info("DownloadFilePath=" + filePath);
        Workbook workbook = PoiUtil.getWorkbook(new File(filePath));

        DownloadIfc service = downloadBaseService.serviceFactory(outPutKbn, s001Bean.getTenkaiKbn());
        service.downloadExecute(workbook);

        // ファイル名「基本ファイル名_[YYYYMMDDHH24MI].xlsx」
        FileUtils.httpDownloadExcelResponse(workbook, downloadFileName + "_" + sdf.format(now) + ".xlsx", resp);

        return null;
    }

}
