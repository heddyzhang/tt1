package jp.co.toshiba.hby.pspromis.syuueki.service;

import java.math.BigDecimal;
import java.sql.CallableStatement;
import java.sql.SQLException;
import java.sql.Types;
import java.util.Date;
import javax.ejb.Stateless;
import javax.inject.Inject;
import javax.interceptor.Interceptors;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import jp.co.toshiba.hby.pspromis.syuueki.bean.ResultMessageBean;
import jp.co.toshiba.hby.pspromis.syuueki.dto.AnkenRecalDto;
import jp.co.toshiba.hby.pspromis.syuueki.dto.IppanBalanceMakerDto;
import jp.co.toshiba.hby.pspromis.syuueki.dto.IspHikiateDto;
import jp.co.toshiba.hby.pspromis.syuueki.dto.PattenCalcDto;
import jp.co.toshiba.hby.pspromis.syuueki.dto.PoRirekiMakeDto;
import jp.co.toshiba.hby.pspromis.syuueki.dto.PoRirekiMakeIDto;
import jp.co.toshiba.hby.pspromis.syuueki.dto.SpInfoInsertDto;
import jp.co.toshiba.hby.pspromis.syuueki.dto.P0DaihyoAnkenSetDto;
import jp.co.toshiba.hby.pspromis.syuueki.dto.NuclearRenkeiBatchDto;
import jp.co.toshiba.hby.pspromis.syuueki.dto.NuclearRenkeiDispBatchDto;
import jp.co.toshiba.hby.pspromis.syuueki.dto.NuclearRenkeiSyuekiFlgBatchDto;
import jp.co.toshiba.hby.pspromis.syuueki.dto.SyuP7ChangeYmItemNetInfoDto;
import jp.co.toshiba.hby.pspromis.syuueki.facade.SysdateEntityFacade;
import jp.co.toshiba.hby.pspromis.syuueki.facade.SyuGeBukenInfoTblFacade;
import jp.co.toshiba.hby.pspromis.syuueki.interceptor.TranceInterceptor;
import jp.co.toshiba.hby.pspromis.syuueki.util.ConstantString;
import jp.co.toshiba.hby.pspromis.syuueki.util.LoginUserInfo;
import jp.co.toshiba.hby.pspromis.syuueki.util.Utils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * PS-Promis収益管理システム
 * RDBMS ストアドプロシージャCall用Service
 * @author (NPS)S.Ibayashi
 */
@Stateless
@Interceptors({TranceInterceptor.class})
public class StoredProceduresService {

    @PersistenceContext(unitName = jp.co.toshiba.hby.pspromis.syuueki.util.ConstantString.syuuekiDataSourceName)
    private EntityManager em;

    public static final Logger logger = LoggerFactory.getLogger(StoredProceduresService.class);

    @Inject
    private SysdateEntityFacade sysdateEntityFacade;

    @Inject
    private SyuGeBukenInfoTblFacade syuGeBukenInfoTblFacade;

    @Inject
    private ResultMessageBean resultMessageBean;
    
    @Inject
    private LoginUserInfo loninUserInfo;
    
    /**
     * 再計算処理 Call
     * @param dto
     * @throws java.sql.SQLException
     */
    public void callAnkenRecal(AnkenRecalDto dto) throws SQLException {
        String procedureName = "SYU_ANKEN_RECAL_MAIN.ANKEN_MAIN";
        dto.setExeProcedureName(procedureName);
        
        // プロシージャ実行前にDBの更新状態を反映しておく。
        em.flush();
        
        CallableStatement cstmt = null;
        try {
            logger.info("call recal package[{}] ankenId=[{}] rirekiId=[{}], procFlg=[{}]", procedureName, dto.getAnkenId(), dto.getRirekiId(), dto.getProcFlg());

            java.sql.Connection conn = em.unwrap(java.sql.Connection.class);

            Date now = sysdateEntityFacade.getSysdate();
            java.sql.Timestamp timestamp = Utils.changeSqlDate(now);

            cstmt = conn.prepareCall("{call " + procedureName + "(?,?,?,?,?,?) }");
            cstmt.setString(1, dto.getAnkenId());
            cstmt.setInt(2, dto.getRirekiId());
            cstmt.setString(3, dto.getProcFlg());
            cstmt.setTimestamp(4, timestamp);
            cstmt.setString(5, loninUserInfo.getUserId());
            cstmt.registerOutParameter(6, Types.VARCHAR);

            cstmt.execute();

            String status = cstmt.getString(6);
            logger.info("result recal package[{}] resultStatus=[{}]", status);

            dto.setStatus(status);

        } finally {
            try {
                if (cstmt != null) {
                    cstmt.close();
                }
            } catch (SQLException sqle){}
        }
    }

    /**
     * 一般案件・再計算処理 Call
     * @param dto
     * @throws java.sql.SQLException
     */
    public void callAnken_I_Recal(AnkenRecalDto dto) throws SQLException {
        String procedureName = "SYU_ANKEN_RECAL_I_MAIN.ANKEN_MAIN";
        dto.setExeProcedureName(procedureName);
        
        // プロシージャ実行前にDBの更新状態を反映しておく。
        em.flush();
        
        CallableStatement cstmt = null;
        try {
            logger.info("call recal package[{}] ankenId=[{}] rirekiId=[{}], procFlg=[{}]", procedureName, dto.getAnkenId(), dto.getRirekiId(), dto.getProcFlg());
            
            java.sql.Connection conn = em.unwrap(java.sql.Connection.class);

            Date now = sysdateEntityFacade.getSysdate();
            java.sql.Timestamp timestamp = Utils.changeSqlDate(now);
            
            cstmt = conn.prepareCall("{call " + procedureName + "(?,?,?,?,?,?) }");
            cstmt.setString(1, dto.getAnkenId());
            cstmt.setInt(2, dto.getRirekiId());
            cstmt.setString(3, dto.getProcFlg());
            cstmt.setTimestamp(4, timestamp);
            cstmt.setString(5, loninUserInfo.getUserId());
            cstmt.registerOutParameter(6, Types.VARCHAR);

            cstmt.execute();

            String status = cstmt.getString(6);
            logger.info("result recal package[{}] resultStatus=[{}]", status);

            dto.setStatus(status);

        } finally {
            try {
                if (cstmt != null) {
                    cstmt.close();
                }
            } catch (SQLException sqle){}
        }
    }

    /**
     * [進行基準]月次確定(or確定解除)処理 Call
     * @param dto
     * @throws java.sql.SQLException
     */
    public void callPoRirekiMake(PoRirekiMakeDto dto) throws SQLException {
        // プロシージャ実行前にDBの更新状態を反映しておく。
        em.flush();
        
        CallableStatement cstmt = null;
        try {
            java.sql.Connection conn = em.unwrap(java.sql.Connection.class);

            //Date now = sysdateEntityFacade.getSysdate();
            //java.sql.Timestamp timestamp = Utils.changeSqlDate(now);
            
            cstmt = conn.prepareCall("{call SYU_P0_RIREKI_MAKE.MAIN(?,?,?,?,?,?,?)}");
            cstmt.setString(1, dto.getDivisionCode());
            cstmt.setString(2, dto.getGroupCode());
            cstmt.setString(3, dto.getSalesClass());
            cstmt.setString(4, dto.getKanjyoYm());
            cstmt.setString(5, dto.getRirekiId());
            cstmt.setString(6, dto.getSyoriFlg());
            cstmt.registerOutParameter(7, Types.VARCHAR);

            cstmt.execute();

            String status = cstmt.getString(7);

            dto.setErrFlg(status);

        } finally {
            try {
                if (cstmt != null) {
                    cstmt.close();
                }
            } catch (SQLException sqle){}
        }
    }

    /**
     * [一般データ]月次確定(or確定解除)処理 Call
     * @param dto
     * @throws java.sql.SQLException
     */
    public void callPoRireki_I_Make(PoRirekiMakeIDto dto) throws SQLException {
        // プロシージャ実行前にDBの更新状態を反映しておく。
        em.flush();
        
        CallableStatement cstmt = null;
        try {
            java.sql.Connection conn = em.unwrap(java.sql.Connection.class);

            cstmt = conn.prepareCall("{call SYU_P0_RIREKI_I_MAKE.MAIN(?,?,?,?,?,?,?,?,?)}");
            cstmt.setString(1, dto.getDivisionCode());
            cstmt.setString(2, dto.getGroupCode());
            cstmt.setString(3, dto.getcBukaCd());
            cstmt.setString(4, dto.getTeamCode());
            cstmt.setString(5, dto.getHonsyaShisyaKbn());
            cstmt.setString(6, dto.getKanjyoYm());
            cstmt.setString(7, dto.getSyoriFlg());
            cstmt.setString(8, dto.getRirekiId());
            cstmt.registerOutParameter(9, Types.VARCHAR);

            cstmt.execute();

            String status = cstmt.getString(9);

            dto.setErrFlg(status);

        } finally {
            try {
                if (cstmt != null) {
                    cstmt.close();
                }
            } catch (SQLException sqle){}
        }
    }
    
    
     /**
     * SP情報登録処理 Call
     * @param dto
     */
    public void callSpInfoInsert(SpInfoInsertDto dto) throws SQLException {
        // プロシージャ実行前にDBの更新状態を反映しておく。
        em.flush();
        
        CallableStatement cstmt = null;
        try {
            java.sql.Connection conn = em.unwrap(java.sql.Connection.class);

            cstmt = conn.prepareCall("{call PACK_KI_SP_INS.MAIN(?,?,?,?,?) }");
            cstmt.setString(1, dto.getAnkenId());
            cstmt.setString(2, dto.getKbn());
            cstmt.setString(3, dto.getUserId());            
            cstmt.registerOutParameter(4, Types.INTEGER);
            cstmt.registerOutParameter(5, Types.VARCHAR);

            cstmt.execute();

            int status   = cstmt.getInt(4);
            String mess  = cstmt.getString(5);

            dto.setStatus(status);
            dto.setStatusMessage(mess);

        } finally {
            try {
                if (cstmt != null) {
                    cstmt.close();
                }
            } catch (SQLException e){}
        }
    }
    
    /**
     * 注入パターン計算処理 Call
     * @param dto
     */
    public void callPattenCalc(PattenCalcDto dto) throws SQLException {
        // プロシージャ実行前にDBの更新状態を反映しておく。
        em.flush();
        
        CallableStatement cstmt = null;
        try {
            java.sql.Connection conn = em.unwrap(java.sql.Connection.class);

            cstmt = conn.prepareCall("{call PACK_PATTEN_CALC.MAIN(?,?,?,?,?) }");
            cstmt.setString(1, dto.getAnkenId());
            cstmt.setString(2, dto.getKbn());
            cstmt.setString(3, dto.getUserId());            
            cstmt.registerOutParameter(4, Types.INTEGER);
            cstmt.registerOutParameter(5, Types.VARCHAR);

            cstmt.execute();

            int status   = cstmt.getInt(4);
            String mess  = cstmt.getString(5);

            dto.setStatus(status);
            dto.setStatusMessage(mess);

        } finally {
            try {
                if (cstmt != null) {
                    cstmt.close();
                }
            } catch (SQLException e){}
        }
    }    
    
    /**
     * 指定見込年月・通貨・事業部のレート取得 Call
     * @param dto
     */
    public BigDecimal getMikomiCurrencyRate(String syuekiYm, String currencyCode, String divitionCode) throws SQLException {
        // プロシージャ実行前にDBの更新状態を反映しておく。
        em.flush();
        
        CallableStatement cstmt = null;
        try {
            java.sql.Connection conn = em.unwrap(java.sql.Connection.class);

            cstmt = conn.prepareCall("{? = call GET_MIKOMI_RATE(?,?,?)}");
            cstmt.registerOutParameter(1, Types.NUMERIC);
            cstmt.setString(2, syuekiYm);
            cstmt.setString(3, currencyCode);
            cstmt.setString(4, divitionCode);

            cstmt.execute();

            BigDecimal rate = cstmt.getBigDecimal(1);

            return rate;

        } finally {
            try {
                if (cstmt != null) {
                    cstmt.close();
                }
            } catch (SQLException e){}
        }
    }
    
    /**
     * 検索用文字列に変換
     * @param searchStr
     * @param dto
     * @return 
     * @throws java.sql.SQLException 
     */
    public String getSearchStr(String searchStr) throws SQLException {
        // プロシージャ実行前にDBの更新状態を反映しておく。
        em.flush();
        
        CallableStatement cstmt = null;
        try {
            java.sql.Connection conn = em.unwrap(java.sql.Connection.class);

            cstmt = conn.prepareCall("{? = call GET_CHANGE_SEARCH_STR(?)}");
            cstmt.registerOutParameter(1, Types.VARCHAR);
            cstmt.setString(2, searchStr);

            cstmt.execute();

            String str = cstmt.getString(1);

            return str;

        } finally {
            try {
                if (cstmt != null) {
                    cstmt.close();
                }
            } catch (SQLException e){}
        }
    }
    
    /**
     * 一般案件・案分パッケージ Call
     * @param dto
     * @throws java.sql.SQLException
     */
    public void callIppanBalanceMaker(IppanBalanceMakerDto dto) throws SQLException {
        // プロシージャ実行前にDBの更新状態を反映しておく。
        em.flush();
        
        CallableStatement cstmt = null;
        try {
            java.sql.Connection conn = em.unwrap(java.sql.Connection.class);
            
            logger.info("call SYU_P0_IPPAN_BALANCE_MAKE.ANKEN_MAIN ankenId=[{}] rirekiId=[{}], syoriFig=[{}]", dto.getAnkenId(), dto.getRirekiId(), dto.getSyoriFlg());
            cstmt = conn.prepareCall("{call SYU_P0_IPPAN_BALANCE_MAKE.ANKEN_MAIN(?,?,?,?)}");
            cstmt.setString(1, dto.getAnkenId());
            cstmt.setInt(2, Integer.parseInt(dto.getRirekiId()));
            cstmt.setString(3, dto.getSyoriFlg());
            cstmt.registerOutParameter(4, Types.VARCHAR);

            cstmt.execute();

            String status = cstmt.getString(4);
            logger.info("result SYU_P0_IPPAN_BALANCE_MAKE.ANKEN_MAIN resultStatus=[{}]", status);

            dto.setStatus(status);

        } finally {
            try {
                if (cstmt != null) {
                    cstmt.close();
                }
            } catch (SQLException sqle){}
        }
    }

    /**
     * 再計算処理(この中で一般/進行基準を判断して適切なパッケージを実行する)
     * @param dto
     * @throws java.sql.SQLException
     */
    private void callAnkenRecalAuto(AnkenRecalDto dto) throws SQLException {
        em.flush();
        
        // 対象案件の売上基準を取得
        String salesClass = syuGeBukenInfoTblFacade.getSalesClass(dto.getAnkenId(), String.valueOf(dto.getRirekiId()));
        
        if (ConstantString.salesClassS.equals(salesClass)) {
            // 進行基準案件
            callAnkenRecal(dto);
        } else {
            // 一般案件
            callAnken_I_Recal(dto);
        }
    }

    /**
     * 再計算処理(この中で一般/進行基準を判断して適切なパッケージを実行する)
     * @param ankenId 物件Key
     * @param rirekiId 履歴ID
     * @param procFlg 処理FLG
     * @throws java.sql.SQLException
     */
    public void callAnkenRecalAuto(String ankenId, String rirekiId, String procFlg) throws Exception {
        AnkenRecalDto dto = new AnkenRecalDto();
        dto.setAnkenId(ankenId);
        dto.setRirekiId(Integer.parseInt(rirekiId));
        dto.setProcFlg(procFlg);
        
        callAnkenRecalAuto(dto);
        
        if (!"0".equals(dto.getStatus())) {
            if ("8".equals(dto.getStatus())) {
                resultMessageBean.setN7RenkeiStsFlg("9");
            } else {
                throw new Exception("再計算処理[" + dto.getExeProcedureName() + "]でエラーが発生しました。ankenId=" + ankenId + " rirekiId=" + rirekiId + " procFlg=" + procFlg);
            }
        }
    }

    /**
     * (原子力)収益管理システムへのデータ送信処理を実行
     * @param dto パッケージ実行用パラメータ
     * @throws SQLException
     */
    public void callNuclearSysRenkeiBatch(NuclearRenkeiBatchDto dto) throws SQLException {
        String procedureName = "SYU_N7_RENKEI_BATCH.PROC_MAIN";
        dto.setExeProcedureName(procedureName);
        
        // プロシージャ実行前にDBの更新状態を反映しておく。
        em.flush();
        
        CallableStatement cstmt = null;
        try {
            logger.info("call NuclearSysRenkeiBatch ankenId=[{}] rirekiId=[{}] callId=[{}], renkeiType=[{}]", dto.getAnkenId(), dto.getRirekiId(), loninUserInfo.getUserId(), dto.getRenkeiType());
            java.sql.Connection conn = em.unwrap(java.sql.Connection.class);

            cstmt = conn.prepareCall("{call " + procedureName + "(?,?,?,?,?,?)}");
            cstmt.setString(1, dto.getAnkenId());
            cstmt.setInt(2, Integer.parseInt(dto.getRirekiId()));
            cstmt.setString(3, loninUserInfo.getUserId());
            cstmt.setString(4, dto.getRenkeiType());
            cstmt.registerOutParameter(5, Types.INTEGER);
            cstmt.registerOutParameter(6, Types.VARCHAR);

            cstmt.execute();

            int status = cstmt.getInt(5);
            String resultMessage = cstmt.getString(6);
            logger.info("result NuclearSysRenkei resultStatus=[{}] resultMessage=[{}]", status, resultMessage);

            resultMessageBean.setN7RenkeiStsFlg(String.valueOf(status));

            dto.setStatus(status);
            dto.setErrMsg(resultMessage);

        } finally {
            try {
                if (cstmt != null) {
                    cstmt.close();
                }
            } catch (SQLException sqle){}
        }
    }

    /**
     * (原子力)データ送信処理を実行(プロパティの設定でパッケージをコールするべきかを判断する。)
     * ※未完成のため保留
     * @param ankenId 物件Key
     * @param rirekiId 履歴ID;
     */
    public void callN7RenkeiBatchJudge(String ankenId, String rirekiId) throws SQLException {
//        String n7RenkeiBatchFlg = Env.CallN7RenkeiBatchFlg.getValue();
//        logger.info("n7RenkeiBatchFlg=[{}]", n7RenkeiBatchFlg);
//        if (n7RenkeiBatchFlg.equals("1")) {
//            callN7RenkeiBatch(ankenId, rirekiId);
//        }
    }

    /**
     * 最新値更新：発番更新 パッケージの実行
     */
    public String callOnlineHbMake(String ankenId, String rirekiId) throws SQLException {
        String procedureName = "SYU_P0_ONLINE_HB_MAKE.main";
        
        // プロシージャ実行前にDBの更新状態を反映しておく。
        em.flush();
        
        CallableStatement cstmt = null;
        try {
            logger.info("call " + procedureName + " ankenId=[{}] rirekiId=[{}]", ankenId, rirekiId);
            java.sql.Connection conn = em.unwrap(java.sql.Connection.class);

            cstmt = conn.prepareCall("{call " + procedureName + "(?,?,?)}");
            cstmt.setString(1, ankenId);
            cstmt.setInt(2, Integer.parseInt(rirekiId));
            cstmt.registerOutParameter(3, Types.VARCHAR);

            cstmt.execute();

            String status = StringUtils.defaultString(cstmt.getString(3));
            logger.info("result " + procedureName + " resultStatus=[{}]", status);

            return status;

        } finally {
            try {
                if (cstmt != null) {
                    cstmt.close();
                }
            } catch (SQLException sqle){}
        }
    }
    
    /**
     * 最新値更新：契約更新 パッケージの実行
     */
    public String callOnlineKeiyakuMake(String ankenId, String rirekiId) throws SQLException {
        String procedureName = "SYU_P0_ONLINE_KEIYAKU_MAKE.main";
        
        // プロシージャ実行前にDBの更新状態を反映しておく。
        em.flush();
        
        CallableStatement cstmt = null;
        try {
            logger.info("call " + procedureName + " ankenId=[{}] rirekiId=[{}]", ankenId, rirekiId);
            java.sql.Connection conn = em.unwrap(java.sql.Connection.class);

            cstmt = conn.prepareCall("{call " + procedureName + "(?,?,?)}");
            cstmt.setString(1, ankenId);
            cstmt.setInt(2, Integer.parseInt(rirekiId));
            cstmt.registerOutParameter(3, Types.VARCHAR);

            cstmt.execute();

            String status = StringUtils.defaultString(cstmt.getString(3));
            logger.info("result " + procedureName + " resultStatus=[{}]", status);

            return status;

        } finally {
            try {
                if (cstmt != null) {
                    cstmt.close();
                }
            } catch (SQLException sqle){}
        }
    }
    
    /**
     * 最新値更新：見積更新 パッケージの実行
     */
    public String callOnlineEstMake(String ankenId, String rirekiId) throws SQLException {
        String procedureName = "SYU_P0_ONLINE_EST_MAKE.main";
        
        String dispKbn = "G"; //画面からの呼び出し判別用
        
        // プロシージャ実行前にDBの更新状態を反映しておく。
        em.flush();
        
        CallableStatement cstmt = null;
        try {
            logger.info("call " + procedureName + " ankenId=[{}] rirekiId=[{}] ", ankenId, rirekiId);
            java.sql.Connection conn = em.unwrap(java.sql.Connection.class);

            cstmt = conn.prepareCall("{call " + procedureName + "(?,?,?,?,?)}");
            cstmt.setString(1, ankenId);
            cstmt.setInt(2, Integer.parseInt(rirekiId));
            cstmt.setString(3, dispKbn);
            
            cstmt.registerOutParameter(4, Types.VARCHAR);
            cstmt.registerOutParameter(5, Types.VARCHAR);

            cstmt.execute();

            String status = StringUtils.defaultString(cstmt.getString(4));
            logger.info("result " + procedureName + " resultStatus=[{}]", status);

            return status;

        } finally {
            try {
                if (cstmt != null) {
                    cstmt.close();
                }
            } catch (SQLException sqle){}
        }
    }
    
    /**
     * 最新値更新パッケージの実行
     * @param ankenId 案件id
     * @param rirekiId 履歴id
     * @param updateKbn 更新区分(1:発番更新 2:受注通知更新 3:見積更新)
     */
    public String callUpdateNewData(String ankenId, String rirekiId, String updateKbn) throws Exception {
        String status = "0";
        
        if ("1".equals(updateKbn)) {
            // 発番更新
            status = callOnlineHbMake(ankenId, rirekiId);
        } else if ("2".equals(updateKbn)) {
            // 契約更新
            status = callOnlineKeiyakuMake(ankenId, rirekiId);
        } else {
            // 見積更新
            status = callOnlineEstMake(ankenId, rirekiId);
        }

        if ("9".equals(status)) {
            throw new Exception("最新値更新処理でエラーが発生しました。ankenId=" + ankenId + " rirekiId=" + rirekiId + " updateKbn=" + updateKbn);
        }
        
        return status;
    }

    /**
     * 収益対象FLG付け替え時の案件データ入れ替えパッケージを実行
     * @param dto パッケージの引数
     */
    public void callP0DaihyoAnkenSet(P0DaihyoAnkenSetDto dto) throws Exception {
        String procedureName = "SYU_P0_DAIHYO_ANKEN_SET.MAIN";
        dto.setExeProcedureName(procedureName);
        
        // プロシージャ実行前にDBの更新状態を反映しておく。
        em.flush();
        
        CallableStatement cstmt = null;
        try {
            logger.info("call package[{}] daihyoAnkenId=[{}] invaildAnkenId=[{}], ankenOrderNo=[{}]", procedureName, dto.getDaihyoAnkenId(), dto.getInvaildAnkenId(), dto.getAnkenOrderNo());

            java.sql.Connection conn = em.unwrap(java.sql.Connection.class);

            cstmt = conn.prepareCall("{call " + procedureName + "(?,?,?,?,?)}");
            cstmt.setString(1, dto.getDaihyoAnkenId());
            cstmt.setString(2, dto.getInvaildAnkenId());
            cstmt.setString(3, dto.getAnkenOrderNo());
            cstmt.registerOutParameter(4, Types.VARCHAR);
            cstmt.registerOutParameter(5, Types.VARCHAR);

            cstmt.execute();

            String errFlg = cstmt.getString(4);
            String errMsg = cstmt.getString(5);
            logger.info("result package[{}] errFlg=[{}] errMsg=[{}]", procedureName, errFlg, errMsg);

            dto.setErrFlg(errFlg);
            dto.setErrMsg(errMsg);

        } finally {
            try {
                if (cstmt != null) {
                    cstmt.close();
                }
            } catch (SQLException sqle){}
        }
    }

    /**
     * 関連ISP区分解除パッケージを実行
     * @param ankenId 案件ID
     * @param rirekiId 履歴ID
     */
    public void callOffIspFlg(String ankenId, String rirekiId) throws Exception {
        String procedureName = "SYU_P0_COMMON.SYU_OFF_ISP_FLG";
        
        // プロシージャ実行前にDBの更新状態を反映しておく。
        em.flush();
        
        CallableStatement cstmt = null;
        try {
            logger.info("call package[{}] ankenId=[{}] rirekiId=[{}]", procedureName, ankenId, rirekiId);

            java.sql.Connection conn = em.unwrap(java.sql.Connection.class);

            cstmt = conn.prepareCall("{call " + procedureName + "(?,?,?)}");
            cstmt.setString(1, ankenId);
            cstmt.setInt(2, Integer.parseInt(rirekiId));
            cstmt.registerOutParameter(3, Types.VARCHAR);

            cstmt.execute();

            String errFlg = cstmt.getString(3);
            logger.info("result package[{}] errFlg=[{}]", procedureName, errFlg);

            if ("9".equals(errFlg)) {
                throw new Exception("関連ISP案件解除パッケージ[" + procedureName + "]でエラーが発生しました。ankenId=" + ankenId + " rirekiId=" + rirekiId + " rirekiId=" + rirekiId);
            }

        } finally {
            try {
                if (cstmt != null) {
                    cstmt.close();
                }
            } catch (SQLException sqle){}
        }
    }

    /**
     * 収益対象FLG付け替え時の原子力データ入れ替えプロシジャを実行
     * @param dto パッケージの引数
     */
    public void callNuclearRenkeiSyuekiFlg(NuclearRenkeiSyuekiFlgBatchDto dto) throws Exception {
        //String procedureName = "SYU_N7_RENKEI_BATCH.PROC_CHANGE_SYUEKI_FLG";
        String procedureName = "SYU_RECAL_SYUEKI_FLG_SET.PROC_CHANGE_SYUEKI_FLG";
        dto.setExeProcedureName(procedureName);
        
        // プロシージャ実行前にDBの更新状態を反映しておく。
        em.flush();
        
        CallableStatement cstmt = null;
        try {
            logger.info("call package[{}] daihyoAnkenId=[{}] invaildAnkenId=[{}], ankenOrderNo=[{}]", procedureName, dto.getDaihyoAnkenId(), dto.getInvaildAnkenId(), dto.getAnkenOrderNo());

            java.sql.Connection conn = em.unwrap(java.sql.Connection.class);

            cstmt = conn.prepareCall("{call " + procedureName + "(?,?,?,?,?,?,?)}");
            cstmt.setString(1, dto.getDaihyoAnkenId());
            cstmt.setString(2, dto.getInvaildAnkenId());
            cstmt.setString(3, dto.getAnkenOrderNo());
            cstmt.setString(4, loninUserInfo.getUserId());
            cstmt.registerOutParameter(5, Types.INTEGER);
            cstmt.registerOutParameter(6, Types.VARCHAR);
            cstmt.registerOutParameter(7, Types.VARCHAR);

            cstmt.execute();

            int status = cstmt.getInt(5);
            String resultMessage = StringUtils.defaultString(cstmt.getString(6));
            String errorAnkenId = StringUtils.defaultString(cstmt.getString(7));
            logger.info("result package[{}] status=[{}] errMsg=[{}] errorAnkenId=[{}]", procedureName, status, resultMessage, errorAnkenId);

            resultMessageBean.setN7RenkeiStsFlg(String.valueOf(status));
            
            dto.setStatus(status);
            dto.setErrMsg(resultMessage);
            dto.setErrorAnkenId(errorAnkenId);

        } finally {
            try {
                if (cstmt != null) {
                    cstmt.close();
                }
            } catch (SQLException sqle){}
        }
    }

    /**
     * 収益対象FLG付け替え時の原子力データ入れ替えプロシジャを実行(進行基準まとめ案件用)
     * @param dto パッケージの引数
     */
    public void callNuclearRenkeiSyuekiFlgM(NuclearRenkeiSyuekiFlgBatchDto dto) throws Exception {
        String procedureName = "SYU_RECAL_SYUEKI_FLG_SET.PROC_CHANGE_SYUEKI_FLG_M";
        dto.setExeProcedureName(procedureName);
        
        // プロシージャ実行前にDBの更新状態を反映しておく。
        em.flush();
        
        CallableStatement cstmt = null;
        try {
            logger.info("call package[{}] daihyoAnkenId=[{}] invaildAnkenId=[{}], ankenOrderNo=[{}]", procedureName, dto.getDaihyoAnkenId(), dto.getInvaildAnkenId(), dto.getAnkenOrderNo());

            java.sql.Connection conn = em.unwrap(java.sql.Connection.class);

            cstmt = conn.prepareCall("{call " + procedureName + "(?,?,?,?,?,?,?)}");
            cstmt.setString(1, dto.getDaihyoAnkenId());
            cstmt.setString(2, dto.getInvaildAnkenId());
            cstmt.setString(3, dto.getAnkenOrderNo());
            cstmt.setString(4, loninUserInfo.getUserId());
            cstmt.registerOutParameter(5, Types.INTEGER);
            cstmt.registerOutParameter(6, Types.VARCHAR);
            cstmt.registerOutParameter(7, Types.VARCHAR);

            cstmt.execute();

            int status = cstmt.getInt(5);
            String resultMessage = StringUtils.defaultString(cstmt.getString(6));
            String errorAnkenId = StringUtils.defaultString(cstmt.getString(7));
            logger.info("result package[{}] status=[{}] errMsg=[{}] errorAnkenId=[{}]", procedureName, status, resultMessage, errorAnkenId);

            resultMessageBean.setN7RenkeiStsFlg(String.valueOf(status));
            
            dto.setStatus(status);
            dto.setErrMsg(resultMessage);
            dto.setErrorAnkenId(errorAnkenId);

        } finally {
            try {
                if (cstmt != null) {
                    cstmt.close();
                }
            } catch (SQLException sqle){}
        }
    }
      
    /**
     * (原子力)収益管理システムへのデータ送信処理を実行(画面から直接起動)
     * @param dto パッケージ実行用パラメータ
     * @throws SQLException
     */
    public void callNuclearSysRenkeiDispBatch(NuclearRenkeiDispBatchDto dto) throws SQLException {
        String procedureName = "SYU_N7_RENKEI_BATCH.PROC_DISP_CALL_MAIN";
        dto.setExeProcedureName(procedureName);
        
        // プロシージャ実行前にDBの更新状態を反映しておく。
        em.flush();
        
        CallableStatement cstmt = null;
        try {
            logger.info("call NuclearSysRenkeiDispBatch ankenId=[{}] rirekiId=[{}] callId=[{}], dispKbn=[{}]", dto.getAnkenId(), dto.getRirekiId(), loninUserInfo.getUserId(), dto.getDispKbn());
            java.sql.Connection conn = em.unwrap(java.sql.Connection.class);

            cstmt = conn.prepareCall("{call " + procedureName + "(?,?,?,?,?,?)}");
            cstmt.setString(1, dto.getAnkenId());
            cstmt.setInt(2, Integer.parseInt(dto.getRirekiId()));
            cstmt.setString(3, loninUserInfo.getUserId());
            cstmt.setString(4, dto.getDispKbn());
            cstmt.registerOutParameter(5, Types.INTEGER);
            cstmt.registerOutParameter(6, Types.VARCHAR);

            cstmt.execute();

            int status = cstmt.getInt(5);
            String resultMessage = cstmt.getString(6);
            logger.info("result NuclearSysRenkeiDispBatch resultStatus=[{}] resultMessage=[{}]", status, resultMessage);

            resultMessageBean.setN7RenkeiStsFlg(String.valueOf(status));

            dto.setStatus(status);
            dto.setErrMsg(resultMessage);

        } finally {
            try {
                if (cstmt != null) {
                    cstmt.close();
                }
            } catch (SQLException sqle){}
        }
    }
    
    /**
     * 項番データの売上年月の月移動パッケージ
     *   ※移動先の年月はダミー年月('D'+YYYYMM)で発行する
     *     そのため、このパッケージを実行した処理の最後には必ず
     * @param dto パッケージ実行用パラメータ
     * @throws SQLException
     */
    public void callSyuP7ChangeYmItemNetInfo(SyuP7ChangeYmItemNetInfoDto dto) throws SQLException {
        String procedureName = "SYU_P7_CHANGE_YM_ITEM_NET_INFO.CHANGE_URI_SYUEKI_YM";
        dto.setExeProcedureName(procedureName);
    
        // プロシージャ実行前にDBの更新状態を反映しておく。
        em.flush();
 
        CallableStatement cstmt = null;
        try {
            logger.info("call SyuP7ChangeYmItemNetInfo ankenId=[{}] rirekiId=[{}] dataKbn=[{}], oSyuekiYm=[{}], nSyuekiYm=[{}], delFlg=[{}]", dto.getAnkenId(), dto.getRirekiId(), dto.getDataKbn(), dto.getOSyuekiYm(), dto.getNSyuekiYm(), dto.getDelFlg());
            java.sql.Connection conn = em.unwrap(java.sql.Connection.class);

            cstmt = conn.prepareCall("{call " + procedureName + "(?,?,?,?,?,?,?,?)}");
            cstmt.setString(1, dto.getAnkenId());
            cstmt.setInt(2, Integer.parseInt(dto.getRirekiId()));
            cstmt.setString(3, dto.getDataKbn());
            cstmt.setString(4, dto.getOSyuekiYm());
            cstmt.setString(5, dto.getNSyuekiYm());
            cstmt.setString(6, dto.getDelFlg());
            cstmt.registerOutParameter(7, Types.VARCHAR);
            cstmt.registerOutParameter(8, Types.VARCHAR);

            cstmt.execute();

            String status = StringUtils.defaultString(cstmt.getString(7));
            String resultMessage = StringUtils.defaultString(cstmt.getString(8));
            logger.info("result SyuP7ChangeYmItemNetInfo resultStatus=[{}] resultMessage=[{}]", status, resultMessage);

            dto.setErrFlg(status);
            dto.setErrMsg(resultMessage);
        
        } finally {
            try {
                if (cstmt != null) {
                    cstmt.close();
                }
            } catch (SQLException sqle){}
        }
    }
    
    public void callSyuP7ChangeYmItemNetInfoFix(SyuP7ChangeYmItemNetInfoDto dto) throws SQLException {
        String procedureName = "SYU_P7_CHANGE_YM_ITEM_NET_INFO.FIX_URI_SYUEKI_YM";
        dto.setExeProcedureName(procedureName);
    
        // プロシージャ実行前にDBの更新状態を反映しておく。
        em.flush();
 
        CallableStatement cstmt = null;
        try {
            logger.info("call SyuP7ChangeYmItemNetInfoFix ankenId=[{}] rirekiId=[{}] dataKbn=[{}]", dto.getAnkenId(), dto.getRirekiId(), dto.getDataKbn());
            java.sql.Connection conn = em.unwrap(java.sql.Connection.class);

            cstmt = conn.prepareCall("{call " + procedureName + "(?,?,?,?,?)}");
            cstmt.setString(1, dto.getAnkenId());
            cstmt.setInt(2, Integer.parseInt(dto.getRirekiId()));
            cstmt.setString(3, dto.getDataKbn());
            cstmt.registerOutParameter(4, Types.VARCHAR);
            cstmt.registerOutParameter(5, Types.VARCHAR);

            cstmt.execute();

            String status = StringUtils.defaultString(cstmt.getString(4));
            String resultMessage = StringUtils.defaultString(cstmt.getString(5));
            logger.info("result SyuP7ChangeYmItemNetInfoFix resultStatus=[{}] resultMessage=[{}]", status, resultMessage);

            dto.setErrFlg(status);
            dto.setErrMsg(resultMessage);
        
        } finally {
            try {
                if (cstmt != null) {
                    cstmt.close();
                }
            } catch (SQLException sqle){}
        }
    }
    
    /**
     *  ISP案件実績紐付け　引当　Call
     * @param dto
     * @throws java.sql.SQLException
     */
    public void callIspHikiate(IspHikiateDto dto) throws SQLException {
        
        // プロシージャ実行前にDBの更新状態を反映しておく。
        em.flush();
        
        CallableStatement cstmt = null;
        try {
            java.sql.Connection conn = em.unwrap(java.sql.Connection.class);
            
            cstmt = conn.prepareCall("{call SYU_P0_ISP_HIKIATE.ANKEN_MAIN(?,?,?,?,?,?,?,?,?)}");
            cstmt.setString(1, dto.getTaisyoAnkenId());
            cstmt.setString(2, dto.getHikiateAnkenId());
            cstmt.setInt(3, dto.getRirekiId());
            cstmt.setString(4, dto.getTaisyoYm());
            cstmt.setString(5, dto.getShiteiKbn());
            cstmt.setBigDecimal(6, dto.getHikiateIsp());
            cstmt.setBigDecimal(7, dto.getHikiateNet());
            cstmt.registerOutParameter(8, Types.VARCHAR);
            cstmt.registerOutParameter(9, Types.VARCHAR);

            cstmt.execute();

            String resuleFlg = StringUtils.defaultString(cstmt.getString(8));
            String resultMessage = StringUtils.defaultString(cstmt.getString(9));
            logger.info("result SyuP7ChangeYmItemNetInfoFix resultStatus=[{}] resultMessage=[{}]", resuleFlg, resultMessage);

            dto.setErrFlg(resuleFlg);
            dto.setErrMsg(resultMessage);

        } finally {
            try {
                if (cstmt != null) {
                    cstmt.close();
                }
            } catch (SQLException sqle){}
        }
    }
}
