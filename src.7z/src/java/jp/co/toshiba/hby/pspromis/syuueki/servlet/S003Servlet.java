package jp.co.toshiba.hby.pspromis.syuueki.servlet;

import java.util.HashMap;
import java.util.Map;
import javax.inject.Inject;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpServletRequest;
import jp.co.toshiba.hby.pspromis.syuueki.bean.ResultMessageBean;
import jp.co.toshiba.hby.pspromis.syuueki.bean.S003Bean;
import jp.co.toshiba.hby.pspromis.syuueki.service.S003Service;
import jp.co.toshiba.hby.pspromis.syuueki.service.StoredProceduresService;
import jp.co.toshiba.hby.pspromis.syuueki.util.CdiUtils;
import jp.co.toshiba.hby.pspromis.syuueki.util.ParameterBinder;

/**
 * PS-Promis収益管理システム
 * 期間損益(一般) Servlet
 * @author (NPC)K.Sano
 */
@WebServlet(name="S003", urlPatterns={"/servlet/S003", "/servlet/S003/*"})
public class S003Servlet extends AbstractServlet {

    /**
     * jsp
     */
    private static final String INDEX_JSP = "S003/s003.jsp";

    /**
     * 使用serviceクラスをinjection(CDI)<br>
     * InjectアノテーションよりAPサーバー(Glassfish)側で自動的にインスタンス作成(new)される。<br>
     * service側はステートレスセッションbeanにするため、Statelessアノテーションをつけておくこと。<br>
     */
    @Inject
    private S003Service s003Service;

    @Inject
    private StoredProceduresService storedProceduresService;
    
    /**
     * パラメータ格納クラスをinjection(CDI)<br>
     * InjectアノテーションよりAPサーバー(Glassfish)側で自動的にインスタンス作成(new)される。<br>
     */
    @Inject
    private S003Bean s003Bean;

    /**
     * 初期表示
     * @param req
     * @param resp
     * @return
     * @throws Exception 
     */
    public String indexAction(HttpServletRequest req, HttpServletResponse resp)
    throws Exception {
        logger.info("S003Servlet#indexAction");

        // リクエストパラメータをs003Beanの同名フィールドに一括コピー
        ParameterBinder.Bind(s003Bean, req);
        s003Bean.setEditFlg("");
        s003Service.indexExecute();
        
        return INDEX_JSP;
    }

    /**
     * 編集表示
     * @param req
     * @param resp
     * @return
     * @throws Exception 
     */
    public String editAction(HttpServletRequest req, HttpServletResponse resp)
    throws Exception {
        logger.info("S003Servlet#editAction");

        // リクエストパラメータをs003Beanの同名フィールドに一括コピー
        ParameterBinder.Bind(s003Bean, req);

        // 表示円貨は1円単位に戻す
        s003Bean.setJpyUnit(1);
        s003Bean.setEditFlg("1");
        s003Service.indexExecute();
        
        return INDEX_JSP;
    }

    /**
     * 保存
     * @param req
     * @param resp
     * @return
     * @throws Exception 
     */
    public String saveAction(HttpServletRequest req, HttpServletResponse resp) throws Exception {
        logger.info("S003Servlet#saveAction");

        // リクエストパラメータをs003Beanの同名フィールドに一括コピー
        ParameterBinder.Bind(s003Bean, req);

        // 登録を行う
        s003Service.updateExpectedAmount(0);
        
        // (原子力)連携バッチを実行
        //storedProceduresService.callN7RenkeiBatchJudge(s003Bean.getAnkenId(), s003Bean.getRirekiId());
        
        // 処理結果を戻す。
        Map<String, Object> jsonMap = new HashMap<>();
        ResultMessageBean resultMessageBean = CdiUtils.getBean(ResultMessageBean.class);
        resultMessageBean.createResultMessage(jsonMap);
        resopnseDecodeJson(resp, jsonMap);

        return null;
    }
    
    /**
     * 見込レート反映処理
     * @param req
     * @param resp
     * @return
     * @throws Exception 
     */
    public String mikomiRateAction(HttpServletRequest req, HttpServletResponse resp) throws Exception {
        logger.info("S003Servlet#mikomiRateAction");

        // リクエストパラメータをs003Beanの同名フィールドに一括コピー
        ParameterBinder.Bind(s003Bean, req);

        // 登録を行う
        s003Service.findMikomiRate();
        
       //List<Map<String, String>> mikomiRateInfo = s003Bean.getMikomiRateInfoList();
        Map<String, Map<String, String>> mikomiRateInfo = s003Bean.getMikomiRateInfo();
        resopnseDecodeJson(resp, mikomiRateInfo);

        return null;
    }
    
    /**
     * 最新値更新
     */
    public String updateNewDataAction(HttpServletRequest req, HttpServletResponse resp)
    throws Exception {
        logger.info("S003Servlet#updateNewDataAction");

        ParameterBinder.Bind(s003Bean, req);

        if ("1".equals(s003Bean.getEditFlg())) {
            // 更新モードの場合は画面の値も更新する
            s003Service.updateExpectedAmount(1);
        } else {
            // 参照モード
            s003Service.callUpdateDataProcedureExecute(1);
        }

        // 処理結果を戻す。
        Map<String, Object> jsonMap = new HashMap<>();
        ResultMessageBean resultMessageBean = CdiUtils.getBean(ResultMessageBean.class);
        resultMessageBean.createResultMessage(jsonMap);
        resopnseDecodeJson(resp, jsonMap);
        
        return null;
    }
    
}
