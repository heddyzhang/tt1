package jp.co.toshiba.hby.pspromis.syuueki.filter;

import java.io.IOException;
import java.io.PrintStream;
import java.io.PrintWriter;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.inject.Inject;
import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.annotation.WebFilter;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import jp.co.toshiba.hby.pspromis.syuueki.bean.AuthorityBean;
import jp.co.toshiba.hby.pspromis.syuueki.dto.DivisionDto;
import jp.co.toshiba.hby.pspromis.syuueki.entity.DivisionMst;
import jp.co.toshiba.hby.pspromis.syuueki.entity.SyokusyuMst;
import jp.co.toshiba.hby.pspromis.syuueki.enums.Env;
import jp.co.toshiba.hby.pspromis.syuueki.facade.DivisionMstFacade;
import jp.co.toshiba.hby.pspromis.syuueki.facade.SyokusyuMstFacade;
import jp.co.toshiba.hby.pspromis.syuueki.service.KengenService;
import jp.co.toshiba.hby.pspromis.syuueki.service.SessionTblService;
import jp.co.toshiba.hby.pspromis.syuueki.util.DateFormatDefin;
import jp.co.toshiba.hby.pspromis.syuueki.util.LoginUserInfo;
import jp.co.toshiba.hby.pspromis.syuueki.pages.DivisonComponentPage;
//import jp.co.toshiba.hby.pspromis.syuueki.dto.DivisionDto;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * PS-Promis収益管理システム
 * Servlet用フィルター
 * @author (NPC)S.Ibayashi
 */
@WebFilter(filterName = "BaseFilter", urlPatterns = {"/servlet/*"})
public class BaseFilter implements Filter {

    public static final Logger logger = LoggerFactory.getLogger(BaseFilter.class);

    private static final boolean debug = true;

    private FilterConfig filterConfig = null;

    private String charset;

    @Inject
    private LoginUserInfo loginUserInfo;

    @Inject
    private DateFormatDefin dateFormatDefin;

    @Inject
    private SessionTblService sessionTblService;

    @Inject
    private KengenService kengenService;
    
    @Inject
    private SyokusyuMstFacade syokusyuMstFacade;

    @Inject
    private DivisionMstFacade divisionMstFacade;
    
    @Inject
    private AuthorityBean authorityBean;
    
    @Inject
    private DivisonComponentPage divisionComponentPage;
    
    public BaseFilter() {
    }    

    /**
     * Destroy method for this filter
     */
    @Override
    public void destroy() {        
    }

    /**
     * Init method for this filter
     * @param filterConfig
     */
    @Override
    public void init(FilterConfig filterConfig) {        
        this.filterConfig = filterConfig;
        charset = Env.getValue(Env.Charset);
        
        // web.xmlからシステムで利用する日付書式を取得してDateFormatDefinに設定しておく。
        ServletContext context = filterConfig.getServletContext();
        dateFormatDefin.setDateFormatDate(context.getInitParameter("dateFormat"));
        dateFormatDefin.setDateFormatYm(context.getInitParameter("dateFormatYM"));
        dateFormatDefin.setDateFormatTimestamp(context.getInitParameter("dateFormatTimestamp"));
    }

    /**
     * ログイン者情報をセッションテーブルから情報取得
     * @throws ServletException 
     */
    private void searchSessionTbl() throws ServletException {
        try {
            if (loginUserInfo.isIsSessionTblInfo()) {
                logger.info("userd session tbl id=" + loginUserInfo.getSessionId() + " userid=" + loginUserInfo.getUserId());
            } else {
                logger.info("search session tbl id=" + loginUserInfo.getSessionId() + " userid=" + loginUserInfo.getUserId());
                Map<String, Object> sessionMap = sessionTblService.getSessionMap();
                if (sessionMap != null) {
                    loginUserInfo.setDepartmentCd((String)sessionMap.get("IDSZKCD"));
                    loginUserInfo.setDepartmentName((String)sessionMap.get("IDSZKR"));
                    loginUserInfo.setIsSessionTblInfo(true);
                } else {
                    logger.info("no session tbl data id=" + loginUserInfo.getSessionId() + " userid=" + loginUserInfo.getUserId());
                }
            }

        } catch(SQLException e) {
            throw new ServletException(e);
        }
    }

    /**
     * 事業部マスタのデータを取得
     */
    private void searchDivisionMstList() {
//List<DivisionMst> divisionEntityList = divisionMstFacade.findAllDivisionList();
//divisionComponentPage.setDivisionMst(divisionEntityList);

        if (divisionComponentPage.getDivisionList() != null) {
            logger.info("now Getting divisionComponent");
        } else {
            List<DivisionMst> divisionEntityList = divisionMstFacade.findAllDivisionList();
            divisionComponentPage.setDivisionMst(divisionEntityList);
        }

        // ログイン者所属事業部で、一番優先順位が高い事業部をセットする
        DivisionDto priorityDivision = divisionComponentPage.getPriorityDivision();
        loginUserInfo.setPriorityDivCode(priorityDivision.getDivisionCode());
    }

    /**
     * ログイン者の職種マスタデータを取得
     */
    public void serchSyokusyuMstList() {
        if (loginUserInfo.isIsJgrpSyokusyuInfo()) {
            logger.info("used jgrpSyokusyu userid=" + loginUserInfo.getUserId());
        } else {
            logger.info("search jgrpSyokusyu userid=" + loginUserInfo.getUserId());
        
            List<SyokusyuMst> entityList
                    = syokusyuMstFacade.getJobGrSyokusyu(loginUserInfo.getUserId());

            List<Map<String, Object>> syokusyuList = new ArrayList<>();

            if (entityList != null) {
                for(SyokusyuMst entity : entityList) {
                    logger.info("get syokusyu JgrpId=" + entity.getJgrpId() + " syokusyuCd=" + entity.getSyokusyuCd() + " division=" + entity.getAtsukaiDivision());
                    Map<String, Object> syokusyuMap = new HashMap<>();
                    syokusyuMap.put("JgrpId", entity.getJgrpId());
                    syokusyuMap.put("syokusyuCd", entity.getSyokusyuCd());
                    syokusyuMap.put("division", entity.getAtsukaiDivision());
                    syokusyuMap.put("divisionSubName", entity.getDivisionSubName());
                    syokusyuMap.put("divisionSubCode", entity.getDivisionSubCode());
                    syokusyuMap.put("jgrpPetName", entity.getJgrpPetName());
                    syokusyuList.add(syokusyuMap);
                }
            }

            loginUserInfo.setJobGrList(syokusyuList);
            loginUserInfo.setIsJgrpSyokusyuInfo(true);
        }
    }

    /**
     * ログイン者の職種マスタデータを取得
     * @throws java.lang.Exception
     */
    public void serchAuthority() throws Exception {
        boolean isSearchKengenMst = false;
        
        if (authorityBean == null) {
            isSearchKengenMst = true;
        } else {
            if (authorityBean.getAuthorityKeyMap() == null || authorityBean.getAuthorityRirekiKeyMap() == null) {
                isSearchKengenMst = true;
            }
        }
  
        if (isSearchKengenMst) {
            kengenService.searchKengenMst();
        }
    }
    
    /**
     * フィルター前処理
     * @param request
     * @param response
     * @throws IOException
     * @throws ServletException 
     */
    private void doBeforeProcessing(ServletRequest request, ServletResponse response)
    //throws IOException, ServletException{
    throws Exception{
        // エンコード文字コードを設定
        request.setCharacterEncoding(charset);
        response.setCharacterEncoding(charset);

        // ログインユーザー情報をPS-Promisセッションから取得してオブジェクトにセット
        loginUserInfo.setUserInfo((HttpServletRequest)request);

        // セッションテーブルから情報取得
        searchSessionTbl();

        // 職種マスタを検索
        serchSyokusyuMstList();

        // 権限の検索
        serchAuthority();
        
        // 事業部マスタの検索
        searchDivisionMstList();
    }

    private void doAfterProcessing(ServletRequest request, ServletResponse response)
    throws IOException, ServletException {
    }

    /**
     *
     * @param request The servlet request we are processing
     * @param response The servlet response we are creating
     * @param chain The filter chain we are processing
     *
     * @exception IOException if an input/output error occurs
     * @exception ServletException if a servlet error occurs
     */
    @Override
    public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain)
    throws IOException, ServletException {
        Throwable problem = null;
        try {
            doBeforeProcessing(request, response);
            
            chain.doFilter(request, response);
        } catch (Throwable t) {
            ((HttpServletResponse)response).setHeader("X-ERROR-PAGE", "1");
            logger.error("致命的エラー発生", t);
            problem = t;
        }

        doAfterProcessing(request, response);

        if (problem != null) {
            if (problem instanceof ServletException) {

                throw (ServletException) problem;
            }
            if (problem instanceof IOException) {
                throw (IOException) problem;
            }
            throw new ServletException(problem);
            //sendProcessingError(problem, response);
        }
    }
    
}
