package jp.co.toshiba.hby.pspromis.syuueki.facade;

import java.util.Map;
import java.util.HashMap;
import java.util.List;
import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.inject.Inject;
import javax.interceptor.Interceptors;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import jp.co.toshiba.hby.pspromis.common.jdbc.SqlExecutor;
import jp.co.toshiba.hby.pspromis.syuueki.entity.DivisionMst;
import jp.co.toshiba.hby.pspromis.syuueki.interceptor.TranceInterceptor;

/**
 *
 * @author ibayashi
 */
@Stateless
@Interceptors({TranceInterceptor.class}) 
public class DivisionMstFacade {

    @PersistenceContext(unitName = jp.co.toshiba.hby.pspromis.syuueki.util.ConstantString.syuuekiDataSourceName)
    private EntityManager entityManager;

    @Inject
    private SqlExecutor sqlExecutor;

    /**
     * 指定条件の事業部データを取得する
     * @param condition
     * @return 
     */
    @TransactionAttribute(TransactionAttributeType.NOT_SUPPORTED)
    public List<DivisionMst> findDivisionList(Map<String, Object> condition) {
        List<DivisionMst> list
                = sqlExecutor.getResultList(entityManager, DivisionMst.class, "/sql/divisionMst/selectDivisionMst.sql", condition);

        return list;
    }
    
    /**
     * 全事業部データを取得する
     * @return 
     */
    @TransactionAttribute(TransactionAttributeType.NOT_SUPPORTED)
    public List<DivisionMst> findAllDivisionList() {
        Map<String, Object> condition = new HashMap<>();
        condition.put("divisionType", "1");
        
        return findDivisionList(condition);
    }

}
