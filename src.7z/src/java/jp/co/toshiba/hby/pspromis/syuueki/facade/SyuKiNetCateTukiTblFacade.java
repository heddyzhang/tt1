/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package jp.co.toshiba.hby.pspromis.syuueki.facade;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.ejb.Stateless;
import javax.inject.Inject;
import javax.interceptor.Interceptors;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import jp.co.toshiba.hby.pspromis.syuueki.entity.StringEntity;
import jp.co.toshiba.hby.pspromis.syuueki.entity.SyuKiNetCateTukiTbl;
import jp.co.toshiba.hby.pspromis.syuueki.interceptor.TranceInterceptor;
import jp.co.toshiba.hby.pspromis.syuueki.util.LoginUserInfo;
import org.apache.commons.collections.CollectionUtils;

/**
 *
 * @author ibayashi
 */
@Stateless
@Interceptors({TranceInterceptor.class})
public class SyuKiNetCateTukiTblFacade extends AbstractFacade<SyuKiNetCateTukiTbl> {
    @PersistenceContext(unitName = jp.co.toshiba.hby.pspromis.syuueki.util.ConstantString.syuuekiDataSourceName)
    private EntityManager em;

    @Override
    protected EntityManager getEntityManager() {
        return em;
    }

    public SyuKiNetCateTukiTblFacade() {
        super(SyuKiNetCateTukiTbl.class);
    }

    @Inject
    private LoginUserInfo loginUserInfo;

    /**
     * パラメータにログイン者idをセット
     */
    private Map<String, Object> addParamLoginId(Map<String, Object> _params) {
        Map<String, Object> ret = _params;
        if (ret == null) {
            ret = new HashMap<>();
        }
        ret.put("userId", loginUserInfo.getUserId());
        return ret;
    }

    public SyuKiNetCateTukiTbl getPkInfo(String ankenId, Integer rirekiId, String dataKbn, String syuekiYm, String categoryCode, String categoryKbn1, String categoryKbn2) {
        Query q = em.createNamedQuery("KiNetCateTukiTbl.findPk", SyuKiNetCateTukiTbl.class);
        
        q.setParameter("ankenId", ankenId);
        q.setParameter("rirekiId", rirekiId);
        q.setParameter("dataKbn", dataKbn);
        q.setParameter("syuekiYm", syuekiYm);
        q.setParameter("categoryCode", categoryCode);
        q.setParameter("categoryKbn1", categoryKbn1);
        q.setParameter("categoryKbn2", categoryKbn2);

        SyuKiNetCateTukiTbl en;
        
        try {
            en = (SyuKiNetCateTukiTbl)q.getSingleResult();
        } catch(javax.persistence.NoResultException e){
            // 指定PKのデータが存在しない場合
            en = null;
        }
        
        return en;
    }

    public SyuKiNetCateTukiTbl getPkInfo(String ankenId, Integer rirekiId, String dataKbn, String syuekiYm) {
        Map<String, Object> condition = new HashMap<>(); 
        condition.put("ankenId", ankenId);
        condition.put("rirekiId", rirekiId);
        condition.put("dataKbn", dataKbn);
        condition.put("syuekiYm", syuekiYm);

        SyuKiNetCateTukiTbl en = sqlExecutor.getSingleResult(em, SyuKiNetCateTukiTbl.class, "/sql/syuKiNetCateTukiTbl/selectKiNetCateTukiTblPk.sql", condition);
        
        return en;
    }

    /**
     * 指定した条件の対象データを削除
     * @param condtion
     * @return 
     */
    public int deleteSyuKiNetCateTukiTbl(Map<String, Object> condtion) {
        int count = sqlExecutor.executeUpdateSql(em, "/sql/syuKiNetCateTukiTbl/deleteKiNetCateTukiTbl.sql", condtion);
        return count;
    }

    /**
     * 受注管理/受注NETの更新(新規登録)
     * @param _params
     * @return 
     */
    public int entrySyuKiNetCateTukiTbl(Map<String, Object> _params) {
        Map<String, Object> params = addParamLoginId(_params);
        int count;

        // 更新
        count = sqlExecutor.executeUpdateSql(em, "/sql/syuKiNetCateTukiTbl/updateSyuKiNetCateTukiTbl.sql", params);
        // 更新データ存在しない場合は新規登録
        if (count == 0) {
            insertSyuKiNetCateTukiTbl(params);
        }

        return count;
    }
    
    /**
     * 登録
     */
    public int insertSyuKiNetCateTukiTbl(Map<String, Object> _params) {
        Map<String, Object> params = addParamLoginId(_params);
        int count = sqlExecutor.executeUpdateSql(em, "/sql/syuKiNetCateTukiTbl/insertSyuKiNetCateTukiTbl.sql", params);
        return count;
    }

    /**
     * カテゴリ区分の更新
     * @param condition 
     */
    public void updateCategory(Map<String ,Object> condition){
        int count = sqlExecutor.executeUpdateSql(em, "/sql/syuKiNetCateTukiTbl/updateCategory.sql", condition);
    }
    
    /**
     * 対象カテゴリの最終見込/当月以降の見込データを削除
     * @param condition 
     */
    public void deleteTargetCategoryMikomiNet(Map<String ,Object> condition){
        int count = sqlExecutor.executeUpdateSql(em, "/sql/syuKiNetCateTukiTbl/deleteCateMikomiKiNetCateTukiTbl.sql", condition);
    }
    
    /**
     * 最新の年月を取得
     * @param params
     * @return 
     */
    public String getMaxSyuekiYm(Map<String, Object> params){
        List<StringEntity> list = sqlExecutor.getResultList(em, StringEntity.class, "/sql/syuKiNetCateTukiTbl/selectMaxSyuekiYm.sql", params);
        
        if (CollectionUtils.isNotEmpty(list)) {
            return list.get(0).getString().trim();
        } else {
            return "";
        }
    }

    /**
     * 売上年月の更新
     * @param _params
     */
    public int changeSyuekiYm(Map<String, Object> _params){
        int count = sqlExecutor.executeUpdateSql(em, "/sql/syuKiNetCateTukiTbl/changeSyuekiYm.sql", _params);
        return count;
    }

    /**
     * 売上NET情報を特定年月から特定年月にコピー
     * @param condition
     */
    public int copySyuekiYmUriageNet(Map<String, Object> condition) {
        // 回収データの年月コピーを行う
        int count = sqlExecutor.executeUpdateSql(em, "/sql/syuKiNetCateTukiTbl/copySyuekiYmUriageNet.sql", condition);

        return count;
    }
    
}
