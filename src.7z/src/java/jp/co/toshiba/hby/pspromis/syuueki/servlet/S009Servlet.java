package jp.co.toshiba.hby.pspromis.syuueki.servlet;

import java.util.HashMap;
import java.util.Map;
import javax.inject.Inject;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpServletRequest;
import jp.co.toshiba.hby.pspromis.syuueki.bean.S009Bean;
import jp.co.toshiba.hby.pspromis.syuueki.bean.S009MstBean;
import jp.co.toshiba.hby.pspromis.syuueki.bean.ValidationInfoBean;
import jp.co.toshiba.hby.pspromis.syuueki.service.S009Service;
import jp.co.toshiba.hby.pspromis.syuueki.util.ParameterBinder;
import jp.co.toshiba.hby.pspromis.syuueki.validation.S009Validation;

/**
 * PS-Promis収益管理システム
 * 注入パターンマスタ詳細 Servlet
 * @author kitajima
 */
@WebServlet(name="S009", urlPatterns={"/servlet/S009", "/servlet/S009/*"})
public class S009Servlet extends AbstractServlet {

    /**
     * jsp
     */
    private static final String INDEX_JSP = "S009/s009.jsp";

    /**
     * 使用serviceクラスをinjection(CDI)<br>
     */
    @Inject
    private S009Service s009Service;

    /**
     * パラメータ格納クラスをinjection(CDI)<br>
     */
    @Inject
    private S009Bean s009Bean;
    
    @Inject
    private S009MstBean s009MstBean;
    
    @Inject
    private ValidationInfoBean validationInfoBean;
    
    /**
     * 初期表示
     * @param req
     * @param resp
     * @return
     * @throws Exception 
     */
    public String indexAction(HttpServletRequest req, HttpServletResponse resp)
    throws Exception {
        logger.info("S009Servlet#indexAction");
        
        // リクエストパラメータをs009Beanの同名フィールドに一括コピー
        ParameterBinder.Bind(s009Bean, req);
        
        // サービスの実行(トランザクションの単位にもなる)
        s009Service.indexExecute();

        return INDEX_JSP;
    }

    /**
     * 一覧データ取得(注入パターンマスタ)
     * @param req
     * @param resp
     * @return
     * @throws Exception 
     */
    public String listAction(HttpServletRequest req, HttpServletResponse resp)
    throws Exception {
        logger.info("S009Servlet#listAction");

        // リクエストパラメータをs009Beanの同名フィールドに一括コピー
        ParameterBinder.Bind(s009Bean, req);
        
        // ダイレクトアクセスされた場合はindexにリダイレクト
        if (!"1".equals(s009Bean.getListFlg())) {
            resp.sendRedirect(req.getContextPath() + "/servlet/S009");
            return null;
        }

        // パラメータのバリデーションチェック
        S009Validation validation = new S009Validation(s009Bean);
        validation.execListValidation(validationInfoBean);
        
        if (validationInfoBean.isSuccess()) {
            // メニュー選択により処理を分岐
            if ("PTN".equals(s009Bean.getSelMenu())) {
                // 注入パターンマスタ
                s009Service.listExecute();
            } else if ("UPLOAD".equals(s009Bean.getSelMenu())) {
                // 見込アップロード指定画面表示
                s009Service.uploadlistExecute();
            } else if ("RATE".equals(s009Bean.getSelMenu())) {
                // 見込レートマスタ
                s009Service.listRateTypeExecute();
            }
        }

        // jspをforward
        return INDEX_JSP;
    }
   
    /**
     * プラント種別マスタ再取得
     * @param req
     * @param resp
     * @return
     * @throws Exception 
     */
    public String plantTypeMstAction(HttpServletRequest req, HttpServletResponse resp)
    throws Exception {
        logger.info("S009Servlet#plantTypeMstAction");
    
        // リクエストパラメータをs009Beanの同名フィールドに一括コピー
        ParameterBinder.Bind(s009Bean, req);

        s009Service.plantTypeMstExecute();
    
        // 結果セットをjson出力
        Map<String, Object> jsonMap = new HashMap<>();
        jsonMap.put("plantTypeList", s009MstBean.getPlantTypeList());
        resopnseDecodeJson(resp, jsonMap);
        
        // ここでは戻すjspが存在しないため、nullを返す。
        return null;
    }

}
