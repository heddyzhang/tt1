package jp.co.toshiba.hby.pspromis.syuueki.entity;

import java.io.Serializable;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 *
 * @author rnomura
 */
@Entity
@Table(name = "SYU_GE_CATEGORY_MAP")
public class SyuGeCategoryMapView implements Serializable {

    private static final long serialVersionUID = 1L;
    
    @Id
    @Column(name = "CATEGORY_CODE")
    private String categoryCode;
    
    @Column(name = "CATEGORY_KBN1")
    private String categoryKbn1;

    @Column(name = "CATEGORY_KBN2")
    private String categoryKbn2;

    @Column(name = "CATEGORY_NAME1")
    private String categoryName1;
    
    @Column(name = "CATEGORY_NAME2")
    private String categoryName2;

    @Column(name = "DIVISION_CODE")
    private String divisionCode;

    @Column(name = "SALES_CLASS")
    private String salesClass;

    @Column(name = "IS_DELETED")
    private String isDeleted;

    @Column(name = "BIKOU")
    private String bikou;
    
    public SyuGeCategoryMapView() {
    }

    public String getCategoryCode() {
        return categoryCode;
    }

    public void setCategoryCode(String categoryCode) {
        this.categoryCode = categoryCode;
    }

    public String getCategoryKbn1() {
        return categoryKbn1;
    }

    public void setCategoryKbn1(String categoryKbn1) {
        this.categoryKbn1 = categoryKbn1;
    }

    public String getCategoryKbn2() {
        return categoryKbn2;
    }

    public void setCategoryKbn2(String categoryKbn2) {
        this.categoryKbn2 = categoryKbn2;
    }

    public String getCategoryName1() {
        return categoryName1;
    }

    public void setCategoryName1(String categoryName1) {
        this.categoryName1 = categoryName1;
    }

    public String getCategoryName2() {
        return categoryName2;
    }

    public void setCategoryName2(String categoryName2) {
        this.categoryName2 = categoryName2;
    }

    public String getDivisionCode() {
        return divisionCode;
    }

    public void setDivisionCode(String divisionCode) {
        this.divisionCode = divisionCode;
    }

    public String getSalesClass() {
        return salesClass;
    }

    public void setSalesClass(String salesClass) {
        this.salesClass = salesClass;
    }

    public String getIsDeleted() {
        return isDeleted;
    }

    public void setIsDeleted(String isDeleted) {
        this.isDeleted = isDeleted;
    }

    public String getBikou() {
        return bikou;
    }

    public void setBikou(String bikou) {
        this.bikou = bikou;
    }
}
