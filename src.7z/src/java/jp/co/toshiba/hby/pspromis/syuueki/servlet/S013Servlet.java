package jp.co.toshiba.hby.pspromis.syuueki.servlet;

import java.util.HashMap;
import java.util.Map;
import javax.inject.Inject;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpServletRequest;
import jp.co.toshiba.hby.pspromis.syuueki.bean.S013Bean;
import jp.co.toshiba.hby.pspromis.syuueki.bean.ValidationInfoBean;
import jp.co.toshiba.hby.pspromis.syuueki.service.S013Service;
import jp.co.toshiba.hby.pspromis.syuueki.util.ParameterBinder;
import jp.co.toshiba.hby.pspromis.syuueki.validation.S013Validation;

/**
 * PS-Promis収益管理システム
 * 月次確定検索 Servlet
 * @author ibayashi
 */
@WebServlet(name="S013", urlPatterns={"/servlet/S013", "/servlet/S013/*"})
public class S013Servlet extends AbstractServlet {

    /**
     * jsp
     */
    private static final String INDEX_JSP = "S013/s013.jsp";

    @Inject
    private S013Bean s013Bean;
    
    /**
     * 使用serviceクラスをinjection(CDI)<br>
     */
    @Inject
    private S013Service s013Service;

    @Inject
    private ValidationInfoBean validationInfoBean;
    
    /**
     * 初期表示
     * @param req
     * @param resp
     * @return
     * @throws Exception 
     */
    public String indexAction(HttpServletRequest req, HttpServletResponse resp)
    throws Exception {
        logger.info("S013Servlet#indexAction");
        
        // リクエストパラメータをS013Beanの同名フィールドに一括コピー
        ParameterBinder.Bind(s013Bean, req);
        
        // サービスの実行(トランザクションの単位にもなる)
        s013Service.indexExecute();

        return INDEX_JSP;
    }

    /**
     * 一覧データ取得(注入パターンマスタ)
     * @param req
     * @param resp
     * @return
     * @throws Exception 
     */
    public String listAction(HttpServletRequest req, HttpServletResponse resp)
    throws Exception {
        logger.info("S013Servlet#listAction");

        // リクエストパラメータをS013Beanの同名フィールドに一括コピー
        ParameterBinder.Bind(s013Bean, req);

        // ダイレクトアクセスされた場合はindexにリダイレクト
        if (!"1".equals(s013Bean.getListFlg())) {
            resp.sendRedirect(req.getContextPath() + "/servlet/S013");
            return null;
        }

        // パラメータのバリデーションチェック
        S013Validation validation = new S013Validation(s013Bean);
        validation.execListValidation(validationInfoBean);

        if (validationInfoBean.isSuccess()) {
            // バリデーションチェックに通った場合のみサービス実行。
            s013Service.listExecute();
        }

        // jspをforward
        return INDEX_JSP;
    }

    /**
     * 検索条件の指定により営業部門の選択候補を絞り込み
     * @param req
     * @param resp
     * @return
     * @throws Exception 
     */
    public String eigyoSectionAction(HttpServletRequest req, HttpServletResponse resp) 
    throws Exception {
        logger.info("S013Servlet#eigyoSectionAction");

        // リクエストパラメータをS013Beanの同名フィールドに一括コピー
        ParameterBinder.Bind(s013Bean, req);

        s013Service.eigyoSectionExecute();

        // 結果セットをjson出力
        Map<String, Object> jsonMap = new HashMap<>();
        jsonMap.put("eigyoSectionList", s013Bean.getEigyoSectionList());
        jsonMap.put("eigyoSectionCode", s013Bean.getEigyoSectionCode());
        resopnseDecodeJson(resp, jsonMap);

        // ここでは戻すjspが存在しないため、nullを返す。
        return null;
    }
    
    /**
     * 検索条件の指定により対象(予算ベース)の選択候補を絞り込み
     * @param req
     * @param resp
     * @return
     * @throws Exception 
     */
    public String taishoAction(HttpServletRequest req, HttpServletResponse resp) 
    throws Exception {
        logger.info("S013Servlet#taishoAction");

        // リクエストパラメータをS013Beanの同名フィールドに一括コピー
        ParameterBinder.Bind(s013Bean, req);

        s013Service.taishoExecute();

        // 結果セットをjson出力
        Map<String, Object> jsonMap = new HashMap<>();
        jsonMap.put("taishoList", s013Bean.getTaishoList());
        jsonMap.put("taisho", s013Bean.getTaisho());
        resopnseDecodeJson(resp, jsonMap);

        // ここでは戻すjspが存在しないため、nullを返す。
        return null;
    }
    
}
