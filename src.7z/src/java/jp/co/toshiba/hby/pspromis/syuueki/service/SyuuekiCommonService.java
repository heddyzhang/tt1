/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package jp.co.toshiba.hby.pspromis.syuueki.service;

import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import javax.ejb.Stateless;
import javax.inject.Inject;
import javax.interceptor.Interceptors;
import jp.co.toshiba.hby.pspromis.syuueki.bean.SyuuekiCommonBean;
import jp.co.toshiba.hby.pspromis.syuueki.dto.DivisionDto;
import jp.co.toshiba.hby.pspromis.syuueki.entity.SyuGeBukkenInfoTbl;
import jp.co.toshiba.hby.pspromis.syuueki.entity.TeamEntity;
import jp.co.toshiba.hby.pspromis.syuueki.entity.BuMst;
import jp.co.toshiba.hby.pspromis.syuueki.facade.TeamMstFacade;
import jp.co.toshiba.hby.pspromis.syuueki.interceptor.TranceInterceptor;
import jp.co.toshiba.hby.pspromis.syuueki.util.ConstantString;
import jp.co.toshiba.hby.pspromis.syuueki.util.LoginUserInfo;
import jp.co.toshiba.hby.pspromis.syuueki.pages.DivisonComponentPage;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 *
 * @author ibayashi
 */
@Stateless
@Interceptors({TranceInterceptor.class})
public class SyuuekiCommonService {

    private static final Logger log = LoggerFactory.getLogger(LoginUserInfo.class);
    
    @Inject
    private DivisonComponentPage divisionComponentPage;
    
    @Inject
    private LoginUserInfo loginUserInfo;
    
    @Inject
    private TeamMstFacade teamMstFacade;
    
    @Inject
    private SyuuekiCommonBean syuuekiCommonBean;

    /**
     * 対象事業部が全案件の参照権限があるかをチェック
     * @param divisionCd
     * @return 参照権限あり:true My案件のみ参照可能:false
     */
    public boolean isDivisionAnkenViewOk(String divisionCd) {
        boolean isViewOk = false;
        
        DivisionDto divisionDto = divisionComponentPage.getTargetDivision(divisionCd);
        String[] syokusyuAry = loginUserInfo.getJobGrSyokusyuArrayInfo("syokusyuCd", divisionCd);
        if (divisionDto != null && (syokusyuAry != null && syokusyuAry.length > 0)) {
            String allAnkenViewSyokusyuCd = StringUtils.defaultString(divisionDto.getAllAnkenViewSyokusyuCd());
            for (String syokusyuCd: syokusyuAry) {
                if (allAnkenViewSyokusyuCd.contains(syokusyuCd)) {
                    isViewOk = true;
                    break;
                }
            }
        }
        
        return isViewOk;
    }
    
    /**
     * 案件の編集権限チェック
     * @param geBukkenEntity
     * @return 
     */
    public boolean isAnkenEditOk(SyuGeBukkenInfoTbl geBukkenEntity) {
        boolean isEditOk = true;

        String divisionCode = StringUtils.defaultString(geBukkenEntity.getDivisionCode());
        DivisionDto divisionDto = divisionComponentPage.getTargetDivision(divisionCode);

        // ログイン者保有チームコードでチェックが必要な事業部は、以下の編集権限チェックを行う。
        if ("1".equals(divisionDto.getAnkenEditAuthKbn())) {
            List<TeamEntity> myTeamList = syuuekiCommonBean.getMyTeamList();
            if (myTeamList == null) {
                myTeamList = teamMstFacade.findUserTeamList(loginUserInfo.getUserId());
                syuuekiCommonBean.setMyTeamList(myTeamList);
                log.info("ログイン者のチームコードを取得 ANKEN_ID=[{}]", geBukkenEntity.getAnkenId());
            }
            log.info("ログイン者チームコード件数=[{}] ANKEN_ID=[{}]", myTeamList.size(), geBukkenEntity.getAnkenId());
            
            isEditOk = isAnkenEditTeamCode(geBukkenEntity, myTeamList);
        }
        
        return isEditOk;
    }

    /**
     * 案件の権限チェック(発番チームコードでのチェック)
     * @param geBukkenEntity
     * @param myTeamList
     * @return 
     */
    public boolean isAnkenEditTeamCode(SyuGeBukkenInfoTbl geBukkenEntity, List<TeamEntity> myTeamList) {
        // 案件の事業部コード
        String divisionCode = StringUtils.defaultString(geBukkenEntity.getDivisionCode());
        // 案件の売上基準
        String salesClass = StringUtils.defaultString(geBukkenEntity.getSalesClass());
        // 扱いCコード
        String targetTeamCode = StringUtils.defaultString(geBukkenEntity.getAtsukaiCCode());
        // 販売チームコード　3桁目以降(2018A追加)
        String targetEgTeamCode = StringUtils.substring(StringUtils.defaultString(geBukkenEntity.getEgTeamCd()), 2);
        // 製造チームコード 3桁目以降(2018A追加)
        String targetSzTeamCode = StringUtils.substring(StringUtils.defaultString(geBukkenEntity.getSzTeamCd()), 2);
        // 販売C(2018A追加)
        String hbCCd = StringUtils.defaultString(geBukkenEntity.getHbCCd());
        // 製造C(2018A追加)
        String szCCd = StringUtils.defaultString(geBukkenEntity.getSzCCd());
 
        List<Map<String, Object>> jobGrList = loginUserInfo.getJobGrList();
        for (Map<String, Object> info: jobGrList) {
            String userDivisionCode = StringUtils.defaultString((String)info.get("division"));
            String syokusyuCd = StringUtils.defaultString((String)info.get("syokusyuCd"));

            log.info("SyuuekiCommonService#isAnkenEditTeamCode ankenId=[{}] divisionCode=[{}] userJobGr=[{}] userDivisionCode=[{}] syokusyuCd=[{}]",
                geBukkenEntity.getAnkenId(), divisionCode, StringUtils.defaultString((String)info.get("JgrpId")), userDivisionCode, syokusyuCd
            );

            if (!divisionCode.equals(userDivisionCode)) {
                continue;
            }

            if (ConstantString.salesClassS.equals(salesClass)) {
                // 進行基準案件(職種M)
                if ("M".equals(syokusyuCd)) {
                    return true;
                }

            } else {
                // 一般案件(ログイン者の保有チームコードと案件の扱いCコードが一致)
                if (CollectionUtils.isNotEmpty(myTeamList)) {
                    for (TeamEntity tEntity : myTeamList) {
                        String myTeamCd = StringUtils.defaultString(tEntity.getTeamCd());
                        myTeamCd = StringUtils.substring(myTeamCd, 2);
                        log.info("SyuuekiCommonService#isAnkenEditTeamCode targetTeamCode=[{}] targetEgTeamCode=[{}]  targetSzTeamCode=[{}] hbCCd=[{}] szCCd=[{}] myTeamCd=[{}]", targetTeamCode, targetEgTeamCode, targetSzTeamCode, hbCCd, szCCd, myTeamCd);

                        // (2018A変更)扱いCに加え、販売チームコードor製造チームコードの何れかが一致している場合は編集OKとする
                        //if (targetTeamCode.equals(myTeamCd) || targetEgTeamCode.equals(myTeamCd) || targetSzTeamCode.equals(myTeamCd)) {
                        //if (targetTeamCode.equals(myTeamCd) || hbCCd.equals(myTeamCd) || szCCd.equals(myTeamCd)) {
                        if (targetTeamCode.equals(myTeamCd) || hbCCd.equals(myTeamCd) || szCCd.equals(myTeamCd) || targetEgTeamCode.equals(myTeamCd) || targetSzTeamCode.equals(myTeamCd)) {
                            return true;
                        }
                    }
                }
            }
        }

        return false;
    }
    
    /**
     * BUマスタ候補から、ログイン者所属JobGrのdivisionSubName(兼務先のDivisionSubName全て)と一致するSBU(or BU)を配列で取得
     * 1件でも不一致があれば一致していないと見なす
     * @param targetDivisionCode 対象の事業部コード
     * @param list　BUマスタ候補
     * @param kbn 返却する情報(0:BUコード 1:SBUコード)
     * @return 
     */
    public String[] getDefaultLoginSameBuArray(String targetDivisionCode, List<BuMst> list, int kbn) {
        if (CollectionUtils.isEmpty(list)) {
            return null;
        }

        List<BuMst> changeList = list;
        String[] loginSubDivisionNames = loginUserInfo.getJobGrSyokusyuArrayInfo("divisionSubName", targetDivisionCode);
        if (loginSubDivisionNames == null) {
            return null;
        }

        Set<String> sameDataList = new HashSet<>();
        for (String loginSubDivisionName: loginSubDivisionNames) {
            int sameSubDivisionNameCount = 0;
            for (BuMst buMst: changeList) {
                String buDivisionCode = StringUtils.defaultString(buMst.getDivisionCode());
                if (!buDivisionCode.equals(targetDivisionCode)) {
                    continue;
                }

                if (isSameSubDivisionName(buMst, loginSubDivisionName)) {
                    String data;
                    if (kbn == 0) {
                        data = buMst.getBuCode();
                    } else {
                        data = buMst.getSbuCode();
                    }
                    sameDataList.add(data);
                    sameSubDivisionNameCount++;
                }
            }
            
            // 対象のDIVISION_SUB_NAMEに一致するBUが存在しない場合、BU条件のデフォルトは1件も選択してはならないのでこれまでため込みしたBUデフォルト条件は全てクリアする
            if (sameSubDivisionNameCount == 0) {
                sameDataList.clear();
                break;
            }
        }

        return (String[])sameDataList.toArray(new String[0]);
    }
    
    /**
     * BUマスタからログイン者所属JobGrのdivisionSubName(兼務先のDivisionSubName全て)と一致するかを確認
     * 1件でも不一致があれば一致していないと見なす
     * @param buMst
     * @param divisionSubNames
     * @return 
     */
    public boolean isSameSubDivisionName(BuMst buMst, String[] divisionSubNames) {
        if (buMst == null || divisionSubNames == null) {
            return false;
        }

        for (String divisionSubName: divisionSubNames) {
            if (isSameSubDivisionName(buMst, divisionSubName)) {
                return true;
            }
        }

        //return (divisionSubNames.length == sameCount);
        return false;
    }

    public boolean isSameSubDivisionName(BuMst buMst, String divisionSubName) {
        if (buMst == null || StringUtils.isEmpty(divisionSubName)) {
            return false;
        }

        boolean isSame = divisionSubName.equals(buMst.getBuName());
        return isSame;
    }

}
