package jp.co.toshiba.hby.pspromis.syuueki.service;

import java.math.BigDecimal;
//import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.ejb.Stateless;
import javax.inject.Inject;
import javax.interceptor.Interceptors;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
//import jp.co.toshiba.hby.pspromis.common.util.StringUtil;
import jp.co.toshiba.hby.pspromis.syuueki.bean.S012Bean;
import jp.co.toshiba.hby.pspromis.syuueki.entity.OperationLog;
import jp.co.toshiba.hby.pspromis.syuueki.entity.SyuGeBukkenInfoTbl;
import jp.co.toshiba.hby.pspromis.syuueki.enums.Env;
import jp.co.toshiba.hby.pspromis.syuueki.facade.SyuGeBukenInfoTblFacade;
import jp.co.toshiba.hby.pspromis.syuueki.interceptor.TranceInterceptor;
import jp.co.toshiba.hby.pspromis.common.jdbc.SqlExecutor;
//import jp.co.toshiba.hby.pspromis.syuueki.dto.AnkenRecalIDto;
import jp.co.toshiba.hby.pspromis.syuueki.entity.SyuCurMst;
//import jp.co.toshiba.hby.pspromis.syuueki.entity.SyuKiJyuchuSpTbl;
import jp.co.toshiba.hby.pspromis.syuueki.entity.SyuKiSpCurTbl;
import jp.co.toshiba.hby.pspromis.syuueki.entity.SyuKiSpTukiITbl;
import jp.co.toshiba.hby.pspromis.syuueki.entity.SyuKiSpTukiSTbl;
import jp.co.toshiba.hby.pspromis.syuueki.entity.SyuSaSpCurTitleTbl;
import jp.co.toshiba.hby.pspromis.syuueki.entity.SyuSaSpCurCurrencyTbl;
import jp.co.toshiba.hby.pspromis.syuueki.facade.SysdateEntityFacade;
import jp.co.toshiba.hby.pspromis.syuueki.facade.SyuCurMstFacade;
import jp.co.toshiba.hby.pspromis.syuueki.facade.SyuKiJyuchuSpTblFacade;
import jp.co.toshiba.hby.pspromis.syuueki.facade.SyuKiSpCurTblFacade;
import jp.co.toshiba.hby.pspromis.syuueki.facade.SyuKiSpTukiITblFacade;
import jp.co.toshiba.hby.pspromis.syuueki.facade.SyuSaSpCurTitleTblFacade;
import jp.co.toshiba.hby.pspromis.syuueki.facade.SyuSaSpCurTblFacade;
import jp.co.toshiba.hby.pspromis.syuueki.facade.SyuKiSpTukiSTblFacade;
import jp.co.toshiba.hby.pspromis.syuueki.util.ConstantString;
import jp.co.toshiba.hby.pspromis.syuueki.util.EntityUtils;
import jp.co.toshiba.hby.pspromis.syuueki.util.LoginUserInfo;
import jp.co.toshiba.hby.pspromis.syuueki.util.NumberUtils;
import org.apache.commons.beanutils.BeanUtils;
import org.apache.commons.beanutils.PropertyUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 *
 * @author sano
 */
@Stateless
@Interceptors({TranceInterceptor.class})
public class S012Service {
    public static final Logger logger = LoggerFactory.getLogger(S012Service.class);

    @PersistenceContext(unitName = jp.co.toshiba.hby.pspromis.syuueki.util.ConstantString.syuuekiDataSourceName)
    private EntityManager em;
    
    @Inject
    private S012Bean s012Bean;

    @Inject
    private LoginUserInfo loginUserInfo;

    @Inject
    protected SqlExecutor sqlExecutor;
    
    @Inject
    private SyuGeBukenInfoTblFacade syuGeBukenInfoTblFacade;
    
    @Inject
    private SyuCurMstFacade syuCurMstFacade;
    
    @Inject
    private SyuKiJyuchuSpTblFacade syuKiJyuchuSpTblFacade;
    
    @Inject
    private SyuKiSpCurTblFacade syuKiSpCurTblFacade;

    @Inject
    private SyuKiSpTukiITblFacade syuKiSpTukiITblFacade;
    
    @Inject
    private SyuKiSpTukiSTblFacade syuKiSpTukiSTblFacade;
    
    @Inject
    private SyuSaSpCurTitleTblFacade syuSaSpCurTitleTblFacade;
    
    @Inject
    private SyuSaSpCurTblFacade syuSaSpCurTblFacade;
    
    @Inject
    private SysdateEntityFacade sysdateEntityFacade;

    @Inject
    private StoredProceduresService storedProceduresService;

    @Inject
    private OperationLogService operationLogService;
    
    // 最終見込 登録対象データ区分を定義
    private final String[] targetSaDataKbnAry = {"SM"};
    
    /**
     * 初期表示時機能
     * @throws Exception
     */
    public void indexExecute() throws Exception {
        Map<String, Object> condition1 = new HashMap<>();
        condition1.put("ankenId", s012Bean.getAnkenId());
        condition1.put("rirekiId", s012Bean.getRirekiId());

        // 通貨の新規追加行数
        //int currencyNewCount = Integer.parseInt(Env.getValue(Env.Mikomi_New_CurrencyCode_Count));
        int currencyNewCount = Integer.parseInt(Env.Mikomi_New_CurrencyCode_Count.getValue());
        
        // GEテーブルから収益案件基本情報の取得
        SyuGeBukkenInfoTbl syuGeBukkenItem = syuGeBukenInfoTblFacade.findPk(condition1);
        String salesClass = StringUtils.defaultString(syuGeBukkenItem.getSalesClass());

        // 通貨リスト
        List<SyuCurMst> curMsgList = syuCurMstFacade.findAll();
        
        // 対象案件の登録されている通貨情報を取得
        Map<String, Object> conditionCurrency = new HashMap<>(condition1);
        conditionCurrency.put("dataKbn", ConstantString.finalDataKbn);
        conditionCurrency.put("syuekiYm", ConstantString.finalSyuekiYm);
        //List<SyuSaSpCurTitleTbl> currencyList;
        
        String dispKeiyakuRateFlg = "0";
        List<SyuSaSpCurCurrencyTbl> currencyList;
        if (ConstantString.salesClassS.equals(salesClass)) {
            // 進行(原価)基準案件の通貨情報一覧
            currencyList = syuSaSpCurTitleTblFacade.findShinkoAnkenCurrencyList(conditionCurrency);
            dispKeiyakuRateFlg = "1";
        } else {
            // 完成基準案件の通貨情報一覧
            currencyList = syuSaSpCurTitleTblFacade.findAnkenCurrencyList(conditionCurrency);
        }

        List<Map<String, Object>> rtnList = new ArrayList<>();
        //for (SyuKiJyuchuSpTbl jyuchuCurrency : currencyList) {
        //for (SyuSaSpCurTitleTbl currencyEntity : currencyList) {
        for (SyuSaSpCurCurrencyTbl currencyEntity : currencyList) {
            Map<String, Object> entity = new HashMap<>(PropertyUtils.describe(currencyEntity));

            entity.put("currencyLabel", currencyEntity.getCurrencyCode());
            for (SyuCurMst curMst : curMsgList) {
                if (curMst.getCurrencyCode().equals(currencyEntity.getCurrencyCode())) {
                    entity.put("currencyLabel", curMst.getCurrencyCode() + ":" + curMst.getDispName());
                    break;
                }
            }
            
            // 削除してはいけない場合、フラグを立てておく(画面でこのFLGをみて編集不可にしている)
            String noDeleteFlg;
            if (ConstantString.salesClassS.equals(salesClass)) {
                // 進行(原価)基準の場合 → 売上実績が登録済の通貨は削除できなようにする
                Map<String, Object> conditionJisseki = new HashMap<>(condition1);
                conditionJisseki.put("dataKbn", "J");
                conditionJisseki.put("currencyCode", currencyEntity.getCurrencyCode());

                int jissekiCount = syuKiSpTukiSTblFacade.getSyuKiSpTukiSTblCount(conditionJisseki);
//                int childAnkenCurrencyCount = 0;
//                if ("1".equals(syuGeBukkenItem.getAnkenFlg())) {
//                    // まとめ案件の場合、対象通貨を子案件に保持しているかをチェックする
//                    childAnkenCurrencyCount = syuKiSpCurTblFacade.countChildAnkenCurrency(s012Bean.getAnkenId(), s012Bean.getRirekiId(), currencyEntity.getCurrencyCode());
//                }

                // 対象通貨の実績が存在 or 子案件に通貨が存在する場合は削除不可
//                noDeleteFlg = (jissekiCount > 0 || childAnkenCurrencyCount > 0) ? "1" : "0";
                noDeleteFlg = (jissekiCount > 0) ? "1" : "0";

            }  else {
                // 完成基準案件の場合 → 受注通知実績が作成済の通貨は削除できないようにする。
                noDeleteFlg = (syuKiSpCurTblFacade.selectJyuchuRenbanCount(entity) > 0) ? "1" : "0";
            }
            entity.put("noDeleteFlg", noDeleteFlg);

            entity.put("createdFlg", "1");
            rtnList.add(entity);
        }

        // 新規登録用　○件分の空データを追加
        for (int i=0; i<currencyNewCount; i++) {
            //SyuKiJyuchuSpTbl newItem = new SyuKiJyuchuSpTbl();
            SyuSaSpCurTitleTbl newItem = new SyuSaSpCurTitleTbl();
            Map<String, Object> entity = PropertyUtils.describe(newItem);
            entity.put("createdFlg", "0");
            entity.put("noDeleteFlg", "1");   // 新規登録行データは削除不可としておく。
            rtnList.add(entity);
        }

        s012Bean.setListCurMst(curMsgList);
        s012Bean.setCurrencyList(rtnList);
        s012Bean.setDivisionCode(syuGeBukkenItem.getDivisionCode());
        s012Bean.setSalesClass(salesClass);
        s012Bean.setDispKeiyakuRateFlg(dispKeiyakuRateFlg);
    }

    /**
     * (最終見込関連)
     * 新規通貨を受注・売上の最終見込データとして新規登録
     * @param condition
     */
    private void createSaCurrencyData(final Map<String, Object> baseCondition) throws Exception {
        String currencyCode = StringUtils.defaultString((String)baseCondition.get("currencyCode"));

        Map<String, Object> condition = new HashMap<>(baseCondition);

        // 通貨の登録状態をチェック
        // 既に登録済みの場合は以後の処理を行う必要がないため、処理をスルーする。
        Integer currencyCount = syuSaSpCurTitleTblFacade.getCountCurrency(condition);
        if (currencyCount > 0) {
            return;
        }

        EntityUtils.setCreatedInfo(condition, loginUserInfo.getUserId());
        
        // SYU_SA_SP_CUR_TITLE_TBLの登録
        syuSaSpCurTitleTblFacade.insertSyuSaSpCurTitleTbl(condition);
        
        // SYU_SA_SP_CUR_TBLの登録(データ区分SM(当初見込)を登録しておく)
        if (ConstantString.currencyCodeEn.equals(currencyCode)) {
            // 日本円の場合はレート1を強制セット
            condition.put("keiyakuRate", (new BigDecimal(1)));
        }
        // 定義されているデータ区分分のレコードを登録
        for (String dataKbn: targetSaDataKbnAry) {
            condition.put("dataKbn", dataKbn);
            syuSaSpCurTblFacade.insertNotExistsSyuSaSpCurTbl(condition);
        }
    }

    /**
     * 通貨SEQを取得
     */
    private String getCurMstSeq(String currencyCode) {
        // 通貨マスタ情報を取得して、SEQを取得
        String currencyCodeSeq = null;
        SyuCurMst syuCurMst = syuCurMstFacade.findPk(currencyCode);
        if (syuCurMst != null) {
            currencyCodeSeq = syuCurMst.getDispSeq();
        }
        return currencyCodeSeq;
    }
    
    /**
     * (進行基準案件・期間損益関連)
     * 新規通貨を受注・売上の最終見込データとして新規登録
     * @param condition
     */
    private void createShinkoKiCurrencyData(final Map<String, Object> _condition) throws Exception {
        String renban = ConstantString.shinkoRenban;
        
        // 通貨登録チェック
        Map<String, Object> condition = new HashMap<>(_condition);
        condition.put("renban", renban);
        Integer currencyCount = syuKiSpCurTblFacade.countSyuKiSpCur(condition);
        if (currencyCount > 0) {
            return;
        }
        
        String currencyCode = StringUtils.defaultString((String)condition.get("currencyCode"));
        Date now = sysdateEntityFacade.getSysdate();
        String loginId = loginUserInfo.getUserId();

        // 通貨マスタ情報を取得して、SEQを取得
        String currencyCodeSeq = getCurMstSeq(currencyCode);

        // (売上)期間損益・売上高/契約金額・通貨詳細 を登録
        SyuKiSpCurTbl syuKiSpCurTblEntity = new SyuKiSpCurTbl();
        BeanUtils.populate(syuKiSpCurTblEntity, condition);
        syuKiSpCurTblEntity.setCurrencyCodeSeq(currencyCodeSeq);
        syuKiSpCurTblEntity.setRenban(renban);
        syuKiSpCurTblEntity.setKeiyaku_rate(ConstantString.currencyCodeEn.equals(currencyCode) ? (new BigDecimal(1)) : null);   // todo 外貨の契約レートをどうするか確認必要(売上開始or勘定月で設定されているレートでOK?)
        syuKiSpCurTblEntity.setCreatedAt(now);
        syuKiSpCurTblEntity.setCreatedBy(loginId);
        syuKiSpCurTblEntity.setUpdatedAt(now);
        syuKiSpCurTblEntity.setUpdatedBy(loginId);
        //syuKiSpCurTblFacade.create(syuKiSpCurTblEntity);
        syuKiSpCurTblFacade.edit(syuKiSpCurTblEntity);
        
        // (売上)期間損益・月別詳細(進行) を登録
        SyuKiSpTukiSTbl syuKiSpTukiSTblEntity = new SyuKiSpTukiSTbl();
        BeanUtils.populate(syuKiSpTukiSTblEntity, condition);
        syuKiSpTukiSTblEntity.setCreatedAt(now);
        syuKiSpTukiSTblEntity.setCreatedBy(loginId);
        syuKiSpTukiSTblEntity.setUpdatedAt(now);
        syuKiSpTukiSTblEntity.setUpdatedBy(loginId);
//        // 日本円の場合はレート1を強制セット
//        if (ConstantString.currencyCodeEn.equals(currencyCode)) {
//            syuKiSpTukiITblEntity.setUriRate(new BigDecimal(1));
//        }
        syuKiSpTukiSTblFacade.edit(syuKiSpTukiSTblEntity);
    }
    
    /**
     * (期間損益関連)
     * 新規通貨を受注・売上の最終見込データとして新規登録
     * @param condition
     */
    private void createKiCurrencyData(Map<String, Object> condition) throws Exception {
        String currencyCode = StringUtils.defaultString((String)condition.get("currencyCode"));
        Date now;
        String loginId;
        
        // 通貨の登録状態をチェック(最終見込：Fレコードを対象にチェック)
        // 既に登録済みの場合は以後の処理を行う必要がないため、処理をスルーする。
        Integer currencyCount = syuKiJyuchuSpTblFacade.getCountJyuchuSp(condition);
        if (currencyCount > 0) {
            return;
        }

        now = sysdateEntityFacade.getSysdate();
        loginId = loginUserInfo.getUserId();

        // (受注)受注管理・SP内訳を登録
        if (ConstantString.currencyCodeEn.equals(currencyCode)) {
            // 日本円の場合はレート1を強制セット
            condition.put("jyuchuRate", (new BigDecimal(1)));
        }
        syuKiJyuchuSpTblFacade.insertJyuchuSpRate(condition);

        // 通貨マスタ情報を取得して、SEQを取得
        String currencyCodeSeq = getCurMstSeq(currencyCode);
//        String currencyCodeSeq = null;
//        SyuCurMst syuCurMst = syuCurMstFacade.findPk(currencyCode);
//        if (syuCurMst != null) {
//            currencyCodeSeq = syuCurMst.getDispSeq();
//        }
        
        // (売上)期間損益・売上高/契約金額・通貨詳細 を登録
        SyuKiSpCurTbl syuKiSpCurTblEntity = new SyuKiSpCurTbl();
        BeanUtils.populate(syuKiSpCurTblEntity, condition);
        syuKiSpCurTblEntity.setCurrencyCodeSeq(currencyCodeSeq);
        syuKiSpCurTblEntity.setRenban(ConstantString.finalRenban);
        syuKiSpCurTblEntity.setRenbanSeq(new BigDecimal(ConstantString.finalRenbanSeq));
        syuKiSpCurTblEntity.setCreatedAt(now);
        syuKiSpCurTblEntity.setCreatedBy(loginId);
        syuKiSpCurTblEntity.setUpdatedAt(now);
        syuKiSpCurTblEntity.setUpdatedBy(loginId);
        //syuKiSpCurTblFacade.create(syuKiSpCurTblEntity);
        syuKiSpCurTblFacade.edit(syuKiSpCurTblEntity);
        
        // (売上)期間損益・月別詳細(一般) を登録
        SyuKiSpTukiITbl syuKiSpTukiITblEntity = new SyuKiSpTukiITbl();
        BeanUtils.populate(syuKiSpTukiITblEntity, condition);
        syuKiSpTukiITblEntity.setRenban(ConstantString.finalRenban);
        syuKiSpTukiITblEntity.setCreatedAt(now);
        syuKiSpTukiITblEntity.setCreatedBy(loginId);
        syuKiSpTukiITblEntity.setUpdatedAt(now);
        syuKiSpTukiITblEntity.setUpdatedBy(loginId);
        // 日本円の場合はレート1を強制セット
        if (ConstantString.currencyCodeEn.equals(currencyCode)) {
            syuKiSpTukiITblEntity.setUriRate(new BigDecimal(1));
        }
        //syuKiSpTukiITblFacade.create(syuKiSpTukiITblEntity);
        syuKiSpTukiITblFacade.edit(syuKiSpTukiITblEntity);
    }
    
    /**
     * 処理対象の案件を取得する(進行基準/原価回収基準の場合は対象案件にぶら下がる子案件も通貨登録の対象に含めるため)
     */
    private List<SyuGeBukkenInfoTbl> getTargetAnkenList(String salesClass) {
        List<SyuGeBukkenInfoTbl> targetAnkenList = new ArrayList();

        // 進行基準/原価回収基準の案件は子案件も処理対象とする。
        if (ConstantString.salesClassS.equals(salesClass)) {
            Map<String, Object> condition = new HashMap<>();
            condition.put("ankenId", s012Bean.getAnkenId());
            condition.put("rirekiId", s012Bean.getRirekiId());
            List<SyuGeBukkenInfoTbl> targetChildAnkenList = syuGeBukenInfoTblFacade.findChildAnken(condition);
            for (SyuGeBukkenInfoTbl childAnkenEntity: targetChildAnkenList) {
                targetAnkenList.add(childAnkenEntity);
            }
        }

        // 自案件は必ず処理対象とする
        SyuGeBukkenInfoTbl mainAnkenEntity = new SyuGeBukkenInfoTbl();
        mainAnkenEntity.setAnkenId(s012Bean.getAnkenId());
        targetAnkenList.add(mainAnkenEntity);

        return targetAnkenList;
    }
    
    /**
     * 登録・更新・削除
     * @throws Exception
     */
    public void updateExecute() throws Exception {
        Map<String, Object> baseCondition = new HashMap<>();
        baseCondition.put("ankenId", s012Bean.getAnkenId());
        baseCondition.put("rirekiId", s012Bean.getRirekiId());

        // GEテーブルから対象案件の売上基準を取得
        String salesClass = syuGeBukenInfoTblFacade.getSalesClass(s012Bean.getAnkenId(), s012Bean.getRirekiId());

        // 処理対象の案件を取得
        List<SyuGeBukkenInfoTbl> targetAnkenList = getTargetAnkenList(salesClass);

        // 対象の通貨1件1件毎に処理を行う。
        for (int i=0; i<s012Bean.getCurrencyCode().length; i++) {
            for (SyuGeBukkenInfoTbl ankenEntity: targetAnkenList) {
                // 案件IDをセット
                baseCondition.put("ankenId", ankenEntity.getAnkenId());
                
                // 最終見込系の通貨データを登録/更新/削除
                saveSaCurrencyInfo(baseCondition, i);

                ////// 期間損益関連テーブルの通貨の登録は、案件の売上基準で登録内容が異なるため、それぞれの売上基準で処理を分ける
                if (ConstantString.salesClassS.equals(salesClass)) {
                    ////// 進行(原価回収)基準案件の処理
                    saveShinkoKiCurrencyInfo(baseCondition, i);

                } else {
                    ////// 完成基準案件の処理
                    saveKiCurrencyInfo(baseCondition, i);
                }

                // 契約レートを登録(契約レートを表示している場合のみ実施)   ※進行 or 原価回収基準(GE.SALES_CLASS='1'の案件)のみこのロジックが通るようにしている
                if ("1".equals(s012Bean.getDispKeiyakuRateFlg())) {
                    if (StringUtils.isNotEmpty(s012Bean.getCurrencyCode()[i]) && "1".equals(s012Bean.getEditKeiyakuRateFlg()[i]) && !"1".equals(s012Bean.getDelFlg()[i])) {
                        em.flush();
                        saveKeiyakuRate(baseCondition, salesClass, i);
                    }
                }

            }
        }

        // 再計算処理(一般案件)パッケージをCall
        //  ※Step4 このパッケージの見直しが必要なのでは？
        //this.callAnken_I_Recal();

        // 操作ログの登録
        this.registOperationLog();
        
        // 再計算処理パッケージをCall
        for (SyuGeBukkenInfoTbl ankenEntity: targetAnkenList) {
            String ankenId = ankenEntity.getAnkenId();
            storedProceduresService.callAnkenRecalAuto(ankenId, s012Bean.getRirekiId(), "0");
        }
    }

    /**
     * 最終見込関連の通貨情報の追加/編集/削除
     */
    private void saveSaCurrencyInfo(final Map<String, Object> baseCondition, int index) throws Exception {
        String delFlg = s012Bean.getDelFlg()[index];
        String currencyCode = s012Bean.getCurrencyCode()[index];
        
        Map<String, Object> addCondition = new HashMap<>(baseCondition);
        addCondition.put("currencyCode", currencyCode);
        
        if ("1".equals(delFlg)) {
            // 削除データ
            deleteSaCurrencyData(addCondition);

        } else {
            // 通貨が選択されている場合(新規追加)
            if (StringUtils.isNotEmpty(currencyCode)) {
                // 新規登録データ(新規追加行で通貨を選択した場合)
                createSaCurrencyData(addCondition);
            }
        }

    }
    
    /**
     * (進行・原価基準案件用)期間損益関連の通貨情報の追加/編集/削除
     */
    private void saveShinkoKiCurrencyInfo(final Map<String, Object> baseCondition, int index) throws Exception {
        String delFlg = s012Bean.getDelFlg()[index];
        String currencyCode = s012Bean.getCurrencyCode()[index];

        Map<String, Object> addCondition = new HashMap<>(baseCondition);
        addCondition.put("currencyCode", currencyCode);
        
        if ("1".equals(delFlg)) {
            // 削除データ
            deleteShinkoKiCurrencyData(addCondition);

        } else {
            // 通貨が選択されている場合
            if (StringUtils.isNotEmpty(currencyCode)) {
                // 新規登録データ(新規追加行で通貨を選択した場合)
                addCondition.put("dataKbn", "G");
                addCondition.put("syuekiYm", "999900G");
                createShinkoKiCurrencyData(addCondition);
            }
        }
    }
    
    /**
     * 契約レートを保存する
     */
    private void saveKeiyakuRate(final Map<String, Object> baseCondition, String salesClass, int index) throws Exception {
        Map<String, Object> addCondition = new HashMap<>(baseCondition);
        addCondition.put("currencyCode", s012Bean.getCurrencyCode()[index]);
        addCondition.put("renban",  ConstantString.salesClassS.equals(salesClass) ? ConstantString.shinkoRenban : ConstantString.finalRenban);
        
        BigDecimal keiyakuRate = null;
        if (StringUtils.isNotEmpty(s012Bean.getKeiyakuRate()[index])) {
            keiyakuRate = NumberUtils.changeBigDecimal(s012Bean.getKeiyakuRate()[index]);
        }
        addCondition.put("keiyakuRate",  keiyakuRate);
        
        syuKiSpCurTblFacade.updateKeiyakuRate(addCondition);
    }

    /**
     * (完成基準案件用)期間損益関連の通貨情報の追加/編集/削除
     */
    private void saveKiCurrencyInfo(final Map<String, Object> baseCondition, int index) throws Exception {
        //String createdFlg = s012Bean.getCreatedFlg()[index];
        String delFlg = s012Bean.getDelFlg()[index];
        String currencyCode = s012Bean.getCurrencyCode()[index];

        Map<String, Object> addCondition = new HashMap<>(baseCondition);
        addCondition.put("currencyCode", currencyCode);
        
        if ("1".equals(delFlg)) {
            // 削除データ
            addCondition.put("renban", ConstantString.finalRenban);
            deleteKiCurrencyData(addCondition);

        } else {
            // 通貨が選択されている場合
            if (StringUtils.isNotEmpty(currencyCode)) {
                // 新規登録データ(新規追加行で通貨を選択した場合)
                addCondition.put("dataKbn", ConstantString.finalDataKbn);
                addCondition.put("syuekiYm", ConstantString.finalSyuekiYm);
                createKiCurrencyData(addCondition);
            }
        }
    }
    
    /**
     * (最終見込)通貨を削除
     * @param condition
     */
    private void deleteSaCurrencyData(Map<String, Object> condition) {
        // SYU_SA_SP_CUR_TITLE_TBLの削除
        syuSaSpCurTitleTblFacade.deleteSyuSaSpCurTitleTbl(condition);
        
        // SYU_SA_SP_CUR_TBLの削除
        syuSaSpCurTblFacade.deleteSyuSaSpCurTbl(condition);
    }

    /**
     *　進行(原価)基準案件・(期間損益)通貨を削除
     * @param condition
     */
    private void deleteShinkoKiCurrencyData(Map<String, Object> condition) {
        // (売上)期間損益・売上高/契約金額・通貨詳細 を削除
        syuKiSpCurTblFacade.deleteSyuKiSpCurTbl(condition);
        
        // (売上)SYU_KI_SP_TUKI_S_TBLの削除
        syuKiSpTukiSTblFacade.deleteSyuKiSpTukiSTbl(condition);
    }

    /**
     * 完成基準案件・(期間損益)通貨を削除
     * @param condition
     */
    private void deleteKiCurrencyData(Map<String, Object> condition) {
        // (受注)受注管理・SP内訳 を削除
        syuKiJyuchuSpTblFacade.deleteJyuchuSpRate(condition);

        // (売上)期間損益・売上高/契約金額・通貨詳細 を削除
        syuKiSpCurTblFacade.deleteSyuKiSpCurTbl(condition);
        
        // (売上)期間損益・月別詳細(一般) を削除
        syuKiSpTukiITblFacade.deleteSyuKiSpTukiITbl(condition);
    }

    /**
     * 再計算処理をcallする。
     */
//    private void callAnken_I_Recal() throws Exception {
//        AnkenRecalIDto dto = new AnkenRecalIDto();
//        dto.setAnkenId(s012Bean.getAnkenId());
//        dto.setRirekiId(Integer.parseInt(s012Bean.getRirekiId()));
//
//        storedProceduresService.callAnken_I_Recal(dto);
//        
//        if (!"0".equals(dto.getStatus())) {
//            throw new Exception("再計算処理[SYU_ANKEN_RECAL_I_MAIN]でエラーが発生しました。物件Key=" + s012Bean.getAnkenId());
//        }
//    }

    /**
     * 操作ログの登録
     * @throws Exception
     */
    public void registOperationLog() throws Exception{
        OperationLog operationLog = operationLogService.getOperationLog();

        String objectType = operationLogService.getObjectType(s012Bean.getProcId());
        
        operationLog.setOperationCode("ADD_MIKOMISP");
        operationLog.setObjectId(20);
        operationLog.setObjectType(objectType);
        operationLog.setRemarks(s012Bean.getAnkenId());

        operationLogService.insertOperationLogSearch(operationLog);
    }

}
