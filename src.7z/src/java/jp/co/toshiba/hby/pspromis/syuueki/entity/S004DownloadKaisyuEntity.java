/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package jp.co.toshiba.hby.pspromis.syuueki.entity;

import java.io.Serializable;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;

/**
 *
 * @author kitajima
 */
@Entity
public class S004DownloadKaisyuEntity implements Serializable {
    private static final long serialVersionUID = 1L;
    
    @Id
    @Column(name = "ANKEN_ID")
    private String ankenId;
    @Id
    @Column(name = "CURRENCY_CODE")
    private String currencyCode;
    @Id
    @Column(name = "ZEI")
    private String zei;
    @Id
    @Column(name = "ZEI_KBN")
    private String zeiKbn;
    //@Id
    //@Column(name = "KINSYU")
    //private String kinsyu;
    @Id
    @Column(name = "KINSYU_KBN")
    private String kinsyuKbn;
    //@Id
    //@Column(name = "KAISYU")
    //private String kaisyu;
    @Id
    @Column(name = "KAISYU_KBN")
    private String kaisyuKbn;
    @Id
    @Column(name = "KBN")
    private String kbn;
    @Column(name = "RNK")
    private String rnk;


    public void setAnkenId(String ankenId) {
        this.ankenId = ankenId;
    }

    public String getAnkenId() {
        return ankenId;
    }
    
    public void setCurrencyCode(String currencyCode) {
        this.currencyCode = currencyCode;
    }

    public String getCurrencyCode() {
        return currencyCode;
    }

    public String getZei() {
        return zei;
    }

    public void setZei(String zei) {
        this.zei = zei;
    }

    public String getZeiKbn() {
        return zeiKbn;
    }

    public void setZeiKbn(String zeiKbn) {
        this.zeiKbn = zeiKbn;
    }

    public String getKinsyuKbn() {
        return kinsyuKbn;
    }

    public void setKinsyuKbn(String kinsyuKbn) {
        this.kinsyuKbn = kinsyuKbn;
    }

    public String getKaisyuKbn() {
        return kaisyuKbn;
    }

    public void setKaisyuKbn(String kaisyuKbn) {
        this.kaisyuKbn = kaisyuKbn;
    }

//    public String getKinsyu() {
//        return kinsyu;
//    }
//
//    public void setKinsyu(String kinsyu) {
//        this.kinsyu = kinsyu;
//    }
//
//    public String getKaisyu() {
//        return kaisyu;
//    }
//
//    public void setKaisyu(String kaisyu) {
//        this.kaisyu = kaisyu;
//    }
    
    public String getKbn() {
        return kbn;
    }

    public void setKbn(String kbn) {
        this.kbn = kbn;
    }

    public String getRnk() {
        return rnk;
    }

    public void setRnk(String rnk) {
        this.rnk = rnk;
    }
    
}
