package jp.co.toshiba.hby.pspromis.syuueki.bean;

import java.io.Serializable;
import java.util.List;
import javax.enterprise.context.SessionScoped;
import javax.inject.Named;
import jp.co.toshiba.hby.pspromis.syuueki.entity.BuMst;
import jp.co.toshiba.hby.pspromis.syuueki.entity.M0130BunruiOrg;
import jp.co.toshiba.hby.pspromis.syuueki.entity.PlantTypeMst;
/**
 *
 * @author sano
 */
@Named(value = "s009MstBean")
@SessionScoped
public class S009MstBean extends AbstractBean implements Serializable {

    /**
     * BUマスタ
     */
    private List<BuMst> buMstList;
    /**
     * サイトマスタ
     */
    private List<PlantTypeMst> plantTypeList;
    /**
     * 収益分類マスタ
     */
    private List<M0130BunruiOrg> bunruiList;

    /**
     * Creates a new instance of S009MstBean
     */
    public S009MstBean() {
    }

    public List<BuMst> getBuMstList() {
        return buMstList;
    }

    public void setBuMstList(List<BuMst> buMstList) {
        this.buMstList = buMstList;
    }

    public List<PlantTypeMst> getPlantTypeList() {
        return plantTypeList;
    }

    public void setPlantTypeList(List<PlantTypeMst> plantTypeList) {
        this.plantTypeList = plantTypeList;
    }

    public List<M0130BunruiOrg> getBunruiList() {
        return bunruiList;
    }

    public void setBunruiList(List<M0130BunruiOrg> bunruiList) {
        this.bunruiList = bunruiList;
    }
}
