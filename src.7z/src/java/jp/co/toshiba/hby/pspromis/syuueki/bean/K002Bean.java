package jp.co.toshiba.hby.pspromis.syuueki.bean;

import java.util.List;
import javax.enterprise.context.RequestScoped;
import javax.inject.Named;
import jp.co.toshiba.hby.pspromis.syuueki.entity.Es88051Tbl;

/**
 *
 * @author horie
 */
@Named(value = "k002Bean")
@RequestScoped
public class K002Bean {
    /**
     * 一覧検索フラグ
     */
    private String listFlg = "0";

    /**
     * 設置先一覧データ
     */
    private List<Es88051Tbl> stchList;

    /**
     * 検索条件：事業部・電力社
     */
    private String divDen;

    /**
     * 検索条件：事業部・原子力
     */
    private String divGen;

    /**
     * 検索条件：事業部・火水ジ
     */
    private String divKa;

    /**
     * 検索条件・設置場所名称
     */
    private String stchName;
    
    /**
     * 検索条件・設置場所コード
     */
    private String stchCode;
    
    /**
     * 検索結果・検索件数
     */
    private Integer count;
 
    /**
     * 現在表示するページ番号
     */
    private Integer page;

    public List<Es88051Tbl> getStchList() {
        return stchList;
    }
    
    public void setStchList(List<Es88051Tbl> stchList) {
        this.stchList = stchList;
    }

    public Integer getCount() {
        return count;
    }

    public void setCount(Integer count) {
        this.count = count;
    }

    public Integer getPage() {
        return page;
    }

    public void setPage(Integer page) {
        this.page = page;
    }

    public String getListFlg() {
        return listFlg;
    }

    public void setListFlg(String listFlg) {
        this.listFlg = listFlg;
    }

    public String getDivDen() {
        return divDen;
    }

    public void setDivDen(String divDen) {
        this.divDen = divDen;
    }

    public String getDivGen() {
        return divGen;
    }

    public void setDivGen(String divGen) {
        this.divGen = divGen;
    }

    public String getDivKa() {
        return divKa;
    }

    public void setDivKa(String divKa) {
        this.divKa = divKa;
    }

    public String getStchName() {
        return stchName;
    }

    public void setStchName(String stchName) {
        this.stchName = stchName;
    }

    public String getStchCode() {
        return stchCode;
    }

    public void setStchCode(String stchCode) {
        this.stchCode = stchCode;
    }

}
