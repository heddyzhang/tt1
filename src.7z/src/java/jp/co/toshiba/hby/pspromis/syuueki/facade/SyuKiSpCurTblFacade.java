package jp.co.toshiba.hby.pspromis.syuueki.facade;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.interceptor.Interceptors;
import javax.ejb.Stateless;
import javax.inject.Inject;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import jp.co.toshiba.hby.pspromis.syuueki.entity.SyuKiSpCurTbl;
import jp.co.toshiba.hby.pspromis.syuueki.interceptor.TranceInterceptor;
import jp.co.toshiba.hby.pspromis.syuueki.util.LoginUserInfo;
import jp.co.toshiba.hby.pspromis.syuueki.entity.StringEntity;
import org.apache.commons.collections.CollectionUtils;

/**
 *
 * @author ibayashi
 */
@Stateless
@Interceptors({TranceInterceptor.class})
public class SyuKiSpCurTblFacade extends AbstractFacade<SyuKiSpCurTbl> {
    @PersistenceContext(unitName = jp.co.toshiba.hby.pspromis.syuueki.util.ConstantString.syuuekiDataSourceName)
    private EntityManager em;

    @Override
    protected EntityManager getEntityManager() {
        return em;
    }

    public SyuKiSpCurTblFacade() {
        super(SyuKiSpCurTbl.class);
    }

    @Inject
    private LoginUserInfo loginUserInfo;
    
    /**
     * パラメータにログイン者idをセット
     */
    private Map<String, Object> addParamLoginId(Map<String, Object> _params) {
        Map<String, Object> ret = _params;
        if (ret == null) {
            ret = new HashMap<>();
        }
        ret.put("userId", loginUserInfo.getUserId());
        return ret;
    }
    
    /**
     * 期間損益・売上高/契約金額・通貨詳細 検索
     * @param condition
     * @return 
     */
    public List<SyuKiSpCurTbl> selectSyuKiSpCur(Object condition) {
        List<SyuKiSpCurTbl> syuKiSpCurTbl = sqlExecutor.getResultList(em, SyuKiSpCurTbl.class, "/sql/syuKiSpCurTbl/selectSyuKiSpCurTbl.sql", condition);
        return syuKiSpCurTbl;
    }
    
    /**
     * 期間損益・売上高/契約金額・通貨詳細 件数の取得
     * @param condition
     * @return 
     */
    public int countSyuKiSpCur(Object condition) {
        int count = sqlExecutor.getCount(em, "/sql/syuKiSpCurTbl/selectCountSyuKiSpCurTbl.sql", condition);
        return count;
    }
    
    /**
     * 期間損益・売上高/契約金額・通貨詳細(受注通知が発行されているデータ件数) 検索
     * @param _params
     * @return 
     */
    public int selectJyuchuRenbanCount(Map<String, Object> _params) {
        int count = sqlExecutor.getCount(em, "/sql/syuKiSpCurTbl/selectJyuchuTutiRenbanCount.sql", _params);
        return count;
    }
    
    /**
     * 期間損益・売上高/契約金額・通貨詳細 削除
     * @param _params
     * @return 
     */
    public int deleteSyuKiSpCurTbl(Map<String, Object> _params) {
        int count= sqlExecutor.executeUpdateSql(em, "/sql/syuKiSpCurTbl/deleteSyuKiSpCurTbl.sql", _params);
        return count;
    }

    /**
     * 期間損益・売上高/契約金額・通貨詳細(新規登録)
     * @param _params
     * @return 
     */
    public int insertSyuKiSpCurTbl(Map<String, Object> _params) {
        Map<String, Object> params = addParamLoginId(_params);
        int count = sqlExecutor.executeUpdateSql(em, "/sql/syuKiSpCurTbl/insertSyuKiSpCurTbl.sql", params);
        return count;
    }

    /**
     * 期間損益・売上高/契約金額・通貨詳細(新規登録)
     * @param _params
     * @return 
     */
    public int updateKeiyakuRate(Map<String, Object> _params) {
        Map<String, Object> params = addParamLoginId(_params);
        int count = sqlExecutor.executeUpdateSql(em, "/sql/syuKiSpCurTbl/updateKeiyakuRate.sql", params);
        return count;
    }

    /**
     * 子案件の通貨件数を取得
     * @param ankenId
     * @param rirekiId
     * @param currencyCode
     * @return 
     */
    public int countChildAnkenCurrency(String ankenId, String rirekiId, String currencyCode) {
        Map<String, Object> condition = new HashMap<>();
        condition.put("ankenId", ankenId);
        condition.put("rirekiId", Integer.parseInt(rirekiId));
        condition.put("currencyCode", currencyCode);
        int count = sqlExecutor.getCount(em, "/sql/syuKiSpCurTbl/countCurrencyChildAnken.sql", condition);
        return count;
    }

    /**
     * 期間損益・売上高/契約金額・通貨詳細(新規登録判定)
     * @param _params
     * @return 
     */
    public int entrySyuKiSpCur(Map<String, Object> _params) {
        int count;

        // 検索
        count = this.countSyuKiSpCur(_params);
        // 既存データ存在しない場合は新規登録
        if (count == 0) {
            count = this.insertSyuKiSpCurTbl(_params);
        }

        return count;
    }
    
    /**
     * 指定案件の通貨コード(マルチ通貨の場合はCURRENCY_CODE_SEQが一番若いもの)を取得
     * @param _params
     * @return 
     */
    public String selectCurrencyCode(Map<String, Object> _params) {
        List<StringEntity> list = sqlExecutor.getResultList(em, StringEntity.class, "/sql/syuKiSpCurTbl/selectCurrencyCode.sql", _params);
        
        if (CollectionUtils.isNotEmpty(list)) {
            return list.get(0).getString().trim();
        } else {
            return "";
        }
    }

}
