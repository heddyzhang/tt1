package jp.co.toshiba.hby.pspromis.syuueki.servlet;

import java.io.File;
import java.io.PrintWriter;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.inject.Inject;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpServletRequest;
import jp.co.toshiba.hby.pspromis.syuueki.bean.ResultMessageBean;
import jp.co.toshiba.hby.pspromis.syuueki.bean.S005Bean;
import jp.co.toshiba.hby.pspromis.syuueki.bean.S005MstBean;
import jp.co.toshiba.hby.pspromis.syuueki.bean.ValidationInfoBean;
import jp.co.toshiba.hby.pspromis.syuueki.facade.SysdateEntityFacade;
import jp.co.toshiba.hby.pspromis.syuueki.service.S005Service;
import jp.co.toshiba.hby.pspromis.syuueki.service.download.KobanListService;
import jp.co.toshiba.hby.pspromis.syuueki.util.CdiUtils;
import jp.co.toshiba.hby.pspromis.syuueki.util.DetailExcelUtils;
import jp.co.toshiba.hby.pspromis.syuueki.util.FileUtils;
import jp.co.toshiba.hby.pspromis.syuueki.util.ParameterBinder;
import jp.co.toshiba.hby.pspromis.syuueki.util.PoiUtil;
import org.apache.poi.ss.usermodel.Workbook;

/**
 * PS-Promis収益管理システム
 * 項番一覧 Servlet
 * @author (NPC)T.Wakamatsu
 */
@WebServlet(name="S005", urlPatterns={"/servlet/S005", "/servlet/S005/*"})
public class S005Servlet extends AbstractServlet {

    /**
     * jsp
     */
    private static final String INDEX_JSP = "S005/s005.jsp";

    /**
     * 使用serviceクラスをinjection(CDI)<br>
     * InjectアノテーションよりAPサーバー(Glassfish)側で自動的にインスタンス作成(new)される。<br>
     * service側はステートレスセッションbeanにするため、Statelessアノテーションをつけておくこと。<br>
     */
    @Inject
    private S005Service s005Service;

    /**
     * パラメータ格納クラスをinjection(CDI)<br>
     * InjectアノテーションよりAPサーバー(Glassfish)側で自動的にインスタンス作成(new)される。<br>
     */
    @Inject
    private S005Bean s005Bean;

    @Inject
    private S005MstBean s005MstBean;

    @Inject
    private SysdateEntityFacade sysdateFacade;

    @Inject
    private ValidationInfoBean validationInfoBean;

    @Inject
    private KobanListService kobanListService;

    /**
     * 初期表示
     * @param req
     * @param resp
     * @return
     * @throws Exception
     */
    public String indexAction(HttpServletRequest req, HttpServletResponse resp)
    throws Exception {
        logger.info("S005Servlet#indexAction");

        // リクエストパラメータをs005Beanの同名フィールドに一括コピー
        ParameterBinder.Bind(s005Bean, req);

        // 一覧検索状態をクリアしておく。
        s005Bean.setListFlg("0");

        // サービスの実行(トランザクション単位)
        s005Service.indexExecute();

        return INDEX_JSP;
    }

    /**
     * 検索条件・部課の選択リストを取得
     * @param req
     * @param resp
     * @return
     * @throws Exception
     */
    public String selectBukaAction(HttpServletRequest req, HttpServletResponse resp)
    throws Exception {
        logger.info("S005Servlet#selectBukaAction");

        // リクエストパラメータをs005Beanの同名フィールドに一括コピー
        ParameterBinder.Bind(s005Bean, req);

        // サービスの実行
        s005Service.selectBukaList();

        // 結果セットをjson出力
        Map<String, Object> jsonMap = new HashMap<>();
        jsonMap.put("sekkeiBukaList", s005MstBean.getSekkeiBukaList());
        jsonMap.put("kojoBukaList", s005MstBean.getKojoBukaList());
        resopnseDecodeJson(resp, jsonMap);

        return null;
    }

    /**
     * 一覧データ取得
     * @param req
     * @param resp
     * @return
     * @throws Exception
     */
    public String listAction(HttpServletRequest req, HttpServletResponse resp)
    throws Exception {
        logger.info("S005Servlet#listAction");

        // リクエストパラメータをs005Beanの同名フィールドに一括コピー
        ParameterBinder.Bind(s005Bean, req);

        // 必要あらばリクエストパラメータのバリデーションチェックを入れる予定
        // (Beans Validation(＋独自バリデーション))

        // サービスの実行(トランザクション単位)
        // ※バリデーションチェックに通った場合のみサービス実行。
        s005Service.listExecute();

        // jspをforward
        return INDEX_JSP;
    }

    /**
     * csv出力
     * @param req
     * @param resp
     * @return
     * @throws Exception
     */
//    public String outputCsvAction(HttpServletRequest req, HttpServletResponse resp)
//    throws Exception {
//        logger.info("S001Servlet#outputCsvAction");
//
//        // リクエストパラメータをs005Beanの同名フィールドに一括コピー
//        ParameterBinder.Bind(s005Bean, req);
//
//        // resopnse header設定
//        setDownloadCsvHeader(resp, "項番一覧(期間)_" + (new SimpleDateFormat("yyyyMMddHHmm")).format(new Date()) + ".csv");
//
//        // csv出力
//        PrintWriter writer = resp.getWriter();
//        s005Service.csvExecute(writer);
//
//        writer.flush();
//
//        // jspは出力しないのでnull
//        return null;
//    }


    /**
     * excel出力
     * @param req
     * @param resp
     * @return
     * @throws Exception
     */
    public String outputExcelAction(HttpServletRequest req, HttpServletResponse resp)
    throws Exception {
        logger.info("S005Servlet#outputExcelAction");

        // リクエストパラメータをs005Beanの同名フィールドに一括コピー
        ParameterBinder.Bind(s005Bean, req);

        Date now = sysdateFacade.getSysdate();
        SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMddHHmm");

        // テンプレートファイルの読み込み
        String filePath = req.getServletContext().getRealPath("WEB-INF/template/ankenDetail_template.xlsx");
        Workbook workbook = PoiUtil.getWorkbook(new File(filePath));

        // 上記で読み込みしたテンプレートファイルは案件の詳細全般で利用しているものなので、
        // 不要なシートを全て削除する(最終見込損益で利用するシート以外を全て削除)
        DetailExcelUtils.leaveDetailSheet(workbook, "koban");

        // テンプレートにデータ埋め込み
        kobanListService.outputDownloadExcel(workbook);

        // テンプレート出力
        // (暫定)ファイル名「[案件番号]_項番一覧(期間)_[YYYYMMDDHH24MI].xlsx」
        FileUtils.httpDownloadExcelResponse(workbook, s005Bean.getAnkenId() + "_項番一覧_" + sdf.format(now) + ".xlsx", resp);

        return null;
    }

    /**
     * 一覧データ取得
     * @param req
     * @param resp
     * @return
     * @throws Exception
     */
    public String saveAction(HttpServletRequest req, HttpServletResponse resp)
    throws Exception {
        logger.info("S005Servlet#saveAction");

        // リクエストパラメータをs005Beanの同名フィールドに一括コピー
        ParameterBinder.Bind(s005Bean, req);

        // 必要あらばリクエストパラメータのバリデーションチェックを入れる予定
        // バリデーションチェック
        if (!s005Service.validationExecute(validationInfoBean)) {
            // 入力エラーが存在する場合はエラー情報を返す
            resopnseDecodeJson(resp, validationInfoBean.getMessages());
        } else {
            // サービスの実行(トランザクション単位)
            s005Service.saveExecute(0);

            // 処理結果を戻す。
            Map<String, Object> jsonMap = new HashMap<>();
            ResultMessageBean resultMessageBean = CdiUtils.getBean(ResultMessageBean.class);
            resultMessageBean.createResultMessage(jsonMap);
            resopnseDecodeJson(resp, jsonMap);
        }

        // jspをforward
        return null;
    }

    /**
     * 一覧データ取得
     * @param req
     * @param resp
     * @return
     * @throws Exception
     */
    public String deleteAction(HttpServletRequest req, HttpServletResponse resp)
    throws Exception {
        logger.info("S005Servlet#deleteAction");

        // リクエストパラメータをs005Beanの同名フィールドに一括コピー
        ParameterBinder.Bind(s005Bean, req);

        // 必要あらばリクエストパラメータのバリデーションチェックを入れる予定
        // (Beans Validation(＋独自バリデーション))

        // サービスの実行(トランザクション単位)
        s005Service.deleteExecute();

        // 処理結果を戻す。
        Map<String, Object> jsonMap = new HashMap<>();
        ResultMessageBean resultMessageBean = CdiUtils.getBean(ResultMessageBean.class);
        resultMessageBean.createResultMessage(jsonMap);
        resopnseDecodeJson(resp, jsonMap);

        // jspをforward
        return null;
    }

    /**
     * 最新値更新
     */
    public String updateNewDataAction(HttpServletRequest req, HttpServletResponse resp)
    throws Exception {
        logger.info("S005Servlet#updateNewDataAction");

        ParameterBinder.Bind(s005Bean, req);

        if ("1".equals(s005Bean.getEditFlg())) {
            // 更新モードの場合は画面の値も更新する
            s005Service.saveExecute(1);
        } else {
            // 参照モード
            s005Service.reCalc(1);
        }

        // 処理結果を戻す。
        Map<String, Object> jsonMap = new HashMap<>();
        ResultMessageBean resultMessageBean = CdiUtils.getBean(ResultMessageBean.class);
        resultMessageBean.createResultMessage(jsonMap);
        resopnseDecodeJson(resp, jsonMap);

        return null;
    }
    /**
     * 項番のチェック
     * @param req
     * @param resp
     * @return
     * @throws Exception
     */
    public String checkOederItemAction(HttpServletRequest req, HttpServletResponse resp)
    throws Exception {
        logger.info("S005Servlet#selectBukaAction");

        // リクエストパラメータをs005Beanの同名フィールドに一括コピー
        ParameterBinder.Bind(s005Bean, req);

        // サービスの実行
        s005Service.selectBukaList();

        // 結果セットをjson出力
        Map<String, Object> jsonMap = new HashMap<>();
        jsonMap.put("sekkeiBukaList", s005MstBean.getSekkeiBukaList());

        resopnseDecodeJson(resp, jsonMap);

        return null;
    }

    /**
     * 2017/12/07 #013 #023 ADD 項番最終見込設定
     * 項番最終見込設定
     * @param req
     * @param resp
     * @return
     * @throws Exception
     */
    public String mikokmiSetAction(HttpServletRequest req, HttpServletResponse resp)
    throws Exception {
        logger.info("S005Servlet#mikokmiSetAction");

        // リクエストパラメータをs005Beanの同名フィールドに一括コピー
        ParameterBinder.Bind(s005Bean, req);

// 必要あらばリクエストパラメータのバリデーションチェックを入れる予定
//        // バリデーションチェック
//        if (!s005Service.validationExecute(validationInfoBean)) {
//            // 入力エラーが存在する場合はエラー情報を返す
//            resopnseDecodeJson(resp, validationInfoBean.getMessages());
//        } else {
//            // EXECUTE
//        }

        // サービスの実行(トランザクション単位)
        s005Service.mikokmiSetExecute(0);

        // 処理結果を戻す。
        Map<String, Object> jsonMap = new HashMap<>();
        ResultMessageBean resultMessageBean = CdiUtils.getBean(ResultMessageBean.class);
        resultMessageBean.createResultMessage(jsonMap);
        resopnseDecodeJson(resp, jsonMap);

        // jspをforward
        return null;
    }

    /**
     * 2017/12/07 #013 #023 ADD 項番最終見込設定
     * 項番最終見込設定
     * @param req
     * @param resp
     * @return
     * @throws Exception
     */
    public String mikokmiSetAllAction(HttpServletRequest req, HttpServletResponse resp)
    throws Exception {
        logger.info("S005Servlet#mikokmiSetAction");

        // リクエストパラメータをs005Beanの同名フィールドに一括コピー
        ParameterBinder.Bind(s005Bean, req);

// 必要あらばリクエストパラメータのバリデーションチェックを入れる予定
//        // バリデーションチェック
//        if (!s005Service.validationExecute(validationInfoBean)) {
//            // 入力エラーが存在する場合はエラー情報を返す
//            resopnseDecodeJson(resp, validationInfoBean.getMessages());
//        } else {
//            // EXECUTE
//        }

        // サービスの実行(トランザクション単位)
        s005Service.mikokmiSetExecute(1);

        // 処理結果を戻す。
        Map<String, Object> jsonMap = new HashMap<>();
        ResultMessageBean resultMessageBean = CdiUtils.getBean(ResultMessageBean.class);
        resultMessageBean.createResultMessage(jsonMap);
        resopnseDecodeJson(resp, jsonMap);

        // jspをforward
        return null;
    }
}
