package jp.co.toshiba.hby.pspromis.syuueki.service;

import java.math.BigDecimal;
import java.sql.SQLException;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.ejb.Stateless;
import javax.inject.Inject;
import javax.interceptor.Interceptors;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
//import jp.co.toshiba.hby.pspromis.common.util.CollectionUtil;
//import jp.co.toshiba.hby.pspromis.common.util.StringUtil;
import jp.co.toshiba.hby.pspromis.syuueki.bean.AggregateConditionBean;
import jp.co.toshiba.hby.pspromis.syuueki.bean.S001MstBean;
import jp.co.toshiba.hby.pspromis.syuueki.bean.S023Bean;
import jp.co.toshiba.hby.pspromis.syuueki.entity.BuMst;
import jp.co.toshiba.hby.pspromis.syuueki.entity.TeamEntity;
import jp.co.toshiba.hby.pspromis.syuueki.facade.KanjyoMstFacade;
import jp.co.toshiba.hby.pspromis.syuueki.facade.M0130LineEigJobgrFacade;
import jp.co.toshiba.hby.pspromis.syuueki.facade.SyuWfControlTblFacade;
import jp.co.toshiba.hby.pspromis.syuueki.facade.BuMstFacade;
import jp.co.toshiba.hby.pspromis.syuueki.interceptor.TranceInterceptor;
import jp.co.toshiba.hby.pspromis.syuueki.jdbc.DbUtilsExecutor;
import jp.co.toshiba.hby.pspromis.syuueki.jdbc.SqlFile;
import jp.co.toshiba.hby.pspromis.syuueki.pages.DetailHeader;
import jp.co.toshiba.hby.pspromis.syuueki.pages.DivisonComponentPage;
import jp.co.toshiba.hby.pspromis.syuueki.util.DateUtils;
import jp.co.toshiba.hby.pspromis.syuueki.util.LoginUserInfo;
import jp.co.toshiba.hby.pspromis.syuueki.util.SyuuekiUtils;
import jp.co.toshiba.hby.pspromis.syuueki.util.Utils;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 *
 * @author rnomura
 */
@Stateless
@Interceptors({TranceInterceptor.class})
public class S023Service {
    /**
     * ロガー
     */
    public static final Logger logger = LoggerFactory.getLogger(S023Service.class);
    
    @PersistenceContext(unitName = jp.co.toshiba.hby.pspromis.syuueki.util.ConstantString.syuuekiDataSourceName)
    private EntityManager em;

    @Inject
    private S023Bean s023Bean;
    
    @Inject
    private AggregateConditionBean aggregateConditionBean;
    /**
     * Injection loginUserInfo
     * (ユーザー情報(ユーザーid,名称,所属部課名)を格納したオブジェクト)
     */
    @Inject
    private LoginUserInfo loginUserInfo;
    /**
     * Injection DetailHeader
     */
    @Inject
    private DetailHeader dateilHeader;
    
    @Inject
    private KanjyoMstFacade kanjyoMstFacade;
    
    @Inject
    private BuMstFacade buMstFacade;

    @Inject
    private S001MstBean s001MstBean;
    
    @Inject
    private M0130LineEigJobgrFacade m0130LineEigJobgrFacade;

    /**
     * Injection OperationLogService
     */
    @Inject
    private OperationLogService operationLogService;
    @Inject
    private SyuWfControlTblFacade syuWfControlTblFacade;
    
    @Inject
    private SyuuekiUtils sUtils;
    
    @Inject
    private DateUtils dUtils;
    
    @Inject
    private Utils utils;
    
    @Inject
    private DbUtilsExecutor dbUtilsExecutor;
    
    @Inject
    private DivisonComponentPage divisionComponentPage;
    
    /**
     * 画面表示　ビジネスロジック
     * @throws Exception 
     */
    public void indexExecute() throws Exception {
        logger.info("S023Service#indexExecute");
        
    }
    
    /**
     * 一覧検索処理
     */
    public void listExecute() throws Exception {
        logger.info("S023Service#listExecute");
        
        // 検索結果の取得
        getSearchResult();
        
        s023Bean.setListFlg("1");
    }
    

    
    /**
     * 「差」行用のデータリスト作成処理
     * @param aggList
     * @return 
     */
    private List<Map<String, Object>> makeDataList(List<Map<String, Object>> aggList, String rirekiId){
        List<Map<String, Object>> list = new ArrayList<>();
        String jsKey = "J_SP_";
        String jnKey = "J_NET_";
        String usKey = "U_SP_";
        String unKey = "U_NET_";
        String ksKey = "K_SP_";
        
        for(Map<String, Object> map : aggList){
            // 総計行は処理を行わない
            if(map.get("TOTAL_KBN").equals(BigDecimal.ZERO)){
                list.add(map);
                continue;
            }
            
            int num = 0;
            for(Map<String, Object> yoko: aggregateConditionBean.getYokozikuList()){
                BigDecimal nowSpVal = (BigDecimal) map.get(jsKey + "NOW" + num);
                BigDecimal befSpVal = (BigDecimal) map.get(jsKey + "BEF" + num);
                BigDecimal difSpVal = sUtils.arari(nowSpVal, befSpVal);
                map.put(jsKey + "DIF" + num, difSpVal);
                
                nowSpVal = (BigDecimal) map.get(usKey + "NOW" + num);
                befSpVal = (BigDecimal) map.get(usKey + "BEF" + num);
                difSpVal = sUtils.arari(nowSpVal, befSpVal);
                map.put(usKey + "DIF" + num, difSpVal);
                
                nowSpVal = (BigDecimal) map.get(ksKey + "NOW" + num);
                befSpVal = (BigDecimal) map.get(ksKey + "BEF" + num);
                difSpVal = sUtils.arari(nowSpVal, befSpVal);
                map.put(ksKey + "DIF" + num, difSpVal);
                
                BigDecimal nowNetVal = (BigDecimal) map.get(jnKey + "NOW" + num);
                BigDecimal befNetVal = (BigDecimal) map.get(jnKey + "BEF" + num);
                BigDecimal difNetVal = sUtils.arari(nowNetVal, befNetVal);
                map.put(jnKey + "DIF" + num, difNetVal);
                
                nowNetVal = (BigDecimal) map.get(unKey + "NOW" + num);
                befNetVal = (BigDecimal) map.get(unKey + "BEF" + num);
                difNetVal = sUtils.arari(nowNetVal, befNetVal);
                map.put(unKey + "DIF" + num, difNetVal);
                
                num++;
            }
            
            list.add(map);
        }
        
        return list;
    }
    
    /**
     * 検索結果の取得
     * @throws SQLException 
     */
//    public void getSearchResult() throws SQLException{
//        // ページ切り替えか否かを判定
//        if (s023Bean.getPage() == null || s023Bean.getPage() <= 0) {
//            s023Bean.setPage(1);
//        }
//
//        // 案件リスト取得SQL実行
//        List<Map<String, Object>> list = getAggregateData("0");
//        
//        if(aggregateConditionBean.getComparison().equals("G") || aggregateConditionBean.getComparison().equals("Y")){
//            // 「差」行用のデータリスト作成
//            list = makeDataList(list);
//        }
//        
//        // 画面表示用集計キーセット
//        setHeadData(list);
//        
//        s023Bean.setAggregateList(list);
//
//        // 総計データ取得SQL実行
//        list = getAggregateData("1");
//        
//        BigDecimal count = Utils.changeBigDecimal(list.get(0).get("COUNT"));
//        s023Bean.setCount(count.intValue());
//        s023Bean.setSummaryList(list);
//    }
    
    public void getSearchResult() throws SQLException{
        // ページ切り替えか否かを判定
        if (s023Bean.getPage() == null || s023Bean.getPage() <= 0) {
            s023Bean.setPage(1);
        }

        // 案件リスト取得SQL実行
        List<Map<String, Object>> list = getAggregateData("0");
        
        if(aggregateConditionBean.getComparison().equals("G") || aggregateConditionBean.getComparison().equals("Y")){
            // 「差」行用のデータリスト作成
            list = makeDataList(list);
        }
        
        // 画面表示用集計キーセット
        setHeadData(list);
        
        s023Bean.setAggregateList(list);

        // 総計データ取得SQL実行
        //list = getAggregateData("1");
        
        if (CollectionUtils.isNotEmpty(list)) {
            // 総件数を取得
            BigDecimal allDataCount = Utils.changeBigDecimal(list.get(0).get("ALL_ANKEN_COUNT"));
            s023Bean.setCount(allDataCount.intValue());
            
            // 総件数行を設定
            List<Map<String, Object>> summaryList = new ArrayList<>();
            Map<String, Object> totalInfo = list.get(0);
            summaryList.add(totalInfo);
            s023Bean.setSummaryList(summaryList);
        }
    }
    
    /**
     * 確定月より履歴ID取得処理
     * @return 
     */
    public String getRirekiId(){
        String rirekiId = "";
        if(aggregateConditionBean.getComparison().equals("G") || aggregateConditionBean.getComparison().equals("Y")){
            Map<String, Object> param = new HashMap<>();
            param.put("divisionCode", aggregateConditionBean.getDivisionCode());
            if (aggregateConditionBean.getSalesClass() != null) {
                param.put("salesClass", Arrays.asList(aggregateConditionBean.getSalesClass()));
            }
            if(aggregateConditionBean.getComparison().equals("G")) {
                param.put("taishoYm", aggregateConditionBean.getComparisonData().replace("/", ""));
            } else {
                param.put("taishoYm", aggregateConditionBean.getSelComparisonData());
            }
            
            rirekiId = syuWfControlTblFacade.findRirekiId(param);
            if(StringUtils.isNotEmpty(rirekiId)){
                String[] ary = rirekiId.split(",");
                String rId = "";
                for(String id : ary){
                    rId = rId + "'" + id + "',";
                }
                rirekiId = rId.substring(0, rId.length()-1);
            }
        }
        
        return rirekiId;
    }
    
    /**
     * 集計データの取得
     * @param flg "0":案件別データ "1":総計データ
     * @return
     * @throws SQLException 
     */
    public List<Map<String, Object>> getAggregateData(String flg) throws SQLException{
        List<Map<String, Object>> result;
        
        String sqlFilePath = "/sql/syuGeBukkenInfoTbl/selectDetailAggregateList.sql";
        
        Map<String, Object> condition = getCondition();
        logger.info("condition atsukaiTeamCode=[{}] atsukaiCCode=[{}]", condition.get("ankenTeamCode"), condition.get("atsukaiCCode"));

        // 集計データ取得処理
        condition.put("sumFlg", flg);
        // SQLを取得
        SqlFile sqlFile = new SqlFile();
        String sql = sqlFile.getSqlString(sqlFilePath, condition);
        Object[] params = sqlFile.getSqlParams(sqlFilePath, condition);
        
        // SQL実行でデータ検索(SQLが重いので一覧データと総合計行データを一気に取得する)
        int limit = utils.getPageLimit();
        int offset = utils.getPageOffset(s023Bean.getPage());
        result = dbUtilsExecutor.dbUtilsGetSqlList(em, sql, params, offset, limit);
        
//        if(flg.equals("0")){
//            // ページング込の案件リストデータ取得
//            int limit = utils.getPageLimit();
//            int offset = utils.getPageOffset(s023Bean.getPage());
//            result = dbUtilsExecutor.dbUtilsGetSqlList(em, sql, params, offset, limit);
//        } else {
//            // 総計データ取得
//            result = dbUtilsExecutor.dbUtilsGetSqlList(em, sql, params);
//        }
        
        return result;
    }
    
    /**
     * 「差」行用のデータリスト作成処理
     * @param aggList
     * @return 
     */
    private List<Map<String, Object>> makeDataList(List<Map<String, Object>> aggList){
        List<Map<String, Object>> list = new ArrayList<>();
        String jsKey = "J_SP_";
        String jnKey = "J_NET_";
        String usKey = "U_SP_";
        String unKey = "U_NET_";
        String ksKey = "K_SP_";
        
        for(Map<String, Object> map : aggList){
            int num = 0;
            for(Map<String, Object> yoko: aggregateConditionBean.getYokozikuList()){
                BigDecimal nowSpVal = (BigDecimal) map.get(jsKey + "NOW" + num);
                BigDecimal befSpVal = (BigDecimal) map.get(jsKey + "BEF" + num);
                BigDecimal difSpVal = sUtils.arari(nowSpVal, befSpVal);
                map.put(jsKey + "DIF" + num, difSpVal);
                
                nowSpVal = (BigDecimal) map.get(usKey + "NOW" + num);
                befSpVal = (BigDecimal) map.get(usKey + "BEF" + num);
                difSpVal = sUtils.arari(nowSpVal, befSpVal);
                map.put(usKey + "DIF" + num, difSpVal);
                
                nowSpVal = (BigDecimal) map.get(ksKey + "NOW" + num);
                befSpVal = (BigDecimal) map.get(ksKey + "BEF" + num);
                difSpVal = sUtils.arari(nowSpVal, befSpVal);
                map.put(ksKey + "DIF" + num, difSpVal);
                
                BigDecimal nowNetVal = (BigDecimal) map.get(jnKey + "NOW" + num);
                BigDecimal befNetVal = (BigDecimal) map.get(jnKey + "BEF" + num);
                BigDecimal difNetVal = sUtils.arari(nowNetVal, befNetVal);
                map.put(jnKey + "DIF" + num, difNetVal);
                
                nowNetVal = (BigDecimal) map.get(unKey + "NOW" + num);
                befNetVal = (BigDecimal) map.get(unKey + "BEF" + num);
                difNetVal = sUtils.arari(nowNetVal, befNetVal);
                map.put(unKey + "DIF" + num, difNetVal);
                
                num++;
            }
            
            list.add(map);
        }
        
        return list;
    }
    
    /**
     * 画面表示用ヘッダーデータセット
     */
    private void setHeadData(List<Map<String, Object>> list){
        Map<String, Object> headData = list.get(0);
        String primaryKey = "";
        String secondaryKey = "";
        
        primaryKey = (String) headData.get("KEY0_NAME");
        // 一次集計に"サブBU"or"BU"を選択した場合
        if(aggregateConditionBean.getPrimaryUnit().equals("1") || aggregateConditionBean.getPrimaryUnit().equals("6")){
            if(StringUtils.isNotEmpty(s023Bean.getAggregateKey1()) && StringUtils.isNotEmpty((CharSequence) headData.get("KEY1_NAME"))){
                secondaryKey = (String) headData.get("KEY1_NAME");
            }
        } else {
            if(StringUtils.isNotEmpty(s023Bean.getAggregateKey1()) && StringUtils.isNotEmpty((CharSequence) headData.get("KEY1_NAME"))){
                primaryKey += (String) headData.get("KEY1_NAME");
            }
            if(StringUtils.isNotEmpty(s023Bean.getAggregateKey2())){
                secondaryKey = (String)headData.get("KEY2_NAME");
            }
        }
        
        s023Bean.setHeadPrimaryKey(primaryKey);
        s023Bean.setHeadSecondaryKey(secondaryKey);

    }
    
    /**
     * 検索用条件のセット
     * @return 
     */
    public Map<String, Object> getCondition(){
        // 検索条件をセット
        Map<String, Object> condition = getSearchCondition();
        
        // 確定月から履歴ID取得
        String rirekiId = getRirekiId();

        // 集計単位からSQL生成
        StringBuilder key = getKeySql();

        condition.put("key", String.valueOf(key));
        condition.put("keyCount", s023Bean.getKeyCount());

        // 集計データ部SQL作成
        StringBuilder selectSumData = getSelectSumDataSql(rirekiId);
        condition.put("selectSumData", selectSumData);

        // 案件毎のSUMMARYデータ部作成
        StringBuilder selectData = getSelectDataSql(rirekiId);
        condition.put("selectData", selectData);

        return condition;
    }
    
    /**
     * 画面の検索条件をセット
     * @return 
     */
    private Map<String, Object> getSearchCondition(){
        Map<String, Object> condition = new HashMap<>();

        // 事業部コード:(原子力)であるかを判断
        boolean isNuclearDivision = divisionComponentPage.isNuclearDivision(aggregateConditionBean.getDivisionCode());
        
        // 事業部
        //if (s001Bean.getDivisionCode() != null) {
        if (StringUtils.isNotEmpty(aggregateConditionBean.getDivisionCode())) {
            //condition.put("divisionCode", Arrays.asList(s001Bean.getDivisionCode()));
            condition.put("divisionCode", aggregateConditionBean.getDivisionCode());
        }
        // 売上基準
        if (aggregateConditionBean.getSalesClass() != null && aggregateConditionBean.getSalesClass().length > 0) {
            condition.put("salesClass", Arrays.asList(aggregateConditionBean.getSalesClass()));
        }
        
        //20180306 原価回収基準対応　ADD START
        if (aggregateConditionBean.getSalesClassGenka() != null) {
            condition.put("salesClassGenka", aggregateConditionBean.getSalesClassGenka());
        }
        //20180306 原価回収基準対応　ADD END 
        
        // 表示単位
        condition.put("dispKbn", aggregateConditionBean.getDispKbn());
        // 見積種類
        if(StringUtils.isNotEmpty(aggregateConditionBean.getDivisionCode()) && isNuclearDivision){
            if (aggregateConditionBean.getMitumoriKbn() != null && aggregateConditionBean.getMitumoriKbn().length > 0) {
                condition.put("mitumoriKbn", Arrays.asList(aggregateConditionBean.getMitumoriKbn()));
            }
        }
        // (電力ジ対応追加)主管課
        //if (aggregateConditionBean.getSyukanJobGrId() != null) {
        if (StringUtils.isNotEmpty(aggregateConditionBean.getSyukanJobGrId())) {
            condition.put("syukanJobGrId", aggregateConditionBean.getSyukanJobGrId());
        }
        // (電力ジ対応追加)サブBU
        //if (aggregateConditionBean.getSubBuId() != null) {
        if (aggregateConditionBean.getSubBuId() != null && aggregateConditionBean.getSubBuId().length > 0) {
            // 元画面から、他事業部のBUが渡ってくる可能性があるため、対象の事業部に該当するBUのみに絞って検索する
            Map<String, Object> targetSbuCondition = new HashMap<>();
            targetSbuCondition.put("divisionCode", aggregateConditionBean.getDivisionCode());
            targetSbuCondition.put("sbuCodeList", aggregateConditionBean.getSubBuId());
            List<BuMst> targetDivisionSbuList = buMstFacade.findConditionList(targetSbuCondition);
            List<String> sbuList = new ArrayList<>();
            for (BuMst buMst: targetDivisionSbuList) {
                sbuList.add(buMst.getSbuCode());
            }
            if (CollectionUtils.isNotEmpty(sbuList)) {
                condition.put("subBuId", sbuList);
            }
        }
        // チームコード
        condition.put("myTeamFlg", aggregateConditionBean.getMyTeamFlg());
        // 検索条件でチームコードの所属チームが選択されており、
        // 且つプルダウンが選択されていない場合、全ての候補が選択条件となる
        if ("T".equals(aggregateConditionBean.getMyTeamFlg()) && StringUtils.isEmpty(aggregateConditionBean.getMyTeamCd())) {
            List<TeamEntity> teamMstList = s001MstBean.getTeamMstList();
            List<String> teamCdList = new ArrayList<>();
            for (TeamEntity rec : teamMstList) {
                teamCdList.add(rec.getTeamCd().trim());
            }
            condition.put("myTeamCd", teamCdList);
        } else {
            List<String> teamCdList = new ArrayList<>();
            if(StringUtils.isNotEmpty(aggregateConditionBean.getMyTeamCd())) {
                teamCdList.add(aggregateConditionBean.getMyTeamCd().trim());
            }else{
                teamCdList.add(aggregateConditionBean.getMyTeamCd());
            }
            condition.put("myTeamCd", teamCdList);
        }
        logger.info("atsukaiTeamCode=[{}] atsukaiCCode=[{}]", aggregateConditionBean.getTeamCode(), aggregateConditionBean.getHanbaiCode());
        condition.put("ankenTeamCode", aggregateConditionBean.getTeamCode());
        condition.put("atsukaiCCode", aggregateConditionBean.getHanbaiCode());
        // 営業担当
        if (StringUtils.isNotEmpty(aggregateConditionBean.getEigyoJobGrId())) {
            List<String> eigCodeList = m0130LineEigJobgrFacade.findLineEigCodeList(aggregateConditionBean.getDivisionCode(), aggregateConditionBean.getEigyoJobGrId(), true);
            // 検索条件：営業担当は、事業部によりマッチさせる項目が異なる。そのため以下にその判断用パラメータを設定
            if (CollectionUtils.isNotEmpty(eigCodeList)) {
                //if (StringUtils.equals(aggregateConditionBean.getDivisionCode(), divNuclear)) {
                if (isNuclearDivision) {
                    // 事業部:(原子力)として営業担当を検索
                    condition.put("eigyoJobGrCodeList", eigCodeList);
                } else {
                    // 事業部:(火水ジ)として営業担当を検索
                    condition.put("eigyoTeamCodeList", eigCodeList);
                }
            }
        }
        
        //勘定年月のセット
        condition.put("ippanKanjyoYm", kanjyoMstFacade.getNowKanjoDate("0"));
        condition.put("shinkouKanjyoYm", kanjyoMstFacade.getNowKanjoDate("1"));
        if(aggregateConditionBean.getComparison().equals("G")) {
            condition.put("befKanjyoYm", aggregateConditionBean.getComparisonData().replace("/", ""));
        } else if(aggregateConditionBean.getComparison().equals("Y")){
            String[] ym = SyuuekiUtils.getKikanMonthAry(aggregateConditionBean.getSelComparisonData().substring(0, 5));
            condition.put("befKanjyoYm", ym[0]);
        }
        
        ////// 受注/売上/回収のどの情報を出力するか？
        condition.put("jyuchuDataFlg", aggregateConditionBean.getJyuchuDataFlg());  // 受注データを出力(1:出力 0:未出力)
        condition.put("uriageDataFlg", aggregateConditionBean.getUriageDataFlg());  // 売上データを出力(1:出力 0:未出力)
        condition.put("kaisyuDataFlg", aggregateConditionBean.getKaisyuDataFlg());  // 回収データを出力(1:出力 0:未出力)

        ////// [対象データ]の期間を絞り込む条件を設定
        // 年月from-to
        //condition.put("conditionSyuekiYmFlg", aggregateConditionBean.getConditionSyuekiYmFlg());
        condition.put("conditionSyuekiYmFrom", aggregateConditionBean.getConditionSyuekiYmFrom());
        condition.put("conditionSyuekiYmTo", aggregateConditionBean.getConditionSyuekiYmTo());
        condition.put("conditionPeriodFlg", aggregateConditionBean.getConditionPeriodFlg());
        
        // 集計画面にて選択されたアンカー情報のセット
        condition.put("key0", s023Bean.getAggregateKey0());
        condition.put("key1", s023Bean.getAggregateKey1());
        condition.put("key2", s023Bean.getAggregateKey2());

        // 一次集計単位
        //  (一部検索が遅い集計単位は、直接項目指定で条件絞り込みを行うので、その判断のために指定)
        //  (2017B時点では主管課(2)を一次集計単位に指定した場合に遅いため条件を指定する)
        condition.put("primaryUnit", aggregateConditionBean.getPrimaryUnit());
        // 二次集計単位(2017B現在SQLでは未使用)
        condition.put("secondaryUnit", aggregateConditionBean.getSecondaryUnit());
        
        return condition;
    }
    
    /**
     * 集計条件に応じたKEYを作成
     */
    private StringBuilder getKeySql(){
        StringBuilder key = new StringBuilder();
        int count = 0;
        String kbn;
        
        // 第1次集計SQL作成(s)
        //if(aggregateConditionBean.getPrimaryUnit().equals("0") || aggregateConditionBean.getPrimaryUnit().equals("2")){
        if (aggregateConditionBean.isPrimaryUnitBuka()) {
            if(aggregateConditionBean.getPrimaryUnit().equals("0")){
                //　集計単位:営業課
                kbn = "1";
            } else {
                // 集計単位:主管課
                kbn = "2";
            }
            key.append(", NVL(" + getSelectBuka("B_CD", kbn) + ", '	') AS KEY").append(String.valueOf(count)).append(" ");
            key.append(", " + getSelectBuka("B_NM", kbn) + " AS KEY").append(String.valueOf(count)).append("_NAME ");
            count++;

            key.append(", NVL(" + getSelectBuka("K_CD", kbn) + ", '	') AS KEY").append(String.valueOf(count)).append(" ");
            key.append(", " + getSelectBuka("K_NM", kbn) + " AS KEY").append(String.valueOf(count)).append("_NAME ");
            count++;

        } else if(aggregateConditionBean.getPrimaryUnit().equals("1")){
            // 集計単位:サブBU
            key.append(", NVL(BI.SUB_BU_ID, '	') AS KEY").append(String.valueOf(count)).append(" ");
            key.append(", BI.SUB_BU_NAME AS KEY").append(String.valueOf(count)).append("_NAME ");
            count++;
            
        } else if (aggregateConditionBean.getPrimaryUnit().equals("6")){
            // 集計単位:BU
            //key.append(", NVL(TO_CHAR(BI.BU_ID), '	') AS KEY").append(String.valueOf(count)).append(" ");
            //key.append(", BI.BU_NAME AS KEY").append(String.valueOf(count)).append("_NAME ");
            key.append(", NVL(GET_BU_NAME(BI.SUB_BU_ID, BI.DIVISION_CODE), '	') AS KEY").append(String.valueOf(count)).append(" ");
            key.append(", GET_BU_NAME(BI.SUB_BU_ID, BI.DIVISION_CODE) AS KEY").append(String.valueOf(count)).append("_NAME ");
            count++;
            
        }
        // 第1次集計SQL作成(e)
        
        // 第2次集計SQL作成(s)
        //「営業課」、「主管課」が選択されている場合
        //if(aggregateConditionBean.getSecondaryUnit().equals("0") || aggregateConditionBean.getSecondaryUnit().equals("2")){
        if (aggregateConditionBean.isSecondaryUnitBuka()) {
            if(aggregateConditionBean.getSecondaryUnit().equals("0")){
                kbn = "1";
            } else {
                kbn = "2";
            }
            key.append(", NVL(" + getSelectBuka("K_CD", kbn) + ", '	') AS KEY").append(String.valueOf(count)).append(" ");
            key.append(", " + getSelectBuka("BK_NM", kbn) + " AS KEY").append(String.valueOf(count)).append("_NAME ");
            count++;

        } else {
            // サブBUが選択されている場合
            if(aggregateConditionBean.getSecondaryUnit().equals("1")){
                key.append(", NVL(BI.SUB_BU_ID, '	') AS KEY").append(String.valueOf(count)).append(" ");
                key.append(", BI.SUB_BU_NAME AS KEY").append(String.valueOf(count)).append("_NAME ");
                count++;
            }
            // 設置場所が選択されている場合
            if(aggregateConditionBean.getSecondaryUnit().equals("3")){
                key.append(", NVL(BI.STCH_NAME, '	') AS KEY").append(String.valueOf(count)).append(" ");
                key.append(", BI.STCH_NAME AS KEY").append(String.valueOf(count)).append("_NAME ");
                count++;
            }
            // プラントコード + 収益分類が選択されている場合
            if(aggregateConditionBean.getSecondaryUnit().equals("4")){
                key.append(", NVL(BI.PLANT_CODE || ' ' || BI.BUNRUI_CD, '	') AS KEY").append(String.valueOf(count)).append(" ");
                key.append(", BI.PLANT_CODE || ' ' || (SELECT M1.BUNRUI_NM FROM N7_BUNRUI_MST M1 WHERE M1.BUNRUI_CD = BI.BUNRUI_CD AND M1.BU_CD = BI.SUB_BU_ID) AS KEY").append(String.valueOf(count)).append("_NAME ");
                count++;
            }
        }
        // 第2次集計SQL作成(e)
        
        // key2までSQLが作られていない場合
        if(count < 3) {
            // key1までSQLが作られていない場合
            if(count < 2){
                key.append(", NULL AS KEY1 ");
                key.append(", NULL AS KEY1_NAME ");
            }
            key.append(", NULL AS KEY2 ");
            key.append(", NULL AS KEY2_NAME ");
            
        }
        
        s023Bean.setKeyCount(count);
        
        return key;
    }
    
    /**
     * 営業課・主管課のSELECT句取得
     * @param bukaKbn 1:営業課 2:主管課
     * @param valueKbn 取得する値
     */
    private String getSelectBuka(String bukaKbn, String valueKbn) {
        String select = "";

        // 事業部コード:(原子力)であるかを判断
        boolean isNuclearDivision = divisionComponentPage.isNuclearDivision(aggregateConditionBean.getDivisionCode());

        //if (divNuclear.equals(aggregateConditionBean.getDivisionCode())) {
        if (isNuclearDivision) {
            // 原子力
            select = "GET_SUM_BUKA_CODE_GEN(BI.ANKEN_ID, '" + bukaKbn + "', '" + valueKbn + "')";
        } else {
            // 火水ジ
            select = "GET_SUM_BUKA_CODE_KA(BI.ANKEN_TEAM_CODE, '" + bukaKbn + "')";
        }

        return select;
    }

    /**
     *  集計データ部SQL作成
     **/
    private StringBuilder getSelectSumDataSql(String rirekiId){
        StringBuilder selectSumData = new StringBuilder();
        
        StringBuilder jutyu = new StringBuilder();
        StringBuilder uriage = new StringBuilder();
        StringBuilder kaishu = new StringBuilder();
        
        // 出力項目「受注」が選択されている場合
        if(Arrays.asList(aggregateConditionBean.getOutputItem()).contains("0")){
            jutyu = getJutyuSumSql(rirekiId);
        }
        // 出力項目「売上」が選択されている場合
        if(Arrays.asList(aggregateConditionBean.getOutputItem()).contains("1")){
            uriage = getUriageSumSql(rirekiId);
        }
        // 出力項目「回収」が選択されている場合
        if(Arrays.asList(aggregateConditionBean.getOutputItem()).contains("2")){
            kaishu = getKaishuSumSql(rirekiId);
        }
        
        selectSumData.append(jutyu);
        selectSumData.append(uriage);
        selectSumData.append(kaishu);

        return selectSumData;
    }
    
//    private StringBuilder getJutyuSumSql(String rirekiId){
//        StringBuilder sql = new StringBuilder();
//        int num = 0;
//        
//        // 受注SP取得sql
//        for(Map<String, Object> map: aggregateConditionBean.getYokozikuList()){
//            sql.append(", SUM(T1.J_SP_NOW");
//            sql.append(num);
//            sql.append(") AS J_SP_NOW");
//            sql.append(num);
//            sql.append(" ");
//            
//            num++;
//        }
//        
//        num = 0;
//        
//        // 受注SP取得sql
//        for(Map<String, Object> map: aggregateConditionBean.getYokozikuList()){
//            sql.append(", SUM(T1.J_NET_NOW");
//            sql.append(num);
//            sql.append(") AS J_NET_NOW");
//            sql.append(num);
//            sql.append(" ");
//            
//            num++;
//        }
//        
//        if(StringUtils.isNotEmpty(rirekiId)){
//            num = 0;
//            // 受注SP取得sql
//            for(Map<String, Object> map: aggregateConditionBean.getYokozikuList()){
//                sql.append(", SUM(T1.J_SP_BEF");
//                sql.append(num);
//                sql.append(") AS J_SP_BEF");
//                sql.append(num);
//                sql.append(" ");
//
//                num++;
//            }
//
//            num = 0;
//
//            // 受注SP取得sql
//            for(Map<String, Object> map: aggregateConditionBean.getYokozikuList()){
//                sql.append(", SUM(T1.J_NET_BEF");
//                sql.append(num);
//                sql.append(") AS J_NET_BEF");
//                sql.append(num);
//                sql.append(" ");
//
//                num++;
//            }
//        }
//        
//        return sql;
//    }
    
    private StringBuilder getJutyuSumSql(String rirekiId){
        StringBuilder sql = new StringBuilder();
        int num = 0;
        
        // 受注SP取得sql
        for(Map<String, Object> map: aggregateConditionBean.getYokozikuList()){
            sql.append(", (SUM(T1.J_SP_NOW");
            sql.append(num);
            sql.append(") OVER()) AS SUM_J_SP_NOW");
            sql.append(num);
            sql.append(" ");
            
            num++;
        }
        
        num = 0;
        
        // 受注SP取得sql
        for(Map<String, Object> map: aggregateConditionBean.getYokozikuList()){
            sql.append(", (SUM(T1.J_NET_NOW");
            sql.append(num);
            sql.append(") OVER()) AS SUM_J_NET_NOW");
            sql.append(num);
            sql.append(" ");
            
            num++;
        }
        
        if(StringUtils.isNotEmpty(rirekiId)){
            num = 0;
            // 受注SP取得sql
            for(Map<String, Object> map: aggregateConditionBean.getYokozikuList()){
                sql.append(", (SUM(T1.J_SP_BEF");
                sql.append(num);
                sql.append(") OVER()) AS SUM_J_SP_BEF");
                sql.append(num);
                sql.append(" ");

                num++;
            }

            num = 0;

            // 受注SP取得sql
            for(Map<String, Object> map: aggregateConditionBean.getYokozikuList()){
                sql.append(", (SUM(T1.J_NET_BEF");
                sql.append(num);
                sql.append(") OVER()) AS SUM_J_NET_BEF");
                sql.append(num);
                sql.append(" ");

                num++;
            }
        }
        
        return sql;
    }
    
    
//    private StringBuilder getUriageSumSql(String rirekiId){
//        StringBuilder sql = new StringBuilder();
//        int num = 0;
//        
//        for(Map<String, Object> map: aggregateConditionBean.getYokozikuList()){
//            sql.append(", SUM(T1.U_SP_NOW");
//            sql.append(num);
//            sql.append(") AS U_SP_NOW");
//            sql.append(num);
//            sql.append(" ");
//                    
//            num++;
//        }
//        
//        num = 0;
//        
//        for(Map<String, Object> map: aggregateConditionBean.getYokozikuList()){
//            sql.append(", SUM(T1.U_NET_NOW");
//            sql.append(num);
//            sql.append(") AS U_NET_NOW");
//            sql.append(num);
//            sql.append(" ");
//            
//            num++;
//        }
//        
//        if(StringUtils.isNotEmpty(rirekiId)){
//            num = 0;
//            
//            for(Map<String, Object> map: aggregateConditionBean.getYokozikuList()){
//                sql.append(", SUM(T1.U_SP_BEF");
//                sql.append(num);
//                sql.append(") AS U_SP_BEF");
//                sql.append(num);
//                sql.append(" ");
//
//                num++;
//            }
//
//            num = 0;
//
//            for(Map<String, Object> map: aggregateConditionBean.getYokozikuList()){
//                sql.append(", SUM(T1.U_NET_BEF");
//                sql.append(num);
//                sql.append(") AS U_NET_BEF");
//                sql.append(num);
//                sql.append(" ");
//
//                num++;
//            }
//        }
//        
//        return sql;
//    }
    
    
    private StringBuilder getUriageSumSql(String rirekiId){
        StringBuilder sql = new StringBuilder();
        int num = 0;
        
        for(Map<String, Object> map: aggregateConditionBean.getYokozikuList()){
            sql.append(", (SUM(T1.U_SP_NOW");
            sql.append(num);
            sql.append(") OVER()) AS SUM_U_SP_NOW");
            sql.append(num);
            sql.append(" ");
                    
            num++;
        }
        
        num = 0;
        
        for(Map<String, Object> map: aggregateConditionBean.getYokozikuList()){
            sql.append(", (SUM(T1.U_NET_NOW");
            sql.append(num);
            sql.append(") OVER()) AS SUM_U_NET_NOW");
            sql.append(num);
            sql.append(" ");
            
            num++;
        }
        
        if(StringUtils.isNotEmpty(rirekiId)){
            num = 0;
            
            for(Map<String, Object> map: aggregateConditionBean.getYokozikuList()){
                sql.append(", (SUM(T1.U_SP_BEF");
                sql.append(num);
                sql.append(") OVER()) AS SUM_U_SP_BEF");
                sql.append(num);
                sql.append(" ");

                num++;
            }

            num = 0;

            for(Map<String, Object> map: aggregateConditionBean.getYokozikuList()){
                sql.append(", (SUM(T1.U_NET_BEF");
                sql.append(num);
                sql.append(") OVER()) AS SUM_U_NET_BEF");
                sql.append(num);
                sql.append(" ");

                num++;
            }
        }
        
        return sql;
    }
    
//    private StringBuilder getKaishuSumSql(String rirekiId){
//        StringBuilder sql = new StringBuilder();
//        int num = 0;
//        
//        for(Map<String, Object> map: aggregateConditionBean.getYokozikuList()){
//            sql.append(", SUM(T1.K_SP_NOW");
//            sql.append(num);
//            sql.append(") AS K_SP_NOW");
//            sql.append(num);
//            sql.append(" ");
//            
//            num++;
//        }
//        
//        if(StringUtils.isNotEmpty(rirekiId)){
//            num = 0;
//            
//            for(Map<String, Object> map: aggregateConditionBean.getYokozikuList()){
//                sql.append(", SUM(T1.K_SP_BEF");
//                sql.append(num);
//                sql.append(") AS K_SP_BEF");
//                sql.append(num);
//                sql.append(" ");
//
//                num++;
//            }
//        }
//        
//        return sql;
//    }
    
    private StringBuilder getKaishuSumSql(String rirekiId){
        StringBuilder sql = new StringBuilder();
        int num = 0;
        
        for(Map<String, Object> map: aggregateConditionBean.getYokozikuList()){
            sql.append(", (SUM(T1.K_SP_NOW");
            sql.append(num);
            sql.append(") OVER()) AS SUM_K_SP_NOW");
            sql.append(num);
            sql.append(" ");
            
            num++;
        }
        
        if(StringUtils.isNotEmpty(rirekiId)){
            num = 0;
            
            for(Map<String, Object> map: aggregateConditionBean.getYokozikuList()){
                sql.append(", (SUM(T1.K_SP_BEF");
                sql.append(num);
                sql.append(") OVER()) AS SUM_K_SP_BEF");
                sql.append(num);
                sql.append(" ");

                num++;
            }
        }
        
        return sql;
    }

    private StringBuilder getSelectDataSql(String rirekiId){
        StringBuilder selectData = new StringBuilder();
        
        StringBuilder jutyu = new StringBuilder();
        StringBuilder uriage = new StringBuilder();
        StringBuilder kaishu = new StringBuilder();
        
        // 出力項目「受注」が選択されている場合
        if(Arrays.asList(aggregateConditionBean.getOutputItem()).contains("0")){
            jutyu = getJutyuSql(rirekiId);
        }
        // 出力項目「売上」が選択されている場合
        if(Arrays.asList(aggregateConditionBean.getOutputItem()).contains("1")){
            uriage = getUriageSql(rirekiId);
        }
        // 出力項目「回収」が選択されている場合
        if(Arrays.asList(aggregateConditionBean.getOutputItem()).contains("2")){
            kaishu = getKaishuSql(rirekiId);
        }
        
        selectData.append(jutyu);
        selectData.append(uriage);
        selectData.append(kaishu);
        
        return selectData;
    }
    
    /**
     * 受注行データ取得SQL作成処理
     * @return 
     */
    private StringBuilder getJutyuSql(String rirekiId){
        StringBuilder sql = new StringBuilder();
        int num = 0;
        
        // SP取得sql作成
        for(Map<String, Object> map: aggregateConditionBean.getYokozikuList()){
            String kbn = (String) map.get("dataKbn");
            String syuekiYm = (String) map.get("syuekiYm");
            
            switch(kbn) {
                case "J":
                    sql.append(", (SELECT S.JYUCHU_SP FROM SYU_KI_JYUCHU_TOTAL_TBL S WHERE S.ANKEN_ID = A.ANKEN_ID AND S.RIREKI_ID = A.RIREKI_ID AND S.DATA_KBN = (CASE WHEN S.SYUEKI_YM < A.NOW_KANJYO_YM THEN 'J' ELSE 'M' END) AND S.SYUEKI_YM = '");
                    sql.append(syuekiYm);
                    sql.append("') AS J_SP_NOW");
                    sql.append(num);
                    sql.append(" ");

                    break;
                case "Y":
                    String[] ym = SyuuekiUtils.getKikanFromYm(syuekiYm);
                    sql.append(", (SELECT SUM(S.JYUCHU_SP) FROM SYU_KI_JYUCHU_TOTAL_TBL S WHERE S.ANKEN_ID = A.ANKEN_ID AND S.RIREKI_ID = A.RIREKI_ID AND S.DATA_KBN = 'K' AND S.SYUEKI_YM IN ('");
                    sql.append(ym[0]);
                    sql.append("', '");
                    sql.append(ym[1]);
                    sql.append("')) AS J_SP_NOW");
                    sql.append(num);
                    sql.append(" ");

                    break;
                default :
                    sql.append(", (SELECT S.JYUCHU_SP FROM SYU_KI_JYUCHU_TOTAL_TBL S WHERE S.ANKEN_ID = A.ANKEN_ID AND S.RIREKI_ID = A.RIREKI_ID AND S.DATA_KBN = '");
                    sql.append(kbn);
                    sql.append("' AND S.SYUEKI_YM = '");
                    sql.append(syuekiYm);
                    sql.append("') AS J_SP_NOW");
                    sql.append(num);
                    sql.append(" ");
                    break;
            }
            
            num++;
        }
        
        num = 0;
        // NET取得sql作成
        for(Map<String, Object> map: aggregateConditionBean.getYokozikuList()){
            String kbn = (String) map.get("dataKbn");
            String syuekiYm = (String) map.get("syuekiYm");

            switch(kbn) {
                case "J":
                    sql.append(", (SELECT S.JYUCHU_NET FROM SYU_KI_JYUCHU_TOTAL_TBL S WHERE S.ANKEN_ID = A.ANKEN_ID AND S.RIREKI_ID = A.RIREKI_ID AND S.DATA_KBN = (CASE WHEN S.SYUEKI_YM < A.NOW_KANJYO_YM THEN 'J' ELSE 'M' END) AND S.SYUEKI_YM = '");
                    sql.append(syuekiYm);
                    sql.append("') AS J_NET_NOW");
                    sql.append(num);
                    sql.append(" ");

                    break;
                case "Y":
                    String[] ym = SyuuekiUtils.getKikanFromYm(syuekiYm);
                    sql.append(", (SELECT SUM(S.JYUCHU_NET) FROM SYU_KI_JYUCHU_TOTAL_TBL S WHERE S.ANKEN_ID = A.ANKEN_ID AND S.RIREKI_ID = A.RIREKI_ID AND S.DATA_KBN = 'K' AND S.SYUEKI_YM IN ('");
                    sql.append(ym[0]);
                    sql.append("', '");
                    sql.append(ym[1]);
                    sql.append("')) AS J_NET_NOW");
                    sql.append(num);
                    sql.append(" ");

                    break;
                default :
                    sql.append(", (SELECT S.JYUCHU_NET FROM SYU_KI_JYUCHU_TOTAL_TBL S WHERE S.ANKEN_ID = A.ANKEN_ID AND S.RIREKI_ID = A.RIREKI_ID AND S.DATA_KBN = '");
                    sql.append(kbn);
                    sql.append("' AND S.SYUEKI_YM = '");
                    sql.append(syuekiYm);
                    sql.append("') AS J_NET_NOW");
                    sql.append(num);
                    sql.append(" ");
                    break;
            }
            
            num++;
        }
        
        // 前回確定が選択されている場合
        if(StringUtils.isNotEmpty(rirekiId)){
            num = 0;
            // SP取得sql作成
            for(Map<String, Object> map: aggregateConditionBean.getYokozikuList()){
                String kbn = (String) map.get("dataKbn");
                String syuekiYm = (String) map.get("syuekiYm");

                switch(kbn) {
                    case "J":
                        sql.append(", (SELECT SUM(S.JYUCHU_SP) FROM SYU_R_KI_JYUCHU_TOTAL_TBL S WHERE S.ANKEN_ID = A.ANKEN_ID AND S.RIREKI_ID IN (");
                        sql.append(rirekiId);
                        sql.append(") AND S.DATA_KBN = (CASE WHEN S.SYUEKI_YM < A.BEF_KANJYO_YM THEN 'J' ELSE 'M' END) AND S.SYUEKI_YM = '");
                        sql.append(syuekiYm);
                        sql.append("') AS J_SP_BEF");
                        sql.append(num);
                        sql.append(" ");

                        break;
                    case "Y":
                        String[] ym = SyuuekiUtils.getKikanFromYm(syuekiYm);
                        sql.append(", (SELECT SUM(S.JYUCHU_SP) FROM SYU_R_KI_JYUCHU_TOTAL_TBL S WHERE S.ANKEN_ID = A.ANKEN_ID AND S.RIREKI_ID IN (");
                        sql.append(rirekiId);
                        sql.append(") AND S.DATA_KBN = 'K' AND S.SYUEKI_YM IN ('");
                        sql.append(ym[0]);
                        sql.append("', '");
                        sql.append(ym[1]);
                        sql.append("')) AS J_SP_BEF");
                        sql.append(num);
                        sql.append(" ");

                        break;
                    default :
                        sql.append(", (SELECT SUM(S.JYUCHU_SP) FROM SYU_R_KI_JYUCHU_TOTAL_TBL S WHERE S.ANKEN_ID = A.ANKEN_ID AND S.RIREKI_ID IN (");
                        sql.append(rirekiId);
                        sql.append(") AND S.DATA_KBN = '");
                        sql.append(kbn);
                        sql.append("' AND S.SYUEKI_YM = '");
                        sql.append(syuekiYm);
                        sql.append("') AS J_SP_BEF");
                        sql.append(num);
                        sql.append(" ");
                        break;
                }

                num++;
            }

            num = 0;
            // NET取得sql作成
            for(Map<String, Object> map: aggregateConditionBean.getYokozikuList()){
                String kbn = (String) map.get("dataKbn");
                String syuekiYm = (String) map.get("syuekiYm");

                switch(kbn) {
                    case "J":
                        sql.append(", (SELECT SUM(S.JYUCHU_NET) FROM SYU_R_KI_JYUCHU_TOTAL_TBL S WHERE S.ANKEN_ID = A.ANKEN_ID AND S.RIREKI_ID IN (");
                        sql.append(rirekiId);
                        sql.append(") AND S.DATA_KBN = (CASE WHEN S.SYUEKI_YM < A.BEF_KANJYO_YM THEN 'J' ELSE 'M' END) AND S.SYUEKI_YM = '");
                        sql.append(syuekiYm);
                        sql.append("') AS J_NET_BEF");
                        sql.append(num);
                        sql.append(" ");

                        break;
                    case "Y":
                        String[] ym = SyuuekiUtils.getKikanFromYm(syuekiYm);
                        sql.append(", (SELECT SUM(S.JYUCHU_NET) FROM SYU_R_KI_JYUCHU_TOTAL_TBL S WHERE S.ANKEN_ID = A.ANKEN_ID AND S.RIREKI_ID IN (");
                        sql.append(rirekiId);
                        sql.append(") AND S.DATA_KBN = 'K' AND S.SYUEKI_YM IN ('");
                        sql.append(ym[0]);
                        sql.append("', '");
                        sql.append(ym[1]);
                        sql.append("')) AS J_NET_BEF");
                        sql.append(num);
                        sql.append(" ");

                        break;
                    default :
                        sql.append(", (SELECT SUM(S.JYUCHU_NET) FROM SYU_R_KI_JYUCHU_TOTAL_TBL S WHERE S.ANKEN_ID = A.ANKEN_ID AND S.RIREKI_ID IN (");
                        sql.append(rirekiId);
                        sql.append(") AND S.DATA_KBN = '");
                        sql.append(kbn);
                        sql.append("' AND S.SYUEKI_YM = '");
                        sql.append(syuekiYm);
                        sql.append("') AS J_NET_BEF");
                        sql.append(num);
                        sql.append(" ");
                        break;
                }

                num++;
            }
        }
        
        return sql;
    }
    
    /**
     * 売上行データ取得SQL作成処理
     * @return 
     */
    private StringBuilder getUriageSql(String rirekiId){
        StringBuilder sql = new StringBuilder();
        int num = 0;
        
        // SP取得sql作成
        for(Map<String, Object> map: aggregateConditionBean.getYokozikuList()){
            String kbn = (String) map.get("dataKbn");
            String syuekiYm = (String) map.get("syuekiYm");
            
            switch(kbn){
                case "J" :
                    sql.append(", (SELECT S.URIAGE_AMOUNT FROM SYU_KI_SP_TOTAL_TBL S WHERE S.ANKEN_ID = A.ANKEN_ID AND S.RIREKI_ID = A.RIREKI_ID AND S.DATA_KBN = (CASE WHEN S.SYUEKI_YM < A.NOW_KANJYO_YM THEN 'J' ELSE 'M' END) AND S.SYUEKI_YM = '");
                    sql.append(syuekiYm);
                    sql.append("') AS U_SP_NOW");
                    sql.append(num);
                    sql.append(" ");
                    break;
                case "Y" :
                    String[] ym = SyuuekiUtils.getKikanFromYm(syuekiYm);
                    sql.append(", (SELECT SUM(S.URIAGE_AMOUNT) FROM SYU_KI_SP_TOTAL_TBL S WHERE S.ANKEN_ID = A.ANKEN_ID AND S.RIREKI_ID = A.RIREKI_ID AND S.DATA_KBN = 'K' AND S.SYUEKI_YM IN ('");
                    sql.append(ym[0]);
                    sql.append("', '");
                    sql.append(ym[1]);
                    sql.append("')) AS U_SP_NOW");
                    sql.append(num);
                    sql.append(" ");
                    break;
                default :
                    sql.append(", (SELECT S.URIAGE_AMOUNT FROM SYU_KI_SP_TOTAL_TBL S WHERE S.ANKEN_ID = A.ANKEN_ID AND S.RIREKI_ID = A.RIREKI_ID AND S.DATA_KBN = '");
                    sql.append(kbn);
                    sql.append("' AND S.SYUEKI_YM = '");
                    sql.append(syuekiYm);
                    sql.append("') AS U_SP_NOW");
                    sql.append(num);
                    sql.append(" ");
                    break;
            }

            num++;
        }
        
        num = 0;
        // NET取得sql作成
        for(Map<String, Object> map: aggregateConditionBean.getYokozikuList()){
            String kbn = (String) map.get("dataKbn");
            String syuekiYm = (String) map.get("syuekiYm");
            
            switch(kbn) {
                case "J" :
                    sql.append(", (SELECT N.URIAGE_GENKA FROM SYU_KI_NET_TOTAL_TBL N WHERE N.ANKEN_ID = A.ANKEN_ID AND N.RIREKI_ID = A.RIREKI_ID AND N.DATA_KBN = (CASE WHEN N.SYUEKI_YM < A.NOW_KANJYO_YM THEN 'J' ELSE 'M' END) AND N.SYUEKI_YM = '");
                    sql.append(syuekiYm);
                    sql.append("') AS U_NET_NOW");
                    sql.append(num);
                    sql.append(" ");
                    break;
                case "Y" :
                    String[] ym = SyuuekiUtils.getKikanFromYm(syuekiYm);
                    sql.append(", (SELECT SUM(N.URIAGE_GENKA) FROM SYU_KI_NET_TOTAL_TBL N WHERE N.ANKEN_ID = A.ANKEN_ID AND N.RIREKI_ID = A.RIREKI_ID AND N.DATA_KBN = 'K' AND N.SYUEKI_YM IN ('");
                    sql.append(ym[0]);
                    sql.append("', '");
                    sql.append(ym[1]);
                    sql.append("')) AS U_NET_NOW");
                    sql.append(num);
                    sql.append(" ");
                    break;
                default :
                    sql.append(", (SELECT N.URIAGE_GENKA FROM SYU_KI_NET_TOTAL_TBL N WHERE N.ANKEN_ID = A.ANKEN_ID AND N.RIREKI_ID = A.RIREKI_ID AND N.DATA_KBN = '");
                    sql.append(kbn);
                    sql.append("' AND N.SYUEKI_YM = '");
                    sql.append(syuekiYm);
                    sql.append("') AS U_NET_NOW");
                    sql.append(num);
                    sql.append(" ");
                    break;
            }

            num++;
        }
        
        // 前回確定が選択されている場合
        if(StringUtils.isNotEmpty(rirekiId)){
            num = 0;
            
            // SP取得sql作成
            for(Map<String, Object> map: aggregateConditionBean.getYokozikuList()){
                String kbn = (String) map.get("dataKbn");
                String syuekiYm = (String) map.get("syuekiYm");

                switch(kbn){
                    case "J" :
                        sql.append(", (SELECT SUM(S.URIAGE_AMOUNT) FROM SYU_R_KI_SP_TOTAL_TBL S WHERE S.ANKEN_ID = A.ANKEN_ID AND S.RIREKI_ID IN ( ");
                        sql.append(rirekiId);
                        sql.append(") AND S.DATA_KBN = (CASE WHEN S.SYUEKI_YM < A.BEF_KANJYO_YM THEN 'J' ELSE 'M' END) AND S.SYUEKI_YM = '");
                        sql.append(syuekiYm);
                        sql.append("') AS U_SP_BEF");
                        sql.append(num);
                        sql.append(" ");
                        break;
                    case "Y" :
                        String[] ym = SyuuekiUtils.getKikanFromYm(syuekiYm);
                        sql.append(", (SELECT SUM(S.URIAGE_AMOUNT) FROM SYU_R_KI_SP_TOTAL_TBL S WHERE S.ANKEN_ID = A.ANKEN_ID AND S.RIREKI_ID IN ( ");
                        sql.append(rirekiId);
                        sql.append(") AND S.DATA_KBN = 'K' AND S.SYUEKI_YM IN ('");
                        sql.append(ym[0]);
                        sql.append("', '");
                        sql.append(ym[1]);
                        sql.append("')) AS U_SP_BEF");
                        sql.append(num);
                        sql.append(" ");
                        break;
                    default :
                        sql.append(", (SELECT SUM(S.URIAGE_AMOUNT) FROM SYU_R_KI_SP_TOTAL_TBL S WHERE S.ANKEN_ID = A.ANKEN_ID AND S.RIREKI_ID IN ( ");
                        sql.append(rirekiId);
                        sql.append(") AND S.DATA_KBN = '");
                        sql.append(kbn);
                        sql.append("' AND S.SYUEKI_YM = '");
                        sql.append(syuekiYm);
                        sql.append("') AS U_SP_BEF");
                        sql.append(num);
                        sql.append(" ");
                        break;
                }

                num++;
            }

            num = 0;
            // NET取得sql作成
            for(Map<String, Object> map: aggregateConditionBean.getYokozikuList()){
                String kbn = (String) map.get("dataKbn");
                String syuekiYm = (String) map.get("syuekiYm");

                switch(kbn) {
                    case "J" :
                        sql.append(", (SELECT SUM(N.URIAGE_GENKA) FROM SYU_R_KI_NET_TOTAL_TBL N WHERE N.ANKEN_ID = A.ANKEN_ID AND N.RIREKI_ID IN (");
                        sql.append(rirekiId);
                        sql.append(") AND N.DATA_KBN = (CASE WHEN N.SYUEKI_YM < A.BEF_KANJYO_YM THEN 'J' ELSE 'M' END) AND N.SYUEKI_YM = '");
                        sql.append(syuekiYm);
                        sql.append("') AS U_NET_BEF");
                        sql.append(num);
                        sql.append(" ");
                        break;
                    case "Y" :
                        String[] ym = SyuuekiUtils.getKikanFromYm(syuekiYm);
                        sql.append(", (SELECT SUM(N.URIAGE_GENKA) FROM SYU_R_KI_NET_TOTAL_TBL N WHERE N.ANKEN_ID = A.ANKEN_ID AND N.RIREKI_ID IN (");
                        sql.append(rirekiId);
                        sql.append(") AND N.DATA_KBN = 'K' AND N.SYUEKI_YM IN ('");
                        sql.append(ym[0]);
                        sql.append("', '");
                        sql.append(ym[1]);
                        sql.append("')) AS U_NET_BEF");
                        sql.append(num);
                        sql.append(" ");
                        break;
                    default :
                        sql.append(", (SELECT SUM(N.URIAGE_GENKA) FROM SYU_R_KI_NET_TOTAL_TBL N WHERE N.ANKEN_ID = A.ANKEN_ID AND N.RIREKI_ID IN (");
                        sql.append(rirekiId);
                        sql.append(") AND N.DATA_KBN = '");
                        sql.append(kbn);
                        sql.append("' AND N.SYUEKI_YM = '");
                        sql.append(syuekiYm);
                        sql.append("') AS U_NET_BEF");
                        sql.append(num);
                        sql.append(" ");
                        break;
                }

                num++;
            }
        }
        
        return sql;
    }
    
    /**
     * 回収行データ取得SQL作成処理
     * @return 
     */
    private StringBuilder getKaishuSql(String rirekiId){
        StringBuilder sql = new StringBuilder();
        int num = 0;
        
        // (電力ジ対応で変更)回収額は"回収円貨＋回収円貨税率"で出力
        String selectKaisyuAmount = "SUM(CASE WHEN (S.KAISYU_ENKA_AMOUNT IS NOT NULL or S.KAISYU_ENKA_ZEI IS NOT NULL) THEN (NVL(S.KAISYU_ENKA_AMOUNT, 0) + NVL(S.KAISYU_ENKA_ZEI, 0)) END)";
        
        // SP取得sql作成
        for(Map<String, Object> map: aggregateConditionBean.getYokozikuList()){
            String kbn = (String) map.get("dataKbn");
            String syuekiYm = (String) map.get("syuekiYm");
            
            switch(kbn) {
                case "J" :
                    sql.append(", (SELECT " + selectKaisyuAmount + " FROM SYU_KI_KAISYU_TBL S WHERE S.ANKEN_ID = A.ANKEN_ID AND S.RIREKI_ID = A.RIREKI_ID AND S.DATA_KBN = (CASE WHEN S.SYUEKI_YM < A.NOW_KANJYO_YM THEN 'J' ELSE 'M' END) AND S.SYUEKI_YM = '");
                    sql.append(syuekiYm);
                    sql.append("') AS K_SP_NOW");
                    sql.append(num);
                    sql.append(" ");
                    break;
                case "Y" :
                    String[] ym = SyuuekiUtils.getKikanFromYm(syuekiYm);
                    sql.append(", (SELECT " + selectKaisyuAmount + " FROM SYU_KI_KAISYU_TBL S WHERE S.ANKEN_ID = A.ANKEN_ID AND S.RIREKI_ID = A.RIREKI_ID AND S.DATA_KBN = 'K' AND S.SYUEKI_YM IN ('");
                    sql.append(ym[0]);
                    sql.append("', '");
                    sql.append(ym[1]);
                    sql.append("')) AS K_SP_NOW");
                    sql.append(num);
                    sql.append(" ");
                    break;
                default :
                    sql.append(", (SELECT " + selectKaisyuAmount + " FROM SYU_KI_KAISYU_TBL S WHERE S.ANKEN_ID = A.ANKEN_ID AND S.RIREKI_ID = A.RIREKI_ID AND S.DATA_KBN = '");
                    sql.append(kbn);
                    sql.append("' AND S.SYUEKI_YM = '");
                    sql.append(syuekiYm);
                    sql.append("') AS K_SP_NOW");
                    sql.append(num);
                    sql.append(" ");
                    break;
            }

            num++;
        }
        
        if(StringUtils.isNotEmpty(rirekiId)){
            num = 0;
            
            // SP取得sql作成
            for(Map<String, Object> map: aggregateConditionBean.getYokozikuList()){
                String kbn = (String) map.get("dataKbn");
                String syuekiYm = (String) map.get("syuekiYm");

                switch(kbn) {
                    case "J" :
                        sql.append(", (SELECT " + selectKaisyuAmount + " FROM SYU_R_KI_KAISYU_TBL S WHERE S.ANKEN_ID = A.ANKEN_ID AND S.RIREKI_ID IN (");
                        sql.append(rirekiId);
                        sql.append(") AND S.DATA_KBN = (CASE WHEN S.SYUEKI_YM < A.BEF_KANJYO_YM THEN 'J' ELSE 'M' END) AND S.SYUEKI_YM = '");
                        sql.append(syuekiYm);
                        sql.append("') AS K_SP_BEF");
                        sql.append(num);
                        sql.append(" ");
                        break;
                    case "Y" :
                        String[] ym = SyuuekiUtils.getKikanFromYm(syuekiYm);
                        sql.append(", (SELECT " + selectKaisyuAmount + " FROM SYU_R_KI_KAISYU_TBL S WHERE S.ANKEN_ID = A.ANKEN_ID AND S.RIREKI_ID IN (");
                        sql.append(rirekiId);
                        sql.append(") AND S.DATA_KBN = 'K' AND S.SYUEKI_YM IN ('");
                        sql.append(ym[0]);
                        sql.append("', '");
                        sql.append(ym[1]);
                        sql.append("')) AS K_SP_BEF");
                        sql.append(num);
                        sql.append(" ");
                        break;
                    default :
                        sql.append(", (SELECT " + selectKaisyuAmount + " FROM SYU_R_KI_KAISYU_TBL S WHERE S.ANKEN_ID = A.ANKEN_ID AND S.RIREKI_ID IN (");
                        sql.append(rirekiId);
                        sql.append(") AND S.DATA_KBN = '");
                        sql.append(kbn);
                        sql.append("' AND S.SYUEKI_YM = '");
                        sql.append(syuekiYm);
                        sql.append("') AS K_SP_BEF");
                        sql.append(num);
                        sql.append(" ");
                        break;
                }

                num++;
            }
        }
        
        return sql;
    }
}
