package jp.co.toshiba.hby.pspromis.syuueki.service.download;

import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.ejb.Stateless;
import javax.inject.Inject;
import javax.interceptor.Interceptors;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import jp.co.toshiba.hby.pspromis.syuueki.bean.S001Bean;
import jp.co.toshiba.hby.pspromis.syuueki.interceptor.TranceInterceptor;
import jp.co.toshiba.hby.pspromis.common.jdbc.SqlExecutor;
import jp.co.toshiba.hby.pspromis.syuueki.entity.OperationLog;
import jp.co.toshiba.hby.pspromis.syuueki.entity.SyuBatchLog;
import jp.co.toshiba.hby.pspromis.syuueki.entity.SyuGeBukkenInfoTblView;
import jp.co.toshiba.hby.pspromis.syuueki.enums.Label;
import jp.co.toshiba.hby.pspromis.syuueki.facade.SysdateEntityFacade;
import jp.co.toshiba.hby.pspromis.syuueki.facade.SyuBatchLogFacade;
import jp.co.toshiba.hby.pspromis.syuueki.facade.SyuWfControlTblFacade;
import jp.co.toshiba.hby.pspromis.syuueki.jdbc.DbUtilsExecutor;
import jp.co.toshiba.hby.pspromis.syuueki.service.OperationLogService;
import jp.co.toshiba.hby.pspromis.syuueki.service.S001Service;
import jp.co.toshiba.hby.pspromis.syuueki.util.PoiUtil;
import jp.co.toshiba.hby.pspromis.syuueki.util.LoginUserInfo;
import jp.co.toshiba.hby.pspromis.syuueki.util.SyuuekiUtils;
import jp.co.toshiba.hby.pspromis.syuueki.util.Utils;
import org.apache.commons.lang3.StringUtils;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Row;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
/**
 * PS-Promis収益管理システム
 * 案件検索 Service(受注残一覧Excel)
 * @author (NPC)horie
 */
@Stateless
@Interceptors({TranceInterceptor.class})
public class JyuchuZanListService implements DownloadIfc {

    public static final Logger logger = LoggerFactory.getLogger(JyuchuZanListService.class);

    @PersistenceContext(unitName = jp.co.toshiba.hby.pspromis.syuueki.util.ConstantString.syuuekiDataSourceName)
    private EntityManager em;

    @Inject
    private S001Service s001Service;
    
    @Inject
    private SyuWfControlTblFacade syuWfControlTblFacade;
    
    /**
     * パラメータ格納クラスをinjection(CDI)<br>
     * InjectアノテーションよりAPサーバー(Glassfish)側で自動的にインスタンス作成(new)される。<br>
     */
    @Inject
    private S001Bean s001Bean;

    /**
     * Injection loginUserInfo
     * (ユーザー情報(ユーザーid,名称,所属部課名)を格納したオブジェクト)
     */
    @Inject
    private LoginUserInfo loginUserInfo;

    /**
     * Injection sqlExecutor
     */
    @Inject
    protected SqlExecutor sqlExecutor;

    /**
     * Injection SyuuekiUtils
     */
    @Inject
    private SyuuekiUtils syuuekiUtils;

    @Inject
    private SysdateEntityFacade sysdateFacade;

    @Inject
    private SyuBatchLogFacade syuBatchLogFacade;

    @Inject
    private OperationLogService operationLogService;

    //@Inject
    //private OperationLogService operationLogService;
    
    private static final String SHEETNAME = "list";
    private static final int FIRST_ROW_INDEX = 5;
    private static final int BASE_ROW_INDEX = 5;

    /**
     * 指定した受注残一覧Excelテンプレートにデータを書き込む
     */
    @Override
    public void downloadExecute(Workbook workbook) throws Exception {

        logger.info("[JyuchuZanListService#downloadExecute]");

        int rowNum = FIRST_ROW_INDEX;
        String jpyUnitKbn = "1";
        Sheet sheet = workbook.getSheet(SHEETNAME);
        
        // 日時フォーマット
        SimpleDateFormat sdf1 = new SimpleDateFormat("yyyy/MM");
        SimpleDateFormat sdf2 = new SimpleDateFormat(syuuekiUtils.formatTimeStamp());
        SimpleDateFormat sdf3 = new SimpleDateFormat("yyyy/MM/dd");
        
        Map<String, Object> condtion = s001Service.getCondition();
        
        // 月次確定か予算だったら履歴IDを取得する
        if (!"R".equals(s001Bean.getRirekiFlg())) {
            condtion.put("rirekiId", "0");
        } else {
            condtion.put("rirekiId", Arrays.asList(syuWfControlTblFacade.findRirekiId(condtion).split(",")));
        }

        // データ取得
        List<SyuGeBukkenInfoTblView> list = sqlExecutor.getResultList(em, SyuGeBukkenInfoTblView.class, "/sql/selectListSyuueki.sql", condtion);
        
        // 物件行のスタイルを取得
        Row row = PoiUtil.getRow(sheet, BASE_ROW_INDEX, true);
        List<Cell> cellList = PoiUtil.getCellList(row);

        // 単位
        String jpyUnit = Label.getValue(Label.jpyUnit1);

        if(s001Bean.getJpyUnit() == 1000){
            jpyUnitKbn = "2";
            jpyUnit = Label.getValue(Label.jpyUnit2);
        }else if(s001Bean.getJpyUnit() == 1000000){
            jpyUnitKbn = "3";
            jpyUnit = Label.getValue(Label.jpyUnit3);
        }

        // ヘッダー出力
        String header = Label.getValue(Label.outputName) + "：" + loginUserInfo.getUserName();
        header = header + "　　　" + Label.getValue(Label.outputDate) + "：" + sdf2.format(sysdateFacade.getSysdate());
        header = header + "　　　" + Label.getValue(Label.unitLabel) + "：" + jpyUnit;
        if(jpyUnitKbn.equals("1")){
                PoiUtil.setCellValue(sheet, 0, 7, "");
        }
            

                
        PoiUtil.setCellValue(sheet, 0, 4, header);

        // 実績日付を取得
        Map<String, Object> conditionJiseki = new HashMap<>();
        conditionJiseki.put("result", "0");
        conditionJiseki.put("batchId", "SYU_ANKEN_MAKE_DAILY");
        SyuBatchLog batchLogEntityJiseki = syuBatchLogFacade.getMaxEndDate(conditionJiseki);
        
        // 実績日付を出力
        PoiUtil.setCellValue(sheet, 1, 1, sdf3.format(batchLogEntityJiseki.getEndTime()));
        
        // 受注残日付を取得
        Map<String, Object> conditionJyucyuZan = new HashMap<>();
        conditionJyucyuZan.put("result", "0");
        conditionJyucyuZan.put("batchId", "SYU_JYUCHUZAN_UPDATE");
        SyuBatchLog batchLogEntityJyucyuZan = syuBatchLogFacade.getMaxEndDate(conditionJyucyuZan);
        
        // 受注残日付を出力
        PoiUtil.setCellValue(sheet, 3, 30, "受注残（" + sdf3.format(batchLogEntityJyucyuZan.getEndTime()) + "更新）");
        
        // データ種別を出力
        String stringDataKbnDisp = s001Bean.getDataKbnDisp();
        PoiUtil.setCellValue(sheet, 2, 1, stringDataKbnDisp);
        
        // 列の非表示コントロール
        String[] juchuZanKbn = s001Bean.getJuchuZanKbn();
        
        if(juchuZanKbn == null){
            // SP
            sheet.setColumnWidth(22, 0);
            sheet.setColumnWidth(25, 0);
            sheet.setColumnWidth(27, 0);
            sheet.setColumnWidth(30, 0);
            sheet.setColumnWidth(34, 0);
            // ISP
            sheet.setColumnWidth(31, 0);
            // NET
            sheet.setColumnWidth(23, 0);
            sheet.setColumnWidth(28, 0);
            sheet.setColumnWidth(32, 0);
            sheet.setColumnWidth(35, 0);
            // NET(転売)
            sheet.setColumnWidth(33, 0);
        }else{
            // SP
            if(!Arrays.asList(juchuZanKbn).contains("S")){
                sheet.setColumnWidth(22, 0);
                sheet.setColumnWidth(25, 0);
                sheet.setColumnWidth(27, 0);
                sheet.setColumnWidth(30, 0);
                sheet.setColumnWidth(34, 0);
            }
            // ISP
            if(!Arrays.asList(juchuZanKbn).contains("I")){
                sheet.setColumnWidth(31, 0);
            }
            // NET
            if(!Arrays.asList(juchuZanKbn).contains("N")){
                sheet.setColumnWidth(23, 0);
                sheet.setColumnWidth(28, 0);
                sheet.setColumnWidth(32, 0);
                sheet.setColumnWidth(35, 0);
            }
            // NET(転売)
            if(!Arrays.asList(juchuZanKbn).contains("T")){
                sheet.setColumnWidth(33, 0);
            }
        }
        
        for (int i = 0; i < list.size(); i++){
            
            int cellNum = 0;

            //行データを取得
            SyuGeBukkenInfoTblView SyuGeBukkenInfoTblView = list.get(i);

            // 2行目以降は1行目のスタイルをコピー
            if (rowNum > FIRST_ROW_INDEX) {
                row = PoiUtil.getRow(sheet, rowNum, true);
                PoiUtil.copyRowStyleValue(row, cellList, false);
            }

            if(SyuGeBukkenInfoTblView.getOrderNo() != null){
                PoiUtil.setCellValue(sheet, rowNum, cellNum++, SyuGeBukkenInfoTblView.getOrderNo());
            }else{
                PoiUtil.setCellValue(sheet, rowNum, cellNum++, SyuGeBukkenInfoTblView.getAnkenId());
            }

            
            // S/N (Xは出力しない)
            if(!"X".equals(SyuGeBukkenInfoTblView.getSnKbn())){
                PoiUtil.setCellValue(sheet, rowNum, cellNum++, syuuekiUtils.getSNLabel(SyuGeBukkenInfoTblView.getSnKbn()));
            }else{
                PoiUtil.setCellValue(sheet, rowNum, cellNum++, null);
            }

            // 売上基準
            //PoiUtil.setCellValue(sheet, rowNum, cellNum++, syuuekiUtils.getSalesClassLabelFull(SyuGeBukkenInfoTblView.getSalesClass()));//20180302 原価回収基準対応　REP
            PoiUtil.setCellValue(sheet, rowNum, cellNum++, syuuekiUtils.getSalesClassLabelAddLoss(syuuekiUtils.getSalesClassLabelGenFull(SyuGeBukkenInfoTblView.getSalesClass(),SyuGeBukkenInfoTblView.getSalesClassGenka()), SyuGeBukkenInfoTblView.getLossControlFlag()));//20180302 原価回収基準対応　REP
            
            
            // 売上区分
            if("1".equals(SyuGeBukkenInfoTblView.getUriageEndFlg()) || "2".equals(SyuGeBukkenInfoTblView.getUriageEndFlg())){
                PoiUtil.setCellValue(sheet, rowNum, cellNum++, syuuekiUtils.getUriageEndLabel(SyuGeBukkenInfoTblView.getUriageEndFlg(),0));
            }else{
                PoiUtil.setCellValue(sheet, rowNum, cellNum++, null);
            }

            // 分割見込・項番見込
            if ("3".equals(SyuGeBukkenInfoTblView.getInputIchiranFlg())) {
                PoiUtil.setCellValue(sheet, rowNum, cellNum++, Label.kobanMikomi.getLabel());
            } else if ("1".equals(SyuGeBukkenInfoTblView.getBunkatsuFlg())){
                PoiUtil.setCellValue(sheet, rowNum, cellNum++, Label.split.getLabel());
            } else {
                PoiUtil.setCellValue(sheet, rowNum, cellNum++, null);
            }

            // 注文主
            PoiUtil.setCellValue(sheet, rowNum, cellNum++, SyuGeBukkenInfoTblView.getTradeName());

            // 設置場所
            PoiUtil.setCellValue(sheet, rowNum, cellNum++, SyuGeBukkenInfoTblView.getStchName());

            // 品名
            PoiUtil.setCellValue(sheet, rowNum, cellNum++, SyuGeBukkenInfoTblView.getAnkenName());

            // サブBUコード
            PoiUtil.setCellValue(sheet, rowNum, cellNum++, SyuGeBukkenInfoTblView.getSubBuId());

            // サブBU名称
            PoiUtil.setCellValue(sheet, rowNum, cellNum++, SyuGeBukkenInfoTblView.getSubBuName());

            // プラントコード
            PoiUtil.setCellValue(sheet, rowNum, cellNum++, SyuGeBukkenInfoTblView.getPlantCode());

            // 収益分類
            PoiUtil.setCellValue(sheet, rowNum, cellNum++, SyuGeBukkenInfoTblView.getBunruiNm());

            // 営業部門
            PoiUtil.setCellValue(sheet, rowNum, cellNum++, SyuGeBukkenInfoTblView.getHatEgBukaRnm());

            // 営業担当
            PoiUtil.setCellValue(sheet, rowNum, cellNum++, SyuGeBukkenInfoTblView.getHatEgEmpNm());

            // 業態
            PoiUtil.setCellValue(sheet, rowNum, cellNum++, SyuGeBukkenInfoTblView.getGyotai());

            // 販売事業部(販売営業チームコードの頭二桁)
            PoiUtil.setCellValue(sheet, rowNum, cellNum++, StringUtils.substring(SyuGeBukkenInfoTblView.getSzTeamCd(), 0, 2));

            // 販売営業
            PoiUtil.setCellValue(sheet, rowNum, cellNum++, SyuGeBukkenInfoTblView.getEgTeamCd());

            // 販売営業(販売営業チームコードの頭二桁)
            PoiUtil.setCellValue(sheet, rowNum, cellNum++, StringUtils.substring(SyuGeBukkenInfoTblView.getEgTeamCd(), 0, 2));

            // 製造営業
            PoiUtil.setCellValue(sheet, rowNum, cellNum++, SyuGeBukkenInfoTblView.getSzTeamCd());

            // 販売C
            PoiUtil.setCellValue(sheet, rowNum, cellNum++, SyuGeBukkenInfoTblView.getHbCCd());

            // 販売S
            PoiUtil.setCellValue(sheet, rowNum, cellNum++, SyuGeBukkenInfoTblView.getHbSCd());

            // 販売E
            PoiUtil.setCellValue(sheet, rowNum, cellNum++, SyuGeBukkenInfoTblView.getHbECd());

            // 発番_SP
            PoiUtil.setCellValue(sheet, rowNum, cellNum++, syuuekiUtils.changeUnit(Utils.changeBigDecimal(Utils.getObjToStrValue(SyuGeBukkenInfoTblView.getHatSp())), jpyUnitKbn));
            //PoiUtil.setCellValue(sheet, rowNum, cellNum++, utils.changeBigDecimal(utils.getObjToStrValue(SyuGeBukkenInfoTblView.getHatSp())));

            // 発番_NET
            PoiUtil.setCellValue(sheet, rowNum, cellNum++, syuuekiUtils.changeUnit(Utils.changeBigDecimal(Utils.getObjToStrValue(SyuGeBukkenInfoTblView.getHatNet())), jpyUnitKbn));

            // 発番_M率
            PoiUtil.setCellValue(sheet, rowNum, cellNum++, Utils.changeBigDecimal(syuuekiUtils.mrate(Utils.changeBigDecimal(Utils.getObjToStrValue(SyuGeBukkenInfoTblView.getHatSp())), Utils.changeBigDecimal(Utils.getObjToStrValue(SyuGeBukkenInfoTblView.getHatNet())))));

            // 契約_契約SP
            PoiUtil.setCellValue(sheet, rowNum, cellNum++, syuuekiUtils.changeUnit(Utils.changeBigDecimal(Utils.getObjToStrValue(SyuGeBukkenInfoTblView.getKeiyakuSp())), jpyUnitKbn));

            // 契約_最終連番
            PoiUtil.setCellValue(sheet, rowNum, cellNum++, SyuGeBukkenInfoTblView.getKeiyakuRenbanMax());

            // 売上_SP
            PoiUtil.setCellValue(sheet, rowNum, cellNum++, syuuekiUtils.changeUnit(Utils.changeBigDecimal(Utils.getObjToStrValue(SyuGeBukkenInfoTblView.getUriageSp())), jpyUnitKbn));

            // 売上_NET
            PoiUtil.setCellValue(sheet, rowNum, cellNum++, syuuekiUtils.changeUnit(Utils.changeBigDecimal(Utils.getObjToStrValue(SyuGeBukkenInfoTblView.getUriageNet())), jpyUnitKbn));

            // 売上_M率
            PoiUtil.setCellValue(sheet, rowNum, cellNum++, Utils.changeBigDecimal(syuuekiUtils.mrate(Utils.changeBigDecimal(Utils.getObjToStrValue(SyuGeBukkenInfoTblView.getUriageSp())), Utils.changeBigDecimal(Utils.getObjToStrValue(SyuGeBukkenInfoTblView.getUriageNet())))));

            // 受注残_SP
            PoiUtil.setCellValue(sheet, rowNum, cellNum++, syuuekiUtils.changeUnit(Utils.changeBigDecimal(Utils.getObjToStrValue(SyuGeBukkenInfoTblView.getJyuchuZanSp())), jpyUnitKbn));

            // 受注残_ISP
            PoiUtil.setCellValue(sheet, rowNum, cellNum++, syuuekiUtils.changeUnit(Utils.changeBigDecimal(Utils.getObjToStrValue(SyuGeBukkenInfoTblView.getJyuchuZanIsp())), jpyUnitKbn));

            // 受注残_NET
            PoiUtil.setCellValue(sheet, rowNum, cellNum++, syuuekiUtils.changeUnit(Utils.changeBigDecimal(Utils.getObjToStrValue(SyuGeBukkenInfoTblView.getJyuchuZanNet())), jpyUnitKbn));

            // 受注残_NET(転売)
            PoiUtil.setCellValue(sheet, rowNum, cellNum++, syuuekiUtils.changeUnit(Utils.changeBigDecimal(Utils.getObjToStrValue(SyuGeBukkenInfoTblView.getJyuchuZanTenbai())), jpyUnitKbn));

            // 最終見込_SP
            PoiUtil.setCellValue(sheet, rowNum, cellNum++, syuuekiUtils.changeUnit(Utils.changeBigDecimal(Utils.getObjToStrValue(SyuGeBukkenInfoTblView.getSaisyuSp())), jpyUnitKbn));

            // 最終見込_NET
            PoiUtil.setCellValue(sheet, rowNum, cellNum++, syuuekiUtils.changeUnit(Utils.changeBigDecimal(Utils.getObjToStrValue(SyuGeBukkenInfoTblView.getSaisyuNet())), jpyUnitKbn));

            // 最終見込_M率
            //PoiUtil.setCellValue(sheet, rowNum, cellNum++, utils.changeBigDecimal(syuuekiUtils.mrate(utils.changeBigDecimal(utils.getObjToStrValue(SyuGeBukkenInfoTblView.getSaisyuSp())), utils.changeBigDecimal(utils.getObjToStrValue(SyuGeBukkenInfoTblView.getSaisyuNet())))));
            PoiUtil.setCellValue(sheet, rowNum, cellNum++, SyuGeBukkenInfoTblView.getSaisyuMritu());

            // 受注年月_発番
            if(SyuGeBukkenInfoTblView.getHatJyuchuDate() != null){
                PoiUtil.setCellValue(sheet, rowNum, cellNum++, sdf1.format(SyuGeBukkenInfoTblView.getHatJyuchuDate()));
            }else{
                PoiUtil.setCellValue(sheet, rowNum, cellNum++, null);
            }

            // 受注年月_最終見込
            if(SyuGeBukkenInfoTblView.getJyuchuEnd() != null){
                PoiUtil.setCellValue(sheet, rowNum, cellNum++, sdf1.format(SyuGeBukkenInfoTblView.getJyuchuEnd()));
            }else{
                PoiUtil.setCellValue(sheet, rowNum, cellNum++, null);
            }

            // 売上年月_発番
            if(SyuGeBukkenInfoTblView.getHatUriageYotei() != null){
            PoiUtil.setCellValue(sheet, rowNum, cellNum++, sdf1.format(SyuGeBukkenInfoTblView.getHatUriageYotei()));
            }else{
                PoiUtil.setCellValue(sheet, rowNum, cellNum++, null);
            }

            // 売上年月_最終見込
            if(SyuGeBukkenInfoTblView.getUriageEnd() != null){
            PoiUtil.setCellValue(sheet, rowNum, cellNum++, sdf1.format(SyuGeBukkenInfoTblView.getUriageEnd()));
            }else{
                PoiUtil.setCellValue(sheet, rowNum, cellNum++, null);
            }

            // 出荷日限_発番
            if(SyuGeBukkenInfoTblView.getHatSyukkaNichigen() != null){
                PoiUtil.setCellValue(sheet, rowNum, cellNum++, sdf3.format(SyuGeBukkenInfoTblView.getHatSyukkaNichigen()));
            }else{
                PoiUtil.setCellValue(sheet, rowNum, cellNum++, null);
            }

            // 回収予定_発番
            if(SyuGeBukkenInfoTblView.getHatKaisyuYotei() != null){
                PoiUtil.setCellValue(sheet, rowNum, cellNum++, sdf1.format(SyuGeBukkenInfoTblView.getHatKaisyuYotei()));
            }else{
                PoiUtil.setCellValue(sheet, rowNum, cellNum++, null);
            }

            // 取扱店
            String toriatsuName = syuuekiUtils.getToriatsuName(SyuGeBukkenInfoTblView.getToriatsuNm());
            PoiUtil.setCellValue(sheet, rowNum, cellNum++, toriatsuName);
            
            // 販売ルート
            String salesRouteNm = SyuGeBukkenInfoTblView.getSalesRouteNm();
            PoiUtil.setCellValue(sheet, rowNum, cellNum++, salesRouteNm);
            
            rowNum++;
        }
        
        // 操作ログを出力
        OperationLog operationLog = operationLogService.getOperationLog();
        operationLog.setOperationCode("DL_JOB");
        operationLog.setObjectType("ANKEN");
        operationLog.setObjectId(10);
        operationLog.setRemarks("受注残一覧");
        operationLogService.insertOperationLogSearch(operationLog);
    }

}
