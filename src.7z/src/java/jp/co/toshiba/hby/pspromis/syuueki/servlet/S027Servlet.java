/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package jp.co.toshiba.hby.pspromis.syuueki.servlet;

import java.util.HashMap;
import java.util.Map;
import javax.inject.Inject;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import jp.co.toshiba.hby.pspromis.syuueki.bean.ResultMessageBean;
import jp.co.toshiba.hby.pspromis.syuueki.bean.S027Bean;
import jp.co.toshiba.hby.pspromis.syuueki.service.S027Service;
import jp.co.toshiba.hby.pspromis.syuueki.util.CdiUtils;
import jp.co.toshiba.hby.pspromis.syuueki.util.ParameterBinder;

/**
 *
 * @author watabe
 */
@WebServlet(name = "s027Servlet", urlPatterns = {"/servlet/S027","/servlet/S027/*"})
public class S027Servlet extends AbstractServlet {

    private static final String INDEX_JSP ="S027/s027.jsp";
    
    @Inject
    private S027Bean s027Bean;
    
    @Inject
    private S027Service s027Service;
    
    /**
     * 初期表示（勘定月-1か月）
     * @param req
     * @param resp
     * @return 
     */
    public String indexAction(HttpServletRequest req, HttpServletResponse resp)
    throws Exception {
        logger.info("s027#indexAction");
        // リクエストパラメータをs001Beanの同名フィールドに一括コピー
        ParameterBinder.Bind(s027Bean, req);
        //serviceの実行
        s027Service.getIspData();
        
        return INDEX_JSP;
    }
    
    /**
     * 検索ボタン
     * @param req
     * @param resp
     * @return 
     */
    public String searchAction(HttpServletRequest req, HttpServletResponse resp)
    throws Exception {
        logger.info("s027#searchAction");
        // リクエストパラメータをs001Beanの同名フィールドに一括コピー
        ParameterBinder.Bind(s027Bean, req);
        //serviceの実行
        s027Service.getSearchData();
        
        return INDEX_JSP;
    }
    
    /**
     * 引当ボタン
     * @param req
     * @param resp
     * @return 
     */
    public String hikiateAction(HttpServletRequest req, HttpServletResponse resp) 
    throws Exception {
        logger.info("s027#hikiateAction");
        // リクエストパラメータをs007Beanの同名フィールドに一括コピー
        ParameterBinder.Bind(s027Bean, req);
        s027Service.ispHikiate();
            // 処理結果を戻す。
            Map<String, Object> jsonMap = new HashMap<>();
            ResultMessageBean resultMessageBean = CdiUtils.getBean(ResultMessageBean.class);
            resultMessageBean.createResultMessage(jsonMap);
            resopnseDecodeJson(resp, jsonMap);
        return null;
    }
}
