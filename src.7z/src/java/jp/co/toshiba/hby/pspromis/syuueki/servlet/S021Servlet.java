package jp.co.toshiba.hby.pspromis.syuueki.servlet;

import javax.inject.Inject;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpServletRequest;
import jp.co.toshiba.hby.pspromis.syuueki.bean.S021Bean;
import jp.co.toshiba.hby.pspromis.syuueki.bean.ValidationMessageBean;
import jp.co.toshiba.hby.pspromis.syuueki.service.S021Service;
import jp.co.toshiba.hby.pspromis.syuueki.util.ParameterBinder;
import jp.co.toshiba.hby.pspromis.syuueki.enums.Label;

/**
 * ES-Promis収益管理システム
 * 検索パターン追加・整理
 * @author 
 */
@WebServlet(name="S021", urlPatterns={"/servlet/S021", "/servlet/S021/*"})
public class S021Servlet extends AbstractServlet {

    private static final String INDEX_JSP = "S021/searchPattern.jsp";
    
    private static final String API_LAYOUT_JSP = "S021/searchPatternLayoutLi.jsp";
    
    @Inject
    private S021Bean s021Bean;

    @Inject
    private S021Service s021Service;

    @Inject
    private ValidationMessageBean validationMessageBean;

    /**
     * 初期表示(検索パターン追加)
     * @param req
     * @param resp
     * @return
     * @throws Exception 
     */
    public String addPatternAction(HttpServletRequest req, HttpServletResponse resp)
    throws Exception {
        // リクエストパラメータをs020Beanの同名フィールドに一括コピー
        ParameterBinder.Bind(s021Bean, req);

        // サービスの実行(トランザクションの単位にもなる)
        s021Service.indexExecute();

        s021Bean.setDispKbn("0");
        s021Bean.setDispName(Label.dispNameAddSearchPattern.getLabel());
        
        return INDEX_JSP;
    }

    /**
     * 初期表示(検索パターン整理)
     * @param req
     * @param resp
     * @return
     * @throws Exception 
     */
    public String finishingSearchPatternAction(HttpServletRequest req, HttpServletResponse resp)
    throws Exception {
        // リクエストパラメータをs020Beanの同名フィールドに一括コピー
        ParameterBinder.Bind(s021Bean, req);

        // サービスの実行(トランザクションの単位にもなる)
        s021Service.indexExecute();

        s021Bean.setDispKbn("1");
        s021Bean.setDispName(Label.dispNameFinishingSearchPattern.getLabel());
        
        return INDEX_JSP;
    }

    /**
     * 初期表示(検索パターン追加処理 実行)
     * @param req
     * @param resp
     * @return
     * @throws Exception 
     */
    public String saveAction(HttpServletRequest req, HttpServletResponse resp)
    throws Exception {
        // リクエストパラメータをs020Beanの同名フィールドに一括コピー
        ParameterBinder.Bind(s021Bean, req);

        // サービスの実行(トランザクションの単位にもなる)
        if ("1".equals(s021Bean.getDispKbn())) {
            ////// 検索パターン整理
            if (!s021Service.validationUpdatePattern()) {
                resopnseDecodeJson(resp, validationMessageBean.errorJsonInfo());
            } else {
                s021Service.updatePatternExecute();
            }

        } else {
            ////// 検索パターン追加
            if (!s021Service.validationAddPattern()) {
                resopnseDecodeJson(resp, validationMessageBean.errorJsonInfo());
            } else {
                s021Service.addPatternExecute();
            }
        }

        return null;
    }

    /**
     * 検索パターン取得API(各検索画面のパターン指定欄の表示に利用)
     * @param req
     * @param resp
     * @return
     * @throws Exception 
     */
    public String searchPatternApiAction(HttpServletRequest req, HttpServletResponse resp)
    throws Exception {
        ParameterBinder.Bind(s021Bean, req);

        s021Service.searchPatternApiExecute();
        
        return API_LAYOUT_JSP;
    }

}
