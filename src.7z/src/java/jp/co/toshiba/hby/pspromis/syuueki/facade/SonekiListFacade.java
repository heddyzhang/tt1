package jp.co.toshiba.hby.pspromis.syuueki.facade;

import javax.ejb.Stateless;
import javax.interceptor.Interceptors;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import jp.co.toshiba.hby.pspromis.syuueki.entity.SonekiList;
import jp.co.toshiba.hby.pspromis.syuueki.interceptor.TranceInterceptor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 *
 * @author sano
 */
@Stateless
@Interceptors({TranceInterceptor.class})
public class SonekiListFacade extends AbstractFacade<SonekiList> {

    /**
     * ロガ－
     */
    private static final Logger logger = LoggerFactory.getLogger(SonekiListFacade.class);

    @PersistenceContext(unitName = jp.co.toshiba.hby.pspromis.syuueki.util.ConstantString.syuuekiDataSourceName)
    private EntityManager em;

    public SonekiListFacade() {
        super(SonekiList.class);
    }

    @Override
    protected EntityManager getEntityManager() {
        return em;
    }

    /**
     * 損益表を取得
     * @param condition
     * @return 
     */
    public SonekiList findList(Object condition) {
        logger.info("SonekiListFacade#findList");

        SonekiList list = sqlExecutor.getSingleResult(em, SonekiList.class, "/sql/S002/selectSonekiList.sql", condition);
        
        return list;
    }
}
