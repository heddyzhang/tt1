/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package jp.co.toshiba.hby.pspromis.syuueki.entity;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/**
 *
 * @author masaki
 */
@Entity
@Table(name = "SYU_MIKOMI_RATE_MST")
public class SyuMikomiRateMst implements Serializable {
    private static final long serialVersionUID = 1L;

    @Column(name = "TYPE")
    @Id
    private String type;

    @Column(name = "DIVISION_CODE")
    @Id
    private String divisionCode;
    
    @Column(name = "MAIN_ORDER_NO")
    @Id
    private String mainOrderNo;

    @Column(name = "ANKEN_NAME")
    private String ankenName;

    @Column(name = "CURRENCY_CODE")
    @Id
    private String currencyCode;

    @Column(name = "MIKOMI_RATE")
    private BigDecimal mikomiRate;

    @Column(name = "CREATED_BY")
    private String createdBy;

    @Column(name = "CREATION_DATE")
    @Temporal(TemporalType.TIMESTAMP)
    private Date creationDate;

    @Column(name = "LAST_UPDATE_BY")
    private String lastUpdateBy;

    @Column(name = "LAST_UPDATE_DATE")
    @Temporal(TemporalType.TIMESTAMP)
    private Date lastUpdateDate;
    
    @Column(name = "LAST_UPDATE_ID")
    private String lastUpdateId;

    
    public SyuMikomiRateMst() {
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getCurrencyCode() {
        return currencyCode;
    }

    public void setCurrencyCode(String currencyCode) {
        this.currencyCode = currencyCode;
    }

    public String getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    public Date getCreationDate() {
        return creationDate;
    }

    public void setCreationDate(Date creationDate) {
        this.creationDate = creationDate;
    }

    public String getLastUpdateBy() {
        return lastUpdateBy;
    }

    public void setLastUpdateBy(String lastUpdateBy) {
        this.lastUpdateBy = lastUpdateBy;
    }

    public Date getLastUpdateDate() {
        return lastUpdateDate;
    }

    public void setLastUpdateDate(Date lastUpdateDate) {
        this.lastUpdateDate = lastUpdateDate;
    }

    public String getDivisionCode() {
        return divisionCode;
    }

    public void setDivisionCode(String divisionCode) {
        this.divisionCode = divisionCode;
    }

    public String getMainOrderNo() {
        return mainOrderNo;
    }

    public void setMainOrderNo(String mainOrderNo) {
        this.mainOrderNo = mainOrderNo;
    }

    public String getAnkenName() {
        return ankenName;
    }

    public void setAnkenName(String ankenName) {
        this.ankenName = ankenName;
    }

    public BigDecimal getMikomiRate() {
        return mikomiRate;
    }

    public void setMikomiRate(BigDecimal mikomiRate) {
        this.mikomiRate = mikomiRate;
    }

    public String getLastUpdateId() {
        return lastUpdateId;
    }

    public void setLastUpdateId(String lastUpdateId) {
        this.lastUpdateId = lastUpdateId;
    }

    
}
