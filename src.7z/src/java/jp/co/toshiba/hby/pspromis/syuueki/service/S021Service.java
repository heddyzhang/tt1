package jp.co.toshiba.hby.pspromis.syuueki.service;

import java.util.List;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import javax.ejb.Stateless;
import javax.inject.Inject;
import javax.interceptor.Interceptors;
import jp.co.toshiba.hby.pspromis.syuueki.bean.S021Bean;
import jp.co.toshiba.hby.pspromis.syuueki.bean.ValidationMessageBean;
import jp.co.toshiba.hby.pspromis.syuueki.entity.SyuSearchPatternTbl;
import jp.co.toshiba.hby.pspromis.syuueki.entity.SyuSearchPatternColTbl;
import jp.co.toshiba.hby.pspromis.syuueki.enums.Label;
import jp.co.toshiba.hby.pspromis.syuueki.enums.ValidatorMessage;
import jp.co.toshiba.hby.pspromis.syuueki.facade.SyuSearchPatternTblFacade;
import jp.co.toshiba.hby.pspromis.syuueki.interceptor.TranceInterceptor;
import jp.co.toshiba.hby.pspromis.syuueki.util.EntityUtils;
import jp.co.toshiba.hby.pspromis.syuueki.util.LoginUserInfo;
import jp.co.toshiba.hby.pspromis.syuueki.util.ValidationUtils;
import jp.co.toshiba.hby.pspromis.syuueki.util.Utils;
import org.apache.commons.beanutils.BeanUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.beanutils.PropertyUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * ES-Promis収益管理システム
 * 検索パターン追加・整理 Service
 * @author 
 */
@Stateless
@Interceptors({TranceInterceptor.class})
public class S021Service {

    public static final Logger log = LoggerFactory.getLogger(S021Service.class);

    @Inject
    private S021Bean s021Bean;

    @Inject
    private ValidationMessageBean validationMessageBean;

    @Inject
    private LoginUserInfo loginUserInfo;

    @Inject
    private SyuSearchPatternTblFacade syuSearchPatternTblFacade;

    /**
     * バリデーションチェック(パターン名称追加)
     * @throws Exception
     */
    public boolean validationAddPattern() throws Exception {
        String message = "";
        if (!ValidationUtils.isRequired(s021Bean.getNewPatternName())) {
            // 必須チェック
            message = ValidatorMessage.REQUIRED.getMessae(Label.patternName.getLabel());
            
        } else if (!ValidationUtils.isByteOver(s021Bean.getNewPatternName(), 256)) {
            // 桁数チェック
            message = ValidatorMessage.BYTE_OVER_HAN_ZEN.getMessae(Label.patternName.getLabel(), 256, ValidationUtils.getZenCharCount(256));
            validationMessageBean.setErrorInfo("hinmei", message);
        }
            
//            // 重複チェック
//            if (!isCheckPatternNameRepeat(s021Bean.getNewPatternName())) {
//                message = ValidatorMessage.SAME_DATA_ERROR.getMessae(Label.patternName.getLabel());
//            }

        if (StringUtils.isNotEmpty(message)) {
            validationMessageBean.setErrorInfo("newPatternName", message);
        }
        
        return validationMessageBean.isSuccess();
    }

    /**
     * バリデーションチェック(パターン名称整理)
     * @throws Exception
     */
    public boolean validationUpdatePattern() throws Exception {
        String message;
        
        List<Map<String, String>> list = s021Bean.getUpdatePatternList();
        String[] selectedIndexs = s021Bean.getSelectedIndex();

        // 一覧データを別オブジェクトにコピー
        List<Map<String, String>> copyList = new ArrayList<>(list);
        copyList.addAll(list);

        // 削除対象データ
        List<Integer> notPatternSeqList = new ArrayList<>();

        // 削除対象のパターンSEQをため込む
        log.info("list=[]", list);
        log.info("copyList1=[]", copyList);
        if (selectedIndexs != null) {
            for (String strIndex: selectedIndexs) {
                int idx = Integer.parseInt(strIndex);
                Map<String, String> data = copyList.get(idx);
                
                // パターンSEQを控えておく
                Integer patternSeq = Integer.parseInt((String)data.get("patternSeq"));
                notPatternSeqList.add(patternSeq);
                
                // 一覧からデータを削除
                copyList.remove(idx);
            }
        }

        // 名称の重複チェック
        log.info("copyList2=[]", copyList);
        if (CollectionUtils.isNotEmpty(copyList)) {
            // 画面での名称一覧をMapにためる
            Map<String, Integer> nameMapCount = new HashMap<>();
            for (Map<String, String> data: copyList) {
                String patternName = (String)data.get("patternName");
                if (StringUtils.isNotEmpty(patternName)) {
                    Utils.setNameMapCount(nameMapCount, patternName);
                }
            }
 
            log.info("nameMapCount=[]", nameMapCount);
            
            // データを1件ずつチェック
            for (Map<String, String> data: copyList) {
                String patternName = (String)data.get("patternName");
                Integer index = Integer.parseInt((String)data.get("index"));

                message = "";
                String errorKey = "updatePatternList-" + index + "-patternName";

                if (!ValidationUtils.isRequired(patternName)) {
                    // 必須チェック
                    message = ValidatorMessage.REQUIRED.getMessae(Label.patternName.getLabel());
                } else if (!ValidationUtils.isByteOver(patternName, 256)) {
                    // 桁数チェック
                    message = ValidatorMessage.BYTE_OVER_HAN_ZEN.getMessae(Label.patternName.getLabel(), 256, ValidationUtils.getZenCharCount(256));
                } else {
                    // 重複指定チェック
                    Integer count = nameMapCount.get(patternName);
                    if (count > 1) {
                        message = ValidatorMessage.REPEAT_DATA_ERROR.getMessae(Label.patternName.getLabel());
                    }
                }
                
                if (StringUtils.isNotEmpty(message)) {
                    validationMessageBean.setErrorInfo(errorKey, message);
                }
            }
        }
  
        return validationMessageBean.isSuccess();
    }

    /**
     * 初期表示時機能
     * @throws Exception
     */
    public void indexExecute() throws Exception {
        List<SyuSearchPatternTbl> list = syuSearchPatternTblFacade.findSearchPatternList(loginUserInfo.getUserId(), s021Bean.getDisplayId());
        s021Bean.setDispPatternList(list);
    }

    /**
     * 検索パターンの追加 処理
     */
    public void addPatternExecute() throws Exception {
        Integer newPatternSeq = syuSearchPatternTblFacade.getCreatePatternSeq(loginUserInfo.getUserId(), s021Bean.getDisplayId());

        // 入力したパターン名称が既に登録済みであるかをチェック(登録済みの場合はそのレコード情報も取得)
        SyuSearchPatternTbl patternEntity = getSearchPatternName();
        
        if (patternEntity == null) {
            ////// 入力したパターン名が存在しない場合
            // パターン名称の追加
            addPattern(newPatternSeq);

            // 検索条件の追加
            addPatternCol(newPatternSeq);
        } else {
            ////// 存在する場合
            // パターン名称の更新(更新日を変更したい)
            updatePatternNameNowData(patternEntity);
            
            // 検索条件の変更(削除→追加)
            addPatternCol(new Integer(patternEntity.getPatternSeq()));
        }
    }

    /**
     * 検索パターンの更新・削除 処理
     */
    public void updatePatternExecute() throws Exception {
        log.info("updatePatternList={}", s021Bean.getUpdatePatternList());
        
        if (CollectionUtils.isNotEmpty(s021Bean.getUpdatePatternList())) {
            // 削除対象の検索パターンを削除
            deletePattern();

            // 更新対象の検索パターンを更新
            updatePatternName();
        }
    }
    
    /**
     * 検索パターンの取得用API
     * @throws Exception
     */
    public void searchPatternApiExecute() throws Exception {
        List<SyuSearchPatternTbl> list = syuSearchPatternTblFacade.findSearchPatternList(loginUserInfo.getUserId(), s021Bean.getDisplayId());
        s021Bean.setDispPatternList(list);
    }

    /**
     * 選択した画面・パターンの検索条件をコピーする(検索条件を利用する各検索一覧画面の[パターン検索]メニューで利用)
     * @param destBean データのコピー元となるbean
     * @throws Exception
     */
    public void copySearchPattern(Object destBean) throws Exception {
        Map<String, List<String>> condition = getConditionMap();
        log.info("copy condition={}", condition);

        Set<Map.Entry<String, List<String>>> entrySet = condition.entrySet();
        Iterator<Map.Entry<String, List<String>>> ite = entrySet.iterator();

        while(ite.hasNext()) {
            Map.Entry<String, List<String>> entry = ite.next();
            String key = entry.getKey();
            List<String> targetValue = entry.getValue();
            boolean isSetValue = false;

            if (targetValue.size() == 1) {
                try {
//                  log.info("conditon name=[{}] type=[] editerClass=[{}]", key, PropertyUtils.getPropertyType(destBean, key), PropertyUtils.getPropertyEditorClass(destBean, key));
                    //PropertyUtils.setProperty(destBean, key, targetValue.get(0));
                    BeanUtils.setProperty(destBean, key, targetValue.get(0));
                    isSetValue = true;
                    log.info("copy single property key=[{}] value=[{}]", key, targetValue);
                //} catch (NoSuchMethodException e) {
                //    log.info("NoSuchMethodException copy single key=[{}] value=[{}]", key, targetValue);
                } catch (Exception e) {
                    log.info("Exception copy single key=[{}] value=[{}] exception=[{}]", key, targetValue, e.getMessage());
                }
            }

            if (!isSetValue) {
                try {
                    String[] values = (String[])targetValue.toArray(new String[0]);
                    BeanUtils.setProperty(destBean, key, values);
                    log.info("copy list property key=[{}] value=[{}]", key, values);
                //} catch (NoSuchMethodException e) {
                //    log.info("NoSuchMethodException copy list key=[{}] value=[{}]", key, targetValue);
                } catch (Exception e) {
                    log.info("Exception list single key=[{}] value=[{}] exception=[{}]", key, targetValue, e.getMessage());
                }
            }
        }

    }
    
    /**
     * 検索パターンを取得して、Mapに変換
     * (1データはString 同一キーで複数データ存在する場合はList変換)
     * @throws Exception
     */
    private Map<String, List<String>> getConditionMap() {
        List<SyuSearchPatternColTbl> list = syuSearchPatternTblFacade.findSearchPatternColList(loginUserInfo.getUserId(), s021Bean.getDisplayId(), s021Bean.getPatternSeq());
        Map<String, List<String>> condition = new HashMap<>();
        
        for (SyuSearchPatternColTbl entity: list) {
            String name = entity.getColName();
            String value = StringUtils.defaultString(entity.getColValue());
            
            if (StringUtils.isNotEmpty(name)) {
                List<String> targetValue;
                // 同一検索条件データ(チェックボックス等の条件データ)はList化する。
                if (condition.containsKey(name)) {
                    targetValue = condition.get(name);
                    targetValue.add(value);

                } else {
                    targetValue = new ArrayList<>();
                    targetValue.add(value);
                }
                
                condition.put(name, targetValue);
            }
        }
        
        return condition;
    }
    
    /**
     * 登録済パターンを取得
     */
    private SyuSearchPatternTbl getSearchPatternName() {
        SyuSearchPatternTbl entity = syuSearchPatternTblFacade.findSearchPatternName(loginUserInfo.getUserId(), s021Bean.getDisplayId(), s021Bean.getNewPatternName());
        return entity;
    }
    
    /**
     * 検索パターン名称の追加
     */
    private void addPattern(Integer newPatternSeq) {
        Map<String, Object> params = getBaseCondition();
        params.put("patternSeq", newPatternSeq);
        params.put("patternName", s021Bean.getNewPatternName());
        EntityUtils.setCreatedInfo(params, loginUserInfo.getUserId());

        syuSearchPatternTblFacade.insertSearchPattern(params);
    }

    /**
     * 検索条件の追加
     */
    private void addPatternCol(Integer newPatternSeq) {
        List<Map<String, String>> conditionList = s021Bean.getConditionList();

        if (CollectionUtils.isNotEmpty(conditionList)) {
            Map<String, Object> condtion = getBaseCondition();
            condtion.put("patternSeq", newPatternSeq);
            EntityUtils.setCreatedInfo(condtion, loginUserInfo.getUserId());
            
            syuSearchPatternTblFacade.deleteSearchPatternCol(condtion);

            Integer index = 1;
            for (Map<String, String> data: conditionList) {
                condtion.put("colSeq", index);
                condtion.put("colName", StringUtils.defaultString((String)data.get("name")));
                condtion.put("colValue", StringUtils.defaultString((String)data.get("value")));
                
                syuSearchPatternTblFacade.insertSearchPatternCol(condtion);
                
                index++;
            }
        }
    }

    /**
     * 検索パターンの削除
     */
    private void deletePattern() {
        Map<String, Object> condtion = getBaseCondition();
        String[] selectedIndexs = s021Bean.getSelectedIndex();
        
        List<Map<String, String>> patternList = s021Bean.getUpdatePatternList();
        List<Map<String, String>> deleteDataList = new ArrayList<>();

        if (selectedIndexs != null) {
            for (String strIndex: selectedIndexs) {
                int idx = Integer.parseInt(strIndex);
                
                Map<String, String> data = patternList.get(idx);

                Short patternSeq = Short.parseShort((String)data.get("patternSeq"));
                condtion.put("patternSeq", patternSeq);
                
                // 検索パターン削除
                syuSearchPatternTblFacade.deleteSearchPattern(condtion);

                // 検索パターンの各検索条件を削除
                syuSearchPatternTblFacade.deleteSearchPatternCol(condtion);

                deleteDataList.add(data);
            }
        }

        // 削除対象のデータを一覧変数から削除(更新時にこれらが対象にならないようにするため)
        if (CollectionUtils.isNotEmpty(deleteDataList)) {
            for (Map<String, String> data: deleteDataList) {
                patternList.remove(data);
            }
        }

    }

    /**
     * 検索パターン名の更新
     */
    private void updatePatternName() {
        Map<String, Object> condtion = getBaseCondition();
        EntityUtils.setCreatedInfo(condtion, loginUserInfo.getUserId());

        List<Map<String, String>> patternList = s021Bean.getUpdatePatternList();

        if (CollectionUtils.isNotEmpty(s021Bean.getUpdatePatternList())) {
            for (Map<String, String> data: patternList) {
                Short patternSeq = Short.parseShort((String)data.get("patternSeq"));
                condtion.put("patternSeq", patternSeq);
                condtion.put("patternName", StringUtils.defaultString((String)data.get("patternName")));
                condtion.put("patternChangeFlg", "1");
                
                syuSearchPatternTblFacade.updateSearchPattern(condtion);
            }
        }
    }

    /**
     * 検索パターン名の更新(パターン追加時の既存パターン変更時)
     */
    private void updatePatternNameNowData(SyuSearchPatternTbl patternEntity) {
        Map<String, Object> condtion = getBaseCondition();
        condtion.put("patternSeq", patternEntity.getPatternSeq());
        condtion.put("patternName", s021Bean.getNewPatternName());
        EntityUtils.setCreatedInfo(condtion, loginUserInfo.getUserId());
        
        syuSearchPatternTblFacade.updateSearchPattern(condtion);
    }

    /**
     * パターン名称 重複チェック
     */
//    private boolean isCheckPatternNameRepeat(String patternName) {
//        Map<String, Object> condition = getBaseCondition();
//        condition.put("matchPatternName", patternName);
//
//        Integer count = syuSearchPatternTblFacade.countSearchPatternName(loginUserInfo.getUserId(), s021Bean.getDisplayId(), patternName);
//        if (count > 0) {
//            return false;
//        }
//        return true;
//    }

    /**
     * 基本的な条件を取得
     */
    private Map<String, Object> getBaseCondition() {
        Map<String, Object> baseCondition = new HashMap<>();
        baseCondition.put("idtuid", loginUserInfo.getUserId());
        baseCondition.put("displayId", s021Bean.getDisplayId());
        return baseCondition;
    }
    
}
