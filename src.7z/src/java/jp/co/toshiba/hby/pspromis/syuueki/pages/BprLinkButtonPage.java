package jp.co.toshiba.hby.pspromis.syuueki.pages;

import javax.inject.Inject;
import javax.inject.Named;
import javax.enterprise.context.RequestScoped;
import jp.co.toshiba.hby.pspromis.syuueki.bean.BprLinkBean;
import jp.co.toshiba.hby.pspromis.syuueki.service.BprLinkService;
import lombok.Getter;
import lombok.Setter;

/**
 *
 * @author ibayashi
 */
@Named(value = "bprLinkButtonPage")
@RequestScoped
@Getter @Setter
public class BprLinkButtonPage {

    @Inject
    private BprLinkBean bprLinkBean;
    
    @Inject
    private BprLinkService bprLinkService;

    private String ankenId;
    
    private String rirekiId;
    
    private String rirekiFlg;
    
    private String procId;

    public void initProcess() throws Exception {
        setParameter();

        // ボタン表示判定
        bprLinkService.executeDispButton();
    }
    
    private void setParameter() {
        bprLinkBean.setAnkenId(ankenId);
        bprLinkBean.setRirekiId(rirekiId);
        bprLinkBean.setRirekiFlg(rirekiFlg);
        bprLinkBean.setProcId(procId);
    }

}
