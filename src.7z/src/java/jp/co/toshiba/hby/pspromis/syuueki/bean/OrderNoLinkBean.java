/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package jp.co.toshiba.hby.pspromis.syuueki.bean;

import java.util.List;
import javax.enterprise.context.RequestScoped;
import javax.inject.Named;
import jp.co.toshiba.hby.pspromis.syuueki.entity.SyuGeBukkenInfoTbl;
import lombok.Getter;
import lombok.Setter;

/**
 *
 * @author watabe
 */
@Named(value = "orderNoLinkBean")
@RequestScoped
@Getter @Setter
public class OrderNoLinkBean extends AbstractBean{
  
    //AbstractBeanと重複しないように気を付ける
    private List<SyuGeBukkenInfoTbl> syuGeBukkenInfoTblList; 
    
    private String orderNo;
    private String isDeleted;
    private String syuekiFlg;
    private String divisionCode;
    private String plantCode;
    private String mitumoriNo;
    private String ankenName;
    private String ankenFlg;
    private String ankenId;
    private String ankenRev;
    private String salesClass;
        
}
