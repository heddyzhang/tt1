/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package jp.co.toshiba.hby.pspromis.syuueki.entity;

import java.io.Serializable;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 *
 * @author sano
 */
@Entity
@Table(name = "PLANT_TYPE_MST")
public class PlantTypeMst implements Serializable {
    private static final long serialVersionUID = 1L;

    @Id
    @Column(name = "PLANT_TYPE_CODE")
    private String plantTypeCode;
    
    @Column(name = "PLANT_TYPE_NAME")
    private String plantTypeName;

/*
    @Column(name = "ID")
    @Id
    private long id;

    @Column(name = "PLANT_TYPE_CODE")
    private String plantTypeCode;
    
    @Column(name = "DIVISION_CODE")
    private String divisionCode;

    @Column(name = "N7_PLANT_TYPE_CODE")
    private String n7PlantTypeCode;

    @Column(name = "N8_PLANT_TYPE_CODE")
    private String n8PlantTypeCode;

    @Column(name = "BU_ID")
    private Long buId;

    @Column(name = "PLANT_TYPE_NAME")
    private String plantTypeName;

    @Column(name = "PLANT_TYPE_NAME_ENG")
    private String plantTypeNameEng;

    @Column(name = "AVAIL_FROM")
    @Temporal(TemporalType.TIMESTAMP)
    private Date availFrom;

    @Column(name = "AVAIL_TO")
    @Temporal(TemporalType.TIMESTAMP)
    private Date availTo;

    @Column(name = "ORDERED_BY")
    private Long orderedBy;

    @Column(name = "IS_DELETED")
    private short isDeleted;

    @Column(name = "CREATED_AT")
    @Temporal(TemporalType.TIMESTAMP)
    private Date createdAt;

    @Column(name = "CREATED_BY")
    private String createdBy;

    @Column(name = "UPDATED_AT")
    @Temporal(TemporalType.TIMESTAMP)
    private Date updatedAt;

    @Column(name = "UPDATED_BY")
    private String updatedBy;

    @Column(name = "DELETED_AT")
    @Temporal(TemporalType.TIMESTAMP)
    private Date deletedAt;

    @Column(name = "DELETED_BY")
    private String deletedBy;

    @Column(name = "SBU_CODE")
    private String sbuCode;
*/
    public PlantTypeMst() {
    }

    public String getPlantTypeCode() {
        return plantTypeCode;
    }

    public void setPlantTypeCode(String plantTypeCode) {
        this.plantTypeCode = plantTypeCode;
    }

    public String getPlantTypeName() {
        return plantTypeName;
    }

    public void setPlantTypeName(String plantTypeName) {
        this.plantTypeName = plantTypeName;
    }

}
