package jp.co.toshiba.hby.pspromis.syuueki.servlet;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import javax.inject.Inject;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpServletRequest;
import jp.co.toshiba.hby.pspromis.syuueki.bean.ResultMessageBean;
import jp.co.toshiba.hby.pspromis.syuueki.bean.S002Bean;
import jp.co.toshiba.hby.pspromis.syuueki.facade.SysdateEntityFacade;
import jp.co.toshiba.hby.pspromis.syuueki.service.S002DownloadService;
import jp.co.toshiba.hby.pspromis.syuueki.service.S002Service;
import jp.co.toshiba.hby.pspromis.syuueki.service.StoredProceduresService;
import jp.co.toshiba.hby.pspromis.syuueki.util.DetailExcelUtils;
import jp.co.toshiba.hby.pspromis.syuueki.util.FileUtils;
import jp.co.toshiba.hby.pspromis.syuueki.util.ParameterBinder;
import jp.co.toshiba.hby.pspromis.syuueki.util.PoiUtil;
import jp.co.toshiba.hby.pspromis.syuueki.util.CdiUtils;
import org.apache.poi.ss.usermodel.Workbook;

/**
 * PS-Promis収益管理システム
 * 最終見込損益 Servlet
 * @author (NPC)K.Sano
 */
@WebServlet(name="S002", urlPatterns={"/servlet/S002", "/servlet/S002/*"})
public class S002Servlet extends AbstractServlet {

    /**
     * jsp
     */
    private static final String INDEX_JSP = "S002/s002.jsp";

    /**
     * 使用serviceクラスをinjection(CDI)<br>
     * InjectアノテーションよりAPサーバー(Glassfish)側で自動的にインスタンス作成(new)される。<br>
     * service側はステートレスセッションbeanにするため、Statelessアノテーションをつけておくこと。<br>
     */
    @Inject
    private S002Service s002Service;

    @Inject
    private S002DownloadService s002DlService;

    @Inject
    private StoredProceduresService storedProceduresService;
    
    @Inject
    private SysdateEntityFacade sysdateFacade;
    
    /**
     * パラメータ格納クラスをinjection(CDI)<br>
     * InjectアノテーションよりAPサーバー(Glassfish)側で自動的にインスタンス作成(new)される。<br>
     */
    @Inject
    private S002Bean s002Bean;

    /**
     * 初期表示
     * @param req
     * @param resp
     * @return
     * @throws Exception 
     */
    public String indexAction(HttpServletRequest req, HttpServletResponse resp)
    throws Exception {
        logger.info("S002Servlet#indexAction");

        // リクエストパラメータをs002Beanの同名フィールドに一括コピー
        ParameterBinder.Bind(s002Bean, req);

        s002Service.indexExecute();

        return INDEX_JSP;
    }
    
    /**
     * Excelダウンロード処理
     * @param req
     * @param resp
     * @return
     * @throws Exception 
     */
    public String outputCsvAction(HttpServletRequest req, HttpServletResponse resp) throws Exception {
        ParameterBinder.Bind(s002Bean, req);
        
        Date now = sysdateFacade.getSysdate();
        SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMddHHmm");
        
        // テンプレートファイルの読み込み
        //String filePath = req.getServletContext().getRealPath("WEB-INF/template/saishuMikomiSoneki_template.xlsx");
        String filePath = req.getServletContext().getRealPath("WEB-INF/template/ankenDetail_template.xlsx");
        Workbook workbook = PoiUtil.getWorkbook(new File(filePath));
        
        // 上記で読み込みしたテンプレートファイルは案件の詳細全般で利用しているものなので、
        // 不要なシートを全て削除する(最終見込損益で利用するシート以外を全て削除)
        DetailExcelUtils.leaveDetailSheet(workbook, "saisyu");

        // テンプレートにデータ埋め込み
        s002DlService.outputDownloadExcel(workbook);
        
        // テンプレート出力
        // ファイル名「[案件番号]_期間損益_[YYYYMMDDHH24MI].xlsx」
        FileUtils.httpDownloadExcelResponse(workbook, s002Bean.getAnkenId() + "_最終期間損益_" + sdf.format(now) + ".xlsx", resp);

        return null;
    }
    
    /**
     * 保存処理
     * @param req
     * @param resp
     * @return
     * @throws Exception 
     */
    public String saveAction(HttpServletRequest req, HttpServletResponse resp)
    throws Exception {
        logger.info("S002Servlet#saveAction");

        // リクエストパラメータをs002Beanの同名フィールドに一括コピー
        ParameterBinder.Bind(s002Bean, req);

        s002Service.saveExecute(0);

        // (原子力)連携バッチを実行
        //storedProceduresService.callN7RenkeiBatchJudge(s002Bean.getAnkenId(), s002Bean.getRirekiId());
        
        // 処理結果を戻す。
        Map<String, Object> jsonMap = new HashMap<>();
        ResultMessageBean resultMessageBean = CdiUtils.getBean(ResultMessageBean.class);
        resultMessageBean.createResultMessage(jsonMap);
        resopnseDecodeJson(resp, jsonMap);

        return null;
    }

    /**
     * 最新値更新
     */
    public String updateNewDataAction(HttpServletRequest req, HttpServletResponse resp)
    throws Exception {
        logger.info("S002Servlet#updateNewData");

        ParameterBinder.Bind(s002Bean, req);

        if (s002Bean.isEdit()) {
            // 更新モードの場合は画面の値も更新する
            s002Service.saveExecute(1);
        } else {
            // 参照モード
            s002Service.callUpdateDataProcedureExecute(1);
        }

        // 処理結果を戻す。
        Map<String, Object> jsonMap = new HashMap<>();
        ResultMessageBean resultMessageBean = CdiUtils.getBean(ResultMessageBean.class);
        resultMessageBean.createResultMessage(jsonMap);
        resopnseDecodeJson(resp, jsonMap);
        
        return null;
    }
}
