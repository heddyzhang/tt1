package jp.co.toshiba.hby.pspromis.syuueki.bean;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.List;
import java.util.Map;
import javax.enterprise.context.RequestScoped;
import javax.inject.Named;
import jp.co.toshiba.hby.pspromis.syuueki.entity.SyuGeBukkenInfoTblView;
import jp.co.toshiba.hby.pspromis.syuueki.entity.SyuWfControlTbl;
import org.apache.commons.lang3.StringUtils;
import lombok.Getter;
import lombok.Setter;
/**
 *
 * @author ibayashi
 */
@Named(value = "s001Bean")
@RequestScoped
@Getter @Setter
public class S001Bean extends AbstractBean {

    /**
     * 一覧検索フラグ
     */
    private String listFlg = "0";

    /**
     * 検索条件：事業部
     */
    //@NotNull
    //private String[] divisionCode;
    private String divisionCode;
    
    //private String divDen;

    /**
     * 検索条件：事業部・原子力
     */
    //private String divGen;

    /**
     * 検索条件：事業部・火水ジ
     */
    //private String divKa;

    /**
     * buコード
     */
    private String[] buId;

    /**
     * サブBUコード
     */
    private String[] subBuId;

    /**
     * 担当物件のみ
     */
    private String tantoOnlyKbn;

    /**
     * My案件Flg
     */
    private String myTeamFlg;

    /**
     * 検索条件・チームコード(プルダウン)
     */
    private String myTeamCd;

    /**
     * 検索条件・チームコード(本社)
     */
    private String teamCode;
    
    /**
     * 検索条件・チームコード(販売C)
     */
    private String hanbaiCode;

    /**
     * 検索条件・担当部門（組織）コード
     */
    private String tantoBumonCode;
    
    /**
     * 検索条件・担当部門（組織）名
     */
    private String tantoBumonName;
    
    /**
     * 検索条件・営業担当JobGrコード
     */
    private String eigyoTanJobgrCode;
    
    /**
     * 検索条件・営業担当JobGr名
     */
    private String eigyoTanJobgrName;

    /**
     * 検索条件・原価/バック営業JobGrコード
     */
    private String genkaJobgrCode;

    /**
     * 検索条件・原価/バック営業JobGr名
     */
    private String genkaJobgrName;

    /**
     * 検索条件・受注年月From
     */
    private String juchuYmFrom;

    /**
     * 検索条件・受注年月To
     */
    private String juchuYmTo;

    /**
     * 検索条件・受注年月/売上年月(and/or)
     */
    private String juYmJoken;

    /**
     * 検索条件・売上開始年月From
     */
    private String uriageStartYmFrom;
    
    /**
     * 検索条件・売上開始年月To
     */
    private String uriageStartYmTo;

    /**
     * 検索条件・売上予定From
     */
    private String uriageYoteiYmFrom;
    
    /**
     * 検索条件・売上予定To
     */
    private String uriageYoteiYmTo;

    /**
     * 検索条件・売上基準(進行基準)
     */
    private String[] salesClass;
    
    /**
     * 検索条件・注番
     */
    private String orderNo;
 
    /**
     * 検索条件・項番
     */
    private String koban;

    /**
     * 検索条件・見積番号
     */
    private String qno;

    /**
     * 検索条件・案件名称
     */
    private String ankenName;

    /**
     * 検索条件・注文主名
     */
    private String tradeName;
    
    /**
     * 検索条件・設置先コード
     */
    private String stchCode;

    /**
     * 検索条件・設置先名称
     */
    private String stchName;
    
    /**
     * 検索条件・ステージ
     */
    private BigDecimal stageId;

    /**
     * 検索条件・表示単位
     */
    private String dispKbn;

    /**
     * 検索条件・収益分類
     */
    private String bunruiCd;

    /**
     * 検索条件・見積種類
     */
    private String[] mitumoriKbn;
    
    /**
     * 検索条件・サイト
     */
    private String site;
    
    /**
     * 検索条件・プラントコード
     */
    private String plantCode;
    
    /**
     * 検索条件・実施年度
     */
    private String jissiNendo;

    /**
     * 検索条件・定件回数
     */
    private String teiken;

    /**
     * 検索条件・ISP区分(ISPのみ)
     */
    private String[] ispKbn;

    /**
     * 検索条件・売上FLG
     */
    private String[] uriageEndFlg;

    /**
     * 検索条件・売上FLG(売上区分 含む/含まない)
     */
    private String uriageTouKanbaiKbn;

    /**
     * 検索条件・収益管理対象
     */
    private String syuekiControlKbn;
    
    /**
     * 検索条件・ソート順1
     */
    private String sort1;

    /**
     * 検索条件・ソート順1区分(昇順/降順)
     */
    private String sort1Kbn;
    
    /**
     * 検索条件・ソート順2
     */
    private String sort2;

    /**
     * 検索条件・ソート順2区分(昇順/降順)
     */
    private String sort2Kbn;

    /**
     * My案件Flg
     */
    private String myAnkenFlg;

    /**
     * My案件KBN(JobGr:J 個人:K)
     */
    private String myAnkenKbn;
    
    /**
     * My案件検索・JobGr
     */
    private String myAnkenJobGr;
    
    /**
     * My案件検索・担当者
     */
    private String myAnkenTanto;

    /**
     * 一覧表示データ総件数
     */
    private Integer count;

    /**
     * 現在表示するページ番号
     */
    private Integer page;

    /**
     * 一覧・SP合計
     */
    private BigInteger sumSp;
    
    /**
     * 一覧・NET合計
     */
    private BigInteger sumNet;
    
     /**
     * 職種フラグ
     */
    private int shokushuFlg;

    /**
     * 一覧取得結果
     */
    private List<SyuGeBukkenInfoTblView> list;

    /**
     * BookMark検索Flg(2014下 add)
     */
    private String bookMarkFlg;

    /**
     * 検索タイプ<br/>
     * N：一般検索<br/>
     * D：詳細検索
     */
    private String listDispType;
    
    /**
     * 編集フラグ<br/>
     * 0：参照モード<br/>
     * 1：編集モード
     */
    private String editFlg;
    
    /**
     * 詳細検索<br/>
     * 0：非表示<br/>
     * 1：表示
     */
    private String detailFlg;

    /**
     * データ種別<br/>
     * O：原案<br/>
     * M：月次確定<br/>
     * Y：予算
     */
    private String dataKbn;

    /**
     * データ種別(対象月)
     */
    private String taishoYm;

    /**
     * 出荷日限
     */
    private String forwardTermYmFrom;
    private String forwardTermYmTo;

    /**
     * 回収予定
     */
    private String recoveryYoteiYmFrom;
    private String recoveryYoteiYmTo;
    
    /**
     * S/N発
     */
    private String[] snHatsuban;
    
    /**
     * 甲乙
     */
    private String[] discrimination;

    /**
     * 業態
     */
    private String gyotaiCd;

    /**
     * SP
     */
    private String spFrom;
    private String spTo;

    /**
     * NET
     */
    private String netFrom;
    private String netTo;

    /**
     * M率
     */
    private String mrateFrom;
    private String mrateTo;

    /**
     * 受注残<br/>
     * A：全て<br/>
     * E：受注残あり
     */
    private String juchuZan;

    
    /**
     * 営業担当
     */
    private String eigyoJobGrId;

    /**
     * 回収月(from,to)
     */
    private String kaisyuYmFrom;
    private String kaisyuYmTo;
    
    /**
     * 売上指示状況
     */
    private String[] uriageShijiFlg;
    
    /**
     * 売上修正対象
     */
    private String uriSyuseiFlg;
    
    /**
     * 契約形態
     */
    private String keiyakuKeitaiCd;
    
    /**
     * 案件状況(最新見積回答あり)
     */
    private String ankenJyokyoMitKaitoFlg;
    
    /**
     * 案件状況(最新調達回答あり)
     */
    private String ankenJyokyoSateiKaitoFlg;
    
    /**
     * 案件状況(問題案件)
     */
    private String ankenJyokyoMondaiFlg;
    
    /**
     * 案件状況(ポテンシャル管理)
     */
    private String ankenJyokyoPotentialFlg;
    
    /**
     * 案件状況(見込未入力)
     */
    private String ankenJyokyoMikomiFlg;
    
    /**
     * 案件状況(仮売上あり)
     */
    private String ankenJyokyoKariUriFlg;
    
    /**
     * 見込金額　確定状況(SP未確定)
     */
    private String spKakuteiFlg;
    
    /**
     * 見込金額　確定状況(NET未確定)
     */
    private String netKakuteiFlg;
    
    /**
     * 案件ランク
     */
    private String[] ankenRank;
    
    /**
     * A/#
     */
    private String aNo;

    /**
     * 白地調整案件Flg
     */
    private String shirajiDelFlg;
    
    /**
     * 履歴ID(カンマ区切り)
     */
    private String rirekiIdList;
    
    /**
     * 保存項目
     */
    private String[] listSaveFlg;
    private String[] listGaikaFlg;
    private String[] listAnkenId;
    private String[] listRirekiId;
    private String[] listCurCode;
    private String[] listSaisyuSpGaika;
    private String[] listSaisyuJyuchuRate;
    private String[] listSaisyuSp;
    private String[] listSaisyuNet;
    private String[] listJyuchuEnd;
    private String[] listUriageEnd;
    private String[] listBikou;

    /**
     * 勘定月
     */
    private String kanjyoYm;
    
    /**
     * 勘定月(翌月)
     */
    private String nextKankyoYm;
    
    /**
     * 勘定月の期初月
     */
    private String startKanjyoYm;
    
    /**
     * 勘定月の末月
     */
    private String endKanjyoYm;
    
    /**
     * 中計年度
     */
    private String chukeiNendo;

    /**
     * 円貨表示単位
     */
    private Integer jpyUnit = 1;

    private String jpyUnitKbn = "1";

    /**
     * 邦貨onlyフラグ
     */
    private boolean jpyOnlyFlg = true;

    /**
     * 対象選択候補の一覧
     */
    private List<SyuWfControlTbl> taishoList;

    // 出力時オプション子画面用 
    /**
     * 出力時オプション子画面:出力対象区分
     * 1:案件一覧(月展開) 2:サマリ表(月展開) 3:受注残一覧
     */
    private String outputKbn;
    
    /**
     * 出力時オプション子画面:展開　J：受注　U：売上
     */
    private String tenkaiKbn;
    
    /**
     * 出力時オプション子画面:対象 年
     */
    private String taishoY;
    
    /**
     *出力時オプション子画面: 対象 期　K：上期　S：下期
     */
    private String taishoKi;
    
    /**
     * 出力時オプション子画面:小計行　0：販売チーム　1：設置場所　9：なし
     */
    private String shokeiKbn;
    
    /**
     * 出力時オプション子画面:表示項目　S:SP、N:NET、A:粗利、M:M率
     */
    private String[] dispItemKbn;

    /**
     * 出力時オプション子画面:受注残表示　S:SP、I:ISP、N:NET、T:NET(転売)
     */
    private String[] juchuZanKbn;

    /**
     * 出力時指定オプション子画面:対象期間(年、期)が変更可能か？
     * 1:変更可能 0:変更不可
     */
    private String optionKiChangeFlg;

    /**
     * 出力時指定オプション子画面:合計行を計算式出力か？値か？
     * 1:計算式 0:値
     */
    private String optionSummaryKbn;

    private String[] optionTargetAnkenId;

    /**
     * パターン検索用のパターンSEQ(パターン検索ボタンで利用)
     */
    private String searchPatternSeq;

    /**
     * 事業部毎の編集可否判断用のList
     * 画面で事業部を切り替えた場合、My案件のFLGのON/OFFをjavascriptで制御するための情報
     *  Mapのkey=事業部コード
     *  Mapのvalue=1:全案件参照可能(My案件切り替え可能) 0:My案件のみ検索可能(My案件切り替え不可)
     */
    private Map<String, String> myAnkenDivisionAuthFlgInfo;
    
    //20180302 原価回収基準対応　ADD     
     /**
     * 検索条件・売上基準(原価回収基準)
     */
    private String salesClassGenka;
          
            
            
    /**
     * Creates a new instance of S001Bean
     */
    public S001Bean() {
    }

    public String getListFlg() {
        return listFlg;
    }

    public void setListFlg(String listFlg) {
        this.listFlg = listFlg;
    }

    public Integer getCount() {
        return count;
    }

    public void setCount(Integer count) {
        this.count = count;
    }

    public Integer getPage() {
        return page;
    }

    public void setPage(Integer page) {
        this.page = page;
    }

    public String getOrderNo() {
        return orderNo;
    }

    public void setOrderNo(String orderNo) {
        this.orderNo = orderNo;
    }

    public BigInteger getSumSp() {
        return sumSp;
    }

    public void setSumSp(BigInteger sumSp) {
        this.sumSp = sumSp;
    }

    public BigInteger getSumNet() {
        return sumNet;
    }

    public void setSumNet(BigInteger sumNet) {
        this.sumNet = sumNet;
    }

    public List<SyuGeBukkenInfoTblView> getList() {
        return list;
    }

    public void setList(List<SyuGeBukkenInfoTblView> list) {
        this.list = list;
    }

    public String getMyTeamFlg() {
        return myTeamFlg;
    }

    public void setMyTeamFlg(String myTeamFlg) {
        this.myTeamFlg = myTeamFlg;
    }

    public String getMyTeamCd() {
        return myTeamCd;
    }

    public void setMyTeamCd(String myTeamCd) {
        this.myTeamCd = myTeamCd;
    }

    public String getTeamCode() {
        return teamCode;
    }

    public void setTeamCode(String teamCode) {
        this.teamCode = teamCode;
    }

    public String getHanbaiCode() {
        return hanbaiCode;
    }

    public void setHanbaiCode(String hanbaiCode) {
        this.hanbaiCode = hanbaiCode;
    }

    public String getTantoBumonCode() {
        return tantoBumonCode;
    }

    public void setTantoBumonCode(String tantoBumonCode) {
        this.tantoBumonCode = tantoBumonCode;
    }

    public String getTantoBumonName() {
        return tantoBumonName;
    }

    public void setTantoBumonName(String tantoBumonName) {
        this.tantoBumonName = tantoBumonName;
    }
    
    public String getEigyoTanJobgrCode() {
        return eigyoTanJobgrCode;
    }

    public void setEigyoTanJobgrCode(String eigyoTanJobgrCode) {
        this.eigyoTanJobgrCode = eigyoTanJobgrCode;
    }

    public String getEigyoTanJobgrName() {
        return eigyoTanJobgrName;
    }

    public void setEigyoTanJobgrName(String eigyoTanJobgrName) {
        this.eigyoTanJobgrName = eigyoTanJobgrName;
    }

    public String getGenkaJobgrCode() {
        return genkaJobgrCode;
    }

    public void setGenkaJobgrCode(String genkaJobgrCode) {
        this.genkaJobgrCode = genkaJobgrCode;
    }

    public String getGenkaJobgrName() {
        return genkaJobgrName;
    }

    public void setGenkaJobgrName(String genkaJobgrName) {
        this.genkaJobgrName = genkaJobgrName;
    }

    public String[] getSalesClass() {
        return salesClass;
    }

    public void setSalesClass(String[] salesClass) {
        this.salesClass = salesClass;
    }

    public String getKoban() {
        return koban;
    }

    public void setKoban(String koban) {
        this.koban = koban;
    }

    public String getQno() {
        return qno;
    }

    public void setQno(String qno) {
        this.qno = qno;
    }

    public String getAnkenName() {
        return ankenName;
    }

    public void setAnkenName(String ankenName) {
        this.ankenName = ankenName;
    }

    public String getStchCode() {
        return stchCode;
    }

    public void setStchCode(String stchCode) {
        this.stchCode = stchCode;
    }

    public String getStchName() {
        return stchName;
    }

    public void setStchName(String stchName) {
        this.stchName = stchName;
    }

    public String getDispKbn() {
        return dispKbn;
    }

    public void setDispKbn(String dispKbn) {
        this.dispKbn = dispKbn;
    }

    public String getPlantCode() {
        return plantCode;
    }

    public void setPlantCode(String plantCode) {
        this.plantCode = plantCode;
    }

    public String getJissiNendo() {
        return jissiNendo;
    }

    public void setJissiNendo(String jissiNendo) {
        this.jissiNendo = jissiNendo;
    }

    //@Digits(integer=4, fraction=0, message="{integerError}")
    //@Pattern(regexp="^[0-9]+$/", message="{integerError}")
    public String getTeiken() {
        return teiken;
    }

    public void setTeiken(String teiken) {
        this.teiken = teiken;
    }

    public String[] getIspKbn() {
        return ispKbn;
    }

    public void setIspKbn(String[] ispKbn) {
        this.ispKbn = ispKbn;
    }

    public String getSort1() {
        return sort1;
    }

    public void setSort1(String sort1) {
        this.sort1 = sort1;
    }

    public String getSort1Kbn() {
        return sort1Kbn;
    }

    public void setSort1Kbn(String sort1Kbn) {
        this.sort1Kbn = sort1Kbn;
    }

    public String getSort2() {
        return sort2;
    }

    public void setSort2(String sort2) {
        this.sort2 = sort2;
    }

    public String getSort2Kbn() {
        return sort2Kbn;
    }

    public void setSort2Kbn(String sort2Kbn) {
        this.sort2Kbn = sort2Kbn;
    }

    public String getTantoOnlyKbn() {
        return tantoOnlyKbn;
    }

    public void setTantoOnlyKbn(String tantoOnlyKbn) {
        this.tantoOnlyKbn = tantoOnlyKbn;
    }

    public String getSite() {
        return site;
    }

    public void setSite(String site) {
        this.site = site;
    }

    public BigDecimal getStageId() {
        return stageId;
    }

    public void setStageId(BigDecimal stageId) {
        this.stageId = stageId;
    }

    public String getBunruiCd() {
        return bunruiCd;
    }

    public void setBunruiCd(String bunruiCd) {
        this.bunruiCd = bunruiCd;
    }

    public String[] getMitumoriKbn() {
        return mitumoriKbn;
    }

    public void setMitumoriKbn(String[] mitumoriKbn) {
        this.mitumoriKbn = mitumoriKbn;
    }

    public String[] getSubBuId() {
        return subBuId;
    }

    public void setSubBuId(String[] subBuId) {
        this.subBuId = subBuId;
    }

    public String[] getBuId() {
        return buId;
    }

    public void setBuId(String[] buId) {
        this.buId = buId;
    }

    public String getUriageYoteiYmFrom() {
        return uriageYoteiYmFrom;
    }

    public void setUriageYoteiYmFrom(String uriageYoteiYmFrom) {
        this.uriageYoteiYmFrom = uriageYoteiYmFrom;
    }

    public String getUriageYoteiYmTo() {
        return uriageYoteiYmTo;
    }

    public void setUriageYoteiYmTo(String uriageYoteiYmTo) {
        this.uriageYoteiYmTo = uriageYoteiYmTo;
    }

    public String[] getUriageEndFlg() {
        return uriageEndFlg;
    }

    public void setUriageEndFlg(String[] uriageEndFlg) {
        this.uriageEndFlg = uriageEndFlg;
    }
    
    public int getShokushuFlg() {
        return shokushuFlg;
    }

    public void setShokushuFlg(int shokushuFlg) {
        this.shokushuFlg = shokushuFlg;
    }
    
    public String getBookMarkFlg() {
        return bookMarkFlg;
    }

    public void setBookMarkFlg(String bookMarkFlg) {
        this.bookMarkFlg = bookMarkFlg;
    }

    public String getMyAnkenJobGr() {
        return myAnkenJobGr;
    }

    public void setMyAnkenJobGr(String myAnkenJobGr) {
        this.myAnkenJobGr = myAnkenJobGr;
    }

    public String getMyAnkenTanto() {
        return myAnkenTanto;
    }

    public void setMyAnkenTanto(String myAnkenTanto) {
        this.myAnkenTanto = myAnkenTanto;
    }

    public String getMyAnkenFlg() {
        return myAnkenFlg;
    }

    public void setMyAnkenFlg(String myAnkenFlg) {
        this.myAnkenFlg = myAnkenFlg;
    }

    public String getMyAnkenKbn() {
        return myAnkenKbn;
    }

    public void setMyAnkenKbn(String myAnkenKbn) {
        this.myAnkenKbn = myAnkenKbn;
    }

    public String getJuchuYmFrom() {
        return juchuYmFrom;
    }

    public void setJuchuYmFrom(String juchuYmFrom) {
        this.juchuYmFrom = juchuYmFrom;
    }

    public String getJuchuYmTo() {
        return juchuYmTo;
    }

    public void setJuchuYmTo(String juchuYmTo) {
        this.juchuYmTo = juchuYmTo;
    }

    public String getUriageStartYmFrom() {
        return uriageStartYmFrom;
    }

    public void setUriageStartYmFrom(String uriageStartYmFrom) {
        this.uriageStartYmFrom = uriageStartYmFrom;
    }

    public String getUriageStartYmTo() {
        return uriageStartYmTo;
    }

    public void setUriageStartYmTo(String uriageStartYmTo) {
        this.uriageStartYmTo = uriageStartYmTo;
    }

    public String getListDispType() {
        return listDispType;
    }

    public void setListDispType(String listDispType) {
        this.listDispType = listDispType;
    }

    public String getEditFlg() {
        return editFlg;
    }

    public void setEditFlg(String editFlg) {
        this.editFlg = editFlg;
    }

    public String getDetailFlg() {
        return detailFlg;
    }

    public void setDetailFlg(String detailFlg) {
        this.detailFlg = detailFlg;
    }

    public String getTradeName() {
        return tradeName;
    }

    public void setTradeName(String tradeName) {
        this.tradeName = tradeName;
    }

    public String getDataKbn() {
        return dataKbn;
    }

    public void setDataKbn(String dataKbn) {
        this.dataKbn = dataKbn;
    }

    public String getTaishoYm() {
        return taishoYm;
    }

    public void setTaishoYm(String taishoYm) {
        this.taishoYm = taishoYm;
    }

    public String getForwardTermYmFrom() {
        return forwardTermYmFrom;
    }

    public void setForwardTermYmFrom(String forwardTermYmFrom) {
        this.forwardTermYmFrom = forwardTermYmFrom;
    }

    public String getForwardTermYmTo() {
        return forwardTermYmTo;
    }

    public void setForwardTermYmTo(String forwardTermYmTo) {
        this.forwardTermYmTo = forwardTermYmTo;
    }

    public String getRecoveryYoteiYmFrom() {
        return recoveryYoteiYmFrom;
    }

    public void setRecoveryYoteiYmFrom(String recoveryYoteiYmFrom) {
        this.recoveryYoteiYmFrom = recoveryYoteiYmFrom;
    }

    public String getRecoveryYoteiYmTo() {
        return recoveryYoteiYmTo;
    }

    public void setRecoveryYoteiYmTo(String recoveryYoteiYmTo) {
        this.recoveryYoteiYmTo = recoveryYoteiYmTo;
    }

    public String[] getSnHatsuban() {
        return snHatsuban;
    }

    public void setSnHatsuban(String[] snHatsuban) {
        this.snHatsuban = snHatsuban;
    }

    public String[] getDiscrimination() {
        return discrimination;
    }

    public void setDiscrimination(String[] discrimination) {
        this.discrimination = discrimination;
    }

    public String getGyotaiCd() {
        return gyotaiCd;
    }

    public void setGyotaiCd(String gyotaiCd) {
        this.gyotaiCd = gyotaiCd;
    }

    public String getSpFrom() {
        return spFrom;
    }

    public void setSpFrom(String spFrom) {
        this.spFrom = spFrom;
    }

    public String getSpTo() {
        return spTo;
    }

    public void setSpTo(String spTo) {
        this.spTo = spTo;
    }

    public String getNetFrom() {
        return netFrom;
    }

    public void setNetFrom(String netFrom) {
        this.netFrom = netFrom;
    }

    public String getNetTo() {
        return netTo;
    }

    public void setNetTo(String netTo) {
        this.netTo = netTo;
    }

    public String getMrateFrom() {
        return mrateFrom;
    }

    public void setMrateFrom(String mrateFrom) {
        this.mrateFrom = mrateFrom;
    }

    public String getMrateTo() {
        return mrateTo;
    }

    public void setMrateTo(String mrateTo) {
        this.mrateTo = mrateTo;
    }

    public String getJuchuZan() {
        return juchuZan;
    }

    public void setJuchuZan(String juchuZan) {
        this.juchuZan = juchuZan;
    }

    public String getShirajiDelFlg() {
        return shirajiDelFlg;
    }

    public void setShirajiDelFlg(String shirajiDelFlg) {
        this.shirajiDelFlg = shirajiDelFlg;
    }

    public String getRirekiIdList() {
        return rirekiIdList;
    }

    public void setRirekiIdList(String rirekiIdList) {
        this.rirekiIdList = rirekiIdList;
    }

    public String[] getListSaveFlg() {
        return listSaveFlg;
    }

    public void setListSaveFlg(String[] listSaveFlg) {
        this.listSaveFlg = listSaveFlg;
    }

    public String[] getListGaikaFlg() {
        return listGaikaFlg;
    }

    public void setListGaikaFlg(String[] listGaikaFlg) {
        this.listGaikaFlg = listGaikaFlg;
    }

    public String[] getListAnkenId() {
        return listAnkenId;
    }

    public void setListAnkenId(String[] listAnkenId) {
        this.listAnkenId = listAnkenId;
    }

    public String[] getListRirekiId() {
        return listRirekiId;
    }

    public void setListRirekiId(String[] listRirekiId) {
        this.listRirekiId = listRirekiId;
    }

    public String[] getListCurCode() {
        return listCurCode;
    }

    public void setListCurCode(String[] listCurCode) {
        this.listCurCode = listCurCode;
    }

    public String[] getListSaisyuSpGaika() {
        return listSaisyuSpGaika;
    }

    public void setListSaisyuSpGaika(String[] listSaisyuSpGaika) {
        this.listSaisyuSpGaika = listSaisyuSpGaika;
    }

    public String[] getListSaisyuJyuchuRate() {
        return listSaisyuJyuchuRate;
    }

    public void setListSaisyuJyuchuRate(String[] listSaisyuJyuchuRate) {
        this.listSaisyuJyuchuRate = listSaisyuJyuchuRate;
    }

    public String[] getListSaisyuSp() {
        return listSaisyuSp;
    }

    public void setListSaisyuSp(String[] listSaisyuSp) {
        this.listSaisyuSp = listSaisyuSp;
    }

    public String[] getListSaisyuNet() {
        return listSaisyuNet;
    }

    public void setListSaisyuNet(String[] listSaisyuNet) {
        this.listSaisyuNet = listSaisyuNet;
    }

    public String[] getListJyuchuEnd() {
        return listJyuchuEnd;
    }

    public void setListJyuchuEnd(String[] listJyuchuEnd) {
        this.listJyuchuEnd = listJyuchuEnd;
    }

    public String[] getListUriageEnd() {
        return listUriageEnd;
    }

    public void setListUriageEnd(String[] listUriageEnd) {
        this.listUriageEnd = listUriageEnd;
    }

    public String[] getListBikou() {
        return listBikou;
    }

    public void setListBikou(String[] listBikou) {
        this.listBikou = listBikou;
    }

    public String getKanjyoYm() {
        return kanjyoYm;
    }

    public void setKanjyoYm(String kanjyoYm) {
        this.kanjyoYm = kanjyoYm;
    }

    public String getChukeiNendo() {
        return chukeiNendo;
    }

    public void setChukeiNendo(String chukeiNendo) {
        this.chukeiNendo = chukeiNendo;
    }

    public Integer getJpyUnit() {
        return jpyUnit;
    }

    public void setJpyUnit(Integer jpyUnit) {
        this.jpyUnit = jpyUnit;
    }

    public String getJpyUnitKbn() {
        return jpyUnitKbn;
    }

    public void setJpyUnitKbn(String jpyUnitKbn) {
        this.jpyUnitKbn = jpyUnitKbn;
    }

    public List<SyuWfControlTbl> getTaishoList() {
        return taishoList;
    }

    public void setTaishoList(List<SyuWfControlTbl> taishoList) {
        this.taishoList = taishoList;
    }

    public boolean isJpyOnlyFlg() {
        return jpyOnlyFlg;
    }

    public void setJpyOnlyFlg(boolean jpyOnlyFlg) {
        this.jpyOnlyFlg = jpyOnlyFlg;
    }

    public String getOutputKbn() {
        return outputKbn;
    }

    public void setOutputKbn(String outputKbn) {
        this.outputKbn = outputKbn;
    }

    public String getTenkaiKbn() {
        return tenkaiKbn;
    }

    public void setTenkaiKbn(String tenkaiKbn) {
        this.tenkaiKbn = tenkaiKbn;
    }

    public String getTaishoY() {
        return taishoY;
    }

    public void setTaishoY(String taishoY) {
        this.taishoY = taishoY;
    }

    public String getTaishoKi() {
        return taishoKi;
    }

    public void setTaishoKi(String taishoKi) {
        this.taishoKi = taishoKi;
    }

    public String getShokeiKbn() {
        return shokeiKbn;
    }

    public void setShokeiKbn(String shokeiKbn) {
        this.shokeiKbn = shokeiKbn;
    }

    public String[] getDispItemKbn() {
        return dispItemKbn;
    }

    public void setDispItemKbn(String[] dispItemKbn) {
        this.dispItemKbn = dispItemKbn;
    }

    public String[] getJuchuZanKbn() {
        return juchuZanKbn;
    }

    public void setJuchuZanKbn(String[] juchuZanKbn) {
        this.juchuZanKbn = juchuZanKbn;
    }
    
    public String getDataKbnDisp() {
        String str = "";
        if("M".equals(this.getDataKbn())){
            str = "月次確定(" + this.getTaishoYm() + ")";
        }else if("Y".equals(this.getDataKbn())){
            str = "予算ベース(" + this.getTaishoYm() + ")";
        } else {
            str = "原案";
        }
        return str;
    }
    
    @Override
    public String getRirekiFlg() {
        String thisDataKbn = StringUtils.defaultString(this.getDataKbn());
        if (!"O".equals(thisDataKbn)) {
            return "R";
        } else {
            return "";
        }
    }

    public String getOptionKiChangeFlg() {
        return optionKiChangeFlg;
    }

    public void setOptionKiChangeFlg(String optionKiChangeFlg) {
        this.optionKiChangeFlg = optionKiChangeFlg;
    }

    public String getOptionSummaryKbn() {
        return optionSummaryKbn;
    }

    public void setOptionSummaryKbn(String optionSummaryKbn) {
        this.optionSummaryKbn = optionSummaryKbn;
    }

    public String getUriageTouKanbaiKbn() {
        return uriageTouKanbaiKbn;
    }

    public void setUriageTouKanbaiKbn(String uriageTouKanbaiKbn) {
        this.uriageTouKanbaiKbn = uriageTouKanbaiKbn;
    }

    public String getJuYmJoken() {
        return juYmJoken;
    }

    public void setJuYmJoken(String juYmJoken) {
        this.juYmJoken = juYmJoken;
    }

    public String[] getOptionTargetAnkenId() {
        return optionTargetAnkenId;
    }



}
