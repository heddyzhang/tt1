/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package jp.co.toshiba.hby.pspromis.syuueki.service.mikomiupload;

/**
 *
 * @author ibayashi
 */
public interface UploadComponent {
    
    /**
     * 入力内容のデータチェック
     * @return 
     * @throws java.lang.Exception
     */
    public boolean isDataCheck() throws Exception;

    /**
     * アップロード処理の実行
     * @throws java.lang.Exception
     */
    public void executeUpload() throws Exception;
}
