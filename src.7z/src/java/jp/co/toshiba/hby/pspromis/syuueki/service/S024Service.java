package jp.co.toshiba.hby.pspromis.syuueki.service;

import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.List;
import java.util.Map;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import javax.inject.Inject;
import javax.ejb.Stateless;
import javax.interceptor.Interceptors;
import jp.co.toshiba.hby.pspromis.common.exception.PspRunTimeExceotion;
import jp.co.toshiba.hby.pspromis.syuueki.bean.S024Bean;
import jp.co.toshiba.hby.pspromis.syuueki.bean.ValidationMessageBean;
import jp.co.toshiba.hby.pspromis.syuueki.entity.SyuCurMst;
import jp.co.toshiba.hby.pspromis.syuueki.entity.SyuGeBukkenInfoTbl;
import jp.co.toshiba.hby.pspromis.syuueki.entity.SyuKiKaisyuTblView;
import jp.co.toshiba.hby.pspromis.syuueki.entity.SyuZeikbnMst;
import jp.co.toshiba.hby.pspromis.syuueki.entity.OperationLog;
import jp.co.toshiba.hby.pspromis.syuueki.enums.Env;
import jp.co.toshiba.hby.pspromis.syuueki.enums.Label;
import jp.co.toshiba.hby.pspromis.syuueki.enums.ValidatorMessage;
import jp.co.toshiba.hby.pspromis.syuueki.facade.KanjyoMstFacade;
import jp.co.toshiba.hby.pspromis.syuueki.facade.SyuCurMstFacade;
import jp.co.toshiba.hby.pspromis.syuueki.facade.SyuGeBukenInfoTblFacade;
import jp.co.toshiba.hby.pspromis.syuueki.facade.SyuKiKaisyuTblFacade;
import jp.co.toshiba.hby.pspromis.syuueki.facade.SyuZeikbnMstFacade;
import jp.co.toshiba.hby.pspromis.syuueki.interceptor.TranceInterceptor;
import jp.co.toshiba.hby.pspromis.syuueki.util.DateUtils;
import jp.co.toshiba.hby.pspromis.syuueki.util.SyuuekiUtils;
import jp.co.toshiba.hby.pspromis.syuueki.util.ValidationUtils;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 *
 * @author ibayashi
 */
@Stateless
@Interceptors({TranceInterceptor.class})
public class S024Service {

    public static final Logger log = LoggerFactory.getLogger(S024Service.class);
    
    @Inject
    private S024Bean s024Bean;
    
    @Inject
    private SyuCurMstFacade syuCurMstFacade;
    
    @Inject
    private SyuZeikbnMstFacade syuZeikbnMstFacade;
    
    @Inject
    private SyuKiKaisyuTblFacade syuKiKaisyuTblFacade;
    
    @Inject
    private SyuGeBukenInfoTblFacade syuGeBukenInfoTblFacade;
    
    @Inject
    private KanjyoMstFacade kanjyoMstFacade;
    
    @Inject
    private StoredProceduresService storedProceduresService;
    
    @Inject
    private OperationLogService operationLogService;

    @Inject
    private SyuuekiUtils syuuekiUtils;
    
    @Inject
    private ValidationMessageBean validationMessageBean;
    
    /**
     * 画面表示　ビジネスロジック
     * @throws Exception 
     */
    public void indexExecute() throws Exception {
        log.info("S024Service#indexExecute");
        
        // データの取得
        searchKaisyuDataList();
        
        //画面表示用の選択候補取得
        getDispData();
    }

    /**
     * 保存処理　ビジネスロジック
     * @throws Exception 
     */
    public void saveExecute() throws Exception {
        log.info("S024Service#saveExecute");
        
        // 削除対象として選択されているデータを物理削除
        deleteKaisyuData();
        
        // その他のデータを更新/登録
        entryKaisyuData();
        
        // 操作ログ保存
        registOperationLog();
        
        // 再計算パッケージ実行
        storedProceduresService.callAnkenRecalAuto(s024Bean.getAnkenId(), s024Bean.getRirekiId(), "0");
    }

    /**
     * 表示する一覧データを取得
     */
    private void searchKaisyuDataList() throws Exception {
        Map<String, Object> params = new HashMap<>();
        params.put("ankenId", s024Bean.getAnkenId());
        params.put("rirekiId", Integer.parseInt(s024Bean.getRirekiId()));
        
        List<SyuKiKaisyuTblView> kaisyuList = syuKiKaisyuTblFacade.selectKaisyuSyubetuList(s024Bean.getAnkenId(), s024Bean.getRirekiId());

        // 新規登録データ5(プロパティより取得)行分を追加
        int newDataLineCount = Integer.valueOf(Env.Kaisyu_New_Count.getValue());
        for (int i=0; i<newDataLineCount; i++) {
            SyuKiKaisyuTblView newEntity = new SyuKiKaisyuTblView();
            newEntity.setAnkenId(s024Bean.getAnkenId());
            newEntity.setRirekiId(Integer.valueOf(s024Bean.getRirekiId()));
            newEntity.setCurrencyCode("");
            newEntity.setZeiKbn("");
            newEntity.setKinsyuKbn("");
            newEntity.setKaisyuKbn("");
            newEntity.setNewFlg("1");   // 新規登録行データは削除不可としておく。
            kaisyuList.add(newEntity);
        }

        s024Bean.setDataList(kaisyuList);
    }
    
    /**
     * 画面表示用の選択候補取得
     */
    private void getDispData(){
        // 通貨選択候補取得
        List<SyuCurMst> curList = syuCurMstFacade.findByAnken(s024Bean.getAnkenId(), Integer.valueOf(s024Bean.getRirekiId()));
        s024Bean.setCurrencyCodeList(curList);
        
        List<SyuZeikbnMst> zeiList = syuZeikbnMstFacade.findAll();
        s024Bean.setZeiKbnList(zeiList);
        
    }

    /**
     * [削除]選択された回収情報データを削除
     */
    private void deleteKaisyuData() throws Exception {
        String[] delIndexs = s024Bean.getDelIndexs();
        
        if (delIndexs != null) {
            for (String index: delIndexs) {
                Map<String, Object> data = s024Bean.getKaisyuList().get(Integer.parseInt(index));
                Map<String, Object> condition = setDataCondition(data, "", "");
                
                syuKiKaisyuTblFacade.deleteKaisyuSyubetu(condition);
            }
        }
    }
    
    /**
     * 回収情報データを登録/更新
     */
    private void entryKaisyuData() throws Exception {
        List<Map<String, Object>> kaisyuList = s024Bean.getKaisyuList();
        
        Map<String, Object> params = new HashMap<>();
        params.put("ankenId", s024Bean.getAnkenId());
        params.put("rirekiId", Integer.parseInt(s024Bean.getRirekiId()));
        SyuGeBukkenInfoTbl geEntity = getGeEntity(params);
        
        //勘定年月をマスタから取得
        String nowKanjyoYm = kanjyoMstFacade.getNowKanjoDate(geEntity.getSalesClass());
        //INSERT用の勘定年月を取得
        String kanjoYm = getKanjoYm(geEntity);
        
        if(StringUtils.isEmpty(kanjoYm)){
            kanjoYm = nowKanjyoYm;
        }

        if (CollectionUtils.isNotEmpty(kaisyuList)) {
            int idx = 0;
            for (Map<String, Object> data: kaisyuList) {
                //[削除]選択行は更新対象から除外
                if(s024Bean.getDelIndexs() != null && Arrays.asList(s024Bean.getDelIndexs()).contains(String.valueOf(idx))){
                    idx++;
                    continue;
                }
                idx++;

                //処理用のconditionをセット
                Map<String, Object> condition = setDataCondition(data, kanjoYm, nowKanjyoYm);
                
                //更新対象行かチェック
                if(chkUpdateTarget(data)){
                    continue;
                }
                
                //同一データの存在チェック
                if(chkExistsData(data, condition)){
                    continue;
                }
                
                //対象データの登録
                registData(data, condition);
            }
        }
        
    }
    
    /**
     * 更新対象外行のチェック
     * @param data
     * @return  true:更新対象外  false:更新対象
     */
    private boolean chkUpdateTarget(Map<String, Object> data){
        boolean flg = false;
        if(data.get("newFlg").equals("1")){
            // 新規行なら4項目のチェック
            if(StringUtils.isEmpty((String)data.get("currencyCode")) && StringUtils.isEmpty((String)data.get("zeiKbn"))
               && StringUtils.isEmpty((String)data.get("kinsyuKbn")) && StringUtils.isEmpty((String)data.get("kaisyuKbn"))
            ){
                // 4項目全て空なら対象外
                flg = true;
            }
        }
        
        return flg;
        
    }
    
    /**
     * 同一データの存在チェック
     * @param data
     * @return  true:同一データあり  false:同一データなし
     */
    private boolean chkExistsData(Map<String, Object> data, Map<String, Object> condition){
        return syuKiKaisyuTblFacade.countKaisyuSyubetsu(condition);
    }
    
    /**
     * データの登録処理
     * @param data 
     */
    private void registData(Map<String, Object> data, Map<String, Object> condition) throws Exception{
        boolean registFlg = false;
        
        if(data.get("newFlg").equals("0")){
            // 既存データはUPDATEする
            int cnt = syuKiKaisyuTblFacade.updateKaisyuSyubetu(condition);
            if(cnt > 0){
                registFlg = true;
            }
        }
        
        if(!registFlg){
            syuKiKaisyuTblFacade.insertKaisyuSyubetu(condition);
        }
    }
    
    private Map<String, Object> setDataCondition(Map<String, Object> data, String kanjoYm, String nowKanjoYm) throws Exception{
        Map<String, Object> condition = new HashMap<>();
        condition.put("ankenId", s024Bean.getAnkenId());
        condition.put("rirekiId", s024Bean.getRirekiId());
        condition.put("dataKbn", syuuekiUtils.getJissekiFlg(DateUtils.parseDate(nowKanjoYm), kanjoYm) ? "J" : "M");
        condition.put("currencyCode", data.get("currencyCode"));
        condition.put("syuekiYm", kanjoYm);
        condition.put("zeiKbn", data.get("zeiKbn"));
        condition.put("kinsyuKbn", data.get("kinsyuKbn"));
        condition.put("kaisyuKbn", data.get("kaisyuKbn"));
        condition.put("befCurrencyCode", data.get("befCurrencyCode"));
        condition.put("befZeiKbn", data.get("befZeiKbn"));
        condition.put("befKinsyuKbn", data.get("befKinsyuKbn"));
        condition.put("befKaisyuKbn", data.get("befKaisyuKbn"));
        
        return condition;
    }
    
    private String getKanjoYm(SyuGeBukkenInfoTbl entity) throws Exception{
        Map<String, Object> params = new HashMap<>();
        params.put("ankenId", s024Bean.getAnkenId());
        params.put("rirekiId", Integer.parseInt(s024Bean.getRirekiId()));
        
        // 2018/01/18 進行基準での回収種別追加後、再計算でエラーとなったため修正
        //String syuekiYm = syuKiKaisyuTblFacade.getMaxSyuekiYm(params);
        String syuekiYm = syuKiKaisyuTblFacade.getMaxKaisyuShubetsuYm(params);
        if(StringUtils.isNotEmpty(syuekiYm)){
            return syuekiYm;
        }

        String uriageEndFlg = StringUtils.defaultString(entity.getUriageEndFlg(), "0");
        if (uriageEndFlg.equals("0") || uriageEndFlg.equals("1")) {
            syuekiYm = DateUtils.getString(entity.getUriageEnd(), DateUtils.getMONTH_MEDIUM_SIMPLE_PATTERN());
        } else {
            syuekiYm = DateUtils.getString(entity.getUriageEndFin(), DateUtils.getMONTH_MEDIUM_SIMPLE_PATTERN());
        }

        if(StringUtils.isNotEmpty(syuekiYm)){
            return syuekiYm;
        }

        return "";
    }
    
    /**
     * 案件基本情報(GE)を取得
     */
    private SyuGeBukkenInfoTbl getGeEntity(final Map<String, Object> params) throws Exception {
        SyuGeBukkenInfoTbl geEntity = syuGeBukenInfoTblFacade.findPk(params);
        if (geEntity == null) {
            String errorMessage = Label.errorNoAnkenDate.getLabel();
            log.error(errorMessage + " ankenId=" + s024Bean.getAnkenId() + " rirekiId=" + s024Bean.getRirekiId());
            throw new PspRunTimeExceotion(errorMessage);
        }
        return geEntity;
    }
    
    public boolean validation() throws Exception {
        int idx=0;
        
        Map<String, Integer> chofukuCheckMap = new HashMap<>();
        String errorOverlapMessage = ValidatorMessage.KAISYU_EDIT_OVERLAP.getMessae();
        
        for(Map<String, Object> data : s024Bean.getKaisyuList()){
            // チェックが必要か確認
            if(s024Bean.getDelIndexs() != null && Arrays.asList(s024Bean.getDelIndexs()).contains(String.valueOf(idx))){
                idx++;
                continue;
            }
            
            String currencyCode = (String) data.get("currencyCode");
            String zeiKbn = (String) data.get("zeiKbn");
            String kinsyuKbn = (String) data.get("kinsyuKbn");
            String kaisyuKbn = (String) data.get("kaisyuKbn");

            // 重複指定チェックのためのデータため込み
            if (StringUtils.isNotEmpty(currencyCode)
                    && StringUtils.isNotEmpty(zeiKbn)
                    && StringUtils.isNotEmpty(kinsyuKbn)
                    && StringUtils.isNotEmpty(kaisyuKbn)
             ) {
                String key = currencyCode + "\t" + zeiKbn + "\t" + kinsyuKbn + "\t" + kaisyuKbn;
                Integer beforeIndex = chofukuCheckMap.get(key);
                chofukuCheckMap.put(key, idx);

                // 同一の組み合わせが指定されている場合、対象行にエラーメッセージを表示
                if (beforeIndex != null) {
                    String messageKey = "error-" + String.valueOf(idx) + "-currencyCode";
                    validationMessageBean.setErrorInfo(messageKey, errorOverlapMessage);
                  
                    idx++;
                    continue;
                }
            }

            //// 未指定の項目が存在するかをチェック
            if(data.get("newFlg").equals("1")){
                //新規行の場合
                if(
                    ValidationUtils.isRequired(currencyCode) 
                    && ValidationUtils.isRequired(zeiKbn)
                    && ValidationUtils.isRequired(kinsyuKbn) 
                    && ValidationUtils.isRequired(kaisyuKbn)
                ){
                    // 全て選択されている場合OK
                    idx++;
                    continue;
                } else if(
                    !ValidationUtils.isRequired(currencyCode) 
                    && !ValidationUtils.isRequired(zeiKbn)
                    && !ValidationUtils.isRequired(kinsyuKbn) 
                    && !ValidationUtils.isRequired(kaisyuKbn)
                ){
                    // 全て選択されていない場合OK
                    idx++;
                    continue;
                } else {
                    checkData(data, idx);
                }
            } else {
                //更新行の場合
                checkData(data, idx);
            }
            
            idx++;
        }

        return validationMessageBean.isSuccess();
    }

    private void checkData(Map<String, Object> data, int idx){
        
       if (!ValidationUtils.isRequired((String) data.get("currencyCode"))) {
           // 必須チェックエラー
           validationMessageBean.setErrorInfo("error-" + String.valueOf(idx) + "-currencyCode", ValidatorMessage.REQUIRED.getMessae(Label.currency.getLabel()));
       }
       
       // 税率チェック
       if (!ValidationUtils.isRequired((String) data.get("zeiKbn"))) {
           // 必須チェックエラー
           validationMessageBean.setErrorInfo("error-" + String.valueOf(idx) + "-zeiKbn", ValidatorMessage.REQUIRED.getMessae(Label.taxRate.getLabel()));
       }
       
       // 金種チェック
       if (!ValidationUtils.isRequired((String) data.get("kinsyuKbn"))) {
           // 必須チェックエラー
           validationMessageBean.setErrorInfo("error-" + String.valueOf(idx) + "-kinsyuKbn", ValidatorMessage.REQUIRED.getMessae(Label.kinsyu.getLabel()));
       }
       
       // 前受チェック
       if (!ValidationUtils.isRequired((String) data.get("kaisyuKbn"))) {
           // 必須チェックエラー
           validationMessageBean.setErrorInfo("error-" + String.valueOf(idx) + "-kaisyuKbn", ValidatorMessage.REQUIRED.getMessae(Label.maeuke.getLabel()));
       }
    }
    
    /**
     * 操作ログの登録
     * @throws Exception
     */
    public void registOperationLog() throws Exception{
        OperationLog operationLog = operationLogService.getOperationLog();

        operationLog.setOperationCode("KAISYU_EDIT");
        operationLog.setObjectId(20);
        operationLog.setObjectType(operationLogService.getObjectType(s024Bean.getProcId()));
        operationLog.setRemarks(s024Bean.getAnkenId());

        operationLogService.insertOperationLogSearch(operationLog);
    }
    
}
