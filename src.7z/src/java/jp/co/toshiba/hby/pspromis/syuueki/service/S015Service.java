package jp.co.toshiba.hby.pspromis.syuueki.service;

import java.io.File;
import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.ejb.Stateless;
import javax.inject.Inject;
import javax.interceptor.Interceptors;
import jp.co.toshiba.hby.pspromis.common.util.CollectionUtil;
import jp.co.toshiba.hby.pspromis.syuueki.bean.S015Bean;
import jp.co.toshiba.hby.pspromis.syuueki.bean.ValidationMessageBean;
import jp.co.toshiba.hby.pspromis.syuueki.entity.SyuAttachTbl;
import jp.co.toshiba.hby.pspromis.syuueki.entity.SyuGeBukkenInfoTbl;
import jp.co.toshiba.hby.pspromis.syuueki.enums.Env;
import jp.co.toshiba.hby.pspromis.syuueki.enums.ValidatorMessage;
import jp.co.toshiba.hby.pspromis.syuueki.enums.Label;
import jp.co.toshiba.hby.pspromis.syuueki.facade.SyuAttachTblFacade;
import jp.co.toshiba.hby.pspromis.syuueki.facade.SyuGeBukenInfoTblFacade;
import jp.co.toshiba.hby.pspromis.syuueki.interceptor.TranceInterceptor;
import jp.co.toshiba.hby.pspromis.syuueki.util.DateUtils;
import jp.co.toshiba.hby.pspromis.syuueki.util.EntityUtils;
import jp.co.toshiba.hby.pspromis.syuueki.util.LoginUserInfo;
import jp.co.toshiba.hby.pspromis.syuueki.util.ValidationUtils;
import jp.co.toshiba.hby.pspromis.syuueki.util.FileUtils;
import org.apache.commons.beanutils.PropertyUtils;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.fileupload.FileItem;
import org.apache.commons.io.FilenameUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
/**
 * ES-Promis収益管理システム
 * 添付資料 Service
 * @author (NPC)S.Ibayashi
 */
@Stateless
@Interceptors({TranceInterceptor.class})
public class S015Service {

    public static final Logger log = LoggerFactory.getLogger(S015Service.class);

    @Inject
    private S015Bean s015Bean;

    @Inject
    private ValidationMessageBean validationMessageBean;
    
    @Inject
    private LoginUserInfo loginUserInfo;

    @Inject
    private SyuAttachTblFacade syuAttachTblFacade;
    
    @Inject
    private SyuGeBukenInfoTblFacade syuGeBukenInfoTblFacade;


    /**
     * 初期表示時機能
     * @throws Exception
     */
    public void indexExecute() throws Exception {
        List<SyuAttachTbl> dispList = findDispAttachList();
        s015Bean.setDispList(dispList);
        
        SyuGeBukkenInfoTbl ankenEntity = getAnkenEntity();
        s015Bean.setDivisionCode(StringUtils.defaultString(ankenEntity.getDivisionCode()));
    }

    /**
     * 保存前のバリデーションチェック
     */
    public boolean validation() throws Exception {
        String message;
        String label;

        // 画面一覧
        List<Map<String, Object>> list = s015Bean.getAttachList();

        // 
        int i = 0;
        if (CollectionUtils.isNotEmpty(list)) {
            for (Map<String, Object> data: list) {
                int entryDataKbn = getEntryDataKbn(data);

                // 資料名 チェック
                if (entryDataKbn > 0) {
                    String title = (String)data.get("title");
                    if (!ValidationUtils.isByteOver(title, 100)) {
                        label = Label.documentName.getLabel();
                        message = ValidatorMessage.BYTE_OVER_HAN_ZEN.getMessae(label, 100, ValidationUtils.getZenCharCount(100));
                        validationMessageBean.setErrorInfo("attachList-" + i + "-title", message);
                    }
                }
                
                // ファイル名のバイトチェック
                if (entryDataKbn == 2) {
                    String fileName = FilenameUtils.getName(((FileItem)data.get("file")).getName());
                    if (!ValidationUtils.isByteOver(fileName, 100)) {
                        label = Label.fileName.getLabel();
                        message = ValidatorMessage.BYTE_OVER_HAN_ZEN.getMessae(label, 100, ValidationUtils.getZenCharCount(100));
                        validationMessageBean.setErrorInfo("attachList-" + i + "-urlFile", message);
                    }
                }
                
                // URLのバイトチェック
                if (entryDataKbn == 3) {
                    String url = (String)data.get("url");
                    if (!ValidationUtils.isByteOver(url, 255)) {
                        label = Label.urlName.getLabel();
                        message = ValidatorMessage.BYTE_OVER_HAN_ZEN.getMessae(label, 255, ValidationUtils.getZenCharCount(255));
                        validationMessageBean.setErrorInfo("attachList-" + i + "-urlFile", message);
                    }
                }

                i++;
            }
        }
        
        return validationMessageBean.isSuccess();
    }

    /**
     * 保存処理
     * @throws java.lang.Exception
     */
    public void saveExecute() throws Exception {
        int idx = 0;
        List<Map<String, Object>> list = s015Bean.getAttachList();
        
        // 対象案件の基本情報を取得
        SyuGeBukkenInfoTbl ankenEntity = getAnkenEntity();

        // アップロードファイル
        List<Map<String, Object>> uploadFileList = new ArrayList<>();
        // 削除ファイル
        List<String> deleteFileList = new ArrayList<>();
        
        // 画面のデータをDBに登録
        if (CollectionUtils.isNotEmpty(list)) {
            for (Map<String, Object> data: list) {
                String seq = StringUtils.defaultString((String)data.get("seq"));

                int entryDataKbn = getEntryDataKbn(data);

                if (entryDataKbn < 0) {
                    ////// 削除対象として選択されたデータの場合、テーブルからデータ削除
                    if (StringUtils.isNotEmpty(seq)) {
                        // 削除対象SEQのファイルが履歴情報に作成されているかチェック
                        int rirekiCount = syuAttachTblFacade.getRirekiCount(s015Bean.getAnkenId(), s015Bean.getRirekiId(), seq);
                        // 履歴情報に存在しないファイルはファイルの実態を物理削除する(削除ファイルのパスをため込む)
                        if (rirekiCount == 0) {
                            SyuAttachTbl removeFileEntity = syuAttachTblFacade.findAttachInfo(s015Bean.getAnkenId(), s015Bean.getRirekiId(), seq);
                            String removeFilePath = removeFileEntity.getAttFilePath() + "/" + removeFileEntity.getAttFileServName();
                            deleteFileList.add(removeFilePath);
                        }
                        // 添付ファイルのテーブルデータを削除
                        syuAttachTblFacade.deleteAttach(s015Bean.getAnkenId(), s015Bean.getRirekiId(), seq);
                    }

                } else {
                    ////// 新規登録 or 更新
                    SyuAttachTbl entity = null;
                    if (entryDataKbn == 1) {
                        // 更新行
                        entity = getUpdateDataEntity(data);
                        syuAttachTblFacade.updateAttach(entity);
                    } else if (entryDataKbn >= 2) {
                        // 新規登録行
                        entity = getNewDataEntity(data, ankenEntity);
                        syuAttachTblFacade.insertAttach(entity);
                    }

                    // 添付ファイルの登録データであれば、アップロード対象リストに追加
                    if (entity != null && StringUtils.isNotEmpty(entity.getAttFileName())) {
                        Map<String, Object> uploadFileInfo = PropertyUtils.describe(entity);
                        uploadFileInfo.put("file", (FileItem)data.get("file"));
                        uploadFileList.add(uploadFileInfo);
                    }
                }
            }
        }

        // 指定した添付ファイルをアップロード
        uploadFile(uploadFileList);

        // 削除指定された実ファイルを削除(履歴テーブル(月次確定情報)に存在しないファイルのみ)
        removeFile(deleteFileList);
    }

    /**
     * 登録/更新データチェック
     * return 0:更新・登録対象データではない 1:更新データ 2:新規登録(ファイル) 3:新規登録(URL) -1:削除データ
     */
    private int getEntryDataKbn(Map<String, Object> data) {
        String selectData = StringUtils.defaultString((String)data.get("selectData"));
        String seq = StringUtils.defaultString((String)data.get("seq"));
        
        if ("1".equals(selectData)) {
            return -1;
        } else {
            if (StringUtils.isNotEmpty(seq)) {
                return 1;
            } else {
                String attachKind = (String)data.get("attachKind");
                if ("1".equals(attachKind) && data.get("file") != null) {
                    return 2;
                }
                if ("0".equals(attachKind) && StringUtils.isNotEmpty((String)data.get("url"))) {
                    return 3;
                }
            }
        }
        return 0;
    }

    /**
     * ダウンロードを行う添付ファイルの取得
     * @throws java.lang.Exception
     */
    public void getAttachmentFileExecute() throws Exception {
        SyuAttachTbl targetEntity
                = syuAttachTblFacade.findAttachInfo(s015Bean.getAnkenId(), s015Bean.getRirekiId(), s015Bean.getTargetSeq(), s015Bean.getRirekiFlg());

        String attFileFullPath = targetEntity.getAttFilePath() + "/" + targetEntity.getAttFileServName();
        String attFileName = targetEntity.getAttFileName();
        log.info("Download Attach File Info path=[{}] fileName=[{}]", attFileFullPath, attFileName);
        
        s015Bean.setAttFileFullPath(attFileFullPath);
        s015Bean.setAttFileName(attFileName);
    }

    /**
     * 添付情報一覧データを取得
     */
    private List<SyuAttachTbl> findDispAttachList() {
        int fixRowCount = Integer.parseInt(Env.Attach_File_New_Count.getValue());
        int emptyRowCount;
        
        List<SyuAttachTbl> list = syuAttachTblFacade.findAttachList(s015Bean.getAnkenId(), s015Bean.getRirekiId(), s015Bean.getRirekiFlg());
        List<SyuAttachTbl> dispList = CollectionUtil.createAndCopyList(SyuAttachTbl.class, list);
        
        if (CollectionUtils.isEmpty(dispList)) {
            dispList = new ArrayList<>();
        }
        
        // 編集モードの場合
        if (s015Bean.isEdit()) {
            // 登録済データが10行未満であれば10行分の登録行を確保
            emptyRowCount = fixRowCount - dispList.size();
            if (emptyRowCount > 0) {
                for (int i=1; i<=emptyRowCount; i++) {
                    SyuAttachTbl entity = new SyuAttachTbl();
                    dispList.add(entity);
                }
            }

            // 最後に見えない隠し行のデータを作成(行追加の際、ここを元に追加するために利用)
            SyuAttachTbl entity = new SyuAttachTbl();
            dispList.add(entity);
        }
     
        return dispList;
    }

    /**
     * 案件の基本情報を取得
     */
    private SyuGeBukkenInfoTbl getAnkenEntity() {
        Map<String, Object> condition = new HashMap<>();
        condition.put("ankenId", s015Bean.getAnkenId());
        condition.put("rirekiId", Integer.parseInt(s015Bean.getRirekiId()));
        condition.put("rirekiFlg", s015Bean.getRirekiFlg());
        
        SyuGeBukkenInfoTbl ankenEntity = syuGeBukenInfoTblFacade.findPk(condition);
        return ankenEntity;
    }

    /**
     * 1データの新規追加データを取得
     */
    private SyuAttachTbl getNewDataEntity(final Map<String, Object> data, final SyuGeBukkenInfoTbl ankenEntity) {
        log.info("insert Attach Data=[{]]" ,data.toString());
        
        String newSeq = syuAttachTblFacade.getNewSeq(s015Bean.getAnkenId(), s015Bean.getRirekiId());
        String attachKind = StringUtils.defaultString((String)data.get("attachKind"));
        
        SyuAttachTbl entity = new SyuAttachTbl();
        entity.setAnkenId(s015Bean.getAnkenId());
        entity.setRirekiId(Integer.parseInt(s015Bean.getRirekiId()));
        entity.setSeq(new BigInteger(newSeq));
        entity.setTitle(StringUtils.defaultString((String)data.get("title")));
        
        if ("1".equals(attachKind)) {
            // 添付ファイル
            FileItem fItem = (FileItem)data.get("file");
            
            // 添付ファイルをリネームし、この名称でサーバーに保存する
            Date now = new Date();
            String fileServName = loginUserInfo.getUserId() + DateUtils.getString(now, "yyyyMMddHHmmss") + "_" + newSeq;

            entity.setAttFileName(FilenameUtils.getName(fItem.getName()));
            entity.setAttFileServName(fileServName);
            entity.setAttFilePath(getAttFilePath(data, ankenEntity));
        } else {
            // URL
            entity.setUrlName(StringUtils.defaultString((String)data.get("url")));
        }
        
        EntityUtils.setCreatedInfo(entity, loginUserInfo.getUserId());

        return entity;
    }

    /**
     * 1データの更新データを取得
     */
    private SyuAttachTbl getUpdateDataEntity(final Map<String, Object> data) {
        log.info("update Attach Data=[{]]" ,data.toString());
        
        SyuAttachTbl entity = new SyuAttachTbl();
        entity.setAnkenId(s015Bean.getAnkenId());
        entity.setRirekiId(Integer.parseInt(s015Bean.getRirekiId()));
        entity.setSeq(new BigInteger((String)data.get("seq")));
        entity.setTitle(StringUtils.defaultString((String)data.get("title")));
        
        EntityUtils.setUpdatedInfo(entity, loginUserInfo.getUserId());
        
        return entity;
    }

    /**
     * 添付ファイルの格納パスを取得
     */
    private String getAttFilePath(Map<String, Object> data, SyuGeBukkenInfoTbl ankenEntity) {
        Date now = new Date();
        String year = DateUtils.getDateString(now);
        year = StringUtils.substring(year, 0, 4);

        String basePath = Env.Upload_Base_Att_Path.getValue();
        String ankenPath = ankenEntity.getDivisionCode() + "/" + year + "/" + s015Bean.getAnkenId();
        
        String fullPath = basePath + "/" + ankenPath;
        log.info("attach upload path=[{}]", fullPath);
        
        return fullPath;
    }

    /**
     * アップロードファイルのリストを追加
     */
    private void uploadFile(List<Map<String, Object>> uploadFileList) throws Exception {
        if (CollectionUtils.isEmpty(uploadFileList)) {
            return;
        }
        
        for (Map<String, Object> uploadData: uploadFileList) {
            String attFilePath = (String)uploadData.get("attFilePath");
            String attFileServName = (String)uploadData.get("attFileServName");

            FileItem fItem = (FileItem)uploadData.get("file");
            String fileName = FilenameUtils.getName(fItem.getName());
            
            // 保管先ディレクトリの作成(存在しない場合)
            File dir = new File(attFilePath);
            if (!dir.isDirectory()) {
                dir.mkdirs();
            }

            // アップロードの実行
            fItem.write(new File(attFilePath, attFileServName));

            log.info("Execute Upload Attach File name=[{}] serverPath=[{}]", fileName, (attFilePath + "/" + attFileServName));
        }
    }

    /**
     * 削除指定されたアップロード済ファイルの実態を削除
     */
    private void removeFile(List<String> removeFileList) {
        if (CollectionUtils.isEmpty(removeFileList)) {
            return;
        }

        for (String removeFilePath: removeFileList) {
            FileUtils.deleteFile(removeFilePath);
        }
    }

}