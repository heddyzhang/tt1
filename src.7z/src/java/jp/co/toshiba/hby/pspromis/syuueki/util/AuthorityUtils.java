package jp.co.toshiba.hby.pspromis.syuueki.util;

import java.io.Serializable;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import javax.enterprise.context.SessionScoped;
import javax.inject.Inject;
import javax.inject.Named;
import jp.co.toshiba.hby.pspromis.syuueki.bean.AuthorityBean;
import org.apache.commons.lang3.StringUtils;
/**
 * 収益管理 共通ユーティリティ<br>
 * ELからも使用可能なようにCDI管理する(ApplicationScoped)
 * @author (NPC)S.Ibayashi
 */
@Named(value = "authUtl")
@SessionScoped
public class AuthorityUtils implements Serializable {
    
    @Inject
    private AuthorityBean authorityBean;

    public int enableFlg(String code) {
        return enableFlg(code, "", "");
    }

    public int enableFlg(String code, String divisionCd, String rirekiFlg) {
        Map<String, Set<String>> keyMap;
        
        if ("R".equals(rirekiFlg)) {
            keyMap = authorityBean.getAuthorityRirekiKeyMap();
        } else {
            keyMap = authorityBean.getAuthorityKeyMap();
        }

        if (keyMap == null) {
            return 0;
        } else {
            return getFuncCdFlg(keyMap, divisionCd, code);
        }

    }

    private int getFuncCdFlg(Map<String, Set<String>> keyMap, String divisionCd, String code) {
        Set<String> funcSet;
        int result = 0;
        
        if (StringUtils.isNotEmpty(divisionCd)) {
            // 事業部を指定された場合
            // 指定事業部で権限が存在するかをチェック
            funcSet = keyMap.get(divisionCd);
            if (funcSet != null && funcSet.contains(code)) {
                result = 1;
            }

        } else {
            // 事業部が未指定の場合
            // 権限がある全事業部データを走査して指定権限があるかをチェック
            Set<String> divisionCdSet = keyMap.keySet();
            Iterator<String> ite = divisionCdSet.iterator();
            while(ite.hasNext()) {
                String workDivisionCd = ite.next();
                funcSet = keyMap.get(workDivisionCd);
                if (funcSet != null && funcSet.contains(code)) {
                    result = 1;
                    break;
                }
            }
        }
        
        return result;
    }

}
