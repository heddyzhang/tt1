package jp.co.toshiba.hby.pspromis.syuueki.entity;

import java.io.Serializable;
import java.math.BigInteger;
import java.util.Date;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

/**
 *
 * @author ibayashi
 */
@Entity
@Table(name = "JGRP_MEMBER_TBL")
public class JgrpMemberTbl implements Serializable {
    private static final long serialVersionUID = 1L;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 10)
    @Column(name = "JGRP_ID")
    @Id
    private String jgrpId;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 10)
    @Column(name = "MEMBER_ID")
    @Id
    private String memberId;
    @Basic(optional = false)
    @NotNull
    @Column(name = "JGRP_SEQ")
    private BigInteger jgrpSeq;
    @Basic(optional = false)
    @NotNull
    @Column(name = "JGRP_UP_SEQ")
    private BigInteger jgrpUpSeq;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 10)
    @Column(name = "JGRP_PARENT_ID")
    private String jgrpParentId;
    @Size(max = 1)
    @Column(name = "JGRP_STS")
    private String jgrpSts;
    @Size(max = 84)
    @Column(name = "MEMBER_NAME")
    private String memberName;
    @Size(max = 6)
    @Column(name = "MEMBER_BUKA_CD")
    private String memberBukaCd;
    @Size(max = 120)
    @Column(name = "MEMBER_BUKA_NAME")
    private String memberBukaName;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 1)
    @Column(name = "MEMBER_TYPE")
    private String memberType;
    @Size(max = 3)
    @Column(name = "MEMBER_YAKU_CD")
    private String memberYakuCd;
    @Size(max = 60)
    @Column(name = "MEMBER_YAKU_NAME")
    private String memberYakuName;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 1)
    @Column(name = "MEMBER_KBN")
    private String memberKbn;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 1)
    @Column(name = "JL_FLG")
    private String jlFlg;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 1)
    @Column(name = "APP_KBN")
    private String appKbn;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 1)
    @Column(name = "MAIL_FLG")
    private String mailFlg;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 1)
    @Column(name = "DELETE_FLG")
    private String deleteFlg;
    @Size(max = 8)
    @Column(name = "LOCKER_UID")
    private String lockerUid;
    @Size(max = 144)
    @Column(name = "LOCKER")
    private String locker;
    @Column(name = "INSERT_DATE")
    @Temporal(TemporalType.TIMESTAMP)
    private Date insertDate;
    @Column(name = "UPDATE_DATE")
    @Temporal(TemporalType.TIMESTAMP)
    private Date updateDate;
    @Column(name = "DELETE_DATE")
    @Temporal(TemporalType.TIMESTAMP)
    private Date deleteDate;
    @Size(max = 8)
    @Column(name = "INSERTER_UID")
    private String inserterUid;
    @Size(max = 144)
    @Column(name = "INSERTER")
    private String inserter;
    @Size(max = 8)
    @Column(name = "UPDATER_UID")
    private String updaterUid;
    @Size(max = 144)
    @Column(name = "UPDATER")
    private String updater;
    @Size(max = 8)
    @Column(name = "DELETER_UID")
    private String deleterUid;
    @Size(max = 144)
    @Column(name = "DELETER")
    private String deleter;

    public JgrpMemberTbl() {
    }

    public String getJgrpId() {
        return jgrpId;
    }

    public void setJgrpId(String jgrpId) {
        this.jgrpId = jgrpId;
    }

    public String getMemberId() {
        return memberId;
    }

    public void setMemberId(String memberId) {
        this.memberId = memberId;
    }

    public BigInteger getJgrpSeq() {
        return jgrpSeq;
    }

    public void setJgrpSeq(BigInteger jgrpSeq) {
        this.jgrpSeq = jgrpSeq;
    }

    public BigInteger getJgrpUpSeq() {
        return jgrpUpSeq;
    }

    public void setJgrpUpSeq(BigInteger jgrpUpSeq) {
        this.jgrpUpSeq = jgrpUpSeq;
    }

    public String getJgrpParentId() {
        return jgrpParentId;
    }

    public void setJgrpParentId(String jgrpParentId) {
        this.jgrpParentId = jgrpParentId;
    }

    public String getJgrpSts() {
        return jgrpSts;
    }

    public void setJgrpSts(String jgrpSts) {
        this.jgrpSts = jgrpSts;
    }

    public String getMemberName() {
        return memberName;
    }

    public void setMemberName(String memberName) {
        this.memberName = memberName;
    }

    public String getMemberBukaCd() {
        return memberBukaCd;
    }

    public void setMemberBukaCd(String memberBukaCd) {
        this.memberBukaCd = memberBukaCd;
    }

    public String getMemberBukaName() {
        return memberBukaName;
    }

    public void setMemberBukaName(String memberBukaName) {
        this.memberBukaName = memberBukaName;
    }

    public String getMemberType() {
        return memberType;
    }

    public void setMemberType(String memberType) {
        this.memberType = memberType;
    }

    public String getMemberYakuCd() {
        return memberYakuCd;
    }

    public void setMemberYakuCd(String memberYakuCd) {
        this.memberYakuCd = memberYakuCd;
    }

    public String getMemberYakuName() {
        return memberYakuName;
    }

    public void setMemberYakuName(String memberYakuName) {
        this.memberYakuName = memberYakuName;
    }

    public String getMemberKbn() {
        return memberKbn;
    }

    public void setMemberKbn(String memberKbn) {
        this.memberKbn = memberKbn;
    }

    public String getJlFlg() {
        return jlFlg;
    }

    public void setJlFlg(String jlFlg) {
        this.jlFlg = jlFlg;
    }

    public String getAppKbn() {
        return appKbn;
    }

    public void setAppKbn(String appKbn) {
        this.appKbn = appKbn;
    }

    public String getMailFlg() {
        return mailFlg;
    }

    public void setMailFlg(String mailFlg) {
        this.mailFlg = mailFlg;
    }

    public String getDeleteFlg() {
        return deleteFlg;
    }

    public void setDeleteFlg(String deleteFlg) {
        this.deleteFlg = deleteFlg;
    }

    public String getLockerUid() {
        return lockerUid;
    }

    public void setLockerUid(String lockerUid) {
        this.lockerUid = lockerUid;
    }

    public String getLocker() {
        return locker;
    }

    public void setLocker(String locker) {
        this.locker = locker;
    }

    public Date getInsertDate() {
        return insertDate;
    }

    public void setInsertDate(Date insertDate) {
        this.insertDate = insertDate;
    }

    public Date getUpdateDate() {
        return updateDate;
    }

    public void setUpdateDate(Date updateDate) {
        this.updateDate = updateDate;
    }

    public Date getDeleteDate() {
        return deleteDate;
    }

    public void setDeleteDate(Date deleteDate) {
        this.deleteDate = deleteDate;
    }

    public String getInserterUid() {
        return inserterUid;
    }

    public void setInserterUid(String inserterUid) {
        this.inserterUid = inserterUid;
    }

    public String getInserter() {
        return inserter;
    }

    public void setInserter(String inserter) {
        this.inserter = inserter;
    }

    public String getUpdaterUid() {
        return updaterUid;
    }

    public void setUpdaterUid(String updaterUid) {
        this.updaterUid = updaterUid;
    }

    public String getUpdater() {
        return updater;
    }

    public void setUpdater(String updater) {
        this.updater = updater;
    }

    public String getDeleterUid() {
        return deleterUid;
    }

    public void setDeleterUid(String deleterUid) {
        this.deleterUid = deleterUid;
    }

    public String getDeleter() {
        return deleter;
    }

    public void setDeleter(String deleter) {
        this.deleter = deleter;
    }
    
}
