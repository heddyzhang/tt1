/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package jp.co.toshiba.hby.pspromis.syuueki.entity;

import java.io.Serializable;
import java.math.BigDecimal;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;

/**
 *
 * @author sano
 */
@Entity
public class RecoveryAmount implements Serializable {
    private static final long serialVersionUID = 1L;

    @Id
    @Column(name = "CURRENCY_CODE")
    private String currencyCode;
    @Id
    @Column(name = "ZEI_KBN")
    private String zeiKbn;
    @Id
    @Column(name = "KINSYU_KBN")
    private String kinsyuKbn;
    @Id
    @Column(name = "KAISYU_KBN")
    private String kaisyuKbn;

    @Column(name = "CURRENCY_CODE_COUNT")
    private int currencyCodeCount;
    @Column(name = "PRE_CURRENCY_CODE")
    private String preCurrencyCode;
    @Column(name = "ZEI_RNM")
    private String zeiRnm;
    @Column(name = "ZEI_RATE")
    private BigDecimal zeiRate;

    @Column(name = "PRE_KAISYU_AMOUNT_TOTAL")
    private BigDecimal preKaisyuAmountTotal;
    @Column(name = "KAISYU_AMOUNT_1")
    private BigDecimal kaisyuAmount1;
    @Column(name = "KAISYU_AMOUNT_2")
    private BigDecimal kaisyuAmount2;
    @Column(name = "KAISYU_AMOUNT_3")
    private BigDecimal kaisyuAmount3;
    @Column(name = "KAISYU_AMOUNT_4")
    private BigDecimal kaisyuAmount4;
    @Column(name = "KAISYU_AMOUNT_5")
    private BigDecimal kaisyuAmount5;
    @Column(name = "KAISYU_AMOUNT_6")
    private BigDecimal kaisyuAmount6;
    @Column(name = "KAISYU_AMOUNT_7")
    private BigDecimal kaisyuAmount7;
    @Column(name = "KAISYU_AMOUNT_8")
    private BigDecimal kaisyuAmount8;
    @Column(name = "KAISYU_AMOUNT_9")
    private BigDecimal kaisyuAmount9;
    @Column(name = "KAISYU_AMOUNT_10")
    private BigDecimal kaisyuAmount10;
    @Column(name = "KAISYU_AMOUNT_11")
    private BigDecimal kaisyuAmount11;
    @Column(name = "KAISYU_AMOUNT_12")
    private BigDecimal kaisyuAmount12;
    @Column(name = "KAISYU_AMOUNT_TM")
    private BigDecimal kaisyuAmountTm;
    @Column(name = "KAISYU_AMOUNT_K1")
    private BigDecimal kaisyuAmountK1;
    @Column(name = "KAISYU_AMOUNT_K2")
    private BigDecimal kaisyuAmountK2;
    @Column(name = "KAISYU_AMOUNT_G")
    private BigDecimal kaisyuAmountG;
    @Column(name = "KAISYU_AMOUNT_F")
    private BigDecimal kaisyuAmountF;
    @Column(name = "KAISYU_AMOUNT_K1_DIFF")
    private BigDecimal kaisyuAmountK1Diff;
    @Column(name = "KAISYU_AMOUNT_K2_DIFF")
    private BigDecimal kaisyuAmountK2Diff;
    @Column(name = "KAISYU_AMOUNT_G_DIFF")
    private BigDecimal kaisyuAmountGDiff;
    @Column(name = "KAISYU_AMOUNT_DIFF")
    private BigDecimal kaisyuAmountDiff;
    @Column(name = "KAISYU_AMOUNT_1Q")
    private BigDecimal kaisyuAmount1Q;
    @Column(name = "KAISYU_AMOUNT_2Q")
    private BigDecimal kaisyuAmount2Q;
    @Column(name = "KAISYU_AMOUNT_3Q")
    private BigDecimal kaisyuAmount3Q;
    @Column(name = "KAISYU_AMOUNT_4Q")
    private BigDecimal kaisyuAmount4Q;
    @Column(name = "KAISYU_AMOUNT_1Q_DIFF")
    private BigDecimal kaisyuAmount1QDiff;
    @Column(name = "KAISYU_AMOUNT_2Q_DIFF")
    private BigDecimal kaisyuAmount2QDiff;
    @Column(name = "KAISYU_AMOUNT_3Q_DIFF")
    private BigDecimal kaisyuAmount3QDiff;
    @Column(name = "KAISYU_AMOUNT_4Q_DIFF")
    private BigDecimal kaisyuAmount4QDiff;


    @Column(name = "PRE_KAISYU_ENKA_AMOUNT_TOTAL")
    private BigDecimal preKaisyuEnkaAmountTotal;
    @Column(name = "KAISYU_ENKA_AMOUNT_1")
    private BigDecimal kaisyuEnkaAmount1;
    @Column(name = "KAISYU_ENKA_AMOUNT_2")
    private BigDecimal kaisyuEnkaAmount2;
    @Column(name = "KAISYU_ENKA_AMOUNT_3")
    private BigDecimal kaisyuEnkaAmount3;
    @Column(name = "KAISYU_ENKA_AMOUNT_4")
    private BigDecimal kaisyuEnkaAmount4;
    @Column(name = "KAISYU_ENKA_AMOUNT_5")
    private BigDecimal kaisyuEnkaAmount5;
    @Column(name = "KAISYU_ENKA_AMOUNT_6")
    private BigDecimal kaisyuEnkaAmount6;
    @Column(name = "KAISYU_ENKA_AMOUNT_7")
    private BigDecimal kaisyuEnkaAmount7;
    @Column(name = "KAISYU_ENKA_AMOUNT_8")
    private BigDecimal kaisyuEnkaAmount8;
    @Column(name = "KAISYU_ENKA_AMOUNT_9")
    private BigDecimal kaisyuEnkaAmount9;
    @Column(name = "KAISYU_ENKA_AMOUNT_10")
    private BigDecimal kaisyuEnkaAmount10;
    @Column(name = "KAISYU_ENKA_AMOUNT_11")
    private BigDecimal kaisyuEnkaAmount11;
    @Column(name = "KAISYU_ENKA_AMOUNT_12")
    private BigDecimal kaisyuEnkaAmount12;
    @Column(name = "KAISYU_ENKA_AMOUNT_TM")
    private BigDecimal kaisyuEnkaAmountTm;
    @Column(name = "KAISYU_ENKA_AMOUNT_K1")
    private BigDecimal kaisyuEnkaAmountK1;
    @Column(name = "KAISYU_ENKA_AMOUNT_K2")
    private BigDecimal kaisyuEnkaAmountK2;
    @Column(name = "KAISYU_ENKA_AMOUNT_G")
    private BigDecimal kaisyuEnkaAmountG;
    @Column(name = "KAISYU_ENKA_AMOUNT_F")
    private BigDecimal kaisyuEnkaAmountF;
    @Column(name = "KAISYU_ENKA_AMOUNT_K1_DIFF")
    private BigDecimal kaisyuEnkaAmountK1Diff;
    @Column(name = "KAISYU_ENKA_AMOUNT_K2_DIFF")
    private BigDecimal kaisyuEnkaAmountK2Diff;
    @Column(name = "KAISYU_ENKA_AMOUNT_G_DIFF")
    private BigDecimal kaisyuEnkaAmountGDiff;
    @Column(name = "KAISYU_ENKA_AMOUNT_DIFF")
    private BigDecimal kaisyuEnkaAmountDiff;
    @Column(name = "KAISYU_ENKA_AMOUNT_1Q")
    private BigDecimal kaisyuEnkaAmount1Q;
    @Column(name = "KAISYU_ENKA_AMOUNT_2Q")
    private BigDecimal kaisyuEnkaAmount2Q;
    @Column(name = "KAISYU_ENKA_AMOUNT_3Q")
    private BigDecimal kaisyuEnkaAmount3Q;
    @Column(name = "KAISYU_ENKA_AMOUNT_4Q")
    private BigDecimal kaisyuEnkaAmount4Q;
    @Column(name = "KAISYU_ENKA_AMOUNT_1Q_DIFF")
    private BigDecimal kaisyuEnkaAmount1QDiff;
    @Column(name = "KAISYU_ENKA_AMOUNT_2Q_DIFF")
    private BigDecimal kaisyuEnkaAmount2QDiff;
    @Column(name = "KAISYU_ENKA_AMOUNT_3Q_DIFF")
    private BigDecimal kaisyuEnkaAmount3QDiff;
    @Column(name = "KAISYU_ENKA_AMOUNT_4Q_DIFF")
    private BigDecimal kaisyuEnkaAmount4QDiff;


    @Column(name = "PRE_KAISYU_ENKA_ZEI_TOTAL")
    private BigDecimal preKaisyuEnkaZeiTotal;
    @Column(name = "KAISYU_ENKA_ZEI_1")
    private BigDecimal kaisyuEnkaZei1;
    @Column(name = "KAISYU_ENKA_ZEI_2")
    private BigDecimal kaisyuEnkaZei2;
    @Column(name = "KAISYU_ENKA_ZEI_3")
    private BigDecimal kaisyuEnkaZei3;
    @Column(name = "KAISYU_ENKA_ZEI_4")
    private BigDecimal kaisyuEnkaZei4;
    @Column(name = "KAISYU_ENKA_ZEI_5")
    private BigDecimal kaisyuEnkaZei5;
    @Column(name = "KAISYU_ENKA_ZEI_6")
    private BigDecimal kaisyuEnkaZei6;
    @Column(name = "KAISYU_ENKA_ZEI_7")
    private BigDecimal kaisyuEnkaZei7;
    @Column(name = "KAISYU_ENKA_ZEI_8")
    private BigDecimal kaisyuEnkaZei8;
    @Column(name = "KAISYU_ENKA_ZEI_9")
    private BigDecimal kaisyuEnkaZei9;
    @Column(name = "KAISYU_ENKA_ZEI_10")
    private BigDecimal kaisyuEnkaZei10;
    @Column(name = "KAISYU_ENKA_ZEI_11")
    private BigDecimal kaisyuEnkaZei11;
    @Column(name = "KAISYU_ENKA_ZEI_12")
    private BigDecimal kaisyuEnkaZei12;
    @Column(name = "KAISYU_ENKA_ZEI_TM")
    private BigDecimal kaisyuEnkaZeiTm;
    @Column(name = "KAISYU_ENKA_ZEI_K1")
    private BigDecimal kaisyuEnkaZeiK1;
    @Column(name = "KAISYU_ENKA_ZEI_K2")
    private BigDecimal kaisyuEnkaZeiK2;
    @Column(name = "KAISYU_ENKA_ZEI_G")
    private BigDecimal kaisyuEnkaZeiG;
    @Column(name = "KAISYU_ENKA_ZEI_F")
    private BigDecimal kaisyuEnkaZeiF;
    @Column(name = "KAISYU_ENKA_ZEI_K1_DIFF")
    private BigDecimal kaisyuEnkaZeiK1Diff;
    @Column(name = "KAISYU_ENKA_ZEI_K2_DIFF")
    private BigDecimal kaisyuEnkaZeiK2Diff;
    @Column(name = "KAISYU_ENKA_ZEI_G_DIFF")
    private BigDecimal kaisyuEnkaZeiGDiff;
    @Column(name = "KAISYU_ENKA_ZEI_DIFF")
    private BigDecimal kaisyuEnkaZeiDiff;
    @Column(name = "KAISYU_ENKA_ZEI_1Q")
    private BigDecimal kaisyuEnkaZei1Q;
    @Column(name = "KAISYU_ENKA_ZEI_2Q")
    private BigDecimal kaisyuEnkaZei2Q;
    @Column(name = "KAISYU_ENKA_ZEI_3Q")
    private BigDecimal kaisyuEnkaZei3Q;
    @Column(name = "KAISYU_ENKA_ZEI_4Q")
    private BigDecimal kaisyuEnkaZei4Q;
    @Column(name = "KAISYU_ENKA_ZEI_1Q_DIFF")
    private BigDecimal kaisyuEnkaZei1QDiff;
    @Column(name = "KAISYU_ENKA_ZEI_2Q_DIFF")
    private BigDecimal kaisyuEnkaZei2QDiff;
    @Column(name = "KAISYU_ENKA_ZEI_3Q_DIFF")
    private BigDecimal kaisyuEnkaZei3QDiff;
    @Column(name = "KAISYU_ENKA_ZEI_4Q_DIFF")
    private BigDecimal kaisyuEnkaZei4QDiff;

//    @Column(name = "RUIKEI_KAISYU_AMOUNT_1")
//    private BigDecimal ruikeiKaisyuAmount1;
//    @Column(name = "RUIKEI_KAISYU_AMOUNT_2")
//    private BigDecimal ruikeiKaisyuAmount2;
//    @Column(name = "RUIKEI_KAISYU_AMOUNT_3")
//    private BigDecimal ruikeiKaisyuAmount3;
//    @Column(name = "RUIKEI_KAISYU_AMOUNT_4")
//    private BigDecimal ruikeiKaisyuAmount4;
//    @Column(name = "RUIKEI_KAISYU_AMOUNT_5")
//    private BigDecimal ruikeiKaisyuAmount5;
//    @Column(name = "RUIKEI_KAISYU_AMOUNT_6")
//    private BigDecimal ruikeiKaisyuAmount6;
//    @Column(name = "RUIKEI_KAISYU_AMOUNT_7")
//    private BigDecimal ruikeiKaisyuAmount7;
//    @Column(name = "RUIKEI_KAISYU_AMOUNT_8")
//    private BigDecimal ruikeiKaisyuAmount8;
//    @Column(name = "RUIKEI_KAISYU_AMOUNT_9")
//    private BigDecimal ruikeiKaisyuAmount9;
//    @Column(name = "RUIKEI_KAISYU_AMOUNT_10")
//    private BigDecimal ruikeiKaisyuAmount10;
//    @Column(name = "RUIKEI_KAISYU_AMOUNT_11")
//    private BigDecimal ruikeiKaisyuAmount11;
//    @Column(name = "RUIKEI_KAISYU_AMOUNT_12")
//    private BigDecimal ruikeiKaisyuAmount12;;
//    @Column(name = "RUIKEI_KAISYU_AMOUNT_TM")
//    private BigDecimal ruikeiKaisyuAmountTm;
//    @Column(name = "RUIKEI_KAISYU_AMOUNT_K1")
//    private BigDecimal ruikeiKaisyuAmountK1;
//    @Column(name = "RUIKEI_KAISYU_AMOUNT_K2")
//    private BigDecimal ruikeiKaisyuAmountK2;
//    @Column(name = "RUIKEI_KAISYU_AMOUNT_G")
//    private BigDecimal ruikeiKaisyuAmountG;
//    @Column(name = "RUIKEI_KAISYU_AMOUNT_F")
//    private BigDecimal ruikeiKaisyuAmountF;
//    @Column(name = "RUIKEI_KAISYU_AMOUNT_K1_DIFF")
//    private BigDecimal ruikeiKaisyuAmountK1Diff;
//    @Column(name = "RUIKEI_KAISYU_AMOUNT_K2_DIFF")
//    private BigDecimal ruikeiKaisyuAmountK2Diff;
//    @Column(name = "RUIKEI_KAISYU_AMOUNT_G_DIFF")
//    private BigDecimal ruikeiKaisyuAmountGDiff;
//    @Column(name = "RUIKEI_KAISYU_AMOUNT_DIFF")
//    private BigDecimal ruikeiKaisyuAmountDiff;

//    @Column(name = "MI_KAISYU_AMOUNT_1")
//    private BigDecimal miKaisyuAmount1;
//    @Column(name = "MI_KAISYU_AMOUNT_2")
//    private BigDecimal miKaisyuAmount2;
//    @Column(name = "MI_KAISYU_AMOUNT_3")
//    private BigDecimal miKaisyuAmount3;
//    @Column(name = "MI_KAISYU_AMOUNT_4")
//    private BigDecimal miKaisyuAmount4;
//    @Column(name = "MI_KAISYU_AMOUNT_5")
//    private BigDecimal miKaisyuAmount5;
//    @Column(name = "MI_KAISYU_AMOUNT_6")
//    private BigDecimal miKaisyuAmount6;
//    @Column(name = "MI_KAISYU_AMOUNT_7")
//    private BigDecimal miKaisyuAmount7;
//    @Column(name = "MI_KAISYU_AMOUNT_8")
//    private BigDecimal miKaisyuAmount8;
//    @Column(name = "MI_KAISYU_AMOUNT_9")
//    private BigDecimal miKaisyuAmount9;
//    @Column(name = "MI_KAISYU_AMOUNT_10")
//    private BigDecimal miKaisyuAmount10;
//    @Column(name = "MI_KAISYU_AMOUNT_11")
//    private BigDecimal miKaisyuAmount11;
//    @Column(name = "MI_KAISYU_AMOUNT_12")
//    private BigDecimal miKaisyuAmount12;;
//    @Column(name = "MI_KAISYU_AMOUNT_TM")
//    private BigDecimal miKaisyuAmountTm;
//    @Column(name = "MI_KAISYU_AMOUNT_K1")
//    private BigDecimal miKaisyuAmountK1;
//    @Column(name = "MI_KAISYU_AMOUNT_K2")
//    private BigDecimal miKaisyuAmountK2;
//    @Column(name = "MI_KAISYU_AMOUNT_G")
//    private BigDecimal miKaisyuAmountG;
//    @Column(name = "MI_KAISYU_AMOUNT_F")
//    private BigDecimal miKaisyuAmountF;
//    @Column(name = "MI_KAISYU_AMOUNT_K1_DIFF")
//    private BigDecimal miKaisyuAmountK1Diff;
//    @Column(name = "MI_KAISYU_AMOUNT_K2_DIFF")
//    private BigDecimal miKaisyuAmountK2Diff;
//    @Column(name = "MI_KAISYU_AMOUNT_G_DIFF")
//    private BigDecimal miKaisyuAmountGDiff;
//    @Column(name = "MI_KAISYU_AMOUNT_DIFF")
//    private BigDecimal miKaisyuAmountDiff;


//    @Column(name = "RUIKEI_KAISYU_AMOUNT_1Q")
//    private BigDecimal ruikeiKaisyuAmount1Q;
//    @Column(name = "RUIKEI_KAISYU_AMOUNT_2Q")
//    private BigDecimal ruikeiKaisyuAmount2Q;
//    @Column(name = "RUIKEI_KAISYU_AMOUNT_3Q")
//    private BigDecimal ruikeiKaisyuAmount3Q;
//    @Column(name = "RUIKEI_KAISYU_AMOUNT_4Q")
//    private BigDecimal ruikeiKaisyuAmount4Q;
//    @Column(name = "RUIKEI_KAISYU_AMOUNT_1Q_Diff")
//    private BigDecimal ruikeiKaisyuAmount1QDiff;
//    @Column(name = "RUIKEI_KAISYU_AMOUNT_2Q_Diff")
//    private BigDecimal ruikeiKaisyuAmount2QDiff;
//    @Column(name = "RUIKEI_KAISYU_AMOUNT_3Q_Diff")
//    private BigDecimal ruikeiKaisyuAmount3QDiff;
//    @Column(name = "RUIKEI_KAISYU_AMOUNT_4Q_Diff")
//    private BigDecimal ruikeiKaisyuAmount4QDiff;

//    @Column(name = "MI_KAISYU_AMOUNT_1Q")
//    private BigDecimal miKaisyuAmount1Q;
//    @Column(name = "MI_KAISYU_AMOUNT_2Q")
//    private BigDecimal miKaisyuAmount2Q;
//    @Column(name = "MI_KAISYU_AMOUNT_3Q")
//    private BigDecimal miKaisyuAmount3Q;
//    @Column(name = "MI_KAISYU_AMOUNT_4Q")
//    private BigDecimal miKaisyuAmount4Q;
//    @Column(name = "MI_KAISYU_AMOUNT_1Q_Diff")
//    private BigDecimal miKaisyuAmount1QDiff;
//    @Column(name = "MI_KAISYU_AMOUNT_2Q_Diff")
//    private BigDecimal miKaisyuAmount2QDiff;
//    @Column(name = "MI_KAISYU_AMOUNT_3Q_Diff")
//    private BigDecimal miKaisyuAmount3QDiff;
//    @Column(name = "MI_KAISYU_AMOUNT_4Q_Diff")
//    private BigDecimal miKaisyuAmount4QDiff;

//    @Column(name = "KAISYU_AMOUNT_TOTAL")
//    private BigDecimal kaisyuAmountTotal;
//    @Column(name = "RUIKEI_KAISYU_AMOUNT_TOTAL")
//    private BigDecimal ruikeiKaisyuAmountTotal;
//    @Column(name = "MI_KAISYU_AMOUNT_TOTAL")
//    private BigDecimal miKaisyuAmountTotal;

    public RecoveryAmount() {
    }

    public String getCurrencyCode() {
        return this.currencyCode;
    }

    public void setCurrencyCode(String currencyCode) {
        this.currencyCode = currencyCode;
    }

    public BigDecimal getKaisyuAmount1() {
        return this.kaisyuAmount1;
    }

    public void setKaisyuAmount1(BigDecimal kaisyuAmount1) {
        this.kaisyuAmount1 = kaisyuAmount1;
    }

    public BigDecimal getKaisyuAmount2() {
        return this.kaisyuAmount2;
    }

    public void setKaisyuAmount2(BigDecimal kaisyuAmount2) {
        this.kaisyuAmount2 = kaisyuAmount2;
    }

    public BigDecimal getKaisyuAmount3() {
        return this.kaisyuAmount3;
    }

    public void setKaisyuAmount3(BigDecimal kaisyuAmount3) {
        this.kaisyuAmount3 = kaisyuAmount3;
    }

    public BigDecimal getKaisyuAmount4() {
        return this.kaisyuAmount4;
    }

    public void setKaisyuAmount4(BigDecimal kaisyuAmount4) {
        this.kaisyuAmount4 = kaisyuAmount4;
    }

    public BigDecimal getKaisyuAmount5() {
        return this.kaisyuAmount5;
    }

    public void setKaisyuAmount5(BigDecimal kaisyuAmount5) {
        this.kaisyuAmount5 = kaisyuAmount5;
    }

    public BigDecimal getKaisyuAmount6() {
        return this.kaisyuAmount6;
    }

    public void setKaisyuAmount6(BigDecimal kaisyuAmount6) {
        this.kaisyuAmount6 = kaisyuAmount6;
    }

    public BigDecimal getKaisyuAmount7() {
        return this.kaisyuAmount7;
    }

    public void setKaisyuAmount7(BigDecimal kaisyuAmount7) {
        this.kaisyuAmount7 = kaisyuAmount7;
    }

    public BigDecimal getKaisyuAmount8() {
        return this.kaisyuAmount8;
    }

    public void setKaisyuAmount8(BigDecimal kaisyuAmount8) {
        this.kaisyuAmount8 = kaisyuAmount8;
    }

    public BigDecimal getKaisyuAmount9() {
        return this.kaisyuAmount9;
    }

    public void setKaisyuAmount9(BigDecimal kaisyuAmount9) {
        this.kaisyuAmount9 = kaisyuAmount9;
    }

    public BigDecimal getKaisyuAmount10() {
        return this.kaisyuAmount10;
    }

    public void setKaisyuAmount10(BigDecimal kaisyuAmount10) {
        this.kaisyuAmount10 = kaisyuAmount10;
    }

    public BigDecimal getKaisyuAmount11() {
        return this.kaisyuAmount11;
    }

    public void setKaisyuAmount11(BigDecimal kaisyuAmount11) {
        this.kaisyuAmount11 = kaisyuAmount11;
    }

    public BigDecimal getKaisyuAmount12() {
        return this.kaisyuAmount12;
    }

    public void setKaisyuAmount12(BigDecimal kaisyuAmount12) {
        this.kaisyuAmount12 = kaisyuAmount12;
    }

    public BigDecimal getKaisyuAmountTm() {
        return this.kaisyuAmountTm;
    }

    public void setKaisyuAmountTm(BigDecimal kaisyuAmountTm) {
        this.kaisyuAmountTm = kaisyuAmountTm;
    }

    public BigDecimal getKaisyuAmountK1() {
        return this.kaisyuAmountK1;
    }

    public void setKaisyuAmountK1(BigDecimal kaisyuAmountK1) {
        this.kaisyuAmountK1 = kaisyuAmountK1;
    }

    public BigDecimal getKaisyuAmountK2() {
        return this.kaisyuAmountK2;
    }

    public void setKaisyuAmountK2(BigDecimal kaisyuAmountK2) {
        this.kaisyuAmountK2 = kaisyuAmountK2;
    }

    public BigDecimal getKaisyuAmountG() {
        return this.kaisyuAmountG;
    }

    public void setKaisyuAmountG(BigDecimal kaisyuAmountG) {
        this.kaisyuAmountG = kaisyuAmountG;
    }

    public BigDecimal getKaisyuAmountF() {
        return this.kaisyuAmountF;
    }

    public void setKaisyuAmountF(BigDecimal kaisyuAmountF) {
        this.kaisyuAmountF = kaisyuAmountF;
    }

    public BigDecimal getKaisyuAmountK1Diff() {
        return this.kaisyuAmountK1Diff;
    }

    public void setKaisyuAmountK1Diff(BigDecimal kaisyuAmountK1Diff) {
        this.kaisyuAmountK1Diff = kaisyuAmountK1Diff;
    }

    public BigDecimal getKaisyuAmountK2Diff() {
        return this.kaisyuAmountK2Diff;
    }

    public void setKaisyuAmountK2Diff(BigDecimal kaisyuAmountK2Diff) {
        this.kaisyuAmountK2Diff = kaisyuAmountK2Diff;
    }

    public BigDecimal getKaisyuAmountGDiff() {
        return this.kaisyuAmountGDiff;
    }

    public void setKaisyuAmountGDiff(BigDecimal kaisyuAmountGDiff) {
        this.kaisyuAmountGDiff = kaisyuAmountGDiff;
    }

    public BigDecimal getKaisyuAmountDiff() {
        return this.kaisyuAmountDiff;
    }

    public void setKaisyuAmountDiff(BigDecimal kaisyuAmountDiff) {
        this.kaisyuAmountDiff = kaisyuAmountDiff;
    }

    public BigDecimal getKaisyuAmount1Q() {
        return kaisyuAmount1Q;
    }

    public void setKaisyuAmount1Q(BigDecimal kaisyuAmount1Q) {
        this.kaisyuAmount1Q = kaisyuAmount1Q;
    }

    public BigDecimal getKaisyuAmount2Q() {
        return kaisyuAmount2Q;
    }

    public void setKaisyuAmount2Q(BigDecimal kaisyuAmount2Q) {
        this.kaisyuAmount2Q = kaisyuAmount2Q;
    }

    public BigDecimal getKaisyuAmount3Q() {
        return kaisyuAmount3Q;
    }

    public void setKaisyuAmount3Q(BigDecimal kaisyuAmount3Q) {
        this.kaisyuAmount3Q = kaisyuAmount3Q;
    }

    public BigDecimal getKaisyuAmount4Q() {
        return kaisyuAmount4Q;
    }

    public void setKaisyuAmount4Q(BigDecimal kaisyuAmount4Q) {
        this.kaisyuAmount4Q = kaisyuAmount4Q;
    }

    public BigDecimal getKaisyuAmount1QDiff() {
        return kaisyuAmount1QDiff;
    }

    public void setKaisyuAmount1QDiff(BigDecimal kaisyuAmount1QDiff) {
        this.kaisyuAmount1QDiff = kaisyuAmount1QDiff;
    }

    public BigDecimal getKaisyuAmount2QDiff() {
        return kaisyuAmount2QDiff;
    }

    public void setKaisyuAmount2QDiff(BigDecimal kaisyuAmount2QDiff) {
        this.kaisyuAmount2QDiff = kaisyuAmount2QDiff;
    }

    public BigDecimal getKaisyuAmount3QDiff() {
        return kaisyuAmount3QDiff;
    }

    public void setKaisyuAmount3QDiff(BigDecimal kaisyuAmount3QDiff) {
        this.kaisyuAmount3QDiff = kaisyuAmount3QDiff;
    }

    public BigDecimal getKaisyuAmount4QDiff() {
        return kaisyuAmount4QDiff;
    }

    public void setKaisyuAmount4QDiff(BigDecimal kaisyuAmount4QDiff) {
        this.kaisyuAmount4QDiff = kaisyuAmount4QDiff;
    }

    public String getZeiKbn() {
        return zeiKbn;
    }

    public void setZeiKbn(String zeiKbn) {
        this.zeiKbn = zeiKbn;
    }

    public String getKinsyuKbn() {
        return kinsyuKbn;
    }

    public void setKinsyuKbn(String kinsyuKbn) {
        this.kinsyuKbn = kinsyuKbn;
    }

    public String getKaisyuKbn() {
        return kaisyuKbn;
    }

    public void setKaisyuKbn(String kaisyuKbn) {
        this.kaisyuKbn = kaisyuKbn;
    }

    public int getCurrencyCodeCount() {
        return currencyCodeCount;
    }

    public void setCurrencyCodeCount(int currencyCodeCount) {
        this.currencyCodeCount = currencyCodeCount;
    }

    public String getPreCurrencyCode() {
        return preCurrencyCode;
    }

    public void setPreCurrencyCode(String preCurrencyCode) {
        this.preCurrencyCode = preCurrencyCode;
    }

    public String getZeiRnm() {
        return zeiRnm;
    }

    public void setZeiRnm(String zeiRnm) {
        this.zeiRnm = zeiRnm;
    }

    public BigDecimal getZeiRate() {
        return zeiRate;
    }

    public void setZeiRate(BigDecimal zeiRate) {
        this.zeiRate = zeiRate;
    }

    public BigDecimal getPreKaisyuAmountTotal() {
        return preKaisyuAmountTotal;
    }

    public void setPreKaisyuAmountTotal(BigDecimal preKaisyuAmountTotal) {
        this.preKaisyuAmountTotal = preKaisyuAmountTotal;
    }

    public BigDecimal getPreKaisyuEnkaAmountTotal() {
        return preKaisyuEnkaAmountTotal;
    }

    public void setPreKaisyuEnkaAmountTotal(BigDecimal preKaisyuEnkaAmountTotal) {
        this.preKaisyuEnkaAmountTotal = preKaisyuEnkaAmountTotal;
    }

    public BigDecimal getKaisyuEnkaAmount1() {
        return kaisyuEnkaAmount1;
    }

    public void setKaisyuEnkaAmount1(BigDecimal kaisyuEnkaAmount1) {
        this.kaisyuEnkaAmount1 = kaisyuEnkaAmount1;
    }

    public BigDecimal getKaisyuEnkaAmount2() {
        return kaisyuEnkaAmount2;
    }

    public void setKaisyuEnkaAmount2(BigDecimal kaisyuEnkaAmount2) {
        this.kaisyuEnkaAmount2 = kaisyuEnkaAmount2;
    }

    public BigDecimal getKaisyuEnkaAmount3() {
        return kaisyuEnkaAmount3;
    }

    public void setKaisyuEnkaAmount3(BigDecimal kaisyuEnkaAmount3) {
        this.kaisyuEnkaAmount3 = kaisyuEnkaAmount3;
    }

    public BigDecimal getKaisyuEnkaAmount4() {
        return kaisyuEnkaAmount4;
    }

    public void setKaisyuEnkaAmount4(BigDecimal kaisyuEnkaAmount4) {
        this.kaisyuEnkaAmount4 = kaisyuEnkaAmount4;
    }

    public BigDecimal getKaisyuEnkaAmount5() {
        return kaisyuEnkaAmount5;
    }

    public void setKaisyuEnkaAmount5(BigDecimal kaisyuEnkaAmount5) {
        this.kaisyuEnkaAmount5 = kaisyuEnkaAmount5;
    }

    public BigDecimal getKaisyuEnkaAmount6() {
        return kaisyuEnkaAmount6;
    }

    public void setKaisyuEnkaAmount6(BigDecimal kaisyuEnkaAmount6) {
        this.kaisyuEnkaAmount6 = kaisyuEnkaAmount6;
    }

    public BigDecimal getKaisyuEnkaAmount7() {
        return kaisyuEnkaAmount7;
    }

    public void setKaisyuEnkaAmount7(BigDecimal kaisyuEnkaAmount7) {
        this.kaisyuEnkaAmount7 = kaisyuEnkaAmount7;
    }

    public BigDecimal getKaisyuEnkaAmount8() {
        return kaisyuEnkaAmount8;
    }

    public void setKaisyuEnkaAmount8(BigDecimal kaisyuEnkaAmount8) {
        this.kaisyuEnkaAmount8 = kaisyuEnkaAmount8;
    }

    public BigDecimal getKaisyuEnkaAmount9() {
        return kaisyuEnkaAmount9;
    }

    public void setKaisyuEnkaAmount9(BigDecimal kaisyuEnkaAmount9) {
        this.kaisyuEnkaAmount9 = kaisyuEnkaAmount9;
    }

    public BigDecimal getKaisyuEnkaAmount10() {
        return kaisyuEnkaAmount10;
    }

    public void setKaisyuEnkaAmount10(BigDecimal kaisyuEnkaAmount10) {
        this.kaisyuEnkaAmount10 = kaisyuEnkaAmount10;
    }

    public BigDecimal getKaisyuEnkaAmount11() {
        return kaisyuEnkaAmount11;
    }

    public void setKaisyuEnkaAmount11(BigDecimal kaisyuEnkaAmount11) {
        this.kaisyuEnkaAmount11 = kaisyuEnkaAmount11;
    }

    public BigDecimal getKaisyuEnkaAmount12() {
        return kaisyuEnkaAmount12;
    }

    public void setKaisyuEnkaAmount12(BigDecimal kaisyuEnkaAmount12) {
        this.kaisyuEnkaAmount12 = kaisyuEnkaAmount12;
    }

    public BigDecimal getKaisyuEnkaAmountTm() {
        return kaisyuEnkaAmountTm;
    }

    public void setKaisyuEnkaAmountTm(BigDecimal kaisyuEnkaAmountTm) {
        this.kaisyuEnkaAmountTm = kaisyuEnkaAmountTm;
    }

    public BigDecimal getKaisyuEnkaAmountK1() {
        return kaisyuEnkaAmountK1;
    }

    public void setKaisyuEnkaAmountK1(BigDecimal kaisyuEnkaAmountK1) {
        this.kaisyuEnkaAmountK1 = kaisyuEnkaAmountK1;
    }

    public BigDecimal getKaisyuEnkaAmountK2() {
        return kaisyuEnkaAmountK2;
    }

    public void setKaisyuEnkaAmountK2(BigDecimal kaisyuEnkaAmountK2) {
        this.kaisyuEnkaAmountK2 = kaisyuEnkaAmountK2;
    }

    public BigDecimal getKaisyuEnkaAmountG() {
        return kaisyuEnkaAmountG;
    }

    public void setKaisyuEnkaAmountG(BigDecimal kaisyuEnkaAmountG) {
        this.kaisyuEnkaAmountG = kaisyuEnkaAmountG;
    }

    public BigDecimal getKaisyuEnkaAmountF() {
        return kaisyuEnkaAmountF;
    }

    public void setKaisyuEnkaAmountF(BigDecimal kaisyuEnkaAmountF) {
        this.kaisyuEnkaAmountF = kaisyuEnkaAmountF;
    }

    public BigDecimal getKaisyuEnkaAmountK1Diff() {
        return kaisyuEnkaAmountK1Diff;
    }

    public void setKaisyuEnkaAmountK1Diff(BigDecimal kaisyuEnkaAmountK1Diff) {
        this.kaisyuEnkaAmountK1Diff = kaisyuEnkaAmountK1Diff;
    }

    public BigDecimal getKaisyuEnkaAmountK2Diff() {
        return kaisyuEnkaAmountK2Diff;
    }

    public void setKaisyuEnkaAmountK2Diff(BigDecimal kaisyuEnkaAmountK2Diff) {
        this.kaisyuEnkaAmountK2Diff = kaisyuEnkaAmountK2Diff;
    }

    public BigDecimal getKaisyuEnkaAmountGDiff() {
        return kaisyuEnkaAmountGDiff;
    }

    public void setKaisyuEnkaAmountGDiff(BigDecimal kaisyuEnkaAmountGDiff) {
        this.kaisyuEnkaAmountGDiff = kaisyuEnkaAmountGDiff;
    }

    public BigDecimal getKaisyuEnkaAmountDiff() {
        return kaisyuEnkaAmountDiff;
    }

    public void setKaisyuEnkaAmountDiff(BigDecimal kaisyuEnkaAmountDiff) {
        this.kaisyuEnkaAmountDiff = kaisyuEnkaAmountDiff;
    }

    public BigDecimal getKaisyuEnkaAmount1Q() {
        return kaisyuEnkaAmount1Q;
    }

    public void setKaisyuEnkaAmount1Q(BigDecimal kaisyuEnkaAmount1Q) {
        this.kaisyuEnkaAmount1Q = kaisyuEnkaAmount1Q;
    }

    public BigDecimal getKaisyuEnkaAmount2Q() {
        return kaisyuEnkaAmount2Q;
    }

    public void setKaisyuEnkaAmount2Q(BigDecimal kaisyuEnkaAmount2Q) {
        this.kaisyuEnkaAmount2Q = kaisyuEnkaAmount2Q;
    }

    public BigDecimal getKaisyuEnkaAmount3Q() {
        return kaisyuEnkaAmount3Q;
    }

    public void setKaisyuEnkaAmount3Q(BigDecimal kaisyuEnkaAmount3Q) {
        this.kaisyuEnkaAmount3Q = kaisyuEnkaAmount3Q;
    }

    public BigDecimal getKaisyuEnkaAmount4Q() {
        return kaisyuEnkaAmount4Q;
    }

    public void setKaisyuEnkaAmount4Q(BigDecimal kaisyuEnkaAmount4Q) {
        this.kaisyuEnkaAmount4Q = kaisyuEnkaAmount4Q;
    }

    public BigDecimal getKaisyuEnkaAmount1QDiff() {
        return kaisyuEnkaAmount1QDiff;
    }

    public void setKaisyuEnkaAmount1QDiff(BigDecimal kaisyuEnkaAmount1QDiff) {
        this.kaisyuEnkaAmount1QDiff = kaisyuEnkaAmount1QDiff;
    }

    public BigDecimal getKaisyuEnkaAmount2QDiff() {
        return kaisyuEnkaAmount2QDiff;
    }

    public void setKaisyuEnkaAmount2QDiff(BigDecimal kaisyuEnkaAmount2QDiff) {
        this.kaisyuEnkaAmount2QDiff = kaisyuEnkaAmount2QDiff;
    }

    public BigDecimal getKaisyuEnkaAmount3QDiff() {
        return kaisyuEnkaAmount3QDiff;
    }

    public void setKaisyuEnkaAmount3QDiff(BigDecimal kaisyuEnkaAmount3QDiff) {
        this.kaisyuEnkaAmount3QDiff = kaisyuEnkaAmount3QDiff;
    }

    public BigDecimal getKaisyuEnkaAmount4QDiff() {
        return kaisyuEnkaAmount4QDiff;
    }

    public void setKaisyuEnkaAmount4QDiff(BigDecimal kaisyuEnkaAmount4QDiff) {
        this.kaisyuEnkaAmount4QDiff = kaisyuEnkaAmount4QDiff;
    }

    public BigDecimal getPreKaisyuEnkaZeiTotal() {
        return preKaisyuEnkaZeiTotal;
    }

    public void setPreKaisyuEnkaZeiTotal(BigDecimal preKaisyuEnkaZeiTotal) {
        this.preKaisyuEnkaZeiTotal = preKaisyuEnkaZeiTotal;
    }

    public BigDecimal getKaisyuEnkaZei1() {
        return kaisyuEnkaZei1;
    }

    public void setKaisyuEnkaZei1(BigDecimal kaisyuEnkaZei1) {
        this.kaisyuEnkaZei1 = kaisyuEnkaZei1;
    }

    public BigDecimal getKaisyuEnkaZei2() {
        return kaisyuEnkaZei2;
    }

    public void setKaisyuEnkaZei2(BigDecimal kaisyuEnkaZei2) {
        this.kaisyuEnkaZei2 = kaisyuEnkaZei2;
    }

    public BigDecimal getKaisyuEnkaZei3() {
        return kaisyuEnkaZei3;
    }

    public void setKaisyuEnkaZei3(BigDecimal kaisyuEnkaZei3) {
        this.kaisyuEnkaZei3 = kaisyuEnkaZei3;
    }

    public BigDecimal getKaisyuEnkaZei4() {
        return kaisyuEnkaZei4;
    }

    public void setKaisyuEnkaZei4(BigDecimal kaisyuEnkaZei4) {
        this.kaisyuEnkaZei4 = kaisyuEnkaZei4;
    }

    public BigDecimal getKaisyuEnkaZei5() {
        return kaisyuEnkaZei5;
    }

    public void setKaisyuEnkaZei5(BigDecimal kaisyuEnkaZei5) {
        this.kaisyuEnkaZei5 = kaisyuEnkaZei5;
    }

    public BigDecimal getKaisyuEnkaZei6() {
        return kaisyuEnkaZei6;
    }

    public void setKaisyuEnkaZei6(BigDecimal kaisyuEnkaZei6) {
        this.kaisyuEnkaZei6 = kaisyuEnkaZei6;
    }

    public BigDecimal getKaisyuEnkaZei7() {
        return kaisyuEnkaZei7;
    }

    public void setKaisyuEnkaZei7(BigDecimal kaisyuEnkaZei7) {
        this.kaisyuEnkaZei7 = kaisyuEnkaZei7;
    }

    public BigDecimal getKaisyuEnkaZei8() {
        return kaisyuEnkaZei8;
    }

    public void setKaisyuEnkaZei8(BigDecimal kaisyuEnkaZei8) {
        this.kaisyuEnkaZei8 = kaisyuEnkaZei8;
    }

    public BigDecimal getKaisyuEnkaZei9() {
        return kaisyuEnkaZei9;
    }

    public void setKaisyuEnkaZei9(BigDecimal kaisyuEnkaZei9) {
        this.kaisyuEnkaZei9 = kaisyuEnkaZei9;
    }

    public BigDecimal getKaisyuEnkaZei10() {
        return kaisyuEnkaZei10;
    }

    public void setKaisyuEnkaZei10(BigDecimal kaisyuEnkaZei10) {
        this.kaisyuEnkaZei10 = kaisyuEnkaZei10;
    }

    public BigDecimal getKaisyuEnkaZei11() {
        return kaisyuEnkaZei11;
    }

    public void setKaisyuEnkaZei11(BigDecimal kaisyuEnkaZei11) {
        this.kaisyuEnkaZei11 = kaisyuEnkaZei11;
    }

    public BigDecimal getKaisyuEnkaZei12() {
        return kaisyuEnkaZei12;
    }

    public void setKaisyuEnkaZei12(BigDecimal kaisyuEnkaZei12) {
        this.kaisyuEnkaZei12 = kaisyuEnkaZei12;
    }

    public BigDecimal getKaisyuEnkaZeiTm() {
        return kaisyuEnkaZeiTm;
    }

    public void setKaisyuEnkaZeiTm(BigDecimal kaisyuEnkaZeiTm) {
        this.kaisyuEnkaZeiTm = kaisyuEnkaZeiTm;
    }

    public BigDecimal getKaisyuEnkaZeiK1() {
        return kaisyuEnkaZeiK1;
    }

    public void setKaisyuEnkaZeiK1(BigDecimal kaisyuEnkaZeiK1) {
        this.kaisyuEnkaZeiK1 = kaisyuEnkaZeiK1;
    }

    public BigDecimal getKaisyuEnkaZeiK2() {
        return kaisyuEnkaZeiK2;
    }

    public void setKaisyuEnkaZeiK2(BigDecimal kaisyuEnkaZeiK2) {
        this.kaisyuEnkaZeiK2 = kaisyuEnkaZeiK2;
    }

    public BigDecimal getKaisyuEnkaZeiG() {
        return kaisyuEnkaZeiG;
    }

    public void setKaisyuEnkaZeiG(BigDecimal kaisyuEnkaZeiG) {
        this.kaisyuEnkaZeiG = kaisyuEnkaZeiG;
    }

    public BigDecimal getKaisyuEnkaZeiF() {
        return kaisyuEnkaZeiF;
    }

    public void setKaisyuEnkaZeiF(BigDecimal kaisyuEnkaZeiF) {
        this.kaisyuEnkaZeiF = kaisyuEnkaZeiF;
    }

    public BigDecimal getKaisyuEnkaZeiK1Diff() {
        return kaisyuEnkaZeiK1Diff;
    }

    public void setKaisyuEnkaZeiK1Diff(BigDecimal kaisyuEnkaZeiK1Diff) {
        this.kaisyuEnkaZeiK1Diff = kaisyuEnkaZeiK1Diff;
    }

    public BigDecimal getKaisyuEnkaZeiK2Diff() {
        return kaisyuEnkaZeiK2Diff;
    }

    public void setKaisyuEnkaZeiK2Diff(BigDecimal kaisyuEnkaZeiK2Diff) {
        this.kaisyuEnkaZeiK2Diff = kaisyuEnkaZeiK2Diff;
    }

    public BigDecimal getKaisyuEnkaZeiGDiff() {
        return kaisyuEnkaZeiGDiff;
    }

    public void setKaisyuEnkaZeiGDiff(BigDecimal kaisyuEnkaZeiGDiff) {
        this.kaisyuEnkaZeiGDiff = kaisyuEnkaZeiGDiff;
    }

    public BigDecimal getKaisyuEnkaZeiDiff() {
        return kaisyuEnkaZeiDiff;
    }

    public void setKaisyuEnkaZeiDiff(BigDecimal kaisyuEnkaZeiDiff) {
        this.kaisyuEnkaZeiDiff = kaisyuEnkaZeiDiff;
    }

    public BigDecimal getKaisyuEnkaZei1Q() {
        return kaisyuEnkaZei1Q;
    }

    public void setKaisyuEnkaZei1Q(BigDecimal kaisyuEnkaZei1Q) {
        this.kaisyuEnkaZei1Q = kaisyuEnkaZei1Q;
    }

    public BigDecimal getKaisyuEnkaZei2Q() {
        return kaisyuEnkaZei2Q;
    }

    public void setKaisyuEnkaZei2Q(BigDecimal kaisyuEnkaZei2Q) {
        this.kaisyuEnkaZei2Q = kaisyuEnkaZei2Q;
    }

    public BigDecimal getKaisyuEnkaZei3Q() {
        return kaisyuEnkaZei3Q;
    }

    public void setKaisyuEnkaZei3Q(BigDecimal kaisyuEnkaZei3Q) {
        this.kaisyuEnkaZei3Q = kaisyuEnkaZei3Q;
    }

    public BigDecimal getKaisyuEnkaZei4Q() {
        return kaisyuEnkaZei4Q;
    }

    public void setKaisyuEnkaZei4Q(BigDecimal kaisyuEnkaZei4Q) {
        this.kaisyuEnkaZei4Q = kaisyuEnkaZei4Q;
    }

    public BigDecimal getKaisyuEnkaZei1QDiff() {
        return kaisyuEnkaZei1QDiff;
    }

    public void setKaisyuEnkaZei1QDiff(BigDecimal kaisyuEnkaZei1QDiff) {
        this.kaisyuEnkaZei1QDiff = kaisyuEnkaZei1QDiff;
    }

    public BigDecimal getKaisyuEnkaZei2QDiff() {
        return kaisyuEnkaZei2QDiff;
    }

    public void setKaisyuEnkaZei2QDiff(BigDecimal kaisyuEnkaZei2QDiff) {
        this.kaisyuEnkaZei2QDiff = kaisyuEnkaZei2QDiff;
    }

    public BigDecimal getKaisyuEnkaZei3QDiff() {
        return kaisyuEnkaZei3QDiff;
    }

    public void setKaisyuEnkaZei3QDiff(BigDecimal kaisyuEnkaZei3QDiff) {
        this.kaisyuEnkaZei3QDiff = kaisyuEnkaZei3QDiff;
    }

    public BigDecimal getKaisyuEnkaZei4QDiff() {
        return kaisyuEnkaZei4QDiff;
    }

    public void setKaisyuEnkaZei4QDiff(BigDecimal kaisyuEnkaZei4QDiff) {
        this.kaisyuEnkaZei4QDiff = kaisyuEnkaZei4QDiff;
    }

}
