package jp.co.toshiba.hby.pspromis.syuueki.service;

import java.math.BigDecimal;
import java.sql.SQLException;
import java.util.List;
import java.util.ArrayList;
import java.util.Map;
import java.util.HashMap;
import java.util.Arrays;
import java.util.Collection;
import java.util.Set;
import java.util.HashSet;
import java.util.LinkedHashSet;
import javax.annotation.Resource;
import javax.ejb.Stateless;
import javax.ejb.TransactionManagement;
import javax.ejb.TransactionManagementType;
import javax.inject.Inject;
import javax.interceptor.Interceptors;
import javax.transaction.UserTransaction;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import jp.co.toshiba.hby.pspromis.syuueki.bean.SyuekiFlgEditBean;
import jp.co.toshiba.hby.pspromis.syuueki.bean.SyuekiFlgEditBeanMessageBean;
import jp.co.toshiba.hby.pspromis.syuueki.dto.P0DaihyoAnkenSetDto;
//import jp.co.toshiba.hby.pspromis.syuueki.dto.NuclearRenkeiBatchDto;
import jp.co.toshiba.hby.pspromis.syuueki.dto.NuclearRenkeiSyuekiFlgBatchDto;
import jp.co.toshiba.hby.pspromis.syuueki.dto.SyuekiFlgMessageDto;
import jp.co.toshiba.hby.pspromis.syuueki.entity.OperationLog;
import jp.co.toshiba.hby.pspromis.syuueki.entity.TeamEntity;
import jp.co.toshiba.hby.pspromis.syuueki.entity.SyuGeBukkenInfoTbl;
import jp.co.toshiba.hby.pspromis.syuueki.enums.Env;
import jp.co.toshiba.hby.pspromis.syuueki.facade.SyuGeBukenInfoTblFacade;
import jp.co.toshiba.hby.pspromis.syuueki.facade.TeamMstFacade;
import jp.co.toshiba.hby.pspromis.syuueki.facade.NucUriageSetuFacade;
import jp.co.toshiba.hby.pspromis.syuueki.interceptor.TranceInterceptor;
import jp.co.toshiba.hby.pspromis.syuueki.util.ConstantString;
import jp.co.toshiba.hby.pspromis.syuueki.util.EntityUtils;
import jp.co.toshiba.hby.pspromis.syuueki.util.LoginUserInfo;
import jp.co.toshiba.hby.pspromis.syuueki.util.Utils;
import jp.co.toshiba.hby.pspromis.syuueki.enums.Label;
import jp.co.toshiba.hby.pspromis.syuueki.facade.KanjyoMstFacade;
import jp.co.toshiba.hby.pspromis.syuueki.pages.DivisonComponentPage;
//import jp.co.toshiba.hby.pspromis.syuueki.jdbc.SqlFile;
//import jp.co.toshiba.hby.pspromis.syuueki.jdbc.DbUtilsExecutor;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.collections.CollectionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * ES-Promis収益管理システム
 * 収益対象FLG設定・解除 Service
 * @author (NPC)S.Ibayashi
 */
@Stateless
@Interceptors({TranceInterceptor.class})
@TransactionManagement(TransactionManagementType.BEAN)
public class SyuekiFlgEditService {

    public static final Logger log = LoggerFactory.getLogger(SyuekiFlgEditService.class);

    @Inject
    private SyuekiFlgEditBean syuekiFlgEditBean;
    
    @Inject
    private SyuekiFlgEditBeanMessageBean syuekiFlgEditBeanMessageBean;

    @Inject
    private OperationLogService operationLogService;
    
    @Inject
    private SyuGeBukenInfoTblFacade syuGeBukenInfoTblFacade;

    @Inject
    private TeamMstFacade teamMstFacade;

    @Inject
    private SyuuekiCommonService syuuekiCommonService;
    
    @Inject
    private KanjyoMstFacade kanjyoMstFacade;
    
    @Inject
    private NucUriageSetuFacade ncUriageSetuFacade;
    
    @Inject
    private LoginUserInfo loginUserInfo;

    @Inject
    private StoredProceduresService storedProceduresService;

    @Inject
    private DivisonComponentPage divisionComponentPage;

    @Resource
    private UserTransaction userTransaction;

    /**
     * 案件の編集権限をチェック
     * @throws Exception 
     */
    //private boolean isAnkenEdit(SyuGeBukkenInfoTbl geEntity, List<TeamEntity> teamMstList) {
    private boolean isAnkenEdit(SyuGeBukkenInfoTbl geEntity) {
        //boolean isEdit = loginUserInfo.isAnkenEdit(geEntity, teamMstList);
        boolean isEdit = syuuekiCommonService.isAnkenEditOk(geEntity);
        return isEdit;
    }

    /**
     * (原子力)収益管理で当月の売上指示が行われているかをチェック(対象データ)
     */
    private boolean isCheckNuclaerUriSjiji(SyuGeBukkenInfoTbl geEntity, String kanjypMh) throws SQLException {
        //SqlFile sqlFile = new SqlFile();
        
        // SQLファイルの取得
        //String splFilePath = "/sql/nucUriageSetu/selectCountNucUriageSetu.sql";
        //log.info("[isCheckNuclaerUriSjiji] SQL_SELECT_FILE=[{}]", splFilePath);
        
        // パラメータを作成
        Map<String, Object> condition = new HashMap<>();
        condition.put("bukkenId", geEntity.getOldTAnkenNo());
        condition.put("uriagetuki", kanjypMh);
        
        //String sqlString = sqlFile.getSqlString(splFilePath, condition);
        //Object[] sqlParams = sqlFile.getSqlParams(splFilePath, condition);
        
        Integer count = ncUriageSetuFacade.countUriageSetu(condition);

        log.info("[isCheckNuclaerUriSjiji] T0130_URIAGE_SETU DATA COUNT=[{}]", count);
        if (count > 0) {
            return true;
        }

        return false;
    }

/**
 * (進行基準子案件暫定処置)
 * (原子力)進行基準子案件は一時的に収益対象設定の付け替えを不可にする
 * 該当データが存在する場合は、対象注番が格納されたCollection(Set)を取得
 * @param ankenTargetData 収益対象設定の案件/注番情報(key: orderNo=注番 newAnkenId=付け替え先案件 oldAnkenId=付け替え元案件)
 */
//private Set<String> getNucShinkoAnkenMessage(List<Map<String, String>> ankenTargetData) throws SQLException {
//    if (CollectionUtils.isEmpty(ankenTargetData)) {
//        return null;
//    }
//
//    Set<String> targetAnnkenIds = new LinkedHashSet<>();
//    String nuclearDivCode = StringUtils.defaultString(Env.Div_Gen.getValue());  // (原子力)事業部コード
//
//    for (Map<String, String> ankenInfo: ankenTargetData) {
//        String newAnkenId = StringUtils.defaultString(ankenInfo.get("newAnkenId"));
//        String divisionCode = StringUtils.defaultString(ankenInfo.get("divisionCode"));
//        String salesClass = StringUtils.defaultString(ankenInfo.get("salesClass"));
//        String ankenFlg = StringUtils.defaultString(ankenInfo.get("ankenFlg"));
//        String oldAnkenId = StringUtils.defaultString(ankenInfo.get("oldAnkenId"));
//
//        // (原子力)案件以外はこの暫定処置は不要なので処理をスルー
//        if (!divisionCode.equals(nuclearDivCode)) {
//            continue;
//        }
//
//        // 付け替え先の案件が進行基準子案件かどうかをチェック
//        if (ConstantString.salesClassS.equals(salesClass) && !"1".equals(ankenFlg)) {
//            targetAnnkenIds.add(newAnkenId);
//        }
//
//        if (StringUtils.isNotEmpty(oldAnkenId)) {
//            // 付け替え元案件が進行基準子案件かどうかをチェック
//            Map<String, Object> condition = new HashMap<>();
//            condition.put("ankenId", oldAnkenId);
//            condition.put("rirekiId", Integer.parseInt(ConstantString.geRirekiId));
//            SyuGeBukkenInfoTbl oldGeEntity = syuGeBukenInfoTblFacade.findPk(condition);
//            if (ConstantString.salesClassS.equals(oldGeEntity.getSalesClass()) && !"1".equals(oldGeEntity.getAnkenFlg())) {
//                targetAnnkenIds.add(oldAnkenId);
//            }
//        }
//    }
//
//    return targetAnnkenIds;
//}
    
    /**
     * (原子力)収益管理で当月の売上指示が行われているかをチェック
     * 該当データが存在する場合は、対象注番が格納されたCollection(Set)を取得
     * @param ankenTargetData 収益対象設定の案件/注番情報(key: orderNo=注番 newAnkenId=付け替え先案件 oldAnkenId=付け替え元案件)
     */
    private Set<String> getNucUriSijiAnkenMessage(List<Map<String, String>> ankenTargetData) throws SQLException {
        if (CollectionUtils.isEmpty(ankenTargetData)) {
            return null;
        }

        Set<String> uriShijiOrderNoSet = new LinkedHashSet<>();
        String nuclearMitumoriSeiTehai = StringUtils.defaultString(Env.Mitumori_Seitehai.getValue());  // (原子力)見積種類[正式手配]
        Map<String, String> kanjyoMhMap = new HashMap<>();  // key:SALES_CLASS VALUE:勘定年月
        
        for (Map<String, String> ankenInfo: ankenTargetData) {
            String oldAnkenId = ankenInfo.get("oldAnkenId");
            if (StringUtils.isNotEmpty(oldAnkenId)) {
                // 付け替え元案件のGE情報を取得
                Map<String, Object> condition = new HashMap<>();
                condition.put("ankenId", oldAnkenId);
                condition.put("rirekiId", Integer.parseInt(ConstantString.geRirekiId));
                SyuGeBukkenInfoTbl oldGeEntity = syuGeBukenInfoTblFacade.findPk(condition);

                // 事業部コード:(原子力)であるかを判断
                boolean isNuclearDivision = divisionComponentPage.isNuclearDivision(oldGeEntity.getDivisionCode());
                
                // (原子力・正式手配のみ)当月内で売上指示が行われている場合は収益FLG付け替え不可とする
                //if (nuclearDivCode.equals(oldGeEntity.getDivisionCode()) && nuclearMitumoriSeiTehai.equals(oldGeEntity.getMitumoriKbn()) && StringUtils.isNotEmpty(oldGeEntity.getOldTAnkenNo())) {
                if (isNuclearDivision && nuclearMitumoriSeiTehai.equals(oldGeEntity.getMitumoriKbn()) && StringUtils.isNotEmpty(oldGeEntity.getOldTAnkenNo())) {
                    // 現勘定年月を取得
                    if (!kanjyoMhMap.containsKey(oldGeEntity.getSalesClass())) {
                        String kanjyoMh = kanjyoMstFacade.getNowKanjoDate(oldGeEntity.getSalesClass());
                        kanjyoMhMap.put(oldGeEntity.getSalesClass(), kanjyoMh);
                    }
                    // 現勘定年月内で売上指示が行われているかをチェック
                    if (isCheckNuclaerUriSjiji(oldGeEntity, kanjyoMhMap.get(oldGeEntity.getSalesClass()))) {
                        uriShijiOrderNoSet.add(oldGeEntity.getOrderNo());
                    }
                }
            }
        }

        return uriShijiOrderNoSet;
    }
    
    /**
     * バリデーションチェック(収益FLG設定)
     * ここで、収益対象設定処理のためのデータの加工も同時に行う
     * @throws Exception 
     */
    public boolean validationEdit() throws Exception {
        log.info("SyuekiFlgEditService#validationEdit");

        String editSyuekiFlg = "1";
        String resultMessage = "";
        
        Set<String> allOrderNoSet = new HashSet<>();
        Set<String> repeatOrderNoSet = new LinkedHashSet<>();
        Set<String> noEditAnkenSet = new LinkedHashSet<>();
        Set<String> alreadySyuekiFlgSet = new LinkedHashSet<>();
        //List<TeamEntity> teamMstList = teamMstFacade.findUserTeamList(loginUserInfo.getUserId());
        
        // 画面で選択したデータを回しながら、更新対象を決定
        List<Map<String, String>> list = syuekiFlgEditBean.getAnkenList();
        for (String idx: syuekiFlgEditBean.getCheckData()) {
            int index = Integer.parseInt(idx);
            Map<String, String> data = list.get(index);

            // 案件を検索
            Map<String, Object> condition = new HashMap<>();
            condition.put("ankenId", StringUtils.defaultString((String)data.get("ankenId")));
            condition.put("rirekiId", Integer.parseInt(ConstantString.geRirekiId));
            SyuGeBukkenInfoTbl geEntity = syuGeBukenInfoTblFacade.findPk(condition);

            String ankenId = StringUtils.defaultString(geEntity.getAnkenId());
            String orderNo = StringUtils.defaultString(geEntity.getOrderNo());
            String syuekiFlg = StringUtils.defaultString(geEntity.getSyuekiFlg());
            String salesClass = StringUtils.defaultString(geEntity.getSalesClass());
            String ankenFlg = StringUtils.defaultString(geEntity.getAnkenFlg());
            String stageId = StringUtils.defaultString(String.valueOf(geEntity.getStageId()));

            // 編集権限チェック
            //if (!isAnkenEdit(geEntity, teamMstList)) {
            if (!isAnkenEdit(geEntity)) {
                noEditAnkenSet.add(ankenId);

            } else {
                if (!editSyuekiFlg.equals(syuekiFlg)) {  // これから設定しようとしている収益対象FLGになっていないデータを更新対象にする。
                    if (!ConstantString.salesClassS.equals(salesClass) || (ConstantString.salesClassS.equals(salesClass) && "1".equals(ankenFlg))) {
                        ////// 子案件(一般案件＋進行基準まとめの子案件)
                        if (StringUtils.isNotEmpty(orderNo) && !ConstantString.cancelStageId.equals(stageId)) {  // stageId=5は注番取消
                            if (allOrderNoSet.contains(orderNo)) {
                                repeatOrderNoSet.add(orderNo);
                            }
                        }

                        allOrderNoSet.add(orderNo);
                    }

                    // データ分類毎に、更新対象データを格納分けする。
                    setProcessData(geEntity, editSyuekiFlg);
                } else {
                    // 2017/08/03 既に収益設定されている案件は処理できない(必要がない)ため、処理不可データとしてエラー扱いにする。
                    alreadySyuekiFlgSet.add(ankenId);
                }
            }
        }

        // 2017/11 (NPC)S.Ibayashi add
        // (原子力・正式手配のみ)当月内で売上指示が行われている場合は収益FLG付け替え不可とする
        List<Map<String, String>> ippanAnkenTargetList = syuekiFlgEditBean.getIppanAnkenChangeTargetList();
        Set<String> uriShijiOrderNoSet = getNucUriSijiAnkenMessage(ippanAnkenTargetList);
        
// ↓この暫定処置は2018/01予定の恒久処置が完了次第解除する予定
// ↓恒久処置前は、進行基準子案件の収益FLGの付け替えを行うと(原子力)収益のデータが壊れてしまうため
///// (進行基準子案件暫定処置)(原子力のみ)進行基準子案件2017/12/15リリース版の暫定処置(S) ///////
//Set<String> nuclearShinkoAnkenSet = getNucShinkoAnkenMessage(ippanAnkenTargetList);
///// (進行基準子案件暫定処置)(原子力のみ)進行基準子案件2017/12/15リリース版の暫定処置(E) ///////

        if (CollectionUtils.isNotEmpty(alreadySyuekiFlgSet)) {
            String ankenIds = collectionToString(alreadySyuekiFlgSet);
            String alreadySyuekiFlgMessage = Label.alreadySyuekiFlg.getMessage(ankenIds);
            resultMessage = Utils.addStringBuff(resultMessage, alreadySyuekiFlgMessage, "\n");
        }
        if (CollectionUtils.isNotEmpty(noEditAnkenSet)) {
            String ankenIds = collectionToString(noEditAnkenSet);
            String noAuthAnkenMessage = Label.alertNoAuthSyuekiFlgEdit.getMessage(ankenIds);
            resultMessage = Utils.addStringBuff(resultMessage, noAuthAnkenMessage, "\n");
        }
        if (CollectionUtils.isNotEmpty(repeatOrderNoSet)) {
            String orderNos = collectionToString(repeatOrderNoSet);
            String orderNoErrorMessage = Label.alertOnlyOneOrderNoSyuekiFlgEdit.getMessage(orderNos);
            resultMessage = Utils.addStringBuff(resultMessage, orderNoErrorMessage, "\n");
        }
        // 2017/11 (NPC)S.Ibayashi add 当月売上指示済みのチェック用メッセージ追加
        if (CollectionUtils.isNotEmpty(uriShijiOrderNoSet)) {
            String orderNos = collectionToString(uriShijiOrderNoSet);
            String alreadyNucUriSijiMessage = Label.errorAlreadyNucUriSiji.getMessage(orderNos);
            resultMessage = Utils.addStringBuff(resultMessage, alreadyNucUriSijiMessage, "\n");
        }

///// (進行基準子案件暫定処置)(原子力のみ)進行基準子案件2017/12/15リリース版の暫定処置(S) ///////
//if (CollectionUtils.isNotEmpty(nuclearShinkoAnkenSet)) {
//    String ankenIds = collectionToString(nuclearShinkoAnkenSet);
//    // 暫定処置のため、メッセージもべたにしておく。
//    String nucShinkoAnkenMessage = StringUtils.replace("進行基準案件:#0#の収益対象設定は現在は行えません。", "#0#", ankenIds);
//    resultMessage = Utils.addStringBuff(resultMessage, nucShinkoAnkenMessage, "\n");
//}
///// (進行基準子案件暫定処置)(原子力のみ)進行基準子案件2017/12/15リリース版の暫定処置(E) ///////
        
        syuekiFlgEditBean.setResultMessage(resultMessage);
        if (StringUtils.isNotEmpty(resultMessage)) {
            syuekiFlgEditBean.setResultFlg("9");
            return false;
        }

        return true;
    }

    /**
     * バリデーションチェック(収益FLG解除)
     * @throws Exception 
     */
    public boolean validationRel() throws Exception {
        log.info("SyuekiFlgEditService#validationRel");
        
        String editSyuekiFlg = "0";
        String resultMessasge = "";
        
        Set<String> noOrderNoMatomeAnkenIdSet = new LinkedHashSet<>();
        Set<String> ippanNoOrderNoSet = new LinkedHashSet<>();
        Set<String> noEditAnkenSet = new LinkedHashSet<>();
        Set<String> alreadyNoSyuekiFlgSet = new LinkedHashSet<>();

        //List<TeamEntity> teamMstList = teamMstFacade.findUserTeamList(loginUserInfo.getUserId());

        // 画面で選択したデータを回しながら、更新対象を決定
        List<Map<String, String>> list = syuekiFlgEditBean.getAnkenList();
        for (String idx: syuekiFlgEditBean.getCheckData()) {
            int index = Integer.parseInt(idx);
            Map<String, String> data = list.get(index);

            // 案件を検索
            Map<String, Object> condition = new HashMap<>();
            condition.put("ankenId", StringUtils.defaultString((String)data.get("ankenId")));
            condition.put("rirekiId", Integer.parseInt(ConstantString.geRirekiId));
            SyuGeBukkenInfoTbl geEntity = syuGeBukenInfoTblFacade.findPk(condition);

//            String ankenId = StringUtils.defaultString((String)data.get("ankenId"));
//            String orderNo = StringUtils.defaultString((String)data.get("orderNo"));
//            String syuekiFlg = StringUtils.defaultString((String)data.get("syuekiFlg"));
//            String salesClass = StringUtils.defaultString((String)data.get("salesClass"));
//            String ankenFlg = StringUtils.defaultString((String)data.get("ankenFlg"));
//            String stageId = StringUtils.defaultString((String)data.get("stageId"));

            String ankenId = StringUtils.defaultString(geEntity.getAnkenId());
            String orderNo = StringUtils.defaultString(geEntity.getOrderNo());
            String syuekiFlg = StringUtils.defaultString(geEntity.getSyuekiFlg());
            String salesClass = StringUtils.defaultString(geEntity.getSalesClass());
            String ankenFlg = StringUtils.defaultString(geEntity.getAnkenFlg());
            String stageId = StringUtils.defaultString(String.valueOf(geEntity.getStageId()));

            // 編集権限チェック
            //if (!isAnkenEdit(geEntity, teamMstList)) {
            if (!isAnkenEdit(geEntity)) {
                noEditAnkenSet.add(ankenId);

            } else {
                if (!editSyuekiFlg.equals(syuekiFlg)) {  // これから設定しようとしている収益対象FLGになっていないデータを更新対象にする。
                    if (StringUtils.isNotEmpty(orderNo) && !ConstantString.cancelStageId.equals(stageId)) {  // 注番が発行済の案件(stageId=5は注番取消)
                        if (ConstantString.salesClassS.equals(salesClass) && "1".equals(ankenFlg)) {
                            ////// 進行基準まとめ案件
                            noOrderNoMatomeAnkenIdSet.add(ankenId);
                        } else {
                            ////// 子案件(一般案件＋進行基準の子案件)
                            ippanNoOrderNoSet.add(orderNo);
                        }
                    }

                    // データ分類毎に、更新対象データを格納分けする。
                    //setProcessData(data, editSyuekiFlg);
                    setProcessData(geEntity, editSyuekiFlg);
                } else {
                    // 2017/08/03 既に収益設定が解除されている案件は処理できない(必要がない)ため、処理不可データとしてエラー扱いにする。
                    alreadyNoSyuekiFlgSet.add(ankenId);
                }
            }
        }

        if (CollectionUtils.isNotEmpty(alreadyNoSyuekiFlgSet)) {
            String ankenIds = collectionToString(alreadyNoSyuekiFlgSet);
            String alreadyNoSyuekiFlgMessage = Label.alreadyNoSyuekiFlg.getMessage(ankenIds);
            resultMessasge = Utils.addStringBuff(resultMessasge, alreadyNoSyuekiFlgMessage, "\n");
        }
        if (CollectionUtils.isNotEmpty(noEditAnkenSet)) {
            String ankenIds = collectionToString(noEditAnkenSet);
            String errorMessage = Label.alertNoAuthSyuekiFlgRel.getMessage(ankenIds);
            //String errorMessage = "案件：" + ankenIds + "は編集権限がないため収益対象解除はできません(サーバー)。";
            resultMessasge = Utils.addStringBuff(resultMessasge, errorMessage, "\n");
        }
        // 子案件で注番が採番済みの場合
        if (CollectionUtils.isNotEmpty(ippanNoOrderNoSet)) {
            String errorMessage = Label.alertRequiredOneSyuekiFlg.getMessage(collectionToString(ippanNoOrderNoSet));
            //String errorMessage = "注番：" + collectionToString(ippanNoOrderNoSet) + " に対して収益管理対象は必ず1件指定してください(サーバー)。";
            resultMessasge = Utils.addStringBuff(resultMessasge, errorMessage, "\n");
        }
        // まとめ案件で注番が採番済みの場合
        if (CollectionUtils.isNotEmpty(noOrderNoMatomeAnkenIdSet)) {
            String errorMessage = Label.alertMatomeAnkenSyuekiFlgRel.getMessage(collectionToString(noOrderNoMatomeAnkenIdSet));
            //String errorMessage = "まとめ案件：" + collectionToString(noOrderNoMatomeAnkenIdSet) + " は注番採番済みのため，収益解除できません(サーバー)。";
            resultMessasge = Utils.addStringBuff(resultMessasge, errorMessage, "\n");
        }
        
        syuekiFlgEditBean.setResultMessage(resultMessasge);
        if (StringUtils.isNotEmpty(resultMessasge)) {
            syuekiFlgEditBean.setResultFlg("9");
            return false;
        }

        return true;
    }

    /**
     * 処理対象データの格納
     * @throws Exception 
     */
    //private void setProcessData(Map<String, String> data, String editSyuekiFlg) {
    private void setProcessData(SyuGeBukkenInfoTbl geEntity, String editSyuekiFlg) {
//        String ankenId = StringUtils.defaultString((String)data.get("ankenId"));;
//        String orderNo = StringUtils.defaultString((String)data.get("orderNo"));
//        String syuekiFlg = StringUtils.defaultString((String)data.get("syuekiFlg"));
//        String salesClass = StringUtils.defaultString((String)data.get("salesClass"));
//        String ankenFlg = StringUtils.defaultString((String)data.get("ankenFlg"));
        String ankenId = StringUtils.defaultString(geEntity.getAnkenId());
        String orderNo = StringUtils.defaultString(geEntity.getOrderNo());
        String syuekiFlg = StringUtils.defaultString(geEntity.getSyuekiFlg());
        String salesClass = StringUtils.defaultString(geEntity.getSalesClass());
        String ankenFlg = StringUtils.defaultString(geEntity.getAnkenFlg());
        String divisionCode = StringUtils.defaultString(geEntity.getDivisionCode());

        // データ分類毎に、更新対象データを格納分けする。
        // (更新時、この格納種類ごとに処理を切り分けする)
        if (!editSyuekiFlg.equals(syuekiFlg)) {  // これから設定しようとしている収益対象FLGになっていないデータを更新対象にする。
            Map<String, String> targetData = new HashMap<>();
            targetData.put("divisionCode", divisionCode);
            targetData.put("salesClass", salesClass);
            targetData.put("ankenFlg", ankenFlg);
            
            // 進行基準まとめ案件の更新対象データを格納
            if (ConstantString.salesClassS.equals(salesClass) && "1".equals(ankenFlg)) {
                targetData.put("ankenId", ankenId);
                targetData.put("orderNo", orderNo);
                syuekiFlgEditBean.setShinkoMatomeAnkenTargetData(targetData);

            // 通常案件の更新対象データを格納
            } else {
                targetData.put("newAnkenId", ankenId);
                if (StringUtils.isNotEmpty(orderNo)) {
                    targetData.put("orderNo", orderNo);

                    // 既存の収益設定済の案件を取得
                    String oldAnkend = getOldAnkenId(orderNo, ankenId, editSyuekiFlg);
                    if (StringUtils.isNotEmpty(oldAnkend)) {
                        targetData.put("oldAnkenId", oldAnkend);
                    }
                }

                syuekiFlgEditBean.setIppanAnkenChangeTargetData(targetData);
            }
        }
    }

    /**
     * 収益FLG設定処理メイン
     * @throws Exception 
     */
    public void editSyuekiFlgMainExecute() throws Exception {
        log.info("SyuekiFlgEditService#editSyuekiFlgMainExecute");

        syuekiFlgEditBeanMessageBean.clear();
        
        // 子案件(一般案件＋進行基準まとめの子案件)の対象注番の収益FLGの設定
        List<Map<String, String>> ippanAnkenTargetList = syuekiFlgEditBean.getIppanAnkenChangeTargetList();
        if (CollectionUtils.isNotEmpty(ippanAnkenTargetList)) {
            for (Map<String, String> data: ippanAnkenTargetList) {
                editIppanAnkenSyuekiFlg(data);
            }
        }

        // 進行基準まとめ案件の収益FLGの設定
        //List<String> shinkoMatomeAnkenTargetList = syuekiFlgEditBean.getShinkoMatomeAnkenTargetList();
        List<Map<String, String>> shinkoMatomeAnkenTargetList = syuekiFlgEditBean.getShinkoMatomeAnkenTargetList();
        if (CollectionUtils.isNotEmpty(shinkoMatomeAnkenTargetList)) {
            for (Map<String, String> ankendata: shinkoMatomeAnkenTargetList) {
                editMatomeAnkenSyuekiFlg(ankendata, "1");
            }
        }

        // 操作ログの登録
        registOperationLogMain();
    }

    /**
     * 収益FLG解除処理メイン
     * @throws Exception 
     */
    public void relSyuekiFlgMainExecute() throws Exception {
        log.info("SyuekiFlgEditService#relSyuekiFlgMainExecute");

        syuekiFlgEditBeanMessageBean.clear();
        
        // 一般案件の対象注番・案件の収益FLG設定解除
        List<Map<String, String>> ippanAnkenTargetList = syuekiFlgEditBean.getIppanAnkenChangeTargetList();
        if (CollectionUtils.isNotEmpty(ippanAnkenTargetList)) {
            for (Map<String, String> data: ippanAnkenTargetList) {
                relIppanAnkenSyuekiFlg(data);
            }
        }

        // 進行基準まとめ案件の対象の設定
        //List<String> shinkoMatomeAnkenTargetList = syuekiFlgEditBean.getShinkoMatomeAnkenTargetList();
        List<Map<String, String>> shinkoMatomeAnkenTargetList = syuekiFlgEditBean.getShinkoMatomeAnkenTargetList();
        if (CollectionUtils.isNotEmpty(shinkoMatomeAnkenTargetList)) {
            for (Map<String, String> ankendata: shinkoMatomeAnkenTargetList) {
                editMatomeAnkenSyuekiFlg(ankendata, "0");
            }
        }
        
        // 操作ログの登録
        registOperationLogMain();

    }

    /**
     * 収益対象FLGの設定(通常の案件)
     */
    private void editIppanAnkenSyuekiFlg(Map<String, String> data) throws Exception {
        int resultFlg = 0;
        int finishTransaction = 0;
        //String errorMessage = "";
        
        String successMessage = "";
        String nuclerRenkenMessage = "";
        String message = "";

        String orderNo = "";
        String newAnkenId = "";
        String oldAnkenId = "";

        try {
            userTransaction.begin();
            log.info("Begin Transaction");

            orderNo = StringUtils.defaultString((String)data.get("orderNo"));
            newAnkenId = StringUtils.defaultString((String)data.get("newAnkenId"));
            oldAnkenId = "";
            if (data.containsKey("oldAnkenId")) {
                oldAnkenId = StringUtils.defaultString((String)data.get("oldAnkenId"));
            }
            String divisionCode = StringUtils.defaultString((String)data.get("divisionCode"));

            log.info("通常案件 収益対象FLG設定 注番=[{}] FLG解除案件=[{}] FLG設定案件=[{}]", orderNo, oldAnkenId, newAnkenId);

            // 収益対象の解除(現状の注番設定済の案件が取得できた場合のみ)
            if (StringUtils.isNotEmpty(oldAnkenId)) {
                oldAnkenId = StringUtils.defaultString((String)data.get("oldAnkenId"));
                String[] oldAnkenIds = {oldAnkenId};
                List<String> oldAnkenIdList = Arrays.asList(oldAnkenIds);
                exeEditSyuekiFlg(oldAnkenIdList, "0");
            }

            // 収益対象の設定(新案件)
            newAnkenId = StringUtils.defaultString((String)data.get("newAnkenId"));
            String[] newAnkenIds = {newAnkenId};
            List<String> newAnkenIdList = Arrays.asList(newAnkenIds);
            exeEditSyuekiFlg(newAnkenIdList, "1");

            // 付け替えパッケージ実行
            boolean isSuccess = callDaihyoAnkenSet(newAnkenId, oldAnkenId, orderNo);

            if (!isSuccess) {
                resultFlg = 9;
                message = Label.errorSetSyuekiFlgIppan.getMessage(newAnkenId, orderNo);
            } else {
                commit();
                finishTransaction = 1;

                ////// (原子力)連携パッケージ実行(収益対象FLG入れ替えにより、原子力データも同期する)
                nuclerRenkenMessage = callNuclearSysRenkeiBatch(newAnkenId, oldAnkenId, orderNo, divisionCode); 
/*
                if (StringUtils.isNotEmpty(oldAnkenId)) {
                    // (原子力)連携パッケージ実行(収益FLG解除対象の案件)
                    nuclerRenkenMessage = callNuclearSysRenkeiBatch(newAnkenId, orderNo, oldAnkenId);
                }
                if (StringUtils.isEmpty(nuclerRenkenMessage)) {
                    // (原子力)連携パッケージ実行(収益FLG設定対象の案件)
                    nuclerRenkenMessage = callNuclearSysRenkeiBatch(newAnkenId, orderNo, newAnkenId);
                }
*/
                if (StringUtils.isNotEmpty(nuclerRenkenMessage)) {
                    resultFlg = 8;
                }
            }

            // 処理成功時のメッセージを定義
            successMessage = Label.successSetSyuekiFlgIppan.getMessage(newAnkenId, orderNo);
            if (StringUtils.isNotEmpty(oldAnkenId)) {
                successMessage = successMessage + Label.successSetSyuekiFlgIppanClear.getMessage(oldAnkenId);
            }

        } catch (Throwable e) {
            resultFlg = 9;
            message = Label.errorSetSyuekiFlgIppan.getMessage(newAnkenId, orderNo);
            log.error(message, e);
            
        } finally {
            if (resultFlg == 0) {
                if (finishTransaction == 0) {
                    commit();
                }
                message = successMessage;

            } else if (resultFlg == 8) {
                if (finishTransaction == 0) {
                    commit();
                }
                message = successMessage + " " + nuclerRenkenMessage;
                resultFlg = 9;
                
            } else {
                if (finishTransaction == 0) {
                    rollback();
                }
            }

            SyuekiFlgMessageDto messageDto = new SyuekiFlgMessageDto();
            messageDto.setResultFlg(resultFlg);
            messageDto.setMessage(message);
            syuekiFlgEditBeanMessageBean.setMessageData(messageDto);
        }

    }

    /**
     * 収益対象FLGの解除(通常の案件)
     */
    private void relIppanAnkenSyuekiFlg(Map<String, String> data) {
        int resultFlg = 0;
        String message = "";
        String successMessage = "";
        String nuclerRenkenMessage = "";

        String newAnkenId = StringUtils.defaultString((String)data.get("newAnkenId"));
        String orderNo = StringUtils.defaultString((String)data.get("orderNo"));
        String divisionCode = StringUtils.defaultString((String)data.get("divisionCode"));

        log.info("通常案件 収益対象FLG解除 案件=[{}]", newAnkenId);
        
        String[] newAnkenIds = {newAnkenId};
        List<String> newAnkenIdList = Arrays.asList(newAnkenIds);

        try {
            userTransaction.begin();
            log.info("Begin Transaction");
        
            exeEditSyuekiFlg(newAnkenIdList, "0");
            commit();

            
            //BSAより解除時も付替えパッケージを呼ぶように依頼を受け修正（2017/06/08)
            // 付け替えパッケージ実行
            boolean isSuccess = callDaihyoAnkenSet("", newAnkenId, orderNo);

            if (!isSuccess) {
                resultFlg = 9;
                message = Label.errorClearSyuekiFlgIppan.getMessage(newAnkenId, orderNo);
            } else {
                // (原子力)連携パッケージ実行(収益FLG設定対象の案件)
                //nuclerRenkenMessage = callNuclearSysRenkeiBatch(newAnkenId, orderNo, newAnkenId);
                nuclerRenkenMessage = callNuclearSysRenkeiBatch("", newAnkenId, orderNo, divisionCode);
                if (StringUtils.isNotEmpty(nuclerRenkenMessage)) {
                    resultFlg = 8;
                }
            }

            successMessage = Label.successClearSyuekiFlgIppan.getMessage(newAnkenId);
            
        } catch (Throwable e) {
            resultFlg = 9;
            message = Label.errorClearSyuekiFlgIppan.getMessage(newAnkenId);
            log.error(message, e);

        } finally {
            if (resultFlg == 0) {
                commit();
                message = successMessage;
            } else if (resultFlg == 8) {
                commit();
                message = successMessage + " " + nuclerRenkenMessage;
                resultFlg = 9;
            } else {
                rollback();
            }

            SyuekiFlgMessageDto messageDto = new SyuekiFlgMessageDto();
            messageDto.setResultFlg(resultFlg);
            messageDto.setMessage(message);
            syuekiFlgEditBeanMessageBean.setMessageData(messageDto);
        }
    }

    /**
     * 収益対象FLGの設定(進行基準まとめ案件＋(その子案件))
     */
    //private void editMatomeAnkenSyuekiFlg(String ankenId, String syuekiFlg) throws Exception {
    private void editMatomeAnkenSyuekiFlg(Map<String, String> ankenData, String syuekiFlg) throws Exception {
        String matomeAnkenId = (String)ankenData.get("ankenId");
        String orderNo = (String)ankenData.get("orderNo");
        String divisionCode = (String)ankenData.get("divisionCode");
        int resultFlg = 0;
        
        String successMessage = "";
        String message = "";
        String nuclerRenkenMessage = "";

        String newAnkenId = ("1".equals(syuekiFlg) ? matomeAnkenId : "");
        String oldAnkenId = ("1".equals(syuekiFlg) ? "" : matomeAnkenId);
        
        // 対象まとめ案件に属する(注番未採番＋注番取消の)子案件を取得(実際はもっと絞り込みが必要)
        Map<String, Object> condition = new HashMap<>();
        condition.put("ankenId", matomeAnkenId);
        condition.put("noOrderNoFlg", "1");
        condition.put("rirekiId", Integer.parseInt(ConstantString.geRirekiId));
        
        List<String> childAnkenNoList = syuGeBukenInfoTblFacade.findChildAnkenNo(condition);
        
        log.info("進行基準まとめ案件 収益対象FLG設定 収益対象FLG=[{}] 親案件=[{}] 子案件={}", syuekiFlg, matomeAnkenId, childAnkenNoList);
        
        List<String> targetSyuekiFlgAnkenList = new ArrayList<>();
        targetSyuekiFlgAnkenList.add(matomeAnkenId);
        if (CollectionUtils.isNotEmpty(childAnkenNoList)) {
            targetSyuekiFlgAnkenList.addAll(childAnkenNoList);
        }

        try {
            userTransaction.begin();
            log.info("Begin Transaction");
            
            // 収益対象の設定
            exeEditSyuekiFlg(targetSyuekiFlgAnkenList, syuekiFlg);

            // (2017/08/03)進行基準まとめ案件に対して、付け替え+営業案件システムへの収益Flg同期パッケージ実行(営業案件への収益FLG同期は必要なため、パッケージを呼ぶように処理を追加)
            boolean isSuccess = callDaihyoAnkenSet(newAnkenId, oldAnkenId, orderNo);

            // 処理結果メッセージの作成
            if (!isSuccess) {
                // 付け替え処理失敗
                resultFlg = 9;
                if ("1".equals(syuekiFlg)) {
                    message = Label.errorSetSyuekiFlgMatome.getMessage(matomeAnkenId);
                } else {
                    message = Label.errorClearSyuekiFlgMatome.getMessage(matomeAnkenId);
                }

            } else {
                // 付け替え処理成功
                if ("1".equals(syuekiFlg)) {
                    successMessage = Label.successSetSyuekiFlgMatome.getMessage(matomeAnkenId);
                } else {
                    successMessage = Label.successClearSyuekiFlgMatome.getMessage(matomeAnkenId);
                }
                
                //　(2017/08/31) (原子力)連携パッケージ実行(まとめ案件)
                commit();
                nuclerRenkenMessage = callNuclearSysRenkeiBatchM(newAnkenId, oldAnkenId, orderNo, divisionCode);
                if (StringUtils.isNotEmpty(nuclerRenkenMessage)) {
                    resultFlg = 8;
                }
                
            }

        } catch (Throwable e) {
            resultFlg = 9;
            if ("1".equals(syuekiFlg)) {
                message = Label.errorSetSyuekiFlgMatome.getMessage(matomeAnkenId);
            } else {
                message = Label.errorClearSyuekiFlgMatome.getMessage(matomeAnkenId);
            }
            log.error(message, e);

        } finally {
            if (resultFlg == 0) {
                message = successMessage;
                commit();
            } else if (resultFlg == 8) {
                commit();
                message = successMessage + " " + nuclerRenkenMessage;
                resultFlg = 9;
                
            } else {
                rollback();
            }
            
            SyuekiFlgMessageDto messageDto = new SyuekiFlgMessageDto();
            messageDto.setResultFlg(resultFlg);
            messageDto.setMessage(message);
            syuekiFlgEditBeanMessageBean.setMessageData(messageDto);
        }

    }

    /**
     * 同一注番での収益対象FLG設定済の案件を取得
     */
    private String getOldAnkenId(String orderNo, String targetAnkenId, String editSyuekiFlg) {
        Map<String, Object> condition = new HashMap<>();
        condition.put("orderNo", orderNo);
        condition.put("syuekiFlg", editSyuekiFlg);
        condition.put("rirekiId", Integer.parseInt(ConstantString.geRirekiId));
        condition.put("noTargetAnkenId", targetAnkenId);  // 自案件は除外する
        condition.put("ankenFlg", "0");                   // 子案件のみ対象(まとめ案件は除外する)
        
        //String oldAnkenId = syuGeBukenInfoTblFacade.getNowSyuekiFlgAnkenId(orderNo, targetAnkenId, ConstantString.geRirekiId, "0");
        String oldAnkenId = syuGeBukenInfoTblFacade.getNowSyuekiFlgAnkenId(condition);
        return oldAnkenId;
    }

    /**
     * 収益対象FLGの設定
     */
    private int exeEditSyuekiFlg(List<String> ankenIds, String syuekiFlg) {
        Map<String, Object> condition = new HashMap<>();
        condition.put("ankenId", ankenIds);
        condition.put("rirekiId", Integer.parseInt(ConstantString.geRirekiId));
        condition.put("syuekiFlg", syuekiFlg);
        EntityUtils.setUpdatedInfo(condition, loginUserInfo.getUserId());
        
        if ("1".equals(syuekiFlg)) {
            // 収益対象設定した案件IDを操作ログ登録用に確保
            syuekiFlgEditBean.setEditSyuekiFlgAnkenId(ankenIds);
        } else {
            // 収益対象解除した案件IDを操作ログ登録用に確保
            syuekiFlgEditBean.setRelSyuekiFlgAnkenId(ankenIds);
        }
        
        return syuGeBukenInfoTblFacade.updateSyuekiFlg(condition);
    }

    /**
     * 操作ログの登録メイン
     * @throws Exception
     */
    private void registOperationLogMain() throws Exception{
        try {
            userTransaction.begin();
            log.info("Begin Transaction");
            
            // 操作ログの登録(登録)
            if (CollectionUtils.isNotEmpty(syuekiFlgEditBean.getEditSyuekiFlgAnkenId())) {
                registOperationLog("SET_SYUEKI_FLG", syuekiFlgEditBean.getEditSyuekiFlgAnkenId());
            }
            // 操作ログの登録(解除)
            if (CollectionUtils.isNotEmpty(syuekiFlgEditBean.getRelSyuekiFlgAnkenId())) {
                registOperationLog("CLR_SYUEKI_FLG", syuekiFlgEditBean.getRelSyuekiFlgAnkenId());
            }
        } catch (Exception e) {
            log.error("収益対象設定 操作ログの登録に失敗しました。", e);
        } finally {
            commit();
        }
    }

    /**
     * 操作ログの登録実行
     * @throws Exception
     */
    private void registOperationLog(String operationCode, List<String> ankenIdList) throws Exception{
        String remarks = "";
        if (CollectionUtils.isNotEmpty(ankenIdList)) {
            remarks = collectionToString(ankenIdList);
        }
        
        OperationLog operationLog = operationLogService.getOperationLog();
        operationLog.setOperationCode(operationCode);
        operationLog.setObjectId(20);
        operationLog.setObjectType("ANKEN");
        operationLog.setRemarks(remarks);

        operationLogService.insertOperationLogSearch(operationLog);
    }

    /**
     * 収益対象FLG付け替えパッケージの実行
     * @param daihyoAnkenId 注番の代表案件
     * @param invaildAnkenId 収益フラグを解除する案件
     * @param ankenOrderNo 対象の注番
     */
    private boolean callDaihyoAnkenSet(String daihyoAnkenId, String invaildAnkenId, String ankenOrderNo) {
        boolean isSuccess = true;
        P0DaihyoAnkenSetDto dto = new P0DaihyoAnkenSetDto();
        dto.setDaihyoAnkenId(daihyoAnkenId);
        dto.setInvaildAnkenId(invaildAnkenId);
        dto.setAnkenOrderNo(ankenOrderNo);
        
        try {
            storedProceduresService.callP0DaihyoAnkenSet(dto);
        } catch (Exception e) {
            isSuccess = false;
            log.error("収益対象FLG付替データ入替処理[" + dto.getExeProcedureName() + "]致命的エラー発生 daihyoAnkenId=[" + dto.getDaihyoAnkenId() + "] invaildAnkenId=[" + dto.getInvaildAnkenId() + "] ankenOrderNo=[" + dto.getAnkenOrderNo() + "]", e);
        }

        if (isSuccess) {
            if (!"0".equals(dto.getErrFlg())) {
                isSuccess = false;
                log.error("収益対象FLG付替データ入替処理[{}]失敗 daihyoAnkenId=[{}] invaildAnkenId=[{}] ankenOrderNo=[{}] errFlg=[{}] errMsg=[{}]", dto.getExeProcedureName(), dto.getDaihyoAnkenId(), dto.getInvaildAnkenId(), dto.getAnkenOrderNo(), dto.getErrFlg(), dto.getErrMsg());
            }
        }
        
        return isSuccess;
    }

    /**
     * (原子力)収益管理システムへのデータ送信パッケージを実行
     * @param ankenId 対象の案件id
     */
    //private String callNuclearSysRenkeiBatch(String targetankenId, String orderNo, String renkeiAnkenId) throws Exception {
    private String callNuclearSysRenkeiBatch(String daihyoAnkenId, String invaildAnkenId, String orderNo, String divisionCode) throws Exception {
        String errorMessage = "";
        
        userTransaction.begin();
        log.info("Begin Transaction");

        //boolean isSuccess = exeCallNuclearSysRenkeiBatch(renkeiAnkenId);
        String errorAnkenId = exeCallNuclearSysRenkeiBatch(daihyoAnkenId, invaildAnkenId, orderNo);
        if (StringUtils.isNotEmpty(errorAnkenId)) {
            rollback();
            
            boolean isNuclearDivision = divisionComponentPage.isNuclearDivision(divisionCode);

            if (isNuclearDivision) {
                // 原子力用エラーメッセージ
                errorMessage = Label.errorSetSyuekiFlgIppanNuclearRenkei.getMessage(errorAnkenId);
            } else {
                // 火水ジ用エラーメッセージ
                errorMessage = Label.errorSetSyuekiFlgRecalIppan.getMessage(errorAnkenId);
            }

        } else {
            commit();
        }
        
        return errorMessage;
    }
    
    /**
     * (原子力)収益管理システムへのデータ送信パッケージを実行
     * 2017/08/10 収益FLGの付け替え制御をパッケージ内でコントロールできるようにするために、呼び出しプロシジャを変更
     * @param ankenId 対象の案件id
     */
    //private boolean exeCallNuclearSysRenkeiBatch(String ankenId) {
    private String exeCallNuclearSysRenkeiBatch(String daihyoAnkenId, String invaildAnkenId, String orderNo) {
        boolean isSuccess = true;
        NuclearRenkeiSyuekiFlgBatchDto dto = new NuclearRenkeiSyuekiFlgBatchDto();
        dto.setDaihyoAnkenId(daihyoAnkenId);
        dto.setInvaildAnkenId(invaildAnkenId);
        dto.setAnkenOrderNo(orderNo);
        
        String errorAnkenId = "";

        try {
            storedProceduresService.callNuclearRenkeiSyuekiFlg(dto);
        } catch (Exception e) {
            errorAnkenId = StringUtils.defaultString(daihyoAnkenId);
            if (StringUtils.isNotEmpty(invaildAnkenId)) {
                errorAnkenId = errorAnkenId.equals("") ? invaildAnkenId : (errorAnkenId + "," + invaildAnkenId);
            }
            log.error("(原子力)収益管理システム 収益FLG付替処理[" + dto.getExeProcedureName() + "]致命的エラー発生 daihyoAnkenId=[" + daihyoAnkenId + "] ankenOrderNo=[" + orderNo + "] orderNo=[" + orderNo+ "]", e);
        }
        
        if (StringUtils.isEmpty(errorAnkenId)) {
            if ((dto.getStatus() != null && dto.getStatus() == 9) || StringUtils.isNotEmpty(dto.getErrorAnkenId())) {
                errorAnkenId = dto.getErrorAnkenId();
                log.error("(原子力)収益管理システム データ送信パッケージ[{}]失敗 daihyoAnkenId=[{}] invaildAnkenId=[{}] ankenOrderNo=[{}] status=[{}] errMsg=[{}] errorAnkenId=[{}]", dto.getExeProcedureName(), dto.getDaihyoAnkenId(), dto.getInvaildAnkenId(), dto.getAnkenOrderNo(),  dto.getStatus(), dto.getErrMsg(), errorAnkenId);
            }
        }

        return errorAnkenId;
    }
    
    
    
   /**
     * (原子力)収益管理システムへのデータ送信パッケージを実行（まとめ案件用）
     * 2017/08/31
     * @param ankenId 対象の案件id
     */
    private String callNuclearSysRenkeiBatchM(String daihyoAnkenId, String invaildAnkenId, String orderNo, String divisionCode) throws Exception {
        String errorMessage = "";
        
        userTransaction.begin();
        log.info("Begin Transaction");
        
        String errorAnkenId = exeCallNuclearSysRenkeiBatchM(daihyoAnkenId, invaildAnkenId, orderNo);
        if (StringUtils.isNotEmpty(errorAnkenId)) {
            rollback();

            // 事業部コード:(原子力)であるかを判断
            boolean isNuclearDivision = divisionComponentPage.isNuclearDivision(divisionCode);
            
            if (isNuclearDivision) {
                // 原子力用エラーメッセージ
                errorMessage = Label.errorSetSyuekiFlgMatomeNuclearRenkei.getMessage(errorAnkenId);
            } else {
                // 火水ジ用エラーメッセージ
                errorMessage = Label.errorSetSyuekiFlgRecalMatome.getMessage(errorAnkenId);
            }
        } else {
            commit();
        }
        
        return errorMessage;
    }
    
    /**
     * (原子力)収益管理システムへのデータ送信パッケージを実行（進行基準まとめ案件）
     * 2017/08/31 
     * @param ankenId 対象の案件id
     */
    private String exeCallNuclearSysRenkeiBatchM(String daihyoAnkenId, String invaildAnkenId, String orderNo) {
        boolean isSuccess = true;
        NuclearRenkeiSyuekiFlgBatchDto dto = new NuclearRenkeiSyuekiFlgBatchDto();
        dto.setDaihyoAnkenId(daihyoAnkenId);
        dto.setInvaildAnkenId(invaildAnkenId);
        dto.setAnkenOrderNo(orderNo);
        
        String errorAnkenId = "";

        try {
            storedProceduresService.callNuclearRenkeiSyuekiFlgM(dto);
        } catch (Exception e) {
            errorAnkenId = StringUtils.defaultString(daihyoAnkenId);
            if (StringUtils.isNotEmpty(invaildAnkenId)) {
                errorAnkenId = errorAnkenId.equals("") ? invaildAnkenId : (errorAnkenId + "," + invaildAnkenId);
            }
            log.error("(原子力)収益管理システム 収益FLG付替処理（進行基準まとめ案件）[" + dto.getExeProcedureName() + "]致命的エラー発生 daihyoAnkenId=[" + daihyoAnkenId + "] ankenOrderNo=[" + orderNo + "] orderNo=[" + orderNo+ "]", e);
        }
        
        if (StringUtils.isEmpty(errorAnkenId)) {
            if ((dto.getStatus() != null && dto.getStatus() == 9) || StringUtils.isNotEmpty(dto.getErrorAnkenId())) {
                errorAnkenId = dto.getErrorAnkenId();
                log.error("(原子力)収益管理システム データ送信パッケージ[{}]失敗 daihyoAnkenId=[{}] invaildAnkenId=[{}] ankenOrderNo=[{}] status=[{}] errMsg=[{}] errorAnkenId=[{}]", dto.getExeProcedureName(), dto.getDaihyoAnkenId(), dto.getInvaildAnkenId(), dto.getAnkenOrderNo(),  dto.getStatus(), dto.getErrMsg(), errorAnkenId);
            }
        }

        return errorAnkenId;
    }
    

    /**
     * コレクション→文字列化
     */
    private String collectionToString(Collection<String> _target) {
        String result = _target.toString();
        result = StringUtils.replace(result, " ", "");
        result = StringUtils.replace(result, "[", "");
        result = StringUtils.replace(result, "]", "");
        return result;
    }

    /**
     * commit
     */
    private void commit() {
        try {
            userTransaction.commit();
            log.info("Commit Transaction");
        } catch (Exception e) {
            log.info("Commit " + e.getMessage());
        }
    }
    
    /**
     * rollback
     */
    private void rollback() {
        try {
            userTransaction.rollback();
            log.info("Rollback Transaction");
        } catch (Exception e) {
            log.info("Rollback " + e.getMessage());
        }
    }
    
}
