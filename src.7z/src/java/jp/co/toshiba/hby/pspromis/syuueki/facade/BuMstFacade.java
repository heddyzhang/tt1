package jp.co.toshiba.hby.pspromis.syuueki.facade;

import java.util.List;
import java.util.ArrayList;
import javax.ejb.Stateless;
import javax.interceptor.Interceptors;
import javax.inject.Inject;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import jp.co.toshiba.hby.pspromis.syuueki.entity.BuMst;
import jp.co.toshiba.hby.pspromis.syuueki.interceptor.TranceInterceptor;
import jp.co.toshiba.hby.pspromis.syuueki.util.LoginUserInfo;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 *
 * @author horie
 */
@Stateless
@Interceptors({TranceInterceptor.class})
public class BuMstFacade extends AbstractFacade<BuMst> {
    /**
     * ロガ－
     */
    private static final Logger logger = LoggerFactory.getLogger(BuMstFacade.class);

    @PersistenceContext(unitName = jp.co.toshiba.hby.pspromis.syuueki.util.ConstantString.syuuekiDataSourceName)
    private EntityManager em;

    @Override
    protected EntityManager getEntityManager() {
        return em;
    }

    @Inject
    private LoginUserInfo loginUserInfo;
    
    public BuMstFacade() {
        super(BuMst.class);
    }

    /**
     * BUマスタを取得
     * @return 
     */
    @Override
    public List<BuMst> findAll() {
       logger.info("BuMstFacade#findAll");

       List<BuMst> list
                = sqlExecutor.getResultList(em, BuMst.class, "/sql/selectBuMst.sql", null);
       
       return list;
    }
    
    /**
     * BUマスタから条件を指定してデータ一覧を取得
     * @param condition
     * @return 
     */
    public List<BuMst> findConditionList(Object condition) {
       logger.info("BuMstFacade#findConditionList");
       
       List<BuMst> list
                = sqlExecutor.getResultList(em, BuMst.class, "/sql/selectBuMst.sql", condition);
       
       return list;
    }
    
    /**
     * BUマスタから条件を指定してデータ一覧を取得(BU情報のみをグルーピング/サブBUは除外する)
     * @param condition
     * @return 
     */
    public List<BuMst> findConditionBuList(Object condition) {
       List<BuMst> list = changeBuOnlyList(findConditionList(condition));
       return list;
    }

    /**
     * BUマスタから1件取得
     * @param condition
     */
    public BuMst findBuMst(Object condition) {
        logger.info("S008Facade#findBuMst");

        return sqlExecutor.getSingleResult(em, BuMst.class, "/sql/selectBuMst.sql", condition);
    }
    
    /**
     * BUマスタ一覧をBUのみにグルーピング化した結果に変換(各BUに入るサブBU情報はBUの一番目の情報になる)
     */
    private List<BuMst> changeBuOnlyList(List<BuMst> list) {
        if (CollectionUtils.isEmpty(list)) {
            return null;
        }
        
        String beforeBuCode = "";
        List<BuMst> buList = new ArrayList<>();
        for (BuMst entity: list) {
            if (entity == null) {
                continue;
            }
            
            String buCode = StringUtils.defaultString(entity.getBuCode());
            if (!buCode.equals(beforeBuCode)) {
               buList.add(entity);
            }
            
            beforeBuCode = buCode;
        }
        
        return buList;
    }
        
}
