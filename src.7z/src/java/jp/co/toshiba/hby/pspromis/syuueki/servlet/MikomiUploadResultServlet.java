package jp.co.toshiba.hby.pspromis.syuueki.servlet;

import javax.inject.Inject;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpServletRequest;
import jp.co.toshiba.hby.pspromis.syuueki.bean.MikomiUploadErrorBean;

/**
 * PS-Promis収益管理システム
 * 注入見込Upload 結果表示Servlet
 * @author sano
 */
@WebServlet(name="MikomiUploadResult", urlPatterns={"/servlet/MikomiUploadResult"})
public class MikomiUploadResultServlet extends AbstractServlet {

    /**
     * jsp
     */
    private static final String SUCCESS_JSP = "mikomiUpload/uploadInfo.jsp";

    /**
     * jsp
     */
    private static final String ERROR_JSP = "mikomiUpload/uploadError.jsp";

    /**
     * パラメータ格納クラスをinjection(CDI)<br>
     * InjectアノテーションよりAPサーバー(Glassfish)側で自動的にインスタンス作成(new)される。<br>
     */
    @Inject
    private MikomiUploadErrorBean mikomiUploadErrorBean;
    
    /**
     * 初期表示
     * @param req
     * @param resp
     * @return
     * @throws Exception 
     */
    public String indexAction(HttpServletRequest req, HttpServletResponse resp)
    throws Exception {
        logger.info("MikomiUploadResultServlet#indexAction");
        String jsp = ERROR_JSP;

        if (mikomiUploadErrorBean != null) {
            if (mikomiUploadErrorBean.isIsSuccess()) {
                jsp = SUCCESS_JSP;
            }
        }

        return jsp;
    }
}
