package jp.co.toshiba.hby.pspromis.syuueki.service.download;

import java.math.BigDecimal;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.ejb.Stateless;
import javax.inject.Inject;
import javax.interceptor.Interceptors;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import jp.co.toshiba.hby.pspromis.syuueki.bean.S001Bean;
import jp.co.toshiba.hby.pspromis.syuueki.interceptor.TranceInterceptor;
import jp.co.toshiba.hby.pspromis.common.jdbc.SqlExecutor;
import jp.co.toshiba.hby.pspromis.syuueki.bean.S014Bean;
import jp.co.toshiba.hby.pspromis.syuueki.entity.OperationLog;
import jp.co.toshiba.hby.pspromis.syuueki.entity.SyuWfControlTbl;
import jp.co.toshiba.hby.pspromis.syuueki.enums.Label;
import jp.co.toshiba.hby.pspromis.syuueki.facade.SysdateEntityFacade;
import jp.co.toshiba.hby.pspromis.syuueki.facade.SyuWfControlTblFacade;
import jp.co.toshiba.hby.pspromis.syuueki.facade.KanjyoMstFacade;
import jp.co.toshiba.hby.pspromis.syuueki.jdbc.DbUtilsExecutor;
import jp.co.toshiba.hby.pspromis.syuueki.jdbc.SqlFile;
import jp.co.toshiba.hby.pspromis.syuueki.service.OperationLogService;
import jp.co.toshiba.hby.pspromis.syuueki.service.S001Service;
import jp.co.toshiba.hby.pspromis.syuueki.util.ConstantString;
import jp.co.toshiba.hby.pspromis.syuueki.util.LoginUserInfo;
import jp.co.toshiba.hby.pspromis.syuueki.util.PoiUtil;
import jp.co.toshiba.hby.pspromis.syuueki.util.SyuuekiUtils;
import jp.co.toshiba.hby.pspromis.syuueki.util.Utils;
import jp.co.toshiba.hby.pspromis.syuueki.pages.DivisonComponentPage;
import jp.co.toshiba.hby.pspromis.syuueki.util.NumberUtils;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.util.CellRangeAddress;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
/**
 * PS-Promis収益管理システム
 * 案件検索 Service(案件一覧Excel)
 * @author (NPC)horie
 */
@Stateless
@Interceptors({TranceInterceptor.class})
public class AnkenGaikaListService implements DownloadIfc {
//public class AnkenGaikaListService {

    public static final Logger logger = LoggerFactory.getLogger(AnkenGaikaListService.class);

    @PersistenceContext(unitName = jp.co.toshiba.hby.pspromis.syuueki.util.ConstantString.syuuekiDataSourceName)
    private EntityManager em;

    @Inject
    private S001Service s001Service;

    @Inject
    private SyuWfControlTblFacade syuWfControlTblFacade;

    @Inject
    private DbUtilsExecutor dbUtilsExecutor;

    /**
     * パラメータ格納クラスをinjection(CDI)<br>
     * InjectアノテーションよりAPサーバー(Glassfish)側で自動的にインスタンス作成(new)される。<br>
     */
    @Inject
    private S001Bean s001Bean;

    @Inject
    private S014Bean s014Bean;

    /**
     * Injection loginUserInfo
     * (ユーザー情報(ユーザーid,名称,所属部課名)を格納したオブジェクト)
     */
    @Inject
    private LoginUserInfo loginUserInfo;

    /**
     * Injection sqlExecutor
     */
    @Inject
    protected SqlExecutor sqlExecutor;

    /**
     * Injection SyuuekiUtils
     */
    @Inject
    private SyuuekiUtils syuuekiUtils;

    @Inject
    private SysdateEntityFacade sysdateFacade;

    @Inject
    private OperationLogService operationLogService;

    @Inject
    private KanjyoMstFacade kanjyoMstFacade;

    @Inject
    private DivisonComponentPage divisionComponentPage;

    //private static final String miriSecFormat = "yyyy-MM-dd HH:mm:ss.S";

    private static final String SHEETNAME = "list";
    private static final String STYLESHEETNAME = "style";
    private static final int FIRST_ROW_INDEX = 5;
    private static final int LAST_SUM_STYLE_ROW_INDEX = 4;
    private static final int DATA_STYLE_ROW_INDEX = 8;
    private static final int DATA_STYLE_ROW_FIRST_INDEX = 10;
    private static final int HALF_YEAR_SP_NET = 60;
    private static final int FIRST_MONTH_SP_BEFORE = 15;
    private static final int MID_SUM_STYLE_ROW_INDEX = 2;
    private static final int ISP_SUBTOTAL_STYLE_ROW_INDEX = 0;

    /**
     * 月次確定画面からの出力か？
     */
    private int monthyKakuteiFlg() {
        if ("S014".equals(s014Bean.getDispId())) {
            return 1;
        } else {
            return 0;
        }
    }

    /**
     * 合計行は計算式出力か？
     */
    private boolean isSummaryCalc() {
        return ("1".equals(s001Bean.getOptionSummaryKbn()));
    }

    /**
     * 基準年月(勘定年月)を取得
     */
    private Date getKanjyoYm() throws ParseException {
        String kanjyoYM;
        if (this.monthyKakuteiFlg() == 1) {
            // 月次確定画面 から出力
            kanjyoYM = s014Bean.getDispBaseKanjyoYm();

        } else {
            // 受注売上見込一覧画面 から出力
            if ("M".equals(s001Bean.getDataKbn())){
                // 検索条件:データ種別=月次確定
                kanjyoYM = s001Bean.getTaishoYm();
            } else if("Y".equals(s001Bean.getDataKbn())){
                // 検索条件:データ種別=予算ベース
                kanjyoYM = SyuuekiUtils.getChangeBaseYm(s001Bean.getTaishoYm());
            } else {
                // 検索条件:データ種別=原案
                kanjyoYM = kanjyoMstFacade.getNowKanjoDate(ConstantString.salesClassI);
            }
        }

        return Utils.parseDate(kanjyoYM);
    }

    /**
     * 列の表示・非表示制御
     */
    private void controlDispColumn(Sheet sheet) {
        String[] dispItemKbn = s001Bean.getDispItemKbn();

        // 何もしない
    }

    /**
     * 指定した案件一覧Excelテンプレートにデータを書き込む
     */
    @Override
    public void downloadExecute(Workbook workbook) throws Exception {
        logger.info("[AnkenGaikaListService#downloadExecute]");

        int i = 0;
        int monthryKakuteiFlg = this.monthyKakuteiFlg();

        // 計算式を適用か？
        boolean summayCalc = this.isSummaryCalc();

        int rowNum = FIRST_ROW_INDEX;

        Sheet sheet = workbook.getSheet(SHEETNAME);
        Sheet sheetStyle = workbook.getSheet(STYLESHEETNAME);

        // 物件行のスタイルを取得(中間行)
        Row row1 = PoiUtil.getRow(sheetStyle, DATA_STYLE_ROW_INDEX, true);
        List<Cell> cellList1 = PoiUtil.getCellList(row1);
        // 物件行のスタイルを取得(1行目)
        Row rowFirst = PoiUtil.getRow(sheetStyle, DATA_STYLE_ROW_FIRST_INDEX, true);
        List<Cell> cellListFirst = PoiUtil.getCellList(rowFirst);

        // 最終合計行のスタイルを取得
        Row row2 = PoiUtil.getRow(sheetStyle, LAST_SUM_STYLE_ROW_INDEX, true);
        List<Cell> cellList2 = PoiUtil.getCellList(row2);

        // 日時フォーマット
        SimpleDateFormat sdf1 = new SimpleDateFormat("yyyy/MM");
        SimpleDateFormat sdf2 = new SimpleDateFormat(syuuekiUtils.formatTimeStamp());
        SimpleDateFormat sdf3 = new SimpleDateFormat("yyyyMM");

        // 単位
        String jpyUnit = Label.getValue(Label.jpyUnit1);
        String jpyUnitKbn = "1";
        if (monthryKakuteiFlg == 1) {
            jpyUnitKbn = s014Bean.getJpyUnit();
            // 月次確定画面から出力
            if("2".equals(s014Bean.getJpyUnit())){
                jpyUnit = Label.getValue(Label.jpyUnit2);
            } else if("3".equals(s014Bean.getJpyUnit())){
                jpyUnit = Label.getValue(Label.jpyUnit3);
            }
        } else {
            // 案件一覧(受注売上見込画面)から出力
            if(s001Bean.getJpyUnit() == 1000){
                jpyUnit = Label.getValue(Label.jpyUnit2);
                jpyUnitKbn = "2";
            } else if(s001Bean.getJpyUnit() == 1000000){
                jpyUnit = Label.getValue(Label.jpyUnit3);
                jpyUnitKbn = "3";
            }
        }

        // 出力者名
        PoiUtil.setCellValue(sheet, 0, 1, loginUserInfo.getUserName());
        // 出力日時
        PoiUtil.setCellValue(sheet, 0, 3, sdf2.format(sysdateFacade.getSysdate()));
        // 単位
        PoiUtil.setCellValue(sheet, 0, 4, Label.getValue(Label.unitLabel) + ":" + jpyUnit);
        PoiUtil.setCellValue(sheet, 1, 74, Label.getValue(Label.unitLabel) + ":" + jpyUnit);
        if(jpyUnitKbn.equals("1")){
            PoiUtil.setCellValue(sheet, 0, 5, "");
        }


        // 対象年期
        String taisyoYK = s001Bean.getTaishoY() + Label.getValue(Label.year);
        taisyoYK = taisyoYK + Label.getValue(Label.firstHalf);
        PoiUtil.setCellValue(sheet, 1, 4, taisyoYK);

        // 展開
        PoiUtil.setCellValue(sheet, 1, 5, "（" + Label.getValue(Label.kaisyu) + Label.getValue(Label.tenkai) + "）");
        PoiUtil.setCellValue(sheet, 4, 9, Label.getValue(Label.kaisyuYm));

        sdf3.setLenient(true);

        // 基準年月(勘定年月)を取得
        Date kanjyoYM = this.getKanjyoYm();

        // 勘定年月の前月を取得
        Date kanjyoYMBefor = Utils.parseDate(SyuuekiUtils.addMonth(StringUtils.replace(syuuekiUtils.exeFormatYm(kanjyoYM), "/", ""), -1));
        logger.info("[AnkenGaikaListService#downloadExecute] kanjyoYm=[{}] kanjyoYMBefor=[{}]", kanjyoYM, kanjyoYMBefor);

        String[] kikanMonthAry = SyuuekiUtils.getKikanMonthAry(s001Bean.getTaishoY() + s001Bean.getTaishoKi());
        // 各月のタイトル(月＋実績(or見込))を出力
        int ymCellNm = FIRST_MONTH_SP_BEFORE;
        String ymJMLabelNow = "";
        String ymJMLabelBef = "";
        for(int j = 0; j < kikanMonthAry.length; j++){
            Date kikanYM = sdf3.parse(kikanMonthAry[j]);

            // ヘッダーの年月を出力(yyyy/mm)
            PoiUtil.setCellValue(sheet, 2, ymCellNm, StringUtils.substring(kikanMonthAry[j], 0, 4) + "/" + StringUtils.substring(kikanMonthAry[j], 4, 6));

            // 今回欄
            if(kikanYM.compareTo(kanjyoYM) < 0){
                ymJMLabelNow = "今回実績";
            }else{
                ymJMLabelNow = "今回見込";
            }
            PoiUtil.setCellValue(sheet, 3, ymCellNm + 4, ymJMLabelNow);

            if(kikanYM.compareTo(kanjyoYMBefor) < 0){
                ymJMLabelBef = "前回実績";
            }else{
                ymJMLabelBef = "前回見込";
            }
            PoiUtil.setCellValue(sheet, 3, ymCellNm, ymJMLabelBef);
            ymCellNm = ymCellNm + 8;
        }
        // 期合計のタイトル(実績(or見込))を出力
        PoiUtil.setCellValue(sheet, 3, ymCellNm + 4, ymJMLabelNow);
        PoiUtil.setCellValue(sheet, 3, ymCellNm, ymJMLabelBef);
        ymCellNm = ymCellNm + 8;
        // [差異]のタイトル(実績(or見込))を出力
        PoiUtil.setCellValue(sheet, 3, ymCellNm, "（" + ymJMLabelNow+ "-" + ymJMLabelBef + "）");


        // 列の非表示コントロール
        this.controlDispColumn(sheet);

        // 案件一覧の取得
        List<Map<String, Object>> list = null;
        if (this.monthyKakuteiFlg() == 1) {
            list = this.findAnkenListKakutei();
        } else {
            list = this.findAnkenList();
        }

        String baseIspKbn = "";

        // 予算ベース全合計用
        BigDecimal yosanSp = null;
        BigDecimal yosanSp01 = null;
        BigDecimal yosanSp2 = null;
        BigDecimal yosanNet = null;
        BigDecimal yosanNet01 = null;
        BigDecimal yosanNet2 = null;


        // 全合計計算用配列と初期化
        Map<String, List<BigDecimal>> goukei = new HashMap<>();
        goukei.put("TOTAL", new ArrayList<BigDecimal>());
        goukei.put("ISP_1", new ArrayList<BigDecimal>());   // 自事業部全合計用配列と初期化
        goukei.put("ISP_2", new ArrayList<BigDecimal>());   // ISP全合計用配列と初期化

        // チームコード中計用配列と初期化
        List<BigDecimal> cyukeiList = new ArrayList<>();

        // チームコード小計用配列と初期化
        List<BigDecimal> syokeiIspList = new ArrayList<>();

        // チームコード中計予算ベース用配列と初期化
        List<BigDecimal> cyukeiYosanList = new ArrayList<>();

        // チームコード小計用配列と初期化
        List<BigDecimal> syokeiIspYosanList = new ArrayList<>();

        // 全合計用配列を初期化
        for(int j = 0; j < HALF_YEAR_SP_NET; j++){
            goukei.get("TOTAL").add(null);
            goukei.get("ISP_1").add(null);
            goukei.get("ISP_2").add(null);

            cyukeiList.add(null);
            syokeiIspList.add(null);
        }

        // 中計小計予算ベース計算用配列を初期化
        for(int j = 0; j < 2; j++){
            cyukeiYosanList.add(null);
            syokeiIspYosanList.add(null);
        }

        ////////////////////////////////////////
        String baseChukeiData = "";
        String chukeiKey = "";
        if("0".equals(s001Bean.getShokeiKbn())){
            chukeiKey = "ATSUKAI_C_CODE";
        } else if("1".equals(s001Bean.getShokeiKbn())){
            chukeiKey = "STCH_NAME";
        }
        if(list.size() > 0){
            if(StringUtils.isNotEmpty(chukeiKey)){
                baseChukeiData = StringUtils.defaultString((String)list.get(0).get(chukeiKey));
            }
            baseIspKbn = nvl((String)list.get(0).get("ISP_KBN"), "0");
        }
        ////////////////////////////////////////

        // 半期データを取得するKeyを格納する配列
        String[] dataKey = {
            "SP1_GAI_BEF",
            "SP1_BEF",
            "NET1_GAI_BEF",
            "NET1_BEF",
            "SP1_GAI_NOW",
            "SP1_NOW",
            "NET1_GAI_NOW",
            "NET1_NOW",
            "SP2_GAI_BEF",
            "SP2_BEF",
            "NET2_GAI_BEF",
            "NET2_BEF",
            "SP2_GAI_NOW",
            "SP2_NOW",
            "NET2_GAI_NOW",
            "NET2_NOW",
            "SP3_GAI_BEF",
            "SP3_BEF",
            "NET3_GAI_BEF",
            "NET3_BEF",
            "SP3_GAI_NOW",
            "SP3_NOW",
            "NET3_GAI_NOW",
            "NET3_NOW",
            "SP4_GAI_BEF",
            "SP4_BEF",
            "NET4_GAI_BEF",
            "NET4_BEF",
            "SP4_GAI_NOW",
            "SP4_NOW",
            "NET4_GAI_NOW",
            "NET4_NOW",
            "SP5_GAI_BEF",
            "SP5_BEF",
            "NET5_GAI_BEF",
            "NET5_BEF",
            "SP5_GAI_NOW",
            "SP5_NOW",
            "NET5_GAI_NOW",
            "NET5_NOW",
            "SP6_GAI_BEF",
            "SP6_BEF",
            "NET6_GAI_BEF",
            "NET6_BEF",
            "SP6_GAI_NOW",
            "SP6_NOW",
            "NET6_GAI_NOW",
            "NET6_NOW",
            "SP_TOTAL_GAI_BEF",
            "SP_TOTAL_BEF",
            "NET_TOTAL_GAI_BEF",
            "NET_TOTAL_BEF",
            "SP_TOTAL_GAI_NOW",
            "SP_TOTAL_NOW",
            "NET_TOTAL_GAI_NOW",
            "NET_TOTAL_NOW",
            "SP_GAI_DIF",
            "SP_DIF",
            "NET_GAI_DIF",
            "NET_DIF"
        };

        // ISP集計の開始/終了行(計算式埋め込みの場合に利用)
        int ispStartRowIndex = rowNum;
        int ispEndRowIndex = rowNum;
        // 中計行を計算するための自事業部行,ISP行
        List<Integer> ispChukeiRowIndexList = new ArrayList<>();
        // 合計行(自事業部計の集計対象にする行数)
        List<Integer> ispSelfIndexList = new ArrayList<>();
        // 合計行(ISP計の集計対象にする行数)
        List<Integer> ispIndexList = new ArrayList<>();

        String ankenIdBef = "";
        //////////////////////////////////////////////////////////////////////////////////
        ////// 一覧データ出力開始
        //////////////////////////////////////////////////////////////////////////////////
        for (Map<String, Object> info : list) {
            i++;

            int cellNum = 0;
            int spNet = 0;

            // ISP小計行を出力したか？
            boolean isOutputIsp = false;

            String nowIspKbn = nvl((String)info.get("ISP_KBN"),"0");

            // 差異を取得
            BigDecimal spDif = syuuekiUtils.arari((BigDecimal)info.get("SP_TOTAL_NOW"), (BigDecimal)info.get("SP_TOTAL_BEF"));
            BigDecimal spGaiDif = syuuekiUtils.arari((BigDecimal)info.get("SP_TOTAL_GAI_NOW"), (BigDecimal)info.get("SP_TOTAL_GAI_BEF"));
            BigDecimal netDif = syuuekiUtils.arari((BigDecimal)info.get("NET_TOTAL_NOW"), (BigDecimal)info.get("NET_TOTAL_BEF"));
            BigDecimal netGaiDif = syuuekiUtils.arari((BigDecimal)info.get("NET_TOTAL_GAI_NOW"), (BigDecimal)info.get("NET_TOTAL_GAI_BEF"));

            // ISP小計計算
            if (StringUtils.isNotEmpty(chukeiKey) && baseChukeiData.equals(StringUtils.defaultString((String)info.get(chukeiKey))) && baseIspKbn.equals(nowIspKbn) || ((StringUtils.isEmpty(chukeiKey)) && baseIspKbn.equals(nowIspKbn))){
                for (int j = 0; j < dataKey.length - 2; j++ ) {
                    syokeiIspList.set(j, Utils.add(syokeiIspList.get(j), (BigDecimal)info.get(dataKey[j])));
                }
                // 差異を計算
                syokeiIspList.set(dataKey.length - 4, Utils.add(syokeiIspList.get(dataKey.length - 4), spGaiDif));
                syokeiIspList.set(dataKey.length - 3, Utils.add(syokeiIspList.get(dataKey.length - 3), spDif));
                syokeiIspList.set(dataKey.length - 2, Utils.add(syokeiIspList.get(dataKey.length - 2), netGaiDif));
                syokeiIspList.set(dataKey.length - 1, Utils.add(syokeiIspList.get(dataKey.length - 1), netDif));

                // 予算ベースを計算
                if(!ankenIdBef.equals((String)info.get("ANKEN_ID"))){
                    syokeiIspYosanList.set(0, Utils.add(syokeiIspYosanList.get(0), (BigDecimal)info.get("YOSAN_SP")));
                    syokeiIspYosanList.set(1, Utils.add(syokeiIspYosanList.get(1), (BigDecimal)info.get("YOSAN_NET")));
                }

                ispEndRowIndex = rowNum;

            } else {
                // ISP小計行を出力
                outIspSubTotalLine(workbook, rowNum, baseIspKbn, baseChukeiData, syokeiIspList, syokeiIspYosanList, jpyUnitKbn, ispStartRowIndex, ispEndRowIndex);
                // 合計行の計算式に埋め込むための行数を確保(計算式を出力指定された場合に利用)
                ispChukeiRowIndexList.add(rowNum);
                if ("2".equals(baseIspKbn)) {
                    ispIndexList.add(rowNum);
                } else {
                    ispSelfIndexList.add(rowNum);
                }

                // 初期化
                for (int j = 0; j < dataKey.length - 2; j++ ) {
                    // 現在行の値を上書きする、値が存在していない場合、0を初期化する
                    syokeiIspList.set(j, (BigDecimal)info.get(dataKey[j]));
                }

                // 差異を初期化
                syokeiIspList.set(dataKey.length - 4, spGaiDif);
                syokeiIspList.set(dataKey.length - 3, spDif);
                syokeiIspList.set(dataKey.length - 2, netGaiDif);
                syokeiIspList.set(dataKey.length - 1, netDif);

                // 予算ベースを初期化
                syokeiIspYosanList.set(0, (BigDecimal)info.get("YOSAN_SP"));
                syokeiIspYosanList.set(1, (BigDecimal)info.get("YOSAN_NET"));

                // 小計キーを更新
                baseIspKbn = nvl((String)info.get("ISP_KBN"), "0");

                isOutputIsp = true;
                rowNum++;
            }

            // 中計計算
            if(StringUtils.isNotEmpty(chukeiKey) && baseChukeiData.equals(StringUtils.defaultString((String)info.get(chukeiKey)))){
                for (int j = 0; j < dataKey.length - 2; j++ ) {
                    cyukeiList.set(j, Utils.add(cyukeiList.get(j), (BigDecimal)info.get(dataKey[j])));
                }
                // 差異を計算
                cyukeiList.set(dataKey.length - 4, Utils.add(cyukeiList.get(dataKey.length - 4), spGaiDif));
                cyukeiList.set(dataKey.length - 3, Utils.add(cyukeiList.get(dataKey.length - 3), spDif));
                cyukeiList.set(dataKey.length - 2, Utils.add(cyukeiList.get(dataKey.length - 2), netGaiDif));
                cyukeiList.set(dataKey.length - 1,  Utils.add(cyukeiList.get(dataKey.length - 1), netDif));

                // 予算ベースを計算
                if(!ankenIdBef.equals((String)info.get("ANKEN_ID"))){
                    cyukeiYosanList.set(0, Utils.add(cyukeiYosanList.get(0), (BigDecimal)info.get("YOSAN_SP")));
                    cyukeiYosanList.set(1, Utils.add(cyukeiYosanList.get(1), (BigDecimal)info.get("YOSAN_NET")));
                }

            }else if(StringUtils.isNotEmpty(chukeiKey) && !baseChukeiData.equals(StringUtils.defaultString((String)info.get(chukeiKey)))){
                // 中計行を出力
                outMidSumLine(workbook, rowNum, baseChukeiData, cyukeiList, cyukeiYosanList, jpyUnitKbn, ispChukeiRowIndexList);

                // 初期化
                for (int j = 0; j < dataKey.length - 2; j++ ) {
                    // 現在行の値を上書きする、値が存在していない場合、0を初期化する
                    cyukeiList.set(j, (BigDecimal)info.get(dataKey[j]));
                }

                // 差異を初期化
                cyukeiList.set(dataKey.length - 4, spGaiDif);
                cyukeiList.set(dataKey.length - 3, spDif);
                cyukeiList.set(dataKey.length - 2, netGaiDif);
                cyukeiList.set(dataKey.length - 1, netDif);

                // 予算ベースを初期化
                cyukeiYosanList.set(0, (BigDecimal)info.get("YOSAN_SP"));
                cyukeiYosanList.set(1, (BigDecimal)info.get("YOSAN_NET"));

                // 中計キーを更新
                baseChukeiData = StringUtils.defaultString((String)info.get(chukeiKey));

                ispChukeiRowIndexList = new ArrayList<>();

                rowNum++;
            }

            // ISP小計行を出力した場合、ISPデータ開始-ISPデータ終了の行数を現在の行に初期化する。
            if (isOutputIsp) {
                ispStartRowIndex = rowNum;
                ispEndRowIndex = rowNum;
            }

            row1 = PoiUtil.getRow(sheet, rowNum, true);
            if (rowNum > FIRST_ROW_INDEX) {
                // 2行目以降のスタイル
                PoiUtil.copyRowStyleValue(row1, cellList1, summayCalc);
            } else {
                // 1行目のスタイル
                PoiUtil.copyRowStyleValue(row1, cellListFirst, summayCalc);
            }


            ///////////////////////////////////////////////////////////////////////////////////////////////
            //////////////////////////// 以下,1行分のデータ出力 /////////////////////////////////////////
            ///////////////////////////////////////////////////////////////////////////////////////////////
            // 売上基準
//            PoiUtil.setCellValue(sheet, rowNum, cellNum++, syuuekiUtils.getSalesClassLabelFull((String)info.get("SALES_CLASS")));//20180302 原価回収基準対応　REP
            PoiUtil.setCellValue(sheet, rowNum, cellNum++, syuuekiUtils.getSalesClassLabelAddLoss(syuuekiUtils.getSalesClassLabelGenFull((String)info.get("SALES_CLASS"),(String)info.get("SALES_CLASS_GENKA")), (String)info.get("LOSS_CONTROL_FLAG")));//20180302 原価回収基準対応　REP  // 2018/06/01 ロスコン対応

            // 本社部課
            PoiUtil.setCellValue(sheet, rowNum, cellNum++, (String)info.get("ATSUKAI_TEAM_CODE"));

            // C部課
            PoiUtil.setCellValue(sheet, rowNum, cellNum++, (String)info.get("ATSUKAI_C_CODE"));

            // 注文主
            PoiUtil.setCellValue(sheet, rowNum, cellNum++, (String)info.get("TRADE_NAME"));

            // 設置場所
            PoiUtil.setCellValue(sheet, rowNum, cellNum++, (String)info.get("STCH_NAME"));

            // 案件名称
            PoiUtil.setCellValue(sheet, rowNum, cellNum++, (String)info.get("ANKEN_NAME"));

            // 案件番号
            PoiUtil.setCellValue(sheet, rowNum, cellNum++, (String)info.get("ANKEN_ID"));

            // O/#
            PoiUtil.setCellValue(sheet, rowNum, cellNum++, (String)info.get("ORDER_NO"));

            // 連番
            PoiUtil.setCellValue(sheet, rowNum, cellNum++, (String)info.get("KEIYAKU_RENBAN_MAX"));

            // 売上月もしくは受注月
            PoiUtil.setCellValue(sheet, rowNum, cellNum++, (info.get("KAISYU_END") != null ? sdf1.format((Date)info.get("KAISYU_END")) : null));

            // 通貨
            PoiUtil.setCellValue(sheet, rowNum, cellNum++, (String)info.get("CURRENCY_CODE_NOW"));

            /////////////////////////// 予算ベース(S) ////////////////////////////////////////////
            // 予算ベース_SP
            BigDecimal yosanSpCell = (BigDecimal)info.get("YOSAN_SP");
            if(ankenIdBef.equals((String)info.get("ANKEN_ID"))){
                yosanSpCell = null;
            }
            PoiUtil.setCellValue(sheet, rowNum, cellNum++, syuuekiUtils.changeUnit(yosanSpCell, jpyUnitKbn));
            // 総合計
            yosanSp = Utils.add(yosanSp,yosanSpCell);
            // ISP合計
            if("2".equals((String)info.get("ISP_KBN"))){
                yosanSp2 = Utils.add(yosanSp2, yosanSpCell);
            } else {
                yosanSp01 = Utils.add(yosanSp01, yosanSpCell);
            }
/*
            PoiUtil.setCellValue(sheet, rowNum, cellNum++, syuuekiUtils.changeUnit((BigDecimal)info.get("YOSAN_SP"), jpyUnitKbn));
            // 総合計
            yosanSp = Utils.add(yosanSp, (BigDecimal)info.get("YOSAN_SP"));
            // ISP合計
            if("2".equals((String)info.get("ISP_KBN"))){
                yosanSp2 = Utils.add(yosanSp2, (BigDecimal)info.get("YOSAN_SP"));
            } else {
                yosanSp01 = Utils.add(yosanSp01, (BigDecimal)info.get("YOSAN_SP"));
            }
*/

            // 予算ベース_NET
            BigDecimal yosanNetCell = (BigDecimal)info.get("YOSAN_NET");
            if(ankenIdBef.equals((String)info.get("ANKEN_ID"))){
                yosanNetCell = null;
            }
            PoiUtil.setCellValue(sheet, rowNum, cellNum++, syuuekiUtils.changeUnit(yosanNetCell, jpyUnitKbn));
            // 総合計
            yosanNet = Utils.add(yosanNet, yosanNetCell);
            // ISP合計
            if("2".equals((String)info.get("ISP_KBN"))){
                yosanNet2 = Utils.add(yosanNet2, yosanNetCell);
            } else {
                yosanNet01 = Utils.add(yosanNet01, yosanNetCell);
            }
/*
            PoiUtil.setCellValue(sheet, rowNum, cellNum++, syuuekiUtils.changeUnit((BigDecimal)info.get("YOSAN_NET"), jpyUnitKbn));
            // 総合計
            yosanNet = Utils.add(yosanNet, (BigDecimal)info.get("YOSAN_NET"));
            // ISP合計
            if("2".equals((String)info.get("ISP_KBN"))){
                yosanNet2 = Utils.add(yosanNet2, (BigDecimal)info.get("YOSAN_NET"));
            } else {
                yosanNet01 = Utils.add(yosanNet01, (BigDecimal)info.get("YOSAN_NET"));
            }
*/
            if (!summayCalc) { // ダウンロードオプションで"合計行:値"の場合のみ設定する
                // 予算ベース_粗利
                PoiUtil.setCellValue(sheet, rowNum, cellNum++, syuuekiUtils.changeUnit(syuuekiUtils.arari(yosanSpCell, yosanNetCell), jpyUnitKbn));
                //PoiUtil.setCellValue(sheet, rowNum, cellNum++, syuuekiUtils.changeUnit(syuuekiUtils.arari((BigDecimal)info.get("YOSAN_SP"), (BigDecimal)info.get("YOSAN_NET")), jpyUnitKbn));
                // 予算ベース_M率
                PoiUtil.setCellValue(sheet, rowNum, cellNum++,  Utils.changeBigDecimal(syuuekiUtils.mrate(Utils.changeBigDecimal(Utils.getObjToStrValue(yosanSpCell)), Utils.changeBigDecimal(Utils.getObjToStrValue(yosanNetCell)))));
                //PoiUtil.setCellValue(sheet, rowNum, cellNum++,  Utils.changeBigDecimal(syuuekiUtils.mrate(Utils.changeBigDecimal(Utils.getObjToStrValue((BigDecimal)info.get("YOSAN_SP"))), Utils.changeBigDecimal(Utils.getObjToStrValue((BigDecimal)info.get("YOSAN_NET"))))));
            } else {
                cellNum++;
                cellNum++;
            }
            ankenIdBef = (String)info.get("ANKEN_ID");
            /////////////////////////// 予算ベース(E) ////////////////////////////////////////////


            /////////////////////////// 各月の前受,売掛をセット(S) ////////////////////////////////////////////
            String spKey;
            String spGaiKey;
            String netKey;
            String netGaiKey;
            // 各月の前受,売掛をセット
            for (int idx=1; idx<=6; idx++) {
                //////////////// 前回 /////////////////
                spKey = "SP" + idx + "_BEF";
                spGaiKey = "SP" + idx + "_GAI_BEF";
                netKey = "NET" + idx + "_BEF";
                netGaiKey = "NET" + idx + "_GAI_BEF";
                // 対象年月(前回)の前受,売掛を出力
                cellNum = writeExcelMonthData(info, spKey, spGaiKey, netKey, netGaiKey, jpyUnitKbn, sheet, rowNum, cellNum);
                // 対象年月のSP前回見込 総合計，自事業部計、ISP計
                addTotalSpNet(goukei, spNet, nowIspKbn, (BigDecimal)info.get(spGaiKey));
                spNet++;
                // 対象年月のSP前回見込 総合計，自事業部計、ISP計
                addTotalSpNet(goukei, spNet, nowIspKbn, (BigDecimal)info.get(spKey));
                spNet++;
                // 対象年月のNET前回見込 総合計，自事業部計、ISP計
                addTotalSpNet(goukei, spNet, nowIspKbn, (BigDecimal)info.get(netGaiKey));
                spNet++;
                // 対象年月のNET前回見込 総合計，自事業部計、ISP計
                addTotalSpNet(goukei, spNet, nowIspKbn, (BigDecimal)info.get(netKey));
                spNet++;


                ////////// 今回 ///////////
                spKey = "SP" + idx + "_NOW";
                spGaiKey = "SP" + idx + "_GAI_NOW";
                netKey = "NET" + idx + "_NOW";
                netGaiKey = "NET" + idx + "_GAI_NOW";
                // 対象年月(今回)のSP,NET,粗利,M率を出力
                cellNum = writeExcelMonthData(info, spKey, spGaiKey, netKey, netGaiKey, jpyUnitKbn, sheet, rowNum, cellNum);
                // 対象年月のSP今回見込 総合計，自事業部計、ISP計
                addTotalSpNet(goukei, spNet, nowIspKbn, (BigDecimal)info.get(spGaiKey));
                spNet++;
                // 対象年月のSP今回見込 総合計，自事業部計、ISP計
                addTotalSpNet(goukei, spNet, nowIspKbn, (BigDecimal)info.get(spKey));
                spNet++;
                // 対象年月のNET今回見込 総合計，自事業部計、ISP計
                addTotalSpNet(goukei, spNet, nowIspKbn, (BigDecimal)info.get(netGaiKey));
                spNet++;
                // 対象年月のNET今回見込 総合計，自事業部計、ISP計
                addTotalSpNet(goukei, spNet, nowIspKbn, (BigDecimal)info.get(netKey));
                spNet++;
            }
            /////////////////////////// 各月の前受,売掛をセット(S) ////////////////////////////////////////////


            /////////////////////////// 期合計(S) ////////////////////////////////////////////
            ////// 前回
            spKey = "SP_TOTAL_BEF";
            spGaiKey = "SP_TOTAL_GAI_BEF";
            netKey = "NET_TOTAL_BEF";
            netGaiKey = "NET_TOTAL_GAI_BEF";
            // 期合計・前回 SP,NET,粗利,M率を出力
            cellNum = writeExcelMonthData(info, spKey, spGaiKey, netKey, netGaiKey, jpyUnitKbn, sheet, rowNum, cellNum);
            // 期合計・前回SPの総合計，自事業部計、ISP計
            addTotalSpNet(goukei, spNet, nowIspKbn, (BigDecimal)info.get(spGaiKey));
            spNet++;
            // 期合計・前回SPの総合計，自事業部計、ISP計
            addTotalSpNet(goukei, spNet, nowIspKbn, (BigDecimal)info.get(spKey));
            spNet++;
            // 期合計・前回NETの総合計，自事業部計、ISP計
            addTotalSpNet(goukei, spNet, nowIspKbn, (BigDecimal)info.get(netGaiKey));
            spNet++;
            // 期合計・前回NETの総合計，自事業部計、ISP計
            addTotalSpNet(goukei, spNet, nowIspKbn, (BigDecimal)info.get(netKey));
            spNet++;

            ////// 今回
            spKey = "SP_TOTAL_NOW";
            spGaiKey = "SP_TOTAL_GAI_NOW";
            netKey = "NET_TOTAL_NOW";
            netGaiKey = "NET_TOTAL_GAI_NOW";
            // SP,NET,粗利,M率を出力
            cellNum = writeExcelMonthData(info, spKey, spGaiKey, netKey, netGaiKey, jpyUnitKbn, sheet, rowNum, cellNum);
            // 期合計・今回SPの総合計，自事業部計、ISP計
            addTotalSpNet(goukei, spNet, nowIspKbn, (BigDecimal)info.get(spGaiKey));
            spNet++;
            // 期合計・今回SPの総合計，自事業部計、ISP計
            addTotalSpNet(goukei, spNet, nowIspKbn, (BigDecimal)info.get(spKey));
            spNet++;
            // 期合計・今回NETの総合計，自事業部計、ISP計
            addTotalSpNet(goukei, spNet, nowIspKbn, (BigDecimal)info.get(netGaiKey));
            spNet++;
            // 期合計・今回NETの総合計，自事業部計、ISP計
            addTotalSpNet(goukei, spNet, nowIspKbn, (BigDecimal)info.get(netKey));
            spNet++;
            /////////////////////////// 期合計(E) ////////////////////////////////////////////


            /////////////////////////// 差異(S) ////////////////////////////////////////////
            // 差異_SP、差異NET
            if (summayCalc) {
                cellNum++;
                cellNum++;
                cellNum++;
                cellNum++;
            } else {
                // ダウンロードオプションで"合計行:値"の場合のみ、直接の値を設定する
                PoiUtil.setCellValue(sheet, rowNum, cellNum++, syuuekiUtils.changeUnit(spGaiDif, jpyUnitKbn));
                PoiUtil.setCellValue(sheet, rowNum, cellNum++, syuuekiUtils.changeUnit(spDif, jpyUnitKbn));
                PoiUtil.setCellValue(sheet, rowNum, cellNum++, syuuekiUtils.changeUnit(netGaiDif, jpyUnitKbn));
                PoiUtil.setCellValue(sheet, rowNum, cellNum++, syuuekiUtils.changeUnit(netDif, jpyUnitKbn));
            }

            // 差異SPの総合計，自事業部計、ISP計
            addTotalSpNet(goukei, spNet, nowIspKbn, spGaiDif);
            spNet++;
            // 差異SPの総合計，自事業部計、ISP計
            addTotalSpNet(goukei, spNet, nowIspKbn, spDif);
            spNet++;
            // 差異NETの総合計，自事業部計、ISP計
            addTotalSpNet(goukei, spNet, nowIspKbn, netGaiDif);
            spNet++;
            // 差異NETの総合計，自事業部計、ISP計
            addTotalSpNet(goukei, spNet, nowIspKbn, netDif);
            spNet++;
            /////////////////////////// 差異(E) ////////////////////////////////////////////

            // 備考
            PoiUtil.setCellValue(sheet, rowNum, cellNum++,  (String)info.get("BIKOU_KIKAN"));

            rowNum++;
        }


        // 最終小計行出力
        outIspSubTotalLine(workbook, rowNum, baseIspKbn, baseChukeiData, syokeiIspList, syokeiIspYosanList, jpyUnitKbn, ispStartRowIndex, ispEndRowIndex);
        // 合計行の計算式に埋め込むための行数を確保(計算式を出力指定された場合に利用)
        ispChukeiRowIndexList.add(rowNum);
        if ("2".equals(baseIspKbn)) {
            ispIndexList.add(rowNum);
        } else {
            ispSelfIndexList.add(rowNum);
        }

        rowNum++;

        // 最終中計行出力
        if(StringUtils.isNotEmpty(chukeiKey)){
            // 中計行を出力
            outMidSumLine(workbook, rowNum, baseChukeiData, cyukeiList, cyukeiYosanList, jpyUnitKbn, ispChukeiRowIndexList);
            rowNum++;
        }

        // 最終合計行を作成
        for(int j = 0; j < 3; j++){
            row2 = PoiUtil.getRow(sheet, rowNum + j, true);
            PoiUtil.copyRowStyleValue(row2, cellList2, summayCalc);
        }

        // 結合
        sheet.addMergedRegion(new CellRangeAddress(rowNum, rowNum, 0, 4));
        sheet.addMergedRegion(new CellRangeAddress(rowNum + 1, rowNum + 1, 0, 4));
        sheet.addMergedRegion(new CellRangeAddress(rowNum + 2, rowNum + 2, 0, 4));

        int spCellNm = FIRST_MONTH_SP_BEFORE;

        PoiUtil.setCellValue(sheet, rowNum, 0, "自事業部　計");
        PoiUtil.setCellValue(sheet, rowNum + 1, 0, "ISP　計");
        PoiUtil.setCellValue(sheet, rowNum + 2, 0, "合計");

        //// 予算ベース最終合計3行出力(S)
        // 自営業部計(SP/NET)
        PoiUtil.setCellValue(sheet, rowNum, spCellNm - 4, syuuekiUtils.changeUnit(yosanSp01, jpyUnitKbn));
        PoiUtil.setCellValue(sheet, rowNum, spCellNm - 3, syuuekiUtils.changeUnit(yosanNet01, jpyUnitKbn));
        // ISP計(SP/NET)
        PoiUtil.setCellValue(sheet, rowNum + 1, spCellNm - 4, syuuekiUtils.changeUnit(yosanSp2, jpyUnitKbn));
        PoiUtil.setCellValue(sheet, rowNum + 1, spCellNm - 3, syuuekiUtils.changeUnit(yosanNet2, jpyUnitKbn));
        // 全合計(SP/NET)
        PoiUtil.setCellValue(sheet, rowNum + 2, spCellNm - 4, syuuekiUtils.changeUnit(yosanSp, jpyUnitKbn));
        PoiUtil.setCellValue(sheet, rowNum + 2, spCellNm - 3, syuuekiUtils.changeUnit(yosanNet, jpyUnitKbn));

        if (summayCalc) { // ダウンロードオプションで"合計行:計算式"の場合のみ設定する
            // 自営業部計(SP/NET)
            PoiUtil.setCellFormula(sheet, rowNum, spCellNm - 4, this.getExcelPlusRowFormula(ispSelfIndexList, spCellNm - 4));
            PoiUtil.setCellFormula(sheet, rowNum, spCellNm - 3, this.getExcelPlusRowFormula(ispSelfIndexList, spCellNm - 3));
            // ISP計(SP/NET)
            PoiUtil.setCellFormula(sheet, rowNum + 1, spCellNm - 4, this.getExcelPlusRowFormula(ispIndexList, spCellNm - 4));
            PoiUtil.setCellFormula(sheet, rowNum + 1, spCellNm - 3, this.getExcelPlusRowFormula(ispIndexList, spCellNm - 3));
            // 全合計(自営業部計+ISP計でも合致するので、簡単なこちらを採用)
            PoiUtil.setCellFormula(sheet, rowNum + 2, spCellNm - 4, "SUM(" + PoiUtil.getCellReferenceStr(rowNum, spCellNm - 4) + "," + PoiUtil.getCellReferenceStr(rowNum + 1, spCellNm - 4) + ")");
            PoiUtil.setCellFormula(sheet, rowNum + 2, spCellNm - 3, "SUM(" + PoiUtil.getCellReferenceStr(rowNum, spCellNm - 3) + "," + PoiUtil.getCellReferenceStr(rowNum + 1, spCellNm - 3) + ")");

        } else {   // ダウンロードオプションで"合計行:値"の場合のみ設定する
            // 自営業部計(粗利/M率)
            PoiUtil.setCellValue(sheet, rowNum, spCellNm - 2, syuuekiUtils.changeUnit(syuuekiUtils.arari(yosanSp01, yosanNet01), jpyUnitKbn));
            PoiUtil.setCellValue(sheet, rowNum, spCellNm - 1, syuuekiUtils.mrate(yosanSp01, yosanNet01));
            // ISP計(粗利/M率)
            PoiUtil.setCellValue(sheet, rowNum + 1, spCellNm - 2, syuuekiUtils.changeUnit(syuuekiUtils.arari(yosanSp2, yosanNet2), jpyUnitKbn));
            PoiUtil.setCellValue(sheet, rowNum + 1, spCellNm - 1, syuuekiUtils.mrate(yosanSp2, yosanNet2));
            // 全合計(粗利/M率)
            PoiUtil.setCellValue(sheet, rowNum + 2, spCellNm - 2, syuuekiUtils.changeUnit(syuuekiUtils.arari(yosanSp, yosanNet), jpyUnitKbn));
            PoiUtil.setCellValue(sheet, rowNum + 2, spCellNm - 1, syuuekiUtils.mrate(yosanSp, yosanNet));
        }
        //// 予算ベース最終合計3行出力(E)


        ////　最終合計行データ出力(S)
        for(int j = 0; j < HALF_YEAR_SP_NET; j = j + 4){
            List<BigDecimal> totalColList = goukei.get("TOTAL");
            List<BigDecimal> isp1ColList = goukei.get("ISP_1");
            List<BigDecimal> isp2ColList = goukei.get("ISP_2");

            // 自事業部計(SP/NET)
            //PoiUtil.setCellValue(sheet, rowNum, spCellNm, syuuekiUtils.changeUnit(isp1ColList.get(j), jpyUnitKbn)); //2018/08 Del
            PoiUtil.setCellValue(sheet, rowNum, spCellNm + 1, syuuekiUtils.changeUnit(isp1ColList.get(j + 1), jpyUnitKbn));
            //PoiUtil.setCellValue(sheet, rowNum, spCellNm + 2, syuuekiUtils.changeUnit(isp1ColList.get(j + 2), jpyUnitKbn)); //2018/08 Del
            PoiUtil.setCellValue(sheet, rowNum, spCellNm + 3, syuuekiUtils.changeUnit(isp1ColList.get(j + 3), jpyUnitKbn));
            // ISP計(SP/NET)
            //PoiUtil.setCellValue(sheet, rowNum + 1, spCellNm, syuuekiUtils.changeUnit(isp2ColList.get(j), jpyUnitKbn)); //2018/08 Del
            PoiUtil.setCellValue(sheet, rowNum + 1, spCellNm + 1, syuuekiUtils.changeUnit(isp2ColList.get(j + 1), jpyUnitKbn));
            //PoiUtil.setCellValue(sheet, rowNum + 1, spCellNm + 2, syuuekiUtils.changeUnit(isp2ColList.get(j + 2), jpyUnitKbn)); //2018/08 Del
            PoiUtil.setCellValue(sheet, rowNum + 1, spCellNm + 3, syuuekiUtils.changeUnit(isp2ColList.get(j + 3), jpyUnitKbn));
            // 全合計(SP/NET)
            //PoiUtil.setCellValue(sheet, rowNum + 2, spCellNm, syuuekiUtils.changeUnit(totalColList.get(j), jpyUnitKbn)); //2018/08 Del
            PoiUtil.setCellValue(sheet, rowNum + 2, spCellNm + 1, syuuekiUtils.changeUnit(totalColList.get(j + 1), jpyUnitKbn));
            //PoiUtil.setCellValue(sheet, rowNum + 2, spCellNm + 2, syuuekiUtils.changeUnit(totalColList.get(j + 2), jpyUnitKbn)); //2018/08 Del
            PoiUtil.setCellValue(sheet, rowNum + 2, spCellNm + 3, syuuekiUtils.changeUnit(totalColList.get(j + 3), jpyUnitKbn));

            if (summayCalc) { // ダウンロードオプションで"合計行:計算式"の場合のみ設定する
                // 自営業部計(SP/NET)
                PoiUtil.setCellFormula(sheet, rowNum, spCellNm); 
                //PoiUtil.setCellFormula(sheet, rowNum, spCellNm, this.getExcelPlusRowFormula(ispSelfIndexList, spCellNm)); //2018/08 Del
                PoiUtil.setCellFormula(sheet, rowNum, spCellNm + 1, this.getExcelPlusRowFormula(ispSelfIndexList, spCellNm + 1));
                PoiUtil.setCellFormula(sheet, rowNum, spCellNm + 2);
                //PoiUtil.setCellFormula(sheet, rowNum, spCellNm + 2, this.getExcelPlusRowFormula(ispSelfIndexList, spCellNm + 2)); //2018/08 Del
                PoiUtil.setCellFormula(sheet, rowNum, spCellNm + 3, this.getExcelPlusRowFormula(ispSelfIndexList, spCellNm + 3));
                // ISP計(SP/NET)
                PoiUtil.setCellFormula(sheet, rowNum + 1, spCellNm);
                //PoiUtil.setCellFormula(sheet, rowNum + 1, spCellNm, this.getExcelPlusRowFormula(ispIndexList, spCellNm)); //2018/08 Del
                PoiUtil.setCellFormula(sheet, rowNum + 1, spCellNm + 1, this.getExcelPlusRowFormula(ispIndexList, spCellNm + 1));
                PoiUtil.setCellFormula(sheet, rowNum + 1, spCellNm + 2);
                //PoiUtil.setCellFormula(sheet, rowNum + 1, spCellNm + 2, this.getExcelPlusRowFormula(ispIndexList, spCellNm + 2)); //2018/08 Del
                PoiUtil.setCellFormula(sheet, rowNum + 1, spCellNm + 3, this.getExcelPlusRowFormula(ispIndexList, spCellNm + 3));
                // 全合計(ISP計+全合計でも合致するので、簡単なこちらを採用)
                PoiUtil.setCellFormula(sheet, rowNum + 2, spCellNm);
                //PoiUtil.setCellFormula(sheet, rowNum + 2, spCellNm, "SUM(" + PoiUtil.getCellReferenceStr(rowNum, spCellNm) + "," + PoiUtil.getCellReferenceStr(rowNum + 1, spCellNm) + ")"); //2018/08 Del
                PoiUtil.setCellFormula(sheet, rowNum + 2, spCellNm + 1, "SUM(" + PoiUtil.getCellReferenceStr(rowNum, spCellNm + 1) + "," + PoiUtil.getCellReferenceStr(rowNum + 1, spCellNm + 1) + ")");
                PoiUtil.setCellFormula(sheet, rowNum + 2, spCellNm + 2);
                //PoiUtil.setCellFormula(sheet, rowNum + 2, spCellNm + 2, "SUM(" + PoiUtil.getCellReferenceStr(rowNum, spCellNm + 2) + "," + PoiUtil.getCellReferenceStr(rowNum + 1, spCellNm + 2) + ")"); //2018/08 Del
                PoiUtil.setCellFormula(sheet, rowNum + 2, spCellNm + 3, "SUM(" + PoiUtil.getCellReferenceStr(rowNum, spCellNm + 3) + "," + PoiUtil.getCellReferenceStr(rowNum + 1, spCellNm + 3) + ")");

            } else {    // ダウンロードオプションで"合計行:値"の場合のみ設定する

//                // 粗利/M率(回収展開の場合は合計)をセット
//                int totalCellNum = spCellNm + 2;
//                setArariMrateValue(sheet, rowNum, totalCellNum, jpyUnitKbn, isp1ColList.get(j), isp1ColList.get(j+1));
//                setArariMrateValue(sheet, (rowNum + 1), totalCellNum, jpyUnitKbn, isp2ColList.get(j), isp2ColList.get(j+1));
//                setArariMrateValue(sheet, (rowNum + 2), totalCellNum, jpyUnitKbn, totalColList.get(j), totalColList.get(j+1));
            }
            ////　最終合計行データ出力(E)

            spCellNm = spCellNm + 4;
        }

        if (summayCalc) {
            // 計算式を実行(ダウンロードオプションで"合計行:計算式"の場合のみ実行)
            sheet.setForceFormulaRecalculation(true);
        }

        // 操作ログを出力
        OperationLog operationLog = operationLogService.getOperationLog();
        operationLog.setOperationCode("DL_JOB");
        operationLog.setObjectType("ANKEN");
        operationLog.setObjectId(10);
        operationLog.setRemarks("案件一覧(月別)");
        operationLogService.insertOperationLogSearch(operationLog);

    }

    /**
     * 各年月欄の前受、売掛
     */
    private int writeExcelMonthData(Map<String, Object> info, String spKey, String spGaiKey, String netKey, String netGaiKey, String jpyUnitKbn, Sheet sheet, int rowNum, int _cellNum) {
        int cellNum = _cellNum;

        // 前受(外貨)出力
        BigDecimal spGaiValue = (BigDecimal)info.get(spGaiKey);
        PoiUtil.setCellValue(sheet, rowNum, cellNum, spGaiValue);
        cellNum = cellNum + 1;

        // 前受(円貨)出力
        BigDecimal spValue = (BigDecimal)info.get(spKey);
        PoiUtil.setCellValue(sheet, rowNum, cellNum, syuuekiUtils.changeUnit(spValue, jpyUnitKbn));
        cellNum = cellNum + 1;

        // 売掛(外貨)出力
        BigDecimal netGaiValue = (BigDecimal)info.get(netGaiKey);
        PoiUtil.setCellValue(sheet, rowNum, cellNum, netGaiValue);
        cellNum = cellNum + 1;

        // 売掛(円貨)出力
        BigDecimal netValue = (BigDecimal)info.get(netKey);
        PoiUtil.setCellValue(sheet, rowNum, cellNum, syuuekiUtils.changeUnit(netValue, jpyUnitKbn));
        cellNum = cellNum + 1;

        return cellNum;
    }

    /**
     * 粗利/M率(回収展開の場合は合計)の値をセットする
     * @return シフト先のセル位置
     */
    private int setArariMrateValue(Sheet sheet, int rowNum, int _cellNum, String jpyUnitKbn, BigDecimal spValue, BigDecimal netValue) {
        int cellNum = _cellNum;

        ///////// ダウンロードオプションで"合計行:値"の場合
        // 合計
        PoiUtil.setCellValue(sheet, rowNum, cellNum, syuuekiUtils.changeUnit(NumberUtils.add(spValue, netValue), jpyUnitKbn));
        cellNum = cellNum + 1;
        // 合計欄の右隣りは何も出力しない(受注・売上展開のテンプレートと合わせるために空欄になっている)
        cellNum = cellNum + 1;

        return cellNum;
    }

    private void addTotalSpNet(Map<String, List<BigDecimal>> goukei, int colIndex, String ispKbn, BigDecimal spNet) {
        List<BigDecimal> totalList = goukei.get("TOTAL");
        List<BigDecimal> Isp1List = goukei.get("ISP_1");
        List<BigDecimal> Isp2List = goukei.get("ISP_2");

        // [合計(最下段の総合計)]行の計算
        totalList.set(colIndex, NumberUtils.add(totalList.get(colIndex), spNet));
        if ("2".equals(ispKbn)) {
            // [ISP 計]行の計算
            Isp2List.set(colIndex, NumberUtils.add(Isp2List.get(colIndex), spNet));
        } else {
            // [自事業部 計]行の計算
            Isp1List.set(colIndex, NumberUtils.add(Isp1List.get(colIndex), spNet));
        }
    }


    /**
     * SYU_WF_CONTROL_TBLから検索対象の本社チームコード、支社チームコード、今回履歴id
     * (月次確定画面からの出力の場合)
     */
    private void findTeamInfoList(
          List<String> honsyaTeamCodeList
        , List<String> shisyaTeamCodeList
        , List<String> teishutsuHonsyaTeamCodeList
        , List<String> teishutsuShisyaTeamCodeList
        , List<String> kakuteiHonsyaTeamCodeList
        , List<String> kakuteiShisyaTeamCodeList
        , List<Object> nowRirekiIdList
    ) throws Exception {
        List<SyuWfControlTbl> teamCodeList = this.findTeamList();

        for (SyuWfControlTbl wfControlTeamInfo : teamCodeList) {
            String honsyaShisyaKbn = wfControlTeamInfo.getHonsyaShisyaKbn();

            // 履歴ID
            Long rirekiId = wfControlTeamInfo.getRirekiId();
            String status = wfControlTeamInfo.getStatus();
            logger.info("[findTeamInfoList] rirekiId=[{}] status=[{}]", rirekiId, status);
            if (ConstantString.wfStatusKakutei.equals(status)) {
                ////// 確定済
                // 確定済のチームコードは、その履歴idを検索対象とする。
                nowRirekiIdList.add(rirekiId);

                // 確定済の本社チームコードと支社チームコードをため込む
                if (StringUtils.isNotEmpty(wfControlTeamInfo.getTeamCode())) {
                    if ("H".equals(honsyaShisyaKbn)) {
                        // 本社チームコード
                        kakuteiHonsyaTeamCodeList.add(wfControlTeamInfo.getTeamCode());
                    } else if ("S".equals(honsyaShisyaKbn)) {
                        // 支社チームコード
                        kakuteiShisyaTeamCodeList.add(wfControlTeamInfo.getTeamCode());
                    }
                }

            } else if (ConstantString.wfStatusTeishutsu.equals(status)) {
                ////// 提出用
                // 提出用の本社チームコードと支社チームコードをため込む
                if (StringUtils.isNotEmpty(wfControlTeamInfo.getTeamCode())) {
                    if ("H".equals(honsyaShisyaKbn)) {
                        // 本社チームコード
                        teishutsuHonsyaTeamCodeList.add(wfControlTeamInfo.getTeamCode());
                    } else if ("S".equals(honsyaShisyaKbn)) {
                        // 支社チームコード
                        teishutsuShisyaTeamCodeList.add(wfControlTeamInfo.getTeamCode());
                    }
                }

            } else {
                ////// 未確定チームコード場合
                // 未確定の本社チームコードと支社チームコードをため込む
                if (StringUtils.isNotEmpty(wfControlTeamInfo.getTeamCode())) {
                    if ("H".equals(honsyaShisyaKbn)) {
                        // 本社チームコード
                        honsyaTeamCodeList.add(wfControlTeamInfo.getTeamCode());
                    } else if ("S".equals(honsyaShisyaKbn)) {
                        // 支社チームコード
                        shisyaTeamCodeList.add(wfControlTeamInfo.getTeamCode());
                    }
                }

            }
        }

    }

    /**
     * 前回履歴IDを取得(月次確定画面からの場合)
     */
    private List<Object> getWfBeforeRirekiIdList() throws Exception {
        List<Object> beforeRirekiIdList = new ArrayList<>();
        Map<String, Object> condtion = this.getWfControlCondition();

        String dataKbn = "M";
        if ("Y".equals(s014Bean.getSyubetsu())) {
            // 月次確定画面を種別:Y(予算確定)で開いた場合
            // 受注売上見込一覧の検索条件:データ種別=予算確定(Y)とする。
            dataKbn = s014Bean.getSyubetsu();
        }
        condtion.put("dataKbn", dataKbn);
        condtion.put("taishoYm", condtion.get("kanjyoYm"));

        String beforeRerekiIds = s001Service.getOldRirekiID(condtion);
        if (StringUtils.isNotEmpty(beforeRerekiIds)) {
            beforeRirekiIdList = new ArrayList<Object>(Arrays.asList(beforeRerekiIds.split(",")));
        }

        return beforeRirekiIdList;
    }

    /**
     * SQL文の基本条件を取得
     */
    private Map<String, Object> getBaseAnkenListCondition() throws ParseException {
        Map<String, Object> condtion = new HashMap<>();

        int monthryKakuteiFlg = this.monthyKakuteiFlg();

        // 半期年月を取得
        String[] kikanMonthAry = SyuuekiUtils.getKikanMonthAry(s001Bean.getTaishoY() + s001Bean.getTaishoKi());

        condtion.put("monthyKakuteiFlg", String.valueOf(monthryKakuteiFlg));
        condtion.put("baseYm", StringUtils.replace(syuuekiUtils.exeFormatYm(this.getKanjyoYm()), "/", ""));
        int ymIndex = 1;
        for (String month : kikanMonthAry) {
            // 年月指定
            condtion.put("syuekiYm" + ymIndex, month);
            ymIndex++;
        }
        condtion.put("syuekiLastYm", SyuuekiUtils.dateToKikan(Utils.parseDate(kikanMonthAry[0])));

        if (monthryKakuteiFlg == 1) {
            // 月次確定画面から出力
            logger.info("[getBaseAnkenListCondition] shisyaHonsyaKbn:[{}]", s014Bean.getHonsyaShisyaKbn());
            if (s014Bean.getHonsyaShisyaKbn().equals("H")) {
                condtion.put("shisyaHonsyaKbn", "1");
            } else {
                condtion.put("shisyaHonsyaKbn", "0");
            }

        } else {
            // 受注売上見込一覧から出力
            logger.info("[getBaseAnkenListCondition] shisyaHonsyaKbn:[H]");
            condtion.put("shisyaHonsyaKbn", "1");
        }

        return condtion;
    }

    /**
     * SQL文のORDER BY句を取得
     */
    private String getAnkenListOrderBy(String prefix) {
        String orderBy = "";
        if ("0".equals(s001Bean.getShokeiKbn())) {
            // 販売チーム
            orderBy = "ORDER BY " + prefix + ".ATSUKAI_C_CODE, (CASE WHEN " + prefix + ".ISP_KBN IS NULL OR " + prefix + ".ISP_KBN = '1' THEN '0' ELSE " + prefix + ".ISP_KBN END) ";
        } else if("1".equals(s001Bean.getShokeiKbn())) {
            // 設置場所
            orderBy = "ORDER BY " + prefix + ".STCH_NAME, (CASE WHEN " + prefix + ".ISP_KBN IS NULL OR " + prefix + ".ISP_KBN = '1' THEN '0' ELSE " + prefix + ".ISP_KBN END) ";
        } else {
            // なし
            orderBy = "ORDER BY (CASE WHEN " + prefix + ".ISP_KBN IS NULL OR " + prefix + ".ISP_KBN = '1' THEN '0' ELSE " + prefix + ".ISP_KBN END) ";
        }

        // 第三ソートキー（売上月もしくは受注月）
        orderBy = orderBy + " , " + prefix + ".KAISYU_END, " + prefix + ".ANKEN_ID ";
        // 第四ソートキー（通貨コード）
        orderBy = orderBy + " , " + "DISP_SEQ_NOW NULLS LAST ";
        return orderBy;
    }

    /**
     * 原案データの履歴ID取得
     */
    private List<Integer> getGenanRirekiIdList() {
        List<Integer> rirekiIdList = new ArrayList<>();
        //rirekiIdList.add(0);
        rirekiIdList.add(Integer.parseInt(ConstantString.geRirekiId));
        rirekiIdList.add(Integer.parseInt(ConstantString.teishutsuRirekiId));
        return rirekiIdList;
    }

    /**
     * SQL文を実行(月次確定画面からの出力)
     */
    private List<Map<String, Object>> findAnkenListKakutei() throws Exception {
        SqlFile sqlFile = new SqlFile();
        //String rirekiFlg = "";

        // 履歴ID(今回データ)
        //    検索条件:データ種別=[原案]時は0を指定。[原案]以外はSYU_WF_CONTROL_TBLから対象の履歴IDを取得して指定する。
        List<Object> nowRirekiIdList = new ArrayList<>();
        // 履歴ID(前回データ)
        //    検索条件:データ種別=[原案]時は1を指定。[原案]以外はSYU_WF_CONTROL_TBLから前回分の履歴IDを取得して指定する。
        List<Object> beforeRirekiIdList = new ArrayList<>();

        // 原案テーブルを検索する履歴ID(原案データ)
        Integer geNowRirekiId = null;
        // 原案テーブルを検索する履歴ID(提出用データ)
        Integer teishutsuRirekiId = null;

        // (未確定)本社チームコード(月次確定画面から出力する場合のみ使用される)
        List<String> honsyaTeamCodeList = new ArrayList<>();
        // (未確定済)支社チームコード(月次確定画面から出力する場合のみ使用される)
        List<String> shisyaTeamCodeList = new ArrayList<>();
        // 原案テーブルから検索するか？
        int genanSearchFlg = 0;

        // (確定済)本社チームコード(月次確定画面から出力する場合のみ使用される)
        List<String> kakuteiHonsyaTeamCodeList = new ArrayList<>();
        // (確定済)支社チームコード(月次確定画面から出力する場合のみ使用される)
        List<String> kakuteiShisyaTeamCodeList = new ArrayList<>();

        // (提出用)本社チームコード(月次確定画面から出力する場合のみ使用される)
        List<String> teishutsuHonsyaTeamCodeList = new ArrayList<>();
        // (提出用)支社チームコード(月次確定画面から出力する場合のみ使用される)
        List<String> teishutsuShisyaTeamCodeList = new ArrayList<>();

        // 作成中+提出用の本社チームコード
        List<String> geHonsyaTeamCode = new ArrayList<>();

        // 履歴テーブルから検索するか？
        int rirekiSearchFlg = 0;

        ////// 確定、未確定それぞれの本社、支社チームコード、確定済の履歴IDを取得
        this.findTeamInfoList(honsyaTeamCodeList, shisyaTeamCodeList, teishutsuHonsyaTeamCodeList, teishutsuShisyaTeamCodeList, kakuteiHonsyaTeamCodeList, kakuteiShisyaTeamCodeList, nowRirekiIdList);
        if (honsyaTeamCodeList.size() > 0 || shisyaTeamCodeList.size() > 0 || teishutsuHonsyaTeamCodeList.size() > 0 || teishutsuShisyaTeamCodeList.size() > 0) {
            genanSearchFlg = 1;
        }
        if (kakuteiHonsyaTeamCodeList.size() > 0 || kakuteiShisyaTeamCodeList.size() > 0) {
            rirekiSearchFlg = 1;
        }

        // 月次確定画面で、[前期]検索中の場合
        if ("1".equals(s014Bean.getBeforKiFlg())) {
            // 本社チームコード、支社チームコードは確定/提出/未確定関わらず1まとめにする。
            honsyaTeamCodeList.addAll(kakuteiHonsyaTeamCodeList);
            honsyaTeamCodeList.addAll(teishutsuHonsyaTeamCodeList);
            shisyaTeamCodeList.addAll(kakuteiShisyaTeamCodeList);
            shisyaTeamCodeList.addAll(teishutsuShisyaTeamCodeList);

            // (提出用)チームコードをクリア
            teishutsuHonsyaTeamCodeList = new ArrayList();
            teishutsuShisyaTeamCodeList = new ArrayList();
            // (確定用)チームコードをクリア
            kakuteiHonsyaTeamCodeList = new ArrayList();
            kakuteiShisyaTeamCodeList = new ArrayList();

            // 原案テーブルのみ参照/履歴テーブルは参照しない 設定にする。
            genanSearchFlg = 1;
            rirekiSearchFlg = 0;
        }

        if (honsyaTeamCodeList.size() > 0 || shisyaTeamCodeList.size() > 0) {
            geNowRirekiId = Integer.parseInt(ConstantString.geRirekiId);
        }
        if (teishutsuHonsyaTeamCodeList.size() > 0 || teishutsuShisyaTeamCodeList.size() > 0) {
            teishutsuRirekiId = Integer.parseInt(ConstantString.teishutsuRirekiId);
        }

        // 原案テーブル検索用の本社・支社チームコードをまとめる
        geHonsyaTeamCode.addAll(honsyaTeamCodeList);
        geHonsyaTeamCode.addAll(teishutsuHonsyaTeamCodeList);

        logger.info("[findAnkenListKakutei] nowRirekiId=[{}] beforeRirekiId=[{}]", nowRirekiIdList, beforeRirekiIdList);
        logger.info("[findAnkenListKakutei] honsyaTeamCodeList=[{}] shisyaTeamCodeList=[{}]", honsyaTeamCodeList, shisyaTeamCodeList);
        logger.info("[findAnkenListKakutei] teishutsuHonsyaTeamCodeList=[{}] teishutsuShisyaTeamCodeList=[{}]", teishutsuHonsyaTeamCodeList, teishutsuShisyaTeamCodeList);
        logger.info("[findAnkenListKakutei] kakuteiHonsyaTeamCodeList=[{}] kakuteiShisyaTeamCodeList=[{}]", kakuteiHonsyaTeamCodeList, kakuteiShisyaTeamCodeList);
        logger.info("[findAnkenListKakutei] genanSearchFlg=[{}], rirekiSearchFlg=[{}]", genanSearchFlg, rirekiSearchFlg);
        logger.info("[findAnkenListKakutei] geNowRirekiId=[{}], teishutsuRirekiId=[{}]", geNowRirekiId, teishutsuRirekiId);

        ///////////////////////////////////////////////////////
        ////////////// SELECT句、FROM句作成(S) /////////////////
        ///////////////////////////////////////////////////////
        String splFilePath;
        String sqlFileRirekiPath;
        // 「出力時オプション選択」ダイアログ [展開]で、"回収"を選択
        splFilePath = "/sql/download/ankenListKaisyu.sql";
        sqlFileRirekiPath = "/sql/download/ankenListKaisyuRireki.sql";
        String splWhereFilePath = "/sql/selectListSyuueki.sql";

        logger.info("[findAnkenList] SQL_FILE=[{}] SQL_RIREKI_FILE=[{}]", splFilePath, sqlFileRirekiPath);

        ///////////////////////////////////////////
        // 原案テーブルを検索する場合
        ///////////////////////////////////////////
        String genanSelect = "";
        Object[] genanSelectFromParam = null;
        String genanWhere = "";
        Object[] genanWhereParam = null;
        if (genanSearchFlg == 1) {
            Map<String, Object> selectFromCondition = this.getBaseAnkenListCondition();

            if (geNowRirekiId == null && teishutsuRirekiId == null) {
                geNowRirekiId = Integer.parseInt(ConstantString.geRirekiId);
            }

            selectFromCondition.put("geNowRirekiId", geNowRirekiId);
            selectFromCondition.put("teishutsuRirekiId", teishutsuRirekiId);

            // 本社営業の案件のみ検索する場合、支社営業用案件は除外するように条件設定する
            // ※電力ジやNEPJは支社→本社の2段階WFは利用しないので、本社案件検索時に支社案件が検索対象に含まれないようにするための措置
            int honsyaTeamCodeCount = honsyaTeamCodeList.size() + teishutsuHonsyaTeamCodeList.size() + kakuteiHonsyaTeamCodeList.size();
            int shisyaTeamCodeCoount = shisyaTeamCodeList.size() + teishutsuShisyaTeamCodeList.size() + kakuteiShisyaTeamCodeList.size();
            String honsyaOnlyFlg = "0";
            if (honsyaTeamCodeCount > 0 && shisyaTeamCodeCoount == 0) {
                honsyaOnlyFlg = "1";
            }
            selectFromCondition.put("honsyaOnlyFlg", honsyaOnlyFlg);
            logger.info("[findAnkenListKakutei] honsyaOnlyFlg=[{}]", honsyaOnlyFlg);

            // 事業部コード:(原子力)であるかを判断(原子力とそれ以外の事業部で検索条件を可変にする)
            String divisionNuclearFlg = "0";
            boolean isNuclearDivision = divisionComponentPage.isNuclearDivision(s014Bean.getDivisionCode());
            if (isNuclearDivision) {
                divisionNuclearFlg = "1";
            }
            selectFromCondition.put("divisionNuclearFlg", divisionNuclearFlg);

            // (未確定)本社チームコード
            if (CollectionUtils.isEmpty(honsyaTeamCodeList)) {
                honsyaTeamCodeList.add("@@@@@@");
            }
            selectFromCondition.put("honsyaTeamCode", honsyaTeamCodeList);
            // (未確定)支社チームコード
            if (CollectionUtils.isEmpty(shisyaTeamCodeList)) {
                shisyaTeamCodeList.add("@@@@@@");
            }
            selectFromCondition.put("shisyaTeamCode", shisyaTeamCodeList);
            // (提出用)本社チームコード
            if (CollectionUtils.isEmpty(teishutsuHonsyaTeamCodeList)) {
                teishutsuHonsyaTeamCodeList.add("@@@@@@");
            }
            selectFromCondition.put("teishutsuHonsyaTeamCode", teishutsuHonsyaTeamCodeList);
            // (提出用)支社チームコード
            if (CollectionUtils.isEmpty(teishutsuShisyaTeamCodeList)) {
                teishutsuShisyaTeamCodeList.add("@@@@@@");
            }
            selectFromCondition.put("teishutsuShisyaTeamCode", teishutsuShisyaTeamCodeList);
            // (確定済)本社チームコード
            if (CollectionUtils.isEmpty(kakuteiHonsyaTeamCodeList)) {
                kakuteiHonsyaTeamCodeList.add("@@@@@@");
            }
            selectFromCondition.put("kakuteiHonsyaTeamCode", kakuteiHonsyaTeamCodeList);
            // (確定済)支社チームコード
            if (CollectionUtils.isEmpty(kakuteiShisyaTeamCodeList)) {
                kakuteiShisyaTeamCodeList.add("@@@@@@");
            }
            selectFromCondition.put("kakuteiShisyaTeamCode", kakuteiShisyaTeamCodeList);
            // (作成中＋提出用)本社チームコード
            if (CollectionUtils.isEmpty(geHonsyaTeamCode)) {
                geHonsyaTeamCode.add("@@@@@@");
            }
            selectFromCondition.put("geHonsyaTeamCode", geHonsyaTeamCode);

            selectFromCondition.put("gaikaFlg", "1");
            // SELECT+FROM句まで作成
            genanSelect = sqlFile.getSqlString(splFilePath, selectFromCondition);
            // SELECT+FROM句までのパラメータ
            genanSelectFromParam = sqlFile.getSqlParams(splFilePath, selectFromCondition);

            // WHERE句とWHERE句に指定するパラメータを取得
            // (selectListSyuueki.sqlからWHERE句と、そこに指定するパラメータのみ取得)
            // WHERE句に指定するパラメータを取得
            Map<String, Object> conditionWhere = this.getWfControlCondition();
            conditionWhere.put("whereOnlyFlg", "1");      // WHERE句のみ抜き出すFLG(SQL文内でこの条件でWHERE句のみ取得できるようにした)
            conditionWhere.put("rirekiFlg", "");
            conditionWhere.put("rirekiId", this.getGenanRirekiIdList());
            conditionWhere.put("syuekiControlKbn", "1");
            genanWhere = sqlFile.getSqlString(splWhereFilePath, conditionWhere);
            genanWhereParam = sqlFile.getSqlParams(splWhereFilePath, conditionWhere);

            genanSelect = genanSelect + " " + genanWhere;
        }

        ///////////////////////////////////////////
        // 履歴テーブルを検索する場合
        ///////////////////////////////////////////
        String rirekiSelect = "";
        Object[] rirekiSelectFromParam = null;
        String rirekiWhere = "";
        Object[] rirekiWhereParam = null;
        if (rirekiSearchFlg == 1) {
            Map<String, Object> selectFromCondition = this.getBaseAnkenListCondition();

            selectFromCondition.put("rirekiId", nowRirekiIdList);

            // 本社チームコード
            if (CollectionUtils.isEmpty(kakuteiHonsyaTeamCodeList)) {
                kakuteiHonsyaTeamCodeList.add("@@@@@@");
            }
            selectFromCondition.put("honsyaTeamCode", kakuteiHonsyaTeamCodeList);

            // 支社チームコード
            if (CollectionUtils.isEmpty(kakuteiShisyaTeamCodeList)) {
                kakuteiShisyaTeamCodeList.add("@@@@@@");
            }
            selectFromCondition.put("shisyaTeamCode", kakuteiShisyaTeamCodeList);

            selectFromCondition.put("nowRirekiId", this.getRirekiIdString(nowRirekiIdList));

            // 前回履歴ID
            beforeRirekiIdList = this.getWfBeforeRirekiIdList();
            if (CollectionUtils.isEmpty(beforeRirekiIdList)) {
                // 履歴IDが見つからない場合は、実際にはありえない履歴IDを指定(SQLで落ちないようにするための対策)
                beforeRirekiIdList.add(-1);
            }
            selectFromCondition.put("beforeRirekiId", this.getRirekiIdString(beforeRirekiIdList));

            selectFromCondition.put("gaikaFlg", "1");
            // SELECT+FROM句まで作成
            rirekiSelect = sqlFile.getSqlString(sqlFileRirekiPath, selectFromCondition);
            // SELECT+FROM句までのパラメータ
            rirekiSelectFromParam = sqlFile.getSqlParams(sqlFileRirekiPath, selectFromCondition);

            // WHERE句とWHERE句に指定するパラメータを取得
            // (selectListSyuueki.sqlからWHERE句と、そこに指定するパラメータのみ取得)
            // WHERE句に指定するパラメータを取得
            Map<String, Object> conditionWhere = this.getWfControlCondition();
            conditionWhere.put("whereOnlyFlg", "1");      // WHERE句のみ抜き出すFLG(SQL文内でこの条件でWHERE句のみ取得できるようにした)
            conditionWhere.put("rirekiFlg", "R");
            conditionWhere.put("rirekiId", nowRirekiIdList);
            conditionWhere.put("syuekiControlKbn", "1");
            rirekiWhere = sqlFile.getSqlString(splWhereFilePath, conditionWhere);
            rirekiWhereParam = sqlFile.getSqlParams(splWhereFilePath, conditionWhere);

            rirekiSelect = rirekiSelect + " " + rirekiWhere;
        }

        ////////////// ORDER BY句を取得(S) ////////////////////
        String orderBy = this.getAnkenListOrderBy("A");
        ////////////// ORDER BY句を取得(E) ////////////////////

        ////////////// 実行するSELECT文を作成(S) ////////////////////
        String executeSql = "SELECT A.* FROM ( #genanSelect# #UNIONALL# #rirekiSelect# ) A #ORDERBY#";
        int selectCount = 0;
        // 実行SQLを作成(原案)
        String changeGenanSelect = "";
        if (StringUtils.isNotEmpty(genanSelect)) {
            changeGenanSelect = genanSelect;
            selectCount++;
        }
        executeSql = StringUtils.replace(executeSql, "#genanSelect#", changeGenanSelect);
        // 実行SQLを作成(履歴)
        String changeRirekiSelect = "";
        if (StringUtils.isNotEmpty(rirekiSelect)) {
            changeRirekiSelect = rirekiSelect;
            selectCount++;
        }
        executeSql = StringUtils.replace(executeSql, "#rirekiSelect#", changeRirekiSelect);
        // 原案と履歴を両方検索する場合、UNION ALLする
        String changeUnionAll = "";
        if (selectCount == 2) {
            changeUnionAll = "UNION ALL";
            executeSql = StringUtils.replace(executeSql, "#UNIONALL#", "UNION ALL");
        }
        executeSql = StringUtils.replace(executeSql, "#UNIONALL#", changeUnionAll);
        // ORDER BY句を付加
        executeSql = StringUtils.replace(executeSql, "#ORDERBY#", orderBy);
        ////////////// 実行するSELECT文を作成(E) ////////////////////

        /////////////////////////////
        ///// 実行SQL作成(S) ////////
        /////////////////////////////
        // 実行するSQL文のパラメータを作成(SELECT+FROM句と、WHERE句のパラメータを統合する)
        List<Object> executeSqlParamsList = new ArrayList<>();
        if (genanSelectFromParam != null) {
            executeSqlParamsList.addAll(Arrays.asList(genanSelectFromParam));
        }
        if (genanWhereParam != null) {
            executeSqlParamsList.addAll(Arrays.asList(genanWhereParam));
        }
        if (rirekiSelectFromParam != null) {
            executeSqlParamsList.addAll(Arrays.asList(rirekiSelectFromParam));
        }
        if (rirekiWhereParam != null) {
            executeSqlParamsList.addAll(Arrays.asList(rirekiWhereParam));
        }

        Object[] executeSqlParams = (Object[])executeSqlParamsList.toArray(new Object[executeSqlParamsList.size()]);

        // SQLを実行(Commons DbUtilで実行)
        List<Map<String, Object>> list = dbUtilsExecutor.dbUtilsGetSqlList(em, executeSql, executeSqlParams);
        return list;
    }


    /**
     * SQL文を実行(受注売上見込一覧)
     */
    private List<Map<String, Object>> findAnkenList() throws Exception {
        SqlFile sqlFile = new SqlFile();

        //int monthryKakuteiFlg = this.monthyKakuteiFlg();
        String rirekiFlg = "";

        Integer geNowRirekiId = new Integer(ConstantString.geRirekiId);   // 原案テーブルを参照する履歴ID

        // 履歴ID(今回データ)
        //    検索条件:データ種別=[原案]時は0を指定。[原案]以外はSYU_WF_CONTROL_TBLから対象の履歴IDを取得して指定する。
        List<Object> nowRirekiIdList = null;
        // 履歴ID(前回データ)
        //    検索条件:データ種別=[原案]時は1を指定。[原案]以外はSYU_WF_CONTROL_TBLから前回分の履歴IDを取得して指定する。
        List<Object> beforeRirekiIdList = new ArrayList<>();

        rirekiFlg = s001Bean.getRirekiFlg();
        if ("R".equals(rirekiFlg)) {
            // 今回履歴IDを取得
            Map<String, Object> s001Condtion = s001Service.getCondition();
            nowRirekiIdList = new ArrayList<Object>(Arrays.asList(syuWfControlTblFacade.findRirekiId(s001Condtion).split(",")));

            // 前回履歴IDを取得
            String beforeRerekiIds = s001Service.getOldRirekiID(s001Condtion);
            if (StringUtils.isNotEmpty(beforeRerekiIds)) {
                beforeRirekiIdList = new ArrayList<Object>(Arrays.asList(beforeRerekiIds.split(",")));
            }
            if (CollectionUtils.isEmpty(beforeRirekiIdList)) {
                beforeRirekiIdList.add(-1);
            }

        } else {
            // 原案テーブルを参照する場合は今回履歴ID=0、前回履歴ID=1にする。
            nowRirekiIdList = new ArrayList<>();
            nowRirekiIdList.add(new Integer(ConstantString.geRirekiId));

            beforeRirekiIdList = new ArrayList<>();
            beforeRirekiIdList.add(new Integer(ConstantString.teishutsuRirekiId));

        }

        logger.info("[findAnkenList] nowRirekiId=[{}] beforeRirekiId=[{}]", nowRirekiIdList, beforeRirekiIdList);

        // 半期年月を取得
        //String[] kikanMonthAry = SyuuekiUtils.getKikanMonthAry(s001Bean.getTaishoY() + s001Bean.getTaishoKi());

        ///////////////////////////////////////////////////////////////
        ////////////// SELECT句、FROM句作成(S) /////////////////
        ///////////////////////////////////////////////////////////////
        String splFilePath = "";
        // 「出力時オプション選択」ダイアログ [展開]で、"回収"を選択
        if ("R".equals(rirekiFlg)) {
            // 月次確定/予算ベースのデータを出力
            splFilePath = "/sql/download/ankenListKaisyuRireki.sql";
        } else {
            // "原案"のデータを取得
            splFilePath = "/sql/download/ankenListKaisyu.sql";
        }

        logger.info("[findAnkenList] SQL_FILE=[{}]", splFilePath);

        // SELECT句、FROM句のパラメータを設定
        //Map<String, Object> selectFromCondition = new HashMap<>();

        Map<String, Object> selectFromCondition = this.getBaseAnkenListCondition();

        selectFromCondition.put("geNowRirekiId", geNowRirekiId);
        selectFromCondition.put("rirekiFlg", rirekiFlg);
        selectFromCondition.put("rirekiId", nowRirekiIdList);
//        selectFromCondition.put("monthyKakuteiFlg", String.valueOf(monthryKakuteiFlg));
        selectFromCondition.put("nowRirekiId", this.getRirekiIdString(nowRirekiIdList));
        selectFromCondition.put("beforeRirekiId", this.getRirekiIdString(beforeRirekiIdList));
        selectFromCondition.put("gaikaFlg", "1");

        // SELECT+FROM句まで作成
        String sqlSelectFrom = sqlFile.getSqlString(splFilePath, selectFromCondition);
        // SELECT+FROM句までのパラメータ
        Object[] params = sqlFile.getSqlParams(splFilePath, selectFromCondition);
        ///////////////////////////////////////////////////////////////
        ////////////// SELECT句、FROM句作成(E) /////////////////
        ///////////////////////////////////////////////////////////////


        //////////////////////////////////////////////////////////////
        ////////////// WHERE句作成(S) ///////////////////////////
        //////////////////////////////////////////////////////////////
        // WHERE句とWHERE句に指定するパラメータを取得
        // (selectListSyuueki.sqlからWHERE句と、そこに指定するパラメータのみ取得)
        splFilePath = "/sql/selectListSyuueki.sql";
        // WHERE句に指定するパラメータを取得
        Map<String, Object> conditionWhere = s001Service.getCondition();
        conditionWhere.put("whereOnlyFlg", "1");      // WHERE句のみ抜き出すFLG(SQL文内でこの条件でWHERE句のみ取得できるようにした)
        conditionWhere.put("rirekiFlg", rirekiFlg);
        conditionWhere.put("rirekiId", nowRirekiIdList);
        conditionWhere.put("syuekiControlKbn", "1");

        String whereString = sqlFile.getSqlString(splFilePath, conditionWhere);
        Object[] whereParams = sqlFile.getSqlParams(splFilePath, conditionWhere);
        ///////////////////////////////////////////////////////
        ////////////// WHERE句作成(E) /////////////////////////
        ///////////////////////////////////////////////////////


        ////////////// ORDER BY句を取得(S) ////////////////////
        String orderBy = this.getAnkenListOrderBy("A");
        ////////////// ORDER BY句を取得(E) ////////////////////


        // 実行するSQL文を取得
        String executeSql = sqlSelectFrom + " " + whereString + " "  + orderBy;

        // 実行するSQL文のパラメータを作成(SELECT+FROM句と、WHERE句のパラメータを統合する)
        List<Object> executeSqlParamsList = Arrays.asList(params);
        executeSqlParamsList = new ArrayList<>(executeSqlParamsList);
        executeSqlParamsList.addAll(Arrays.asList(whereParams));
        Object[] executeSqlParams = (Object[])executeSqlParamsList.toArray(new Object[executeSqlParamsList.size()]);

        // SQLを実行(Commons DbUtilで実行)
        List<Map<String, Object>> list = dbUtilsExecutor.dbUtilsGetSqlList(em, executeSql, executeSqlParams);
        return list;
    }

    /**
     * 履歴idをカンマ区切りの文字列に変換
     */
    private String getRirekiIdString(List<Object> rirekiIdList) {
        if (rirekiIdList == null || rirekiIdList.isEmpty()) {
            return null;
        }

        boolean isFirst = true;
        StringBuilder rirekiIdString = new StringBuilder();
        for (Object rirekiId : rirekiIdList) {
            if (!isFirst) {
                rirekiIdString.append(",");
            }
            rirekiIdString.append(String.valueOf(rirekiId));
            isFirst = false;
        }

        return String.valueOf(rirekiIdString);
    }

    /**
     * 中計行出力
     */
    private void outMidSumLine(Workbook workbook, int rowNum, String baseKeyStr, List<BigDecimal> cyukeiList, List<BigDecimal> cyukeiYosanList, String jpyUnitKbn, List<Integer> chukeiRowIndexList) {
        Sheet sheet = workbook.getSheet(SHEETNAME);
        Sheet sheetStyle = workbook.getSheet(STYLESHEETNAME);
        // 中計行のスタイルを取得
        Row row = PoiUtil.getRow(sheetStyle, MID_SUM_STYLE_ROW_INDEX, true);
        List<Cell> cellList = PoiUtil.getCellList(row);

        // 計算式にするか？
        boolean summaryCalcKbn = this.isSummaryCalc();

        row = PoiUtil.getRow(sheet, rowNum, true);
        PoiUtil.copyRowStyleValue(row, cellList, summaryCalcKbn);

        int cellNm = FIRST_MONTH_SP_BEFORE;

        sheet.addMergedRegion(new CellRangeAddress(rowNum, rowNum, 0, 4));
        PoiUtil.setCellValue(sheet, rowNum, 0, baseKeyStr + " 計");

        // 予算ベースを出力(S)
        PoiUtil.setCellValue(sheet, rowNum, cellNm - 4, syuuekiUtils.changeUnit(cyukeiYosanList.get(0), jpyUnitKbn));
        PoiUtil.setCellValue(sheet, rowNum, cellNm - 3, syuuekiUtils.changeUnit(cyukeiYosanList.get(1), jpyUnitKbn));
        if (summaryCalcKbn) {   // 計算式にする場合
            PoiUtil.setCellFormula(sheet, rowNum, cellNm - 4, this.getExcelPlusRowFormula(chukeiRowIndexList, cellNm - 4));
            PoiUtil.setCellFormula(sheet, rowNum, cellNm - 3, this.getExcelPlusRowFormula(chukeiRowIndexList, cellNm - 3));

        } else {   // 計算式にしない場合
//            // 粗利/M率
            PoiUtil.setCellValue(sheet, rowNum, cellNm - 2, syuuekiUtils.changeUnit(syuuekiUtils.arari(cyukeiYosanList.get(0), cyukeiYosanList.get(1)), jpyUnitKbn));
            PoiUtil.setCellValue(sheet, rowNum, cellNm - 1, syuuekiUtils.mrate(cyukeiYosanList.get(0), cyukeiYosanList.get(1)));
        }
        // 予算ベースを出力(E)

        for(int j = 0; j < HALF_YEAR_SP_NET; j = j + 4){
            //PoiUtil.setCellValue(sheet, rowNum, cellNm, syuuekiUtils.changeUnit(cyukeiList.get(j), jpyUnitKbn)); // 2018/08 Del
            PoiUtil.setCellValue(sheet, rowNum, cellNm + 1, syuuekiUtils.changeUnit(cyukeiList.get(j + 1), jpyUnitKbn));
            //PoiUtil.setCellValue(sheet, rowNum, cellNm + 2, syuuekiUtils.changeUnit(cyukeiList.get(j + 2), jpyUnitKbn)); // 2018/08 Del
            PoiUtil.setCellValue(sheet, rowNum, cellNm + 3, syuuekiUtils.changeUnit(cyukeiList.get(j + 3), jpyUnitKbn));
            if (summaryCalcKbn) {   // 計算式にする場合
                PoiUtil.setCellFormula(sheet, rowNum, cellNm);
                //PoiUtil.setCellFormula(sheet, rowNum, cellNm, this.getExcelPlusRowFormula(chukeiRowIndexList, cellNm)); // 2018/08 Del
                PoiUtil.setCellFormula(sheet, rowNum, cellNm + 1, this.getExcelPlusRowFormula(chukeiRowIndexList, cellNm + 1));
                PoiUtil.setCellFormula(sheet, rowNum, cellNm + 2);
                //PoiUtil.setCellFormula(sheet, rowNum, cellNm + 2, this.getExcelPlusRowFormula(chukeiRowIndexList, cellNm + 2)); // 2018/08 Del
                PoiUtil.setCellFormula(sheet, rowNum, cellNm + 3, this.getExcelPlusRowFormula(chukeiRowIndexList, cellNm + 3));

            } else {   // 計算式にしない場合
//                int startCellNum = cellNm + 2;
//                setArariMrateValue(sheet, rowNum, startCellNum, jpyUnitKbn, cyukeiList.get(j), cyukeiList.get(j+1));
            }

            cellNm = cellNm + 4;
        }
    }

    /**
     * ISP小計行出力
     */
    private void outIspSubTotalLine(Workbook workbook, int rowNum, String baseKeyStr, String chukeiKey, List<BigDecimal> syokeiList, List<BigDecimal> syokeiYosanList, String jpyUnitKbn, int ispStartRowIndex, int ispEndRowIndex) {
        Sheet sheet = workbook.getSheet(SHEETNAME);
        Sheet sheetStyle = workbook.getSheet(STYLESHEETNAME);
        // 小計行のスタイルを取得
        Row row = PoiUtil.getRow(sheetStyle, ISP_SUBTOTAL_STYLE_ROW_INDEX, true);
        List<Cell> cellList = PoiUtil.getCellList(row);

        // 計算式にするか？
        boolean summaryCalcKbn = this.isSummaryCalc();

        row = PoiUtil.getRow(sheet, rowNum, true);
        PoiUtil.copyRowStyleValue(row, cellList, summaryCalcKbn);

        String ispName;
        if("2".equals(baseKeyStr)){
            ispName = "【ISP】";
        }else{
            ispName = "【自事業部】";
        }
        int cellNm = FIRST_MONTH_SP_BEFORE;

        sheet.addMergedRegion(new CellRangeAddress(rowNum, rowNum, 0, 4));
        PoiUtil.setCellValue(sheet, rowNum, 0, ispName + chukeiKey + " 計");

        // 予算ベースを出力(S)
        PoiUtil.setCellValue(sheet, rowNum, cellNm - 4, syuuekiUtils.changeUnit(syokeiYosanList.get(0), jpyUnitKbn));
        PoiUtil.setCellValue(sheet, rowNum, cellNm - 3, syuuekiUtils.changeUnit(syokeiYosanList.get(1), jpyUnitKbn));
        if (summaryCalcKbn) {   // 計算式にする場合
            PoiUtil.setCellFormula(sheet, rowNum, cellNm - 4, "SUM(" + PoiUtil.getCellReferenceStr(ispStartRowIndex, cellNm - 4) + ":" + PoiUtil.getCellReferenceStr(ispEndRowIndex, cellNm - 4) + ")");
            PoiUtil.setCellFormula(sheet, rowNum, cellNm - 3, "SUM(" + PoiUtil.getCellReferenceStr(ispStartRowIndex, cellNm - 3) + ":" + PoiUtil.getCellReferenceStr(ispEndRowIndex, cellNm - 3) + ")");

        } else {
            // 計算式にしない場合、直接値を埋め込む
            // 粗利/M率
            PoiUtil.setCellValue(sheet, rowNum, cellNm - 2, syuuekiUtils.changeUnit(syuuekiUtils.arari(syokeiYosanList.get(0), syokeiYosanList.get(1)), jpyUnitKbn));
            PoiUtil.setCellValue(sheet, rowNum, cellNm - 1, syuuekiUtils.mrate(syokeiYosanList.get(0), syokeiYosanList.get(1)));
        }
        // 予算ベースを出力(E)


        for(int j = 0; j < HALF_YEAR_SP_NET; j = j + 4){
            //PoiUtil.setCellValue(sheet, rowNum, cellNm, syuuekiUtils.changeUnit(syokeiList.get(j), jpyUnitKbn)); // 2018/08 Del
            PoiUtil.setCellValue(sheet, rowNum, cellNm + 1, syuuekiUtils.changeUnit(syokeiList.get(j + 1), jpyUnitKbn));
            //PoiUtil.setCellValue(sheet, rowNum, cellNm + 2, syuuekiUtils.changeUnit(syokeiList.get(j + 2), jpyUnitKbn)); // 2018/08 Del
            PoiUtil.setCellValue(sheet, rowNum, cellNm + 3, syuuekiUtils.changeUnit(syokeiList.get(j + 3), jpyUnitKbn));
            if (summaryCalcKbn) {   // 計算式にする場合
                PoiUtil.setCellFormula(sheet, rowNum, cellNm);
                //PoiUtil.setCellFormula(sheet, rowNum, cellNm, "SUM(" + PoiUtil.getCellReferenceStr(ispStartRowIndex, cellNm) + ":" + PoiUtil.getCellReferenceStr(ispEndRowIndex, cellNm) + ")"); // 2018/08 Del
                PoiUtil.setCellFormula(sheet, rowNum, cellNm + 1, "SUM(" + PoiUtil.getCellReferenceStr(ispStartRowIndex, cellNm + 1) + ":" + PoiUtil.getCellReferenceStr(ispEndRowIndex, cellNm + 1) + ")");
                PoiUtil.setCellFormula(sheet, rowNum, cellNm + 2);
                //PoiUtil.setCellFormula(sheet, rowNum, cellNm + 2, "SUM(" + PoiUtil.getCellReferenceStr(ispStartRowIndex, cellNm + 2) + ":" + PoiUtil.getCellReferenceStr(ispEndRowIndex, cellNm + 2) + ")"); // 2018/08 Del
                PoiUtil.setCellFormula(sheet, rowNum, cellNm + 3, "SUM(" + PoiUtil.getCellReferenceStr(ispStartRowIndex, cellNm + 3) + ":" + PoiUtil.getCellReferenceStr(ispEndRowIndex, cellNm + 3) + ")");

            } else {   // 計算式にしない場合、直接値を埋め込む
//                int startCellNum = cellNm + 2;
//                setArariMrateValue(sheet, rowNum, startCellNum, jpyUnitKbn, syokeiList.get(j), syokeiList.get(j+1));
            }

            cellNm = cellNm + 4;
        }
    }

    /**
     * SYU_WF_CONTROL_TBLを参照するための検索条件を取得
     */
    private Map<String, Object> getWfControlCondition() throws Exception {
        Map<String, Object> condition = new HashMap<>();

        String[] divisionCode = new String[1];
        divisionCode[0] = s014Bean.getDivisionCode();
        String[] salesClass = new String[1];
        salesClass[0] = s014Bean.getSalesClass();

        condition.put("divisionCode", divisionCode);
        condition.put("salesClass", salesClass);
        condition.put("kanjyoYm", StringUtils.replace(s014Bean.getKanjyoYm(), "/", ""));
        condition.put("cBukaCode", s014Bean.getcBukaCode());

        return condition;
    }

    /**
     * 対象の(GROUP_CODE)に該当するチームコード一覧データを取得
     * @return チームコードの配列を格納したMap key=H 本社チームコード key=S:支社チームコード
     */
    private List<SyuWfControlTbl> findTeamList() throws Exception {
        Map<String, Object> condition = this.getWfControlCondition();
        condition.put("dispFlg", "0");    // 一般案件の対象チームコードを取得するので、DISP_FLG=0のデータのみを対象とする。
        logger.info("[findTeamList] condition=[{}]", condition);

        List<SyuWfControlTbl> list = syuWfControlTblFacade.findBukaCode(condition);

        return list;
    }

    /**
     * null変換用
     */
    private String nvl( String inValue, String defaultValue ) {
        if ( StringUtils.isEmpty(inValue) ) {
            return defaultValue;
        }
        return inValue;
    }

    /**
     * ListよりExcel計算式(足し算)を取得
     */
    private String getExcelPlusRowFormula(List<Integer> indexRowList, int cellIndex) {
        String formulaString = "";
        for (Integer index: indexRowList) {
            if (StringUtils.isEmpty(formulaString)) {
                formulaString = PoiUtil.getCellReferenceStr(index, cellIndex);
            } else {
                formulaString = formulaString + "," + PoiUtil.getCellReferenceStr(index, cellIndex);
            }
        }

        if (StringUtils.isNotEmpty(formulaString)) {
            formulaString = "SUM(" + formulaString + ")";
        }
        return formulaString;
    }

}
