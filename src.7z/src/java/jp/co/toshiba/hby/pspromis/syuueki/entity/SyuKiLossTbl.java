package jp.co.toshiba.hby.pspromis.syuueki.entity;

import java.io.Serializable;
import java.util.Date;
import java.math.BigDecimal;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;
import javax.persistence.Id;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/**
 *
 * @author ibayashi
 */
@Entity
@Table(name = "SYU_KI_LOSS_TBL")
public class SyuKiLossTbl implements Serializable {

    private static final long serialVersionUID = 1L;

    @Id
    @Column(name = "ANKEN_ID")
    private String ankenId;
    @Id
    @Column(name = "RIREKI_ID")
    private int rirekiId;
    @Id
    @Column(name = "DATA_KBN")
    private String dataKbn;
    @Id
    @Column(name = "SYUEKI_YM")
    private String syuekiYm;
    @Column(name = "LOSS_HOSEI")
    private BigDecimal lossHosei;
    @Column(name = "LOSS_AMOUNT")
    private BigDecimal lossAmount;        
    @Column(name = "LOSS_GENKA")
    private BigDecimal lossGenka;
    @Column(name = "LOSS_HIKIATE")
    private BigDecimal lossHikiate;
    @Column(name = "LOSS_RUIKEI_HIKIATE")
    private BigDecimal lossRuikeiHikiate;
    @Column(name = "CREATED_AT")
    @Temporal(TemporalType.DATE)
    private Date createdAt;
    @Column(name = "CREATED_BY")
    private String createdBy;
    @Column(name = "UPDATED_AT")
    @Temporal(TemporalType.DATE)
    private Date updatedAt;
    @Column(name = "UPDATED_BY")
    private String updatedBy;
    @Column(name = "UPDATED_BATCH_AT")
    @Temporal(TemporalType.DATE)
    private Date updatedBatchAt;
    @Column(name = "UPDATED_BATCH_BY")
    private String updatedBatchBy;

    public SyuKiLossTbl() {
    }

    public String getAnkenId() {
        return ankenId;
    }

    public void setAnkenId(String ankenId) {
        this.ankenId = ankenId;
    }

    public int getRirekiId() {
        return rirekiId;
    }

    public void setRirekiId(int rirekiId) {
        this.rirekiId = rirekiId;
    }

    public String getDataKbn() {
        return dataKbn;
    }

    public void setDataKbn(String dataKbn) {
        this.dataKbn = dataKbn;
    }

    public String getSyuekiYm() {
        return syuekiYm;
    }

    public void setSyuekiYm(String syuekiYm) {
        this.syuekiYm = syuekiYm;
    }

    public BigDecimal getLossHosei() {
        return lossHosei;
    }

    public void setLossHosei(BigDecimal lossHosei) {
        this.lossHosei = lossHosei;
    }

    public BigDecimal getLossAmount() {
        return lossAmount;
    }

    public void setLossAmount(BigDecimal lossAmount) {
        this.lossAmount = lossAmount;
    }
    
    public BigDecimal getLossGenka() {
        return lossGenka;
    }

    public void setLossGenka(BigDecimal lossGenka) {
        this.lossGenka = lossGenka;
    }

    public BigDecimal getLossHikiate() {
        return lossHikiate;
    }

    public void setLossHikiate(BigDecimal lossHikiate) {
        this.lossHikiate = lossHikiate;
    }

    public BigDecimal getLossRuikeiHikiate() {
        return lossRuikeiHikiate;
    }

    public void setLossRuikeiHikiate(BigDecimal lossRuikeiHikiate) {
        this.lossRuikeiHikiate = lossRuikeiHikiate;
    }

    public Date getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(Date createdAt) {
        this.createdAt = createdAt;
    }

    public String getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    public Date getUpdatedAt() {
        return updatedAt;
    }

    public void setUpdatedAt(Date updatedAt) {
        this.updatedAt = updatedAt;
    }

    public String getUpdatedBy() {
        return updatedBy;
    }

    public void setUpdatedBy(String updatedBy) {
        this.updatedBy = updatedBy;
    }

    public Date getUpdatedBatchAt() {
        return updatedBatchAt;
    }

    public void setUpdatedBatchAt(Date updatedBatchAt) {
        this.updatedBatchAt = updatedBatchAt;
    }

    public String getUpdatedBatchBy() {
        return updatedBatchBy;
    }

    public void setUpdatedBatchBy(String updatedBatchBy) {
        this.updatedBatchBy = updatedBatchBy;
    }

}
