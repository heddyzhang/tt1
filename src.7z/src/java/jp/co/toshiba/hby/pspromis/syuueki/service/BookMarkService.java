/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package jp.co.toshiba.hby.pspromis.syuueki.service;

import java.util.Date;
import javax.ejb.Stateless;
import javax.inject.Inject;
import javax.interceptor.Interceptors;
import jp.co.toshiba.hby.pspromis.syuueki.bean.BookMarkBean;
import jp.co.toshiba.hby.pspromis.syuueki.entity.SyuGeBookmarkTbl;
import jp.co.toshiba.hby.pspromis.syuueki.facade.SyuGeBookmarkTblFacade;
import jp.co.toshiba.hby.pspromis.syuueki.interceptor.TranceInterceptor;
import jp.co.toshiba.hby.pspromis.syuueki.util.LoginUserInfo;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * PS-Promis収益管理システム
 * BookMark登録 Service
 * @author (NPC)S.Ibayashi
 */
@Stateless
@Interceptors({TranceInterceptor.class})
public class BookMarkService {

    public static final Logger logger = LoggerFactory.getLogger(BookMarkService.class);
    
    /**
     * Injection BookMarkBean
     */
    @Inject
    private BookMarkBean bookMarkBean;

    /**
     * Injection loginUserInfo
     * (ユーザー情報(ユーザーid,名称,所属部課名)を格納したオブジェクト)
     */
    @Inject
    private LoginUserInfo loginUserInfo;
    
    /**
     * Injection SyuGeBookmarkTblFacade
     */
    @Inject
    private SyuGeBookmarkTblFacade syuGeBookmarkTblFacade;
    
    /**
     * ブックマーク取得処理
     * @throws Exception 
     */
    public void indexExecute() throws Exception {
        Long count = syuGeBookmarkTblFacade.getCount(loginUserInfo.getUserId(), bookMarkBean.getAnkenId());
        
        if (count > 0) {
            bookMarkBean.setBookMarkFlg(1);
        } else {
            bookMarkBean.setBookMarkFlg(0);
        }
    }

    /**
     * ブックマーク更新実行
     * @throws Exception 
     */
    public void updateExecute() throws Exception {
        // BookMark登録FLGを取得
        String insertFlg = StringUtils.defaultString(bookMarkBean.getInsertFlg(), "0");

        // SyuGeBookmarkTblエンティティを作成
        SyuGeBookmarkTbl entity = createSyuGeBookmarkTbl();
        
        if (insertFlg.equals("1")) {
            // BookMark登録
            syuGeBookmarkTblFacade.create(entity);
            bookMarkBean.setBookMarkFlg(1);
        } else {
            // BookMark削除
            syuGeBookmarkTblFacade.remove(entity);
            bookMarkBean.setBookMarkFlg(0);
        }
    }

    /**
     * SyuGeBookmarkTblエンティティを作成
     */
    private SyuGeBookmarkTbl createSyuGeBookmarkTbl() {
        Date now = new Date();

        SyuGeBookmarkTbl entity = new SyuGeBookmarkTbl();
        entity.setAnkenId(bookMarkBean.getAnkenId());
        entity.setIdtuid(loginUserInfo.getUserId());
        entity.setCreatedAt(now);
        entity.setCreatedBy(loginUserInfo.getUserId());
        entity.setUpdatedAt(now);
        entity.setUpdatedBy(loginUserInfo.getUserId());

        return entity;
    }
}
