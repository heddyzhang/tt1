package jp.co.toshiba.hby.pspromis.syuueki.entity;

import java.io.Serializable;
import java.util.Date;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/**
 *
 * @author ibayashi
 */
@Entity
@Table(name = "SYU_SEARCH_PATTERN_TBL")
public class SyuSearchPatternTbl implements Serializable {

    private static final long serialVersionUID = 1L;

    @Id
    @Column(name = "IDTUID")
    private String idtuid;

    @Id
    @Column(name = "DISPLAY_ID")
    private String displayId;

    @Id
    @Column(name = "PATTERN_SEQ")
    private short patternSeq;

    @Column(name = "PATTERN_NAME")
    private String patternName;
    
    @Column(name = "CREATED_AT")
    @Temporal(TemporalType.TIMESTAMP)
    private Date createdAt;

    @Column(name = "CREATED_BY")
    private String createdBy;

    @Column(name = "UPDATED_AT")
    @Temporal(TemporalType.TIMESTAMP)
    private Date updatedAt;

    @Column(name = "UPDATED_BY")
    private String updatedBy;

    public SyuSearchPatternTbl() {
    }

    public String getIdtuid() {
        return idtuid;
    }

    public void setIdtuid(String idtuid) {
        this.idtuid = idtuid;
    }

    public String getDisplayId() {
        return displayId;
    }

    public void setDisplayId(String displayId) {
        this.displayId = displayId;
    }

    public short getPatternSeq() {
        return patternSeq;
    }

    public void setPatternSeq(short patternSeq) {
        this.patternSeq = patternSeq;
    }

    public String getPatternName() {
        return patternName;
    }

    public void setPatternName(String patternName) {
        this.patternName = patternName;
    }

    public Date getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(Date createdAt) {
        this.createdAt = createdAt;
    }

    public String getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    public Date getUpdatedAt() {
        return updatedAt;
    }

    public void setUpdatedAt(Date updatedAt) {
        this.updatedAt = updatedAt;
    }

    public String getUpdatedBy() {
        return updatedBy;
    }

    public void setUpdatedBy(String updatedBy) {
        this.updatedBy = updatedBy;
    }
    
}
