package jp.co.toshiba.hby.pspromis.syuueki.facade;

import java.math.BigInteger;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.ejb.Stateless;
import javax.interceptor.Interceptors;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import jp.co.toshiba.hby.pspromis.syuueki.entity.StringEntity;
import jp.co.toshiba.hby.pspromis.syuueki.entity.SyuAttachTbl;
import jp.co.toshiba.hby.pspromis.syuueki.interceptor.TranceInterceptor;
import org.apache.commons.collections.CollectionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 *
 * @author 
 */
@Stateless
@Interceptors({TranceInterceptor.class})
public class SyuAttachTblFacade extends AbstractFacade<SyuAttachTbl> {

    private static final Logger logger = LoggerFactory.getLogger(SyuAttachTblFacade.class);
    
    @PersistenceContext(unitName = jp.co.toshiba.hby.pspromis.syuueki.util.ConstantString.syuuekiDataSourceName)
    private EntityManager em;

    @Override
    protected EntityManager getEntityManager() {
        return em;
    }

    public SyuAttachTblFacade() {
        super(SyuAttachTbl.class);
    }

    /**
     * 添付情報一覧の取得
     * @param condition
     * @return 
     */
    public List<SyuAttachTbl> findAttachList(Map<String, Object> condition) {
        List<SyuAttachTbl> list =
                sqlExecutor.getResultList(em, SyuAttachTbl.class, "/sql/syuAttachTbl/selectAttachInfo.sql", condition);

        return list;
    }

    /**
     * 指定物件Key、履歴Id、seqの添付情報一覧を取得
     * @param ankenId
     * @param rirekiId
     * @param seq
     * @param rirekiFlg "R"の場合、履歴テーブル(Rテーブル)を参照
     * @return 
     */
    public SyuAttachTbl findAttachInfo(String ankenId, String rirekiId, String seq, String rirekiFlg) {
        Map<String, Object> condition = new HashMap<>();
        condition.put("ankenId", ankenId);
        condition.put("rirekiId", (new Integer(rirekiId)));
        condition.put("seq", (new Integer(seq)));
        condition.put("rirekiFlg", rirekiFlg);
        
        List<SyuAttachTbl> list = findAttachList(condition);
        SyuAttachTbl entity = null;
        if (CollectionUtils.isNotEmpty(list)) {
            entity = list.get(0);
        }
        
        return entity;
    }

    /**
     * 指定物件Key、履歴Id、seqの添付情報一覧を取得(履歴テーブルは検索しない)
     * @param ankenId
     * @param rirekiId
     * @param seq
     * @return 
     */
    public SyuAttachTbl findAttachInfo(String ankenId, String rirekiId, String seq) {
        return findAttachInfo(ankenId, rirekiId, seq, "");
    }

    /**
     * 指定物件Key、履歴Idの添付情報一覧を取得
     * @param ankenId
     * @param rirekiId
     * @param rirekiFlg
     * @return 
     */
    public List<SyuAttachTbl> findAttachList(String ankenId, String rirekiId, String rirekiFlg) {
        Map<String, Object> condition = new HashMap<>();
        condition.put("ankenId", ankenId);
        condition.put("rirekiId", (new Integer(rirekiId)));
        condition.put("rirekiFlg", rirekiFlg);

        return findAttachList(condition);
    }

    /**
     * 指定物件Key、履歴Idの最新登録ファイルSEQを取得
     * @param ankenId
     * @param rirekiId
     * @return 
     */
    public String getNewSeq(String ankenId, String rirekiId) {
        Map<String, Object> condition = new HashMap<>();
        condition.put("ankenId", ankenId);
        condition.put("rirekiId", (new Integer(rirekiId)));
        
        List<StringEntity> list =
                sqlExecutor.getResultList(em, StringEntity.class, "/sql/syuAttachTbl/getNewSeq.sql", condition);
        
        String newSeq = "1";
        StringEntity entity = null;
        if (CollectionUtils.isNotEmpty(list)) {
            entity = list.get(0);
            newSeq = entity.getString();
        }
        
        return newSeq;
    }

    /**
     * 登録処理
     * @param entity
     * @return 
     */
    public int insertAttach(SyuAttachTbl entity) {
        return sqlExecutor.executeUpdateSql(em, "/sql/syuAttachTbl/insertAttach.sql", entity);
    }

    /**
     * 更新処理
     * @param entity
     * @return 
     */
    public int updateAttach(SyuAttachTbl entity) {
        return sqlExecutor.executeUpdateSql(em, "/sql/syuAttachTbl/updateAttach.sql", entity);
    }

    /**
     * 削除処理
     * @param ankenId
     * @param rirekiId
     * @param seq
     * @return 
     */
    public int deleteAttach(String ankenId, String rirekiId, String seq) {
        Map<String, Object> condition = new HashMap<>();
        condition.put("ankenId", ankenId);
        condition.put("rirekiId", (new Integer(rirekiId)));
        condition.put("seq", (new BigInteger(seq)));
        
        return sqlExecutor.executeUpdateSql(em, "/sql/syuAttachTbl/deleteAttach.sql", condition);
    }

    /**
     * 指定seqの履歴データの作成件数を取得
     * @param ankenId
     * @param rirekiId
     * @param seq
     * @return 
     */
    public int getRirekiCount(String ankenId, String rirekiId, String seq) {
        Map<String, Object> condition = new HashMap<>();
        condition.put("ankenId", ankenId);
        condition.put("rirekiId", (new Integer(rirekiId)));
        condition.put("seq", (new BigInteger(seq)));
        
        return sqlExecutor.getCount(em, "/sql/syuAttachTbl/countRirekiAttachSeq.sql", condition);
    }

}
