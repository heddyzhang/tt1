/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package jp.co.toshiba.hby.pspromis.syuueki.facade;

import java.util.Map;
import javax.ejb.Stateless;
import javax.interceptor.Interceptors;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import jp.co.toshiba.hby.pspromis.common.entity.CountEntity;
import jp.co.toshiba.hby.pspromis.syuueki.entity.SyuKiSpTukiSTbl;
import jp.co.toshiba.hby.pspromis.syuueki.interceptor.TranceInterceptor;

/**
 *
 * @author kitajima
 */
@Stateless
@Interceptors({TranceInterceptor.class})
public class SyuKiSpTukiSTblFacade  extends AbstractFacade<SyuKiSpTukiSTbl> {
    @PersistenceContext(unitName = jp.co.toshiba.hby.pspromis.syuueki.util.ConstantString.syuuekiDataSourceName)
    private EntityManager em;

    @Override
    protected EntityManager getEntityManager() {
        return em;
    }

    public SyuKiSpTukiSTblFacade() {
        super(SyuKiSpTukiSTbl.class);
    }

    public SyuKiSpTukiSTbl getPkInfo(String ankenId, Integer rirekiId, String dataKbn, String syuekiYm, String currencyCode) {
        Query q = em.createNamedQuery("KiSpTukiSTbl.findPk", SyuKiSpTukiSTbl.class);
        
        q.setParameter("ankenId", ankenId);
        q.setParameter("rirekiId", rirekiId);
        q.setParameter("dataKbn", dataKbn);
        q.setParameter("syuekiYm", syuekiYm);
        q.setParameter("currencyCode", currencyCode);

        SyuKiSpTukiSTbl en;
        
        try {
            en = (SyuKiSpTukiSTbl)q.getSingleResult();
        } catch(javax.persistence.NoResultException e){
            // 指定PKのデータが存在しない場合
            en = null;
        }

        return en;
    }

    /**
     * 期間損益・月別詳細(進行・原価) 削除
     * @param _params
     * @return 
     */
    public int deleteSyuKiSpTukiSTbl(Map<String, Object> _params) {
        int count= sqlExecutor.executeUpdateSql(em, "/sql/syuKiSpTukiSTbl/deleteSyuKiSpTukiSTbl.sql", _params);
        return count;
    }
    
    public Integer getSyuKiSpTukiSTblCount(Object condition) throws Exception {
        CountEntity syuKiSpTukiSTbl = sqlExecutor.getSingleResult(em, CountEntity.class, "/sql/syuKiSpTukiSTbl/selectSyuKiSpTukiSTbl.sql", condition);
        return syuKiSpTukiSTbl.getCount();
    }
    
}
