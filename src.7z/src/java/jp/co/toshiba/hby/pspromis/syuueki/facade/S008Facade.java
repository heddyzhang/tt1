package jp.co.toshiba.hby.pspromis.syuueki.facade;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.ejb.Stateless;
import javax.inject.Inject;
import javax.interceptor.Interceptors;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import jp.co.toshiba.hby.pspromis.syuueki.entity.SyuGeBukkenInfoTbl;
import jp.co.toshiba.hby.pspromis.common.entity.CountEntity;
import jp.co.toshiba.hby.pspromis.syuueki.bean.S008Bean;
import jp.co.toshiba.hby.pspromis.syuueki.entity.StringEntity;
import jp.co.toshiba.hby.pspromis.syuueki.interceptor.TranceInterceptor;
import jp.co.toshiba.hby.pspromis.syuueki.util.EntityUtils;
import jp.co.toshiba.hby.pspromis.syuueki.util.LoginUserInfo;
import jp.co.toshiba.hby.pspromis.syuueki.util.Utils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 *
 * @author sano
 */
@Stateless
@Interceptors({TranceInterceptor.class})
public class S008Facade extends AbstractFacade<S008Facade> {

    /**
     * ロガ－
     */
    private static final Logger logger = LoggerFactory.getLogger(S008Facade.class);

    @PersistenceContext(unitName = jp.co.toshiba.hby.pspromis.syuueki.util.ConstantString.syuuekiDataSourceName)
    private EntityManager em;

    @Inject
    private LoginUserInfo loginUserInfo;

    public S008Facade() {
        super(S008Facade.class);
    }

    @Override
    protected EntityManager getEntityManager() {
        return em;
    }

    /**
     * 収益物件情報取得
     *
     * @param condition
     * @return
     */
    public SyuGeBukkenInfoTbl getBukkenInfo(Object condition) {
        logger.info("S008Facade#getBukkenInfo");

        SyuGeBukkenInfoTbl syuGeBukkenInfoTbl = sqlExecutor.getSingleResult(em, SyuGeBukkenInfoTbl.class, "/sql/S008/selectSyuGeBukkenInfo.sql", condition);

        return syuGeBukkenInfoTbl;
    }

    /**
     * 収益物件情報更新
     *
     * @param condition
     */
    public void updateBukkenInfo(Object condition) {
        logger.info("S008Facade#updateBukkenInfo");

        sqlExecutor.executeUpdateSql(em, "/sql/S008/updateSyuGeBukkenInfo.sql", condition);
    }

    /**
     * 受注通知実績登録件数を取得
     *
     * @param condition
     * @return
     * @throws Exception
     */
    public Integer getSyuKiSpTukiSTblCount(Object condition) throws Exception {

        CountEntity syuKiSpTukiSTbl
                = sqlExecutor.getSingleResult(em, CountEntity.class, "/sql/syuKiSpTukiSTbl/selectSyuKiSpTukiSTbl.sql", condition);

        return syuKiSpTukiSTbl.getCount();
    }

    /**
     * 期間損益TBL（原価）カテゴリ別－月別詳細の「注入パターン」以外、データ区分：Ｍ　の件数を取得
     *
     * @param condition
     * @return
     * @throws Exception
     */
    public Integer getSyuKiNetCateTukiTblCount(Object condition) throws Exception {

        CountEntity syuKiNetCateTukiTbl
                = sqlExecutor.getSingleResult(em, CountEntity.class, "/sql/syuKiNetCateTukiTbl/selectKiNetCateTukiTbl.sql", condition);

        return syuKiNetCateTukiTbl.getCount();
    }

    /**
     * 期間損益TBL（原価）　カテゴリタイトルの削除
     *
     * @param condition
     * @return
     * @throws Exception
     */
    public int deleteSyuKiNetCateTitleTbl(Object condition) {
        logger.info("S008Facade#deleteSyuKiNetCateTitleTbl");

        return sqlExecutor.executeUpdateSql(em, "/sql/S008/deleteSyuKiNetCateTitleTbl.sql", condition);
    }

    /**
     * 期間損益TBL（原価）　カテゴリ別－月別詳細の削除
     *
     * @param condition
     * @return
     * @throws Exception
     */
    public int deleteSyuKiNetCateTukiTbl(Object condition) {
        logger.info("S008Facade#deleteSyuKiNetCateTukiTbl");

        return sqlExecutor.executeUpdateSql(em, "/sql/S008/deleteSyuKiNetCateTukiTbl.sql", condition);
    }

    /**
     * 白地案件 新規登録用　6桁SEQ番号を取得
     *
     * @return
     */
    public String getShirajiSeq() {
        logger.info("S008Facade#getShirajiSeq");

        StringEntity strEntity = sqlExecutor.getSingleResult(em, StringEntity.class, "/sql/S008/getShirajiSeq.sql", null);

        return strEntity.getString();
    }

    /**
     *
     * @param condition
     * @return
     */
    public SyuGeBukkenInfoTbl getIspAnkenId(Object condition) {
        logger.info("S008Facade#getIspAnkenId");
        SyuGeBukkenInfoTbl ret = new SyuGeBukkenInfoTbl();
        List<SyuGeBukkenInfoTbl> syuGeBukkenInfoTbl = sqlExecutor.getResultList(em, SyuGeBukkenInfoTbl.class, "/sql/S008/getIspAnkenId.sql", condition);
        if (syuGeBukkenInfoTbl.size() > 0) {
            ret = syuGeBukkenInfoTbl.get(0);
        }
        return ret;
    }

    /**
     * ISP区分更新
     *
     * @param condition
     * @return
     */
    public void updateIspAnkenId(SyuGeBukkenInfoTbl condition) {
        logger.info("S008Facade#updateIspAnkenId");

        sqlExecutor.executeUpdateSql(em, "/sql/S008/updateIspAnkenId.sql", condition);
    }

    /**
     * ポテンシャル値の見込大中小(PD,PT,PS)のデータを削除
     *
     * @param condition
     */
    public void deleteSyuSaSpTotalTbl(Map<String, Object> condition) {
        logger.info("S008Facade#deleteSyuSaSpTotalTbl");
        sqlExecutor.executeUpdateSql(em, "/sql/S008/deleteSyuSaSpTotalTbl.sql", condition);
    }

    /**
     * ポテンシャル値の見込大中小(PD,PT,PS)のデータを削除
     *
     * @param condition
     */
    public void deleteSyuSaSpCurTbl(Map<String, Object> condition) {
        logger.info("S008Facade#deleteSyuSaSpCurTbl");
        sqlExecutor.executeUpdateSql(em, "/sql/S008/deleteSyuSaSpCurTbl.sql", condition);
    }

    /**
     * ポテンシャル値の見込大中小(PD,PT,PS)のデータを削除
     *
     * @param condition
     */
    public void deleteSyuSaNetTotalTbl(Map<String, Object> condition) {
        logger.info("S008Facade#deleteSyuSaNetTotalTbl");
        sqlExecutor.executeUpdateSql(em, "/sql/S008/deleteSyuSaNetTotalTbl.sql", condition);
    }

    /**
     * ポテンシャル値の見込大中小(PD,PT,PS)のデータを削除
     *
     * @param condition
     */
    public void deleteSyuSaNetCateTbl(Map<String, Object> condition) {
        logger.info("S008Facade#deleteSyuSaNetCateTbl");
        sqlExecutor.executeUpdateSql(em, "/sql/S008/deleteSyuSaNetCateTbl.sql", condition);
    }

    /**
     * ポテンシャル値の見込大中小(PD,PT,PS)のデータを削除
     *
     * @param condition
     */
    public void deleteSyuSaSonekiTitleTbl(Map<String, Object> condition) {
        logger.info("S008Facade#deleteSyuSaSonekiTitleTbl");
        sqlExecutor.executeUpdateSql(em, "/sql/S008/deleteSyuSaSonekiTitleTbl.sql", condition);
    }

    /**
     * ポテンシャル値の見込大中小(PD,PT,PS)のデータを削除
     *
     * @param condition
     */
    public void deleteSyuKiBikou(Map<String, Object> condition) {
        logger.info("S008Facade#deleteSyuKiBikou");
        sqlExecutor.executeUpdateSql(em, "/sql/S008/deleteSyuKiBikou.sql", condition);
    }

    /**
     * ポテンシャル値の見込大中小(PD,PT,PS)のデータを削除
     *
     * @param condition
     */
    public void deleteSyuSaNetItemTbl(Map<String, Object> condition) {
        logger.info("S008Facade#deleteSyuSaNetItemTbl");
        sqlExecutor.executeUpdateSql(em, "/sql/S008/deleteSyuSaNetItemTbl.sql", condition);
    }

    /**
     * ポテンシャル値の見込大中小(PD,PT,PS)のデータを削除
     *
     * @param condition
     */
    public void deleteSyuSaHanCateTbl(Map<String, Object> condition) {
        logger.info("S008Facade#deleteSyuSaNetItemTbl");
        sqlExecutor.executeUpdateSql(em, "/sql/S008/deleteSyuSaHanCateTbl.sql", condition);
    }

    /**
     * 2017/11/14 ADD #5 #12 #22 （収益）受注年月と（収益）売上予定を加える
     * 集計受注年月を取得</br>
     * 2個未満取得できる場合は"1"、2個以上取得できる場合は"0"を返す
     * @param bean
     * @return
     */
    public String getJyuchuEndEditFlg(S008Bean bean) {
        logger.info("S008Facade#getJyuchuEndEditFlg");
        Map<String, Object> condition = new HashMap<>();
        condition.put("ankenId", bean.getAnkenId());
        condition.put("rirekiId", bean.getRirekiId());
        condition.put("kanjyoYm", StringUtils.replace(bean.getNowYm(), "/", ""));
        StringEntity strEntity = sqlExecutor.getSingleResult(em, StringEntity.class, "/sql/S008/getJyuchuEndEditFlg.sql", condition);
        return strEntity.getString();
    }
    /**
     * 2017/11/14 ADD #5 #12 #22 （収益）受注年月と（収益）売上予定を加える
     * 集計売上予定年月を取得</br>
     * 2個未満取得できる場合は"1"、2個以上取得できる場合は"0"を返す
     * @param bean
     * @return
     */
    public String getUriageEndEditFlg(S008Bean bean) {
        logger.info("S008Facade#getUriageEndEditFlg");
        Map<String, Object> condition = new HashMap<>();
        condition.put("ankenId", bean.getAnkenId());
        condition.put("rirekiId", bean.getRirekiId());
        condition.put("kanjyoYm", StringUtils.replace(bean.getNowYm(), "/", ""));
        StringEntity strEntity = sqlExecutor.getSingleResult(em, StringEntity.class, "/sql/S008/getUriageEndEditFlg.sql", condition);
        return strEntity.getString();
    }
    /**
     * 2017/11/14 ADD #5 #12 #22 （収益）受注年月と（収益）売上予定を加える
     * 集計回収年月を取得</br>
     * 2個未満取得できる場合は"1"、2個以上取得できる場合は"0"を返す
     * @param bean
     * @return
     */
    public String getKaisyuEndEditFlg(S008Bean bean) {
        logger.info("S008Facade#getKaisyuEndEditFlg");
        Map<String, Object> condition = new HashMap<>();
        condition.put("ankenId", bean.getAnkenId());
        condition.put("rirekiId", bean.getRirekiId());
        condition.put("kanjyoYm", StringUtils.replace(bean.getNowYm(), "/", ""));
        StringEntity strEntity = sqlExecutor.getSingleResult(em, StringEntity.class, "/sql/S008/getKaisyuEndEditFlg.sql", condition);
        return strEntity.getString();
    }
    /**
     * 2017/11/14 ADD #5 #12 #22 （収益）受注年月と（収益）売上予定を加える
     * 受注年月に紐付くテーブルを更新する
     * @param bean
     * @throws java.lang.Exception
     */
    public void updateByJyuchuEnd(S008Bean bean) throws Exception {
        logger.info("S008Facade#updateByJyuchuEnd");
        Map<String, Object> condition = new HashMap<>();
        condition.put("ankenId", bean.getAnkenId());
        condition.put("rirekiId", bean.getRirekiId());
        condition.put("jyuchuEnd", StringUtils.replace(bean.getJyuchuEnd(), "/", ""));
        //condition.put("oldJyuchuEnd", StringUtils.replace(bean.getOldJyuchuEnd(), "/", ""));
        condition.put("kanjyoYm", StringUtils.replace(bean.getNowYm(), "/", ""));
        EntityUtils.setUpdatedInfo(condition, loginUserInfo.getUserId());
        // updateをする前に念のためにDeleteを行う
        // deleteを行うと同期が取れていなかったデータが壊れるので行わない
//        sqlExecutor.executeUpdateSql(em, "/sql/S008/deleteSyuKiJyuchuSpTblBySyuekiYm.sql", condition);
//        sqlExecutor.executeUpdateSql(em, "/sql/S008/deleteSyuKiJyuchuNetTblBySyuekiYm.sql", condition);
        // updateを行う
        sqlExecutor.executeUpdateSql(em, "/sql/S008/updateSyuKiJyuchuSpTblBySyuekiYm.sql", condition);
        sqlExecutor.executeUpdateSql(em, "/sql/S008/updateSyuKiJyuchuNetTblBySyuekiYm.sql", condition);
    }
    /**
     * 2017/11/14 ADD #5 #12 #22 （収益）受注年月と（収益）売上予定を加える
     * 売上予定に紐付くテーブルを更新する
     * @param bean
     * @throws java.lang.Exception
     */
    public void updateByUriageEnd(S008Bean bean) throws Exception {
        logger.info("S008Facade#updateByUriageEnd");
        Map<String, Object> condition = new HashMap<>();
        condition.put("ankenId", bean.getAnkenId());
        condition.put("rirekiId", bean.getRirekiId());
        condition.put("uriageEnd", StringUtils.replace(bean.getUriageEnd(), "/", ""));
        //condition.put("oldUriageEnd", StringUtils.replace(bean.getOldUriageEnd(), "/", ""));
        condition.put("kanjyoYm", StringUtils.replace(bean.getNowYm(), "/", ""));
        EntityUtils.setUpdatedInfo(condition, loginUserInfo.getUserId());
        // updateをする前に念のためにDeleteを行う
        // deleteを行うと同期が取れていなかったデータが壊れるので行わない
//        sqlExecutor.executeUpdateSql(em, "/sql/S008/deleteSyuKiSpTukiITblBySyuekiYm.sql", condition);
//        sqlExecutor.executeUpdateSql(em, "/sql/S008/deleteSyuKiNetCateTukiTblBySyuekiYm.sql", condition);
//        sqlExecutor.executeUpdateSql(em, "/sql/S008/deleteSyuKiNetItemTukiTblBySyuekiYm.sql", condition);
        // updateを行う
        sqlExecutor.executeUpdateSql(em, "/sql/S008/updateSyuKiSpTukiITblBySyuekiYm.sql", condition);
        sqlExecutor.executeUpdateSql(em, "/sql/S008/updateSyuKiNetCateTukiTblBySyuekiYm.sql", condition);
        sqlExecutor.executeUpdateSql(em, "/sql/S008/updateSyuKiNetItemTukiTblBySyuekiYm.sql", condition);
    }
    /**
     * 2017/11/14 ADD #5 #12 #22 （収益）受注年月と（収益）売上予定を加える
     * 回収月に紐付くテーブルを更新する
     * @param bean
     * @throws java.lang.Exception
     */
    public void updateByKaisyuEnd(S008Bean bean) throws Exception {
        logger.info("S008Facade#updateByKaisyuEnd");
        Map<String, Object> condition = new HashMap<>();
        condition.put("ankenId", bean.getAnkenId());
        condition.put("rirekiId", bean.getRirekiId());
        condition.put("kaisyuEnd", StringUtils.replace(bean.getKaisyuEnd(), "/", ""));
        //condition.put("oldKaisyuEnd", StringUtils.replace(bean.getOldKaisyuEnd(), "/", ""));
        condition.put("kanjyoYm", StringUtils.replace(bean.getNowYm(), "/", ""));
        EntityUtils.setUpdatedInfo(condition, loginUserInfo.getUserId());
        // updateをする前に念のためにDeleteを行う
        // deleteを行うと同期が取れていなかったデータが壊れるので行わない
//        sqlExecutor.executeUpdateSql(em, "/sql/S008/deleteSyuKiKaisyuTblBySyuekiYm.sql", condition);
        // updateを行う
        sqlExecutor.executeUpdateSql(em, "/sql/S008/updateSyuKiKaisyuTblBySyuekiYm.sql", condition);
    }
}
