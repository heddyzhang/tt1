package jp.co.toshiba.hby.pspromis.syuueki.service;

import java.util.*;
import javax.ejb.Stateless;
import javax.inject.Inject;
import javax.interceptor.Interceptors;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import jp.co.toshiba.hby.pspromis.common.util.StringUtil;
import jp.co.toshiba.hby.pspromis.syuueki.bean.S011Bean;
import jp.co.toshiba.hby.pspromis.syuueki.dto.NuclearRenkeiDispBatchDto;
import jp.co.toshiba.hby.pspromis.syuueki.entity.OperationLog;
import jp.co.toshiba.hby.pspromis.syuueki.entity.SyuGeBukkenInfoTbl;
import jp.co.toshiba.hby.pspromis.syuueki.entity.SyuGeNetItemTbl;
import jp.co.toshiba.hby.pspromis.syuueki.entity.SyuKiBikou;
import jp.co.toshiba.hby.pspromis.syuueki.facade.SyuGeBukenInfoTblFacade;
import jp.co.toshiba.hby.pspromis.syuueki.facade.SyuGeNetItemTblViewFacade;
import jp.co.toshiba.hby.pspromis.syuueki.facade.SyuKiBikouFacade;
import jp.co.toshiba.hby.pspromis.syuueki.interceptor.TranceInterceptor;
import jp.co.toshiba.hby.pspromis.syuueki.util.EntityUtils;
import jp.co.toshiba.hby.pspromis.syuueki.util.LoginUserInfo;
import jp.co.toshiba.hby.pspromis.syuueki.util.SyuuekiUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
/**
 * PS-Promis収益管理システム
 * 備考入力 Service
 * @author masaki
 */
@Stateless
@Interceptors({TranceInterceptor.class})
public class S011Service {

    /**
     * ロガー
     */
    public static final Logger logger = LoggerFactory.getLogger(S011Service.class);

    @PersistenceContext(unitName = jp.co.toshiba.hby.pspromis.syuueki.util.ConstantString.syuuekiDataSourceName)
    private EntityManager em;

    /**
     * Injection loginUserInfo
     * (ユーザー情報(ユーザーid,名称,所属部課名)を格納したオブジェクト)
     */
    @Inject
    private LoginUserInfo loginUserInfo;
    /**
     * パラメータ格納クラスをinjection(CDI)<br>
     * InjectアノテーションよりAPサーバー(Glassfish)側で自動的にインスタンス作成(new)される。<br>
     */
    @Inject
    private S011Bean s011Bean;
    
    @Inject
    private SyuKiBikouFacade syuKiBikouFacade;

    @Inject
    private SyuuekiUtils syuuekiUtils;
    
    @Inject
    private SyuGeNetItemTblViewFacade syuGeNetItemTblViewFacade;
        
    @Inject
    private OperationLogService operationLogService;

    @Inject
    private SyuGeBukenInfoTblFacade geBukenInfoTblFacade;

    @Inject
    private StoredProceduresService storedProceduresService;
    
    /**
     * 備考を取得
     */
    private SyuKiBikou getBikouEntity() {

        SyuKiBikou bikouEntity = null;
                
        if(s011Bean.getDispFlg().equals("2")){
            bikouEntity = 
                syuGeNetItemTblViewFacade.getBikou(s011Bean.getAnkenId(), Integer.parseInt(s011Bean.getRirekiId()), s011Bean.getOrderItem(), s011Bean.getRirekiFlg());    
        } else if(s011Bean.getDispFlg().equals("1")){
            bikouEntity = 
                syuKiBikouFacade.findPk(s011Bean.getAnkenId(), Integer.parseInt(s011Bean.getRirekiId()), s011Bean.getDataKbn(), s011Bean.getRirekiFlg());
        } else {
            bikouEntity = 
                syuKiBikouFacade.findPk(s011Bean.getAnkenId(), Integer.parseInt(s011Bean.getRirekiId()), s011Bean.getSyuekiYm(), s011Bean.getRirekiFlg());
        }
        
        return bikouEntity;
    }
    
    /**
     * どの画面から呼び出されたか判断する
     */
    private String dispJudge() {
        if(StringUtil.isNotEmpty(s011Bean.getSyuekiYm())){
            // 期間損益の場合
            return "0";
        } else if(StringUtil.isNotEmpty(s011Bean.getDataKbn())){
            // 最終見込損益の場合
            return "1";
        } else {
            // 項番一覧の場合
            return "2";
        }
    }

    /**
     * 初期表示 ビジネスロジック
     * @throws Exception 
     */
    public void indexExecute() throws Exception {
        
        // 事業部コード取得のため物件情報テーブルを取得
        Map<String, Object> condition = new LinkedHashMap<>();
        condition.put("ankenId", s011Bean.getAnkenId());
        condition.put("rirekiId", s011Bean.getRirekiId());
        SyuGeBukkenInfoTbl ankenEntity = geBukenInfoTblFacade.findPk(condition);
        s011Bean.setSyuGeBukkenInfoTbl(ankenEntity);
        
        // どの画面から呼び出されたか判断
        String dispFlg = dispJudge();
        s011Bean.setDispFlg(dispFlg);
        
        // 項番一覧の場合、対象欄用情報の取得(注番、製番記号)
        if(dispFlg.equals("2")){
            SyuGeNetItemTbl entity = 
                    syuGeNetItemTblViewFacade.getDispKoban(
                            s011Bean.getAnkenId()
                          , s011Bean.getRirekiId()
                          , s011Bean.getOrderItem()
                          , s011Bean.getRirekiFlg()
                    );
            s011Bean.setOrderNo(entity.getOrderNo());
            s011Bean.setSeiban(entity.getSeiban());
        }

        // 進行基準の備考テーブル情報取得
        SyuKiBikou bikouEntity = getBikouEntity();
        s011Bean.setSyuKiBikou(bikouEntity);
    }
    
    /**
     * 登録処理 ビジネスロジック
     * @return
     * @throws Exception 
     */
    public boolean save() throws Exception {
        boolean retBool = true;
        // 更新条件をセット
        Map<String, Object> condition = new HashMap<>();
        condition.put("ankenId", s011Bean.getAnkenId());
        condition.put("rirekiId", s011Bean.getRirekiId());
        condition.put("rirekiFlg", s011Bean.getRirekiFlg());
        condition.put("bikou", s011Bean.getBikou());
        EntityUtils.setCreatedInfo(condition, loginUserInfo.getUserId());

        if(s011Bean.getDispFlg().equals("0") || s011Bean.getDispFlg().equals("1")){
            String dataType = getBikoDataType();
            condition.put("kbn", dataType);
        } else {
            condition.put("orderItem", s011Bean.getOrderItem());
        }

//        if(s011Bean.getDispFlg().equals("0")) {
//            condition.put("kbn", s011Bean.getSyuekiYm());
//        } else if(s011Bean.getDispFlg().equals("1")) {
//            condition.put("kbn", s011Bean.getDataKbn());
//        } else {
//            condition.put("orderItem", s011Bean.getOrderItem());
//        }
        // 備考更新
        updateBikou(condition);

        // 操作ログ登録
        registOperationLog();
        
        // （原子力）収益連携バッチをコール
        // (2017/11/22 連携バッチは自立型トランザクションになり、ここでCALLしても変更情報が反映されないようなので、S011Servletから直接呼ぶように修正)
        //callNuclearSysRenkeiDisp();
        
        return retBool;
    }

    private String getBikoDataType() {
        String dataType = "";
        if (s011Bean.getDispFlg().equals("0")){
            dataType = s011Bean.getSyuekiYm();
        } else if(s011Bean.getDispFlg().equals("1")) {
            dataType = s011Bean.getDataKbn();
        } else {
            dataType = s011Bean.getOrderItem();
        }
        return dataType;
    }

    /**
     * 更新処理(進行基準の備考)
     */
    private void updateBikou(Map<String, Object> data) {
        String bikou = (String)data.get("bikou");
        
        // 備考が未入力の場合
        if (StringUtils.isEmpty(bikou)) {
            // 期間損益　または　最終見込損益　の場合
            if(!s011Bean.getDispFlg().equals("2")){
                
                SyuKiBikou bikouEntity = getBikouEntity();
                // 備考データのレコードを削除
                em.remove(bikouEntity);
            }else {
                syuGeNetItemTblViewFacade.updateBikou(data);
            }
        // 備考が入力されている場合
        } else {
            // 対象データの更新
            // 期間損益　または　最終見込損益　の場合
            if(!s011Bean.getDispFlg().equals("2")){
                int count = syuKiBikouFacade.updateSyuKiBikou(data);
                if (count == 0) {
                    syuKiBikouFacade.insertSyuKiBikou(data);
                }
                
            // 項番一覧　の場合
            } else {
                syuGeNetItemTblViewFacade.updateBikou(data);
            }
        }
    }

    /**
     * 操作ログの登録
     * @param operationCode
     * @throws Exception
     */
    public void registOperationLog() throws Exception{
        OperationLog operationLog = operationLogService.getOperationLog();
        
        String objectType = operationLogService.getObjectType(s011Bean.getProcId());
        
        operationLog.setOperationCode("SAVE_TUKI_BIKOU");
        operationLog.setObjectId(20);
        operationLog.setObjectType(objectType);
        operationLog.setRemarks(s011Bean.getAnkenId());
        operationLog.setRemarks2(getBikoDataType());
        
        operationLogService.insertOperationLogSearch(operationLog);
    }
    
    
    /**
     * （原子力）収益連携バッチをCallする
     */
    public void callNuclearSysRenkeiDisp() throws Exception {
        String dispKbn = "SAVE_BIKOU";
        NuclearRenkeiDispBatchDto dto = new NuclearRenkeiDispBatchDto();
        dto.setAnkenId(s011Bean.getAnkenId());
        dto.setRirekiId(s011Bean.getRirekiId());
        dto.setDispKbn(dispKbn);
        
        storedProceduresService.callNuclearSysRenkeiDispBatch(dto);
            
        if (0 != dto.getStatus()) {
            String errorInfo = "ankenId=" + s011Bean.getAnkenId()
                    + " rirekiId=" + s011Bean.getRirekiId()
                    + " dispKbn=" + dispKbn;
                    
            throw new Exception("[SYU_N7_RENKEI_BATCH.PROC_DISP_CALL_MAIN]でエラーが発生しました。" + errorInfo);
        }
        
    }
    
}
