package jp.co.toshiba.hby.pspromis.syuueki.service.download;

import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.HashMap;
import javax.ejb.Stateless;
import javax.inject.Inject;
import javax.interceptor.Interceptors;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import jp.co.toshiba.hby.pspromis.syuueki.bean.DownloadOptBean;
import jp.co.toshiba.hby.pspromis.syuueki.bean.S001Bean;
import jp.co.toshiba.hby.pspromis.syuueki.bean.S002Bean;
import jp.co.toshiba.hby.pspromis.syuueki.bean.S004Bean;
import jp.co.toshiba.hby.pspromis.syuueki.bean.S005Bean;
import jp.co.toshiba.hby.pspromis.syuueki.entity.OperationLog;
import jp.co.toshiba.hby.pspromis.syuueki.enums.Env;
import jp.co.toshiba.hby.pspromis.syuueki.enums.Label;
import jp.co.toshiba.hby.pspromis.syuueki.interceptor.TranceInterceptor;
import jp.co.toshiba.hby.pspromis.syuueki.jdbc.DbUtilsExecutor;
import jp.co.toshiba.hby.pspromis.syuueki.jdbc.SqlFile;
import jp.co.toshiba.hby.pspromis.syuueki.service.S002DownloadService;
import jp.co.toshiba.hby.pspromis.syuueki.service.S004DownloadService;
import jp.co.toshiba.hby.pspromis.syuueki.service.OperationLogService;
import jp.co.toshiba.hby.pspromis.syuueki.util.ConstantString;
import jp.co.toshiba.hby.pspromis.syuueki.util.DetailExcelUtils;
import jp.co.toshiba.hby.pspromis.syuueki.util.FileUtils;
import jp.co.toshiba.hby.pspromis.syuueki.util.LoginUserInfo;
import jp.co.toshiba.hby.pspromis.syuueki.util.PoiUtil;
import jp.co.toshiba.hby.pspromis.syuueki.util.ZipCompresser;
import org.apache.commons.beanutils.PropertyUtils;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.compress.archivers.ArchiveException;
import org.apache.commons.compress.archivers.ArchiveOutputStream;
import org.apache.commons.compress.archivers.zip.ZipArchiveEntry;
import org.apache.commons.compress.archivers.zip.ZipArchiveOutputStream;
import org.apache.commons.compress.utils.IOUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.apache.poi.ss.usermodel.Workbook;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * ES-Promis収益管理システム
 * 一括ダウンロード処理
 * @author
 */
@Stateless
@Interceptors({TranceInterceptor.class})
public class IkkatsuListService {
    
    private static final Logger log = LoggerFactory.getLogger(IkkatsuListService.class);
    
    @PersistenceContext(unitName = jp.co.toshiba.hby.pspromis.syuueki.util.ConstantString.syuuekiDataSourceName)
    private EntityManager em;
    
    @Inject
    private DbUtilsExecutor dbUtilsExecutor;

    @Inject
    private LoginUserInfo loginUserInfo;
    
    @Inject
    private DownloadOptBean downloadOptBean;
    
    @Inject
    private S001Bean s001Bean;
    
    @Inject
    private S002DownloadService s002DownloadService;
    
    @Inject
    private S002Bean s002Bean;

    @Inject
    private S004DownloadService s004DownloadService;
    
    @Inject
    private S004Bean s004Bean;

    @Inject
    private KobanListService kobanListService;
    
    @Inject
    private S005Bean s005Bean;

    @Inject
    private OperationLogService operationLogService;
    
    /**
     * Excelダウンロードファイルの取得
     * @return 
     */
    public String getDownloadFilePath() {
        String baseDirName = getOutputBaseDirectory();
        String downloadFilePath = baseDirName + "/" + downloadOptBean.getDownloadFileName() + "/" + downloadOptBean.getDownloadFileName() + ".zip";
        return downloadFilePath;
    }

    /**
     * Excelダウンロードファイルの作成
     * @param req
     * @param resp
     * @throws Exception
     */
    public void createFileExecute(HttpServletRequest req, HttpServletResponse resp) throws Exception {
        List<Map<String, String>> excelFileList = new ArrayList<>();
        boolean isCreatedZip = true;
        File tempDir = null;

        try {
            String outputDirecotryName = outputDirectoryName();

            // ワークディレクトリにExcel出力用ディレクトリを作成する
            String baseDirName = getOutputBaseDirectory();
            String tempDirName = baseDirName + "/" + outputDirecotryName;
            tempDir = new File(tempDirName);
            tempDir.mkdir();

            List<Map<String, Object>> ankenList = this.findAnkenList();
            for (Map<String, Object> ankenData: ankenList) {
                String ankenId = StringUtils.defaultString((String)ankenData.get("ANKEN_ID"));
                String rirekiId = ((BigDecimal)ankenData.get("RIREKI_ID")).toString();
                String salesClass = StringUtils.defaultString((String)ankenData.get("SALES_CLASS"));
                String orderNo = StringUtils.defaultString((String)ankenData.get("ORDER_NO"));

                log.info("ankenId=[{}] rirekiId=[{}] salesClass=[{}] orderNo=[{}]", ankenId, rirekiId, salesClass, orderNo);

                String[] sheetKbns = getSheetKbns(salesClass);

                // テンプレートシートを読み込み、必要なシート以外を削除
                Workbook workbook = readTemplateFile(req);
                DetailExcelUtils.leaveDetailSheet(workbook, sheetKbns);

                for (String sheetKbn: sheetKbns) {
                    // 最終見込損益用シートにデータを書き込み
                    if ("saisyu".equals(sheetKbn)) {
                        writeSaisyuInfo(workbook, ankenId, rirekiId);
                    }
                    // 期間損益(進行基準)シートにデータを書き込み
                    if ("kikanS".equals(sheetKbn)) {
                        // (一般案件は期間損益シートは未実装のため、進行基準案件のみ行う)
                        if (ConstantString.salesClassS.equals(salesClass)) {
                            writeKikanSInfo(workbook, ankenId, rirekiId);
                        }
                    }
                    // 項番一覧シートにデータを書き込み
                    if ("koban".equals(sheetKbn)) {
                        writeKobanInfo(workbook, ankenId, rirekiId);
                    }
                }

                // 現在の処理案件をExcelに出力
                String outputFileName = orderNo + "_" + ankenId + "_syuueki.xlsx";
                String zipOutputFileName = orderNo + "_" + ankenId + "_収益情報.xlsx";
                String fullPath = tempDirName + "/" + outputFileName;
                this.outputExcel(workbook, fullPath);

                Map<String, String> fileInfo = new HashMap<>();
                fileInfo.put("filePath", fullPath);
                fileInfo.put("zipFileName", zipOutputFileName);

                excelFileList.add(fileInfo);
            }
            
            // Excelファイルを作成したディレクトリを圧縮
            String zipFileName = outputDirecotryName;
            File zipFile = new File(tempDir + "/" + zipFileName + ".zip");
            createZipFile(zipFile, excelFileList);
            //ZipCompresser.createZipFile(zipFile, tempDir, "utf-8");

            // ダウンロードのための圧縮ファイル名をセット
            downloadOptBean.setDownloadFileName(zipFileName);

            // 操作ログを登録
            this.registOperationLog();
            
        } catch (Exception e) {
            isCreatedZip = false;
            throw e;
        } finally {
            // Excelファイルを削除
            deleteExcelFile(excelFileList);
            // エラー発生時は途中まで作成した中間データも削除
            if (!isCreatedZip && tempDir != null) {
                FileUtils.deleteDir(tempDir);
            }
        }
    }
    
    /**
     * メインの一覧を取得(SQL実行)
     */
    private List<Map<String, Object>> findAnkenList() throws Exception {
        SqlFile sqlFile = new SqlFile();
        
        // SQLファイルの取得
        String splFilePath = "/sql/download/selectIkkatsuAnkenList.sql";
        log.info("[findMainList] SQL_SELECT_FILE=[{}]", splFilePath);
        
        // パラメータを作成
        Map<String, Object> condition = new HashMap<>();
        condition.put("targetAnkenId", Arrays.asList(s001Bean.getOptionTargetAnkenId()));
        condition.put("rirekiId", getRirekiIdList());
        condition.put("rirekiFlg", "");

        String sqlString = sqlFile.getSqlString(splFilePath, condition);
        Object[] sqlParams = sqlFile.getSqlParams(splFilePath, condition);

        // SQLを実行(Commons DbUtilで実行)
        List<Map<String, Object>> list = dbUtilsExecutor.dbUtilsGetSqlList(em, sqlString, sqlParams);
        return list;
    }
    
    /**
     * 履歴IDを取得
     */
    private List<Integer> getRirekiIdList() {
        List<Integer> rirekiList = new ArrayList<>();
        rirekiList.add(0);
        return rirekiList;
    }
    
    /**
     * 出力対象シート(複数)を取得
     */
    private String[] getSheetKbns(String salesClass) {
        String[] outputSheetKbns = downloadOptBean.getOptionIkkatsuOutPutSheetKbn();
        List<String> sheetList = new ArrayList<>(3);
        for (String sheetKbn: outputSheetKbns) {
            switch (sheetKbn) {
                case "1":
                    sheetList.add("saisyu");
                    break;
                case "2":
                    // 期間損益(進行基準)の出力シートは、進行基準案件のみ残す
                    if (ConstantString.salesClassS.equals(salesClass)) {
                        sheetList.add("kikanS");
                    }
                    break;
                case "3":
                    sheetList.add("koban");
                    break;
            }
        }
 
        return (String[])sheetList.toArray(new String[0]);
    }
    
    /**
     * Excel出力用ディレクトリ名を取得
     */
    private String outputDirectoryName() {
        SimpleDateFormat timeStampSd = new SimpleDateFormat("yyyyMMddHHmmss");
        String nowString = timeStampSd.format(new Date());
        
        String tempDir = loginUserInfo.getUserId() + "_" + nowString;
        return tempDir;
    }
    
    /**
     * 作業ベースディレクトリを取得
     */
    private String getOutputBaseDirectory() {
        String baseDir = Env.Download_Temp_Dir_Work.getValue();
        return baseDir;
    }

    /**
     * Excelファイルの出力
     */
    private void outputExcel(Workbook workbook, String outPutFullName) throws Exception{
        try(OutputStream out = new FileOutputStream(outPutFullName);) {
            workbook.write(out);
            out.flush();
        }
    }

    /**
     * 作成したファイルをzipに固める
     * @param zipFile
     * @param fileList
     * @throws org.apache.commons.compress.archivers.ArchiveException
     * @throws java.io.IOException
     */
    public void createZipFile(File zipFile, List<Map<String, String>> fileList) throws ArchiveException, IOException {
        try (OutputStream out = new BufferedOutputStream(new FileOutputStream(zipFile))){
            try (ZipArchiveOutputStream archive = new ZipArchiveOutputStream(out)){
                archive.setEncoding("Windows-31J");

                for (Map<String, String> fileInfo: fileList) {
                    String name = fileInfo.get("zipFileName");
                    String filePath = fileInfo.get("filePath");
                    archive.putArchiveEntry(new ZipArchiveEntry(name));
                    try (InputStream is = new FileInputStream(filePath)) {
                        IOUtils.copy(is, archive);
                        archive.closeArchiveEntry();
                    }
                }

                archive.finish();
                archive.flush();
            }

            out.flush();
        }
    }

    /**
     * Excelファイルの削除
     */
    private void deleteExcelFile(List<Map<String, String>> excelFileList) {
        if (CollectionUtils.isNotEmpty(excelFileList)) {
            for (Map<String, String> fileInfo: excelFileList) {
                String filePath = fileInfo.get("filePath");
                File excel = new File(filePath);
                if (excel.isFile()) {
                    excel.delete();
                }
            }
        }
    }
    
    /**
     * ダウンロード用Excelファイルの読み込み
     */
    private Workbook readTemplateFile(HttpServletRequest req) throws IOException, FileNotFoundException, InvalidFormatException {
        String filePath = req.getServletContext().getRealPath("WEB-INF/template/ankenDetail_template.xlsx");
        Workbook workbook = PoiUtil.getWorkbook(new File(filePath));
        return workbook;
    }

    /**
     * 最終見込損益の情報をExcelに書き込み
     */
    private void writeSaisyuInfo(Workbook workbook, String ankenId, String rirekiId) throws Exception {
        // 最終見込損益Excelファイル作成に必要なパラメータを初期化
        PropertyUtils.copyProperties(s002Bean, (new S002Bean()));
        
        s002Bean.setAnkenId(ankenId);
        s002Bean.setRirekiId(rirekiId);
        s002Bean.setIsIkkatsuFlg(true);
        
        s002DownloadService.outputDownloadExcel(workbook);
    }

    /**
     * 期間損益(進行基準)の情報をExcelに書き込み
     */
    private void writeKikanSInfo(Workbook workbook, String ankenId, String rirekiId) throws Exception {
        // 期間損益Excelファイル作成に必要なパラメータを初期化
        PropertyUtils.copyProperties(s004Bean, (new S004Bean()));
        
        s004Bean.setAnkenId(ankenId);
        s004Bean.setRirekiId(rirekiId);
        s004Bean.setIsIkkatsuFlg(true);

        s004DownloadService.outputDownloadExcel(workbook);
    }
    
    /**
     * 項番一覧（期間）の情報をExcelに書き込み
     * 
     */
    private void writeKobanInfo(Workbook workbook, String ankenId, String rirekiId) throws Exception {
        // 項番一覧Excelファイル作成に必要なパラメータを初期化
        PropertyUtils.copyProperties(s005Bean, (new S005Bean()));
        
        s005Bean.setAnkenId(ankenId);
        s005Bean.setRirekiId(rirekiId);
        s005Bean.setIsIkkatsuFlg(true);

        kobanListService.outputDownloadExcel(workbook);
    }
    
    
    /**
     * 操作ログを登録
     */
    private void registOperationLog() throws Exception{
        // 操作ログを出力
        OperationLog operationLog = operationLogService.getOperationLog();
        operationLog.setOperationCode("DL_IKKATSU");
        operationLog.setObjectType("ANKEN");
        operationLog.setObjectId(10);
        
        String remarks = "";
        String[] outputSheetKbns = downloadOptBean.getOptionIkkatsuOutPutSheetKbn();
        for (String sheetKbn: outputSheetKbns) {
            String temp = "";
            switch (sheetKbn) {
                case "1":
                    temp = Label.outputFormSaisyu.getLabel();
                    break;
                case "2":
                    temp = Label.outputFormKikan.getLabel();
                    break;
                case "3":
                    temp = Label.outputFormKoban.getLabel();
                    break;
            }
            
            remarks = StringUtils.isEmpty(remarks) ? temp : (remarks + "," + temp);
        }
        
        operationLog.setRemarks(remarks);
        operationLogService.insertOperationLogSearch(operationLog);
    }
}
