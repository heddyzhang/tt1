/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package jp.co.toshiba.hby.pspromis.syuueki.entity;

import java.io.Serializable;
import java.math.BigDecimal;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.validation.constraints.NotNull;

/**
 *
 * @author sano
 */
@Entity
public class ContractAmount implements Serializable {
    private static final long serialVersionUID = 1L;
    
    @Id
    @Column(name = "SEQ")
    private Integer seq;
    @Id
    @Column(name = "CURRENCY_CODE")
    private String currencyCode;
    @Column(name = "KEIYAKU_RATE")
    private String keiyakuRate;
    
    @Column(name = "KEIYAKU_AMOUNT_1")
    private BigDecimal keiyakuAmount1;
    @Column(name = "KEIYAKU_AMOUNT_2")
    private BigDecimal keiyakuAmount2;
    @Column(name = "KEIYAKU_AMOUNT_3")
    private BigDecimal keiyakuAmount3;
    @Column(name = "KEIYAKU_AMOUNT_4")
    private BigDecimal keiyakuAmount4;
    @Column(name = "KEIYAKU_AMOUNT_5")
    private BigDecimal keiyakuAmount5;
    @Column(name = "KEIYAKU_AMOUNT_6")
    private BigDecimal keiyakuAmount6;
    @Column(name = "KEIYAKU_AMOUNT_7")
    private BigDecimal keiyakuAmount7;
    @Column(name = "KEIYAKU_AMOUNT_8")
    private BigDecimal keiyakuAmount8;
    @Column(name = "KEIYAKU_AMOUNT_9")
    private BigDecimal keiyakuAmount9;
    @Column(name = "KEIYAKU_AMOUNT_10")
    private BigDecimal keiyakuAmount10;
    @Column(name = "KEIYAKU_AMOUNT_11")
    private BigDecimal keiyakuAmount11;
    @Column(name = "KEIYAKU_AMOUNT_12")
    private BigDecimal keiyakuAmount12;;
    @Column(name = "KEIYAKU_AMOUNT_TM")
    private BigDecimal keiyakuAmountTm;
    @Column(name = "KEIYAKU_AMOUNT_K1")
    private BigDecimal keiyakuAmountK1;
    @Column(name = "KEIYAKU_AMOUNT_K2")
    private BigDecimal keiyakuAmountK2;
    @Column(name = "KEIYAKU_AMOUNT_G")
    private BigDecimal keiyakuAmountG;
    @Column(name = "KEIYAKU_AMOUNT_F")
    private BigDecimal keiyakuAmountF;
    @Column(name = "KEIYAKU_AMOUNT_K1_DIFF")
    private BigDecimal keiyakuAmountK1Diff;
    @Column(name = "KEIYAKU_AMOUNT_K2_DIFF")
    private BigDecimal keiyakuAmountK2Diff;
    @Column(name = "KEIYAKU_AMOUNT_G_DIFF")
    private BigDecimal keiyakuAmountGDiff;
    @Column(name = "KEIYAKU_AMOUNT_DIFF")
    private BigDecimal keiyakuAmountDiff;
    
    @Column(name = "KEIYAKU_AMOUNT_1Q")
    private BigDecimal keiyakuAmount1Q;
    @Column(name = "KEIYAKU_AMOUNT_2Q")
    private BigDecimal keiyakuAmount2Q;
    @Column(name = "KEIYAKU_AMOUNT_3Q")
    private BigDecimal keiyakuAmount3Q;
    @Column(name = "KEIYAKU_AMOUNT_4Q")
    private BigDecimal keiyakuAmount4Q;
    
    @Column(name = "KEIYAKU_AMOUNT_1Q_DIFF")
    private BigDecimal keiyakuAmount1QDiff;
    @Column(name = "KEIYAKU_AMOUNT_2Q_DIFF")
    private BigDecimal keiyakuAmount2QDiff;
    @Column(name = "KEIYAKU_AMOUNT_3Q_DIFF")
    private BigDecimal keiyakuAmount3QDiff;
    @Column(name = "KEIYAKU_AMOUNT_4Q_DIFF")
    private BigDecimal keiyakuAmount4QDiff;

    public ContractAmount() {
    }
    
    public Integer getSeq() {
        return this.seq;
    }

    public void setSeq(Integer seq) {
        this.seq = seq;
    }
    
    public String getCurrencyCode() {
        return this.currencyCode;
    }

    public void setCurrencyCode(String currencyCode) {
        this.currencyCode = currencyCode;
    }

    public String getKeiyakuRate() {
        return this.keiyakuRate;
    }

    public void setKeiyakuRate(String keiyakuRate) {
        this.keiyakuRate = keiyakuRate;
    }

    public BigDecimal getKeiyakuAmount1() {
        return this.keiyakuAmount1;
    }

    public void setKeiyakuAmount1(BigDecimal keiyakuAmount1) {
        this.keiyakuAmount1 = keiyakuAmount1;
    }
    
    public BigDecimal getKeiyakuAmount2() {
        return this.keiyakuAmount2;
    }

    public void setKeiyakuAmount2(BigDecimal keiyakuAmount2) {
        this.keiyakuAmount2 = keiyakuAmount2;
    }
    
    public BigDecimal getKeiyakuAmount3() {
        return this.keiyakuAmount3;
    }

    public void setKeiyakuAmount3(BigDecimal keiyakuAmount3) {
        this.keiyakuAmount3 = keiyakuAmount3;
    }
    
    public BigDecimal getKeiyakuAmount4() {
        return this.keiyakuAmount4;
    }

    public void setKeiyakuAmount4(BigDecimal keiyakuAmount4) {
        this.keiyakuAmount4 = keiyakuAmount4;
    }
    
    public BigDecimal getKeiyakuAmount5() {
        return this.keiyakuAmount5;
    }

    public void setKeiyakuAmount5(BigDecimal keiyakuAmount5) {
        this.keiyakuAmount5 = keiyakuAmount5;
    }
    
    public BigDecimal getKeiyakuAmount6() {
        return this.keiyakuAmount6;
    }

    public void setKeiyakuAmount6(BigDecimal keiyakuAmount6) {
        this.keiyakuAmount6 = keiyakuAmount6;
    }
    
    public BigDecimal getKeiyakuAmount7() {
        return this.keiyakuAmount7;
    }

    public void setKeiyakuAmount7(BigDecimal keiyakuAmount7) {
        this.keiyakuAmount7 = keiyakuAmount7;
    }
    
    public BigDecimal getKeiyakuAmount8() {
        return this.keiyakuAmount8;
    }

    public void setKeiyakuAmount8(BigDecimal keiyakuAmount8) {
        this.keiyakuAmount8 = keiyakuAmount8;
    }
    
    public BigDecimal getKeiyakuAmount9() {
        return this.keiyakuAmount9;
    }

    public void setKeiyakuAmount9(BigDecimal keiyakuAmount9) {
        this.keiyakuAmount9 = keiyakuAmount9;
    }
    
    public BigDecimal getKeiyakuAmount10() {
        return this.keiyakuAmount10;
    }

    public void setKeiyakuAmount10(BigDecimal keiyakuAmount10) {
        this.keiyakuAmount10 = keiyakuAmount10;
    }
    
    public BigDecimal getKeiyakuAmount11() {
        return this.keiyakuAmount11;
    }

    public void setKeiyakuAmount11(BigDecimal keiyakuAmount11) {
        this.keiyakuAmount11 = keiyakuAmount11;
    }
    
    public BigDecimal getKeiyakuAmount12() {
        return this.keiyakuAmount12;
    }

    public void setKeiyakuAmount12(BigDecimal keiyakuAmount12) {
        this.keiyakuAmount12 = keiyakuAmount12;
    }
    
    public BigDecimal getKeiyakuAmountTm() {
        return this.keiyakuAmountTm;
    }

    public void setKeiyakuAmountTm(BigDecimal keiyakuAmountTm) {
        this.keiyakuAmountTm = keiyakuAmountTm;
    }
    
    public BigDecimal getKeiyakuAmountK1() {
        return this.keiyakuAmountK1;
    }

    public void setKeiyakuAmountK1(BigDecimal keiyakuAmountK1) {
        this.keiyakuAmountK1 = keiyakuAmountK1;
    }
    
    public BigDecimal getKeiyakuAmountK2() {
        return this.keiyakuAmountK2;
    }

    public void setKeiyakuAmountK2(BigDecimal keiyakuAmountK2) {
        this.keiyakuAmountK2 = keiyakuAmountK2;
    }
    
    public BigDecimal getKeiyakuAmountG() {
        return this.keiyakuAmountG;
    }

    public void setKeiyakuAmountG(BigDecimal keiyakuAmountG) {
        this.keiyakuAmountG = keiyakuAmountG;
    }

    public BigDecimal getKeiyakuAmountF() {
        return this.keiyakuAmountF;
    }

    public void setKeiyakuAmountF(BigDecimal keiyakuAmountF) {
        this.keiyakuAmountF = keiyakuAmountF;
    }
    
    public BigDecimal getKeiyakuAmountK1Diff() {
        return this.keiyakuAmountK1Diff;
    }

    public void setKeiyakuAmountK1Diff(BigDecimal keiyakuAmountK1Diff) {
        this.keiyakuAmountK1Diff = keiyakuAmountK1Diff;
    }
    
    public BigDecimal getKeiyakuAmountK2Diff() {
        return this.keiyakuAmountK2Diff;
    }

    public void setKeiyakuAmountK2Diff(BigDecimal keiyakuAmountK2Diff) {
        this.keiyakuAmountK2Diff = keiyakuAmountK2Diff;
    }
    
    public BigDecimal getKeiyakuAmountGDiff() {
        return this.keiyakuAmountGDiff;
    }

    public void setKeiyakuAmountGDiff(BigDecimal keiyakuAmountGDiff) {
        this.keiyakuAmountGDiff = keiyakuAmountGDiff;
    }
    
    public BigDecimal getKeiyakuAmountDiff() {
        return this.keiyakuAmountDiff;
    }

    public void setKeiyakuAmountDiff(BigDecimal keiyakuAmountDiff) {
        this.keiyakuAmountDiff = keiyakuAmountDiff;
    }

    public BigDecimal getKeiyakuAmount1Q() {
        return keiyakuAmount1Q;
    }

    public void setKeiyakuAmount1Q(BigDecimal keiyakuAmount1Q) {
        this.keiyakuAmount1Q = keiyakuAmount1Q;
    }

    public BigDecimal getKeiyakuAmount2Q() {
        return keiyakuAmount2Q;
    }

    public void setKeiyakuAmount2Q(BigDecimal keiyakuAmount2Q) {
        this.keiyakuAmount2Q = keiyakuAmount2Q;
    }

    public BigDecimal getKeiyakuAmount3Q() {
        return keiyakuAmount3Q;
    }

    public void setKeiyakuAmount3Q(BigDecimal keiyakuAmount3Q) {
        this.keiyakuAmount3Q = keiyakuAmount3Q;
    }

    public BigDecimal getKeiyakuAmount4Q() {
        return keiyakuAmount4Q;
    }

    public void setKeiyakuAmount4Q(BigDecimal keiyakuAmount4Q) {
        this.keiyakuAmount4Q = keiyakuAmount4Q;
    }

    public BigDecimal getKeiyakuAmount1QDiff() {
        return keiyakuAmount1QDiff;
    }

    public void setKeiyakuAmount1QDiff(BigDecimal keiyakuAmount1QDiff) {
        this.keiyakuAmount1QDiff = keiyakuAmount1QDiff;
    }

    public BigDecimal getKeiyakuAmount2QDiff() {
        return keiyakuAmount2QDiff;
    }

    public void setKeiyakuAmount2QDiff(BigDecimal keiyakuAmount2QDiff) {
        this.keiyakuAmount2QDiff = keiyakuAmount2QDiff;
    }

    public BigDecimal getKeiyakuAmount3QDiff() {
        return keiyakuAmount3QDiff;
    }

    public void setKeiyakuAmount3QDiff(BigDecimal keiyakuAmount3QDiff) {
        this.keiyakuAmount3QDiff = keiyakuAmount3QDiff;
    }

    public BigDecimal getKeiyakuAmount4QDiff() {
        return keiyakuAmount4QDiff;
    }

    public void setKeiyakuAmount4QDiff(BigDecimal keiyakuAmount4QDiff) {
        this.keiyakuAmount4QDiff = keiyakuAmount4QDiff;
    }

}
