/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package jp.co.toshiba.hby.pspromis.syuueki.facade;

import java.util.List;
import java.util.Map;
import javax.ejb.Stateless;
import javax.interceptor.Interceptors;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import jp.co.toshiba.hby.pspromis.syuueki.entity.StringEntity;
import jp.co.toshiba.hby.pspromis.syuueki.entity.SyuKiNetItemTukiTbl;
import jp.co.toshiba.hby.pspromis.syuueki.interceptor.TranceInterceptor;
import org.apache.commons.collections.CollectionUtils;
import static jp.co.toshiba.hby.pspromis.syuueki.interceptor.TranceInterceptor.logger;

/**
 *
 * @author rnomura
 */
@Stateless
@Interceptors({TranceInterceptor.class})
public class SyuKiNetItemTukiTblFacade extends AbstractFacade<SyuKiNetItemTukiTbl> {

    @PersistenceContext(unitName = jp.co.toshiba.hby.pspromis.syuueki.util.ConstantString.syuuekiDataSourceName)
    private EntityManager em;

    @Override
    protected EntityManager getEntityManager() {
        return em;
    }

    public SyuKiNetItemTukiTblFacade() {
        super(SyuKiNetItemTukiTbl.class);
    }

    /**
     * 項番一覧(期間)保存処理(最新見込)
     * @param condition
     */
    public void updateSeibanSyuKiNetItem(Map<String, Object> condition) {
        // 更新
        int count = sqlExecutor.executeUpdateSql(em, "/sql/S005/updateSeibanSyuKiNetItem.sql", condition);

    }

    /**
     * 項番一覧(期間)保存更新処理(各月の見込)
     * @param condition
     */
    public int deleteNetItem(Map<String, Object> condition) {
        // 更新
        int count = sqlExecutor.executeUpdateSql(em, "/sql/syuKiNetItemTukiTbl/deleteNetItem.sql", condition);
        return count;
    }

    /**
     * 項番一覧(期間)保存更新処理(各月の見込)
     * @param condition
     */
    public int updateNetItem(Map<String, Object> condition) {
        // 更新
        int count = sqlExecutor.executeUpdateSql(em, "/sql/syuKiNetItemTukiTbl/updateNetItem.sql", condition);

        return count;

    }

    /**
     * 項番一覧(期間)保存登録処理(各月の見込)
     * @param condition
     */
    public void insertNetItem(Map<String, Object> condition) {
        // 更新
        int count = sqlExecutor.executeUpdateSql(em, "/sql/syuKiNetItemTukiTbl/insertNetItem.sql", condition);

    }

    /**
     * 見込項番削除処理
     * @param condition
     */
    public void deleteKobanSyuKiNetItem(Map<String, Object> condition) {
        // 更新
        int count = sqlExecutor.executeUpdateSql(em, "/sql/S005/deleteKobanSyuKiNetItem.sql", condition);

    }

    /**
     * 発番引当保存時で取得する見込製番と発番済項番の取得
     * @param condition
     * @return
     */
    public List<SyuKiNetItemTukiTbl> getHikiateItemList(Object condition) {
        logger.info("SyuGeNetItemTblViewFacade#getHikiateItemList");

        List<SyuKiNetItemTukiTbl> list
                = sqlExecutor.getResultList(em, SyuKiNetItemTukiTbl.class, "/sql/syuKiNetItemTukiTbl/selectHikiateOrderItem.sql", condition);

        return list;
    }

    /**
     * 発番引当保存更新処理(各月の見込)
     * @param condition
     */
    public int updateNetItemHikiate(Map<String, Object> condition) {
        // 更新
        int count = sqlExecutor.executeUpdateSql(em, "/sql/syuKiNetItemTukiTbl/updateNetItemHikiate.sql", condition);

        return count;
    }

    /**
     * 発番引当保存登録処理(各月の見込)
     * @param condition
     */
    public int insertNetItemHikiate(Map<String, Object> condition) {
        // 更新
        int count = sqlExecutor.executeUpdateSql(em, "/sql/syuKiNetItemTukiTbl/insertNetItemHikiate.sql", condition);

        return count;
    }

    /**
     * 最新の年月を取得
     * @param params
     * @return
     */
    public String getMaxSyuekiYm(Map<String, Object> params){
        List<StringEntity> list = sqlExecutor.getResultList(em, StringEntity.class, "/sql/syuKiNetItemTukiTbl/selectMaxSyuekiYm.sql", params);

        if (CollectionUtils.isNotEmpty(list)) {
            return list.get(0).getString().trim();
        } else {
            return "";
        }
    }

    /**
     * 売上年月の更新
     * @param _params
     */
    public int changeSyuekiYm(Map<String, Object> _params){
        int count = sqlExecutor.executeUpdateSql(em, "/sql/syuKiNetItemTukiTbl/changeSyuekiYm.sql", _params);
        return count;
    }

    /**
     * @param condition
     * @return
     */
    public List<SyuKiNetItemTukiTbl> selectTargetChangeYmItem(Map<String, Object> condition) {
        logger.info("SyuKiNetItemTukiTblFacade#selectTargetChangeYmItem");

        List<SyuKiNetItemTukiTbl> list = sqlExecutor.getResultList(em, SyuKiNetItemTukiTbl.class, "/sql/syuKiNetItemTukiTbl/selectTargetChangeYmItem.sql", condition);

        return list;
    }

    /**
     * @param condition
     * @return
     */
    public int mergeTargetChangeYmItem(Map<String, Object> condition) {
        // 更新
        int count = sqlExecutor.executeUpdateSql(em, "/sql/syuKiNetItemTukiTbl/mergeTargetChangeYmItem.sql", condition);

        return count;
    }

    /**
     * @param condition
     * @return
     */
    public int updateClearNetItem(Map<String, Object> condition) {
        // 更新
        int count = sqlExecutor.executeUpdateSql(em, "/sql/syuKiNetItemTukiTbl/updateClearNetItem.sql", condition);

        return count;
    }

    /**
     * 2017/12/07 #013 #023 ADD 項番最終見込設定
     * @param condition
     * @return
     */
    public int updateClearNetItemMikomiAll(Map<String, Object> condition) {
        // 更新
        int count = sqlExecutor.executeUpdateSql(em, "/sql/syuKiNetItemTukiTbl/updateClearNetItemMikomiAll.sql", condition);

        return count;
    }

    /**
     * 2017/12/07 #013 #023 ADD 項番最終見込設定
     * @param condition
     * @return
     */
    public int mergeMikomiSet(Map<String, Object> condition) {
        // 更新
        int count = sqlExecutor.executeUpdateSql(em, "/sql/syuKiNetItemTukiTbl/mergeMikomiSet.sql", condition);

        return count;
    }

}
