package jp.co.toshiba.hby.pspromis.syuueki.entity;

import java.io.Serializable;
import java.util.Date;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

/**
 *
 * @author ibayashi
 */
@Entity
@Table(name = "BU_MST")
@NamedQueries({
    @NamedQuery(name = "BuMst.findAll", query = "SELECT b FROM BuMst b"),
    @NamedQuery(name = "BuMst.findById", query = "SELECT b FROM BuMst b WHERE b.id = :id"),
})
public class BuMst implements Serializable {
    private static final long serialVersionUID = 1L;
    @Id
    @Basic(optional = false)
    @NotNull
    @Column(name = "ID")
    private Long id;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 2)
    @Column(name = "DIVISION_CODE")
    private String divisionCode;
    @Size(max = 5)
    @Column(name = "BU_CODE")
    private String buCode;
    @Size(max = 40)
    @Column(name = "BU_NAME")
    private String buName;
    @Size(max = 40)
    @Column(name = "BU_NAME_ENG")
    private String buNameEng;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 5)
    @Column(name = "SBU_CODE")
    private String sbuCode;
    @Size(max = 60)
    @Column(name = "SBU_NAME")
    private String sbuName;
    @Size(max = 40)
    @Column(name = "SBU_NAME_ENG")
    private String sbuNameEng;
    @Column(name = "AVAIL_FROM")
    @Temporal(TemporalType.TIMESTAMP)
    private Date availFrom;
    @Column(name = "AVAIL_TO")
    @Temporal(TemporalType.TIMESTAMP)
    private Date availTo;
    @Basic(optional = false)
    @NotNull
    @Column(name = "CREATED_AT")
    @Temporal(TemporalType.TIMESTAMP)
    private Date createdAt;
    @Size(max = 8)
    @Column(name = "CREATED_BY")
    private String createdBy;
    @Column(name = "UPDATED_AT")
    @Temporal(TemporalType.TIMESTAMP)
    private Date updatedAt;
    @Size(max = 8)
    @Column(name = "UPDATED_BY")
    private String updatedBy;
    @Column(name = "DELETED_AT")
    @Temporal(TemporalType.TIMESTAMP)
    private Date deletedAt;
    @Size(max = 8)
    @Column(name = "DELETED_BY")
    private String deletedBy;
    @Basic(optional = false)
    @NotNull
    @Column(name = "IS_DELETED")
    private short isDeleted;

    public BuMst() {
    }

    public BuMst(Long id) {
        this.id = id;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getDivisionCode() {
        return divisionCode;
    }

    public void setDivisionCode(String divisionCode) {
        this.divisionCode = divisionCode;
    }

    public String getBuCode() {
        return buCode;
    }

    public void setBuCode(String buCode) {
        this.buCode = buCode;
    }

    public String getBuName() {
        return buName;
    }

    public void setBuName(String buName) {
        this.buName = buName;
    }

    public String getBuNameEng() {
        return buNameEng;
    }

    public void setBuNameEng(String buNameEng) {
        this.buNameEng = buNameEng;
    }

    public String getSbuCode() {
        return sbuCode;
    }

    public void setSbuCode(String sbuCode) {
        this.sbuCode = sbuCode;
    }

    public String getSbuName() {
        return sbuName;
    }

    public void setSbuName(String sbuName) {
        this.sbuName = sbuName;
    }

    public String getSbuNameEng() {
        return sbuNameEng;
    }

    public void setSbuNameEng(String sbuNameEng) {
        this.sbuNameEng = sbuNameEng;
    }

    public Date getAvailFrom() {
        return availFrom;
    }

    public void setAvailFrom(Date availFrom) {
        this.availFrom = availFrom;
    }

    public Date getAvailTo() {
        return availTo;
    }

    public void setAvailTo(Date availTo) {
        this.availTo = availTo;
    }

    public Date getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(Date createdAt) {
        this.createdAt = createdAt;
    }

    public String getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    public Date getUpdatedAt() {
        return updatedAt;
    }

    public void setUpdatedAt(Date updatedAt) {
        this.updatedAt = updatedAt;
    }

    public String getUpdatedBy() {
        return updatedBy;
    }

    public void setUpdatedBy(String updatedBy) {
        this.updatedBy = updatedBy;
    }

    public Date getDeletedAt() {
        return deletedAt;
    }

    public void setDeletedAt(Date deletedAt) {
        this.deletedAt = deletedAt;
    }

    public String getDeletedBy() {
        return deletedBy;
    }

    public void setDeletedBy(String deletedBy) {
        this.deletedBy = deletedBy;
    }

    public short getIsDeleted() {
        return isDeleted;
    }

    public void setIsDeleted(short isDeleted) {
        this.isDeleted = isDeleted;
    }

}
