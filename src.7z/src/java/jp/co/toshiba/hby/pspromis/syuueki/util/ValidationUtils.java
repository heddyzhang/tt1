package jp.co.toshiba.hby.pspromis.syuueki.util;

import java.io.UnsupportedEncodingException;
//import java.math.BigDecimal;
import java.text.ParseException;
import org.apache.commons.lang3.StringUtils;

/**
 * バリデーション
 */
public class ValidationUtils {
    
    private static final String checkCharCode = "UTF-8";
    
    /**
     * バイトを取得
     */
    private static byte[] getByte(String val) throws UnsupportedEncodingException {
        if (StringUtils.isNotEmpty(val)) {
            byte[] wk = val.getBytes(checkCharCode);
            return wk;
        }
        return null;
    }
    
    /**
     * 全角文字の文字数を取得
     * @param byteCount
     * @return 
     */
    public static int getZenCharCount(int byteCount) {
        return (byteCount / 3);
    }
    
    /**
     * 必須チェック
     */
    public static boolean isRequired(String val) {
        if (StringUtils.isEmpty(val)) {
            return false;
        }
        return true;
    }
    
    /**
     * 半角桁数チェック(全角文字が混じっていたらエラー)
     */
    public static boolean isHanStringCheck(String val, int charNum) throws UnsupportedEncodingException {
        if (StringUtils.isEmpty(val)) {
            return true;
        }
        
        if (getByte(val).length != val.length()) {
            return false;
        }
        if(!isByteOver(val, charNum)){
            return false;
        }
        return true;
    }

    /**
     * 半角数値チェック
     */
    public static boolean isHanNumberCheck(String val) throws UnsupportedEncodingException {
        if (!val.matches("^[0-9]+$")) {
            return false;
        }
        return true;
    }
    
    /**
     * バイト数チェック
     * @param val
     * @param byteDigits
     * @return 
     * @throws java.io.UnsupportedEncodingException
     */
    public static boolean isByteOver(String val, int byteDigits) throws UnsupportedEncodingException {
        if (StringUtils.isNotEmpty(val)) {
            byte[] wk = getByte(val);
            if (wk.length > byteDigits) {
                return false;
            }
        }
        
        return true;
    }

    /**
     * 日付形式チェック
     */
    public static boolean isDateFormat(String val) {
        try {
            DateUtils.parseDate(val);
        } catch (ParseException pe) {
            return false;
        }
        return true;
    }

    /**
     * 数値チェック(カンマ区切りされていてもokとする)
     * 少数はNG
     * val:チェックする値
     */
    public static boolean isNumberic(String val) {
        try {
            NumberUtils.changeBigDecimal(val);
        } catch (NumberFormatException e){
            return false;
        }
        return true;
    }
}
