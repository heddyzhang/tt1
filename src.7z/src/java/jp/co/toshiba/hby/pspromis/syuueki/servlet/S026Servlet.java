/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package jp.co.toshiba.hby.pspromis.syuueki.servlet;


import javax.inject.Inject;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import jp.co.toshiba.hby.pspromis.syuueki.util.ParameterBinder;
import jp.co.toshiba.hby.pspromis.syuueki.bean.S026Bean;
import jp.co.toshiba.hby.pspromis.syuueki.service.S026Service;

/**
 *
 * @author watabe
 */
@WebServlet(name = "S026", urlPatterns = {"/servlet/S026", "/servlet/S026/*"})
public class S026Servlet extends AbstractServlet {
    /**
     * jsp
     */
    private static final String INDEX_JSP ="S026/s026.jsp" ;
    
    @Inject
    private S026Service s026Service;
    
    @Inject
    private S026Bean s026Bean;
    
    /**
     * 初期表示
     * @param req
     * @param resp
     * @return
     * @throws Exception 
     */
    public String indexAction(HttpServletRequest req, HttpServletResponse resp)
    throws Exception {
        logger.info("s026#indexAction");
        
        ParameterBinder.Bind(s026Bean, req);
        
        s026Service.getUpdateInformation();           
        return INDEX_JSP;
    }
}
