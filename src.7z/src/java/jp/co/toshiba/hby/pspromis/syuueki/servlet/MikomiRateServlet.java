/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package jp.co.toshiba.hby.pspromis.syuueki.servlet;

import java.util.HashMap;
import java.util.Map;
import javax.inject.Inject;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import jp.co.toshiba.hby.pspromis.common.exception.PspRunTimeExceotion;
import jp.co.toshiba.hby.pspromis.syuueki.bean.MikomiRateBean;
import jp.co.toshiba.hby.pspromis.syuueki.bean.S009Bean;
import jp.co.toshiba.hby.pspromis.syuueki.service.MikomiRateService;
import jp.co.toshiba.hby.pspromis.syuueki.util.ParameterBinder;

/**
 * PS-Promis収益管理システム
 * 見込レートマスタ詳細 Servlet
 * @author 
 */
@WebServlet(name="MikomiRate", urlPatterns={"/servlet/MikomiRate", "/servlet/MikomiRate/*"})
public class MikomiRateServlet extends AbstractServlet {

    /**
     * jsp
     */
    private static final String INDEX_JSP = "S009/rateList.jsp";

    /**
     * 使用serviceクラスをinjection(CDI)<br>
     * InjectアノテーションよりAPサーバー(Glassfish)側で自動的にインスタンス作成(new)される。<br>
     * service側はステートレスセッションbeanにするため、Statelessアノテーションをつけておくこと。<br>
     */
    @Inject
    private MikomiRateService mikomiRateService;

    /**
     * パラメータ格納クラスをinjection(CDI)<br>
     * InjectアノテーションよりAPサーバー(Glassfish)側で自動的にインスタンス作成(new)される。<br>
     */
    @Inject
    private MikomiRateBean mikomiRateBean;
    
    /**
     * 保存処理
     * @param req
     * @param resp
     * @return
     * @throws Exception 
     */
    public String saveAction(HttpServletRequest req, HttpServletResponse resp)
    throws Exception {
        logger.info("M001Servlet#deleteAction");
        
        ParameterBinder.Bind(mikomiRateBean, req);
        
        int flg = 0;
        Map<String, Object> resJson = new HashMap<>();
        
        // サービスの実行(トランザクションの単位にもなる)
        try {
            mikomiRateService.save();
        } catch (RuntimeException e) {
            Throwable rte = null;
            rte = e.getCause();
            if (rte.getCause() != null) {
                rte = e.getCause().getCause();
            }
            if (rte instanceof PspRunTimeExceotion) {
                flg = 9;
            } else {
                throw e;
            }
        }

        resJson.put("flg", flg);
        resJson.put("messageInfo", mikomiRateBean.getMessageInfo());
        resopnseDecodeJson(resp, resJson);

        return null;
    }    
}
