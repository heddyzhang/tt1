package jp.co.toshiba.hby.pspromis.syuueki.facade;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.ejb.Stateless;
import javax.interceptor.Interceptors;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import jp.co.toshiba.hby.pspromis.syuueki.entity.SyuGeRirekiInfoTbl;
import jp.co.toshiba.hby.pspromis.syuueki.interceptor.TranceInterceptor;

/**
 *
 * @author ibayashi
 */
@Stateless
@Interceptors({TranceInterceptor.class})
public class SyuGeRirekiInfoTblFacade extends AbstractFacade<SyuGeRirekiInfoTbl> {
    @PersistenceContext(unitName = jp.co.toshiba.hby.pspromis.syuueki.util.ConstantString.syuuekiDataSourceName)
    private EntityManager em;

    @Override
    protected EntityManager getEntityManager() {
        return em;
    }

    public SyuGeRirekiInfoTblFacade() {
        super(SyuGeRirekiInfoTbl.class);
    }

    /**
     * PKから履歴情報を取得
     * @param ankenId
     * @param rirekiId
     * @return 
     */
    public SyuGeRirekiInfoTbl findPk(String ankenId, Integer rirekiId) {
        Map<String, Object> condition = new HashMap<>();
        condition.put("ankenId", ankenId);
        condition.put("rirekiId", rirekiId);
        SyuGeRirekiInfoTbl entity
                = sqlExecutor.getSingleResult(em, SyuGeRirekiInfoTbl.class, "/sql/selectListRireki.sql", condition);
        
        /*
        TypedQuery query = em.createNamedQuery("findPk", SyuGeRirekiInfoTbl.class);
        query.setParameter("ankenId", ankenId);
        query.setParameter("rirekiId", rirekiId);
        
        SyuGeRirekiInfoTbl entity = (SyuGeRirekiInfoTbl)query.getSingleResult();
        */
        return entity;
    }

    /**
     * 履歴一覧を取得
     * @param condition
     * @return List<SyuGeRirekiInfoTbl> 
     */
    public List<SyuGeRirekiInfoTbl> getList(Object condition) {
          
        // SQL文を発行
        List<SyuGeRirekiInfoTbl> list
                = sqlExecutor.getResultList(em, SyuGeRirekiInfoTbl.class, "/sql/selectListRireki.sql", condition);
        
        return list;
    }
}
