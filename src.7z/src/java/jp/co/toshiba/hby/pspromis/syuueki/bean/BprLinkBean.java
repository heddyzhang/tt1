package jp.co.toshiba.hby.pspromis.syuueki.bean;

import javax.enterprise.context.RequestScoped;
import javax.inject.Named;
import java.math.BigDecimal;
import lombok.Getter;
import lombok.Setter;

/**
 * (原子力)関連の各システム連携ボタンの表示情報
 * @author
 */
@Named(value = "bprLinkBean")
@RequestScoped
@Getter @Setter
public class BprLinkBean extends AbstractBean {

    // ボタン表示条件(決裁/見積情報)
    private boolean isKessaiEstButton = false;
    
    // ボタン表示条件(ecas決裁情報)
    private boolean isEcasKessaiButton = false;
    
    // ボタン表示条件((原子力)収支表)
    private boolean isSyushiButton = false;
    
    // ボタン表示条件((原子力)売上指示)
    private boolean isUriageShijiButton = false;
            
    // ボタン表示条件(発番連携)
    private boolean isHatRenkeiButton = false;

    private String procId;
    
    private String linkKbn;
    
    private String targetUrl;
 
    private BigDecimal uriageSeq;
    
    private BigDecimal keiyakuSeq;
    
    private String errorMessage;
}
