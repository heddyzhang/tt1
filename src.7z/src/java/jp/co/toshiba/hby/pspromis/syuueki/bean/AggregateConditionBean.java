package jp.co.toshiba.hby.pspromis.syuueki.bean;

import java.io.Serializable;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.HashMap;
import java.util.Set;
import java.util.HashSet;
import javax.enterprise.context.SessionScoped;
import javax.inject.Named;
import jp.co.toshiba.hby.pspromis.syuueki.enums.Label;
import org.apache.commons.lang3.StringUtils;
import lombok.Getter;
import lombok.Setter;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 *
 * @author rnomura
 */
@Named(value = "aggregateConditionBean")
@SessionScoped
@Getter @Setter
public class AggregateConditionBean extends AbstractBean implements Serializable {
    
    private static final Logger log = LoggerFactory.getLogger(AggregateConditionBean.class);
    
    /**
     * 検索条件：事業部 
     */
    private String divisionCode;
    
    /**
     * 検索条件：売上基準(進行基準)
     */
    private String[] salesClass;

    /**
     * 検索条件：表示単位
     */
    private String dispKbn;
    
    /**
     * 検索条件：営業担当
     */
    private String eigyoJobGrId;
    
    /**
     * 検索条件：主管課(電力ジ対応で追加)
     */
    private String syukanJobGrId;
    
    /**
     * 検索条件：チームコード
     */
    private String myTeamFlg;

    /**
     * 検索条件：チームコード(プルダウン)
     */
    private String myTeamCd;

    /**
     * 検索条件：チームコード(本社)
     */
    private String teamCode;
    
    /**
     * 検索条件：チームコード(販売C)
     */
    private String hanbaiCode;
    
    /**
     * 検索条件：対象データ(From)
     */
    private String targetFrom;
    
    /**
     * 検索条件：対象データ(To)
     */
    private String targetTo;

    /**
     * 検索条件・見積種類
     */
    private String[] mitumoriKbn;
    
    /**
     * buコード
     */
    private String[] buId;

    /**
     * サブBUコード
     */
    private String[] subBuId;
    
    /**
     * 集計設定：1次集計単位
     */
    private String primaryUnit;
    
    /**
     *  集計設定：2次集計単位
     */
    private String secondaryUnit;
    
    /**
     * 集計設定：横軸集計
     */
    private String[] yokozikuAgg;
    
    /**
     * 検索条件:(受注/売上/回収)年月の検索条件を参照するか？(行う:1 行わない:0)
     */
    private String conditionSyuekiYmFlg = "0";

    /**
     * 検索条件:(受注/売上/回収)年月from
     */
    private String conditionSyuekiYmFrom;
    
    /**
     * 検索条件:(受注/売上/回収)年月to
     */
    private String conditionSyuekiYmTo;
    
    /**
     * 検索条件:(受注/売上/回収)期(Q)指定の検索条件を参照するか？(行う:1 行わない:0)
     */
    private String conditionQuarterFlg = "0";
    
    /**
     * 検索条件:(受注/売上/回収)期(Q)指定(YYYY06 or 09 or 12 or 03 + 'Q')from
     */
    private String conditionQuarterFrom;
    
    /**
     * 検索条件:(受注/売上/回収)期(Q)指定(YYYY06 or 09 or 12 or 03 + 'Q')to
     */
    private String conditionQuarterTo;
    
    /**
     * 検索条件:(受注/売上/回収)上期/下期(K)指定の検索条件を参照するか？(行う:1 行わない:0)
     */
    //private String conditionPeriodFlg = "0";
    
    /**
     * 検索条件:(受注/売上/回収)上期/下期(K)指定(YYYY09 or 03 + 'K' or 'S')from
     */
    private String conditionPeriodFrom;
    
    /**
     * 検索条件:(受注/売上/回収)期(Q)指定(YYYY09 or 03 + 'K' or 'S')from
     */
    private String conditionPeriodTo;
    
    /**
     * 検索条件で、年月期間の範囲でデータが存在するかをチェックするか？(チェックする:1 チェックしない:0)
     * ※横軸集計で期間範囲(年月,Q,期,年度)の何れかを指定された場合に立つ
     */
    private String conditionPeriodFlg = "0";
    
    /**
     * 検索条件:(受注/売上/回収)総合計データが存在するかをチェックするか？(チェックする:1 チェックしない:0)
     * ※横軸集計で期間範囲(年月,Q,期,年度)を指定しないで、横軸集計:"合計"を選択した場合に立つ
     */
    private String conditionGokeiFlg = "0";
    
    /**
     * 検索条件:(受注/売上)最終見込データが存在するかをチェックするか？(チェックする:1 チェックしない:0)
     * ※横軸集計で期間範囲(年月,Q,期,年度)を指定しないで、横軸集計:"最終見込"を選択した場合に立つ
     */
    private String conditionFmFlg = "0";

    /**
     * 集計設定：出力項目
     */
    private String[] outputItem;
    
    /**
     *  集計設定：出力単位
     */
    private String outputUnit;
    
    /**
     *  集計設定：比較データ(テキストボックス)
     */
    private String comparisonData;
    
    /**
     *  集計設定：比較データ(セレクトボックス)
     */
    private String selComparisonData;

    /**
     * 集計設定：表示単位
     */
    private String jpyUnit;
    
    /**
     * 比較データラジオボタン
     */
    private String comparison;
    
    /**
     * 検索結果：今回・前回・差　部分ラベルリスト
     */
    private List<String> comparisonLabelList;
    
    /**
     * 検索結果：受注・売上・回収　部分ラベルリスト
     */
    private List<String> outputLabelList;
    
    /**
     *  検索結果:横軸ヘッダー部リスト
     */
    private List<Map<String, Object>> yokozikuList;
    
    /**
     *  検索条件：対象データ「期」(from)selectbox
     */
    private String targetFromKi;
    
    /**
     *  検索条件：対象データ「期」(to)selectbox
     */
    private String targetToKi;
    
    /**
     *  検索条件：対象データ「期」(from)textbox
     */
    private String targetFromKiYm;
    
    /**
     *  検索条件：対象データ「期」(to)textbox
     */
    private String targetToKiYm;
    
    /**
     *  検索条件：対象データ「年度」(from)
     */
    private String targetFromNendo;
    
    /**
     *  検索条件：対象データ「年度」(to)
     */
    private String targetToNendo;
    
    /**
     * 検索結果：2次集計rowspan
     */
    private int secondaryRowspan;
    
    /**
     * 検索結果:今回前回部のrowspan 
     */
    private int comparisonRowspan;

    /**
     * 処理対象案件の事業部が(原子力)タイプであるか?
     */
    private boolean isNuclearDivision = false;

    //20180302 原価回収基準対応　ADD     
     /**
     * 検索条件・売上基準(原価回収基準)
     */
    private String salesClassGenka;
    
    /**
     * 一次集計の内訳情報を展開するためのkeyを詰め込んだmap
     */
    private Map<String, Set<String>> dispKeyInfo;


    public List<String> getComparisonLabelList(){
        return comparisonLabelList;
    }
    
    public void setComparisonLabelList(List<String> comparisonLabelList){
        this.comparisonLabelList = comparisonLabelList;
    }
    
    public List<String> getOutputLabelList(){
        return outputLabelList;
    }
    
    public void setOutputLabelList(List<String> outputLabelList){
        this.outputLabelList = outputLabelList;
    }
    
    public List<Map<String, Object>> getYokozikuList(){
        return yokozikuList;
    }
    
    public void setYokozikuList(List<Map<String, Object>> yokozikuList){
        this.yokozikuList = yokozikuList;
    }
    
    /**
     * テーブル横サイズを取得
     */
    public int getTableWidthSize() {
        int tableWidthSize = 0;
        if (yokozikuList != null && !yokozikuList.isEmpty()) {
            int baseSize = 120 + 1 + 120 + 1 + 120 + 1 + 50;
            tableWidthSize = baseSize * (yokozikuList.size());
        }
        return tableWidthSize;
    }

    /**
     * ラベルからKEYを判断
     * @param label
     * @return 
     */
    public String keyDecision(String label){
        String key = "";
        
        if(label.equals(Label.now.getLabel())){
            key = "NOW";
        }
        if(label.equals(Label.before.getLabel())){
            key = "BEF";
        }
        if(label.equals(Label.diff2.getLabel())){
            key = "DIF";
        }
        
        if(label.equals(Label.jyuchu.getLabel())){
            key = "J";
        }
        if(label.equals(Label.uriage.getLabel())){
            key = "U";
        }
        if(label.equals(Label.kaisyu.getLabel())){
            key = "K";
        }
        
        return key;
    }
    
    public String getHeadTargetData(){
        String data = "";
        
        if(Arrays.asList(this.getYokozikuAgg()).contains("0")){
            data = this.targetFrom + " ～ " + this.targetTo;
            
        } else if(Arrays.asList(this.getYokozikuAgg()).contains("1") || Arrays.asList(this.getYokozikuAgg()).contains("2")){
            data = this.targetFromKiYm + Label.year.getLabel();
            if(this.targetFromKi.equals("K")){
                data += Label.firstHalf.getLabel();
            } else {
                data += Label.secondHalf.getLabel();
            }
            
            data += " ～ " + this.targetToKiYm + Label.year.getLabel();
            if(this.targetToKi.equals("K")){
                data += Label.firstHalf.getLabel();
            } else {
                data += Label.secondHalf.getLabel();
            }
            
        } else if(Arrays.asList(this.getYokozikuAgg()).contains("3")){
            data = this.targetFromNendo + Label.nendo.getLabel();
            data += " ～ " + this.targetToNendo + Label.nendo.getLabel();
        }
        
        return data;
    }
    
    public String getHeadOutputItems(){
        String item = "";
        
        if(Arrays.asList(this.outputItem).contains("0")){
            item = item + Label.jyuchu.getLabel() + " ";
        }
        if(Arrays.asList(this.outputItem).contains("1")){
            item = item + Label.uriage.getLabel() + " ";
        }
        if(Arrays.asList(this.outputItem).contains("2")){
            item = item + Label.kaisyu.getLabel() + " ";
        }
        
        return item;
    }
    
    /**
     * 売上展開のデータを出力するか？
     * @return 
     */
    public String getUriageDataFlg() {
        String uriageDataFlg = "0";
        if(Arrays.asList(this.outputItem).contains("1")){
            uriageDataFlg = "1";
        }
        return uriageDataFlg;
    }
    
    /**
     * 受注展開のデータを出力するか？
     * @return 
     */
    public String getJyuchuDataFlg() {
        String jyuchuDataFlg = "0";
        if(Arrays.asList(this.outputItem).contains("0")){
            jyuchuDataFlg = "1";
        }
        return jyuchuDataFlg;
    }
    
    /**
     * 回収展開のデータを出力するか？
     * @return 
     */
    public String getKaisyuDataFlg() {
        String kaisyuDataFlg = "0";
        if(Arrays.asList(this.outputItem).contains("2")){
            kaisyuDataFlg = "1";
        }
        return kaisyuDataFlg;
    }
    
    /**
     * 集計行のclassを判断する
     * @param aggLevel 
     * @param comparison
     * @param num 
     * @return 
     */
    public String getCellStyle(int aggLevel, String comparison, int num) {
        String style = ""; 
        
        // 総計行
        if(aggLevel == 0){
            style = "soukei";
        }
        // 第1次集計が営業部課(0)/主管課(2)の場合
        //if(this.primaryUnit.equals("0") || this.primaryUnit.equals("2")){
        if (isPrimaryUnitBuka()) {
            if(aggLevel == 1 || (aggLevel == 2 && num ==0)){
                style = "summary";
            }
            if(aggLevel == 2 && num != 0){
                style = "primary";
            }
        //if(this.primaryUnit.equals("1")){

        } else {
            if(aggLevel == 1 || (aggLevel == 2 && num == 0)){
                //style = "primary";
                style = "summary";
            }
        }
        
        if(comparison.equals(Label.before.getLabel())){
            style = "before";
        }
        if(comparison.equals(Label.diff2.getLabel())){
            style = "diff";
        }
        
        return style;
    }
    
    public String getCellStyle(int aggLevel, String comparison) {
        return getCellStyle(aggLevel, comparison, 1);
    }
    
    /**
     * 一次集計キーが部課コード関連(営業部課(0)/主管課(2))であるかをチェックする
     * (部課コード関連の場合は部と課で集計レベルを分けるので、このメソッドで各ロジックの判定を行う)
     * 
     * 今後、一次集計キーに部課コード関連の項目が増えた場合、このメソッド内に判定条件を追加すること
     */
    public boolean isPrimaryUnitBuka() {
        if (this.primaryUnit.equals("0") || this.primaryUnit.equals("2")) {
            return true;
        }
        return false;
    }

    /**
     * 二次集計キーが部課コード関連(営業部課(0)/主管課(2))であるかをチェックする
     * (部課コード関連の場合は部と課で集計レベルを分けるので、このメソッドで各ロジックの判定を行う)
     * 
     * 今後、二次集計キーに部課コード関連の項目が増えた場合、このメソッド内に判定条件を追加すること
     */
    public boolean isSecondaryUnitBuka() {
        if (this.secondaryUnit.equals("0") || this.secondaryUnit.equals("2")) {
            return true;
        }
        return false;
    }

}
