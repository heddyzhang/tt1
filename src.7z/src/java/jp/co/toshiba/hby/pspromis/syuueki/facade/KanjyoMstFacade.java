package jp.co.toshiba.hby.pspromis.syuueki.facade;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.ejb.Stateless;
import javax.inject.Inject;
import javax.interceptor.Interceptors;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import jp.co.toshiba.hby.pspromis.syuueki.entity.KanjyoMst;
import jp.co.toshiba.hby.pspromis.syuueki.entity.StringEntity;
import jp.co.toshiba.hby.pspromis.syuueki.interceptor.TranceInterceptor;
import jp.co.toshiba.hby.pspromis.syuueki.util.Utils;
import org.apache.commons.collections.CollectionUtils;

/**
 *
 * @author ibayashi
 */
@Stateless
@Interceptors({TranceInterceptor.class})
public class KanjyoMstFacade extends AbstractFacade<KanjyoMst> {
    @PersistenceContext(unitName = jp.co.toshiba.hby.pspromis.syuueki.util.ConstantString.syuuekiDataSourceName)
    private EntityManager em;
    
    @Override
    protected EntityManager getEntityManager() {
        return em;
    }

    public KanjyoMstFacade() {
        super(KanjyoMst.class);
    }

    /**
     * 現在の勘定月を取得
     * @param salesClass 工事進行基準フラグ(一般：0、進行基準：1)
     * @return 
     */
    public String getNowKanjoDate(String salesClass) {
        // STEP3
        // 一般/進行基準案件によって、勘定月を参照するマスタを切り替える(一般/進行で、勘定月の切り替えタイミングが異なる)
        Map<String, Object> condition = new HashMap<>(); 
        condition.put("salesClass", salesClass);
        
        //KanjyoMst entity = sqlExecutor.getSingleResult(em, KanjyoMst.class, "/sql/kanjyoMst/selectNowKanjyo.sql", condition);

        //return entity.getKanjyoMh();
        
        StringEntity kanjo = null;
        List<StringEntity> list = sqlExecutor.getResultList(em, StringEntity.class, "/sql/kanjyoMst/selectNowKanjyoMh.sql", condition);
        
        if(CollectionUtils.isNotEmpty(list)){
            return list.get(0).getString().trim();
        } else {
            return "";
        }
        
    }
}
