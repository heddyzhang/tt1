package jp.co.toshiba.hby.pspromis.syuueki.bean;

import java.math.BigDecimal;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.enterprise.context.RequestScoped;
import javax.inject.Named;
import jp.co.toshiba.hby.pspromis.syuueki.entity.SyuWfControlTbl;
import jp.co.toshiba.hby.pspromis.syuueki.util.ConstantString;
import lombok.Getter;
import lombok.Setter;

/**
 *
 * @author ibayashi
 */
@Named(value = "s014Bean")
@RequestScoped
@Getter @Setter
public class S014Bean {

    /**
     * パラメータ・事業部
     */
    private String divisionCode;

    /**
     * パラメータ・WFグループコード
     */
    private String groupCode;
   
    /**
     * パラメータ・売上基準
     */
    private String salesClass;
    
    /**
     * パラメータ・確定月
     */
    private String kanjyoYm;

    /**
     * 予算時確定月
     */
    //private String yosanKanjyoYm;

    /**
     * 画面表示の実績・見込判定用の月
     */
    private String dispBaseKanjyoYm;
    
    /**
     * パラメータ・本社支社区分
     */
    private String honsyaShisyaKbn;

    /**
     * パラメータ・チームコード
     */
    private String teamCode;

    /**
     * パラメータ・種別
     */
    private String syubetsu;

    /**
     * C_BUKAコード
     */
    private String cBukaCode;

    /**
     * パラメータ・確定月
     */
    private Date nextKanjyoYmData;

    /**
     * 営業部門名称
     */
    private String tantoNm;
    
    /**
     * タイトル
     */
    private String rirekiTitle;
    
    /**
     * 履歴ID
     */
    private Long rirekiId;
    
    /**
     * 履歴Flg
     */
    private String rirekiFlg;
    
    /**
     * 状態
     */
    private String status;
    
    /**
     * 起草日時
     */
    private Date kisoAt;
    
    /**
     * 起草者名
     */
    private String kisoName;
    
    /**
     * 調査日時
     */
    private Date chosaAt;
    
    /**
     * 調査者名
     */
    private String chosaName;
    
    /**
     * 承認/確認日時
     */
    private Date syoninAt;
    
    /**
     * 承認/確認者名
     */
    private String syoninName;

    /**
     * 表示単位(1:円 2:千円 3:百万円)
     */
    private String jpyUnit = "1";
    
    /**
     * TOTAL 1Q目のラベル表記
     */
    private String label1Q;
    
    /**
     * TOTAL 2Q目のラベル表記
     */
    private String label2Q;
    
    /**
     * TOTAL・SP(前月確定) 1Q目
     */
    private BigDecimal totalSp1Q;
    
    /**
     * TOTAL・NET(前月確定) 1Q目
     */
    private BigDecimal totalNet1Q;
    
    /**
     * TOTAL・SP(前月確定) 2Q目
     */
    private BigDecimal totalSp2Q;
    
    /**
     * TOTAL・NET(前月確定) 2Q目
     */
    private BigDecimal totalNet2Q;
    
    /**
     * TOTAL・SP(前月確定) 期計
     */
    private BigDecimal totalSpKi;
    
    /**
     * TOTAL・NET(前月確定) 期計
     */
    private BigDecimal totalNetKi;
    
    /**
     * TOTAL・SP(前月確定) 合計
     */
    private BigDecimal totalSpG;
    
    /**
     * TOTAL・NET(前月確定) 合計
     */
    private BigDecimal totalNetG;
    

    /**
     * TOTAL・前月確定年月
     */
    private String kanjyoYmBefore;

    /**
     * TOTAL・SP(前月確定) 1Q目
     */
    private BigDecimal totalSp1QBefore;
    
    /**
     * TOTAL・NET(前月確定) 1Q目
     */
    private BigDecimal totalNet1QBefore;
    
    /**
     * TOTAL・SP(前月確定) 2Q目
     */
    private BigDecimal totalSp2QBefore;
    
    /**
     * TOTAL・NET(前月確定) 2Q目
     */
    private BigDecimal totalNet2QBefore;
    
    /**
     * TOTAL・SP(前月確定) 期計
     */
    private BigDecimal totalSpKiBefore;
    
    /**
     * TOTAL・NET(前月確定) 期計
     */
    private BigDecimal totalNetKiBefore;
    
    /**
     * TOTAL・SP(前月確定) 合計
     */
    private BigDecimal totalSpGBefore;
    
    /**
     * TOTAL・NET(前月確定) 合計
     */
    private BigDecimal totalNetGBefore;
    
    
    /**
     * TOTAL・SP(前月確定) 1Q目 差
     */
    private BigDecimal totalSp1QDiff;
    
    /**
     * TOTAL・NET(前月確定) 1Q目 差
     */
    private BigDecimal totalNet1QDiff;
    
    /**
     * TOTAL・SP(前月確定) 2Q目 差
     */
    private BigDecimal totalSp2QDiff;
    
    /**
     * TOTAL・NET(前月確定) 2Q目 差
     */
    private BigDecimal totalNet2QDiff;
    
    /**
     * TOTAL・SP(前月確定) 期計 差
     */
    private BigDecimal totalSpKiDiff;
    
    /**
     * TOTAL・NET(前月確定) 期計 差
     */
    private BigDecimal totalNetKiDiff;
    
    /**
     * TOTAL・SP(前月確定) 合計 差
     */
    private BigDecimal totalSpGDiff;
    
    /**
     * TOTAL・NET(前月確定) 合計 差
     */
    private BigDecimal totalNetGDiff;
    
    /**
     * 対象物件の合計データ
     */
    private Map<String, Object> totalInfo;

    /**
     * 対象物件一覧データ
     */
    private List<Map<String, Object>> bukkenList;
    
    /**
     * 表示対象月の配列
     */
    private String syuekiYmAry[];
    
    /**
     * 表示対象期間の四半期(1Q目)
     */
    private String syueki1Q;

    /**
     * 表示対象期間の四半期(2Q目)
     */
    private String syueki2Q;

    /**
     * 表示対象期間の期
     */
    private String syuekiKi;
    
    /**
     * 確定(＋解除)権限FLG
     * 1:権限あり 0:権限無し -1:現在の勘定月でないため確定(＋解除)不可能
     */
    private Integer kakuteiFlg = 0;
    
    /**
     * 提出(＋解除)権限FLG
     * 1:権限あり 0:権限無し -1:現在の勘定月でないため確定(＋解除)不可能
     */
    private Integer teishutsuActionFlg = 0;

    /**
     * 支社(本社)確定フラグ
     */
    //private boolean shisyaKakuteiFlg = false;

    /**
     * 本社確定フラグ
     */
    private boolean honsyaKakuteiFlg = false;
    
    /**
     * 確定(解除)アクション可能FLG
     */
    private boolean kakuteiActionFlg = false;

    /**
     * 確定ボタン表示フラグ
     */
    private boolean kakuteiBtnFlg = false;

    /**
     * 確定解除ボタン表示フラグ
     */
    private boolean kakuteiKaijoBtnFlg = false;

    /**
     * 提出用作成ボタン表示フラグ
     */
    private boolean teishutsuBtnFlg = false;
    
    /**
     * 提出用解除ボタン表示フラグ
     */
    private boolean teishutsuKaijoBtnFlg = false;

    /**
     * ステータス区分(K=起草 C=調査 S=承認/確認 H=否認)
     */
    private String statusKbn;
    
    /**
     * 提出処理Flg("1"の場合は提出用作成処理)
     */
    private String teishutsuFlg;

    /**
     * コメント
     */
    private String comment;

    /**
     * 選択チームコード
     */
    private String concatTeamCode;

    /**
     * コメント子画面のタイトル
     */
    private String commentTitle;

    /**
     * コメント子画面のコメント欄一覧
     */
    List<Map<String, Object>> commentList;
    
     /**
      * コメント入力画面 確認メッセージ
      */
    private String commentConfirmMessage;

    /**
     * コメント子画面の確定状況確認一覧
     */
    private List<SyuWfControlTbl> kakuteiJokyoList;

    /**
     * ダウンロード実行FLG(1:ダウンロード 0:その他処理)
     */
    private String downloadFlg;

    /**
     * 当期・前期FLG(1:前期)
     */
    private String beforKiFlg;

    /**
     * 検索対象にする勘定年月
     */
    private String baseKanjyoYm;
    
    /**
     * 対象案件が全て確定済みかどうか?
     * 1:全案件確定済 0:未確定案件あり
     */
    private String allAnkenKakuteiFlg = "0";

    /**
     * 一部確定済だが、一部未確定データが存在するか？
     */
    //private String partNoFixFlg = "0";
    
    
    private List< HashMap<String,String>> kaijoList;
        
    
    private String honsyaKakuteiStatus;
    
    /**
     * 画面ID
     */
    private String dispId;
    
    /**
     * Creates a new instance of S001Bean
     */
    public S014Bean() {
    }

    public String getDivisionCode() {
        return divisionCode;
    }

    public void setDivisionCode(String divisionCode) {
        this.divisionCode = divisionCode;
    }

    public String getGroupCode() {
        return groupCode;
    }

    public void setGroupCode(String groupCode) {
        this.groupCode = groupCode;
    }

    public String getSalesClass() {
        return salesClass;
    }

    public void setSalesClass(String salesClass) {
        this.salesClass = salesClass;
    }

    public String getKanjyoYm() {
        return kanjyoYm;
    }

    public void setKanjyoYm(String kanjyoYm) {
        this.kanjyoYm = kanjyoYm;
    }

//    public String getYosanKanjyoYm() {
//        return yosanKanjyoYm;
//    }
//
//    public void setYosanKanjyoYm(String yosanKanjyoYm) {
//        this.yosanKanjyoYm = yosanKanjyoYm;
//    }

    public String getHonsyaShisyaKbn() {
        return honsyaShisyaKbn;
    }

    public void setHonsyaShisyaKbn(String honsyaShisyaKbn) {
        this.honsyaShisyaKbn = honsyaShisyaKbn;
    }

    public String getTeamCode() {
        return teamCode;
    }

    public void setTeamCode(String teamCode) {
        this.teamCode = teamCode;
    }

    public String getSyubetsu() {
        return syubetsu;
    }

    public void setSyubetsu(String syubetsu) {
        this.syubetsu = syubetsu;
    }

    public String getcBukaCode() {
        return cBukaCode;
    }

    public void setcBukaCode(String cBukaCode) {
        this.cBukaCode = cBukaCode;
    }

    public String getTantoNm() {
        return tantoNm;
    }

    public void setTantoNm(String tantoNm) {
        this.tantoNm = tantoNm;
    }

    public String getRirekiTitle() {
        return rirekiTitle;
    }

    public void setRirekiTitle(String rirekiTitle) {
        this.rirekiTitle = rirekiTitle;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public Date getKisoAt() {
        return kisoAt;
    }

    public void setKisoAt(Date kisoAt) {
        this.kisoAt = kisoAt;
    }

    public String getKisoName() {
        return kisoName;
    }

    public void setKisoName(String kisoName) {
        this.kisoName = kisoName;
    }

    public Date getChosaAt() {
        return chosaAt;
    }

    public void setChosaAt(Date chosaAt) {
        this.chosaAt = chosaAt;
    }

    public String getChosaName() {
        return chosaName;
    }

    public void setChosaName(String chosaName) {
        this.chosaName = chosaName;
    }

    public Date getSyoninAt() {
        return syoninAt;
    }

    public void setSyoninAt(Date syoninAt) {
        this.syoninAt = syoninAt;
    }

    public String getSyoninName() {
        return syoninName;
    }

    public void setSyoninName(String syoninName) {
        this.syoninName = syoninName;
    }

    public BigDecimal getTotalSp1Q() {
        return totalSp1Q;
    }

    public void setTotalSp1Q(BigDecimal totalSp1Q) {
        this.totalSp1Q = totalSp1Q;
    }

    public BigDecimal getTotalNet1Q() {
        return totalNet1Q;
    }

    public void setTotalNet1Q(BigDecimal totalNet1Q) {
        this.totalNet1Q = totalNet1Q;
    }

    public BigDecimal getTotalSp2Q() {
        return totalSp2Q;
    }

    public void setTotalSp2Q(BigDecimal totalSp2Q) {
        this.totalSp2Q = totalSp2Q;
    }

    public BigDecimal getTotalNet2Q() {
        return totalNet2Q;
    }

    public void setTotalNet2Q(BigDecimal totalNet2Q) {
        this.totalNet2Q = totalNet2Q;
    }

    public BigDecimal getTotalSpKi() {
        return totalSpKi;
    }

    public void setTotalSpKi(BigDecimal totalSpKi) {
        this.totalSpKi = totalSpKi;
    }

    public BigDecimal getTotalNetKi() {
        return totalNetKi;
    }

    public void setTotalNetKi(BigDecimal totalNetKi) {
        this.totalNetKi = totalNetKi;
    }

    public BigDecimal getTotalSpG() {
        return totalSpG;
    }

    public void setTotalSpG(BigDecimal totalSpG) {
        this.totalSpG = totalSpG;
    }

    public BigDecimal getTotalNetG() {
        return totalNetG;
    }

    public void setTotalNetG(BigDecimal totalNetG) {
        this.totalNetG = totalNetG;
    }

    public BigDecimal getTotalSp1QBefore() {
        return totalSp1QBefore;
    }

    public void setTotalSp1QBefore(BigDecimal totalSp1QBefore) {
        this.totalSp1QBefore = totalSp1QBefore;
    }

    public BigDecimal getTotalNet1QBefore() {
        return totalNet1QBefore;
    }

    public void setTotalNet1QBefore(BigDecimal totalNet1QBefore) {
        this.totalNet1QBefore = totalNet1QBefore;
    }

    public BigDecimal getTotalSp2QBefore() {
        return totalSp2QBefore;
    }

    public void setTotalSp2QBefore(BigDecimal totalSp2QBefore) {
        this.totalSp2QBefore = totalSp2QBefore;
    }

    public BigDecimal getTotalNet2QBefore() {
        return totalNet2QBefore;
    }

    public void setTotalNet2QBefore(BigDecimal totalNet2QBefore) {
        this.totalNet2QBefore = totalNet2QBefore;
    }

    public BigDecimal getTotalSpKiBefore() {
        return totalSpKiBefore;
    }

    public void setTotalSpKiBefore(BigDecimal totalSpKiBefore) {
        this.totalSpKiBefore = totalSpKiBefore;
    }

    public BigDecimal getTotalNetKiBefore() {
        return totalNetKiBefore;
    }

    public void setTotalNetKiBefore(BigDecimal totalNetKiBefore) {
        this.totalNetKiBefore = totalNetKiBefore;
    }

    public BigDecimal getTotalSpGBefore() {
        return totalSpGBefore;
    }

    public void setTotalSpGBefore(BigDecimal totalSpGBefore) {
        this.totalSpGBefore = totalSpGBefore;
    }

    public BigDecimal getTotalNetGBefore() {
        return totalNetGBefore;
    }

    public void setTotalNetGBefore(BigDecimal totalNetGBefore) {
        this.totalNetGBefore = totalNetGBefore;
    }

    public BigDecimal getTotalSp1QDiff() {
        return totalSp1QDiff;
    }

    public void setTotalSp1QDiff(BigDecimal totalSp1QDiff) {
        this.totalSp1QDiff = totalSp1QDiff;
    }

    public BigDecimal getTotalNet1QDiff() {
        return totalNet1QDiff;
    }

    public void setTotalNet1QDiff(BigDecimal totalNet1QDiff) {
        this.totalNet1QDiff = totalNet1QDiff;
    }

    public BigDecimal getTotalSp2QDiff() {
        return totalSp2QDiff;
    }

    public void setTotalSp2QDiff(BigDecimal totalSp2QDiff) {
        this.totalSp2QDiff = totalSp2QDiff;
    }

    public BigDecimal getTotalNet2QDiff() {
        return totalNet2QDiff;
    }

    public void setTotalNet2QDiff(BigDecimal totalNet2QDiff) {
        this.totalNet2QDiff = totalNet2QDiff;
    }

    public BigDecimal getTotalSpKiDiff() {
        return totalSpKiDiff;
    }

    public void setTotalSpKiDiff(BigDecimal totalSpKiDiff) {
        this.totalSpKiDiff = totalSpKiDiff;
    }

    public BigDecimal getTotalNetKiDiff() {
        return totalNetKiDiff;
    }

    public void setTotalNetKiDiff(BigDecimal totalNetKiDiff) {
        this.totalNetKiDiff = totalNetKiDiff;
    }

    public BigDecimal getTotalSpGDiff() {
        return totalSpGDiff;
    }

    public void setTotalSpGDiff(BigDecimal totalSpGDiff) {
        this.totalSpGDiff = totalSpGDiff;
    }

    public BigDecimal getTotalNetGDiff() {
        return totalNetGDiff;
    }

    public void setTotalNetGDiff(BigDecimal totalNetGDiff) {
        this.totalNetGDiff = totalNetGDiff;
    }

    public String getLabel1Q() {
        return label1Q;
    }

    public void setLabel1Q(String label1Q) {
        this.label1Q = label1Q;
    }

    public String getLabel2Q() {
        return label2Q;
    }

    public void setLabel2Q(String label2Q) {
        this.label2Q = label2Q;
    }

    public String getJpyUnit() {
        return jpyUnit;
    }

    public void setJpyUnit(String jpyUnit) {
        this.jpyUnit = jpyUnit;
    }

    public String getKanjyoYmBefore() {
        return kanjyoYmBefore;
    }

    public void setKanjyoYmBefore(String kanjyoYmBefore) {
        this.kanjyoYmBefore = kanjyoYmBefore;
    }

    public Map<String, Object> getTotalInfo() {
        return totalInfo;
    }

    public void setTotalInfo(Map<String, Object> totalInfo) {
        this.totalInfo = totalInfo;
    }

    public List<Map<String, Object>> getBukkenList() {
        return bukkenList;
    }

    public void setBukkenList(List<Map<String, Object>> bukkenList) {
        this.bukkenList = bukkenList;
    }

    public String[] getSyuekiYmAry() {
        return syuekiYmAry;
    }

    public void setSyuekiYmAry(String[] syuekiYmAry) {
        this.syuekiYmAry = syuekiYmAry;
    }

    public String getSyueki1Q() {
        return syueki1Q;
    }

    public void setSyueki1Q(String syueki1Q) {
        this.syueki1Q = syueki1Q;
    }

    public String getSyueki2Q() {
        return syueki2Q;
    }

    public void setSyueki2Q(String syueki2Q) {
        this.syueki2Q = syueki2Q;
    }

    public String getSyuekiKi() {
        return syuekiKi;
    }

    public void setSyuekiKi(String syuekiKi) {
        this.syuekiKi = syuekiKi;
    }

    public String getStatusKbn() {
        return statusKbn;
    }

    public void setStatusKbn(String statusKbn) {
        this.statusKbn = statusKbn;
    }

    public String getComment() {
        return comment;
    }

    public void setComment(String comment) {
        this.comment = comment;
    }

    public String getConcatTeamCode() {
        return concatTeamCode;
    }

    public void setConcatTeamCode(String concatTeamCode) {
        this.concatTeamCode = concatTeamCode;
    }

    public List<Map<String, Object>> getCommentList() {
        return commentList;
    }

    public void setCommentList(List<Map<String, Object>> commentList) {
        this.commentList = commentList;
    }

    public String getCommentConfirmMessage() {
        return commentConfirmMessage;
    }

    public void setCommentConfirmMessage(String commentConfirmMessage) {
        this.commentConfirmMessage = commentConfirmMessage;
    }

    public List<SyuWfControlTbl> getKakuteiJokyoList() {
        return kakuteiJokyoList;
    }

    public void setKakuteiJokyoList(List<SyuWfControlTbl> kakuteiJokyoList) {
        this.kakuteiJokyoList = kakuteiJokyoList;
    }

    public String getDownloadFlg() {
        return downloadFlg;
    }

    public void setDownloadFlg(String downloadFlg) {
        this.downloadFlg = downloadFlg;
    }

    public Integer getKakuteiFlg() {
        return kakuteiFlg;
    }

    public void setKakuteiFlg(Integer kakuteiFlg) {
        this.kakuteiFlg = kakuteiFlg;
    }

    public boolean isKakuteiBtnFlg() {
        return kakuteiBtnFlg;
    }

    public void setKakuteiBtnFlg(boolean kakuteiBtnFlg) {
        this.kakuteiBtnFlg = kakuteiBtnFlg;
    }

    public boolean isKakuteiKaijoBtnFlg() {
        return kakuteiKaijoBtnFlg;
    }

    public void setKakuteiKaijoBtnFlg(boolean kakuteiKaijoBtnFlg) {
        this.kakuteiKaijoBtnFlg = kakuteiKaijoBtnFlg;
    }

    public Long getRirekiId() {
        return rirekiId;
    }

    public void setRirekiId(Long rirekiId) {
        this.rirekiId = rirekiId;
    }

    public String getRirekiFlg() {
        return rirekiFlg;
    }

    public void setRirekiFlg(String rirekiFlg) {
        this.rirekiFlg = rirekiFlg;
    }

    /**
     * @return the nextKanjyoYmData
     */
    public Date getNextKanjyoYmData() {
        return nextKanjyoYmData;
    }

    /**
     * @param nextKanjyoYmData the nextKanjyoYmData to set
     */
    public void setNextKanjyoYmData(Date nextKanjyoYmData) {
        this.nextKanjyoYmData = nextKanjyoYmData;
    }

    public boolean isIppan() {
        return (ConstantString.salesClassI.equals(this.getSalesClass()));
    }

    public boolean isYosan() {
        return (ConstantString.yosanDataKbn.equals(this.getSyubetsu()));
    }

    public String getBeforKiFlg() {
        return beforKiFlg;
    }

    public void setBeforKiFlg(String beforKiFlg) {
        this.beforKiFlg = beforKiFlg;
    }

    public String getBaseKanjyoYm() {
        return baseKanjyoYm;
    }

    public void setBaseKanjyoYm(String baseKanjyoYm) {
        this.baseKanjyoYm = baseKanjyoYm;
    }

    public boolean isKakuteiActionFlg() {
        return kakuteiActionFlg;
    }

    public void setKakuteiActionFlg(boolean kakuteiActionFlg) {
        this.kakuteiActionFlg = kakuteiActionFlg;
    }

    public boolean isHonsyaKakuteiFlg() {
        return honsyaKakuteiFlg;
    }

    public void setHonsyaKakuteiFlg(boolean honsyaKakuteiFlg) {
        this.honsyaKakuteiFlg = honsyaKakuteiFlg;
    }

    public String getDispBaseKanjyoYm() {
        return dispBaseKanjyoYm;
    }

    public void setDispBaseKanjyoYm(String dispBaseKanjyoYm) {
        this.dispBaseKanjyoYm = dispBaseKanjyoYm;
    }

    public String getAllAnkenKakuteiFlg() {
        return allAnkenKakuteiFlg;
    }

    public void setAllAnkenKakuteiFlg(String allAnkenKakuteiFlg) {
        this.allAnkenKakuteiFlg = allAnkenKakuteiFlg;
    }

    public String getDispId() {
        return dispId;
    }

    public void setDispId(String dispId) {
        this.dispId = dispId;
    }

//    public String getPartNoFixFlg() {
//        return partNoFixFlg;
//    }
//
//    public void setPartNoFixFlg(String partNoFixFlg) {
//        this.partNoFixFlg = partNoFixFlg;
//    }

    /**
     * @return the kaijoList
     */
    public List< HashMap<String,String>> getKaijoList() {
        return kaijoList;
    }

    /**
     * @param kaijoList the kaijoList to set
     */
    public void setKaijoList(List< HashMap<String,String>> kaijoList) {
        this.kaijoList = kaijoList;
    }

    /**
     * コメント入力 チームコードの選択が可能か？
     */
//    public boolean isTeamCheckFlg(String status) {
//        if (ConstantString.wfStatusCreating.equals(status)) {
//            return false;
//        } else {
//            return true;
//        }
//    }

    public boolean isKaijyoOkFlg(String status) {
        boolean flg = false;
        if ("1".equals(teishutsuFlg)) {   // 提出データ解除時
            if (ConstantString.wfStatusTeishutsu.equals(status)) {
                flg = true;
            }
        } else {    // 確定データ解除時
            if (ConstantString.wfStatusKakutei.equals(status)) {
                flg = true;
            }
        }
        return flg;
    }
    
    public boolean isKakuteiOkFlg(String status) {
        boolean flg = false;
        if ("1".equals(teishutsuFlg)) {   // 提出データ作成処理
            if (ConstantString.wfStatusCreating.equals(status)) {
                flg = true;
            }
        } else {   // 確定処理時
            if (!ConstantString.wfStatusKakutei.equals(status)) {
                flg = true;
            }
        }
        return flg;
    }
    
    public boolean isKakuteiStatus(String status) {
        return ConstantString.wfStatusKakutei.equals(status);
    }
    
    public boolean isTeishuTsuStatus(String status) {
        return ConstantString.wfStatusTeishutsu.equals(status);
    }
    
    public boolean isCreateStatus(String status) {
        return ConstantString.wfStatusCreating.equals(status);
    }

}
