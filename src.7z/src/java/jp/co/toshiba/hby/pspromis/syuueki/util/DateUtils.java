package jp.co.toshiba.hby.pspromis.syuueki.util;

import java.sql.Timestamp;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;
import org.apache.commons.lang3.StringUtils;

/**
 * 日付・時刻関連クラス
 */
//@Named(value = "dateUtils")
//@ApplicationScoped
public class DateUtils {

    static private final String DATE_PATTERN ="yyyy/MM/dd";
    static private final String DATE_MEDIUM_HYPHEN_PATTERN = "yyyy-MM-dd";
    static private final String TIME_PATTERN ="HH:mm";
    static private final String ALL_TIME_PATTERN ="HH:mm:ss";
    static private final String ENGLISH_DATE_PATTERN ="EEE MMM dd HH:mm:ss z yyyy";
    static private final String JAPANESE_DATE_PATTERN ="yyyy年MM月dd日";
    static private final String DATE_SEQUENCE = "yyyyMMddHHmmssSSS";
    static private final String DATE_MINUTS_PATTERN = "yyyyMMddHHmm";
    static private final String DATE_MEDIUM_SIMPLE_PATTERN = "yyyyMMdd";
    static private final String MONTH_MEDIUM_SIMPLE_PATTERN = "yyyyMM";
    static private final String DATE_STRING_FORMAT = "%04d/%02d/%02d %s";

    /**
     * 日付変換
     * @param dateStr
     * @param ConvFormat
     * @return
     * @throws java.text.ParseException
     */
    public static String convertString(String dateStr, String ConvFormat) throws ParseException {
        //パラメータチェック
        if (dateStr == null || dateStr.equals("")){
            return null;
        }
        //通常の変換で可能であれば、そのまま処理する
        String rtValue = null;
        Date setDate = null;
        try{
            setDate = getDate(dateStr, getDATE_PATTERN());
        }catch(ParseException e){
            throw e;
            //失敗した場合、英語ローケルの指定でチェック
            //setDate = getDate(dateStr, getENGLISH_DATE_PATTERN(), Locale.ENGLISH);
        }
        if (setDate != null) {
            // 日付情報を返す
            rtValue = getString(setDate, ConvFormat);
        }
        return rtValue;
    }

    /**
     * 日付変換(YYYY/MM/DD形式)
     * @param dateValue
     * @return
     */
    public static String getDateString(Date dateValue) {
        if (dateValue == null) {
            return null;
        }
        return (new SimpleDateFormat(getDATE_PATTERN())).format(dateValue);
    }
    
    /**
     * 日付変換(YYYY/MM/DD形式)
     * @param dateValue
     * @return
     */
    public static String getDateString(String dateValue) {
        if (dateValue == null || "".equals(dateValue)) {
            return null;
        }
        return (new SimpleDateFormat(getDATE_PATTERN())).format(dateValue);
    }
    
    /**
     * 日付変換(yyyy/MM/dd HH:mm:ss形式)
     * @param dateValue
     * @return
     */
    public static String getTimeStampString(Date dateValue) {
        if (dateValue == null) {
            return null;
        }
        return (new SimpleDateFormat(getALL_DATETIME_PATTERN())).format(dateValue);
    }

   /**
     * 日付変換(YYYY-MM-DD形式)
     * @param dateValue
     * @return
     */
    public static String getDateStringHyphen(Date dateValue) {
        if (dateValue == null) {
            return null;
        }
        return (new SimpleDateFormat(getDATE_MEDIUM_HYPHEN_PATTERN())).format(dateValue);
    }

    /**
     * 日付変換(HH:mm形式)
     * @param dateValue
     * @return
     */
    public static String getTimeString(Date dateValue) {
        if (dateValue == null) {
            return null;
        }
        return (new SimpleDateFormat(getALL_TIME_PATTERN())).format(dateValue);
    }

    /**
     * 日付変換(書式指定)
     * @param dateValue
     * @param format
     * @return
     */
    public static String getString(Date dateValue, String format) {
        if (dateValue == null) {
            return null;
        }
        return (new SimpleDateFormat(format)).format(dateValue);
    }

    /**
     * 日付変換(書式指定,Local指定)
     * @param dateValue
     * @param format
     * @param locale
     * @return
     */
    public static String getString(Date dateValue, String format, Locale locale) {
        if (dateValue == null) {
            return null;
        }
        return (new SimpleDateFormat(format,locale)).format(dateValue);
    }

    /**
     * 日付変換(書式指定)
     * @param dateStr
     * @param format
     * @return
     * @throws java.text.ParseException
     */
    public static Date getDate(String dateStr, String format) throws ParseException{
        if (dateStr == null || "".equals(dateStr)) {
            return null;
        }
        return (new SimpleDateFormat(format)).parse(dateStr);
    }

    /**
     * 日付変換(書式指定,Local指定)
     * @param dateStr
     * @param format
     * @param locale
     * @return
     * @throws java.text.ParseException
     */
    public static Date getDate(String dateStr, String format,Locale locale) throws ParseException{
        if (dateStr == null || "".equals(dateStr)) {
            return null;
        }
        return (new SimpleDateFormat(format,locale)).parse(dateStr);
    }

    /**
     * 日付変換(文字列 -> java.sql.Date)
     * @param dateStr
     * @throws java.text.ParseException
     */
/*
    public static final java.sql.Date getSqlDate(String dateStr) throws ParseException{
        if (dateStr == null || dateStr.equals("")) {
            return null;
        }

        Date date = getDate(dateStr, getDATE_PATTERN());
        return getSqlDate(date);
    }
*/
    /**
     * 日付変換(java.util.Date -> java.sql.Date)
     * @param date
     * @param dateStr
     * @return 
     * @throws java.text.ParseException
     */
    public static final java.sql.Date getSqlDate(java.util.Date date) {
        if (date == null) {
            return null;
        }

        Calendar cal = Calendar.getInstance();

        cal.setTime(date);
        cal.set(Calendar.HOUR_OF_DAY, 0);
        cal.set(Calendar.MINUTE, 0);
        cal.set(Calendar.SECOND, 0);
        cal.set(Calendar.MILLISECOND, 0);

        return (new java.sql.Date(cal.getTimeInMillis()));
    }

    /**
     * java.util.Dateをjava.sql.Timestampに変換
     * @param date
     * @return 
     */
    public static java.sql.Timestamp getSqlTimestamp(java.util.Date date) {
        if (date == null) {
            return null;
        }
        
        Calendar cal = Calendar.getInstance();
        cal.setTime(date);
        java.sql.Timestamp d2 = new java.sql.Timestamp(cal.getTimeInMillis());
        
        return d2;
    }
    
    /**
     * @return the DATE_PATTERN
     */
    public static String getDATE_PATTERN() {
        return DATE_PATTERN;//"yyyy/MM/dd"
    }

    /**
     * @return the TIME_PATTERN
     */
    public static String getTIME_PATTERN() {
        return TIME_PATTERN;//"HH:mm"
    }

    /**
     * @return the DATETIME_PATTERN
     */
    public static String getDATETIME_PATTERN() {
        return getDATE_PATTERN()+" "+getTIME_PATTERN();//yyyy/MM/dd HH:mm
    }

    /**
     * @return the ALL_DATETIME_PATTERN
     */
    public static String getALL_DATETIME_PATTERN() {
        return getDATE_PATTERN()+" "+getALL_TIME_PATTERN();//yyyy/MM/dd HH:mm:ss
    }

    /**
     * @return the ALL_TIME_PATTERN
     */
    public static String getALL_TIME_PATTERN() {
        return ALL_TIME_PATTERN;//HH:mm:ss
    }

    /**
     * @return the ENGLISH_DATE_PATTERN
     */
    public static String getENGLISH_DATE_PATTERN() {
        return ENGLISH_DATE_PATTERN;//EEE MMM dd HH:mm:ss z yyyy
    }

    /**
     * @return the JAPANESE_DATE_PATTERN
     */
    public static String getJAPANESE_DATE_PATTERN() {
        return JAPANESE_DATE_PATTERN;//yyyy年MM月dd日(E)
    }

    /**
     * @return the DATE_SEQUENCE
     */
    public static String getDATE_SEQUENCE() {
        return DATE_SEQUENCE;//yyyyMMddHHmmssSSS
    }

    /**
     * @return the MONTH_MEDIUM_SIMPLE_PATTERN
     */
    public static String getMONTH_MEDIUM_SIMPLE_PATTERN() {
        return MONTH_MEDIUM_SIMPLE_PATTERN;
    }

    /**
     * @return the DATE_MEDIUM_SIMPLE_PATTERN
     */
    public static String getDATE_MEDIUM_SIMPLE_PATTERN() {
        return DATE_MEDIUM_SIMPLE_PATTERN;
    }
    
    /**
     * @return the DATE_MEDIUM_HYPHEN_PATTERN
     */
    public static String getDATE_MEDIUM_HYPHEN_PATTERN() {
        return DATE_MEDIUM_HYPHEN_PATTERN;
    }

    /**
     * @return the DATE_STRING_FORMAT
     */
    public static String getDATE_STRING_FORMAT() {
        return DATE_STRING_FORMAT;//%04d/%02d/%02d %s
    }

    public static String getDATE_MINUTS_PATTERN() {
        return DATE_MINUTS_PATTERN;
    }

    /**
     * 現在時刻を取得
     * @return Timestamp
     */
    public static Timestamp getSysdate() {
        return new Timestamp(System.currentTimeMillis());
    }
    
    /**
     * 日付文字列→日付(java.sql.date)に変換<br>
     * パラメータがnull or 空白の場合はnullにする。
     * @param str 日付文字列
     * @param format フォーマット
     * @throws java.text.ParseException
     */
    public static Date parseDate(String str, String... format) throws ParseException {
        String[] parseFormat = null;
        String target = str;

        if (StringUtils.isEmpty(str)) {
            return null;
        }

        if (format != null && format.length > 0) {
            parseFormat = format;
        } else {
            String cTarget= StringUtils.replace(target, "/", "");
            cTarget = StringUtils.replace(cTarget, "-", "");
            if (cTarget.length() == 6) {
                String y = StringUtils.substring(cTarget, 0, 4);
                String m = StringUtils.substring(cTarget, 4, 6);
                String d = "01";
                target = y + "/" + m + "/" + d;
            } else if (cTarget.length() == 8) {
                String y = StringUtils.substring(cTarget, 0, 4);
                String m = StringUtils.substring(cTarget, 4, 6);
                String d = StringUtils.substring(cTarget, 6);
                target = y + "/" + m + "/" + d;
            }

            parseFormat = new String[9];
            parseFormat[0] = "dd-MM-yyyy HH:mm:ss";
            parseFormat[1] = "dd-MM-yyyy HH:mm";
            parseFormat[2] = "dd-MM-yyyy";
            parseFormat[3] = "yyyy-MM-dd HH:mm:ss";
            parseFormat[4] = "yyyy-MM-dd HH:mm";
            parseFormat[5] = "yyyy-MM-dd";
            parseFormat[6] = "yyyy/MM/dd HH:mm:ss";
            parseFormat[7] = "yyyy/MM/dd HH:mm";
            parseFormat[8] = "yyyy/MM/dd";
        }

        Date date = org.apache.commons.lang3.time.DateUtils.parseDateStrictly(target, parseFormat);
        return date;
    }

    /**
     * 指定年月の演算(yyyyMMの文字列で返す)
     */
    public static String getAddMonths(String month, int add) throws ParseException {
        String wkMonth = StringUtils.replace(month, "/", "");
        wkMonth = StringUtils.replace(wkMonth, "-", "");
        Date dateMonth = parseDate(wkMonth);
        return getAddDateMonths(dateMonth, add);
    }
    
    /**
     * 指定年月の演算(yyyyMMの文字列で返す)
     */
    public static String getAddDateMonths(Date month, int add) {
        Date addMonth = org.apache.commons.lang3.time.DateUtils.addMonths(month, add);
        String addMonthStr = org.apache.commons.lang3.time.DateFormatUtils.format(addMonth, getMONTH_MEDIUM_SIMPLE_PATTERN());
        return addMonthStr;
    }
    
}
