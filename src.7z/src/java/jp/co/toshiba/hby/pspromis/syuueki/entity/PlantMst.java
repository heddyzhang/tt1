/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package jp.co.toshiba.hby.pspromis.syuueki.entity;

import java.io.Serializable;
import java.util.Date;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

/**
 *
 * @author ibayashi
 */
@Entity
@Table(name = "PLANT_MST")
public class PlantMst implements Serializable {
    private static final long serialVersionUID = 1L;
    @Basic(optional = false)
    @NotNull
    @Column(name = "ID")
    @Id
    private long id;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 8)
    @Column(name = "PLANT_CODE")
    private String plantCode;
    @Size(max = 2)
    @Column(name = "DIVISION_CODE")
    private String divisionCode;
    @Size(max = 8)
    @Column(name = "N7_PLANT_CODE")
    private String n7PlantCode;
    @Size(max = 8)
    @Column(name = "N7_PWR_CODE")
    private String n7PwrCode;
    @Size(max = 8)
    @Column(name = "N8_PLANT_CODE")
    private String n8PlantCode;
    @Column(name = "BU_ID")
    private Long buId;
    @Size(max = 7)
    @Column(name = "NEW_STCH_CD_PREFIX")
    private String newStchCdPrefix;
    @Size(max = 11)
    @Column(name = "NEW_STCH_CD")
    private String newStchCd;
    @Size(max = 8)
    @Column(name = "N0_62_PLANT_CODE")
    private String n062PlantCode;
    @Size(max = 8)
    @Column(name = "N0_68_PLANT_CODE")
    private String n068PlantCode;
    @Size(max = 120)
    @Column(name = "PLANT_NAME")
    private String plantName;
    @Size(max = 120)
    @Column(name = "PLANT_NAME_ENG")
    private String plantNameEng;
    @Size(max = 10)
    @Column(name = "PLANT_ALIAS")
    private String plantAlias;
    @Size(max = 10)
    @Column(name = "PLANT_ALIAS_ENG")
    private String plantAliasEng;
    @Column(name = "VALID_FROM")
    @Temporal(TemporalType.TIMESTAMP)
    private Date validFrom;
    @Column(name = "VALID_TO")
    @Temporal(TemporalType.TIMESTAMP)
    private Date validTo;
    @Column(name = "SORT_ORDER")
    private Long sortOrder;
    @Column(name = "CREATED_AT")
    @Temporal(TemporalType.TIMESTAMP)
    private Date createdAt;
    @Size(max = 8)
    @Column(name = "CREATED_BY")
    private String createdBy;
    @Column(name = "UPDATED_AT")
    @Temporal(TemporalType.TIMESTAMP)
    private Date updatedAt;
    @Size(max = 8)
    @Column(name = "UPDATED_BY")
    private String updatedBy;
    @Column(name = "DELETED_AT")
    @Temporal(TemporalType.TIMESTAMP)
    private Date deletedAt;
    @Size(max = 8)
    @Column(name = "DELETED_BY")
    private String deletedBy;
    @Basic(optional = false)
    @NotNull
    @Column(name = "IS_DELETED")
    private short isDeleted;

    public PlantMst() {
    }

    public PlantMst(String plantCode) {
        this.plantCode = plantCode;
    }

    public PlantMst(String plantCode, long id, short isDeleted) {
        this.plantCode = plantCode;
        this.id = id;
        this.isDeleted = isDeleted;
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getPlantCode() {
        return plantCode;
    }

    public void setPlantCode(String plantCode) {
        this.plantCode = plantCode;
    }

    public String getDivisionCode() {
        return divisionCode;
    }

    public void setDivisionCode(String divisionCode) {
        this.divisionCode = divisionCode;
    }

    public String getN7PlantCode() {
        return n7PlantCode;
    }

    public void setN7PlantCode(String n7PlantCode) {
        this.n7PlantCode = n7PlantCode;
    }

    public String getN7PwrCode() {
        return n7PwrCode;
    }

    public void setN7PwrCode(String n7PwrCode) {
        this.n7PwrCode = n7PwrCode;
    }

    public String getN8PlantCode() {
        return n8PlantCode;
    }

    public void setN8PlantCode(String n8PlantCode) {
        this.n8PlantCode = n8PlantCode;
    }

    public Long getBuId() {
        return buId;
    }

    public void setBuId(Long buId) {
        this.buId = buId;
    }

    public String getNewStchCdPrefix() {
        return newStchCdPrefix;
    }

    public void setNewStchCdPrefix(String newStchCdPrefix) {
        this.newStchCdPrefix = newStchCdPrefix;
    }

    public String getNewStchCd() {
        return newStchCd;
    }

    public void setNewStchCd(String newStchCd) {
        this.newStchCd = newStchCd;
    }

    public String getN062PlantCode() {
        return n062PlantCode;
    }

    public void setN062PlantCode(String n062PlantCode) {
        this.n062PlantCode = n062PlantCode;
    }

    public String getN068PlantCode() {
        return n068PlantCode;
    }

    public void setN068PlantCode(String n068PlantCode) {
        this.n068PlantCode = n068PlantCode;
    }

    public String getPlantName() {
        return plantName;
    }

    public void setPlantName(String plantName) {
        this.plantName = plantName;
    }

    public String getPlantNameEng() {
        return plantNameEng;
    }

    public void setPlantNameEng(String plantNameEng) {
        this.plantNameEng = plantNameEng;
    }

    public String getPlantAlias() {
        return plantAlias;
    }

    public void setPlantAlias(String plantAlias) {
        this.plantAlias = plantAlias;
    }

    public String getPlantAliasEng() {
        return plantAliasEng;
    }

    public void setPlantAliasEng(String plantAliasEng) {
        this.plantAliasEng = plantAliasEng;
    }

    public Date getValidFrom() {
        return validFrom;
    }

    public void setValidFrom(Date validFrom) {
        this.validFrom = validFrom;
    }

    public Date getValidTo() {
        return validTo;
    }

    public void setValidTo(Date validTo) {
        this.validTo = validTo;
    }

    public Long getSortOrder() {
        return sortOrder;
    }

    public void setSortOrder(Long sortOrder) {
        this.sortOrder = sortOrder;
    }

    public Date getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(Date createdAt) {
        this.createdAt = createdAt;
    }

    public String getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    public Date getUpdatedAt() {
        return updatedAt;
    }

    public void setUpdatedAt(Date updatedAt) {
        this.updatedAt = updatedAt;
    }

    public String getUpdatedBy() {
        return updatedBy;
    }

    public void setUpdatedBy(String updatedBy) {
        this.updatedBy = updatedBy;
    }

    public Date getDeletedAt() {
        return deletedAt;
    }

    public void setDeletedAt(Date deletedAt) {
        this.deletedAt = deletedAt;
    }

    public String getDeletedBy() {
        return deletedBy;
    }

    public void setDeletedBy(String deletedBy) {
        this.deletedBy = deletedBy;
    }

    public short getIsDeleted() {
        return isDeleted;
    }

    public void setIsDeleted(short isDeleted) {
        this.isDeleted = isDeleted;
    }

}
