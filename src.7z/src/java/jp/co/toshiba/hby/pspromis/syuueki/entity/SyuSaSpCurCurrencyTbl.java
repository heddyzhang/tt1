package jp.co.toshiba.hby.pspromis.syuueki.entity;

import java.io.Serializable;
import java.math.BigDecimal;
//import java.util.Date;
import javax.persistence.Id;
import javax.persistence.Column;
import javax.persistence.Entity;
//import javax.persistence.Table;
//import javax.persistence.Temporal;
//import javax.persistence.TemporalType;

/**
 *
 * @author ibayashi
 */
@Entity
public class SyuSaSpCurCurrencyTbl implements Serializable {

    private static final long serialVersionUID = 1L;

    @Id
    @Column(name = "ANKEN_ID")
    private String ankenId;

    @Id
    @Column(name = "RIREKI_ID")
    private int rirekiId;

    @Id
    @Column(name = "CURRENCY_CODE")
    private String currencyCode;

    @Column(name = "DISP_SEQ")
    private BigDecimal dispSeq;

    @Column(name = "KEIYAKU_RATE")
    private BigDecimal keiyakuRate;

    public SyuSaSpCurCurrencyTbl() {
    }

    public String getAnkenId() {
        return ankenId;
    }

    public void setAnkenId(String ankenId) {
        this.ankenId = ankenId;
    }

    public int getRirekiId() {
        return rirekiId;
    }

    public void setRirekiId(int rirekiId) {
        this.rirekiId = rirekiId;
    }

    public String getCurrencyCode() {
        return currencyCode;
    }

    public void setCurrencyCode(String currencyCode) {
        this.currencyCode = currencyCode;
    }

    public BigDecimal getDispSeq() {
        return dispSeq;
    }

    public void setDispSeq(BigDecimal dispSeq) {
        this.dispSeq = dispSeq;
    }

    public BigDecimal getKeiyakuRate() {
        return keiyakuRate;
    }

    public void setKeiyakuRate(BigDecimal keiyakuRate) {
        this.keiyakuRate = keiyakuRate;
    }

}
