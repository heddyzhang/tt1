package jp.co.toshiba.hby.pspromis.syuueki.facade;

import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;
import java.util.List;
import java.util.ArrayList;
import javax.ejb.Stateless;
import javax.inject.Inject;
import javax.interceptor.Interceptors;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import jp.co.toshiba.hby.pspromis.syuueki.entity.CategoryName;
import jp.co.toshiba.hby.pspromis.syuueki.interceptor.TranceInterceptor;
import jp.co.toshiba.hby.pspromis.common.jdbc.SqlExecutor;
import jp.co.toshiba.hby.pspromis.syuueki.entity.StringEntity;
import jp.co.toshiba.hby.pspromis.syuueki.entity.SyuGeCategoryMapView;
import jp.co.toshiba.hby.pspromis.syuueki.jdbc.DbUtilsExecutor;
import jp.co.toshiba.hby.pspromis.syuueki.jdbc.SqlFile;
import org.apache.commons.collections.CollectionUtils;

/**
 *
 * @author ibayashi
 */
@Stateless
@Interceptors({TranceInterceptor.class})
public class CategoryMapFacade {

    @PersistenceContext(unitName = jp.co.toshiba.hby.pspromis.syuueki.util.ConstantString.syuuekiDataSourceName)
    private EntityManager em;

    @Inject
    protected SqlExecutor sqlExecutor;
    
    @Inject
    protected DbUtilsExecutor dbUtilsExecutor;
    
    public Map<String, Object> findCategoryMap(String categoryCode) throws SQLException {
        SqlFile sqlFile = new SqlFile();
        
        String sqlFilePath = "/sql/categoryMst/selectCategoryMstFromCode.sql";
        Map<String, Object> condition = new HashMap<>();
        condition.put("categoryCode", categoryCode);
        
        String sqlString = sqlFile.getSqlString(sqlFilePath, condition);
        Object[] params = sqlFile.getSqlParams(sqlFilePath, condition);
        
        Map<String, Object> result = dbUtilsExecutor.dbUtilsGetSql(em, sqlString, params);
        
        return result;
    }
    
    public List findGetCategoryNameView(String kbn, Map<String, Object> condition) {
        List<CategoryName> list
                = sqlExecutor.getResultList(em, CategoryName.class, "/sql/categoryMst/selectGeCategoryNameView.sql", condition);
        
        return list;
    }
    
    /**
     * カテゴリコード、区分1、区分2の組合せのチェック
     * @param condition
     * @return 
     */
    public SyuGeCategoryMapView getConmbination(Map<String, Object> condition){
        SyuGeCategoryMapView entity = null;
        
        List<SyuGeCategoryMapView> list = sqlExecutor.getResultList(em, SyuGeCategoryMapView.class, "/sql/syuGeCategoryMap/selectCombination.sql", condition);
        
        if(list.size() > 0){
            entity = list.get(0);
        }
        
        return entity;
    }
    
    /**
     * カテゴリ名から区分の取得
     * @param condition
     * @return 
     */
    public SyuGeCategoryMapView getCategoryKbnFromName(Map<String, Object> condition){
        SyuGeCategoryMapView entity = null;
        
        List<SyuGeCategoryMapView> list = sqlExecutor.getResultList(em, SyuGeCategoryMapView.class, "/sql/syuGeCategoryMap/getCategoryKbn.sql", condition);
        
        if(list.size() > 0){
            entity = list.get(0);
        }
        
        return entity;
    }
    
    /**
     * カテゴリ名の取得
     * @param condition
     * @return 
     */
    public List<SyuGeCategoryMapView> getCategoryList(Map<String, Object> condition){
        
        List<SyuGeCategoryMapView> list = sqlExecutor.getResultList(em, SyuGeCategoryMapView.class, "/sql/syuGeCategoryMap/getCategoryKbn.sql", condition);
        
        return list;
    }
    
    /**
     * カテゴリ区分の新規発番
     */
    public String getCategoryKbn(String flg){
        String sql = "";
        if(flg == "1"){
            sql = "/sql/syuGeCategoryMap/getCategoryKbn1Seq.sql";
        } else {
            sql = "/sql/syuGeCategoryMap/getCategoryKbn2Seq.sql";
        }
        
        StringEntity kbn = null;
        
        List<StringEntity> list = sqlExecutor.getResultList(em, StringEntity.class, sql, null);
        
        if(CollectionUtils.isNotEmpty(list)){
            kbn = list.get(0);
        } else {
            return null;
        }
        
        return kbn.getString();
    }
    
    /**
     * 選択候補の取得
     */
    public List<StringEntity> getCateCoiceList(Map<String, Object> condition){
        List<StringEntity> list =  sqlExecutor.getResultList(em, StringEntity.class, "/sql/syuGeCategoryMap/getChoiceList.sql", condition);
        return list;
    }

}
