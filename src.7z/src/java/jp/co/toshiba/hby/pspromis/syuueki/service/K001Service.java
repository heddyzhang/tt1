package jp.co.toshiba.hby.pspromis.syuueki.service;

import java.util.List;
import java.util.Map;
import javax.ejb.Stateless;
import javax.inject.Inject;
import javax.interceptor.Interceptors;
import jp.co.toshiba.hby.pspromis.syuueki.bean.K001Bean;
import jp.co.toshiba.hby.pspromis.syuueki.entity.JgrpTbl;
import jp.co.toshiba.hby.pspromis.syuueki.facade.JgrpTblFacade;
import jp.co.toshiba.hby.pspromis.syuueki.facade.MSectionFacade;
import jp.co.toshiba.hby.pspromis.syuueki.interceptor.TranceInterceptor;
import jp.co.toshiba.hby.pspromis.syuueki.util.LoginUserInfo;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
/**
 * PS-Promis収益管理システム
 * ジョブグループ選択 Service
 * @author (NPC)S.Ibayashi
 */
@Stateless
@Interceptors({TranceInterceptor.class})
public class K001Service {

    public static final Logger logger = LoggerFactory.getLogger(K001Service.class);

    @Inject
    private K001Bean k001Bean;

    @Inject
    private LoginUserInfo loginUserInfo;

    @Inject
    private MSectionFacade mSectionFacade;

    @Inject
    private JgrpTblFacade jgrpTblFacade;

    /**
     * 初期表示時機能
     * @throws Exception
     */
    public void indexExecute() throws Exception {
        // 事業部が選択されていない場合
        if (k001Bean.getDivisionCode() == null) {
            // ログイン者の事業部を強制セット
            k001Bean.setDivisionCode(loginUserInfo.getJobGrSyokusyuArrayInfo("division"));
        }
        
        // 部課一覧を取得
        List<Map<String, Object>> bukaList = mSectionFacade.findAllTreeList(k001Bean.getDivisionCode());

        k001Bean.setBukaList(bukaList);
    }

    /**
     * JobGr一覧取得
     */
    public void jobGrExecute() throws Exception {
        logger.info("deptCd=" + k001Bean.getDeptCd());
        
        // JobGr一覧を取得
        List<JgrpTbl> jobGrList = jgrpTblFacade.findDeptJobGr(k001Bean.getDeptCd());

        k001Bean.setJobGrList(jobGrList);
    }

}
