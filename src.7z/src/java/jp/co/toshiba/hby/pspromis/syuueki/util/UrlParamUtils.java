package jp.co.toshiba.hby.pspromis.syuueki.util;

import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;

/**
 *
 * @author ibayashi
 */
public class UrlParamUtils {
    
    private static final String ENCODE_CHARSET = "UTF-8";
    
    /**
     * 指定した引数をURLエンコードする
     * @param target
     */
    public static String encodeUrl(String target) throws UnsupportedEncodingException {
        if (target == null || target.equals("")) {
            return "";
        }
        String result = URLEncoder.encode(target, ENCODE_CHARSET);
        return result;
    }

}
