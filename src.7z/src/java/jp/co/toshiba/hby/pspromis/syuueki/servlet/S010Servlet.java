package jp.co.toshiba.hby.pspromis.syuueki.servlet;

import java.util.HashMap;
import java.util.Map;
import javax.inject.Inject;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpServletRequest;
import jp.co.toshiba.hby.pspromis.syuueki.bean.S010Bean;
import jp.co.toshiba.hby.pspromis.syuueki.bean.S010Bean;
import jp.co.toshiba.hby.pspromis.syuueki.service.S010Service;
import jp.co.toshiba.hby.pspromis.syuueki.util.ParameterBinder;

/**
 * PS-Promis収益管理システム
 * 完売実績入力 Servlet
 * @author masaki
 */
@WebServlet(name="S010", urlPatterns={"/servlet/S010", "/servlet/S010/*"})
public class S010Servlet extends AbstractServlet {

    /**
     * jsp
     */
    private static final String INDEX_JSP = "S010/s010.jsp";

    /**
     * 使用serviceクラスをinjection(CDI)<br>
     * InjectアノテーションよりAPサーバー(Glassfish)側で自動的にインスタンス作成(new)される。<br>
     * service側はステートレスセッションbeanにするため、Statelessアノテーションをつけておくこと。<br>
     */
    @Inject
    private S010Service s010Service;

    /**
     * パラメータ格納クラスをinjection(CDI)<br>
     * InjectアノテーションよりAPサーバー(Glassfish)側で自動的にインスタンス作成(new)される。<br>
     */
    @Inject
    private S010Bean s010Bean;
    
    /**
     * 初期表示
     * @param req
     * @param resp
     * @return
     * @throws Exception 
     */
    public String indexAction(HttpServletRequest req, HttpServletResponse resp)
    throws Exception {
        logger.info("S010Servlet#indexAction");
        
        ParameterBinder.Bind(s010Bean, req);
        // サービスの実行(トランザクションの単位にもなる)
        s010Service.indexExecute();

        return INDEX_JSP;
    }
    
    /**
     * 保存
     * @param req
     * @param resp
     * @return
     * @throws Exception 
     */
    public String saveAction(HttpServletRequest req, HttpServletResponse resp)
    throws Exception {
        logger.info("S010Servlet#saveAction");
        
        ParameterBinder.Bind(s010Bean, req);
        
        s010Service.save();
        
        return null;
    }
    
}
