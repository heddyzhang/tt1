package jp.co.toshiba.hby.pspromis.syuueki.facade;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.ejb.Stateless;
import javax.inject.Inject;
import javax.interceptor.Interceptors;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import jp.co.toshiba.hby.pspromis.syuueki.entity.EstViewList;
import jp.co.toshiba.hby.pspromis.syuueki.entity.StringEntity;
//import jp.co.toshiba.hby.pspromis.syuueki.enums.Env;
import jp.co.toshiba.hby.pspromis.syuueki.interceptor.TranceInterceptor;
import jp.co.toshiba.hby.pspromis.syuueki.util.ConstantString;
import jp.co.toshiba.hby.pspromis.syuueki.pages.DivisonComponentPage;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 *
 * @author ganryu
 */
@Stateless
@Interceptors({TranceInterceptor.class})
public class S017Facade extends AbstractFacade<StringEntity> {

    private static final Logger logger = LoggerFactory.getLogger(S017Facade.class);

    @PersistenceContext(unitName = jp.co.toshiba.hby.pspromis.syuueki.util.ConstantString.syuuekiDataSourceName)
    private EntityManager em;

    @Inject
    private DivisonComponentPage divisionComponentPage;
    
    @Override
    protected EntityManager getEntityManager() {
        return em;
    }

    public S017Facade() {
        super(StringEntity.class);
    }

    public List<EstViewList> selectQnoList(String oNo, String ankenId, String divisionCode, String ankenFlg) {
        logger.info("S017Facade#selectQnoList");

        // 2017/11/17 ADD #006 決裁/見積情報参照画面からP-Linkへ飛ぶ
        // 事業部コード:(原子力)であるかを判断
        String divisionNuclearFlg = "0";
        boolean isNuclearDivision = divisionComponentPage.isNuclearDivision(divisionCode);
        if (isNuclearDivision) {
            divisionNuclearFlg = "1";
        }
        
        List<EstViewList> list = new ArrayList<>();

        Map<String, Object> condition = new HashMap<>();
        condition.put("orderNo", oNo);
        condition.put("ankenId", ankenId);
        condition.put("rirekiId", Integer.valueOf(ConstantString.geRirekiId));
        // 2017/11/17 ADD #006 決裁/見積情報参照画面からP-Linkへ飛ぶ
        //condition.put("divisionCode", divisionCode);
        //condition.put("divNuclear", divNuclear);
        condition.put("divisionNuclearFlg", divisionNuclearFlg);
        condition.put("ankenFlg", ankenFlg);

        list  = sqlExecutor.getResultList(em, EstViewList.class, "/sql/syuGeBukkenInfoTbl/selectEstViewList.sql", condition);

        return list;
    }
}
