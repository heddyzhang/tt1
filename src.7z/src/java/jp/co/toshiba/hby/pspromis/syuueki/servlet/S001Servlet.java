package jp.co.toshiba.hby.pspromis.syuueki.servlet;

import java.io.File;
import java.io.PrintWriter;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import javax.inject.Inject;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpServletRequest;
import jp.co.toshiba.hby.pspromis.syuueki.bean.S001Bean;
import jp.co.toshiba.hby.pspromis.syuueki.bean.S021Bean;
import jp.co.toshiba.hby.pspromis.syuueki.bean.S001MstBean;
import jp.co.toshiba.hby.pspromis.syuueki.bean.SyuekiFlgEditBean;
import jp.co.toshiba.hby.pspromis.syuueki.bean.SyuekiFlgEditBeanMessageBean;
import jp.co.toshiba.hby.pspromis.syuueki.bean.ValidationMessageBean;
import jp.co.toshiba.hby.pspromis.syuueki.bean.ValidationInfoBean;
import jp.co.toshiba.hby.pspromis.syuueki.facade.SysdateEntityFacade;
import jp.co.toshiba.hby.pspromis.syuueki.service.S001DownloadService;
import jp.co.toshiba.hby.pspromis.syuueki.service.S001Service;
import jp.co.toshiba.hby.pspromis.syuueki.service.S021Service;
import jp.co.toshiba.hby.pspromis.syuueki.service.SyuekiFlgEditService;
import jp.co.toshiba.hby.pspromis.syuueki.util.FileUtils;
import jp.co.toshiba.hby.pspromis.syuueki.util.ParameterBinder;
import jp.co.toshiba.hby.pspromis.syuueki.util.PoiUtil;
import jp.co.toshiba.hby.pspromis.syuueki.util.SyuuekiUtils;
import jp.co.toshiba.hby.pspromis.syuueki.util.Utils;
import jp.co.toshiba.hby.pspromis.syuueki.validation.S001Validation;
import org.apache.commons.beanutils.PropertyUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.poi.ss.usermodel.Workbook;

/**
 * PS-Promis収益管理システム
 * 案件検索 Servlet
 * @author (NPC)S.Ibayashi
 */
@WebServlet(name="S001", urlPatterns={"/servlet/S001", "/servlet/S001/*"})
public class S001Servlet extends AbstractServlet {

    /**
     * jsp
     */
    private static final String INDEX_JSP = "S001/s001.jsp";

    private static final String OPTION_JSP = "S001/downloadOption.jsp";
    
    /**
     * 使用serviceクラスをinjection(CDI)<br>
     * InjectアノテーションよりAPサーバー(Glassfish)側で自動的にインスタンス作成(new)される。<br>
     * service側はステートレスセッションbeanにするため、Statelessアノテーションをつけておくこと。<br>
     */
    @Inject
    private S001Service s001Service;

    @Inject
    private S001DownloadService s001DownloadService;
    
    @Inject
    private SyuekiFlgEditService syuekiFlgEditService;
    
    @Inject
    private S021Service s021Service;
    
    /**
     * パラメータ格納クラスをinjection(CDI)<br>
     * InjectアノテーションよりAPサーバー(Glassfish)側で自動的にインスタンス作成(new)される。<br>
     */
    @Inject
    private S001Bean s001Bean;

    @Inject
    private S021Bean s021Bean;
    
    @Inject
    private SyuekiFlgEditBean syuekiFlgEditBean;

    @Inject
    private SyuekiFlgEditBeanMessageBean syuekiFlgEditBeanMessageBean;
    
    /**
     * マスタ選択候補格納データをinjection(CDI)<br>
     */
    @Inject
    private S001MstBean s001MstBean;
    
    @Inject
    private ValidationInfoBean validationInfoBean;
    
    @Inject
    private SysdateEntityFacade sysdateFacade;
    
    /**
     * 初期表示
     * @param req
     * @param resp
     * @return
     * @throws Exception 
     */
    public String indexAction(HttpServletRequest req, HttpServletResponse resp)
    throws Exception {
        logger.info("S001Servlet#indexAction");
        
        // リクエストパラメータをs001Beanの同名フィールドに一括コピー
        ParameterBinder.Bind(s001Bean, req);
        
        // 不要な情報もパラメータに含まれている可能性があるので事業部以外削除
        String dCode = s001Bean.getDivisionCode();
        PropertyUtils.copyProperties(s001Bean, (new S001Bean()));
        s001Bean.setDivisionCode(dCode);

        // サービスの実行(トランザクションの単位にもなる)
        s001Service.indexExecute();

        return INDEX_JSP;
    }

    /**
     * 一覧データ取得
     * @param req
     * @param resp
     * @return
     * @throws Exception 
     */
    public String listAction(HttpServletRequest req, HttpServletResponse resp)
    throws Exception {
        logger.info("S001Servlet#listAction");

        // リクエストパラメータをs001Beanの同名フィールドに一括コピー
        ParameterBinder.Bind(s001Bean, req);
        
        // ダイレクトアクセスされた場合はindexにリダイレクト
        if (!"1".equals(s001Bean.getListFlg())) {
            resp.sendRedirect(req.getContextPath() + "/servlet/S001");
            return null;
        }

        // パラメータのバリデーションチェック
        S001Validation validation = new S001Validation(s001Bean);
        validation.execListValidation(validationInfoBean);

        if (validationInfoBean.isSuccess()) {
            // サービスの実行(トランザクションの単位にもなる)
            // ※バリデーションチェックに通った場合のみサービス実行。
            s001Service.listExecute();
        } else if (!"1".equals(s001Bean.getDetailFlg())) {
            s001Service.initDetailCondition();
        }

        // jspをforward
        return INDEX_JSP;
    }

    /**
     * 編集表示
     * @param req
     * @param resp
     * @return
     * @throws Exception 
     */
    public String editAction(HttpServletRequest req, HttpServletResponse resp)
    throws Exception {
        logger.info("S001Servlet#editAction");

        // リクエストパラメータをs001Beanの同名フィールドに一括コピー
        ParameterBinder.Bind(s001Bean, req);
        
        // ダイレクトアクセスされた場合はindexにリダイレクト
        if (!"1".equals(s001Bean.getListFlg())) {
            resp.sendRedirect(req.getContextPath() + "/servlet/S001");
            return null;
        }

        // パラメータのバリデーションチェック
        S001Validation validation = new S001Validation(s001Bean);
        validation.execListValidation(validationInfoBean);

        if (validationInfoBean.isSuccess()) {
            // サービスの実行(トランザクションの単位にもなる)
            // ※バリデーションチェックに通った場合のみサービス実行。
            s001Service.editExecute();
        } else if (!"1".equals(s001Bean.getDetailFlg())) {
            s001Service.initDetailCondition();
        }

        // jspをforward
        return INDEX_JSP;
    }
    
    /**
     * 保存処理
     * @param req
     * @param resp
     * @return
     * @throws Exception 
     */
    public String saveAction(HttpServletRequest req, HttpServletResponse resp)
    throws Exception {
        logger.info("S001Servlet#saveAction");

        // リクエストパラメータをs001Beanの同名フィールドに一括コピー
        ParameterBinder.Bind(s001Bean, req);

        s001Service.saveExecute();

        return null;
    }
    
    /**
     * 表示切替
     * @param req
     * @param resp
     * @return
     * @throws Exception 
     */
    public String changeAction(HttpServletRequest req, HttpServletResponse resp)
    throws Exception {
        logger.info("S001Servlet#changeAction");

        // リクエストパラメータをs001Beanの同名フィールドに一括コピー
        ParameterBinder.Bind(s001Bean, req);
        
        // ダイレクトアクセスされた場合はindexにリダイレクト
        if (!"1".equals(s001Bean.getListFlg())) {
            resp.sendRedirect(req.getContextPath() + "/servlet/S001");
            return null;
        }

        // パラメータのバリデーションチェック
        S001Validation validation = new S001Validation(s001Bean);
        validation.execListValidation(validationInfoBean);

        if (validationInfoBean.isSuccess()) {
            // サービスの実行(トランザクションの単位にもなる)
            // ※バリデーションチェックに通った場合のみサービス実行。
            s001Service.changeExecute();
        } else if (!"1".equals(s001Bean.getDetailFlg())) {
            s001Service.initDetailCondition();
        }

        // jspをforward
        return INDEX_JSP;
    }

    /**
     * csv出力
     * @param req
     * @param resp
     * @return
     * @throws Exception 
     */
    public String outputCsvAction(HttpServletRequest req, HttpServletResponse resp)
    throws Exception {
        logger.info("S001Servlet#outputCsvAction");

        // リクエストパラメータをs001Beanの同名フィールドに一括コピー
        ParameterBinder.Bind(s001Bean, req);

        // ダイレクトアクセスされた場合はindexにリダイレクト
        if (!"1".equals(s001Bean.getListFlg())) {
            resp.sendRedirect(req.getContextPath() + "/servlet/S001");
            return null;
        }

        // resopnse header設定
        setDownloadCsvHeader(resp, "案件検索_" + (new SimpleDateFormat("yyyyMMddHHmm")).format(new Date()) + ".csv");

        // csv出力
        PrintWriter writer = resp.getWriter();
        s001Service.csvExecute(writer);

        writer.flush();

        // jspは出力しないのでnull
        return null;
    }
    
    /**
     * BU選択時に収益分類マスタを絞り込み
     * @param req
     * @param resp
     * @return
     * @throws Exception 
     */
    public String bunruiMstAction(HttpServletRequest req, HttpServletResponse resp) 
    throws Exception {
        logger.info("S001Servlet#bunruiMstAction");

        // リクエストパラメータをs001Beanの同名フィールドに一括コピー
        ParameterBinder.Bind(s001Bean, req);

        s001Service.bunruiMstExecute();

        // 結果セットをjson出力
        Map<String, Object> jsonMap = new HashMap<>();
        jsonMap.put("bunruiMst", s001MstBean.getBunruiList());
        jsonMap.put("bunruiCd", s001Bean.getBunruiCd());
        resopnseDecodeJson(resp, jsonMap);

        // ここでは戻すjspが存在しないため、nullを返す。
        return null;
    }

    /**
     * (My案件)JobGr選択時に所属担当者を絞り込み
     * @param req
     * @param resp
     * @return
     * @throws Exception 
     */
    public String jobgrMemberMstAction(HttpServletRequest req, HttpServletResponse resp) 
    throws Exception {
        logger.info("S001Servlet#jobgrMemberMstAction");
        
        // リクエストパラメータをs001Beanの同名フィールドに一括コピー
        ParameterBinder.Bind(s001Bean, req);
        
        s001Service.jobGrMemberMstExecute();

        // 結果セットをjson出力
        Map<String, Object> jsonMap = new HashMap<>();
        jsonMap.put("jobGrMemberList", s001MstBean.getMyJobGrMemberList());
        resopnseDecodeJson(resp, jsonMap);
        
        // ここでは戻すjspが存在しないため、nullを返す。
        return null;
    }
    
    /**
     * 検索条件の指定により対象(予算ベース)の選択候補を絞り込み
     * @param req
     * @param resp
     * @return
     * @throws Exception 
     */
    public String taishoAction(HttpServletRequest req, HttpServletResponse resp) 
    throws Exception {
        logger.info("S001Servlet#taishoAction");

        // リクエストパラメータをS001Beanの同名フィールドに一括コピー
        ParameterBinder.Bind(s001Bean, req);

        s001Service.taishoExecute();

        // 結果セットをjson出力
        Map<String, Object> jsonMap = new HashMap<>();
        jsonMap.put("taishoList", s001Bean.getTaishoList());
//        jsonMap.put("taishoYm", s001Bean.getTaishoYm());
        resopnseDecodeJson(resp, jsonMap);

        // ここでは戻すjspが存在しないため、nullを返す。
        return null;
    }
    
    /**
     * ダウンロード指定オプションダイアログをOpen
     * @param req
     * @param resp
     * @return
     * @throws Exception 
     */
    public String downloadOptionAction(HttpServletRequest req, HttpServletResponse resp)
    throws Exception {
        logger.info("S001Servlet#downloadOptionAction");

        ParameterBinder.Bind(s001Bean, req);
        
        s001Service.defaultDownloadOption();
//        s001Bean.setOptionKiChangeFlg("1");
//
//        // 年月or予算期(データ種別:月次確定or予算ベース)の場合、オプション画面デフォルトで指定する年と期を設定
//        String baseYm = SyuuekiUtils.getChangeBaseYm(StringUtils.replace(s001Bean.getTaishoYm(), "/", ""));
//        String baseKi = "";
//        if (StringUtils.isNotEmpty(baseYm)) {
//            logger.info("[downloadOptionAction] taishoYm=[{}] baseYm=[{}]", s001Bean.getTaishoYm(), baseYm);
//            Date baseDate = Utils.parseDate(baseYm);
//            baseKi = SyuuekiUtils.dateToKikan(baseDate);
//            baseKi = SyuuekiUtils.changeDecodeKikanLabel(baseKi);
//        }
//        // 年月or予算期が指定されている場合、その期をデフォルト指定して、変更も不可にする。
//        if (StringUtils.isNotEmpty(baseKi)) {
//            String nendo = StringUtils.substring(baseKi, 0, 4);
//            String ki = StringUtils.substring(baseKi, 4, 5);
//            
//            s001Bean.setTaishoY(nendo);
//            s001Bean.setTaishoKi(ki);
//            s001Bean.setOptionKiChangeFlg("0");
//            logger.info("[downloadOptionAction] defaultNendo=[{}] defaultKi=[{}]", nendo, ki);
//        }

        return OPTION_JSP;
    }

    /**
     * 案件一覧(Excel)/サマリ表(Excel)/受注残一覧(Excel) ダウンロード
     * @param req
     * @param resp
     * @return
     * @throws Exception 
     */
    public String excelListDownloadAction(HttpServletRequest req, HttpServletResponse resp)
    throws Exception {
        logger.info("S001Servlet#excelListDownloadAction");

        ParameterBinder.Bind(s001Bean, req);
        
        Date now = sysdateFacade.getSysdate();
        SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMddHHmm");
        
        // テンプレートファイルの読み込み
        String templateFileName = "";
        String downloadFileName = "";
        String outPutKbn = StringUtils.defaultString(s001Bean.getOutputKbn());
        switch (outPutKbn) {
            case "1":
                templateFileName = "ankenList_template.xlsx";
                downloadFileName = "案件一覧(月別)";
                break;
            case "2":
                templateFileName = "summaryList_template.xlsx";
                downloadFileName = "サマリ表(月別)";
                break;
            case "3":
                templateFileName = "jyuchuZanList_template.xlsx";
                downloadFileName = "受注残一覧";
                break;
        }
 
        String filePath = req.getServletContext().getRealPath("WEB-INF/template/" + templateFileName);
        logger.info("DownloadFilePath=" + filePath);
        Workbook workbook = PoiUtil.getWorkbook(new File(filePath));
        
        // テンプレートにデータを出力
        s001DownloadService.downloadExecute();
        
        // ファイル名「[案件番号]_期間損益_[YYYYMMDDHH24MI].xlsx」
        FileUtils.httpDownloadExcelResponse(workbook, downloadFileName + "_" + sdf.format(now) + ".xlsx", resp);

        return null;
    }
    
    /**
     * 受注売上見込一覧Csvダウンロード
     * @param req
     * @param resp
     * @return
     * @throws Exception 
     */
    public String csvListDownloadAction(HttpServletRequest req, HttpServletResponse resp)
    throws Exception {
        logger.info("S001Servlet#csvListDownloadAction");

        ParameterBinder.Bind(s001Bean, req);

        Date now = sysdateFacade.getSysdate();
        SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMddHHmm");
        String downloadFileName = "案件一覧";

        // resopnse header設定
        setDownloadCsvHeader(resp, downloadFileName + "_" + sdf.format(now) + ".csv");

        // csv出力
        PrintWriter writer = resp.getWriter();
        s001DownloadService.downloadCsvExecute(writer);

        writer.flush();

        return null;
    }

    /**
     * 収益対象FLGの設定
     * @param req
     * @param resp
     * @return
     * @throws Exception 
     */
    public String editSyuekiFlgAction(HttpServletRequest req, HttpServletResponse resp)
    throws Exception {
        logger.info("S001Servlet#editSyuekiFlgAction");

        ParameterBinder.Bind(syuekiFlgEditBean, req);
        int messageInfoDispFlg = 0;

        // バリデーション
        boolean validationFlg = syuekiFlgEditService.validationEdit();
        if (validationFlg && !"1".equals(syuekiFlgEditBean.getValidationOnlyFlg())) {
            syuekiFlgEditService.editSyuekiFlgMainExecute();
            messageInfoDispFlg = 1;
        }

        Map<String, Object> jsonMap = new HashMap<>();
        jsonMap.put("resultFlg", syuekiFlgEditBean.getResultFlg());
        jsonMap.put("resultMessage", syuekiFlgEditBean.getResultMessage());
        jsonMap.put("processMessageInfoDispFlg", messageInfoDispFlg);
        resopnseDecodeJson(resp, jsonMap);

        return null;
    }

    /**
     * 収益対象FLGの解除
     * @param req
     * @param resp
     * @return
     * @throws Exception 
     */
    public String relSyuekiFlgAction(HttpServletRequest req, HttpServletResponse resp)
    throws Exception {
        logger.info("S001Servlet#relSyuekiFlgAction");

        ParameterBinder.Bind(syuekiFlgEditBean, req);
        int messageInfoDispFlg = 0;

        // バリデーション
        boolean validationFlg = syuekiFlgEditService.validationRel();
        if (validationFlg && !"1".equals(syuekiFlgEditBean.getValidationOnlyFlg())) {
            syuekiFlgEditService.relSyuekiFlgMainExecute();
            messageInfoDispFlg = 1;
        }

        Map<String, Object> jsonMap = new HashMap<>();
        jsonMap.put("resultFlg", syuekiFlgEditBean.getResultFlg());
        jsonMap.put("resultMessage", syuekiFlgEditBean.getResultMessage());
        jsonMap.put("processMessageInfoDispFlg", messageInfoDispFlg);
        resopnseDecodeJson(resp, jsonMap);
        
        return null;
    }

    /**
     * パターン検索用の検索条件設定処理(検索条件を保存した検索パターンより取得する)
     * @param req
     * @param resp
     * @return
     * @throws Exception 
     */
    public String patternSearchsCondtionAction(HttpServletRequest req, HttpServletResponse resp)
    throws Exception {
        logger.info("S001Servlet#patternSearchCondtionAction");
        
        ParameterBinder.Bind(s001Bean, req);
        
        // 初期処理
        s001Service.patternIndexExecute();

        // 保存していたパターン検索用の条件をセット
        s021Bean.setDisplayId("ANKEN");
        s021Bean.setPatternSeq(s001Bean.getSearchPatternSeq());
        s021Service.copySearchPattern(s001Bean);

        // 再セットしたパターンの条件を元に、各種マスタの選択候補を再取得
        s001Service.setMstDateAll();

        return INDEX_JSP;
    }

}
