/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package jp.co.toshiba.hby.pspromis.syuueki.entity;

import java.io.Serializable;
import javax.persistence.Entity;
import javax.persistence.Column;
import javax.persistence.Id;

/**
 *
 * @author ibayashi
 */
@Entity
public class CategoryName implements Serializable {

    private static final long serialVersionUID = 1L;

    @Id
    @Column(name = "CATEGORY_KBN")
    private String categoryKbn;
    
    @Column(name = "CATEGORY_NAME")
    private String categoryName;

    public String getCategoryKbn() {
        return categoryKbn;
    }

    public void setCategoryKbn(String categoryKbn) {
        this.categoryKbn = categoryKbn;
    }

    public String getCategoryName() {
        return categoryName;
    }

    public void setCategoryName(String categoryName) {
        this.categoryName = categoryName;
    }


}
