package jp.co.toshiba.hby.pspromis.syuueki.servlet;

import java.util.HashMap;
import java.util.Map;
import javax.inject.Inject;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpServletRequest;
import jp.co.toshiba.hby.pspromis.syuueki.bean.ResultMessageBean;
import jp.co.toshiba.hby.pspromis.syuueki.bean.S018Bean;
import jp.co.toshiba.hby.pspromis.syuueki.service.S018Service;
import jp.co.toshiba.hby.pspromis.syuueki.util.CdiUtils;
import jp.co.toshiba.hby.pspromis.syuueki.util.ParameterBinder;

/**
 * ES-Promis収益管理システム
 * 項番カテゴリ設定
 * @author 
 */
@WebServlet(name="S018", urlPatterns={"/servlet/S018", "/servlet/S018/*"})
public class S018Servlet extends AbstractServlet {

    private static final String INDEX_JSP = "S018/editItemCate.jsp";
    
    @Inject
    private S018Bean s018Bean;

    @Inject
    private S018Service s018Service;

    /**
     * 初期表示
     * @param req
     * @param resp
     * @return
     * @throws Exception 
     */
    public String indexAction(HttpServletRequest req, HttpServletResponse resp)
    throws Exception {
        // リクエストパラメータをS018Beanの同名フィールドに一括コピー
        ParameterBinder.Bind(s018Bean, req);

        // サービスの実行(トランザクションの単位にもなる)
        s018Service.indexExecute();

        return INDEX_JSP;
    }

    /**
     * 保存(実行)処理
     * @param req
     * @param resp
     * @return
     * @throws Exception 
     */
    public String saveAction(HttpServletRequest req, HttpServletResponse resp) throws Exception {
        // リクエストパラメータをS018Beanの同名フィールドに一括コピー
        ParameterBinder.Bind(s018Bean, req);

        s018Service.saveExecute();
        
        // 処理結果を戻す。
        Map<String, Object> jsonMap = new HashMap<>();
        ResultMessageBean resultMessageBean = CdiUtils.getBean(ResultMessageBean.class);
        resultMessageBean.createResultMessage(jsonMap);
        resopnseDecodeJson(resp, jsonMap);
        
        return null;
    }

}
