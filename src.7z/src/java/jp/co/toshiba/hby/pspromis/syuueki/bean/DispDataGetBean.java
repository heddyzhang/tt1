package jp.co.toshiba.hby.pspromis.syuueki.bean;

import java.util.Date;
import javax.enterprise.context.RequestScoped;
import javax.inject.Named;

/**
 *
 * @author ibayashi
 */
@Named(value = "dispDataGetBean")
@RequestScoped
public class DispDataGetBean {
    
    /**
     * 一般案件・発番実績日時
     */
    private Date ippanHatJDate;
    
    /**
     * 一般案件・契約実績日時
     */
    private Date ippanKeiyakuJDate;
    
    /**
     * 一般案件・売上実績日時
     */
    private Date ippanUriageJDate;
    
    /**
     * 一般案件・受注残日時
     */
    private Date ippanJyuchuZanDate;
    
    /**
     * 一般案件・中計日時
     */
    private Date ippanChukeiDate;
    
    
    /**
     * 進行基準案件・発番実績日時
     */
    private Date shinkoHatJDate;
    
    /**
     * 進行基準案件・契約実績日時
     */
    private Date shinkoKeiyakuJDate;
    
    /**
     * 進行基準案件・売上実績日時
     */
    private Date shinkoUriageJDate;
    
    /**
     * 進行基準案件・受注残日時
     */
    private Date shinkoJyuchuZanDate;
    
    /**
     * 進行基準案件・中計日時
     */
    private Date shinkoChukeiDate;
    
    public DispDataGetBean() {
    }

    public Date getIppanHatJDate() {
        return ippanHatJDate;
    }

    public void setIppanHatJDate(Date ippanHatJDate) {
        this.ippanHatJDate = ippanHatJDate;
    }

    public Date getIppanKeiyakuJDate() {
        return ippanKeiyakuJDate;
    }

    public void setIppanKeiyakuJDate(Date ippanKeiyakuJDate) {
        this.ippanKeiyakuJDate = ippanKeiyakuJDate;
    }

    public Date getIppanUriageJDate() {
        return ippanUriageJDate;
    }

    public void setIppanUriageJDate(Date ippanUriageJDate) {
        this.ippanUriageJDate = ippanUriageJDate;
    }

    public Date getIppanJyuchuZanDate() {
        return ippanJyuchuZanDate;
    }

    public void setIppanJyuchuZanDate(Date ippanJyuchuZanDate) {
        this.ippanJyuchuZanDate = ippanJyuchuZanDate;
    }

    public Date getIppanChukeiDate() {
        return ippanChukeiDate;
    }

    public void setIppanChukeiDate(Date ippanChukeiDate) {
        this.ippanChukeiDate = ippanChukeiDate;
    }

    public Date getShinkoHatJDate() {
        return shinkoHatJDate;
    }

    public void setShinkoHatJDate(Date shinkoHatJDate) {
        this.shinkoHatJDate = shinkoHatJDate;
    }

    public Date getShinkoKeiyakuJDate() {
        return shinkoKeiyakuJDate;
    }

    public void setShinkoKeiyakuJDate(Date shinkoKeiyakuJDate) {
        this.shinkoKeiyakuJDate = shinkoKeiyakuJDate;
    }

    public Date getShinkoUriageJDate() {
        return shinkoUriageJDate;
    }

    public void setShinkoUriageJDate(Date shinkoUriageJDate) {
        this.shinkoUriageJDate = shinkoUriageJDate;
    }

    public Date getShinkoJyuchuZanDate() {
        return shinkoJyuchuZanDate;
    }

    public void setShinkoJyuchuZanDate(Date shinkoJyuchuZanDate) {
        this.shinkoJyuchuZanDate = shinkoJyuchuZanDate;
    }

    public Date getShinkoChukeiDate() {
        return shinkoChukeiDate;
    }

    public void setShinkoChukeiDate(Date shinkoChukeiDate) {
        this.shinkoChukeiDate = shinkoChukeiDate;
    }

}
