package jp.co.toshiba.hby.pspromis.syuueki.facade;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import javax.ejb.Stateless;
import javax.inject.Inject;
import javax.interceptor.Interceptors;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import jp.co.toshiba.hby.pspromis.syuueki.entity.PlantTypeMst;
import jp.co.toshiba.hby.pspromis.syuueki.entity.PlantMst;
import jp.co.toshiba.hby.pspromis.syuueki.interceptor.TranceInterceptor;
import jp.co.toshiba.hby.pspromis.syuueki.util.Utils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
/**
 *
 * @author horie
 */
@Stateless
@Interceptors({TranceInterceptor.class})
public class PlantMstFacade extends AbstractFacade<PlantMst> {
    
    private static final Logger logger = LoggerFactory.getLogger(PlantMstFacade.class);
    
    @PersistenceContext(unitName = jp.co.toshiba.hby.pspromis.syuueki.util.ConstantString.syuuekiDataSourceName)
    private EntityManager em;

    @Override
    protected EntityManager getEntityManager() {
        return em;
    }

    @Inject
    private Utils util;
    
    public PlantMstFacade() {
        super(PlantMst.class);
    }

    /**
     * サイトを取得
     * @param condition
     * @return 
     */
    public List<PlantMst> getSiteList(Object condition) {
        List<PlantMst> list
                = sqlExecutor.getResultList(em, PlantMst.class, "/sql/plantMst/selectSite.sql", condition);

        List<PlantMst> siteList = new ArrayList<>();
        
        Set<String> set = new HashSet<>();
        String siteCode;

        for (PlantMst plantMst : list) {
            siteCode = plantMst.getN7PwrCode();
            if (!set.contains(siteCode)) {
                siteList.add(plantMst);
            }
            set.add(siteCode);
        }

        return siteList;
    }

    /**
     * 設置先場所の件数を取得
     * @param condition
     * @return 
     */
    public Integer getCount(Object condition) {
        if (condition == null) {
            condition = new HashMap<>();
        }
        if (condition instanceof Map) {
            ((Map)condition).put("listFlg", "1");
        }

        Integer count = sqlExecutor.getCount(em, "/sql/plantMst/selectPlantMst.sql", condition);
        return count;
    }

    /**
     * プラントマスタの一覧を取得(選択ダイアログ)
     * @param condition
     * @return 
     */
    public List<PlantMst> getList(Object condition, Integer page) {
        if (condition == null) {
            condition = new HashMap<>();
        }
        if (condition instanceof Map) {
            ((Map)condition).put("listFlg", "0");
        }

        int limit = util.getPageLimit();
        int offset = util.getPageOffset(page);

        List<PlantMst> list
                = sqlExecutor.getResultList(em, PlantMst.class, "/sql/plantMst/selectPlantMst.sql", condition, limit, offset);

        return list;
    }

}
