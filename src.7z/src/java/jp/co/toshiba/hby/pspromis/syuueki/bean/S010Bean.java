package jp.co.toshiba.hby.pspromis.syuueki.bean;

import java.util.List;
import java.util.Map;
import javax.enterprise.context.RequestScoped;
import javax.inject.Named;
import jp.co.toshiba.hby.pspromis.syuueki.entity.SyuGeBukkenInfoTbl;

/**
 *
 * @author masaki
 */
@Named(value = "s010Bean")
@RequestScoped
public class S010Bean extends AbstractBean {
    
    /**
     * 物件情報テーブル
     */
    private SyuGeBukkenInfoTbl syuGeBukkenInfoTbl;

    /**
     * 今回売上高
     */
    List<Map<String, Object>> amountList;
    
    /**
     * 発番NET
     */
    private String hatNet;
    
    /**
     * 製番損益NET
     */
    private String sbnNet;

    /**
     * 為替洗替影響
     */
    private String kawaseEikyo;

    /**
     * 通貨コード
     */
    private String[] keyCode;

    /**
     * 今回売上高
     */
    private String[] keyValue;
    
    /**
     * 完売月
     */
    private String uriageEndFin;

    public SyuGeBukkenInfoTbl getSyuGeBukkenInfoTbl() {
        return syuGeBukkenInfoTbl;
    }

    public void setSyuGeBukkenInfoTbl(SyuGeBukkenInfoTbl syuGeBukkenInfoTbl) {
        this.syuGeBukkenInfoTbl = syuGeBukkenInfoTbl;
    }

    public String getHatNet() {
        return hatNet;
    }

    public void setHatNet(String hatNet) {
        this.hatNet = hatNet;
    }

    public String getSbnNet() {
        return sbnNet;
    }

    public void setSbnNet(String sbnNet) {
        this.sbnNet = sbnNet;
    }

    public String getUriageEndFin() {
        return uriageEndFin;
    }

    public void setUriageEndFin(String uriageEndFin) {
        this.uriageEndFin = uriageEndFin;
    }

    public String[] getKeyCode() {
        return keyCode;
    }

    public void setKeyCode(String[] keyCode) {
        this.keyCode = keyCode;
    }

    public String[] getKeyValue() {
        return keyValue;
    }

    public void setKeyValue(String[] keyValue) {
        this.keyValue = keyValue;
    }

    public List<Map<String, Object>> getAmountList() {
        return amountList;
    }

    public void setAmountList(List<Map<String, Object>> amountList) {
        this.amountList = amountList;
    }

    /**
     * @return the kawaseEikyo
     */
    public String getKawaseEikyo() {
        return kawaseEikyo;
    }

    /**
     * @param kawaseEikyo the kawaseEikyo to set
     */
    public void setKawaseEikyo(String kawaseEikyo) {
        this.kawaseEikyo = kawaseEikyo;
    }

}
