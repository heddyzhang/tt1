/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package jp.co.toshiba.hby.pspromis.syuueki.facade;

import java.util.HashMap;
import java.util.List;
import java.util.ArrayList;
import java.util.Map;
import javax.ejb.Stateless;
import javax.inject.Inject;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import jp.co.toshiba.hby.pspromis.common.entity.CountEntity;
import jp.co.toshiba.hby.pspromis.syuueki.entity.StringEntity;
import jp.co.toshiba.hby.pspromis.syuueki.entity.SyuWfControlTbl;
import jp.co.toshiba.hby.pspromis.syuueki.jdbc.SqlExecutorOriginal;
import jp.co.toshiba.hby.pspromis.syuueki.util.DateUtils;
import jp.co.toshiba.hby.pspromis.syuueki.util.Utils;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;

/**
 *
 * @author ibayashi
 */
@Stateless
public class SyuWfControlTblFacade extends AbstractFacade<SyuWfControlTbl> {
    @PersistenceContext(unitName = jp.co.toshiba.hby.pspromis.syuueki.util.ConstantString.syuuekiDataSourceName)
    private EntityManager em;

    @Inject
    private Utils util;
    
    @Inject
    private SqlExecutorOriginal sqlExecutorExtend;


     
    @Override
    protected EntityManager getEntityManager() {
        return em;
    }

    public SyuWfControlTblFacade() {
        super(SyuWfControlTbl.class);
    }
    /**
     * WF一覧の総件数を取得
     * @param condition
     * @return 
     */
    public CountEntity findTotalCount(Map<String, Object> condition) { 
        condition.put("listFlg", "1");

        CountEntity entity =
                sqlExecutor.getSingleResult(em, CountEntity.class, "/sql/syuWfControlTbl/selectSyuWfControlTbl.sql", condition);

        return entity;
    }

    /**
     * 指定ページのWF一覧の総件数を取得
     * @param condition
     * @return 
     */
    public List<SyuWfControlTbl> findList(Map<String, Object> condition, Integer page) throws Exception {
        int limit = util.getPageLimit();
        int offset = util.getPageOffset(page);

        condition.put("listFlg", "0");

        List<SyuWfControlTbl> list
                = sqlExecutor.getResultList(em, SyuWfControlTbl.class,  "/sql/syuWfControlTbl/selectSyuWfControlTbl.sql", condition, limit, offset);

        return list;
    }

    /**
     * 一般物件取得対象のWFデータを取得
     * @param condition
     * @return 
     */
    public List<SyuWfControlTbl> findTargetBukken(String divisionCode, String salesClass, String kanjyoYm, String cBukaCode) throws Exception {
        return findTargetBukken(divisionCode, salesClass, kanjyoYm, cBukaCode, null);
    }
    public List<SyuWfControlTbl> findTargetBukken(String divisionCode, String salesClass, String kanjyoYm, String cBukaCode, String concatTeamCode) throws Exception {
        Map<String, Object> condition = new HashMap<>();
        condition.put("divisionCode", divisionCode);
        condition.put("salesClass", salesClass);
        condition.put("kanjyoYm", kanjyoYm);
        condition.put("cBukaCode", cBukaCode);
        if(concatTeamCode != null){
            condition.put("concatTeamCode", concatTeamCode);
        }
        if(concatTeamCode!=null && concatTeamCode.length()>0){
            condition.put("concatTeamCode", concatTeamCode.split(",", 0));
        }

        List<SyuWfControlTbl> list
                = sqlExecutor.getResultList(em, SyuWfControlTbl.class, "/sql/syuWfControlTbl/selectSyuWfControlTblTargetBukken.sql", condition);

        return list;
    }
    
    /**
     * 指定GroupCodeのWFデータを取得
     * @param condition
     * @return 
     */
    public List<SyuWfControlTbl> findGroupCode(String divisionCode, String groupCode, String salesClass, String kanjyoYm) throws Exception {
        Map<String, String> condition = new HashMap<>();
        condition.put("divisionCode", divisionCode);
        condition.put("groupCode", groupCode);
        condition.put("salesClass", salesClass);
        condition.put("kanjyoYm", kanjyoYm);

        List<SyuWfControlTbl> list
                = sqlExecutor.getResultList(em, SyuWfControlTbl.class, "/sql/syuWfControlTbl/selectSyuWfControlTblGroupCode.sql", condition);

        return list;
    }

    /**
     * 指定GroupCodeのWFデータを取得
     * @param condition
     * @return 
     */
    public List<SyuWfControlTbl> findBukaCode(String divisionCode, String cBukaCode, String salesClass, String kanjyoYm, String dispFlg) throws Exception {
        String[] divisionCodeList = null;
        if (StringUtils.isNotEmpty(divisionCode)) {
            divisionCodeList = new String[1];
            divisionCodeList[0] = divisionCode;
        }

        String[] salesClassList = null;
        if (StringUtils.isNotEmpty(salesClass)) {
            salesClassList = new String[1];
            salesClassList[0] = salesClass;
        }

        return this.findBukaCode(divisionCodeList, cBukaCode, salesClassList, kanjyoYm, dispFlg);
    }

    /**
     * 指定GroupCodeのWFデータを取得
     * @param condition
     * @return 
     */
    public List<SyuWfControlTbl> findBukaCode(String[] divisionCode, String cBukaCode, String[] salesClass, String kanjyoYm, String dispFlg) throws Exception {
        Map<String, Object> condition = new HashMap<>();
        condition.put("divisionCode", divisionCode);
        condition.put("cBukaCode", cBukaCode);
        condition.put("salesClass", salesClass);
        condition.put("kanjyoYm", kanjyoYm);
        condition.put("dispFlg", dispFlg);

        return this.findBukaCode(condition);
    }

    /**
     * 指定GroupCodeのWFデータを取得
     * @param condition
     * @return 
     */
    public List<SyuWfControlTbl> findBukaCode(Map<String, Object> condition) throws Exception {
        List<SyuWfControlTbl> list
                = sqlExecutor.getResultList(em, SyuWfControlTbl.class, "/sql/syuWfControlTbl/selectSyuWfControlTblBukaCode.sql", condition);

        return list;
    }

    /**
     * 指定PKのWFデータを取得
     * @param condition
     * @return 
     */
    public SyuWfControlTbl findPk(String divisionCode, String groupCode, String salesClass, String kanjyoYm, String honsyaShisyaKbn, String teamCode) throws Exception {
        Map<String, String> condition = new HashMap<>();
        condition.put("divisionCode", divisionCode);
        condition.put("groupCode", groupCode);
        condition.put("salesClass", salesClass);
        condition.put("kanjyoYm", kanjyoYm);
        condition.put("honsyaShisyaKbn", honsyaShisyaKbn);
        condition.put("teamCode", teamCode);

        SyuWfControlTbl entity
                = sqlExecutor.getSingleResult(em, SyuWfControlTbl.class, "/sql/syuWfControlTbl/selectSyuWfControlTblPk.sql", condition);

        return entity;
    }

    /**
     * 指定PKのWFデータ(前月確定分)を取得
     * @param condition
     * @return 
     */
    public SyuWfControlTbl findPkBefore(String divisionCode, String groupCode, String salesClass, String beforeKanjyoYm, String syubetsu, String honsyaShisyaKbn, String teamCode) throws Exception {
        Map<String, String> condition = new HashMap<>();
        condition.put("divisionCode", divisionCode);
        condition.put("groupCode", groupCode);
        condition.put("salesClass", salesClass);
        condition.put("beforeKanjyoYm", beforeKanjyoYm);
        condition.put("syubetsu", syubetsu);
        condition.put("honsyaShisyaKbn", honsyaShisyaKbn);
        condition.put("teamCode", teamCode);

        SyuWfControlTbl entity
                = sqlExecutor.getSingleResult(em, SyuWfControlTbl.class, "/sql/syuWfControlTbl/selectSyuWfControlTblBeforePk.sql", condition);

        return entity;
    }
    
    /**
     * ワークフロー実行
     * @param condition
     */
    public void updateWorkFlow(Map<String, Object> condition) {
        sqlExecutor.executeUpdateSql(em, "/sql/syuWfControlTbl/updateWorkFlow.sql", condition);
    }
    /**
     * 一般案件時の追加ワークフロー実行
     * @param condition
     */
    //public void updateIppanWorkFlow(Map<String, Object> condition) {
    public void updateIppanWorkFlow(Object condition) {
        sqlExecutor.executeUpdateSql(em, "/sql/syuWfControlTbl/updateIppanWorkFlow.sql", condition);
    }
    
    /**
     * 履歴IDをカンマ区切りで取得
     * @param condition
     * @return 
     */
    public String findRirekiId(Map<String, Object> condition) {
        String rirekiId = "";
        List<StringEntity> list
                = sqlExecutor.getResultList(em, StringEntity.class,  "/sql/syuWfControlTbl/selectSyuWfControlTblRirekiId.sql", condition);

        for(StringEntity id : list){
            rirekiId += id.getString() + ",";
        }
        if(rirekiId.length() > 0){
            rirekiId = rirekiId.substring(0, rirekiId.length() - 1);
        }

        return rirekiId;
    }
    
    /**
     * 予算ベースの対象候補を取得
     * @param condition
     * @return 
     */
    public List<SyuWfControlTbl> findYosanTaisho(Map<String, Object> condition) {
        List<SyuWfControlTbl> list
                = sqlExecutor.getResultList(em, SyuWfControlTbl.class, "/sql/syuWfControlTbl/selectYosanKanjyoYm.sql", condition);
        return list;
    }

    /**
     * 一般データの更新対象ステータス、各期集計値を取得
     * @param condition
     * @return 
     */
    public SyuWfControlTbl findIppanStatusInfo(Map<String, Object> condition) {
        SyuWfControlTbl entity
                = sqlExecutor.getSingleResult(em, SyuWfControlTbl.class, "/sql/syuWfControlTbl/selectIppanMaxStatusInfo.sql", condition);
        return entity;
    }

    /**
     * 本社GROUP_CODE対象一覧データを取得(サマリリスト利用)
     */
    public List<SyuWfControlTbl> findSummaryGroupList(Map<String, Object> condition) {
        List<SyuWfControlTbl> list
                = sqlExecutor.getResultList(em, SyuWfControlTbl.class, "/sql/syuWfControlTbl/selectSyuWfControlTblSummaryGroup.sql", condition);
        return list;
    }

    /**
     * 登録されている年を一覧で取得
     */
    public List<String> findYearList() {
        List<StringEntity> list
                = sqlExecutor.getResultList(em, StringEntity.class, "/sql/syuWfControlTbl/selectYearList.sql", null);
        
        List<String> yearList = new ArrayList<>();
        if (CollectionUtils.isNotEmpty(list)) {
            for (StringEntity entity: list) {
                yearList.add(entity.getString());
            }
        }
        return yearList;
    }
    
    /**
     * 指定条件の最新勘定月を取得する
     */
    public String getMaxKanjyoYm(String divisionCode, String groupCode, String salesClass, String dataKbn) {
        Map<String, Object> condition = new HashMap<>();
        condition.put("dataKbn", dataKbn);
        condition.put("divisionCode", divisionCode);
        condition.put("groupCode", groupCode);
        condition.put("salesClass", salesClass);
        
        List<StringEntity> list
                = sqlExecutor.getResultList(em, StringEntity.class, "/sql/syuWfControlTbl/selectMaxKanjyoYm.sql", condition);
        
        StringEntity entity = list.get(0);
        return StringUtils.defaultString(entity.getString());
    }

    /**
     * 
     */
    public String getSyoninAt(Map<String, Object> condition){
        SyuWfControlTbl entity = null;
        String date = "";
        
        List<SyuWfControlTbl> list
                = sqlExecutor.getResultList(em, SyuWfControlTbl.class, "/sql/syuWfControlTbl/selectSyoninAt.sql", condition);
        
        if(CollectionUtils.isNotEmpty(list)){
            entity = list.get(0);
            date = DateUtils.getDateString(entity.getSyoninAt());
        }
        
        return date;
        
    }
}
