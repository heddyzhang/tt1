package jp.co.toshiba.hby.pspromis.syuueki.servlet;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.io.File;
import javax.inject.Inject;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpServletRequest;
import jp.co.toshiba.hby.pspromis.syuueki.bean.DownloadOptBean;
import jp.co.toshiba.hby.pspromis.syuueki.bean.S001Bean;
import jp.co.toshiba.hby.pspromis.syuueki.enums.Env;
import jp.co.toshiba.hby.pspromis.syuueki.service.download.IkkatsuListService;
import jp.co.toshiba.hby.pspromis.syuueki.service.download.ShinkoListService;
import jp.co.toshiba.hby.pspromis.syuueki.facade.SysdateEntityFacade;
import jp.co.toshiba.hby.pspromis.syuueki.util.FileUtils;
import jp.co.toshiba.hby.pspromis.syuueki.util.ParameterBinder;
import jp.co.toshiba.hby.pspromis.syuueki.util.PoiUtil;
import org.apache.commons.io.FilenameUtils;
import org.apache.poi.ss.usermodel.Workbook;

/**
 * ES-Promis収益管理システム
 * 案件検索 Servlet
 * @author (NPC)S.Ibayashi
 */
@WebServlet(name="DownloadOpt", urlPatterns={"/servlet/downloadOpt/*"})
public class DownloadOptServlet extends AbstractServlet {

    private static final String OPT_IKKATSU_JSP = "download/downloadOptionIkkatsu.jsp";

    private static final String OPT_SHINKO_JSP = "download/downloadOptionShinko.jsp";

    @Inject
    private DownloadOptBean downloadOptBean;
    
    @Inject
    private S001Bean s001Bean;
    
    @Inject
    private IkkatsuListService downloadIkkatsuService;

    @Inject
    private ShinkoListService shinkoListService;
    
    @Inject
    private SysdateEntityFacade sysdateFacade;
    
    /**
     * 一括ダウンロード(Excel) ダウンロードオプション表示
     * @param req
     * @param resp
     * @return
     * @throws Exception 
     */
    public String optIkkatsuAction(HttpServletRequest req, HttpServletResponse resp)
    throws Exception {
        // リクエストパラメータをs001Beanの同名フィールドに一括コピー
        //ParameterBinder.Bind(s001Bean, req);

        return OPT_IKKATSU_JSP;
    }

    /**
     * 一括ダウンロード(Excel) ダウンロードファイル作成
     * @param req
     * @param resp
     * @return
     * @throws Exception 
     */
    public String createIkkatsuListAction(HttpServletRequest req, HttpServletResponse resp)
    throws Exception {
        ParameterBinder.Bind(downloadOptBean, req);
        ParameterBinder.Bind(s001Bean, req);

        downloadIkkatsuService.createFileExecute(req, resp);

        Map<String, String> jsonInfo = new HashMap<>();
        jsonInfo.put("downloadFileName", downloadOptBean.getDownloadFileName());
        
        resopnseDecodeJson(resp, jsonInfo);
        return null;
    }

    /**
     * 一括ダウンロード(Excel) ファイルをダウンロード
     * @param req
     * @param resp
     * @return
     * @throws Exception 
     */
    public String downloadIkkatsuFileAction(HttpServletRequest req, HttpServletResponse resp)
    throws Exception {
        ParameterBinder.Bind(downloadOptBean, req);
        ParameterBinder.Bind(s001Bean, req);

        Date now = sysdateFacade.getSysdate();
        SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMddHHmm");
        
        String downloadFilePath = downloadIkkatsuService.getDownloadFilePath();
        //String fileName = FilenameUtils.getBaseName(downloadFilePath) + "." + FilenameUtils.getExtension(downloadFilePath);
        String fileName = "一括ダウンロード_" + sdf.format(now) + "." + FilenameUtils.getExtension(downloadFilePath);
        FileUtils.httpDownloadResponse(downloadFilePath, fileName, resp, false);

        // 作業ディレクトリの削除
        String wkDirPath = Env.Download_Temp_Dir_Work.getValue() + "/" + downloadOptBean.getDownloadFileName() ;
        FileUtils.deleteDir(new File(wkDirPath));
        
        return null;
    }

    /**
     * 工事進行基準案件リスト(Excel) ダウンロードオプション表示
     * @param req
     * @param resp
     * @return
     * @throws Exception 
     */
    public String optShinkoAction(HttpServletRequest req, HttpServletResponse resp)
    throws Exception {
        // リクエストパラメータをs001Beanの同名フィールドに一括コピー
        //ParameterBinder.Bind(s001Bean, req);

        // サービスの実行
        shinkoListService.indexOptionExecute();

        return OPT_SHINKO_JSP;
    }

    /**
     * 工事進行基準案件リスト(Excel) ファイルをダウンロード
     * @param req
     * @param resp
     * @return
     * @throws Exception 
     */
    public String downloadShinkoListFileAction(HttpServletRequest req, HttpServletResponse resp)
    throws Exception {
        ParameterBinder.Bind(downloadOptBean, req);
        ParameterBinder.Bind(s001Bean, req);
        
        logger.info("downloadShinkoListFileAction optionShinkoOutputAnkenKbn=[{}]"
                + " optionShinkoOutputForginKbn=[{}] "
                + " optionShinkoOutputYearNow=[{}] "
                + " optionShikoOutputMonthNow=[{}]"
                + " optionShinkoOutputYearBefore=[{}]"
                + " optionShinkoOutputMonthBefore=[{}]",
            downloadOptBean.getOptionShinkoOutputAnkenKbn(), 
            downloadOptBean.getOptionShinkoOutputForginKbn(), 
            downloadOptBean.getOptionShinkoOutputYearNow(), 
            downloadOptBean.getOptionShikoOutputMonthNow(),
            downloadOptBean.getOptionShinkoOutputYearBefore(),
            downloadOptBean.getOptionShinkoOutputMonthBefore()
        );

        Date now = sysdateFacade.getSysdate();
        SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMddHHmm");

        // テンプレートファイルの読み込み
        String templateFileName = "shinkoList_template.xlsx";
        String downloadFileName = "工事進行基準リスト";
 
        String filePath = req.getServletContext().getRealPath("WEB-INF/template/" + templateFileName);
        logger.info("DownloadFilePath=" + filePath);
        Workbook workbook = PoiUtil.getWorkbook(new File(filePath));

        shinkoListService.downloadExecute(workbook);

        FileUtils.httpDownloadExcelResponse(workbook, downloadFileName + "_" + sdf.format(now) + ".xlsx", resp);
        return null;
    }

}
