package jp.co.toshiba.hby.pspromis.syuueki.entity;

import java.io.Serializable;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

/**
 *
 * @author kitajima
 */
@Entity
@Table(name = "SYU_KI_NET_CATE_TITLE_TBL")
public class SyuKiNetCateTitleTblView implements Serializable {
    private static final long serialVersionUID = 1L;
    @NotNull
    @Size(max = 10)
    @Column(name = "CATEGORY_CODE")
    @Id
    private String categoryCode;
    @Size(max = 256)
    @Column(name = "CATEGORY_NAME")
    @Id
    private String categoryName;
    @Size(max = 7)
    @Column(name = "CATEGORY_SEQ")
    private String categorySeq;

    public SyuKiNetCateTitleTblView() {
    }

    public String getCategoryCode() {
        return categoryCode;
    }

    public void setCategoryCode(String categoryCode) {
        this.categoryCode = categoryCode;
    }
    
    public String getCategoryName() {
        return categoryName;
    }

    public void setCategoryName(String categoryName) {
        this.categoryName = categoryName;
    }

    public String getCategorySeq() {
        return categorySeq;
    }

    public void setCategorySeq(String categorySeq) {
        this.categorySeq = categorySeq;
    }

}