/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package jp.co.toshiba.hby.pspromis.syuueki.entity;

import java.io.Serializable;
import java.math.BigDecimal;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.validation.constraints.NotNull;

/**
 *
 * @author sano
 */
@Entity
public class Cost implements Serializable {
    private static final long serialVersionUID = 1L;
    
    @Id
    @Column(name = "CATEGORY_CODE")
    private String categoryCode;
    @Id
    @Column(name = "CATEGORY_KBN1")
    private String categoryKbn1;
    @Id
    @Column(name = "CATEGORY_KBN2")
    private String categoryKbn2;
    @Column(name = "CATEGORY_NAME1")
    private String categoryName1;
    @Column(name = "CATEGORY_NAME2")
    private String categoryName2;
    
    @Column(name = "NET_1")
    private BigDecimal net1;
    @Column(name = "NET_2")
    private BigDecimal net2;
    @Column(name = "NET_3")
    private BigDecimal net3;
    @Column(name = "NET_4")
    private BigDecimal net4;
    @Column(name = "NET_5")
    private BigDecimal net5;
    @Column(name = "NET_6")
    private BigDecimal net6;
    @Column(name = "NET_7")
    private BigDecimal net7;
    @Column(name = "NET_8")
    private BigDecimal net8;
    @Column(name = "NET_9")
    private BigDecimal net9;
    @Column(name = "NET_10")
    private BigDecimal net10;
    @Column(name = "NET_11")
    private BigDecimal net11;
    @Column(name = "NET_12")
    private BigDecimal net12;;
    @Column(name = "NET_TM")
    private BigDecimal netTm;
    @Column(name = "NET_K1")
    private BigDecimal netK1;
    @Column(name = "NET_K2")
    private BigDecimal netK2;
    @Column(name = "NET_G")
    private BigDecimal netG;
    @Column(name = "NET_F")
    private BigDecimal netF;
    @Column(name = "NET_K1_DIFF")
    private BigDecimal netK1Diff;
    @Column(name = "NET_K2_DIFF")
    private BigDecimal netK2Diff;
    @Column(name = "NET_G_DIFF")
    private BigDecimal netGDiff;
    @Column(name = "NET_DIFF")
    private BigDecimal netDiff;
    
    @Column(name = "INPUT_FLG")
    private String inputFlg;

    @Column(name = "NET_1Q")
    private BigDecimal net1Q;
    @Column(name = "NET_2Q")
    private BigDecimal net2Q;
    @Column(name = "NET_3Q")
    private BigDecimal net3Q;
    @Column(name = "NET_4Q")
    private BigDecimal net4Q;
    
    @Column(name = "NET_1Q_DIFF")
    private BigDecimal net1QDiff;
    @Column(name = "NET_2Q_DIFF")
    private BigDecimal net2QDiff;
    @Column(name = "NET_3Q_DIFF")
    private BigDecimal net3QDiff;
    @Column(name = "NET_4Q_DIFF")
    private BigDecimal net4QDiff;

    @Column(name = "URIAGE_RUIKEI_NET")
    private BigDecimal uriageRuikeiNet;
    
    public Cost() {
    }

    public String getCategoryCode() {
        return this.categoryCode;
    }

    public void setCategoryCode(String categoryCode) {
        this.categoryCode = categoryCode;
    }

    public String getCategoryKbn1() {
        return this.categoryKbn1;
    }

    public void setCategoryKbn1(String categoryKbn1) {
        this.categoryKbn1 = categoryKbn1;
    }

    public String getCategoryKbn2() {
        return this.categoryKbn2;
    }

    public void setCategoryKbn2(String categoryKbn2) {
        this.categoryKbn2 = categoryKbn2;
    }

    public String getCategoryName1() {
        return this.categoryName1;
    }

    public void setCategoryName1(String categoryName1) {
        this.categoryName1 = categoryName1;
    }

    public String getCategoryName2() {
        return this.categoryName2;
    }

    public void setCategoryName2(String categoryName2) {
        this.categoryName2 = categoryName2;
    }

    public BigDecimal getNet1() {
        return this.net1;
    }

    public void setNet1(BigDecimal net1) {
        this.net1 = net1;
    }
    
    public BigDecimal getNet2() {
        return this.net2;
    }

    public void setNet2(BigDecimal net2) {
        this.net2 = net2;
    }
    
    public BigDecimal getNet3() {
        return this.net3;
    }

    public void setNet3(BigDecimal net3) {
        this.net3 = net3;
    }
    
    public BigDecimal getNet4() {
        return this.net4;
    }

    public void setNet4(BigDecimal net4) {
        this.net4 = net4;
    }
    
    public BigDecimal getNet5() {
        return this.net5;
    }

    public void setNet5(BigDecimal net5) {
        this.net5 = net5;
    }
    
    public BigDecimal getNet6() {
        return this.net6;
    }

    public void setNet6(BigDecimal net6) {
        this.net6 = net6;
    }
    
    public BigDecimal getNet7() {
        return this.net7;
    }

    public void setNet7(BigDecimal net7) {
        this.net7 = net7;
    }
    
    public BigDecimal getNet8() {
        return this.net8;
    }

    public void setNet8(BigDecimal net8) {
        this.net8 = net8;
    }
    
    public BigDecimal getNet9() {
        return this.net9;
    }

    public void setNet9(BigDecimal net9) {
        this.net9 = net9;
    }
    
    public BigDecimal getNet10() {
        return this.net10;
    }

    public void setNet10(BigDecimal net10) {
        this.net10 = net10;
    }
    
    public BigDecimal getNet11() {
        return this.net11;
    }

    public void setNet11(BigDecimal net11) {
        this.net11 = net11;
    }
    
    public BigDecimal getNet12() {
        return this.net12;
    }

    public void setNet12(BigDecimal net12) {
        this.net12 = net12;
    }
    
    public BigDecimal getNetTm() {
        return this.netTm;
    }

    public void setNetTm(BigDecimal netTm) {
        this.netTm = netTm;
    }
    
    public BigDecimal getNetK1() {
        return this.netK1;
    }

    public void setNetK1(BigDecimal netK1) {
        this.netK1 = netK1;
    }
    
    public BigDecimal getNetK2() {
        return this.netK2;
    }

    public void setNetK2(BigDecimal netK2) {
        this.netK2 = netK2;
    }
    
    public BigDecimal getNetG() {
        return this.netG;
    }

    public void setNetG(BigDecimal netG) {
        this.netG = netG;
    }

    public BigDecimal getNetF() {
        return this.netF;
    }

    public void setNetF(BigDecimal netF) {
        this.netF = netF;
    }
    
    public BigDecimal getNetK1Diff() {
        return this.netK1Diff;
    }

    public void setNetK1Diff(BigDecimal netK1Diff) {
        this.netK1Diff = netK1Diff;
    }
    
    public BigDecimal getNetK2Diff() {
        return this.netK2Diff;
    }

    public void setNetK2Diff(BigDecimal netK2Diff) {
        this.netK2Diff = netK2Diff;
    }
    
    public BigDecimal getNetGDiff() {
        return this.netGDiff;
    }

    public void setNetGDiff(BigDecimal netGDiff) {
        this.netGDiff = netGDiff;
    }
    
    public BigDecimal getNetDiff() {
        return this.netDiff;
    }

    public void setNetDiff(BigDecimal netDiff) {
        this.netDiff = netDiff;
    }

    public String getInputFlg() {
        return inputFlg;
    }

    public void setInputFlg(String inputFlg) {
        this.inputFlg = inputFlg;
    }

    public BigDecimal getNet1Q() {
        return net1Q;
    }

    public void setNet1Q(BigDecimal net1Q) {
        this.net1Q = net1Q;
    }

    public BigDecimal getNet2Q() {
        return net2Q;
    }

    public void setNet2Q(BigDecimal net2Q) {
        this.net2Q = net2Q;
    }

    public BigDecimal getNet3Q() {
        return net3Q;
    }

    public void setNet3Q(BigDecimal net3Q) {
        this.net3Q = net3Q;
    }

    public BigDecimal getNet4Q() {
        return net4Q;
    }

    public void setNet4Q(BigDecimal net4Q) {
        this.net4Q = net4Q;
    }

    public BigDecimal getNet1QDiff() {
        return net1QDiff;
    }

    public void setNet1QDiff(BigDecimal net1QDiff) {
        this.net1QDiff = net1QDiff;
    }

    public BigDecimal getNet2QDiff() {
        return net2QDiff;
    }

    public void setNet2QDiff(BigDecimal net2QDiff) {
        this.net2QDiff = net2QDiff;
    }

    public BigDecimal getNet3QDiff() {
        return net3QDiff;
    }

    public void setNet3QDiff(BigDecimal net3QDiff) {
        this.net3QDiff = net3QDiff;
    }

    public BigDecimal getNet4QDiff() {
        return net4QDiff;
    }

    public void setNet4QDiff(BigDecimal net4QDiff) {
        this.net4QDiff = net4QDiff;
    }

    /**
     * @return the uriageRuikeiNet
     */
    public BigDecimal getUriageRuikeiNet() {
        return uriageRuikeiNet;
    }

    /**
     * @param uriageRuikeiNet the uriageRuikeiNet to set
     */
    public void setUriageRuikeiNet(BigDecimal uriageRuikeiNet) {
        this.uriageRuikeiNet = uriageRuikeiNet;
    }

}
