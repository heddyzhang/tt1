package jp.co.toshiba.hby.pspromis.syuueki.service.download;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.HashMap;
import javax.ejb.Stateless;
import javax.inject.Inject;
import javax.interceptor.Interceptors;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import jp.co.toshiba.hby.pspromis.syuueki.bean.DownloadOptBean;
import jp.co.toshiba.hby.pspromis.syuueki.entity.OperationLog;
import jp.co.toshiba.hby.pspromis.syuueki.entity.SyuBatchLog;
import jp.co.toshiba.hby.pspromis.syuueki.interceptor.TranceInterceptor;
import jp.co.toshiba.hby.pspromis.syuueki.facade.SyuWfControlTblFacade;
import jp.co.toshiba.hby.pspromis.syuueki.facade.SyuBatchLogFacade;
import jp.co.toshiba.hby.pspromis.syuueki.facade.SysdateEntityFacade;
import jp.co.toshiba.hby.pspromis.syuueki.facade.KanjyoMstFacade;
import jp.co.toshiba.hby.pspromis.syuueki.jdbc.DbUtilsExecutor;
import jp.co.toshiba.hby.pspromis.syuueki.jdbc.SqlFile;
import jp.co.toshiba.hby.pspromis.syuueki.service.OperationLogService;
import jp.co.toshiba.hby.pspromis.syuueki.service.S001Service;
import jp.co.toshiba.hby.pspromis.syuueki.util.ConstantString;
import jp.co.toshiba.hby.pspromis.syuueki.util.LoginUserInfo;
import jp.co.toshiba.hby.pspromis.syuueki.util.PoiUtil;
import jp.co.toshiba.hby.pspromis.syuueki.util.SyuuekiUtils;
import jp.co.toshiba.hby.pspromis.syuueki.util.Utils;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Workbook;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * ES-Promis収益管理システム
 * 工事進行基準リスト Excel出力サービス
 * @author
 */
@Stateless
@Interceptors({TranceInterceptor.class})
public class ShinkoListService {
    private static final Logger log = LoggerFactory.getLogger(ShinkoListService.class);
    
    @PersistenceContext(unitName = jp.co.toshiba.hby.pspromis.syuueki.util.ConstantString.syuuekiDataSourceName)
    private EntityManager em;
    
    @Inject
    private LoginUserInfo loginUserInfo;
    
    @Inject
    private DownloadOptBean downloadOptBean;
    
    @Inject
    private S001Service s001Service;
    
    @Inject
    private DbUtilsExecutor dbUtilsExecutor;

    @Inject
    private SyuWfControlTblFacade syuWfControlTblFacade;
    
    @Inject
    private SyuBatchLogFacade syuBatchLogFacade;
    
    @Inject
    private SysdateEntityFacade sysdateFacade;
    
    @Inject
    private KanjyoMstFacade kanjyoMstFacade;
    
    @Inject
    private SyuuekiUtils syuuekiUtils;

    @Inject
    private OperationLogService operationLogService;
    
    private static final int BASE_ROW_INDEX = 7;
    private static final int BASE_CELL_INDEX = 1;
    
    /**
     * 出力オプション指定の初期値を取得
     */
    public void indexOptionExecute() {
        // 出力実績年月を取得
        List<String> yearList = syuWfControlTblFacade.findYearList();
        
        // デフォルトの実績年月を取得
        String defaultJissekiYm = getDefaultJissekiYm();
        String defaultYear = String.valueOf(SyuuekiUtils.getIntegerYear(defaultJissekiYm));
        String defaultMonth = String.valueOf(SyuuekiUtils.getIntegerMonth(defaultJissekiYm));
        log.info("defaultJissekiYm=[{}], defaultYear=[{}], defaultMonth=[{}]", defaultJissekiYm, defaultYear, defaultMonth);

        //// デフォルトの比較対象年月を取得
        // 実績年月の前4半期の最終月を取得
        String beforeQuater = SyuuekiUtils.calaQuarter(SyuuekiUtils.getTargetQuarterLabel(defaultJissekiYm), -1);
        String[] beforeQuaterMonthAry = SyuuekiUtils.getQuarterMonthAry(beforeQuater);
        String beforeYm = beforeQuaterMonthAry[beforeQuaterMonthAry.length-1];
        String beforeYear = String.valueOf(SyuuekiUtils.getIntegerYear(beforeYm));
        String beforeMonth = String.valueOf(SyuuekiUtils.getIntegerMonth(beforeYm));
        log.info("beforeYm=[{}], beforeYear=[{}], beforeMonth=[{}]", beforeYm, beforeYear, beforeMonth);

        downloadOptBean.setOptionShinkoYearList(yearList);
        downloadOptBean.setOptionShinkoOutputYearNow(defaultYear);
        downloadOptBean.setOptionShikoOutputMonthNow(defaultMonth);
        downloadOptBean.setOptionShinkoOutputYearBefore(beforeYear);
        downloadOptBean.setOptionShinkoOutputMonthBefore(beforeMonth);
    }
    
    /**
     * バッチログから出力実績月のデフォルトを取得
     */
    private String getDefaultJissekiYm() {
        Map<String, Object> condition = new HashMap<>();
        condition.put("result", "0");
        condition.put("batchId", "SYU_P0_TEMPTBL_GAIA");
        condition.put("batchNm", "中間テーブル更新用バッチ");

        String ym;
        SyuBatchLog entity = syuBatchLogFacade.getMaxEndDate(condition);
        if (entity != null && StringUtils.isNotEmpty(entity.getBatchId())) {
            String targetData = StringUtils.defaultString(entity.getTargetDate());
            ym = StringUtils.substring(targetData, 0, 6);
        } else {
            // バッチログに該当が存在しない場合はエラーになるので、現在の進行基準勘定年月をデフォルトにする。
            ym = kanjyoMstFacade.getNowKanjoDate(ConstantString.salesClassS);
        }

        return ym;
    }

    /**
     * 指定した受注残一覧Excelテンプレートにデータを書き込む
     * @param workbook
     * @throws java.lang.Exception
     */
    public void downloadExecute(Workbook workbook) throws Exception {
        // 外貨関連項目の表示判断
        this.dispCurrencyCol(workbook);
        
        // ヘッダ部の出力
        this.outputHeader(workbook);

        // 一覧部の出力
        this.outputMainList(workbook);

        // 操作ログを登録
        this.registOperationLog();
    }

    /**
     * 外貨関連項目の表示判断
     * (出力時オプション指定で"外貨出力：なし"を選択した場合、外貨関連項目を非表示にする)
     */
    private void dispCurrencyCol(Workbook workbook) {
        // 出力時オプション指定で"外貨出力：あり"の場合は何もしない
        if ("1".equals(downloadOptBean.getOptionShinkoOutputForginKbn())) {
            return;
        }
        
        Sheet listSheet = getListSheet(workbook);
        
        // 受注時:円貨～外貨
        for (int i=21; i<=24; i++) {
            listSheet.setColumnWidth(i, 0);
        }
        // 前四半期:円貨～外貨(1)
        for (int i=29; i<=32; i++) {
            listSheet.setColumnWidth(i, 0);
        }
        // 前四半期:円貨～外貨(2)
        for (int i=43; i<=45; i++) {
            listSheet.setColumnWidth(i, 0);
        }
        // 今四半期:円貨～外貨(1)
        for (int i=50; i<=53; i++) {
            listSheet.setColumnWidth(i, 0);
        }
        // 今四半期:円貨～外貨(2)
        for (int i=64; i<=66; i++) {
            listSheet.setColumnWidth(i, 0);
        }
        // 差分:円貨～外貨(1)
        for (int i=71; i<=74; i++) {
            listSheet.setColumnWidth(i, 0);
        }
        // 差分:円貨～外貨(2)
        for (int i=81; i<=83; i++) {
            listSheet.setColumnWidth(i, 0);
        }
    }

    /**
     * ヘッダ情報の出力
     */
    private void outputHeader(Workbook workbook) throws Exception {
        Sheet listSheet = getListSheet(workbook);
        Cell cell;
        String value;

        // 出力実績月
        String outputYm = getOutputYm(1);
        String outputQLabel = getChangeQLabel(outputYm);

        // 比較対象月
        String beforeYm = getBeforeYm(1);
        String beforeQLabel = getChangeQLabel(beforeYm);


        // 出力実績月 出力
        cell = PoiUtil.getCell(listSheet, 0, 1);
        value = (String)(PoiUtil.getCellValue(cell));
        value = StringUtils.replace(value, "#DATA#", outputYm);
        PoiUtil.setCellValue(cell, value);
        
        // 比較対象月 出力
        cell = PoiUtil.getCell(listSheet, 1, 1);
        value = (String)(PoiUtil.getCellValue(cell));
        value = StringUtils.replace(value, "#DATA#", beforeYm);
        PoiUtil.setCellValue(cell, value);
        
        // 出力日 出力
        Date now = sysdateFacade.getSysdate();
        String sysdate = syuuekiUtils.exeFormatYmd(now);
        cell = PoiUtil.getCell(listSheet, 0, 2);
        value = (String)(PoiUtil.getCellValue(cell));
        value = StringUtils.replace(value, "#DATA#", sysdate);
        PoiUtil.setCellValue(cell, value);

        // 出力部門 出力
        cell = PoiUtil.getCell(listSheet, 1, 2);
        value = (String)(PoiUtil.getCellValue(cell));
        value = StringUtils.replace(value, "#DATA#", loginUserInfo.getDepartmentName());
        PoiUtil.setCellValue(cell, value);


        // 前四半期(タイトルの期) 出力
        cell = PoiUtil.getCell(listSheet, 5, 28);
        value = (String)(PoiUtil.getCellValue(cell));
        value = StringUtils.replace(value, "#DATA#", beforeQLabel);
        PoiUtil.setCellValue(cell, value);

        // 前四半期:売上高(タイトルの年月) 出力
        cell = PoiUtil.getCell(listSheet, 6, 42);
        value = (String)(PoiUtil.getCellValue(cell));
        value = StringUtils.replace(value, "#DATA#", beforeYm);
        PoiUtil.setCellValue(cell, value);
        
        // 前四半期:売上原価(タイトルの年月) 出力
        cell = PoiUtil.getCell(listSheet, 6, 46);
        value = (String)(PoiUtil.getCellValue(cell));
        value = StringUtils.replace(value, "#DATA#", beforeYm);
        PoiUtil.setCellValue(cell, value);


        // 今四半期(タイトルの期) 出力
        cell = PoiUtil.getCell(listSheet, 5, 49);
        value = (String)(PoiUtil.getCellValue(cell));
        value = StringUtils.replace(value, "#DATA#", outputQLabel);
        PoiUtil.setCellValue(cell, value);

        // 今四半期:売上高(タイトルの年月) 出力
        cell = PoiUtil.getCell(listSheet, 6, 63);
        value = (String)(PoiUtil.getCellValue(cell));
        value = StringUtils.replace(value, "#DATA#", outputYm);
        PoiUtil.setCellValue(cell, value);
        
        // 今四半期:売上原価(タイトルの年月) 出力
        cell = PoiUtil.getCell(listSheet, 6, 67);
        value = (String)(PoiUtil.getCellValue(cell));
        value = StringUtils.replace(value, "#DATA#", outputYm);
        PoiUtil.setCellValue(cell, value);
        
        // 差分:売上高(タイトルの年月)
        cell = PoiUtil.getCell(listSheet, 6, 80);
        value = (String)(PoiUtil.getCellValue(cell));
        value = StringUtils.replace(value, "#DATA#", outputYm);
        PoiUtil.setCellValue(cell, value);

        // 差分:売上原価(タイトルの年月)
        cell = PoiUtil.getCell(listSheet, 6, 84);
        value = (String)(PoiUtil.getCellValue(cell));
        value = StringUtils.replace(value, "#DATA#", outputYm);
        PoiUtil.setCellValue(cell, value);
    }
    
    /**
     * 一覧の出力
     */
    private void outputMainList(Workbook workbook) throws Exception {
        Sheet listSheet = getListSheet(workbook);
        int rowNum = BASE_ROW_INDEX;

        // データの1行目を取得
        Row row = PoiUtil.getRow(listSheet, BASE_ROW_INDEX, true);
        List<Cell> baseCellList = PoiUtil.getCellList(row);

        // 外貨行のコピー元styleを取得
        Sheet styleSheet = getStyleSheet(workbook);
        Row styleRow = PoiUtil.getRow(styleSheet, 3, true);
        List<Cell> baseCurrencyCellList = PoiUtil.getCellList(styleRow);
        
        // 内訳注番行のコピー元styleを取得
        styleRow = PoiUtil.getRow(styleSheet, 5, true);
        List<Cell> baseUtiwakeCellList = PoiUtil.getCellList(styleRow);

        // SELECT文を実行して、メインの一覧を取得
        List<Map<String, Object>> list = findMainList();
        for (Map<String, Object> mainData: list) {
            boolean isFirstChildChuban = true;
            String beforeOrderNo = "";
            String childChubanFlg = "0";
            Map<String, Object> outputChildChubanData = new HashMap<>();
            String ankenId = (String)(mainData.get("ANKEN_ID"));
            
            mainData.put("CHILD_CHUBAN_FLG", childChubanFlg);
            mainData.put("MAIN_ORDER_NO_FLG", "1");

            // 内訳注番データを検索
            List<Map<String, Object>> childeChubanList = findChildChubanList(ankenId);

            if (CollectionUtils.isNotEmpty(childeChubanList)) {
                int totalCount = childeChubanList.size();
                BigDecimal bigChubanCount = (BigDecimal)(childeChubanList.get(0).get("ORDER_NO_COUNT"));
                if (totalCount > bigChubanCount.intValue()) {
                    // 内訳が2件以上あるか？
                    childChubanFlg = "1";
                    mainData.put("CHILD_CHUBAN_FLG", childChubanFlg);
                    mainData.put("MAIN_ORDER_NO_FLG", "0");
                }
            }

            row = PoiUtil.getRow(listSheet, rowNum, true);
            
            // 2行目以降は1行目のスタイルをコピー
            if (rowNum > BASE_ROW_INDEX) {
                PoiUtil.copyRowStyleValue(row, baseCellList, false, true);
            }

            // 通貨単位のデータを検索
            List<Map<String, Object>> currencyList = findAnkenCurrencyList(ankenId);
            // 通貨"JPY"の件数
            Integer jpyCouunt = getCurrencyCount(currencyList, 1);
            mainData.put("JPY_COUNT", jpyCouunt);
            // 通貨"JPY"以外の件数
            Integer etcCurrencyCount = getCurrencyCount(currencyList, 0);
            mainData.put("ETC_CURRENCY_COUNT", etcCurrencyCount);

            // メインデータの値をセット
            setSheetFromData(row, mainData, 1);
            
            // 外貨を検索してセット(出力時オプション指定で"外貨出力：あり"を選択した場合のみ実行)
            if ("1".equals(downloadOptBean.getOptionShinkoOutputForginKbn())) {
                for (Map<String, Object> currencyData: currencyList) {
                    rowNum++;
                    row = PoiUtil.getRow(listSheet, rowNum, true);
                    PoiUtil.copyRowStyleValue(row, baseCurrencyCellList, false, true);
                    
                    setSheetFromData(row, currencyData, 3);
                }
            }

            // 内訳をセット
            if (CollectionUtils.isNotEmpty(childeChubanList) && "1".equals(childChubanFlg)) {
                for (Map<String, Object> childeData: childeChubanList) {
                    childeData.put("MAIN_ORDER_NO_FLG", "0");
                    String mainOrderNo = StringUtils.defaultString((String)mainData.get("MAIN_ORDER_NO"));
                    String orderNo = StringUtils.defaultString((String)childeData.get("ORDER_NO"));
                    if (orderNo.equals(mainOrderNo)) {
                        childeData.put("MAIN_ORDER_NO_FLG", "1");
                    }

                    if (!isFirstChildChuban && orderNo.equals(beforeOrderNo)) {
                        // 注番が前行と等しい場合はSP/NETを加算
                        plusSpNet(outputChildChubanData, childeData);

                    } else {
                        // 注番が前行と異なる場合はExcelにデータ出力
                        if (!isFirstChildChuban) {
                            rowNum++;
                            row = PoiUtil.getRow(listSheet, rowNum, true);
                            PoiUtil.copyRowStyleValue(row, baseUtiwakeCellList, false, true);
                            setSheetFromData(row, outputChildChubanData, 2);
                        }                

                        outputChildChubanData = new HashMap<>(childeData);
                    }


                    isFirstChildChuban = false;
                    beforeOrderNo = orderNo;
                }
                if (!isFirstChildChuban) {
                    rowNum++;
                    row = PoiUtil.getRow(listSheet, rowNum, true);
                    PoiUtil.copyRowStyleValue(row, baseUtiwakeCellList, false, true);
                    setSheetFromData(row, outputChildChubanData, 2);
                }
            }

            log.info("list AnkenId=[{}]", ankenId);
            rowNum++;
        }

        if (CollectionUtils.isNotEmpty(list)) {
            setLastRowBorderLine(workbook, row);
        }

        // 計算式の実行
        listSheet.setForceFormulaRecalculation(true);
    }

    /**
     * 操作ログを登録
     */
    private void registOperationLog() throws Exception{
        // 操作ログを出力
        OperationLog operationLog = operationLogService.getOperationLog();
        operationLog.setOperationCode("DL_JOB");
        operationLog.setObjectType("ANKEN");
        operationLog.setObjectId(10);
        operationLog.setRemarks("工事進行基準案件リスト");
        operationLogService.insertOperationLogSearch(operationLog);
    }
    
    /**
     * データをセット
     * @param mainData 出力する行データ
     * @param kbn 1:進行基準まとめ案件のデータ行(計行 or 1案件1注番のデータ行) 2:内訳注番行 3:外貨行
     */
    private void setSheetFromData(Row row, Map<String, Object> mainData, int kbn) {
        int cellIdx = BASE_CELL_INDEX;
        Cell cell;
        Object value;

        // 報告No.(なにもセットしない)
        
        // 扱営業
        cellIdx++;
        cell = PoiUtil.getCell(row, cellIdx);
        value = mainData.get("ATSUKAI_TEAM_CODE");
        PoiUtil.setCellValue(cell, value);
        
        // 営業課
        cellIdx++;
        cell = PoiUtil.getCell(row, cellIdx);
        value = mainData.get("EIGYO_DEPT_NM");
        PoiUtil.setCellValue(cell, value);
        
        // 件名
        cellIdx++;
        cell = PoiUtil.getCell(row, cellIdx);
        value = mainData.get("ANKEN_MATOME_NAME");
        PoiUtil.setCellValue(cell, value);

        // 注番
        cellIdx++;
        cell = PoiUtil.getCell(row, cellIdx);
        value = mainData.get("ORDER_NO");
        if (kbn == 1) {
            // 注番が2件以上ある場合は"計"を表示
            String childeChubanFlg = StringUtils.defaultString((String)mainData.get("CHILD_CHUBAN_FLG"));
            if ("1".equals(childeChubanFlg)) {
                value = "計";
            }

        } else if (kbn == 3) {
            value = (String)mainData.get("CURRENCY_CODE");
        }
        PoiUtil.setCellValue(cell, value);

        // 代表注番
        cellIdx++;
        cell = PoiUtil.getCell(row, cellIdx);
        value = mainData.get("MAIN_ORDER_NO_FLG");
        if ("1".equals(value)) value = "●";
        else value = "";
        PoiUtil.setCellValue(cell, value);
        
        // 受注年月
        cellIdx++;
        cell = PoiUtil.getCell(row, cellIdx);
        value = mainData.get("HAT_JYUCHU_DATE");
        PoiUtil.setCellValue(cell, value);
        
        // 進行基準開始年月
        cellIdx++;
        cell = PoiUtil.getCell(row, cellIdx);
        value = mainData.get("URIAGE_START");
        PoiUtil.setCellValue(cell, value);
        
        // 完売予定年月
        cellIdx++;
        cell = PoiUtil.getCell(row, cellIdx);
        value = mainData.get("URIAGE_END");
        PoiUtil.setCellValue(cell, value);
        
        // 中断
        cellIdx++;
        cell = PoiUtil.getCell(row, cellIdx);
        value = mainData.get("CHUDAN_YM");
        value = getDataFlg(value);
        PoiUtil.setCellValue(cell, value);
        
        // 中断年月
        cellIdx++;
        cell = PoiUtil.getCell(row, cellIdx);
        value = mainData.get("CHUDAN_YM");
        PoiUtil.setCellValue(cell, value);
        
        // 再開
        cellIdx++;
        cell = PoiUtil.getCell(row, cellIdx);
        value = mainData.get("SAIKAI_YM");
        value = getDataFlg(value);
        PoiUtil.setCellValue(cell, value);
        
        // 再開年月
        cellIdx++;
        cell = PoiUtil.getCell(row, cellIdx);
        value = mainData.get("SAIKAI_YM");
        PoiUtil.setCellValue(cell, value);
        
        // 完売
        cellIdx++;
        cell = PoiUtil.getCell(row, cellIdx);
        value = mainData.get("URIAGE_END_FIN");
        if (value != null) value = "●";
        PoiUtil.setCellValue(cell, value);
        
        // 完売年月
        cellIdx++;
        cell = PoiUtil.getCell(row, cellIdx);
        value = mainData.get("URIAGE_END_FIN");
        PoiUtil.setCellValue(cell, value);
        
        ///////////// ロスコン(S) /////////////////////
        // 2018A ロスコン対応で出力処理を追加
        cellIdx++;
        cell = PoiUtil.getCell(row, cellIdx);
        value = mainData.get("LOSS_RUIKEI_TOTAL");
        PoiUtil.setCellValue(cell, value);

        cellIdx++;
        cell = PoiUtil.getCell(row, cellIdx);
        value = mainData.get("LOSS_RUIKEI_B");
        PoiUtil.setCellValue(cell, value);
        
        cellIdx++;
        cell = PoiUtil.getCell(row, cellIdx);
        value = mainData.get("LOSS_RUIKEI_N");
        PoiUtil.setCellValue(cell, value);
        ///////////// ロスコン(E) /////////////////////
        
        ///////////// 今四半期 変動有無(S) /////////////////////
        cellIdx++;
        ///////////// 今四半期 変動有無(E) /////////////////////
        
        ///////////// 受注時(S) /////////////////////
        // 総SP
        cellIdx++;
        cell = PoiUtil.getCell(row, cellIdx);
        value = mainData.get("KEIYAKU_AMOUNT");
        PoiUtil.setCellValue(cell, value);
        
        // 円貨(計算式のため値セットは省略)
        cellIdx++;
        
        // 通貨
        cellIdx++;
        if (kbn == 3) {
            cell = PoiUtil.getCell(row, cellIdx);
            value = mainData.get("CURRENCY_CODE");
            PoiUtil.setCellValue(cell, value);
        }
        
        // レート
        cellIdx++;
        if (kbn == 3) {
            cell = PoiUtil.getCell(row, cellIdx);
            value = mainData.get("JT_KEIYAKU_RATE");
            PoiUtil.setCellValue(cell, value);
        }
        
        // 外貨
        cellIdx++;
        if (kbn == 3) {
            cell = PoiUtil.getCell(row, cellIdx);
            value = mainData.get("JT_KEIYAKU_AMOUNT");
            PoiUtil.setCellValue(cell, value);
        }
        
        // 総NET
        cellIdx++;
        cell = PoiUtil.getCell(row, cellIdx);
        value = mainData.get("URIAGE_GENKA");
        PoiUtil.setCellValue(cell, value);
        
        // 粗利(計算式のため値セットは省略)
        cellIdx++;
        
        // M率(計算式のため値セットは省略)
        cellIdx++;
        ///////////// 受注時(E) /////////////////////

        ///////////// 前四半期(S) //////////////////
        // 前四半期:総SP
        cellIdx++;
        cell = PoiUtil.getCell(row, cellIdx);
        value = mainData.get("KEIYAKU_AMOUNT_B");
        PoiUtil.setCellValue(cell, value);
        
        // 前四半期:円貨(計算式のため値セットは省略)
        cellIdx++;
        
        // 前四半期:通貨
        cellIdx++;
        if (kbn == 3) {
            cell = PoiUtil.getCell(row, cellIdx);
            value = mainData.get("CURRENCY_CODE");
            PoiUtil.setCellValue(cell, value);
        }
        
        // 前四半期:レート
        cellIdx++;
        if (kbn == 3) {
            cell = PoiUtil.getCell(row, cellIdx);
            value = mainData.get("KI_KEIYAKU_RATE");
            PoiUtil.setCellValue(cell, value);
        }
        
        // 前四半期:外貨
        cellIdx++;
        if (kbn == 3) {
            cell = PoiUtil.getCell(row, cellIdx);
            value = mainData.get("KI_KEIYAKU_AMOUNT_B");
            PoiUtil.setCellValue(cell, value);
        }

        // 前四半期:確定額(空白表示のため値セットは省略)
        cellIdx++;
        
        // 前四半期:確定率(計算式のため値セットは省略)
        cellIdx++;
        
        // 前四半期:総NET
        cellIdx++;
        cell = PoiUtil.getCell(row, cellIdx);
        value = mainData.get("HAT_NET_B");
        PoiUtil.setCellValue(cell, value);
        
        // 前四半期:確定額
        cellIdx++;
        cell = PoiUtil.getCell(row, cellIdx);
        value = mainData.get("KAKUTEI_NET_B");
        PoiUtil.setCellValue(cell, value);

        // 前四半期:確定率(計算式のため値セットは省略)
        cellIdx++;

        // 前四半期:粗利(計算式のため値セットは省略)
        cellIdx++;

        // 前四半期:Ｍ率(計算式のため値セットは省略)
        cellIdx++;

        // 前四半期:見積総原価
        cellIdx++;
        cell = PoiUtil.getCell(row, cellIdx);
        value = mainData.get("MITSUMORI_GENKA_NET_B");
        PoiUtil.setCellValue(cell, value);
        
        // 前四半期:製番損益
        cellIdx++;
        cell = PoiUtil.getCell(row, cellIdx);
        value = mainData.get("SEIBAN_SONEKI_NET_B");
        PoiUtil.setCellValue(cell, value);
        
        // 前四半期:売上高
        cellIdx++;
        cell = PoiUtil.getCell(row, cellIdx);
        value = mainData.get("URIAGE_RUIKEI_AMOUNT_B");
        PoiUtil.setCellValue(cell, value);
        
        // 前四半期:円貨
        cellIdx++;
        if (kbn == 3) {
            cell = PoiUtil.getCell(row, cellIdx);
            value = mainData.get("KI_URIAGE_RUIKEI_ENKA_AMOUNT_B");
            PoiUtil.setCellValue(cell, value);
        }

        // 前四半期:通貨
        cellIdx++;
        if (kbn == 3) {
            cell = PoiUtil.getCell(row, cellIdx);
            value = mainData.get("CURRENCY_CODE");
            PoiUtil.setCellValue(cell, value);
        }
        
        // 前四半期:外貨
        cellIdx++;
        if (kbn == 3) {
            cell = PoiUtil.getCell(row, cellIdx);
            value = mainData.get("KI_URIAGE_RUIKEI_AMOUNT_B");
            PoiUtil.setCellValue(cell, value);
        }

        // 前四半期:売上原価
        cellIdx++;
        cell = PoiUtil.getCell(row, cellIdx);
        value = mainData.get("URIAGE_RUIKEI_NET_B");
        PoiUtil.setCellValue(cell, value);
        
        // 前四半期:進捗率(計算式のため値セットは省略)
        cellIdx++;
        
        // 前四半期:前受累計
        cellIdx++;
        value = "";
        if (kbn == 1) {
            value = getRuikeiKaisyuAmount(mainData, "RUIKEI_KAISYU_AMOUNT_B");
        } else if (kbn == 3) {
            value = mainData.get("RUIKEI_KAISYU_AMOUNT_B");
        }
        cell = PoiUtil.getCell(row, cellIdx);
        PoiUtil.setCellValue(cell, value);
        ///////////// 前四半期(E) //////////////////


        ///////////// 今四半期(S) //////////////////
        // 今四半期:総SP
        cellIdx++;
        cell = PoiUtil.getCell(row, cellIdx);
        value = mainData.get("KEIYAKU_AMOUNT_N");
        PoiUtil.setCellValue(cell, value);
        
        // 今四半期:円貨(計算式のため値セットは省略)
        cellIdx++;
        
        // 今四半期:通貨
        cellIdx++;
        if (kbn == 3) {
            cell = PoiUtil.getCell(row, cellIdx);
            value = mainData.get("CURRENCY_CODE");
            PoiUtil.setCellValue(cell, value);
        }
        
        // 今四半期:レート
        cellIdx++;
        if (kbn == 3) {
            cell = PoiUtil.getCell(row, cellIdx);
            value = mainData.get("KI_KEIYAKU_RATE");
            PoiUtil.setCellValue(cell, value);
        }
        
        // 今四半期:外貨
        cellIdx++;
        if (kbn == 3) {
            cell = PoiUtil.getCell(row, cellIdx);
            value = mainData.get("KI_KEIYAKU_AMOUNT_N");
            PoiUtil.setCellValue(cell, value);
        }

        // 今四半期:確定額(空白表示のため値セットは省略)
        cellIdx++;
        
        // 今四半期:確定率(計算式のため値セットは省略)
        cellIdx++;

        // 今四半期:総NET
        cellIdx++;
        cell = PoiUtil.getCell(row, cellIdx);
        value = mainData.get("HAT_NET_N");
        PoiUtil.setCellValue(cell, value);
        
        // 今四半期:確定額
        cellIdx++;
        cell = PoiUtil.getCell(row, cellIdx);
        value = mainData.get("KAKUTEI_NET_N");
        PoiUtil.setCellValue(cell, value);
        
        // 今四半期:確定率(計算式のため値セットは省略)
        cellIdx++;

        // 今四半期:粗利(計算式のため値セットは省略)
        cellIdx++;

        // 今四半期:Ｍ率(計算式のため値セットは省略)
        cellIdx++;
        
        // 今四半期:見積総原価
        cellIdx++;
        cell = PoiUtil.getCell(row, cellIdx);
        value = mainData.get("MITSUMORI_GENKA_NET_N");
        PoiUtil.setCellValue(cell, value);
        
        // 今四半期:製番損益
        cellIdx++;
        cell = PoiUtil.getCell(row, cellIdx);
        value = mainData.get("SEIBAN_SONEKI_NET_N");
        PoiUtil.setCellValue(cell, value);
        
        // 今四半期:売上高
        cellIdx++;
        cell = PoiUtil.getCell(row, cellIdx);
        value = mainData.get("URIAGE_RUIKEI_AMOUNT_N");
        PoiUtil.setCellValue(cell, value);

        // 今四半期:円貨
        cellIdx++;
        if (kbn == 3) {
            cell = PoiUtil.getCell(row, cellIdx);
            value = mainData.get("KI_URIAGE_RUIKEI_ENKA_AMOUNT_N");
            PoiUtil.setCellValue(cell, value);
        }

        // 今四半期:通貨
        cellIdx++;
        if (kbn == 3) {
            cell = PoiUtil.getCell(row, cellIdx);
            value = mainData.get("CURRENCY_CODE");
            PoiUtil.setCellValue(cell, value);
        }
        
        // 今四半期:外貨
        cellIdx++;
        if (kbn == 3) {
            cell = PoiUtil.getCell(row, cellIdx);
            value = mainData.get("KI_URIAGE_RUIKEI_AMOUNT_N");
            PoiUtil.setCellValue(cell, value);
        }

        // 今四半期:売上原価
        cellIdx++;
        cell = PoiUtil.getCell(row, cellIdx);
        value = mainData.get("URIAGE_RUIKEI_NET_N");
        PoiUtil.setCellValue(cell, value);
        
        // 今四半期:進捗率(計算式のため値セットは省略)
        cellIdx++;

        // 今四半期:前受累計
        cellIdx++;
        value = "";
        if (kbn == 1) {
            value = getRuikeiKaisyuAmount(mainData, "RUIKEI_KAISYU_AMOUNT_N");
        } else if (kbn == 3) {
            value = mainData.get("RUIKEI_KAISYU_AMOUNT_N");
        }
        cell = PoiUtil.getCell(row, cellIdx);
        PoiUtil.setCellValue(cell, value);
        ///////////// 今四半期(E) //////////////////
        
        
        ///////////// 差分(S) //////////////////
        // 差分:総SP(計算式のため値セットは省略)
        cellIdx++;
        // 差分:円貨(計算式のため値セットは省略)
        cellIdx++;
        
        // 差分:通貨
        cellIdx++;
        if (kbn == 3) {
            cell = PoiUtil.getCell(row, cellIdx);
            value = mainData.get("CURRENCY_CODE");
            PoiUtil.setCellValue(cell, value);
        }
        
        // 差分:レート(計算式のため値セットは省略)
        cellIdx++;
        // 差分:外貨(計算式のため値セットは省略)
        cellIdx++;
        // 差分:総NET(計算式のため値セットは省略)
        cellIdx++;
        // 差分:粗利(計算式のため値セットは省略)
        cellIdx++;
        // 差分:Ｍ率(計算式のため値セットは省略)
        cellIdx++;
        // 差分:見積総原価(計算式のため値セットは省略)
        cellIdx++;
        // 差分:製番損益(計算式のため値セットは省略)
        cellIdx++;
        // 差分:売上高(計算式のため値セットは省略)
        cellIdx++;
        // 差分:円貨(計算式のため値セットは省略)
        cellIdx++;

        // 差分:通貨
        cellIdx++;
        if (kbn == 3) {
            cell = PoiUtil.getCell(row, cellIdx);
            value = mainData.get("CURRENCY_CODE");
            PoiUtil.setCellValue(cell, value);
        }
        
        // 差分:外貨(計算式のため値セットは省略)
        cellIdx++;
        // 差分:売上原価(計算式のため値セットは省略)
        cellIdx++;
        // 差分:進捗率(計算式のため値セットは省略)
        cellIdx++;
        // 差分:前受累計(計算式のため値セットは省略)
        cellIdx++;
        ///////////// 差分(E) //////////////////
    }
    
    /**
     * SP/NETの加算(内訳注番の同一注番案件に関する処理)
     */
    private void plusSpNet(Map<String, Object> baseData, Map<String, Object> addData) throws Exception {
        BigDecimal big;
        
        // 受注時:総NET
        big = Utils.add((BigDecimal)(baseData.get("URIAGE_GENKA")), (BigDecimal)(addData.get("URIAGE_GENKA")));
        baseData.put("URIAGE_GENKA", big);

        // 前四半期:総NET
        big = Utils.add((BigDecimal)(baseData.get("HAT_NET_B")), (BigDecimal)(addData.get("HAT_NET_B")));
        baseData.put("HAT_NET_B", big);
        
        // 前四半期:確定額
        big = Utils.add((BigDecimal)(baseData.get("KAKUTEI_NET_B")), (BigDecimal)(addData.get("KAKUTEI_NET_B")));
        baseData.put("KAKUTEI_NET_B", big);

        
        // 今四半期:総NET
        big = Utils.add((BigDecimal)(baseData.get("HAT_NET_N")), (BigDecimal)(addData.get("HAT_NET_N")));
        baseData.put("HAT_NET_N", big);
        
        // 今四半期:確定額
        big = Utils.add((BigDecimal)(baseData.get("KAKUTEI_NET_N")), (BigDecimal)(addData.get("KAKUTEI_NET_N")));
        baseData.put("KAKUTEI_NET_N", big);

    }

    /**
     * メインの一覧を取得(SQL実行)
     */
    private List<Map<String, Object>> findMainList() throws Exception {
        SqlFile sqlFile = new SqlFile();
        
        // SQLファイルの取得
        String splFilePath = "/sql/download/selectShinkoList.sql";
        String splFilePathWhere = "/sql/selectListSyuueki.sql";
        log.info("[findMainList] SQL_SELECT_FILE=[{}] SQL_WHERE_FILE=[{}]", splFilePath, splFilePathWhere);
        
        // SELECT+FROM句のSQL+パラメータを取得
        Map<String, Object> mainSelectCondition = getSelectCondition();
        mainSelectCondition.put("currencyCodeEn", ConstantString.currencyCodeEn);  // 通貨:JPY(前受累計 の取得に利用)
        String select = sqlFile.getSqlString(splFilePath, mainSelectCondition);
        Object[] selectFromParam = sqlFile.getSqlParams(splFilePath, mainSelectCondition);

        // WHERE句のSQL+パラメータを取得
        Map<String, Object> whereCondition = s001Service.getCondition();
        setWhereConditionInfo(whereCondition);
        whereCondition.put("whereOnlyFlg", "1");      // WHERE句のみ抜き出すFLG
        String where = sqlFile.getSqlString(splFilePathWhere, whereCondition);
        Object[] whereParam = sqlFile.getSqlParams(splFilePathWhere, whereCondition);

        // SELECT句＋WHERE句をガッチャンコして実行するSQLを作成
        String executeSql = select + where + " ORDER BY A.ATSUKAI_TEAM_CODE, A.ORDER_NO";
        
        // 実行するSQL文のパラメータを作成(SELECT+FROM句と、WHERE句のパラメータを統合する)
        List<Object> executeSqlParamsList = new ArrayList<>();
        if (selectFromParam != null) {
            executeSqlParamsList.addAll(Arrays.asList(selectFromParam));
        }
        if (whereParam != null) {
            executeSqlParamsList.addAll(Arrays.asList(whereParam));
        }
        Object[] executeSqlParams = (Object[])executeSqlParamsList.toArray(new Object[executeSqlParamsList.size()]);
        ///////// パラメータ設定(E) ////////
        
        // SQLを実行(Commons DbUtilで実行)
        List<Map<String, Object>> list = dbUtilsExecutor.dbUtilsGetSqlList(em, executeSql, executeSqlParams);

        return list;
    }
    
    /**
     * 指定案件の外貨行のデータ一覧を取得(SQL実行)
     */
    private List<Map<String, Object>> findAnkenCurrencyList(String ankenId) throws Exception {
        SqlFile sqlFile = new SqlFile();
        
        // SQLファイルの取得
        String splFilePath = "/sql/download/selectShinkoCurrencyList.sql";
        
        // パラメータを作成
        Map<String, Object> condition = getSelectCondition();
        setWhereConditionInfo(condition);
        condition.put("ankenId", ankenId);
        
        String sqlString = sqlFile.getSqlString(splFilePath, condition);
        Object[] sqlParams = sqlFile.getSqlParams(splFilePath, condition);
        
        // SQLを実行(Commons DbUtilで実行)
        List<Map<String, Object>> list = dbUtilsExecutor.dbUtilsGetSqlList(em, sqlString, sqlParams);
        return list;
    }

    /**
     * 内訳注番のデータ一覧を取得(SQL実行)
     */
    private List<Map<String, Object>> findChildChubanList(String matomeAnkenNo) throws Exception {
        SqlFile sqlFile = new SqlFile();
        
        // SQLファイルの取得
        String splFilePath = "/sql/download/selectShinkoChildChubanAnkenList.sql";
        
        // パラメータを作成
        Map<String, Object> condition = getSelectCondition();
        setWhereConditionInfo(condition);
        condition.put("ankenId", matomeAnkenNo);

        String sqlString = sqlFile.getSqlString(splFilePath, condition);
        Object[] sqlParams = sqlFile.getSqlParams(splFilePath, condition);

        // SQLを実行(Commons DbUtilで実行)
        List<Map<String, Object>> list = dbUtilsExecutor.dbUtilsGetSqlList(em, sqlString, sqlParams);
        return list;
    }

    /**
     * SELECT句のパラメータ用Mapを取得
     */
    private Map<String, Object> getSelectCondition() {
        Map<String, Object> condition = new HashMap<>();
        
        String beforeYm = getBeforeYm(0);
        String nowYm= getOutputYm(0);
        condition.put("beforeYm", beforeYm);
        condition.put("nowYm", nowYm);
        
        condition.put("beforeYmQ",  SyuuekiUtils.getTargetQuarterLabel(beforeYm));
        condition.put("nowYmQ", SyuuekiUtils.getTargetQuarterLabel(nowYm));

        return condition;
    }

    /**
     * WHEREのパラメータ用Mapを追加(引数のMapに追加)
     */
    private void setWhereConditionInfo(Map<String, Object> whereCondition) {
        whereCondition.put("rirekiFlg", "");
        whereCondition.put("rirekiId", 0);
    }
    
    /**
     * 出力先シートの取得
     */
    private Sheet getListSheet(Workbook workbook) {
        Sheet sheet = workbook.getSheet("list");
        return sheet;
    }

    /**
     * style設定シートの取得
     */
    private Sheet getStyleSheet(Workbook workbook) {
        Sheet sheet = workbook.getSheet("style");
        return sheet;
    }
    
    /**
     * 年月の取得(YYYY/MM)
     * @param year 年
     * @param month 月
     * @param flg 0:スラッシュなし 1:スラッシュあり
     */
    private String getFormatYm(String year, String month, int flg) {
        String ym = year;
        if (flg == 1) ym = ym + "/";
        ym = ym + (StringUtils.length(month) == 1 ? ("0" + month) : month);
        return ym;
    }
    
    /**
     * 出力実績月(今回) 年月の取得
     * @param flg 0:スラッシュなし 1:スラッシュあり
     */
    private String getOutputYm(int flg) {
        return getFormatYm(downloadOptBean.getOptionShinkoOutputYearNow(), downloadOptBean.getOptionShikoOutputMonthNow(), flg);
    }
    
    /**
     * 比較対象(前回) 年月の取得
     * @param flg 0:スラッシュなし 1:スラッシュあり
     */
    private String getBeforeYm(int flg) {
        return getFormatYm(downloadOptBean.getOptionShinkoOutputYearBefore(), downloadOptBean.getOptionShinkoOutputMonthBefore(), flg);
    }
    
    /**
     * 四半期ラベルに変換
     */
    private String getChangeQLabel(String ym) {
        String qLabel = SyuuekiUtils.getTargetQuarterLabel(ym);
        String year = StringUtils.substring(qLabel, 0, 4);
        String q = StringUtils.substring(qLabel, 4, 6);
        if ("06".equals(q)) {
            q = "1Q";
        } else if ("09".equals(q)) {
            q = "2Q";
        } else if ("12".equals(q)) {
            q = "3Q";
        } else if ("03".equals(q)) {
            year = String.valueOf(Integer.parseInt(year) - 1);
            q = "4Q";
        }
        return year + "/" + q;
    }

    /**
     * 
     */
    private String getDataFlg(Object value) {
        if (value == null) {
            return "";
        }
        if (value instanceof String) {
            if (((String)value).equals("")) {
                return "";
            }
        }
        return "●";
    }

    private int getCurrencyCount(List<Map<String, Object>> currencyList, int jpyFlg) {
        int count = 0;
        if (CollectionUtils.isEmpty(currencyList) && jpyFlg == 1) {
            return 1;
        }
        if (CollectionUtils.isNotEmpty(currencyList)) {
            for (Map<String, Object> data: currencyList) {
                String currencyCode = (String)data.get("CURRENCY_CODE");
                if (jpyFlg == 1 && ConstantString.currencyCodeEn.equals(currencyCode)) {
                    return 1;
                }
                if (jpyFlg != 1 && !ConstantString.currencyCodeEn.equals(currencyCode)) {
                    count = count + 1;
                }
            }
        }
        return count;
    }

    /**
     * [前受累計]を取得
     */
    private Object getRuikeiKaisyuAmount(Map<String, Object> mainData, String key) {
        Object ruikeiKaisyuAmount = null;
        String currencyCountKbn = (String)(mainData.get("CURRENCY_COUNT_KBN"));
        
        // 通貨"JPY"件数
        Integer jpyCount = (Integer)mainData.get("JPY_COUNT");
        // 通貨"JPY"以外の件数
        Integer etcCurrencyCount = (Integer)mainData.get("ETC_CURRENCY_COUNT");

        if (etcCurrencyCount > 0) {
            ruikeiKaisyuAmount = "*****";
        } else if (jpyCount > 0) {
            ruikeiKaisyuAmount = mainData.get(key);
        }

        return ruikeiKaisyuAmount;
    }
    
    /**
     * 最後尾の行に下線を設定
     */
    private void setLastRowBorderLine(Workbook workbook, Row row) {
        for (int i=1; i<=4; i++) {
            CellStyle newStyle = workbook.createCellStyle();
            
            Cell cell = PoiUtil.getCell(row, i);
            CellStyle style = cell.getCellStyle();
            newStyle.cloneStyleFrom(style);
            newStyle.setBorderBottom(CellStyle.BORDER_THIN);

            cell.setCellStyle(newStyle);
        }
    }
    
    
}
