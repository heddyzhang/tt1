package jp.co.toshiba.hby.pspromis.syuueki.util;

import org.apache.commons.lang3.StringEscapeUtils;
import org.apache.commons.lang3.StringUtils;

/**
 * エスケープ処理用ユーティリティ
 * @author ibayashi
 */
public class EscapeUtils extends StringEscapeUtils {
  public static String escapeSql(String str) {
      if (str == null) {
          return null;
      }
      return StringUtils.replace(str, "'", "''");
  }
}
