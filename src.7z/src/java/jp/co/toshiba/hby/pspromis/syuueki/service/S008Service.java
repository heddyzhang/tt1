package jp.co.toshiba.hby.pspromis.syuueki.service;

import java.math.BigDecimal;
import java.util.Date;
import java.util.HashMap;
//import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.sql.SQLException;
import javax.ejb.Stateless;
import javax.inject.Inject;
import javax.interceptor.Interceptors;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import jp.co.toshiba.hby.pspromis.common.util.BeanUtil;
import jp.co.toshiba.hby.pspromis.common.util.StringUtil;
import jp.co.toshiba.hby.pspromis.syuueki.bean.S008Bean;
//import jp.co.toshiba.hby.pspromis.syuueki.dto.AnkenRecalDto;
import jp.co.toshiba.hby.pspromis.syuueki.dto.PattenCalcDto;
import jp.co.toshiba.hby.pspromis.syuueki.dto.SpInfoInsertDto;
import jp.co.toshiba.hby.pspromis.syuueki.dto.SyuP7ChangeYmItemNetInfoDto;
import jp.co.toshiba.hby.pspromis.syuueki.entity.AnkenMitumoriTbl;
import jp.co.toshiba.hby.pspromis.syuueki.entity.BuMst;
import jp.co.toshiba.hby.pspromis.syuueki.entity.EstContractTypeMst;
import jp.co.toshiba.hby.pspromis.syuueki.entity.OperationLog;
import jp.co.toshiba.hby.pspromis.syuueki.entity.SyuGeBukkenInfoTbl;
import jp.co.toshiba.hby.pspromis.syuueki.entity.SyuGyotaiMst;
import jp.co.toshiba.hby.pspromis.syuueki.entity.SyuKiSpTotalTbl;
import jp.co.toshiba.hby.pspromis.syuueki.entity.SyuPatternMst;
import jp.co.toshiba.hby.pspromis.syuueki.entity.TeamEntity;
import jp.co.toshiba.hby.pspromis.syuueki.entity.SyuCurMst;
import jp.co.toshiba.hby.pspromis.syuueki.entity.SyuZeikbnMst;
import jp.co.toshiba.hby.pspromis.syuueki.enums.Env;
import jp.co.toshiba.hby.pspromis.syuueki.facade.BuMstFacade;
import jp.co.toshiba.hby.pspromis.syuueki.facade.EstContractTypeMstFacade;
import jp.co.toshiba.hby.pspromis.syuueki.facade.JgrpMemberTblFacade;
import jp.co.toshiba.hby.pspromis.syuueki.facade.KanjyoMstFacade;
import jp.co.toshiba.hby.pspromis.syuueki.facade.S008Facade;
import jp.co.toshiba.hby.pspromis.syuueki.facade.SysdateEntityFacade;
import jp.co.toshiba.hby.pspromis.syuueki.facade.SyuGeBukenInfoTblFacade;
import jp.co.toshiba.hby.pspromis.syuueki.facade.SyuGyotaiMstFacade;
import jp.co.toshiba.hby.pspromis.syuueki.facade.SyuKiSpTotalTblFacade;
import jp.co.toshiba.hby.pspromis.syuueki.facade.SyuPatternMstFacade;
//import jp.co.toshiba.hby.pspromis.syuueki.facade.TeamMstFacade;
import jp.co.toshiba.hby.pspromis.syuueki.facade.AnkenMitsumoriNoFacade;
import jp.co.toshiba.hby.pspromis.syuueki.facade.JgrpTblFacade;
import jp.co.toshiba.hby.pspromis.syuueki.facade.M0130BunruiOrgFacade;
import jp.co.toshiba.hby.pspromis.syuueki.facade.N7SetuBunruiMstFacade;
import jp.co.toshiba.hby.pspromis.syuueki.facade.SyuTajigyobuMstFacade;
import jp.co.toshiba.hby.pspromis.syuueki.facade.SyuKiSpCurTblFacade;
import jp.co.toshiba.hby.pspromis.syuueki.facade.SyuCurMstFacade;
import jp.co.toshiba.hby.pspromis.syuueki.facade.SyuKiKaisyuTblFacade;
import jp.co.toshiba.hby.pspromis.syuueki.facade.SyuZeikbnMstFacade;
import jp.co.toshiba.hby.pspromis.syuueki.facade.SyuKiSpTukiITblFacade;
import jp.co.toshiba.hby.pspromis.syuueki.facade.SyuKiNetCateTukiTblFacade;
import jp.co.toshiba.hby.pspromis.syuueki.facade.SyuKiJyuchuSpTblFacade;
import jp.co.toshiba.hby.pspromis.syuueki.facade.SyuKiJyuchuNetTblFacade;
import jp.co.toshiba.hby.pspromis.syuueki.facade.SyuKiNetItemTukiTblFacade;
import jp.co.toshiba.hby.pspromis.syuueki.interceptor.TranceInterceptor;
import jp.co.toshiba.hby.pspromis.syuueki.util.ConstantString;
import jp.co.toshiba.hby.pspromis.syuueki.util.EntityUtils;
import jp.co.toshiba.hby.pspromis.syuueki.util.LoginUserInfo;
import jp.co.toshiba.hby.pspromis.syuueki.util.SyuuekiUtils;
import jp.co.toshiba.hby.pspromis.syuueki.util.Utils;
import jp.co.toshiba.hby.pspromis.syuueki.jdbc.DbUtilsExecutor;
import jp.co.toshiba.hby.pspromis.syuueki.jdbc.SqlFile;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import jp.co.toshiba.hby.pspromis.syuueki.bean.ValidationInfoBean;
import jp.co.toshiba.hby.pspromis.syuueki.entity.SyuKiSpCurTbl;
import jp.co.toshiba.hby.pspromis.syuueki.pages.DivisonComponentPage;
//import org.apache.commons.beanutils.BeanUtils;

/**
 * PS-Promis収益管理システム<br>
 * 収益情報編集 Service
 *
 * @author sano
 */
@Stateless
@Interceptors({TranceInterceptor.class})
public class S008Service {

    /**
     * ロガー
     */
    public static final Logger logger = LoggerFactory.getLogger(S008Service.class);

    @PersistenceContext(unitName = jp.co.toshiba.hby.pspromis.syuueki.util.ConstantString.syuuekiDataSourceName)
    private EntityManager em;

    /**
     * Injection loginUserInfo<br>
     * (ユーザー情報(ユーザーid,名称,所属部課名)を格納したオブジェクト)
     */
    @Inject
    private LoginUserInfo loginUserInfo;
    /**
     * パラメータ格納クラスをinjection(CDI)<br>
     * InjectアノテーションよりAPサーバー(Glassfish)側で自動的にインスタンス作成(new)される。<br>
     */
    @Inject
    private S008Bean s008Bean;

    @Inject
    private S008Facade s008Facade;

    @Inject
    private SyuPatternMstFacade syuPatternMstFacade;

    @Inject
    private SyuGeBukenInfoTblFacade geBukenInfoTblFacade;

    @Inject
    private StoredProceduresService storedProceduresService;

    @Inject
    private OperationLogService operationLogService;

    @Inject
    private BuMstFacade buMstFacade;

    @Inject
    private SyuGyotaiMstFacade syuGyotaiMstFacade;

    @Inject
    private SysdateEntityFacade sysdateFacade;

    @Inject
    private KanjyoMstFacade kanjyoMstFacade;

    @Inject
    private JgrpMemberTblFacade jgrpMemberTblFacade;

    //@Inject
    //private TeamMstFacade teamMstFacade;

    @Inject
    private SyuuekiCommonService syuuekiCommonService;
    
    @Inject
    private SyuKiSpTotalTblFacade syuKiSpTotalTblFacade;

    @Inject
    private EstContractTypeMstFacade estContractTypeMstFacade;

    @Inject
    private SyuKiSpCurTblFacade syuKiSpCurTblFacade;

    @Inject
    private SyuCurMstFacade syuCurMstFacade;

    @Inject
    private SyuuekiUtils syuuekiUtils;

    @Inject
    private AnkenMitsumoriNoFacade ankenMitsumoriNoFacade;

//    @Inject
//    private SyokusyuMstFacade syokusyuMstFacade;
    @Inject
    private JgrpTblFacade jgrpTblFacade;
    @Inject
    private SyuTajigyobuMstFacade syuTajigyobuMstFacade;

    @Inject
    private M0130BunruiOrgFacade m0130BunruiOrgFacade;

    @Inject
    private N7SetuBunruiMstFacade n7SetuBunruiMstFacade;

    @Inject
    private SyuKiKaisyuTblFacade syuKiKaisyuTblFacade;
    
    @Inject
    private SyuZeikbnMstFacade syuZeikbnMstFacade;
    
    @Inject
    private SyuKiSpTukiITblFacade syuKiSpTukiITblFacade;
    
    @Inject
    private SyuKiNetCateTukiTblFacade syuKiNetCateTukiTblFacade;
    
    @Inject
    private SyuKiJyuchuSpTblFacade syuKiJyuchuSpTblFacade;
    
    @Inject
    private SyuKiJyuchuNetTblFacade syuKiJyuchuNetTblFacade;
    
    @Inject
    private SyuKiNetItemTukiTblFacade syuKiNetItemTukiTblFacade;
    
    @Inject
    private DbUtilsExecutor dbUtilsExecutor;
    
    @Inject
    private ValidationInfoBean validationInfoBean;
    
    @Inject
    private DivisonComponentPage divisionComponentPage;

    /**
     * 初期表示 ビジネスロジック
     *
     * @throws Exception
     */
    public void indexExecute() throws Exception {
        try {
            SyuGeBukkenInfoTbl ankenEntity = null;

            if (StringUtils.isEmpty(s008Bean.getAnkenId())) {
                // 案件idが未指定の場合、編集モード(白地案件新規追加)扱いで画面表示
                // 白地案件は一般案件扱い(sales_class=0)とする。
                ankenEntity = new SyuGeBukkenInfoTbl();
                s008Bean.setEditFlg("2");
                // 白地は一般案件とする。
                s008Bean.setSalesClass(ConstantString.salesClassI);

                // 担当者を設定(ログイン者にする)
                //ankenEntity.setHatEgEmpNo(loginUserInfo.getUserId());
                //ankenEntity.setHatEgEmpNm(jgrpMemberTblFacade.getMemberName(loginUserInfo.getUserId()));
                ankenEntity.setEigTantoId(loginUserInfo.getUserId());
                ankenEntity.setEigTantoNm(jgrpMemberTblFacade.getMemberName(loginUserInfo.getUserId()));

            } else {
                // 検索条件をセット
                Map<String, Object> condition = new HashMap<>();
                condition.put("ankenId", s008Bean.getAnkenId());
                condition.put("rirekiId", s008Bean.getRirekiId());
                condition.put("rirekiFlg", s008Bean.getRirekiFlg());
                ankenEntity = s008Facade.getBukkenInfo(condition);
            }

            // 収益物件情報取得
            s008Bean.setSyuGeBukkenInfoTbl(ankenEntity);
            s008Bean.setAnkenFlg(ankenEntity.getAnkenFlg());
            // 最終更新者氏名を取得
            String updateByName = jgrpMemberTblFacade.getMemberName(ankenEntity.getUpdatedBy());
            s008Bean.setUpdateByName(updateByName);

            // 注入パターンマスタ取得
            List<SyuPatternMst> patternList = null;
            if (ankenEntity != null) {
                Map<String, Object> conditionPattern = new HashMap<>();
                conditionPattern.put("subBuId", ankenEntity.getSubBuId());
                conditionPattern.put("divisionCode", ankenEntity.getDivisionCode());

                patternList = syuPatternMstFacade.getAllPatternMst(conditionPattern);
            }
            s008Bean.setSyuPatternMstList(patternList);

            // BUマスタの選択候補を取得
            // (電力ジ対応)
            // 事業部が増えることで、全てのBUを取得すると沢山とれてしまうことで、パフォーマンスやセキュリティに影響を与えたくないので、
            // ログイン者が所属している事業部のBU情報のみを取得するようにする
            //s008Bean.setBuMstList(buMstFacade.findAll());
            Map<String, Object> buMstCondtion = new HashMap<>();
            buMstCondtion.put("divisionCode", loginUserInfo.getJobGrSyokusyuArrayInfo("division"));
            List<BuMst> buMstList = buMstFacade.findConditionList(buMstCondtion);
            s008Bean.setBuMstList(buMstList);

            // 業態マスタの選択候補を取得
            s008Bean.setGyotaiMstList(syuGyotaiMstFacade.findAll());

            // 職種マスタの選択候補を取得
            if (StringUtils.isNotEmpty(s008Bean.getDivisionCode())) {
                s008Bean.setEigJobgrList(jgrpTblFacade.getJobGrList("L", s008Bean.getDivisionCode()));
                s008Bean.setSyuJobgrList(jgrpTblFacade.getJobGrList("M", s008Bean.getDivisionCode()));
                if (StringUtils.isNotEmpty(s008Bean.getEigJobgrCd())) {
                    //s008Bean.setHatEgEmpNoList(jgrpMemberTblFacade.getEmpNoList("L", s008Bean.getDivisionCode(), s008Bean.getEigJobgrCd()));
                    s008Bean.setEigTantoList(jgrpMemberTblFacade.getEmpNoList("L", s008Bean.getDivisionCode(), s008Bean.getEigJobgrCd()));
                }
                if (StringUtils.isNotEmpty(s008Bean.getSyuJobgrCd())) {
                    s008Bean.setSyuTantoIdList(jgrpMemberTblFacade.getEmpNoList("M", s008Bean.getDivisionCode(), s008Bean.getSyuJobgrCd()));
                }
            }
//            s008Bean.setSyokusyuMstList(syokusyuMstFacade.getMemberList(ankenEntity.getSyuJobgrCd()));

            // ISP事業部
            s008Bean.setIspDivisionNmList(syuTajigyobuMstFacade.getDivisionRnmList(""));

            Map<String, Object> bunruiKey = new HashMap<>();
            bunruiKey.put("buCd", ankenEntity.getSubBuId());
            bunruiKey.put("bunruiCd", ankenEntity.getBunruiCd());
            bunruiKey.put("setuBunruiCd", ankenEntity.getSetuBunruiCd());
            // 収益分類
            s008Bean.setBunruiCdList(m0130BunruiOrgFacade.getList(bunruiKey));
            if (StringUtils.isNotEmpty(ankenEntity.getSubBuId()) && StringUtils.isNotEmpty(ankenEntity.getBunruiCd())) {
                s008Bean.setBunruiNm(m0130BunruiOrgFacade.selectBunruiNm(bunruiKey));
            }
            // 設備分類
            s008Bean.setSetuBunruiCdList(n7SetuBunruiMstFacade.getSetuBunruiNmList(bunruiKey));
            if (StringUtils.isNotEmpty(ankenEntity.getSubBuId()) && StringUtils.isNotEmpty(ankenEntity.getSetuBunruiCd())) {
                s008Bean.setSetuBunruiNm(n7SetuBunruiMstFacade.selectSetuBunruiNm(bunruiKey));
            }

            // step3 20160105 白地案件登録
            // 編集ボタン表示制御
            // 白地案件or進行基準案件の場合は編集ボタン押下可能
            // 履歴フラグがNULLなら編集ボタン押下可能
//            if (("1".equals(s008Bean.getSyuGeBukkenInfoTbl().getShirajiFlg()) || "1".equals(s008Bean.getSyuGeBukkenInfoTbl().getSalesClass()) )
//                    && StringUtils.isEmpty(s008Bean.getRirekiFlg())){
            // ste3改 一般案件でも、編集可能な項目が発生したため、編集ボタンを表示できるようにした。
            if (StringUtils.isEmpty(s008Bean.getRirekiFlg())) {
                s008Bean.setEditBtnFlg("1");
            }

            // 白地案件新規登録時,事業部の初期選択を設定
            if (StringUtils.isEmpty(s008Bean.getSyuGeBukkenInfoTbl().getDivisionCode())) {
                s008Bean.getSyuGeBukkenInfoTbl().setDivisionCode(loginUserInfo.getPriorityDivCode());
            }

            // 白地案件の場合、ログイン者チームの保持案件でない場合は編集不可(編集ボタン非表示)にする。
            //if ("1".equals(s008Bean.getSyuGeBukkenInfoTbl().getShirajiFlg()) && "1".equals(s008Bean.getEditBtnFlg())) {
            // step3改 一般案件で、ログイン者チームの保持案件でない場合は編集不可(編集ボタン非表示)にする。
            if (!"1".equals(s008Bean.getSyuGeBukkenInfoTbl().getSalesClass()) && "1".equals(s008Bean.getEditBtnFlg())) {
                if (!this.isEditFlg(s008Bean.getSyuGeBukkenInfoTbl())) {
                    s008Bean.setEditBtnFlg("0");
                }
            }

            // 参照時設定項目
            if (!"2".equals(s008Bean.getEditFlg())) {
                s008Bean.setSalesClass(s008Bean.getSyuGeBukkenInfoTbl().getSalesClass());
                s008Bean.setShirajiFlg(s008Bean.getSyuGeBukkenInfoTbl().getShirajiFlg());

                if (!StringUtils.isEmpty(s008Bean.getSyuGeBukkenInfoTbl().getGyotai())) {
                    s008Bean.setDispGyotai(s008Bean.getSyuGeBukkenInfoTbl().getGyotai() + "：" + syuGyotaiMstFacade.getName(s008Bean.getSyuGeBukkenInfoTbl().getGyotai()));
                }
            }

            // [契約形態]名称を取得
            EstContractTypeMst estContractTypeMst = estContractTypeMstFacade.selectContractType(ankenEntity.getKeiyakuKeitaiCd());
            if (estContractTypeMst != null && StringUtils.isNotEmpty(estContractTypeMst.getContractName())) {
                s008Bean.setKeiyakuKeitaiName(estContractTypeMst.getContractName());
            }

            Map<String, Object> condition = new HashMap<>();
            condition.put("ankenId", s008Bean.getAnkenId());
            AnkenMitumoriTbl anken = ankenMitsumoriNoFacade.getAnkenMitsumoriNo(condition);
            s008Bean.setMitumoriNo(anken.getMitumoriNo());

            // (収益)受注年月/(収益)売上予定/(収益)回収予定 が分割されているかどうかのFLGを取得
            // (一般案件のみ行う)
            findKanjyoYm();
            getYmEditFlg();
            
        } catch (Exception e) {
            throw e;
        }
    }

    /**
     * 勘定年月取得
     */
    public void findKanjyoYm() throws Exception {
        String kanjoYm = kanjyoMstFacade.getNowKanjoDate(s008Bean.getSalesClass());
        Date kanjoDate = Utils.parseDate(kanjoYm);
        kanjoYm = syuuekiUtils.exeFormatYm(kanjoDate);
        s008Bean.setNowYm(kanjoYm);
    }

    /**
     * 対象案件の事業部が(原子力)タイプであるかを確認するための情報をbeanにセット
     */
    public void setBeanIsNuclear() {
        boolean isNuclearDivision = divisionComponentPage.isNuclearDivision(s008Bean.getDivisionCode());
        s008Bean.setNuclearDivision(isNuclearDivision);
    }
    
    /**
     * 2017/11/14 ADD #5 #12 #22 （収益）受注年月と（収益）売上予定を加える
     * それぞれの項目の編集権限を取得する(保存ボタン押下後に取得すること)
     */
    public void getYmEditFlg() {
        // (収益)受注月,(収益)売上月,(収益)回収月の見込分割FLGの初期化(0:見込分割 1:分割されていない)
        s008Bean.setJyuchuSplitFlg("1");
        s008Bean.setUriageSplitFlg("1");
        s008Bean.setKaisyuSplitFlg("1");
        
        s008Bean.setJyuchuEndEditFlg("1");  // 受注年月はデフォルトの入力は可能としておく
        s008Bean.setUriageEndEditFlg("0");
        s008Bean.setKaisyuEndEditFlg("0");
        s008Bean.setNokiEditFlg("0");
        s008Bean.setKensyutukiEditFlg("0");

        // 一般案件のみ(収益)受注年月,(収益)売上年月,(収益)回収年月が分割されているかをチェック
        if (ConstantString.salesClassI.equals(s008Bean.getSalesClass())) {
            ////// 一般案件の場合
            //(収益)受注年月,(収益)売上年月,(収益)回収年月が(当月以降の見込月が)分割されているかをチェック
            s008Bean.setJyuchuSplitFlg(s008Facade.getJyuchuEndEditFlg(s008Bean));
            s008Bean.setJyuchuEndEditFlg(s008Bean.getJyuchuSplitFlg());
            logger.info("jyuchuSplitFlg=[{}],jyuchuEndEditFlg=[{}]", s008Bean.getJyuchuSplitFlg(), s008Bean.getJyuchuEndEditFlg());
            
            s008Bean.setUriageSplitFlg(s008Facade.getUriageEndEditFlg(s008Bean));
            s008Bean.setUriageEndEditFlg(s008Bean.getUriageSplitFlg());
            logger.info("uriageSplitFlg=[{}],uriageEndEditFlg=[{}]", s008Bean.getUriageSplitFlg(), s008Bean.getUriageEndEditFlg());
            
            s008Bean.setKaisyuSplitFlg(s008Facade.getKaisyuEndEditFlg(s008Bean));
            s008Bean.setKaisyuEndEditFlg(s008Bean.getKaisyuSplitFlg());
            logger.info("kaisyuSplitFlg=[{}],kaisyuEndEditFlg=[{}]", s008Bean.getKaisyuSplitFlg(), s008Bean.getKaisyuEndEditFlg());
            
            // 納期,検収月は入力可
            s008Bean.setNokiEditFlg("1");
            s008Bean.setKensyutukiEditFlg("1");

        } else {
            ////// 進行基準案件の場合
            if ("1".equals(s008Bean.getAnkenFlg())) {
                //// まとめ案件
                // 回収情報はまとめ案件で入力するので、回収月は入力可とする
                s008Bean.setKaisyuEndEditFlg("1");
                
                // 納期,検収月は子案件のmax値をまとめ案件に登録するため、まとめ案件ではこれらの入力は不可。
                
            } else {
                //// 子案件
                // 子案件の売上予定,回収月はまとめ案件のものが利用されるため、子案件では入力不可。
                
                // 納期,検収月は入力可
                s008Bean.setNokiEditFlg("1");
                s008Bean.setKensyutukiEditFlg("1");
            }
        }

    }
    
    /**
     * 更新権限チェック
     *
     * @return
     * @throws Exception
     */
    private boolean isEditFlg(SyuGeBukkenInfoTbl geBukken) throws Exception {
//        // 自事業部の全案件が編集許可されているかをチェック
//        boolean isAllFlg = AuthorityCheck.isMyDivAnkenIAllEditFlg(geBukken, loginUserInfo);
//        if (isAllFlg) {
//            return isAllFlg;
//        } else {
//            // 自事業部の全案件が編集許可されていない場合、自チームの案件のみ編集可能チェック
//            List<TeamEntity> teamMstList = teamMstFacade.findUserTeamList(loginUserInfo.getUserId());
//            boolean authEditFlg = AuthorityCheck.isMyTeam(teamMstList, geBukken);
//            return authEditFlg;
//        }

        // 自チームの案件のみ編集可能チェック
        //List<TeamEntity> teamMstList = teamMstFacade.findUserTeamList(loginUserInfo.getUserId());
        //return loginUserInfo.isAnkenEdit(geBukken, teamMstList);
        boolean isEditOk = syuuekiCommonService.isAnkenEditOk(geBukken);
        return isEditOk;
    }

    /**
     * 更新チームコードチェック(白地案件登録・更新時) ビジネスロジック
     *
     * @return
     * @throws Exception
     */
    public int checkTeamCd() throws Exception {
        this.editTeamCd();

        SyuGeBukkenInfoTbl geBukken = new SyuGeBukkenInfoTbl();
        geBukken.setDivisionCode(s008Bean.getDivisionCode());
        geBukken.setAtsukaiTeamCode(s008Bean.getAtsukaiTeamCode());
        geBukken.setAtsukaiCCode(s008Bean.getAtsukaiCCode());
        geBukken.setHbCCd(s008Bean.getHbCCd());
        geBukken.setSzCCd(s008Bean.getSzCCd());
        geBukken.setEgTeamCd(s008Bean.getEgTeamCd());
        geBukken.setSzTeamCd(s008Bean.getSzTeamCd());
        geBukken.setShirajiFlg(s008Bean.getShirajiFlg());

        boolean isEdit = true;
        if ("1".equals(s008Bean.getShirajiFlg())) {
            isEdit = this.isEditFlg(geBukken);
        }

        //if (this.isEditFlg(geBukken)) {
        if (isEdit) {
            return 1;
        } else {
            return 0;
        }
    }

    /**
     * データチェック処理 ビジネスロジック
     *
     * @return
     * @throws Exception
     */
    public void check() throws Exception {
        try {
            // 検索条件をセット
            Map<String, Object> condition = new HashMap<>();
            condition.put("ankenId", s008Bean.getAnkenId());
            condition.put("rirekiId", s008Bean.getRirekiId());
            condition.put("dataKbn", "J");

            s008Bean.setSyuKiSpTukiSTblCount(s008Facade.getSyuKiSpTukiSTblCount(condition));
            s008Bean.setSyuKiNetCateTukiTblCount(s008Facade.getSyuKiNetCateTukiTblCount(condition));
        } catch (Exception e) {
            throw e;
        }
    }

    /**
     * 事業部変更時の処理
     */
    public void division() {
        if (StringUtils.isNotBlank(s008Bean.getDivisionCode())) {
            s008Bean.setEigJobgrList(jgrpTblFacade.getJobGrList("L", s008Bean.getDivisionCode()));
            s008Bean.setSyuJobgrList(jgrpTblFacade.getJobGrList("M", s008Bean.getDivisionCode()));
            if (StringUtils.isNotBlank(s008Bean.getEigJobgrCd())) {
                //s008Bean.setHatEgEmpNoList(jgrpMemberTblFacade.getEmpNoList("L", s008Bean.getDivisionCode(), s008Bean.getEigJobgrCd()));
                s008Bean.setEigTantoList(jgrpMemberTblFacade.getEmpNoList("L", s008Bean.getDivisionCode(), s008Bean.getEigJobgrCd()));
            }
            if (StringUtils.isNotBlank(s008Bean.getSyuJobgrCd())) {
                s008Bean.setSyuTantoIdList(jgrpMemberTblFacade.getEmpNoList("M", s008Bean.getDivisionCode(), s008Bean.getSyuJobgrCd()));
            }
        }
    }

    /**
     * JobGr変更時の処理
     */
    public void jobGr() {
        if (s008Bean.getSyokusyuCd().equals("L")) {
            if (StringUtils.isNotBlank(s008Bean.getEigJobgrCd())) {
                //s008Bean.setHatEgEmpNoList(jgrpMemberTblFacade.getEmpNoList("L", s008Bean.getDivisionCode(), s008Bean.getEigJobgrCd()));
                s008Bean.setEigTantoList(jgrpMemberTblFacade.getEmpNoList("L", s008Bean.getDivisionCode(), s008Bean.getEigJobgrCd()));
            }
        } else if (s008Bean.getSyokusyuCd().equals("M")) {
            if (StringUtils.isNotBlank(s008Bean.getSyuJobgrCd())) {
                s008Bean.setSyuTantoIdList(jgrpMemberTblFacade.getEmpNoList("M", s008Bean.getDivisionCode(), s008Bean.getSyuJobgrCd()));
            }
        }
    }

    /**
     * サブBU変更時の処理
     */
    public void subBu() {
        Map<String, Object> bunruiKey = new HashMap<>();
        bunruiKey.put("buCd", s008Bean.getSubBu());
        // 収益分類
        s008Bean.setBunruiCdList(m0130BunruiOrgFacade.getList(bunruiKey));
        // 設備分類
        s008Bean.setSetuBunruiCdList(n7SetuBunruiMstFacade.getSetuBunruiNmList(bunruiKey));
    }

    /**
     * 登録するチームコードを判定
     */
    public void editTeamCd() {
        // 業態のISP区分を取得
        String gyotaiIsp = "";
        SyuGyotaiMst condition = new SyuGyotaiMst();
        condition.setGyotaiCd(s008Bean.getGyotai());
        List<SyuGyotaiMst> gyotaiList = syuGyotaiMstFacade.getGyotaiList(condition);
        if (gyotaiList != null && !gyotaiList.isEmpty()) {
            gyotaiIsp = StringUtils.defaultString(gyotaiList.get(0).getGyotaiIsp());
        }

        // 業態ISPで参照先を変更　GE or HB --販売  SZ --製造
        if (gyotaiIsp.equals("GE") || gyotaiIsp.equals("HB")) {
            s008Bean.setAtsukaiTeamCode(s008Bean.getEgTeamCd());
            s008Bean.setAtsukaiCCode(s008Bean.getHbCCd());

        } else if (gyotaiIsp.equals("SZ")) {
            s008Bean.setAtsukaiTeamCode(s008Bean.getSzTeamCd());
            s008Bean.setAtsukaiCCode(s008Bean.getSzCCd());

        }
        logger.info("check gyotai=" + s008Bean.getGyotai() + " gyotaiIsp=" + gyotaiIsp + " AtsukaiTeamCode=" + s008Bean.getAtsukaiTeamCode() + " AtsukaiCCode=" + s008Bean.getAtsukaiCCode());
    }

    /**
     * 登録処理 ビジネスロジック
     *
     * @return
     * @throws Exception
     */
    public boolean save() throws Exception {
        boolean retBool = true;
        boolean isShirajiNewFlg = false;

        try {
            // 事業部コード:(原子力)であるかを判断
            boolean isNuclearDivision = divisionComponentPage.isNuclearDivision(s008Bean.getDivisionCode());

            SyuGeBukkenInfoTbl syuGeBukkenInfoItem = null;
            String ispClearAnkenId = null;

            if (ConstantString.salesClassS.equals(s008Bean.getSalesClass())) {
                // 進行基準案件の更新処理
                saveShinko();
            } else if ("2".equals(s008Bean.getEditFlg()) || "1".equals(s008Bean.getShirajiFlg())) {
                ////// 白地調整案件の新規・編集画面の場合
                // 登録済みデータの取得
                syuGeBukkenInfoItem = getTargetAnkenEntity();
                // ISP区分が分割以外 or 関連ISP案件がクリアor別案件に変わる場合は、元の関連ISP案件のISP区分を元に戻す(為の案件IDを取得しておく)
                if (isClearIspKbn(syuGeBukkenInfoItem)) {
                    ispClearAnkenId = syuGeBukkenInfoItem.getIspRelateId();
                }
                if (StringUtils.isEmpty(syuGeBukkenInfoItem.getAnkenId())) {
                    isShirajiNewFlg = true;
                }
                // 白地案件で必要な項目のセット
                shirajiDataEntry(syuGeBukkenInfoItem);
            }

            if (syuGeBukkenInfoItem == null) {
                syuGeBukkenInfoItem = getTargetAnkenEntity();
            }

            //// 共通項目のデータをセット
            //syuGeBukkenInfoItem.setHatEgEmpNo(s008Bean.getHatEgEmpNo()); // 営業担当
            //syuGeBukkenInfoItem.setHatEgEmpNm(s008Bean.getHatEgEmpNm());
            syuGeBukkenInfoItem.setEigTantoId(s008Bean.getEigTantoId()); // 営業担当
            syuGeBukkenInfoItem.setEigTantoNm(s008Bean.getEigTantoNm());
            syuGeBukkenInfoItem.setSyuTantoId(s008Bean.getSyuTantoId()); // 収益担当
            syuGeBukkenInfoItem.setSyuTantoNm(s008Bean.getSyuTantoNm());

            // 2018A 1198
            syuGeBukkenInfoItem.setIspDivisionNm(s008Bean.getIspDivisionNm()); // ISP事業部
            syuGeBukkenInfoItem.setIspKbn(s008Bean.getIspKbn()); // ISP区分
            
            // STEP4(2016下) add
            // 収益情報
            syuGeBukkenInfoItem.setAnkenRank(s008Bean.getAnkenRank()); // 案件ランク
            if  (isNuclearDivision) {
                syuGeBukkenInfoItem.setPotentialFlg(s008Bean.getPotentialFlg());  // ポテンシャル管理
                syuGeBukkenInfoItem.setBunruiCd(s008Bean.getBunruiCd()); // 収益分類
                syuGeBukkenInfoItem.setSetuBunruiCd(s008Bean.getSetuBunruiCd()); // 設備分類
            } else {
                syuGeBukkenInfoItem.setPotentialFlg("0");  // ポテンシャル管理
            }

            syuGeBukkenInfoItem.setMondaiFlg(StringUtils.defaultString(s008Bean.getMondaiFlg(), "0")); // 問題案件
            syuGeBukkenInfoItem.setMondaiComment(s008Bean.getMondaiComment()); // 問題案件_コメント
            syuGeBukkenInfoItem.setSpKakuteiFlg(s008Bean.getSpKakuteiFlg()); // SP確定
            syuGeBukkenInfoItem.setNetKakuteiFlg(s008Bean.getNetKakuteiFlg()); // NET確定
            // 2017/11/14 ADD #5 #12 #22 （収益）受注年月と（収益）売上予定を加える
            syuGeBukkenInfoItem.setJyuchuEnd(Utils.parseDate(s008Bean.getJyuchuEnd())); // （収益）受注年月
            syuGeBukkenInfoItem.setUriageEnd(Utils.parseDate(s008Bean.getUriageEnd())); // （収益）売上予定
            syuGeBukkenInfoItem.setKaisyuEnd(Utils.parseDate(s008Bean.getKaisyuEnd())); // 回収月
            if (StringUtil.isNotBlank(s008Bean.getKaisyuKakuninFlg())) {
                syuGeBukkenInfoItem.setKaisyuKakuninFlg(Short.parseShort(s008Bean.getKaisyuKakuninFlg())); // 回収確認
            }
            // 2017/11/14 MOD #5 #12 #22 納期を年月日に変更
            syuGeBukkenInfoItem.setNoki(Utils.parseDateWithDate(s008Bean.getNoki())); // 納期
            syuGeBukkenInfoItem.setKensyutuki(StringUtils.replace(s008Bean.getKensyutuki(), "/", "")); // 検収月
            syuGeBukkenInfoItem.setHatlinkSpnetFlg(s008Bean.getHatlinkSpnetFlg()); // 発番自動反映_SP/NET   STEP3改(2016上) add
            syuGeBukkenInfoItem.setHatlinkDateFlg(s008Bean.getHatlinkDateFlg()); // 発番自動反映_売上予定  STEP3改(2016上) add
            syuGeBukkenInfoItem.setInputSaNetFlg(StringUtils.defaultString(s008Bean.getInputSaNetFlg(), "1"));// NET入力の単位:最終見込損益
            syuGeBukkenInfoItem.setInputKiNetFlg(StringUtils.defaultString(s008Bean.getInputKiNetFlg(), "1")); // NET入力の単位:期間損益
            syuGeBukkenInfoItem.setQuarterDispFlg(StringUtils.defaultString(s008Bean.getQuarterDispFlg(), "0"));// 画面表示とExcel出力のQuarter処理フラグ
            syuGeBukkenInfoItem.setMaeruikeiDispFlg(StringUtils.defaultString(s008Bean.getMaeruikeiDispFlg(), "0")); // 期間損益画面の累計表示フラグ
            //syuGeBukkenInfoItem.setChunyuPtnNo(s008Bean.getChunyuPtnNo()); // 注入パターン
            //syuGeBukkenInfoItem.setChunyuStartYm(Utils.parseDate(s008Bean.getChunyuStartYm())); // 注入開始年月

            // UPDATE or INSERT
            // UPDATE時は、変更のあった項目だけ更新される
            geBukenInfoTblFacade.merge(syuGeBukkenInfoItem);
            em.flush();

            // 関連ISP更新
            if ("2".equals(s008Bean.getEditFlg())) {
                updateIspAnken();
            }

            // (白地案件)関連ISP案件がクリアor別に変わる場合、変更前の関連ISP案件を元に戻す(パッケージで行う)
            if (StringUtils.isNotEmpty(ispClearAnkenId)) {
                clearIspKbn(ispClearAnkenId);
            }

            // ポテンシャル管理更新
            if (isNuclearDivision) {
                updatePotentialFlg();
            }

            // (白地案件)新規登録時は、SYU_KI_SP_TOTAL_TBLも作成する。
            if (isShirajiNewFlg) {
                createSpTable();

                // (2017/09/08)デフォルトで仮の受注通知も作成しておく。
                createKariKeiyakuData();
            }

            // 2017/11/14 ADD #5 #12 #22 （収益）受注年月と（収益）売上予定を加える
            // (一般案件のみ行う)
            if (ConstantString.salesClassI.equals(s008Bean.getSalesClass())) {
                moveSyuekiYm();
            }

            // 操作ログを登録
            registOperationLog();

            //// 再計算処理
            if (ConstantString.salesClassS.equals(s008Bean.getSalesClass())) {
                calc();
            } else {
                callRecalPackage();
            }

            // 不要な項番の見込月データ(NET関連が全てNULLのデータ)を削除する
            deketeMikomiTukiEmptyNet();
            
        } catch (Exception e) {
            throw e;
        }
        return retBool;
    }

    /**
     * (収益)各年月の移動制御
     */
    private void moveSyuekiYm() throws Exception {
        // 同期処理を追加
        s008Bean.setOldJyuchuEnd(s008Bean.getOldJyuchuEnd() == null ? "" : s008Bean.getOldJyuchuEnd());
        s008Bean.setOldUriageEnd(s008Bean.getOldUriageEnd() == null ? "" : s008Bean.getOldUriageEnd());
        s008Bean.setOldKaisyuEnd(s008Bean.getOldKaisyuEnd() == null ? "" : s008Bean.getOldKaisyuEnd());

        String kanjyoYm = StringUtils.replace(s008Bean.getNowYm(), "/", "");
        
        // 受注月の移動
        String jyuchuEnd = StringUtils.replace(s008Bean.getJyuchuEnd(), "/", "");
        if (StringUtils.isNotEmpty(jyuchuEnd) && jyuchuEnd.compareTo(kanjyoYm) >= 0) {
            moveJyuchuSpData();
            moveJyuchuNetData();
        }

        // 売上年月の移動
        String uriageEnd = StringUtils.replace(s008Bean.getUriageEnd(), "/", "");
        if (StringUtils.isNotEmpty(uriageEnd) && uriageEnd.compareTo(kanjyoYm) >= 0) {
            moveUriageSpData();
            moveUriageNetData();
            moveUriageNetItemData();
        }

        // 回収月の移動
        String kaisyuEnd = StringUtils.replace(s008Bean.getKaisyuEnd(), "/", "");
        if (StringUtils.isNotEmpty(kaisyuEnd) && kaisyuEnd.compareTo(kanjyoYm) >= 0) {
            moveKaisyuTukiData();
        }

//        // 受注月の移動
//        if (!s008Bean.getOldJyuchuEnd().equals(s008Bean.getJyuchuEnd()) && StringUtils.isNotEmpty(s008Bean.getJyuchuEnd())) {
//            s008Facade.updateByJyuchuEnd(s008Bean);
//        }
//        // 売上月の移動
//        if (!s008Bean.getOldUriageEnd().equals(s008Bean.getUriageEnd()) && StringUtils.isNotEmpty(s008Bean.getUriageEnd())) {
//            s008Facade.updateByUriageEnd(s008Bean);
//        }
//        // 回収月の移動
//        if (!s008Bean.getOldKaisyuEnd().equals(s008Bean.getKaisyuEnd()) && StringUtils.isNotEmpty(s008Bean.getKaisyuEnd())) {
//            s008Facade.updateByKaisyuEnd(s008Bean);
//        }
    }
    
    
    /**
     * 進行基準案件の更新処理
     */
    private void saveShinko() throws Exception {
        // 更新対象項目のみセット
        Map<String, Object> condition = new HashMap<>();
        condition.put("ankenId", s008Bean.getAnkenId());
        condition.put("rirekiId", s008Bean.getRirekiId());
        condition.put("chunyuPtnNo", s008Bean.getChunyuPtnNo()); // 注入パターン
        condition.put("chunyuStartYm", s008Bean.getChunyuStartYm()); // 注入開始年月
        condition.put("quarterDispFlg", s008Bean.getQuarterDispFlg()); // 四半期表示
        condition.put("maeruikeiDispFlg", s008Bean.getMaeruikeiDispFlg()); // 前期累計表示
        condition.put("userId", this.loginUserInfo.getUserId());
        condition.put("dataKbn", "J");
        condition.put("ankenRev", s008Bean.getAnkenRev());
        condition.put("salesClass", s008Bean.getSalesClass());

        // 収益物件情報取更新
        s008Facade.updateBukkenInfo(condition);

        // 受注通知実績の存在チェック
        Integer existCount = s008Facade.getSyuKiSpTukiSTblCount(condition);

        // 収益物件情報取得（案件まとめフラグ(1件別：0、まとめ案件:1)の取得）
        s008Bean.setSyuGeBukkenInfoTbl(s008Facade.getBukkenInfo(condition));
        String ankenFlg = StringUtils.defaultString(s008Bean.getSyuGeBukkenInfoTbl().getAnkenFlg(), "0");

        // 纏め案件単位
        if ("1".equals(ankenFlg)) {
            // 受注通知実績がない場合、SP情報を登録する
            if (existCount == 0) {
                // SP情報の登録「SYU_KI_SP_CUR_TBL」「SYU_KI_SP_TUKI_S_TBL」
                callSpInfoInsert();
            }
        }

        // NET情報の登録
        // 画面の注入パターン設定
        if (StringUtils.isNotEmpty(s008Bean.getChunyuPtnNo())) {
            // 注入パターン計算パッケージの呼出し
            callPatenCalc();
            // 画面の注入パターン未設定
        } else {
            // 期間損益TBL（原価）　カテゴリタイトルの削除
            s008Facade.deleteSyuKiNetCateTitleTbl(condition);
            // 期間損益TBL（原価）　カテゴリ別－月別詳細の削除
            s008Facade.deleteSyuKiNetCateTukiTbl(condition);
        }

        // 再計算処理
        //calc();
    }

    /**
     * 更新対象案件情報を取得しておく
     */
    private SyuGeBukkenInfoTbl getTargetAnkenEntity() {
        SyuGeBukkenInfoTbl syuGeBukkenInfoItem = new SyuGeBukkenInfoTbl();
        if (StringUtils.isNotEmpty(s008Bean.getAnkenId())) {
            Map<String, Object> condition = new HashMap<>();
            condition.put("ankenId", s008Bean.getAnkenId());
            condition.put("rirekiId", s008Bean.getRirekiId());
            condition.put("rirekiFlg", s008Bean.getRirekiFlg());
            SyuGeBukkenInfoTbl ankenEntity = s008Facade.getBukkenInfo(condition);

            syuGeBukkenInfoItem = BeanUtil.createAndCopy(SyuGeBukkenInfoTbl.class, ankenEntity);
        }
        EntityUtils.setUpdatedInfo(syuGeBukkenInfoItem, loginUserInfo.getUserId());

        return syuGeBukkenInfoItem;
    }

    /**
     * 白地案件の新規登録のための項目データをentityに設定
     */
    private void shirajiDataEntry(SyuGeBukkenInfoTbl syuGeBukkenInfoItem) throws Exception {
        // 事業部コード:(原子力)であるかを判断
        boolean isNuclearDivision = divisionComponentPage.isNuclearDivision(s008Bean.getDivisionCode());
            
        if (StringUtils.isEmpty(s008Bean.getAnkenId())) {
            // SEQ番号を取得
            String shirajiSeq = s008Facade.getShirajiSeq();
            // 事業部の2桁目を取得
            //String divisionNum = StringUtils.substring(s008Bean.getDivisionCode(), 1, 2);
            //String wkAnkenId = "C" + divisionNum + shirajiSeq;
            String shirajiHead = divisionComponentPage.getTargetDivision(s008Bean.getDivisionCode()).getCAnkenHead();

            String wkAnkenId = shirajiHead + shirajiSeq;
            logger.info("NEW C ANKEN_ID=[{}]", wkAnkenId);
            
            String wkRirekiId = "0";
            s008Bean.setAnkenId(wkAnkenId);
            s008Bean.setRirekiId(wkRirekiId);
            s008Bean.setShirajiFlg("1");

            // 画面外の項目をセット
            syuGeBukkenInfoItem.setAnkenId(wkAnkenId); // 物件Key
            syuGeBukkenInfoItem.setAnkenRev(0); // 案件Rev
            syuGeBukkenInfoItem.setRirekiId(Integer.parseInt(wkRirekiId)); // 履歴Key
            syuGeBukkenInfoItem.setStatus("0"); // ステータス
            syuGeBukkenInfoItem.setAnkenFlg("0"); // 案件まとめフラグ
            syuGeBukkenInfoItem.setHbNetFlg("0"); // 発番NET利用フラグ
            syuGeBukkenInfoItem.setSalesClass("0"); // 売上基準フラグ
            syuGeBukkenInfoItem.setNetKanriFlg("1"); // NET管理単位フラグ
            syuGeBukkenInfoItem.setSyuekiFlg("1"); // 収益対象フラグ
            syuGeBukkenInfoItem.setSnKbn("X"); // S/N
//            syuGeBukkenInfoItem.setKeiyakuRenbanMax(); // 契約_受注通知の最終連番
            syuGeBukkenInfoItem.setJyuchuZanFlg("0"); // 受注残フラグ
            syuGeBukkenInfoItem.setShirajiFlg("1"); // 白地フラグ
            syuGeBukkenInfoItem.setIsDeleted("0"); // 削除フラグ
            syuGeBukkenInfoItem.setUriageEndFlg("0"); // 売上区分
            // (2017/09/08)見込入力の案件単位は「最終見込損益画面」の編集条件で参照しているため、"1":編集 固定にする。
            //syuGeBukkenInfoItem.setInputAnkenFlg("0"); // 見込入力の案件単位
            syuGeBukkenInfoItem.setInputAnkenFlg("1"); // 見込入力の案件単位
            syuGeBukkenInfoItem.setSabunHaneiFlg("0"); // 見込差反映済
            syuGeBukkenInfoItem.setSaikeisanFlg("0"); // 再計算要フラグ
            syuGeBukkenInfoItem.setInputAnkenDisp("0"); // 表示用：見込入力の案件単位
            syuGeBukkenInfoItem.setBunkatsuFlg("0"); // 分割見込
            syuGeBukkenInfoItem.setUriageShijiFlg("0"); // 売上指示状況
            syuGeBukkenInfoItem.setUriSyusei("0"); // 売上修正対象
            syuGeBukkenInfoItem.setMitKaitoFlg("0"); // 見積回答あり
            syuGeBukkenInfoItem.setChotatuKaitoFlg("0"); // 調達回答あり
            syuGeBukkenInfoItem.setMikomiFlg("0"); // 見込未入力
            syuGeBukkenInfoItem.setChunyuTyokaFlg("0"); // 注入超過
            syuGeBukkenInfoItem.setKariSpFlg("0"); // 仮SP
            syuGeBukkenInfoItem.setKariNetFlg("0"); // 仮NET

            // 白地案件はデフォルトで受注売上見込一覧と期間損益(一般)で編集権限を与えるために通貨JPY、一覧編集FLGを付与する。
            syuGeBukkenInfoItem.setKeiyakuCurCode(ConstantString.currencyCodeEn);
            syuGeBukkenInfoItem.setInputIchiranFlg("1");

            // 受注月・売上月は初回のみセット(後は受注見込、売上見込の更新処理で随時更新されるはず)
            syuGeBukkenInfoItem.setJyuchuEnd(convDate(s008Bean.getHatJyuchuDateI()));
            syuGeBukkenInfoItem.setUriageEnd(convDate(s008Bean.getUriageEndI()));

            // 担当者は新規登録時のみセット
            //syuGeBukkenInfoItem.setHatEgEmpNo(s008Bean.getHatEgEmpNo());
            //syuGeBukkenInfoItem.setHatEgEmpNm(s008Bean.getHatEgEmpNm());

            //原子力のみ見積番号追加 (20160511)
            if (isNuclearDivision) {
                syuGeBukkenInfoItem.setMitumoriKbn("Y");
            }

            EntityUtils.setCreatedInfo(syuGeBukkenInfoItem, loginUserInfo.getUserId());
        }

        // 画面編集項目
        syuGeBukkenInfoItem.setDivisionCode(s008Bean.getDivisionCode());
        // 案件情報
        syuGeBukkenInfoItem.setAnkenName(s008Bean.getAnkenName());// 案件名称
        syuGeBukkenInfoItem.setTradeCode(s008Bean.getTradeCode());// 注文主
        syuGeBukkenInfoItem.setTradeName(s008Bean.getTradeName());
        syuGeBukkenInfoItem.setStchCode(s008Bean.getStchCode());// 設置場所
        syuGeBukkenInfoItem.setStchName(s008Bean.getStchName());
        syuGeBukkenInfoItem.setPlantCode(s008Bean.getPlantCode());// プラントコード
        syuGeBukkenInfoItem.setToriatsuCd(s008Bean.getToriatsuCd());// 取扱店コード
        // サブBU 名称やIDを取得
        syuGeBukkenInfoItem.setSubBuId(s008Bean.getSubBu());
        // 検索条件
        Map<String, Object> condition = new HashMap<>();
        condition.put("sbuCode", s008Bean.getSubBu());
        BuMst buItem = buMstFacade.findBuMst(condition);
        if (buItem != null) {
            syuGeBukkenInfoItem.setSubBuName(buItem.getSbuName());
            syuGeBukkenInfoItem.setBuId(buItem.getId());
            syuGeBukkenInfoItem.setBuName(buItem.getBuName());
        }
        // 実施時期/定検回数
        if (isNuclearDivision) {
            if (StringUtil.isNotBlank(s008Bean.getTeiken())) {
                syuGeBukkenInfoItem.setTeiken(Integer.parseInt(s008Bean.getTeiken()));
                syuGeBukkenInfoItem.setJissiNendo("");
            } else {
                syuGeBukkenInfoItem.setJissiNendo(StringUtils.replace(s008Bean.getJissiNendo(), "/", ""));
                syuGeBukkenInfoItem.setTeiken(null);
            }
        }

        // チームコード判定
        this.editTeamCd();
        String atsukaiTeamCode = s008Bean.getAtsukaiTeamCode();
        String atsukaiCCode = s008Bean.getAtsukaiCCode();

        syuGeBukkenInfoItem.setAtsukaiTeamCode(atsukaiTeamCode);
        syuGeBukkenInfoItem.setAtsukaiCCode(atsukaiCCode);
        // 販売チーム
        syuGeBukkenInfoItem.setEgTeamCd(s008Bean.getEgTeamCd());
        syuGeBukkenInfoItem.setHbCCd(s008Bean.getHbCCd());
        syuGeBukkenInfoItem.setHbSCd(s008Bean.getHbSCd());
        syuGeBukkenInfoItem.setHbECd(s008Bean.getHbECd());
        // 製造チーム
        syuGeBukkenInfoItem.setSzTeamCd(s008Bean.getSzTeamCd());
        syuGeBukkenInfoItem.setSzCCd(s008Bean.getSzCCd());
        syuGeBukkenInfoItem.setSzSCd(s008Bean.getSzSCd());
        syuGeBukkenInfoItem.setSzECd(s008Bean.getSzECd());

        syuGeBukkenInfoItem.setGyotai(s008Bean.getGyotai()); // 業態
        syuGeBukkenInfoItem.setEigJobgrCd(s008Bean.getEigJobgrCd()); // 営業JobGｒ
        syuGeBukkenInfoItem.setEigJobgrNm(s008Bean.getEigJobgrNm());
        syuGeBukkenInfoItem.setSyuJobgrCd(s008Bean.getSyuJobgrCd()); // 収益JobGｒ
        syuGeBukkenInfoItem.setSyuJobgrNm(s008Bean.getSyuJobgrNm());
        syuGeBukkenInfoItem.setHatJyuchuDate(convDate(s008Bean.getHatJyuchuDateI())); // 受注年月
        syuGeBukkenInfoItem.setHatSyukkaNichigen(convDate(s008Bean.getHatSyukkaNichigenI())); // 出荷日限
        syuGeBukkenInfoItem.setHatUriageYotei(convDate(s008Bean.getUriageEndI())); // 売上予定
        syuGeBukkenInfoItem.setHatKaisyuYotei(convDate(s008Bean.getHatKaisyuYoteiI())); // 回収予定
        syuGeBukkenInfoItem.setKouOtsuKbn(s008Bean.getKouOtsuKbn()); // 甲乙
// 2018A 1198
//        syuGeBukkenInfoItem.setIspDivisionNm(s008Bean.getIspDivisionNm()); // ISP事業部
//        syuGeBukkenInfoItem.setIspKbn(s008Bean.getIspKbn()); // ISP区分
        syuGeBukkenInfoItem.setIspRelateId(s008Bean.getIspRelateId()); // 関連ISP案件
        //syuGeBukkenInfoItem.setJyuchuEnd(convDate(s008Bean.getHatJyuchuDateI()));
        //syuGeBukkenInfoItem.setUriageEnd(convDate(s008Bean.getUriageEndI()));
        syuGeBukkenInfoItem.setSaikeisanEnddate(s008Bean.getUriageEndI().replaceAll("/", "")); // 再計算の対象最終月
    }

    /**
     * SYU_KI_SP_TOTAL_TBLの新規登録(案件一覧のデフォルト条件で、このテーブルを参照するために作成する)
     */
    private void createSpTable() {
        Date now = sysdateFacade.getSysdate();

        SyuKiSpTotalTbl syuKiSpTotalTbl = new SyuKiSpTotalTbl();
        syuKiSpTotalTbl.setAnkenId(s008Bean.getAnkenId());
        syuKiSpTotalTbl.setRirekiId(Integer.parseInt(s008Bean.getRirekiId()));
        syuKiSpTotalTbl.setDataKbn("M");
        syuKiSpTotalTbl.setSyuekiYm(StringUtils.replace(s008Bean.getUriageEndI(), "/", ""));
        syuKiSpTotalTbl.setCreatedAt(now);
        syuKiSpTotalTbl.setCreatedBy(loginUserInfo.getUserId());
        syuKiSpTotalTbl.setUpdatedAt(now);
        syuKiSpTotalTbl.setUpdatedBy(loginUserInfo.getUserId());

        syuKiSpTotalTblFacade.create(syuKiSpTotalTbl);
    }

    /**
     * デフォルト受注通知の通貨コードを取得
     */
    private String getDefaultCurrencyCode() {
        return ConstantString.currencyCodeEn;
    }

    /**
     * 案件で利用可能な最優先の通貨コードを受注通知の登録済データより取得
     */
    private String getPriorityCurrencyCode() {
        Map<String, Object> condition = getBaseCondition();
        String currencyCode = syuKiSpCurTblFacade.selectCurrencyCode(condition);
        logger.info("PriorityCurrencyCode=[{}]", currencyCode);
        
        if (StringUtils.isEmpty(currencyCode)) {
            currencyCode = getDefaultCurrencyCode();
            logger.info("DefaultCurrencyCode=[{}]", currencyCode);
        }
        
        return currencyCode;
    }

    /**
     * 新規白地案件作成用
     * デフォルトの仮受注通知データ(SYU_KI_SP_CUR_TBLに連番0001,通貨JPY)の新規登録
     * ((原子力)データの場合、これを作成しておかないと支障があるため実施)
     * ((原子力)では売上NETと受注通知の紐づけが必須になる)
     */
    private void createKariKeiyakuData() {
        Date now = sysdateFacade.getSysdate();
        String currencyCode = getDefaultCurrencyCode();

        String currencyCodeSeq = "";
        SyuCurMst syuCurMstEntity = syuCurMstFacade.findPk(currencyCode);
        if (syuCurMstEntity != null) {
            currencyCodeSeq = syuCurMstEntity.getDispSeq();
        }

        SyuKiSpCurTbl syuKiSpCurTblEntity = new SyuKiSpCurTbl();
        syuKiSpCurTblEntity.setAnkenId(s008Bean.getAnkenId());
        syuKiSpCurTblEntity.setRirekiId(Integer.parseInt(s008Bean.getRirekiId()));
        syuKiSpCurTblEntity.setCurrencyCode(ConstantString.currencyCodeEn);
        syuKiSpCurTblEntity.setCurrencyCodeSeq(currencyCodeSeq);
        syuKiSpCurTblEntity.setRenban(ConstantString.finalRenban);
        syuKiSpCurTblEntity.setRenbanSeq(new BigDecimal(ConstantString.finalRenbanSeq));
        syuKiSpCurTblEntity.setCreatedAt(now);
        syuKiSpCurTblEntity.setCreatedBy(loginUserInfo.getUserId());
        syuKiSpCurTblEntity.setUpdatedAt(now);
        syuKiSpCurTblEntity.setUpdatedBy(loginUserInfo.getUserId());
        syuKiSpCurTblFacade.create(syuKiSpCurTblEntity);
    }

    /**
     * 関連ISP更新 ISP区分が1：ISP分割の場合、関連ISPのISP区分も1にする
     */
    private void updateIspAnken() {
        if (StringUtils.isBlank(s008Bean.getIspKbn())) {
            return;
        }
        if (!s008Bean.getIspKbn().equals(ConstantString.ispKbn1)) {
            return;
        }

        Map<String, Object> condition = new HashMap<>();
        condition.put("ankenId", s008Bean.getIspRelateId());
        condition.put("rirekiId", ConstantString.geRirekiId);
        SyuGeBukkenInfoTbl ankenEntity = s008Facade.getIspAnkenId(condition);
        if (ankenEntity != null) {
            String ispKbn = StringUtils.defaultString(ankenEntity.getIspKbn());
            if (!ispKbn.equals(ConstantString.ispKbn1)) {
                ankenEntity.setIspKbn(ConstantString.ispKbn1);
                ankenEntity.setIspRelateId(s008Bean.getIspRelateId());
                EntityUtils.setUpdatedInfo(ankenEntity, loginUserInfo.getUserId());
                s008Facade.updateIspAnkenId(ankenEntity);
            }
        }
    }

    /**
     * ポテンシャル管理更新<br>
     * ポテンシャル管理が"無"(0)の場合、各テーブルから見込大(PD),見込中(PT),見込小(PS)のデータを削除
     */
    private void updatePotentialFlg() {
        if (StringUtils.defaultString(s008Bean.getPotentialFlg(), "0").equals("0")) {
            String[] dataKbn = new String[]{"PD", "PT", "PS"};
            Map<String, Object> condition = new HashMap<>();
            condition.put("ankenId", s008Bean.getAnkenId());
            condition.put("rirekiId", s008Bean.getRirekiId());
            condition.put("dataKbn", dataKbn);

            s008Facade.deleteSyuSaSpTotalTbl(condition);
            s008Facade.deleteSyuSaSpCurTbl(condition);
            s008Facade.deleteSyuSaNetTotalTbl(condition);
            s008Facade.deleteSyuSaNetCateTbl(condition);
            s008Facade.deleteSyuSaHanCateTbl(condition);
            s008Facade.deleteSyuSaSonekiTitleTbl(condition);
            s008Facade.deleteSyuKiBikou(condition);
            s008Facade.deleteSyuSaNetItemTbl(condition);
        }
    }

    /**
     * 関連ISP案件のISP区分を戻すか否かを判断
     */
    private boolean isClearIspKbn(SyuGeBukkenInfoTbl syuGeBukkenInfoItem) {
        boolean isClear = false;

        // 変更前のISP区分・関連ISP番号
        String nowIspKbn = StringUtils.defaultString(syuGeBukkenInfoItem.getIspKbn());
        String nowIspRelateId = StringUtils.defaultString(syuGeBukkenInfoItem.getIspRelateId());
        // 変更後のISP区分・関連ISP番号
        String afterIspKbn = StringUtils.defaultString(s008Bean.getIspKbn());
        String afterIspRelateId = StringUtils.defaultString(s008Bean.getIspRelateId());

        // 更新前と更新後でISP区分が変更される場合
        if (!nowIspKbn.equals(afterIspKbn) && !ConstantString.ispKbn1.equals(afterIspKbn)) {
            // 更新後のISP区分が"ISP分割"でなくなる場合
            isClear = true;
        } else if (ConstantString.ispKbn1.equals(afterIspKbn) && !nowIspRelateId.equals(afterIspRelateId)) {
            // 関連ISP案件番号が変更される場合
            isClear = true;
        }

        return isClear;
    }

    /**
     * 更新前の関連ISP案件のISP区分を元に戻す
     */
    private void clearIspKbn(String ispClearAnkenId) throws Exception {
        logger.info("clear isp kbn ankenId=[{}]", ispClearAnkenId);
        storedProceduresService.callOffIspFlg(ispClearAnkenId, ConstantString.geRirekiId);
    }

    /**
     * SP情報登録処理をcallする。
     */
    private void callSpInfoInsert() throws Exception {
        SpInfoInsertDto dto = new SpInfoInsertDto();
        dto.setAnkenId(s008Bean.getAnkenId());
        dto.setKbn("0");
        dto.setUserId(this.loginUserInfo.getUserId());

        storedProceduresService.callSpInfoInsert(dto);

        if (dto.getStatus() != 0) {
            throw new Exception("SP情報登録処理[PACK_KI_SP_INS]でエラーが発生しました。エラーメッセージ=" + dto.getStatusMessage() + " 物件Key=" + s008Bean.getAnkenId());
        }
    }

    /**
     * 注入パターン計算処理をcallする。
     */
    private void callPatenCalc() throws Exception {
        PattenCalcDto dto = new PattenCalcDto();
        dto.setAnkenId(s008Bean.getAnkenId());
        dto.setKbn("0");
        dto.setUserId(this.loginUserInfo.getUserId());

        storedProceduresService.callPattenCalc(dto);

        if (dto.getStatus() != 0) {
            throw new Exception("注入パターン計算処理[PACK_PATTEN_CALC]でエラーが発生しました。エラーメッセージ=" + dto.getStatusMessage() + " 物件Key=" + s008Bean.getAnkenId());
        }
    }

    /**
     * 再計算処理実行
     */
    public void calc() throws Exception {
        geBukenInfoTblFacade.setSaikeisanFlg(s008Bean.getAnkenId(), (new Integer(s008Bean.getRirekiId())), "1");

        // 再計算処理を実行
        callRecalPackage();

        // 再計算FLGを解除
        geBukenInfoTblFacade.setSaikeisanFlg(s008Bean.getAnkenId(), (new Integer(s008Bean.getRirekiId())), "0");
    }

    /**
     * 再計算パッケージを呼び出し
     */
    private void callRecalPackage() throws Exception {
        // 再計算処理を実行
        storedProceduresService.callAnkenRecalAuto(s008Bean.getAnkenId(), s008Bean.getRirekiId(), "4");
    }

    /**
     * String型の年月をDate型に変換
     *
     * @param yymm
     * @return
     * @throws Exception
     */
    public Date convDate(String yymm) throws Exception {
        String dateFormat = "yyyy/MM/dd";
        Date rtnDate = null;

        if (!StringUtils.isEmpty(yymm)) {
            rtnDate = Utils.parseDate(yymm + "/01", dateFormat);
        }

        return rtnDate;
    }

    /**
     * 操作ログの登録
     *
     * @param operationCode
     * @throws Exception
     */
    public void registOperationLog() throws Exception {
        OperationLog operationLog = this.operationLogService.getOperationLog();

        String objectType = operationLogService.getObjectType(s008Bean.getProcId());

        operationLog.setOperationCode("SAVE_BUKKEN");
        operationLog.setObjectId(20);
        operationLog.setObjectType(objectType);
        operationLog.setRemarks(s008Bean.getAnkenId());

        operationLogService.insertOperationLogSearch(operationLog);
    }


    /**
     * 保存処理存在チェック
     * @throws Exception
     */
    public void existsValidation() throws Exception {
        logger.info("EidTempEditService#existsValidation");

        String message;
        Map<String, String> messages = validationInfoBean.getMessages();//new LinkedHashMap<>();
        // 検索条件
            if ("1".equals(s008Bean.getIspKbn()) && StringUtils.isNotEmpty(s008Bean.getIspRelateId())) {
                SyuGeBukkenInfoTbl ankenEntity = null;
                // 検索条件をセット
                Map<String, Object> condition = new HashMap<>();
                condition.put("ankenId", s008Bean.getIspRelateId());
                condition.put("rirekiId", s008Bean.getRirekiId());
                condition.put("rirekiFlg", s008Bean.getRirekiFlg());
                ankenEntity = s008Facade.getBukkenInfo(condition);

                if(ankenEntity==null){//念のため
                    message = "入力された関連ISP案件番号が存在していません。";
                    messages.put("ispRelateId", message);
                }else if(StringUtils.isEmpty(ankenEntity.getAnkenId())){
                    message = "入力された関連ISP案件番号が存在していません。";
                    messages.put("ispRelateId", message);
                }
            }

        // メッセージをBeanに設定
        validationInfoBean.setMessages(messages);

    }

    /**
     * 受注年月(SP)データの移動
     */
    private void moveJyuchuSpData() throws Exception {
        String moveJyuchuDate = StringUtils.replace(s008Bean.getJyuchuEnd(), "/", "");
        
        Map<String, Object> condition = getBaseCondition();
        condition.put("dataKbn", "M");
        condition.put("newSyuekiYm", moveJyuchuDate);

        // 現在勘定年月以降で最新の受注年月(SP)を取得
        String maxJyuchuYm = StringUtils.defaultString(syuKiJyuchuSpTblFacade.getMaxSyuekiYm(condition));
        logger.info("maxJyuchuYm(SP)=[{}], moveJyuchuYm(SP)=[{}]", maxJyuchuYm, moveJyuchuDate);
        
        // 案件の受注予定年月と最新の受注予定年月(SP)が同一年月であれば処理をスルーする
        if (maxJyuchuYm.equals(moveJyuchuDate)) {
            return;
        }

        // 受注年月(SP)の移動
        condition.put("syuekiYm", maxJyuchuYm);
        int count = syuKiJyuchuSpTblFacade.changeSyuekiYm(condition);
        
        // 移動可能な受注データが存在しない場合は受注データを新規登録
        if (count == 0) {
            logger.info("Empty JyuchuSp Data Insert Logic");
            String currencyCode = getPriorityCurrencyCode();  // 案件内に登録されている優先順位の高い通貨を取得
            BigDecimal rate = getInitRate(moveJyuchuDate, currencyCode);
            condition.put("currencyCode", currencyCode);
            condition.put("syuekiYm", moveJyuchuDate);
            condition.put("jyuchuRate", rate);
            condition.put("jyuchuSp", 0);
            syuKiJyuchuSpTblFacade.insertJyuchuSpRate(condition);
        }
    }
    
    /**
     * 受注年月(NET)データの移動
     */
    private void moveJyuchuNetData() throws Exception {
        String moveJyuchuDate = StringUtils.replace(s008Bean.getJyuchuEnd(), "/", "");
        
        Map<String, Object> condition = getBaseCondition();
        condition.put("dataKbn", "M");
        condition.put("newSyuekiYm", moveJyuchuDate);
        
        // 現在勘定年月以降で最新の受注年月(NET)を取得
        String maxJyuchuYm = StringUtils.defaultString(syuKiJyuchuNetTblFacade.getMaxSyuekiYm(condition));
        logger.info("maxJyuchuYm(NET)=[{}], moveJyuchuYm(NET)=[{}]", maxJyuchuYm, moveJyuchuDate);

        // 案件の受注予定年月と最新の受注予定年月(NET)が同一年月であれば処理をスルーする
        if (maxJyuchuYm.equals(moveJyuchuDate)) {
            return;
        }
        
        // 受注年月(NET)の移動
        condition.put("syuekiYm", maxJyuchuYm);
        int count = syuKiJyuchuNetTblFacade.changeSyuekiYm(condition);
        
        // 移動可能な受注データが存在しない場合は受注データを新規登録
        if (count == 0) {
            logger.info("Empty JyuchuNet Data Insert Logic");
            Map<String, Object> ikkatsuCategoryInfo = findIkkatsuCategoryInfo(ConstantString.ikkatsuCategoryCode);
            condition.put("syuekiYm", moveJyuchuDate);
            condition.put("categoryCode", ConstantString.ikkatsuCategoryCode);
            condition.put("categoryKbn1", ikkatsuCategoryInfo.get("CATEGORY_KBN1"));
            condition.put("categoryKbn2", ikkatsuCategoryInfo.get("CATEGORY_KBN2"));
            condition.put("categoryName1", ikkatsuCategoryInfo.get("CATEGORY_NAME1"));
            condition.put("categoryName2", ikkatsuCategoryInfo.get("CATEGORY_NAME2"));
            condition.put("categorySeq", ikkatsuCategoryInfo.get("CATEGORY_SEQ"));
            condition.put("jyuchuNet", 0);
            syuKiJyuchuNetTblFacade.insertJyuchuNet(condition);
        }
    }
    
    /**
     * 売上SPデータの移動
     */
    private void moveUriageSpData() throws Exception {
        String moveUriageDate = StringUtils.replace(s008Bean.getUriageEnd(), "/", "");
        
        Map<String, Object> condition = getBaseCondition();
        condition.put("dataKbn", "M");
        condition.put("newSyuekiYm", moveUriageDate);

        // 現在勘定年月以降で最新の売上年月(SP)を取得
        String maxUriageYm = syuKiSpTukiITblFacade.getMaxSyuekiYm(condition);
        logger.info("maxUriageYm(SP)=[{}], moveUriageYm(SP)=[{}]", maxUriageYm, moveUriageDate);
        
        // 案件の売上予定年月と最新の売上予定年月(SP)が同一年月であれば処理をスルーする
        if (maxUriageYm.equals(moveUriageDate)) {
            return;
        }
        
        // 売上年月(SP)の移動
        condition.put("syuekiYm", maxUriageYm);
        int count = syuKiSpTukiITblFacade.changeSyuekiYm(condition);
        
        // 移動可能な売上データが存在しない場合は売上データを新規登録
        if (count == 0) {
            logger.info("Empty UriageSp Data Insert Logic");
            String currencyCode = getPriorityCurrencyCode();  // 案件内に登録されている優先順位の高い通貨を取得
            BigDecimal rate = getInitRate(moveUriageDate, currencyCode);
            condition.put("currencyCode", currencyCode);
            condition.put("syuekiYm", moveUriageDate);
            condition.put("renban", ConstantString.finalRenban);
            condition.put("uriRate", rate);
            condition.put("uriageAmount", 0);
            syuKiSpTukiITblFacade.insertSyuKiSpTukiITbl(condition);
        }
    }
    
    /**
     * 売上NETデータの移動
     */
    private void moveUriageNetData() throws Exception {
        String moveUriageDate = StringUtils.replace(s008Bean.getUriageEnd(), "/", "");
        
        Map<String, Object> condition = getBaseCondition();
        condition.put("dataKbn", "M");
        condition.put("newSyuekiYm", moveUriageDate);
        
        // 現在勘定年月以降で最新の売上年月(NET)を取得
        String maxUriageYm = StringUtils.defaultString(syuKiNetCateTukiTblFacade.getMaxSyuekiYm(condition));
        logger.info("maxUriageYm(NET)=[{}], moveUriageYm(NET)=[{}]", maxUriageYm, moveUriageDate);
        
        // 案件の売上予定年月と最新の売上予定年月(NET)が同一年月であれば処理をスルーする
        if (maxUriageYm.equals(moveUriageDate)) {
            return;
        }

        // 売上年月(NET)の移動
        condition.put("syuekiYm", maxUriageYm);
        int count = syuKiNetCateTukiTblFacade.changeSyuekiYm(condition);
        //int count = syuKiNetCateTukiTblFacade.copySyuekiYmUriageNet(condition);
        // 移動前の売上NETデータを削除する(見込データ)
        //syuKiNetCateTukiTblFacade.deleteSyuKiNetCateTukiTbl(condition);

        // 移動可能な売上データが存在しない場合は売上データを新規登録
        if (count == 0) {
            logger.info("Empty UriageNet Data Insert Logic");
            Map<String, Object> ikkatsuCategoryInfo = findIkkatsuCategoryInfo(ConstantString.ikkatsuCategoryCode);
            condition.put("syuekiYm", moveUriageDate);
            condition.put("categoryCode", ConstantString.ikkatsuCategoryCode);
            condition.put("categoryKbn1", ikkatsuCategoryInfo.get("CATEGORY_KBN1"));
            condition.put("categoryKbn2", ikkatsuCategoryInfo.get("CATEGORY_KBN2"));
            condition.put("net", 0);
            syuKiNetCateTukiTblFacade.insertSyuKiNetCateTukiTbl(condition);
        }
    }
    
    /**
     * 売上NET(項番)データの移動
     */
    private void moveUriageNetItemData() throws Exception {
        String moveUriageDate = StringUtils.replace(s008Bean.getUriageEnd(), "/", "");
        
        Map<String, Object> condition = getBaseCondition();
        condition.put("dataKbn", "M");
        condition.put("newSyuekiYm", moveUriageDate);
        
        // 現在勘定年月以降で最新の売上年月(NET)を取得
        String maxUriageYm = StringUtils.defaultString(syuKiNetItemTukiTblFacade.getMaxSyuekiYm(condition));
        logger.info("maxUriageYm(ITEM)=[{}], moveUriageYm(ITEM)=[{}]", maxUriageYm, moveUriageDate);
        
        // 案件の売上予定年月と最新の売上予定年月(NET)が同一年月であれば処理をスルーする
        if (maxUriageYm.equals(moveUriageDate)) {
            return;
        }

        // 項番の売上月の移動(パッケージで実施)
        callSyuP7ChangeYmItemNetInfo("M", maxUriageYm, moveUriageDate, "0");
        callSyuP7ChangeYmItemNetInfoFix("M");

        // 売上年月(NET)の移動
        //condition.put("syuekiYm", maxUriageYm);
        //syuKiNetItemTukiTblFacade.changeSyuekiYm(condition);
    }
    
    /**
     * 回収年月データの移動
     */
    private void moveKaisyuTukiData() throws Exception {
        String moveKaisyuDate = StringUtils.replace(s008Bean.getKaisyuEnd(), "/", "");
        
        Map<String, Object> condition = getBaseCondition();
        condition.put("newSyuekiYm", moveKaisyuDate);
        
        // 現在勘定年月以降で最新の回収年月を取得
        String maxKaisyuYm = StringUtils.defaultString(syuKiKaisyuTblFacade.getMaxSyuekiYm(condition));
        logger.info("maxKaisyuYm=[{}], moveKaisyuYm=[{}]", maxKaisyuYm, moveKaisyuDate);
        
        // 案件の回収月と最新の回収月が同一年月であれば処理をスルーする
        if (maxKaisyuYm.equals(moveKaisyuDate)) {
            return;
        }

        condition.put("syuekiYm", maxKaisyuYm);
        
        // 回収年月の移動(見込データ)
        condition.put("dataKbn", "M");
        int mikomiMoveCount = syuKiKaisyuTblFacade.copyKaisyuYm(condition);
        // 回収年月の移動(実績データ)
        condition.put("dataKbn", "J");
        int jissekiCount  = syuKiKaisyuTblFacade.copyKaisyuYm(condition);

        // 移動前の回収データを削除する(見込データ)
        condition.put("dataKbn", "M");
        syuKiKaisyuTblFacade.deleteSyuKiKaisyuTbl(condition);
        // 移動前の回収データを削除する(実績データ)
        condition.put("dataKbn", "J");
        syuKiKaisyuTblFacade.deleteSyuKiKaisyuTbl(condition);
        
        // 移動可能な回収データが存在しない場合は回収データを新規登録
        if (mikomiMoveCount == 0 && jissekiCount == 0) {
            logger.info("Empty Kaisyu Data Insert Logic");
            String currencyCode = getPriorityCurrencyCode();  // 案件内に登録されている優先順位の高い通貨を取得
            String zeiKbn;
            if (ConstantString.currencyCodeEn.equals(currencyCode)) {
                // 円貨通貨の場合は、税区分は税マスタのデフォルト値を登録
                SyuZeikbnMst zeiKbnMst = syuZeikbnMstFacade.findDefaultZeiKbnMst();
                zeiKbn = zeiKbnMst.getZeiKbn();
            } else {
                // 外貨通貨の場合は、税区分は輸出免税をデフォルト設定
                zeiKbn = ConstantString.menzeiZeiKbn;
            }

            condition.remove("moveSyuekiYm");
            condition.put("dataKbn", "M");
            condition.put("currencyCode", currencyCode);
            condition.put("syukeiYm", moveKaisyuDate);
            condition.put("kinsyuKbn", ConstantString.kaisyuKinsyuGenkin);
            condition.put("kaisyuKbn", ConstantString.kaisyuKbnNormal);
            condition.put("zeiKbn", zeiKbn);
            condition.put("kaisyuAmount", 0);
            condition.put("kaisyuEnkaAmount", 0);
            syuKiKaisyuTblFacade.entrySyuKiKaisyuTbl(condition, true);
            
            condition.put("dataKbn", "J");
            syuKiKaisyuTblFacade.entrySyuKiKaisyuTbl(condition, true);
        }
    }
    
    /**
     * 一括カテゴリNET情報をセット
     */
    private Map<String, Object> findIkkatsuCategoryInfo(String categoryCode) throws Exception {
        SqlFile sqlFile = new SqlFile();
        String sqlFilePath = "/sql/categoryMst/selectCategoryMstFromCode.sql";
        // 条件設定
        Map<String, Object> conditonCateMst = new HashMap<>();
        conditonCateMst.put("categoryCode", categoryCode);
        // SQL文を取得
        String sqlString = sqlFile.getSqlString(sqlFilePath, conditonCateMst);
        Object[] params = sqlFile.getSqlParams(sqlFilePath, conditonCateMst);
        // 情報を取得
        List<Map<String, Object>> ikkatsuCategoryInfoList = dbUtilsExecutor.dbUtilsGetSqlList(em, sqlString, params);

        if (ikkatsuCategoryInfoList != null && !ikkatsuCategoryInfoList.isEmpty()) {
            return ikkatsuCategoryInfoList.get(0);
        } else {
            return null;
        }
    }

    /**
     * 基本の検索条件を取得
     */
    public Map<String, Object> getBaseCondition() {
        Map<String, Object> condition = new HashMap<>();
        condition.put("ankenId", s008Bean.getAnkenId());
        condition.put("rirekiId", Integer.parseInt(s008Bean.getRirekiId()));
        condition.put("kanjyoYm", StringUtils.replace(s008Bean.getNowYm(), "/", ""));
        condition.put("userId", loginUserInfo.getUserId());
        condition.put("updatedBy", loginUserInfo.getUserId());
        return condition;
    }
    
    /**
     * 項番の見込年月変更用のパッケージを実行
     * @param oSyuekiYm 変更前の売上年月
     * @param nSyuekiYm 変更後の売上
     */
    private void callSyuP7ChangeYmItemNetInfo(String dataKbn, String oSyuekiYm, String nSyuekiYm, String delFlg) throws Exception {
        SyuP7ChangeYmItemNetInfoDto dto = new SyuP7ChangeYmItemNetInfoDto();
        dto.setAnkenId(s008Bean.getAnkenId());
        dto.setRirekiId(s008Bean.getRirekiId());
        dto.setDataKbn(dataKbn);
        dto.setOSyuekiYm(StringUtils.replace(oSyuekiYm, "/", ""));
        dto.setNSyuekiYm(StringUtils.replace(nSyuekiYm, "/", ""));
        dto.setDelFlg(delFlg);
        
        storedProceduresService.callSyuP7ChangeYmItemNetInfo(dto);
        logger.info("callSyuP7ChangeYmItemNetInfo errFlg=[{}] errMsg=[{}]", dto.getErrFlg(), dto.getErrMsg());
        
        if (!"0".equals(dto.getErrFlg())) {
            throw new Exception("項番の売上年月変更パッケージ[" + dto.getExeProcedureName() + "]でエラーが発生しました。ankenId=" + s008Bean.getAnkenId() + " rirekiId=" + s008Bean.getRirekiId() + " dataKbn=" + dto.getDataKbn() + " oSyuekiYm=" + oSyuekiYm + " nSyuekiYm=" + nSyuekiYm);
        }
    }
    
    /**
     * 項番の見込年月変更用のパッケージを実行
     * @param oSyuekiYm 変更前の売上年月
     * @param nSyuekiYm 変更後の売上
     */
    private void callSyuP7ChangeYmItemNetInfoFix(String dataKbn) throws Exception {
        SyuP7ChangeYmItemNetInfoDto dto = new SyuP7ChangeYmItemNetInfoDto();
        dto.setAnkenId(s008Bean.getAnkenId());
        dto.setRirekiId(s008Bean.getRirekiId());
        dto.setDataKbn(dataKbn);
        
        storedProceduresService.callSyuP7ChangeYmItemNetInfoFix(dto);
        logger.info("callSyuP7ChangeYmItemNetInfoFix errFlg=[{}] errMsg=[{}]", dto.getErrFlg(), dto.getErrMsg());
        
        if (!"0".equals(dto.getErrFlg())) {
            throw new Exception("項番の売上年月変更確定パッケージ[" + dto.getExeProcedureName() + "]でエラーが発生しました。ankenId=" + s008Bean.getAnkenId() + " rirekiId=" + s008Bean.getRirekiId() + " dataKbn=" + dto.getDataKbn());
        }
    }

    /**
     * 不要な項番の見込月データ(全てのNETがNULLの月データ)を削除
     * ※これを削除しておかないと、案件詳細画面の[(収益)売上年月]が分割売ではないにも関わらず分割売上とみなされてしまい変更できない支障が発生するために処置を行っておく
     */
    private void deketeMikomiTukiEmptyNet() {
        String kanjyoYm = kanjyoMstFacade.getNowKanjoDate(s008Bean.getSalesClass());
        
        Map<String, Object> condition = new HashMap<>();
        condition.put("ankenId", s008Bean.getAnkenId());
        condition.put("rirekiId", s008Bean.getRirekiId());
        condition.put("dataKbn", "M");
        condition.put("kanjyoYm", kanjyoYm);
        
        syuKiNetItemTukiTblFacade.deleteNetItem(condition);
    }
    
    /**
     * 受注SPや売上SPの初期セットするレートを取得
     */
    private BigDecimal getInitRate(String syuekiYm, String currencyCode) throws SQLException {
        BigDecimal rate;
        if (ConstantString.currencyCodeEn.equals(currencyCode)) {
            // 通貨JPYはレート1固定とする。
            rate = new BigDecimal("1");
        } else {
            // 他通貨はレートマスタよりレート検索(FUNCTION利用)
            rate = storedProceduresService.getMikomiCurrencyRate(syuekiYm, currencyCode, s008Bean.getDivisionCode());
        }
        return rate;
    }
}
