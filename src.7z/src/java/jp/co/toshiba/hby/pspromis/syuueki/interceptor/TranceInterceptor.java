package jp.co.toshiba.hby.pspromis.syuueki.interceptor;

import javax.interceptor.AroundInvoke;
import javax.interceptor.InvocationContext;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * トレースを記憶するinterceptor
 * @author (NPC)S.Ibayashi
 */
public class TranceInterceptor {
    /**
     * ロガー
     */
    public static final Logger logger = LoggerFactory.getLogger(TranceInterceptor.class);

    @AroundInvoke
    public Object trace(InvocationContext inv) throws Exception {
        
        String className = inv.getTarget().getClass().getName();
        String methodName = inv.getMethod().getName();

        long startTime = 0;

        logger.info("start processName=" + className + "#" + methodName);
        try {
            startTime = System.currentTimeMillis();
            return inv.proceed();
            
        } catch (Throwable e) {
            RuntimeException rte = e instanceof RuntimeException ? (RuntimeException)e : new RuntimeException(e);
            throw rte;
        } finally {
            long entTime = System.currentTimeMillis();
            logger.info("end processName=" + className + "#" + methodName + " processTime=" + (entTime - startTime) + "msec");
        }
    }
}
