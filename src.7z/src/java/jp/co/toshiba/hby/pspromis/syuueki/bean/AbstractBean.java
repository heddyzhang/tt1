package jp.co.toshiba.hby.pspromis.syuueki.bean;

import java.util.Date;
import javax.enterprise.context.RequestScoped;
import javax.inject.Named;
import jp.co.toshiba.hby.pspromis.syuueki.enums.ScreenMode;
import lombok.Getter;
import lombok.Setter;
import org.apache.commons.lang3.StringUtils;

/**
 *
 * @author ibayashi
 */
@Named(value = "abstractBean")
@RequestScoped
@Getter
@Setter
public abstract class AbstractBean {

    /**
     * 検索条件・表示/非表示FLG
     */
    private String conditionFlg = "1";

    /**
     * 物件Key
     */
    private String ankenId;

    private String ankenMatomeId;

    /**
     * 履歴Key
     */
    private String rirekiId = "0";

    /**
     * 履歴Flg
     */
    private String rirekiFlg;

    /**
     * 期間(From)
     */
    private String kikanForm;

    /**
     * 期間(To)
     */
    //private String kikanTo;
    /**
     * 勘定月
     */
    private Date kanjoDate;

    /**
     * 参照/編集モード
     */
    private String screenMode = ScreenMode.READ.getValue();

    public String getConditionFlg() {
        return conditionFlg;
    }

    public void setConditionFlg(String conditionFlg) {
        this.conditionFlg = conditionFlg;
    }

    public String getAnkenId() {
        return ankenId;
    }

    public void setAnkenId(String ankenId) {
        this.ankenId = ankenId;
    }

    public String getAnkenMatomeId() {
        return ankenMatomeId;
    }

    public void setAnkenMatomeId(String ankenMatomeId) {
        this.ankenMatomeId = ankenMatomeId;
    }

    public String getRirekiId() {
        return rirekiId;
    }

    public void setRirekiId(String rirekiId) {
        // 履歴idはNUMBERなので、数値以外は設定不許可にする。
        if (StringUtils.isNumeric(rirekiId)) {
            this.rirekiId = rirekiId;
        }
    }

    public String getRirekiFlg() {
        return rirekiFlg;
    }

    public void setRirekiFlg(String rirekiFlg) {
        this.rirekiFlg = rirekiFlg;
    }

    public String getKikanForm() {
        return kikanForm;
    }

    public void setKikanForm(String kikanForm) {
        this.kikanForm = kikanForm;
    }

    /*
    public String getKikanTo() {
        return kikanTo;
    }

    public void setKikanTo(String kikanTo) {
        this.kikanTo = kikanTo;
    }
     */
    public Date getKanjoDate() {
        return kanjoDate;
    }

    public void setKanjoDate(Date kanjoDate) {
        this.kanjoDate = kanjoDate;
    }

    /**
     * 通貨がJPYを取得
     *
     * @return
     */
    public String getCurrencyCodeEn() {
        return jp.co.toshiba.hby.pspromis.syuueki.util.ConstantString.currencyCodeEn;
    }

    /**
     * 画面が参照モードであるかを確認
     */
    public boolean isRead() {
        return ScreenMode.READ.getValue().equals(screenMode);
    }

    /**
     * 画面が編集ードであるかを確認
     */
    public boolean isEdit() {
        return ScreenMode.EDIT.getValue().equals(screenMode);
    }
}
