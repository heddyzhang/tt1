package jp.co.toshiba.hby.pspromis.syuueki.jdbc;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Map;
import javax.persistence.EntityManager;
import jp.co.toshiba.hby.pspromis.common.util.StringUtil;
import jp.co.toshiba.hby.pspromis.common.jdbc.SqlExecutor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * jdbc ResultSetを取り扱うクラス<br/>
 * 大量データ出力を取り扱う場合に利用(それ以外では利用しないこと)
 * @author (NPC)S.Ibayashi
 */
public class ResultSetManeger {
    private static final Logger logger = LoggerFactory.getLogger(ResultSetManeger.class);

    private SqlExecutor sqlExecuor;

    /**
     * コンストラクタ
     * @param sqlExecuor
     */
    public ResultSetManeger(SqlExecutor sqlExecuor) {
        this.sqlExecuor = sqlExecuor;
    }

    /**
     * コンストラクタ
     * @param sqlExecuor
     */
    public ResultSetManeger() {
    }
    
    /**
     * 指定SQLファイルを実行して、結果setをjava.sql.ResultSetで取得
     * @param entityManager
     * @param sql
     * @param params
     * @return
     * @throws Exception 
     */
    public ResultSet getResultSet(EntityManager entityManager, String sql, Object params)
    throws Exception {

        java.sql.Connection conn = entityManager.unwrap(java.sql.Connection.class);
        logger.info("ResultSetManeger#connection hash=" + conn.hashCode());

        SqlFile sqlFile = new SqlFile();
        String sqlString = sqlFile.getSqlString(sql, params);
        Object[] paramsAry = sqlFile.getSqlParams(sql, params);
 
        PreparedStatement pstmt = null;
        ResultSet rset = null;
        int fatchSize = 1000;

        try {
            logger.info("ResultSetManeger#pstm sql=" + sqlString);
            pstmt = conn.prepareStatement(sqlString);
            logger.info("ResultSetManeger#pstmt=" + pstmt);
            pstmt.setFetchSize(fatchSize);
            logger.info("ResultSetManeger#changeFetchSize=" + fatchSize);
            
            StringBuilder paramString = new StringBuilder();
            boolean isFirst = true;
            paramString.append("[");
            for (int i = 0; i < paramsAry.length; i++) {
                if (paramsAry[i] == null) {
                    pstmt.setObject(i + 1, null);
                } else {
                    pstmt.setObject(i + 1, paramsAry[i]);
                }
                
                if (!isFirst) {
                    paramString.append(", ");
                }
                paramString.append(paramsAry[i]);
                isFirst = false;
            }
            paramString.append("]");
            logger.info("SQL Parameters=" + paramString);

            long startTime = System.currentTimeMillis();
            rset = pstmt.executeQuery();
            long entTime = System.currentTimeMillis();
            
            logger.info("ResultSetManeger#getResultSet end sql processTime=" + (entTime - startTime) + "msec");

            return rset;
        } catch(Exception e) {
            close(rset);
            throw e;
        }
    }

    /**
     * 文字化け対策
     */
    private String replaceString(String value) {
        if (StringUtil.isEmpty(value)) {
            return value;
        }
        return value.replace('\u301c', '\uff5e');
    }

    /**
     * ResultSetから指定keyの値を取得(Object)
     * @param rset
     * @param key
     * @return 
     */
    public Object getResultSetObjValue(ResultSet rset, String key) {
        if (rset == null) {
            return null;
        }
        Object value = null;
        try {
            value = rset.getObject(key);
            if (value instanceof String) {
                value = replaceString((String)value);
            }
        } catch (SQLException e) {}
        return value;
    }

    /**
     * ResultSetから指定keyの値を取得(String)
     * @param rset
     * @param key
     * @return 
     */
    public String getResultSetValue(ResultSet rset, String key) {
        if (rset == null) {
            return null;
        }
        String value = null;
        try {
            value = rset.getString(key);
            value = replaceString(value);
        } catch (SQLException e) {}
        return value;
    }

    /**
     * ResultSetの現在行よりMapを取得
     * Mapは引数で指定したインスタンスを利用
     * @param baseMap resultSetの現在行データを詰め込むMap
     * @param rset 現在行のresultSet(予めfatech(next)しておくこと)
     * @throws SQLException
     */
    public void setResultMap(Map<String, Object> baseMap, ResultSet rset) throws SQLException {
        if (baseMap == null) {
            return;
        }
        
        ResultSetMetaData md = rset.getMetaData();
        int maxCol = md.getColumnCount();
        
        baseMap.clear();
        for (int i=1; i<=maxCol; i++) {
            String colName = md.getColumnLabel(i);
            Object colVal= getResultSetObjValue(rset, colName);

            if (colName == null) {
                continue;
            } if (colVal instanceof String) {
                if (colName.equals("")) {
                    continue;
                }
            }

            baseMap.put(colName, colVal);
        }
    }

    /**
     * close処理
     * @param rset
     */
    public void close(ResultSet rset) {
        Statement pstmt = null;
        //java.sql.Connection conn = null;
        
        // ResultSet close
        try {
            if (rset != null) {
                pstmt = rset.getStatement();
                rset.close();
                logger.info("ResultSetManeger#ResultSet close");
            }
        } catch (SQLException e){}

        // PreparedStatement close
        try {
            if (pstmt != null) {
                pstmt.close();
                logger.info("ResultSetManeger#Statement close");
            }
        } catch (SQLException e){}
    }
}
