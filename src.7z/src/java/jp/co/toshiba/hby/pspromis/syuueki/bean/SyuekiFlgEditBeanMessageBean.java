package jp.co.toshiba.hby.pspromis.syuueki.bean;

import java.io.Serializable;
import java.util.List;
import java.util.ArrayList;
import javax.enterprise.context.SessionScoped;
import javax.inject.Named;
import jp.co.toshiba.hby.pspromis.syuueki.dto.SyuekiFlgMessageDto;
import lombok.Getter;
import lombok.Setter;

/**
 *
 * @author ibayashi
 */
@Named(value = "syuekiFlgEditBeanMessageBean")
@SessionScoped
@Getter @Setter
public class SyuekiFlgEditBeanMessageBean implements Serializable {

    private List<SyuekiFlgMessageDto> messageList;

    public void clear() {
        messageList = new ArrayList();
    }
    
    public void setMessageData(SyuekiFlgMessageDto messageDto) {
        if (messageList == null) {
            clear();
        }
        messageList.add(messageDto);
    }
}
