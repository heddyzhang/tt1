/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package jp.co.toshiba.hby.pspromis.syuueki.service.download;

import javax.ejb.Stateless;
import javax.enterprise.inject.New;
import javax.inject.Inject;
import javax.interceptor.Interceptors;
import jp.co.toshiba.hby.pspromis.common.util.StringUtil;
import jp.co.toshiba.hby.pspromis.syuueki.interceptor.TranceInterceptor;

/**
 *
 * @author ibayashi
 */
@Stateless
@Interceptors({TranceInterceptor.class})
public class DownloadBaseService {

    @Inject @New(jp.co.toshiba.hby.pspromis.syuueki.service.download.AnkenListService.class)
    private DownloadIfc ankenListService;

    @Inject @New(jp.co.toshiba.hby.pspromis.syuueki.service.download.JyuchuZanListService.class)
    private DownloadIfc jyuchuZanListService;

    @Inject @New(jp.co.toshiba.hby.pspromis.syuueki.service.download.SummaryListService.class)
    private DownloadIfc summaryListService;

    @Inject @New(jp.co.toshiba.hby.pspromis.syuueki.service.download.AnkenGaikaListService.class)
    private DownloadIfc ankenGaikaListService;

    public DownloadIfc serviceFactory(String outPutKbn) {
        return serviceFactory(outPutKbn, "");
    }

    public DownloadIfc serviceFactory(String outPutKbn, String tenkaiKbn) {
        if ("1".equals(outPutKbn)) {
            if ("G".equals(tenkaiKbn)) {
                return ankenGaikaListService;
            } else {
                return ankenListService;
            }
        } else if ("2".equals(outPutKbn)) {
            return summaryListService;
        } else if ("3".equals(outPutKbn)) {
            return jyuchuZanListService;
        }
        return null;
    }

}
