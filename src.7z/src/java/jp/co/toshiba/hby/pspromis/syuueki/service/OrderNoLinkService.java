package jp.co.toshiba.hby.pspromis.syuueki.service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.ejb.Stateless;
import javax.inject.Inject;
import javax.interceptor.Interceptors;
import jp.co.toshiba.hby.pspromis.common.exception.PspRunTimeExceotion;
import jp.co.toshiba.hby.pspromis.syuueki.bean.OrderNoLinkBean;
import jp.co.toshiba.hby.pspromis.syuueki.entity.SyuGeBukkenInfoTbl;
import jp.co.toshiba.hby.pspromis.syuueki.enums.Label;
import jp.co.toshiba.hby.pspromis.syuueki.facade.SyuGeBukenInfoTblFacade;
import jp.co.toshiba.hby.pspromis.syuueki.interceptor.TranceInterceptor;
import jp.co.toshiba.hby.pspromis.syuueki.util.LoginUserInfo;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 *
 * @author watabe
 */
@Stateless
@Interceptors({TranceInterceptor.class})
public class OrderNoLinkService {
    
    private static final Logger logger = LoggerFactory.getLogger(OrderNoLinkService.class);

    @Inject
    private SyuGeBukenInfoTblFacade syuGeBukenInfoTblFacade;
    
    @Inject
    private LoginUserInfo loginUserInfo;

    @Inject
    private OrderNoLinkBean orderNoLinkBean; 

    public void getOrderNoList(){
        //Facadeから渡されたlistを一件に絞って、OrderNoとdcAnkenNameをBeanに格納する処理を入れる

        String[] divisionCodes = loginUserInfo.getJobGrSyokusyuArrayInfo("division");
        //SyuGeBukkenInfoのエンティティ
        List<SyuGeBukkenInfoTbl> bukkenList= syuGeBukenInfoTblFacade.getOrderNoLink(orderNoLinkBean.getOrderNo(), Integer.parseInt(orderNoLinkBean.getRirekiId()), divisionCodes);
        //listにデータが入っていなかったときのエラー表示
        String errorMessage = Label.errorNoAnkenDate.getLabel();
        if(bukkenList.isEmpty()){
            throw new PspRunTimeExceotion(errorMessage);
        }

        SyuGeBukkenInfoTbl bukkenEntity = bukkenList.get(0);   
        Map<String, Object> condition = new HashMap<>();
        condition.put("rirekiFlg", null);
        condition.put("rirekiId", bukkenEntity.getRirekiId());
        condition.put("ankenFlg", bukkenEntity.getAnkenFlg());
        condition.put("ankenId", bukkenEntity.getAnkenId());

        String mitumoriNo = syuGeBukenInfoTblFacade.findMitumoriNo(condition);

        //注番
        orderNoLinkBean.setOrderNo(bukkenEntity.getOrderNo());
        //案件番号
        orderNoLinkBean.setAnkenId(bukkenEntity.getAnkenId());
        //見積番号
        orderNoLinkBean.setMitumoriNo(mitumoriNo);
        //プラントコード
        orderNoLinkBean.setPlantCode(bukkenEntity.getPlantCode());
        //案件名称
        orderNoLinkBean.setAnkenName(bukkenEntity.getAnkenName());
        orderNoLinkBean.setSalesClass(bukkenEntity.getSalesClass());
        orderNoLinkBean.setAnkenFlg(bukkenEntity.getAnkenFlg());
        orderNoLinkBean.setAnkenRev(String.valueOf(bukkenEntity.getAnkenRev()));
    }

}
