/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package jp.co.toshiba.hby.pspromis.syuueki.util;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.math.BigDecimal;
import java.text.DateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import org.apache.commons.lang3.StringUtils;
//import org.apache.poi.hssf.usermodel.Sheet;
//import org.apache.poi.hssf.usermodel.Row;
//import org.apache.poi.hssf.usermodel.Cell;
import org.apache.poi.hssf.usermodel.HSSFDateUtil;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.apache.poi.ss.formula.FormulaParser;
import org.apache.poi.ss.formula.FormulaRenderer;
import org.apache.poi.ss.formula.FormulaType;
import org.apache.poi.ss.formula.ptg.AreaPtg;
import org.apache.poi.ss.formula.ptg.Ptg;
import org.apache.poi.ss.formula.ptg.RefPtgBase;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.CellValue;
import org.apache.poi.ss.usermodel.CreationHelper;
import org.apache.poi.ss.usermodel.DateUtil;
import org.apache.poi.ss.usermodel.FormulaEvaluator;
import org.apache.poi.ss.usermodel.Name;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.apache.poi.ss.util.AreaReference;
import org.apache.poi.ss.util.CellRangeAddress;
import org.apache.poi.ss.util.CellReference;
import org.apache.poi.xssf.usermodel.XSSFEvaluationWorkbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.apache.poi.xssf.streaming.SXSSFWorkbook;

/**
 * Excelデータ読み込み(poi) ユーティリティ
 *
 * @author ibayashi
 */
public class PoiUtil {

    /**
     * 既存のExcelワークブックを読み込み
     *
     * @param file 読み込みするファイル(java.io.File)
     * @return Excelワークブック(org.apache.poi.ss.usermodel.Workbook)
     * @throws java.io.FileNotFoundException
     * @throws org.apache.poi.openxml4j.exceptions.InvalidFormatException
     */
    public static Workbook getWorkbook(File file) throws FileNotFoundException, IOException, InvalidFormatException {
        try (InputStream in = new FileInputStream(file)) {
            Workbook book = getWorkbook(in);
            return book;
        } catch (Exception e) {
            throw e;
        }
    }

    public static Workbook getWorkbook(InputStream in) throws FileNotFoundException, IOException, InvalidFormatException {
        Workbook book = WorkbookFactory.create(in);
        return book;
    }

    public static Workbook getSXSSFWorkbook(File file) throws FileNotFoundException, IOException, InvalidFormatException {
        try (InputStream in = new FileInputStream(file)) {
            XSSFWorkbook xssfWorkbook = new XSSFWorkbook(in);
            Workbook book = new SXSSFWorkbook(xssfWorkbook);
            return book;
        } catch (Exception e) {
            throw e;
        }
    }

    /**
     * 既存のExcelワークブックを読み込み
     *
     * @param file 読み込みするファイル(java.io.File)
     * @return Excelワークブック(org.apache.poi.ss.usermodel.Workbook)
     * @throws java.io.FileNotFoundException
     * @throws org.apache.poi.openxml4j.exceptions.InvalidFormatException
     */
    public static HSSFWorkbook getHSSFWorkbook(File file) throws FileNotFoundException, IOException, InvalidFormatException {
        InputStream in = new FileInputStream(file);
        return getHSSFWorkbook(in);
    }

    public static HSSFWorkbook getHSSFWorkbook(InputStream in) throws FileNotFoundException, IOException, InvalidFormatException {
        HSSFWorkbook book = new HSSFWorkbook(in);
        return book;
    }

    /**
     * 指定行、列位置のCellオブジェクトを取得 (rowがnullの場合はnull,cellがnullの場合はオブジェクトを新規作成して取得)
     *
     * @param row
     * @param cellNum
     * @return
     */
    public static Cell getCell(Row row, int cellNum) {
        if (row == null) {
            return null;
        }

        //HSSFCell cell = row.getCell(cellNum);
        Cell cell = row.getCell(cellNum);
        if (cell == null) {
            cell = row.createCell(cellNum);
        }

        return cell;
    }

    /**
     * 指定WorkSheet,行位置,列位置のCellオブジェクトを取得
     *
     * @param sheet
     * @param rowNum
     * @param cellNum
     * @return
     */
    public static Cell getCell(Sheet sheet, int rowNum, int cellNum) {
        Row row = getRow(sheet, rowNum, true);
        Cell cell = getCell(row, cellNum);
        return cell;
    }

    /**
     * 指定WorkSheet、行位置のRowオブジェクトを取得 (rowがnullの場合はオブジェクトを新規作成して取得)
     *
     * @param sheet
     * @param rowNum
     * @param isCreate 指定行がnullの場合、行を作成して戻すか(true:作成する false:作成せずnullを戻す)
     * @return
     */
    public static Row getRow(Sheet sheet, int rowNum, boolean isCreate) {
        Row row = sheet.getRow(rowNum);
        if (row == null) {
            if (isCreate) {
                row = sheet.createRow(rowNum);
            }
        }
        return row;
    }

    /**
     * 指定WorkSheet、行位置のRowオブジェクトを取得 (rowがnullの場合はnullを戻す)
     *
     * @param sheet
     * @param rowNum
     * @return
     */
    public static Row getRow(Sheet sheet, int rowNum) {
        Row row = getRow(sheet, rowNum, false);
        return row;
    }

    /**
     * 指定行、列位置のセルの値を取得
     *
     * @param row
     * @param int cellNum
     * @return
     */
    public static Object getCellValue(Row row, int cellNum) {
        Cell cell = getCell(row, cellNum);
        Object value = getCellValue(cell);
        return value;
    }

    /**
     * cellの値を取得
     *
     * @param cell
     * @return
     */
    public static Object getCellValue(Cell cell) {
        switch (cell.getCellType()) {
            case Cell.CELL_TYPE_BLANK:
                return "";

            case Cell.CELL_TYPE_BOOLEAN:
                return cell.getBooleanCellValue();

            case Cell.CELL_TYPE_ERROR:
                return null;

            case Cell.CELL_TYPE_FORMULA:
                return getStringFormulaValue(cell);
            //return "";

            case Cell.CELL_TYPE_NUMERIC:

                if (DateUtil.isCellDateFormatted(cell)) {
                    // データとしては日付型のとき「例：2005年8月26日」
                    return ConvCellDate(cell);
                } else {
                    BigDecimal dAmount = new BigDecimal(cell.getNumericCellValue());
                    return dAmount;
                }
            /*
                if (HSSFDateUtil.isCellDateFormatted(cell)) {
                    return cell.getDateCellValue();
                } else {
                    double val = cell.getNumericCellValue();
                    if (val == Math.ceil(val)) {
                        return new Integer((int) val);
                    } else {
                        return new Double(val);
                    }
                }
             */
            case Cell.CELL_TYPE_STRING:
                return cell.getStringCellValue();

            default:
                return null;
        }
    }

    /**
     * 日付データの読込み<BR>
     * セルの値が「YYYY年MM月DD日」のとき使用
     *
     * @param cell
     * @return
     */
    private static String ConvCellDate(Cell cell) {
        return DateFormat.getDateInstance().format(cell.getDateCellValue());
    }

    /**
     * セルが計算式の場合、その値を取得
     *
     * @param cell
     * @return
     */
    public static Object getStringFormulaValue(Cell cell) {
        Object value = null;

        try {
            value = cell.getStringCellValue();
            return value;
        } catch (Exception e) {
        }

        try {
            if (DateUtil.isCellDateFormatted(cell)) {
                // データとしては日付型のとき「例：2005年8月26日」
                return ConvCellDate(cell);
            } else {
                BigDecimal dAmount = new BigDecimal(cell.getNumericCellValue());
                return dAmount;
            }
        } catch (Exception e) {
        }

        return value;
        /*
        assert cell.getCellType() == Cell.CELL_TYPE_FORMULA;

        Workbook book = cell.getSheet().getWorkbook();
        CreationHelper helper = book.getCreationHelper();
	FormulaEvaluator evaluator = helper.createFormulaEvaluator();
	CellValue value = evaluator.evaluate(cell);

        //evaluator.evaluateInCell(cell);
        
	switch (value.getCellType()) {
        //switch (cell.getCellType()) {
            case Cell.CELL_TYPE_STRING:
                //return cell.getStringCellValue();
                return value.getStringValue();

            case Cell.CELL_TYPE_NUMERIC:
                return value.getNumberValue();

            case Cell.CELL_TYPE_BOOLEAN:
                //return cell.getBooleanCellValue();
                return value.getBooleanValue();

            case Cell.CELL_TYPE_ERROR:
                return null;
                
            default:
		return "";
        }
         */
    }

    /**
     * セルに値をセット<br>
     * セルにセットするスタイルは指定なし。
     *
     * @param cell Cellオブジェクト
     * @param value セルにセットする内容
     */
    public void setCellValue(Sheet sheet, int rowIdx, int cellIdx, Object value, CellStyle style) {
        Cell cell = getCell(sheet, rowIdx, cellIdx);
        setCellValue(cell, value, style);
    }

    /**
     * セルに値をセット<br>
     * セルにセットするスタイルは指定なし。
     *
     * @param cell Cellオブジェクト
     * @param value セルにセットする内容
     */
    public static void setCellValue(Sheet sheet, int rowIdx, int cellIdx, Object value) {
        Cell cell = getCell(sheet, rowIdx, cellIdx);
        setCellValue(cell, value, null);
    }

    /**
     * セルに値をセット<br>
     * セルにセットするスタイルは指定なし。
     *
     * @param cell HSSFCellオブジェクト
     * @param value セルにセットする内容
     */
    public static void setCellValue(Cell cell, Object value) {
        setCellValue(cell, value, null);
    }

    /**
     * セルに文字列をセット<br>
     * セルにセットするスタイルも指定。
     *
     * @param cell HSSFCellオブジェクト
     * @param value セルにセットする内容
     * @param style HSSFCellStyleオブジェクト(セルにセットするスタイル)
     */
    public static void setCellValue(Cell cell, Object value, CellStyle style) {
        // スタイルを設定
        if (style != null) {
            cell.setCellStyle(style);
        }

        if (value != null) {
            String className = value.getClass().getName();
            if (className.equals("java.lang.String")) {
                cell.setCellValue((String) value);
            } else if (className.equals("java.lang.Double")) {
                double dobleValue = ((Double) value).doubleValue();
                cell.setCellValue(dobleValue);
            } else if (className.equals("java.math.BigDecimal")) {
                double dobleValue = ((BigDecimal) value).doubleValue();
                cell.setCellValue(dobleValue);
            } else if (className.equals("java.util.Date") || className.equals("java.sql.Date")) {
                Date date = (Date) value;
                cell.setCellValue(date);
            }
        }
    }

    /**
     * セルに計算式をセット<br>
     * セルにセットするスタイルは指定なし。
     *
     * @param sheet sheetオブジェクト
     * @param rowIdx セルの行番号
     * @param cellIdx セルの列番号
     * @param formula セルにセットする計算式(nullや空文字の場合は対象外)
     */
    public static void setCellFormula(Sheet sheet, int rowIdx, int cellIdx, String formula) {
        Cell cell = getCell(sheet, rowIdx, cellIdx);
        setCellFormula(cell, formula);
    }

    /**
     * セルに計算式をセット<br>
     *
     * @param cell Cellオブジェクト
     * @param formula セルにセットする計算式(nullや空文字の場合は対象外)
     */
    public static void setCellFormula(Cell cell, String formula) {
        if (formula != null && !formula.equals("")) {
            cell.setCellFormula(formula);
        }
    }
    
    /**
     * セルに計算式をセット<br>
     * セルにセットするスタイルは指定なし。
     *
     * @param sheet sheetオブジェクト
     * @param rowIdx セルの行番号
     * @param cellIdx セルの列番号
     * @param formula セルにセットする計算式(計算式を削除する)
     */
    public static void setCellFormula(Sheet sheet, int rowIdx, int cellIdx) {
        Cell cell = getCell(sheet, rowIdx, cellIdx);
        cell.setCellFormula(null);
    }

    /**
     * 指定行のセル情報をListで取得
     *
     * @param row
     * @return
     */
    public static List<Cell> getCellList(Row row) {
        if (row == null) {
            return null;
        }

        List<Cell> cellList = new ArrayList<>();

        for (int i = 0; i < row.getLastCellNum(); i++) {
            Cell cell = getCell(row, i);
            cellList.add(cell);
        }

        return cellList;
    }

    /**
     * 指定行のセル情報をListで取得(取得開始位置を任意指定)
     *
     * @param row
     * @param startIdx
     * @param loopCount
     * @return
     */
    public static List<Cell> getCellList(Row row, int startIdx, Integer loopCount) {
        if (row == null) {
            return null;
        }

        List<Cell> cellList = new ArrayList<>();

        int idx = startIdx;
        int count = 0;
        do {
            Cell cell = getCell(row, idx);
            cellList.add(cell);
            idx++;
            count++;
        } while(count < loopCount);

        return cellList;
    }

    /**
     * 指定行のスタイル(+値)をコピー
     *
     * @param row コピーを行う対象行
     * @param cellList コピーを行うセル一覧
     * @param isValueCopy 値のコピーまで行うか？ true:行う false:行わない
     * @param isFormulaCopy 計算式のコピーまで行うか？ true:行う false:行わない
     */
    public static void copyRowStyleValue(Row row, List<Cell> cellList, boolean isValueCopy, boolean isFormulaCopy) {
        if (row == null) {
            return;
        }

        for (int i = 0; i < cellList.size(); i++) {
            Cell cell = getCell(row, i);
            if (cell != null) {
                Cell orgCell = cellList.get(i);
                if (orgCell == null) {
                    continue;
                }

                CellStyle style = orgCell.getCellStyle();
                Object orgValue = getCellValue(orgCell);

                if (style != null) {
                    cell.setCellStyle(style);
                }

                switch (orgCell.getCellType()) {
                    case Cell.CELL_TYPE_FORMULA:
                        if (isFormulaCopy) {
                            copyFormula(orgCell.getSheet(), orgCell, cell);
                        }
                        break;

                    default:
                        if (isValueCopy) {
                            setCellValue(cell, orgValue, null);
                        }
                        break;
                }

            }
        }
    }

    public static void copyRowStyleValue(Row row, List<Cell> cellList, int startIdx, boolean isValueCopy, boolean isFormulaCopy) {
        if (row == null) {
            return;
        }

        for (int i = 0; i < cellList.size(); i++) {
            Cell cell = getCell(row, i + startIdx);
            if (cell != null) {
                Cell orgCell = cellList.get(i);
                if (orgCell == null) {
                    continue;
                }

                CellStyle style = orgCell.getCellStyle();
                Object orgValue = getCellValue(orgCell);

                if (style != null) {
                    cell.setCellStyle(style);
                }

                switch (orgCell.getCellType()) {
                    case Cell.CELL_TYPE_FORMULA:
                        if (isFormulaCopy) {
                            copyFormula(orgCell.getSheet(), orgCell, cell);
                        }
                        break;

                    default:
                        if (isValueCopy) {
                            setCellValue(cell, orgValue, null);
                        }
                        break;
                }

            }
            
        }
    }
    
    /**
     * 指定行のスタイル(+値)をコピー
     *
     * @param row コピー先の行
     * @param orgRow コピー元の行
     * @param isValueFormulaCopy 値/計算式のコピーまで行うか？ true:行う false:行わない
     */
    public static void copyRowStyleValue(Row row, Row orgRow, boolean isValueFormulaCopy) {
        if (row == null || orgRow == null) {
            return;
        }
        List<Cell> getCellList = getCellList(orgRow);
        copyRowStyleValue(row, getCellList, isValueFormulaCopy, isValueFormulaCopy);
    }

    public static void copyRowStyleValue(Row row, Row orgRow, boolean isValueCopy, boolean isFormulaCopy) {
        if (row == null || orgRow == null) {
            return;
        }
        List<Cell> getCellList = getCellList(orgRow);
        copyRowStyleValue(row, getCellList, isValueCopy, isFormulaCopy);
    }

    /**
     * 指定行のスタイル(+値)をコピー
     *
     * @param row コピーを行う対象行
     * @param cellList コピーを行うセル一覧
     * @param isValueFormulaCopy 値/計算式のコピーまで行うか？ true:行う false:行わない
     */
    public static void copyRowStyleValue(Row row, List<Cell> cellList, boolean isValueFormulaCopy) {
        copyRowStyleValue(row, cellList, isValueFormulaCopy, isValueFormulaCopy);
    }

    
    
    /**
     * 指定列のスタイル(+値)をコピー
     *
     * @param targetSheet コピー先の処理対象シート
     * @param targetCol コピー先の列番号
     * @param orgSheet コピー元の対象シート
     * @param orgCol コピー元の列番号
     * @param isCopyKbn 値のコピー設定 0:値をコピーしない 1:値と計算式をコピー 2:計算式だけコピー
     */
    public static void copyColumnStyleValue(Sheet targetSheet, int targetCol, Sheet orgSheet, int orgCol, int isCopyKbn) {

        for (int rowNum = 0; rowNum < orgSheet.getLastRowNum() + 1; rowNum++) {
            // コピー元の情報を取得
            Row orgRow = getRow(orgSheet, rowNum);
            if (orgRow == null) {
                continue;
            }
            Cell orgCell = getCell(orgRow, orgCol);

            // コピー先の情報を取得
            Row row = getRow(targetSheet, rowNum, true);
            Cell cell = getCell(row, targetCol);

            // コピー先にコピー元のスタイル(+値)をコピー
            CellStyle orgStyle = orgCell.getCellStyle();
            Object orgValue = getCellValue(orgCell);
            if (orgStyle != null) {
                cell.setCellStyle(orgStyle);
            }

            if (isCopyKbn > 0) {
                switch (orgCell.getCellType()) {
                    case Cell.CELL_TYPE_FORMULA:
                        //String formula = orgCell.getCellFormula();
                        //cell.setCellFormula(formula);
                        copyFormula(targetSheet, orgCell, cell);
                        break;

                    default:
                        if (isCopyKbn == 1) {
                            setCellValue(cell, orgValue, null);
                        }
                        break;

                }
            }
        }
    }

    /**
     * 指定列のスタイル(+値)をコピー
     *
     * @param targetSheet コピー先の処理対象シート
     * @param targetCol コピー先の列番号
     * @param orgSheet コピー元の対象シート
     * @param orgCol コピー元の列番号
     * @param sRow コピー開始行番号
     * @param isCopyKbn 値のコピー設定 0:値をコピーしない 1:値と計算式をコピー 2:計算式だけコピー
     */
    public static void copyColumnStyleValue(Sheet targetSheet, int targetCol, Sheet orgSheet, int orgCol, int sRow, int isCopyKbn) {

        for (int rowNum = sRow; rowNum < orgSheet.getLastRowNum() + 1; rowNum++) {
            // コピー元の情報を取得
            Row orgRow = getRow(orgSheet, rowNum);
            if (orgRow == null) {
                continue;
            }
            Cell orgCell = getCell(orgRow, orgCol);

            // コピー先の情報を取得
            Row row = getRow(targetSheet, rowNum, true);
            Cell cell = getCell(row, targetCol);

            // コピー先にコピー元のスタイル(+値)をコピー
            CellStyle orgStyle = orgCell.getCellStyle();
            Object orgValue = getCellValue(orgCell);
            if (orgStyle != null) {
                cell.setCellStyle(orgStyle);
            }

            if (isCopyKbn > 0) {
                switch (orgCell.getCellType()) {
                    case Cell.CELL_TYPE_FORMULA:
                        //String formula = orgCell.getCellFormula();
                        //cell.setCellFormula(formula);
                        copyFormula(targetSheet, orgCell, cell);
                        break;

                    default:
                        if (isCopyKbn == 1) {
                            setCellValue(cell, orgValue, null);
                        }
                        break;

                }
            }
        }
    }
    
    //private static void copyFormula(Sheet sheet, Cell org, Sheet destSheet, Cell dest) {
    public static void copyFormula(Sheet sheet, Cell org, Cell dest) {
        if (org == null || dest == null || sheet == null || org.getCellType() != Cell.CELL_TYPE_FORMULA) {
            return;
        }
        if (org.isPartOfArrayFormulaGroup()) {
            return;
        }
        String formula = org.getCellFormula();
        int shiftRows = dest.getRowIndex() - org.getRowIndex();
        int shiftCols = dest.getColumnIndex() - org.getColumnIndex();

        XSSFEvaluationWorkbook workbookWrapper
                = XSSFEvaluationWorkbook.create((XSSFWorkbook) sheet.getWorkbook());
        Ptg[] ptgs = FormulaParser.parse(formula, workbookWrapper, FormulaType.CELL, sheet.getWorkbook().getSheetIndex(sheet));

        /*
        XSSFEvaluationWorkbook workbookWrapper = XSSFEvaluationWorkbook.create((XSSFWorkbook) destSheet.getWorkbook());
        Ptg[] ptgs = FormulaParser.parse(formula, workbookWrapper, FormulaType.CELL, sheet.getWorkbook().getSheetIndex(sheet));
         */
        for (Ptg ptg : ptgs) {
            if (ptg instanceof RefPtgBase) {
                RefPtgBase ref = (RefPtgBase) ptg;
                if (ref.isColRelative()) {
                    ref.setColumn(ref.getColumn() + shiftCols);
                }
                if (ref.isRowRelative()) {
                    ref.setRow(ref.getRow() + shiftRows);
                }
            } else if (ptg instanceof AreaPtg) {
                AreaPtg ref = (AreaPtg) ptg;
                if (ref.isFirstColRelative()) {
                    ref.setFirstColumn(ref.getFirstColumn() + shiftCols);
                }
                if (ref.isLastColRelative()) {
                    ref.setLastColumn(ref.getLastColumn() + shiftCols);
                }
                if (ref.isFirstRowRelative()) {
                    ref.setFirstRow(ref.getFirstRow() + shiftRows);
                }
                if (ref.isLastRowRelative()) {
                    ref.setLastRow(ref.getLastRow() + shiftRows);
                }
            }
        }
        formula = FormulaRenderer.toFormulaString(workbookWrapper, ptgs);
        dest.setCellFormula(formula);
    }

    /**
     * 縦・横セルを指定してExcelのセル表現(A1,A2,B1等)を取得する。
     *
     * @param len 縦位置:0より指定
     * @param size 横位置:0より指定
     * @return セル表現文字列
     */
    public static String getCellReferenceStr(int len, int size) {
        CellReference ref = new CellReference(len, size);
        return ref.formatAsString();
    }

    /**
     * 行を削除（上に詰める）<br>
     *
     * @param sheet
     * @param delStartRow 削除開始行
     * @param delCnt 削除する行数
     */
    public static void delRow(Sheet sheet, int delStartRow, int delCnt) {
        for (int i = 0; i < delCnt; i++) {
            // 行を削除
            sheet.removeRow(sheet.getRow(delStartRow + i));
        }
        // delCnt分上に詰める
        sheet.shiftRows(delStartRow + delCnt, sheet.getLastRowNum(), -1 * delCnt);
    }

    /**
     * セルの範囲に名前を設定 <br>
     *
     * @param sheet
     * @param cellName
     * @param row1 始点セルの列位置
     * @param col1 始点セルの行位置
     * @param row2　終点セルの列位置
     * @param col2 終点セルの行位置
     */
    public static void setCellNameRange(Sheet sheet, String cellName, int row1, int col1, int row2, int col2) {
        // セル位置を絶対参照で取得
        String strCol1 = "$" + CellReference.convertNumToColString(col1) + "$" + Integer.toString(row1 + 1);
        String strCol2 = "$" + CellReference.convertNumToColString(col2) + "$" + Integer.toString(row2 + 1);
        String strCellRange = "'" + sheet.getSheetName() + "'!" + strCol1 + ":" + strCol2;

        // セルに名前を設定
        Name namedRange = sheet.getWorkbook().createName();
        namedRange.setNameName(cellName);
        namedRange.setRefersToFormula(strCellRange);
    }

    /**
     * セルに名前を設定 <br>
     *
     * @param sheet
     * @param cellName
     * @param row
     * @param col
     */
    public static void setCellName(Sheet sheet, String cellName, int row, int col) {
        // セル位置を絶対参照で取得
        String strCol = "$" + CellReference.convertNumToColString(col) + "$" + Integer.toString(row + 1);
        String strCellRange = "'" + sheet.getSheetName() + "'!" + strCol + ":" + strCol;

        // セルに名前を設定
        Name namedRange = sheet.getWorkbook().createName();
        namedRange.setNameName(cellName);
        namedRange.setRefersToFormula(strCellRange);
    }

    /**
     *
     * @param sheet
     * @param rowNum
     * @param cellNum
     * @param target
     * @param replacement
     */
    public static void replaceCellValue(Sheet sheet, int rowNum, int cellNum, String target, String replacement) {
        Cell cell = getCell(sheet, rowNum, cellNum);
        String cellValueString = (String) (PoiUtil.getCellValue(cell));
        cellValueString = StringUtils.replace(cellValueString, target, replacement);
        setCellValue(cell, cellValueString);
    }

    /**
     * 指定範囲のセルを結合
     *
     * @param sheet
     * @param row1
     * @param col1
     * @param row2
     * @param col2
     */
    public static void addMergedRegion(Sheet sheet, int row1, int col1, int row2, int col2) {
        CellRangeAddress range = getCellRange(row1, col1, row2, col2);
        sheet.addMergedRegion(range);
    }

    /**
     * 範囲の取得
     *
     * @param row1
     * @param col1
     * @param row2
     * @param col2
     * @return
     */
    public static CellRangeAddress getCellRange(int row1, int col1, int row2, int col2) {
        CellRangeAddress range = new CellRangeAddress(row1, row2, col1, col2);
        return range;
    }
    
    /**
     * セルに定義された名前を用いてセルを取得する
     * @param sheet
     * @param cellName
     * @return
     * @throws Exception 
     */
    public static Cell searchCellName(Sheet sheet, String cellName) throws Exception {
        Cell retCell = null;
        Name name = sheet.getWorkbook().getName(cellName);
        if (name != null) {
            String strRef = name.getRefersToFormula();
            if (strRef.indexOf("#REF!") == -1) {
                AreaReference areaRef = new AreaReference(strRef);
                CellReference cellRef = areaRef.getFirstCell();
                Row row = sheet.getRow(cellRef.getRow());
                retCell =  row.getCell(cellRef.getCol());
            }
        }
        return retCell;
    }

}
