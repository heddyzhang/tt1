/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package jp.co.toshiba.hby.pspromis.syuueki.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import javax.ejb.Stateless;
import javax.inject.Inject;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import jp.co.toshiba.hby.pspromis.syuueki.bean.AuthorityBean;
import jp.co.toshiba.hby.pspromis.syuueki.jdbc.DbUtilsExecutor;
import jp.co.toshiba.hby.pspromis.common.jdbc.SqlExecutor;
import jp.co.toshiba.hby.pspromis.syuueki.jdbc.SqlFile;
import jp.co.toshiba.hby.pspromis.syuueki.util.LoginUserInfo;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * PS-Promis収益管理システム
 * 権限取得用 Service
 * @author (NPC)S.Ibayashi
 */
@Stateless
public class KengenService {

    @PersistenceContext(unitName = jp.co.toshiba.hby.pspromis.syuueki.util.ConstantString.syuuekiDataSourceName)
    private EntityManager em;
    
    /**
     * ロガー
     */
    public static final Logger logger = LoggerFactory.getLogger(KengenService.class);
    
    /**
     * ログイン者情報
     */
    @Inject
    private LoginUserInfo loginUserInfo;

    /**
     * Injection sqlExecutor
     */
    @Inject
    protected SqlExecutor sqlExecutor;

    /**
     * Injection dbUtilsExecutor
     */
    @Inject
    private DbUtilsExecutor dbUtilsExecutor;

    /**
     * Injection AuthorityBean
     */
    @Inject
    private AuthorityBean authorityBean;

    /**
     * 権限をマスタから検索してbeanにセット
     * @throws java.lang.Exception
     */
    public void searchKengenMst() throws Exception {
        Map<String, Set<String>> kengenMap = new HashMap<>();
        Map<String, Set<String>> kengenRirekiMap = new HashMap<>();
        
        String sqlFilePath = "/sql/kengenMst/selectKengenMst.sql";

        // 条件を取得
        Map<String, Object> condition = getCondition();

        // SQLを取得
        SqlFile sqlFile = new SqlFile();
        String sql = sqlFile.getSqlString(sqlFilePath, condition);
        Object[] params = sqlFile.getSqlParams(sqlFilePath, condition);

        // SQL実行
        List<Map<String, Object>> list = dbUtilsExecutor.dbUtilsGetSqlList(em, sql, params);

        for (Map<String, Object> info : list) {
            String divisionCd = StringUtils.defaultString((String)info.get("DIVISION_CODE"));
            String rirekiKbn = StringUtils.defaultString((String)info.get("RIREKI_KBN"), "1");
            String funcCd = StringUtils.defaultString((String)info.get("FUNC_CD"));
            
            // 最新・履歴の判定
            if (rirekiKbn.equals("2")) {
                editKengenMap(kengenRirekiMap, divisionCd, funcCd);
            } else {
                editKengenMap(kengenMap, divisionCd, funcCd);
            }
        }

        authorityBean.setAuthorityKeyMap(kengenMap);
        authorityBean.setAuthorityRirekiKeyMap(kengenRirekiMap);
    }
    
    private void editKengenMap(Map<String, Set<String>> kengenMap, String divisionCd, String funcCd) {
        Set<String> kengenFuncSet;
            
        // 事業部毎に格納した権限を取得
        if (kengenMap.containsKey(divisionCd)) {
            kengenFuncSet = kengenMap.get(divisionCd);
        } else {
            kengenFuncSet = new HashSet<>();
        }
        
        // 権限をセット
        //if (!kengenFuncSet.contains(funcCd)) {
            kengenFuncSet.add(funcCd);
        //}
            
        kengenMap.put(divisionCd, kengenFuncSet);
    }

    /**
     * 条件を取得
     */
    private Map<String, Object> getCondition() {
        List<String> divisionList = new ArrayList<>();
        List<String> jobGrList = new ArrayList<>();

        Map<String, Object> condition = new HashMap<>();
        
        //List<Map<String, Object>> loginJobGrList = loginUserInfo.getJobGrList();
        String[] divisionCdAry = loginUserInfo.getJobGrSyokusyuArrayInfo("division");
        String[] loginJobGrAry = loginUserInfo.getJobGrSyokusyuArrayInfo("JgrpId");
        
        if (divisionCdAry != null) {
            for (String divisionCd : divisionCdAry) {
                divisionList.add(divisionCd);
            } 
        }
        
        jobGrList.add("COMMON");
        if (loginJobGrAry != null) {
            for (String jobGrCd : loginJobGrAry) {
                jobGrList.add(jobGrCd);
            }
        }

        condition.put("divisionCode", divisionList);
        condition.put("jgrpId", jobGrList);
        
        return condition;
    }
}
