package jp.co.toshiba.hby.pspromis.syuueki.bean;

import java.util.Map;
import javax.inject.Named;
import javax.enterprise.context.RequestScoped;
import lombok.Getter;
import lombok.Setter;

/**
 * ES-Promis収益管理システム
 * 処理後の出力メッセージを定義するbean
 * @author ibayashi
 */
@Named(value = "resultMessageBean")
@RequestScoped
@Getter @Setter
public class ResultMessageBean {

    /**
     * (原子力)連携処理結果
     */
    private String n7RenkeiStsFlg = "0";

    public void createResultMessage(Map<String, Object> resultInfo) {
        if ("9".equals(n7RenkeiStsFlg)) {
            resultInfo.put("alertResultMessage", "処理は完了しましたが、(原子力)収益管理のデータ保存に失敗しました。");
        }
    }
}
