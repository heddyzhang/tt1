package jp.co.toshiba.hby.pspromis.syuueki.service;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import javax.ejb.Stateless;
import javax.inject.Inject;
import javax.interceptor.Interceptors;
import jp.co.toshiba.hby.pspromis.common.exception.PspRunTimeExceotion;
import jp.co.toshiba.hby.pspromis.syuueki.bean.OpenDetailBean;
import jp.co.toshiba.hby.pspromis.syuueki.entity.SyuGeBukkenInfoTbl;
import jp.co.toshiba.hby.pspromis.syuueki.enums.Label;
import jp.co.toshiba.hby.pspromis.syuueki.facade.OpenDetailFacade;
import jp.co.toshiba.hby.pspromis.syuueki.interceptor.TranceInterceptor;
import jp.co.toshiba.hby.pspromis.syuueki.util.LoginUserInfo;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * PS-Promis収益管理システム
 * 案件検索 開くボタン Service
 * @author koga
 */
@Stateless
@Interceptors({TranceInterceptor.class})
public class OpenDetailService {
    private static final Logger log = LoggerFactory.getLogger(OpenDetailService.class);
    
    @Inject
    private OpenDetailBean openDetailBean;
    
    @Inject
    private OpenDetailFacade openDetailFacade;
    
    @Inject
    private LoginUserInfo loginUserInfo;

    public Map<String, Object> getCondition() {
        String[] divisionCodes = null;
        if (StringUtils.isNotEmpty(openDetailBean.getDivisionCode())) {
            // 事業部を呼出し元から指定した場合は、その事業部の案件のみを検索
            divisionCodes = new String[]{openDetailBean.getDivisionCode()};
        }
        if (divisionCodes == null) {
            // 事業部の指定がされなかった場合、ログイン者の所属事業部を指定
            divisionCodes = loginUserInfo.getJobGrSyokusyuArrayInfo("division");
        }

        Map<String, Object> condition = new LinkedHashMap<>();
        condition.put("no", openDetailBean.getNo());
        condition.put("kbn", openDetailBean.getKbn());
        condition.put("divisionCode", divisionCodes);
        
        log.info("OpenDetailService#condition=[{}]", condition.toString());

        return condition;
    }

    /**
     * 初期表示 ビジネスロジック
     */
    public void indexExecute() {
        log.info("OpenDetailService#indexExecute");
        
        List<SyuGeBukkenInfoTbl> ankenList;
        
        // Kbnの説明：
        // 0:案件番号 1:注番 2:見積番号 3:旧システム番号(2017下期時点では(原子力)収益から呼び出される場合に利用)
        if ("1".equals(openDetailBean.getKbn())) {
            // 注番で検索する場合
            ankenList = findTargetAnkenListFromChuban();
        } else {
            // 案件番号、見積番号で検索する場合
            ankenList = findTargetAnkenList();
        }

        // 検索結果をbeanセット
        openDetailBean.setAnkenId(ankenList.get(0).getAnkenId());
        openDetailBean.setSalesClass(ankenList.get(0).getSalesClass()); 
    }

    /**
     * 対象案件の検索(案件番号/見積番号)
     */
    private List<SyuGeBukkenInfoTbl> findTargetAnkenList() {
        Map<String, Object> condition = this.getCondition();
        List<SyuGeBukkenInfoTbl> ankenList = openDetailFacade.getSyuGeBukkenInfo(condition);
 
        if (CollectionUtils.isEmpty(ankenList)) {
            String errorMessage = Label.getValue(Label.errorNoAnkenDate);
            throw new PspRunTimeExceotion(errorMessage);
        } else {
            if (ankenList.size() >= 2) {
                String errorMessage = Label.getValue(Label.errorPluralAnken);
                throw new PspRunTimeExceotion(errorMessage);    
            }
        }
        
        return ankenList;
    }

    /**
     * 対象案件の検索(注番)
     */
    private List<SyuGeBukkenInfoTbl> findTargetAnkenListFromChuban() {
        Map<String, Object> condition = this.getCondition();
        // 案件の検索(ANKEN_FLG = 1)
        condition.put("ankenFlg", "1");
        List<SyuGeBukkenInfoTbl> ankenList = openDetailFacade.getSyuGeBukkenInfo(condition);
 
        // 複数案件取得できる場合はエラー
        if (CollectionUtils.isNotEmpty(ankenList)) {
            if (ankenList.size() >= 2) {
                log.info("対象注番=[{}], ANKEN_FLG = 1で検索。複数案件あり", openDetailBean.getNo());
                String errorMessage = Label.getValue(Label.errorPluralAnken);
                throw new PspRunTimeExceotion(errorMessage);    
            }

            // 1案件だけ取得できた場合は、それを利用
            log.info("対象注番=[{}], ANKEN_FLG = 1で検索。1案件のみ", openDetailBean.getNo());
            return ankenList;
        }

        // 案件の検索(ANKEN_FLG = 0)
        condition.put("ankenFlg", "0");
        ankenList = openDetailFacade.getSyuGeBukkenInfo(condition);

        if (CollectionUtils.isEmpty(ankenList)) {
            log.info("対象注番=[{}], ANKEN_FLG = 0で検索。案件なし", openDetailBean.getNo());
            String errorMessage = Label.getValue(Label.errorNoAnkenDate);
            throw new PspRunTimeExceotion(errorMessage);
        } else {
            if (ankenList.size() >= 2) {
                log.info("対象注番=[{}], ANKEN_FLG = 0で検索。複数案件あり", openDetailBean.getNo());
                String errorMessage = Label.getValue(Label.errorPluralAnken);
                throw new PspRunTimeExceotion(errorMessage);    
            }
        }
        
        return ankenList;
    }
}
