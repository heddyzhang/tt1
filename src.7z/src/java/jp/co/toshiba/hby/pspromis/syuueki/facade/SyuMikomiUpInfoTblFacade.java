/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package jp.co.toshiba.hby.pspromis.syuueki.facade;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.ejb.Stateless;
import javax.interceptor.Interceptors;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
//import javax.persistence.Query;
import jp.co.toshiba.hby.pspromis.syuueki.entity.SyuMikomiUpInfoTbl;
import jp.co.toshiba.hby.pspromis.syuueki.interceptor.TranceInterceptor;

/**
 *
 * @author ibayashi
 */
@Stateless
@Interceptors({TranceInterceptor.class})
public class SyuMikomiUpInfoTblFacade extends AbstractFacade<SyuMikomiUpInfoTbl> {
    @PersistenceContext(unitName = jp.co.toshiba.hby.pspromis.syuueki.util.ConstantString.syuuekiDataSourceName)
    private EntityManager em;

    @Override
    protected EntityManager getEntityManager() {
        return em;
    }

    public SyuMikomiUpInfoTblFacade() {
        super(SyuMikomiUpInfoTbl.class);
    }

    public SyuMikomiUpInfoTbl getPkInfo(String kbn, String divisionCode) {
        Map<String, Object> condition = new HashMap<>();
        condition.put("kbn", kbn);
        condition.put("divisionCode", divisionCode);

        SyuMikomiUpInfoTbl en = null;
        
        List<SyuMikomiUpInfoTbl> list
                = sqlExecutor.getResultList(em, SyuMikomiUpInfoTbl.class, "/sql/syuMikomiUpInfoTbl/selectMikomiUpInfoTbl.sql", condition);
        
        if (list != null && list.size() > 0) {
            en = list.get(0);
        }
        
        return en;
    }

    public int insert(Object en) {
        int count = sqlExecutor.executeUpdateSql(em, "/sql/syuMikomiUpInfoTbl/insertSyuMikomiUpInfoTbl.sql", en);
        return count;
    }
    
    public int update(Object en) {
        int count = sqlExecutor.executeUpdateSql(em, "/sql/syuMikomiUpInfoTbl/updateSyuMikomiUpInfoTbl.sql", en);
        return count;
    }
}
