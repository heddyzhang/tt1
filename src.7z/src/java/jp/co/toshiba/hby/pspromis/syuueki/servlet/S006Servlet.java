package jp.co.toshiba.hby.pspromis.syuueki.servlet;

import javax.inject.Inject;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpServletRequest;
import jp.co.toshiba.hby.pspromis.syuueki.bean.S006Bean;
import jp.co.toshiba.hby.pspromis.syuueki.service.S006Service;
import jp.co.toshiba.hby.pspromis.syuueki.util.ParameterBinder;

/**
 * PS-Promis収益管理システム
 * 履歴検索 Servlet
 * @author (NPC)T.Wakamatsu
 */
@WebServlet(name="S006", urlPatterns={"/servlet/S006", "/servlet/S006/*"})
public class S006Servlet extends AbstractServlet {

    /**
     * jsp
     */
    private static final String INDEX_JSP = "S006/s006.jsp";

    /**
     * 使用serviceクラスをinjection(CDI)<br>
     * InjectアノテーションよりAPサーバー(Glassfish)側で自動的にインスタンス作成(new)される。<br>
     * service側はステートレスセッションbeanにするため、Statelessアノテーションをつけておくこと。<br>
     */
    @Inject
    private S006Service s006Service;

    /**
     * パラメータ格納クラスをinjection(CDI)<br>
     * InjectアノテーションよりAPサーバー(Glassfish)側で自動的にインスタンス作成(new)される。<br>
     */
    @Inject
    private S006Bean s006Bean;

    /**
     * 初期表示
     * @param req
     * @param resp
     * @return INDEX_JSP
     * @throws Exception 
     */
    public String indexAction(HttpServletRequest req, HttpServletResponse resp)
    throws Exception {
        logger.info("S006Servlet#indexAction");

        // リクエストパラメータをs006Beanの同名フィールドに一括コピー
        ParameterBinder.Bind(s006Bean, req);

        // サービスの実行(トランザクション単位)
        s006Service.indexExecute();

        return INDEX_JSP;
    }
}
