package jp.co.toshiba.hby.pspromis.syuueki.facade;

import java.util.List;
import javax.ejb.Stateless;
import javax.inject.Inject;
import javax.interceptor.Interceptors;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import jp.co.toshiba.hby.pspromis.syuueki.entity.SyuPatternItemMst;
import jp.co.toshiba.hby.pspromis.syuueki.entity.SyuPatternMst;
import jp.co.toshiba.hby.pspromis.syuueki.interceptor.TranceInterceptor;
import jp.co.toshiba.hby.pspromis.syuueki.util.Utils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
/**
 *
 * @author sano
 */
@Stateless
@Interceptors({TranceInterceptor.class})
public class SyuPatternMstFacade extends AbstractFacade<SyuPatternMst> {
    
    private static final Logger logger = LoggerFactory.getLogger(SyuPatternMstFacade.class);
    
    @PersistenceContext(unitName = jp.co.toshiba.hby.pspromis.syuueki.util.ConstantString.syuuekiDataSourceName)
    private EntityManager em;

    @Override
    protected EntityManager getEntityManager() {
        return em;
    }

    @Inject
    private Utils util;
    
    public SyuPatternMstFacade() {
        super(SyuPatternMst.class);
    }

    /**
     * パターンマスタ一覧を取得
     * @param condition
     * @param page
     * @return
     * @throws Exception 
     */
    public List<SyuPatternMst> getPatternMstList(Object condition, Integer page) throws Exception {
        int limit = util.getPageLimit();
        int offset = util.getPageOffset(page);
        
        List<SyuPatternMst> list
                = sqlExecutor.getResultList(em, SyuPatternMst.class, "/sql/S009/selectSyuPatternMst.sql", condition, limit, offset);
        return list;
    }

    /**
     * パターンマスタ件数を取得
     * @param condition
     * @return
     * @throws Exception 
     */
    public Long getPatternMstListCount(Object condition) throws Exception {
        
        SyuPatternMst syuPatternMst
                = sqlExecutor.getSingleResult(em, SyuPatternMst.class, "/sql/S009/selectSyuPatternMst.sql", condition);
        
        return syuPatternMst.getCount();
    }
    
    /**
     * パターンマスタを取得
     * @param condition
     * @return
     * @throws Exception 
     */
    public SyuPatternMst getPatternMst(Object condition) throws Exception {
        SyuPatternMst syuPatternMst = sqlExecutor.getSingleResult(em, SyuPatternMst.class, "/sql/M001/selectSyuPatternMst.sql", condition);
        return syuPatternMst;
    }
    
    /**
     * 注入パターンNOを発番
     * @param condition
     * @return
     * @throws Exception 
     */
    public String seqCyunyuPtnNo(Object condition) throws Exception {
        SyuPatternMst syuPatternMst = sqlExecutor.getSingleResult(em, SyuPatternMst.class, "/sql/M001/seqChunyuPtnNo.sql", condition);
        return syuPatternMst.getChunyuPtnNo();
    }
    
    /**
     * パターンマスタを取得
     * @param condition
     * @return
     * @throws Exception 
     */
    public List<SyuPatternMst> getAllPatternMst(Object condition) throws Exception {
         List<SyuPatternMst> list = sqlExecutor.getResultList(em, SyuPatternMst.class, "/sql/patternMst/selectPatternMst.sql", condition);
        return list;
    }
}
