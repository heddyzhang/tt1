/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package jp.co.toshiba.hby.pspromis.syuueki.entity;

import java.io.Serializable;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;

/**
 *
 * @author wakamatsu
 */
@Entity
public class SyuGeNetItemTblBuka implements Serializable {
    private static final long serialVersionUID = 1L;

    @Id
    @Column(name = "BUKA_CODE")
    private String bukaCode;

    @Id
    @Column(name = "BUKA_NAME")
    private String bukaName;

    public SyuGeNetItemTblBuka() {
    }

    public String getBukaCode() {
        return bukaCode;
    }

    public void setBukaCode(String bukaCode) {
        this.bukaCode = bukaCode;
    }

    public String getBukaName() {
        return bukaName;
    }

    public void setBukaName(String bukaName) {
        this.bukaName = bukaName;
    }

}
