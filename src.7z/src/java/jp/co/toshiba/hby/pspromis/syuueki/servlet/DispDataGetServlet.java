package jp.co.toshiba.hby.pspromis.syuueki.servlet;

import javax.inject.Inject;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import jp.co.toshiba.hby.pspromis.syuueki.bean.DispDataGetBean;
import jp.co.toshiba.hby.pspromis.syuueki.service.DispDataGetService;

/**
 * PS-Promis収益管理システム
 * データ更新日確認ダイアログ 表示
 * @author ibayashi
 */
@WebServlet(name="DispDataGet", urlPatterns={"/servlet/DispDataGet", "/servlet/DispDataGet/*"})
public class DispDataGetServlet extends AbstractServlet {

    /**
     * jsp
     */
    private static final String INDEX_JSP = "DispDataGet/dispDataGet.jsp";
    
    //@Inject
    //private DispDataGetBean dispDataGetBean;
    
    @Inject
    private DispDataGetService dispDataGetService;
    
    /**
     * 初期表示
     * @param req
     * @param resp
     * @return
     * @throws Exception 
     */
    public String indexAction(HttpServletRequest req, HttpServletResponse resp)
    throws Exception {
        logger.info("DispDataGetServlet#indexAction");
       
        //dispDataGetBean = new DispDataGetBean();
        
        dispDataGetService.indexExecute();

        return INDEX_JSP;
    }

}
