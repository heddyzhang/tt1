/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package jp.co.toshiba.hby.pspromis.syuueki.facade;

import javax.ejb.Stateless;
import javax.interceptor.Interceptors;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import jp.co.toshiba.hby.pspromis.syuueki.entity.SyuKiNetSogenkaTukiTbl;
import jp.co.toshiba.hby.pspromis.syuueki.interceptor.TranceInterceptor;

/**
 *
 * @author kitajima
 */
@Stateless
@Interceptors({TranceInterceptor.class})
public class SyuKiNetSogenkaTukiTblFacade extends AbstractFacade<SyuKiNetSogenkaTukiTbl> {
    @PersistenceContext(unitName = jp.co.toshiba.hby.pspromis.syuueki.util.ConstantString.syuuekiDataSourceName)
    private EntityManager em;

    @Override
    protected EntityManager getEntityManager() {
        return em;
    }

    public SyuKiNetSogenkaTukiTblFacade() {
        super(SyuKiNetSogenkaTukiTbl.class);
    }

    public SyuKiNetSogenkaTukiTbl getPkInfo(String ankenId, Integer rirekiId, String dataKbn, String syuekiYm) {
        Query q = em.createNamedQuery("KiNetSogenkaTukiTbl.findPk", SyuKiNetSogenkaTukiTbl.class);
        
        q.setParameter("ankenId", ankenId);
        q.setParameter("rirekiId", rirekiId);
        q.setParameter("dataKbn", dataKbn);
        q.setParameter("syuekiYm", syuekiYm);

        SyuKiNetSogenkaTukiTbl en;
        
        try {
            en = (SyuKiNetSogenkaTukiTbl)q.getSingleResult();
        } catch(javax.persistence.NoResultException e){
            // 指定PKのデータが存在しない場合
            en = null;
        }

        return en;
    }
    
}
