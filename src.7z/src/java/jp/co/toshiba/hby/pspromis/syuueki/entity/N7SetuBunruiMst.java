package jp.co.toshiba.hby.pspromis.syuueki.entity;

import java.io.Serializable;
import java.util.Date;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;

/**
 * 設備分類マスタ
 *
 * @author ganryu
 */
@Entity
@Table(name = "N7_SETU_BUNRUI_MST")
public class N7SetuBunruiMst implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 10)
    @Column(name = "SETU_BUNRUI_CD")
    private String setuBunruiCd;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 5)
    @Column(name = "BU_CD")
    private String buCd;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 80)
    @Column(name = "SETU_BUNRUI_NM")
    private String setuBunruiNm;
    @Basic(optional = false)
    @NotNull
    @Column(name = "DEL_FLG")
    private short delFlg;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 8)
    @Column(name = "UPDATE_ID")
    private String updateId;
    @Basic(optional = false)
    @NotNull
    @Column(name = "UPDATE_DT")
    @Temporal(TemporalType.DATE)
    private Date updateDt;
    @Basic(optional = false)
    @NotNull
    @Column(name = "VALID_FROM")
    @Temporal(TemporalType.DATE)
    private Date validFrom;
    @Basic(optional = false)
    @NotNull
    @Column(name = "VALID_TO")
    @Temporal(TemporalType.DATE)
    private Date validTo;

    public N7SetuBunruiMst() {
    }

    public String getSetuBunruiCd() {
        return setuBunruiCd;
    }

    public void setSetuBunruiCd(String setuBunruiCd) {
        this.setuBunruiCd = setuBunruiCd;
    }

    public String getBuCd() {
        return buCd;
    }

    public void setBuCd(String buCd) {
        this.buCd = buCd;
    }

    public String getSetuBunruiNm() {
        return setuBunruiNm;
    }

    public void setSetuBunruiNm(String setuBunruiNm) {
        this.setuBunruiNm = setuBunruiNm;
    }

    public short getDelFlg() {
        return delFlg;
    }

    public void setDelFlg(short delFlg) {
        this.delFlg = delFlg;
    }

    public String getUpdateId() {
        return updateId;
    }

    public void setUpdateId(String updateId) {
        this.updateId = updateId;
    }

    public Date getUpdateDt() {
        return updateDt;
    }

    public void setUpdateDt(Date updateDt) {
        this.updateDt = updateDt;
    }

    public Date getValidFrom() {
        return validFrom;
    }

    public void setValidFrom(Date validFrom) {
        this.validFrom = validFrom;
    }

    public Date getValidTo() {
        return validTo;
    }

    public void setValidTo(Date validTo) {
        this.validTo = validTo;
    }

}
