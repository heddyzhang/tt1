package jp.co.toshiba.hby.pspromis.syuueki.service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.ejb.Stateless;
import javax.inject.Inject;
import javax.interceptor.Interceptors;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import jp.co.toshiba.hby.pspromis.syuueki.bean.K005Bean;
import jp.co.toshiba.hby.pspromis.syuueki.entity.TradeMst;
import jp.co.toshiba.hby.pspromis.syuueki.facade.TradeMstFacade;
import jp.co.toshiba.hby.pspromis.syuueki.interceptor.TranceInterceptor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * PS-Promis収益管理システム
 * 設置場所選択 Service
 * @author (NPC)S.horie
 */
@Stateless
@Interceptors({TranceInterceptor.class})
public class K005Service {

    public static final Logger logger = LoggerFactory.getLogger(K005Service.class);

    @PersistenceContext(unitName = jp.co.toshiba.hby.pspromis.syuueki.util.ConstantString.syuuekiDataSourceName)
    private EntityManager em;

    @Inject
    private K005Bean k005Bean;
    
    @Inject
    private TradeMstFacade tradeMstFacade;
    
    /**
     * 検索条件用Mapを作成
     */
    private Map getCondition() {
        Map<String, Object> condition = new HashMap<>();

        // 注文主名称
        condition.put("tradeName", k005Bean.getTradeName());
        // 注文主コード(Step3追加)
        condition.put("tradeCode", k005Bean.getTradeCode());
        
        return condition;
    }

    /**
     * 初期表示時機能
     * @throws Exception
     */
    public void indexExecute() throws Exception {
        searchExecute();
    }

    /**
     * 検索機能
     * @throws Exception
     */
    
    public void searchExecute() throws Exception {
        // ページ切り替えか否かを判定
        boolean isPageing = true;
        if (k005Bean.getPage() == null || k005Bean.getPage() <= 0) {
            isPageing = false;
            k005Bean.setPage(1);
        }

        // 検索条件をセット
        Map condition = getCondition();
        
        if (!isPageing) {
            // 検索ボタン
            Integer count = tradeMstFacade.getCount(condition);
            k005Bean.setCount(count);
        }

       if (k005Bean.getCount() > 0) {
            List<TradeMst> list = tradeMstFacade.getList(condition, k005Bean.getPage());
            k005Bean.setTradeList(list);
       }
    }

}
