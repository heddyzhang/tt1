/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package jp.co.toshiba.hby.pspromis.syuueki.jdbc;

import java.io.ByteArrayOutputStream;
import java.io.Closeable;
import java.io.IOException;
import java.io.InputStream;
import java.util.logging.Logger;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.Query;
import jp.co.toshiba.hby.pspromis.common.exception.PspRunTimeExceotion;
import jp.co.toshiba.hby.pspromis.common.jdbc.ClasspathSqlResource;
import jp.co.toshiba.hby.pspromis.common.jdbc.SqlResource;
import jp.co.toshiba.hby.pspromis.common.jdbc.bean.BeanDesc;
import jp.co.toshiba.hby.pspromis.common.jdbc.bean.BeanDescFactory;
import jp.co.toshiba.hby.pspromis.common.jdbc.bean.PropertyDesc;
import jp.co.toshiba.hby.pspromis.common.jdbc.paser.Node;
import jp.co.toshiba.hby.pspromis.common.jdbc.paser.SqlContext;
import jp.co.toshiba.hby.pspromis.common.jdbc.paser.SqlContextImpl;
import jp.co.toshiba.hby.pspromis.common.jdbc.paser.SqlParserImpl;
import jp.co.toshiba.hby.pspromis.syuueki.entity.StringEntity;

/**
 *
 * @author ibayashi
 */
@Stateless
public class SqlExecutorOriginal {
    private static final Logger logger = Logger.getLogger(SqlExecutorOriginal.class.getName());
    
    protected Node prepareNode(SqlResource resource) {
        String sql;
        try {
            InputStream in = resource.getInputStream();
            if (in == null) {
                throw new RuntimeException(String.format("resource: %s is not found.", resource));
            }
            sql = new String(readStream(in), "UTF-8");
        } catch (IOException | RuntimeException ex) {
            throw new PspRunTimeExceotion(ex);
        }
        sql = sql.trim();
        if (sql.endsWith(";")) {
            sql = sql.substring(0, sql.length() - 1);
        }
        Node node = new SqlParserImpl(sql).parse();
        return node;
    }
    
    public SqlContext getSqlContext(Object param) {
        SqlContext context = new SqlContextImpl();

        if (param != null) {
            BeanDesc beanDesc = BeanDescFactory.getBeanDesc(param);
            for (int i = 0; i < beanDesc.getPropertyDescSize(); i++) {
                PropertyDesc pd = beanDesc.getPropertyDesc(i);
                context.addArg(pd.getPropertyName(), pd.getValue(param), pd
                        .getPropertyType());
                        logger.warning("paramName："+ pd.getPropertyName());
                        logger.warning("val："+ pd.getValue(param));
            }
        }

        return context;
    }

    @SuppressWarnings("unchecked")
    protected Query setParameters(Query query, Object[] params) {
        for (int i = 0; i < params.length; i++) {
            if (params[i] == null) {
                query = query.setParameter(i + 1, null);
            } else {
                query = query.setParameter(i + 1, params[i]);
            }
        }
        return query;
    }
    
    public byte[] readStream(InputStream in) {
        if (in == null) {
            return null;
        }
        ByteArrayOutputStream out = null;
        try {
            out = new ByteArrayOutputStream();
            byte[] buf = new byte[1024 * 8];
            int length = 0;
            while ((length = in.read(buf)) != -1) {
                out.write(buf, 0, length);
            }
        } catch (IOException e) {
           throw new PspRunTimeExceotion(e);
        } finally {
            closeQuietly(in);
            closeQuietly(out);
        }
        return out.toByteArray();
    }
    
    public static void closeQuietly(Closeable closeable) {
        if (closeable != null) {
            try {
                closeable.close();
            } catch (IOException ex) {
                // ignore
            }
        }
    }
    
    public String getString(EntityManager entityManager, String sql, Object param) {
        Node node = prepareNode(new ClasspathSqlResource(sql));
        SqlContext context = getSqlContext(param);
        node.accept(context);
        Query query = entityManager.createNativeQuery(context.getSql(), StringEntity.class);
        query = this.setParameters(query, context.getBindVariables());
        StringEntity entity = (StringEntity) query.getSingleResult();
        logger.info("SQL発行："+ query.toString());
        return entity.getString();
    }
    
    public Object[] getSqlParams(String sql, Object param) {
        Node node = prepareNode(new ClasspathSqlResource(sql));
        SqlContext context = getSqlContext(param);
        node.accept(context);
        
        return context.getBindVariables();
    }
    
    public String getSqlString(String sql, Object param) {
        Node node = prepareNode(new ClasspathSqlResource(sql));
        SqlContext context = getSqlContext(param);
        node.accept(context);
        context.getSql();
        return context.getSql();
    }
}
