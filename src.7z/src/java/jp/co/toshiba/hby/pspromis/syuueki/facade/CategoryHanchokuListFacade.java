package jp.co.toshiba.hby.pspromis.syuueki.facade;

import java.util.List;
import javax.ejb.Stateless;
import javax.interceptor.Interceptors;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import jp.co.toshiba.hby.pspromis.syuueki.entity.CategoryHanchokuList;
import jp.co.toshiba.hby.pspromis.syuueki.entity.SonekiList;
import jp.co.toshiba.hby.pspromis.syuueki.interceptor.TranceInterceptor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 *
 * @author sano
 */
@Stateless
@Interceptors({TranceInterceptor.class})
public class CategoryHanchokuListFacade extends AbstractFacade<SonekiList> {

    /**
     * ロガ－
     */
    private static final Logger logger = LoggerFactory.getLogger(CategoryHanchokuListFacade.class);

    @PersistenceContext(unitName = jp.co.toshiba.hby.pspromis.syuueki.util.ConstantString.syuuekiDataSourceName)
    private EntityManager em;

    public CategoryHanchokuListFacade() {
        super(SonekiList.class);
    }

    @Override
    protected EntityManager getEntityManager() {
        return em;
    }

    /**
     * 販直費カテゴリー別内訳を取得
     * @param condition
     * @return 
     */
    public List<CategoryHanchokuList> findList(Object condition) {
        logger.info("ProductSonekiListFacade#findList");

        List<CategoryHanchokuList> list = sqlExecutor.getResultList(em, CategoryHanchokuList.class, "/sql/S002/selectCategoryHanchokuList.sql", condition);
        
        return list;
    }
}
