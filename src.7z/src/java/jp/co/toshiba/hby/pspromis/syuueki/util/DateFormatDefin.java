/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package jp.co.toshiba.hby.pspromis.syuueki.util;

import java.io.Serializable;
import javax.enterprise.context.ApplicationScoped;
import javax.inject.Named;

/**
 * PS-Promis収益管理システム
 * 日付書式の定義クラス(filterでweb.xmlより書式を取得して設定)
 * @author (NPC)S.Ibayashi
 */
@Named(value = "dateFormatDefin")
@ApplicationScoped
public class DateFormatDefin implements Serializable {
    /**
     * 日付書式
     */
    private String dateFormatDate;

    /**
     * 年月書式
     */
    private String dateFormatYm;

    /**
     * 日次書式
     */
    private String dateFormatTimestamp;

    /**
     * 勘定年月のフォーマット
     */
    private String dataFormatCalcKanjoYm = "yyyyMM";

    /**
     * SP,NET(円貨)の表示書式(カンマ編集)
     */
    private String jpyUnitFmt = "###,###,###,###,##0";

    /**
     * SP,NET(外貨)の表示書式(カンマ編集)
     */
    //private String foreignUnitFmt = "###,###,###,###,##0.000";
    private String foreignUnitFmt = "###,###,###,###,##0.00";

    /**
     * M率の表示書式(カンマ編集)
     */
    private String mratFmt = "###0.00";

    /**
     * レートフォーマット
     */
    private String rateFmt = "##0.00";
    
    public String getDateFormatDate() {
        return dateFormatDate;
    }

    public void setDateFormatDate(String dateFormatDate) {
        this.dateFormatDate = dateFormatDate;
    }

    public String getDateFormatYm() {
        return dateFormatYm;
    }

    public void setDateFormatYm(String dateFormatYm) {
        this.dateFormatYm = dateFormatYm;
    }

    public String getDateFormatTimestamp() {
        return dateFormatTimestamp;
    }

    public void setDateFormatTimestamp(String dateFormatTimestamp) {
        this.dateFormatTimestamp = dateFormatTimestamp;
    }

    public String getJpyUnitFmt() {
        return jpyUnitFmt;
    }

    public void setJpyUnitFmt(String jpyUnitFmt) {
        this.jpyUnitFmt = jpyUnitFmt;
    }

    public String getMratFmt() {
        return mratFmt;
    }

    public void setMratFmt(String mratFmt) {
        this.mratFmt = mratFmt;
    }

    public String getDataFormatCalcKanjoYm() {
        return dataFormatCalcKanjoYm;
    }

    public void setDataFormatCalcKanjoYm(String dataFormatCalcKanjoYm) {
        this.dataFormatCalcKanjoYm = dataFormatCalcKanjoYm;
    }

    public String getRateFmt() {
        return rateFmt;
    }

    public void setRateFmt(String rateFmt) {
        this.rateFmt = rateFmt;
    }

    public String getForeignUnitFmt() {
        return foreignUnitFmt;
    }

    public void setForeignUnitFmt(String foreignUnitFmt) {
        this.foreignUnitFmt = foreignUnitFmt;
    }

}
