package jp.co.toshiba.hby.pspromis.syuueki.facade;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.ejb.Stateless;
import javax.inject.Inject;
import javax.interceptor.Interceptors;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import jp.co.toshiba.hby.pspromis.common.util.CollectionUtil;
import jp.co.toshiba.hby.pspromis.syuueki.entity.SyuKiNetCateTitleTbl;
import jp.co.toshiba.hby.pspromis.syuueki.entity.SyuKiNetCateTitleTblView;
import jp.co.toshiba.hby.pspromis.syuueki.interceptor.TranceInterceptor;
import jp.co.toshiba.hby.pspromis.syuueki.util.LoginUserInfo;

/**
 *
 * @author kitajima
 */
@Stateless
@Interceptors({TranceInterceptor.class})
public class SyuKiNetCateTitleTblFacade extends AbstractFacade<SyuKiNetCateTitleTbl>{
    @PersistenceContext(unitName = jp.co.toshiba.hby.pspromis.syuueki.util.ConstantString.syuuekiDataSourceName)
    private EntityManager em;

    @Override
    protected EntityManager getEntityManager() {
        return em;
    }

    public SyuKiNetCateTitleTblFacade() {
        super(SyuKiNetCateTitleTbl.class);
    }

    @Inject
    private LoginUserInfo loginUserInfo;

    /**
     * パラメータにログイン者idをセット
     */
    private Map<String, Object> addParamLoginId(Map<String, Object> _params) {
        Map<String, Object> ret = _params;
        if (ret == null) {
            ret = new HashMap<>();
        }
        ret.put("userId", loginUserInfo.getUserId());
        return ret;
    }

    /**
     * 期間損益TBLから手動追加したデータを取得
     * @param condition
     * @return
     */
    public List<SyuKiNetCateTitleTbl> selectChoseiList(Map<String, Object> condition) { 
        
        // 売上原価調整口の一覧を取得
        List<SyuKiNetCateTitleTbl> list
                = sqlExecutor.getResultList(em, SyuKiNetCateTitleTbl.class, "/sql/syuKiNetCateTitleTbl/selectGenkaChosei.sql", condition);
        
        return list;
        
    }

    /**
     * 手動追加されたカテゴリーコードの最大値を取得
     * @param condition
     * @return
     */
    public SyuKiNetCateTitleTbl selectMaxCateCode(Map<String, Object> condition) { 
        SyuKiNetCateTitleTbl entity = null;
        
        List<SyuKiNetCateTitleTbl> list = sqlExecutor.getResultList(em, SyuKiNetCateTitleTbl.class, "/sql/syuKiNetCateTitleTbl/selectMaxInputCatCode.sql", condition);
        
        if(!CollectionUtil.isEmpty(list)){
            entity = list.get(0);
        }
        
        return entity;
    }

    /**
     * 最終見込損益　売上原価カテゴリ一覧を取得
     * @param condition
     * @return 
     */
    public List<SyuKiNetCateTitleTbl> getList(Map<String, Object> condition) {

        List<SyuKiNetCateTitleTbl> list
                = sqlExecutor.getResultList(em, SyuKiNetCateTitleTbl.class, "/sql/syuKiNetCateTitleTbl/selectKiNetCateTitleList.sql", condition);
        
        return list;
    }
    
    /**
     * 最終見込損益　売上原価カテゴリ一覧を取得
     * @param condition
     * @return 
     */
    public List<SyuKiNetCateTitleTbl> getBaseList(Map<String, Object> condition) {

        List<SyuKiNetCateTitleTbl> list
                = sqlExecutor.getResultList(em, SyuKiNetCateTitleTbl.class, "/sql/syuKiNetCateTitleTbl/selectBaseKiNetCateTitleList.sql", condition);
        
        return list;
    }
    
    
    public Long getPkCount(String ankenId, Integer rirekiId, String categoryCode, String categoryKbn1, String categoryKbn2) {
        Query q = em.createNamedQuery("KiNetCateTitleTbl.PKCount");
        q.setParameter("ankenId", ankenId);
        q.setParameter("rirekiId", rirekiId);
        q.setParameter("categoryCode", categoryCode);
        q.setParameter("categoryKbn1", categoryKbn1);
        q.setParameter("categoryKbn2", categoryKbn2);
        return (Long)q.getSingleResult();
    }
    
    public SyuKiNetCateTitleTbl getPkInfo(String ankenId, Integer rirekiId, String categoryCode, String categoryKbn1, String categoryKbn2) {
        Query q = em.createNamedQuery("KiNetCateTitleTbl.findPk");
        q.setParameter("ankenId", ankenId);
        q.setParameter("rirekiId", rirekiId);
        q.setParameter("categoryCode", categoryCode);
        q.setParameter("categoryKbn1", categoryKbn1);
        q.setParameter("categoryKbn2", categoryKbn2);
        
        SyuKiNetCateTitleTbl en;
        
        try {
            en = (SyuKiNetCateTitleTbl)q.getSingleResult();
        } catch(javax.persistence.NoResultException e){
            // 指定PKのデータが存在しない場合
            en = null;
        }

        return en;
    }

    /**
     * 最終見込損益 件数の取得
     * @param condition
     * @return 
     */
    public int countSyuKiNetCateTitle(Object condition) {
        int count = sqlExecutor.getCount(em, "/sql/syuKiNetCateTitleTbl/selectCountSyuKiNetCateTitleTbl.sql", condition);
        return count;
    }

    /**
     * 最終見込損益(新規登録)
     * @param _params
     * @return 
     */
    public int insertSyuKiNetCateTitleTbl(Map<String, Object> _params) {
        Map<String, Object> params = addParamLoginId(_params);
        int count = sqlExecutor.executeUpdateSql(em, "/sql/syuKiNetCateTitleTbl/insertSyuKiNetCateTitleTbl.sql", params);
        return count;
    }

    /**
     * NETカテゴリ(更新)
     * @param _params
     * @return 
     */
    public int updateSyuKiNetCateTitleTbl(Map<String, Object> _params) {
        Map<String, Object> params = addParamLoginId(_params);
        int count = sqlExecutor.executeUpdateSql(em, "/sql/syuKiNetCateTitleTbl/updateSyuKiNetCateTitleTbl.sql", params);
        return count;
    }

    /**
     * 最終見込損益(新規登録判定)
     * @param _params
     * @return 
     */
    public int entrySyuKiNetCateTitle(Map<String, Object> _params) {
        int count;

        // 検索
        count = this.countSyuKiNetCateTitle(_params);
        // 既存データ存在しない場合は新規登録
        if (count == 0) {
            count = this.insertSyuKiNetCateTitleTbl(_params);
        }

        return count;
    }
    
    /**
     * 項番一覧検索　条件用リストを取得(カテゴリ1)
     * @param condition
     * @return 
     */
    public List<SyuKiNetCateTitleTblView> getSearchList1(Map<String, Object> condition) {
        condition.put("no", "1");
//        List<SyuKiNetCateTitleTblView> list
//                = sqlExecutor.getResultList(em, SyuKiNetCateTitleTblView.class, "/sql/syuKiNetCateTitleTbl/selectSearchList1.sql", condition);
       
        List<SyuKiNetCateTitleTblView> list
                = sqlExecutor.getResultList(em, SyuKiNetCateTitleTblView.class, "/sql/syuKiNetCateTitleTbl/selectSearchList.sql", condition);

        return list;
    }
    
    /**
     * 項番一覧検索　条件用リストを取得(カテゴリ2)
     * @param condition
     * @return 
     */
    public List<SyuKiNetCateTitleTblView> getSearchList2(Map<String, Object> condition) {
        condition.put("no", "2");
        
//        List<SyuKiNetCateTitleTblView> list
//                = sqlExecutor.getResultList(em, SyuKiNetCateTitleTblView.class, "/sql/syuKiNetCateTitleTbl/selectSearchList2.sql", condition);
        
        List<SyuKiNetCateTitleTblView> list
                = sqlExecutor.getResultList(em, SyuKiNetCateTitleTblView.class, "/sql/syuKiNetCateTitleTbl/selectSearchList.sql", condition);

        return list;
    }

    /**
     * 項番カテゴリ設定　カテゴリ一覧取得(SYU_KI_NET_CATE_TITLE_TBL、SYU_SA_NET_CATE_TITLE_TBL両方に存在するデータ)
     * @param condition
     * @return 
     */
    public List<SyuKiNetCateTitleTbl> getSearchKobnCategory(Map<String, Object> condition) {

       List<SyuKiNetCateTitleTbl> list
                = sqlExecutor.getResultList(em, SyuKiNetCateTitleTbl.class, "/sql/syuKiNetCateTitleTbl/selectKobnCategory.sql", condition);
        
        return list;
    }
    
    /**
     * 指定した名前が登録されているかチェック
     * @param condition
     * @return 
     */
    public SyuKiNetCateTitleTbl getCategoryInfo(Map<String, Object> condition){
        SyuKiNetCateTitleTbl entity = null;
        
        List<SyuKiNetCateTitleTbl> list = sqlExecutor.getResultList(em, SyuKiNetCateTitleTbl.class, "/sql/syuKiNetCateTitleTbl/getCategoryInfo.sql", condition);
        
        if(list.size() > 0){
            entity = list.get(0);
        }
        
        return entity;
    }
    
    /**
     * NETカテゴリ一覧の取得
     * @param condition
     * @return 
     */
    public List<SyuKiNetCateTitleTbl> getCategoryList(Map<String, Object> condition){
        List<SyuKiNetCateTitleTbl> list = sqlExecutor.getResultList(em, SyuKiNetCateTitleTbl.class, "/sql/syuKiNetCateTitleTbl/getCategoryInfo.sql", condition);
        
        return list;
    }
    
    /**
     * カテゴリの削除
     */
    public void deleteCategory(Map<String, Object> condition){
        sqlExecutor.executeUpdateSql(em, "/sql/syuKiNetCateTitleTbl/deleteCategory.sql", condition);
    }
}
