/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package jp.co.toshiba.hby.pspromis.syuueki.entity;

import java.io.Serializable;
import java.math.BigDecimal;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

@Entity
public class SyuKiKaisyuTblView implements Serializable {

    private static final long serialVersionUID = 1L;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 32)
    @Column(name = "ANKEN_ID", nullable = false, length = 32)
    @Id
    private String ankenId;
    @Basic(optional = false)
    @NotNull
    @Column(name = "RIREKI_ID", nullable = false)
    @Id
    private int rirekiId;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 3)
    @Column(name = "CURRENCY_CODE", nullable = false, length = 3)
    @Id
    private String currencyCode;
    @Column(name = "DISP_SEQ")
    private String dispSeq;
    @NotNull
    @Column(name = "ZEI_KBN")
    @Id
    private String zeiKbn;
    @Column(name = "ZEI_DEFAULT_FLG")
    private BigDecimal zeiDefaultFlg;
    @NotNull
    @Column(name = "KINSYU_KBN")
    @Id
    private String kinsyuKbn;
    @NotNull
    @Column(name = "KAISYU_KBN")
    @Id
    private String kaisyuKbn;
    @Column(name = "NEW_FLG")
    private String newFlg;

    public SyuKiKaisyuTblView() {
    }

    public String getAnkenId() {
        return ankenId;
    }

    public void setAnkenId(String ankenId) {
        this.ankenId = ankenId;
    }

    /**
     * @return the rirekiId
     */
    public int getRirekiId() {
        return rirekiId;
    }

    /**
     * @param rirekiId the rirekiId to set
     */
    public void setRirekiId(int rirekiId) {
        this.rirekiId = rirekiId;
    }

    /**
     * @return the currencyCode
     */
    public String getCurrencyCode() {
        return currencyCode;
    }

    /**
     * @param currencyCode the currencyCode to set
     */
    public void setCurrencyCode(String currencyCode) {
        this.currencyCode = currencyCode;
    }

    /**
     * @return the syuekiYm
     */
    public String getDispSeq() {
        return dispSeq;
    }

    /**
     * @param dispSeq the syuekiYm to set
     */
    public void setDispSeq(String dispSeq) {
        this.dispSeq = dispSeq;
    }

    public String getZeiKbn() {
        return zeiKbn;
    }

    public void setZeiKbn(String zeiKbn) {
        this.zeiKbn = zeiKbn;
    }

    public BigDecimal getZeiDefaultFlg() {
        return zeiDefaultFlg;
    }

    public void setZeiDefaultFlg(BigDecimal zeiDefaultFlg) {
        this.zeiDefaultFlg = zeiDefaultFlg;
    }

    public String getKinsyuKbn() {
        return kinsyuKbn;
    }

    public void setKinsyuKbn(String kinsyuKbn) {
        this.kinsyuKbn = kinsyuKbn;
    }

    public String getKaisyuKbn() {
        return kaisyuKbn;
    }

    public void setKaisyuKbn(String kaisyuKbn) {
        this.kaisyuKbn = kaisyuKbn;
    }

    public String getNewFlg() {
        return newFlg;
    }

    public void setNewFlg(String newFlg) {
        this.newFlg = newFlg;
    }

}
