package jp.co.toshiba.hby.pspromis.common.util;

import org.eclipse.persistence.logging.AbstractSessionLog;
import org.eclipse.persistence.logging.SessionLog;
import org.eclipse.persistence.logging.SessionLogEntry;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;


public class CustomAbstractSessionLog extends AbstractSessionLog implements SessionLog {
    private static final Logger logger = LoggerFactory.getLogger(CustomAbstractSessionLog.class.getName());
    
    /* @see org.eclipse.persistence.logging.AbstractSessionLog#log(org.eclipse.persistence.logging.SessionLogEntry)
     */
    @Override
    public void log(SessionLogEntry sessionLogEntry) {
        if(sessionLogEntry.getLevel()==3){
            logger.info(sessionLogEntry.getMessage()); // untranslated/undecoded message_id
        }else{
            logger.debug(sessionLogEntry.getMessage()); // untranslated/undecoded message_id
        }
    }
}