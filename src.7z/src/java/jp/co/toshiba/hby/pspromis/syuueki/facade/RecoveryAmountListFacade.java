package jp.co.toshiba.hby.pspromis.syuueki.facade;

import java.util.List;
import javax.ejb.Stateless;
import javax.interceptor.Interceptors;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import jp.co.toshiba.hby.pspromis.syuueki.entity.RecoveryAmount;
import jp.co.toshiba.hby.pspromis.syuueki.interceptor.TranceInterceptor;
import org.apache.commons.collections4.CollectionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 *
 * @author sano
 */
@Stateless
@Interceptors({TranceInterceptor.class})
public class RecoveryAmountListFacade extends AbstractFacade<RecoveryAmount> {

    /**
     * ロガ－
     */
    private static final Logger logger = LoggerFactory.getLogger(RecoveryAmountListFacade.class);

    @PersistenceContext(unitName = jp.co.toshiba.hby.pspromis.syuueki.util.ConstantString.syuuekiDataSourceName)
    private EntityManager em;

    public RecoveryAmountListFacade() {
        super(RecoveryAmount.class);
    }

    @Override
    protected EntityManager getEntityManager() {
        return em;
    }

    /**
     * 回収見込を取得
     * @param condition
     * @return
     */
    // 2017/11/20 #072 ADD 回収Total行追加
    public RecoveryAmount findTotal(Object condition) {
        logger.info("RecoveryAmountListFacade#findTotal");

        //RecoveryAmount rec = sqlExecutor.getSingleResult(em, RecoveryAmount.class, "/sql/S004/selectKsRecoveryAmountTotal.sql", condition);
        //return rec;
        
        RecoveryAmount entity;
        List<RecoveryAmount> list = sqlExecutor.getResultList(em, RecoveryAmount.class, "/sql/S004/selectKsRecoveryAmountTotal.sql", condition);
        if (CollectionUtils.isNotEmpty(list)) {
            entity = list.get(0);
        } else {
            entity = new RecoveryAmount();
        }
        return entity;
    }

    /**
     * 回収見込を取得
     * @param condition
     * @return
     */
    public List<RecoveryAmount> findList(Object condition) {
        logger.info("RecoveryAmountListFacade#findList");

        List<RecoveryAmount> list =
                sqlExecutor.getResultList(em, RecoveryAmount.class, "/sql/S004/selectKsRecoveryAmount.sql", condition);

        return list;
    }

    /**
     * 回収見込を取得
     * @param condition
     * @return
     */
    public List<RecoveryAmount> findAllPreviousPeriodList(Object condition) {
        logger.info("RecoveryAmountListFacade#findPreviousPeriodList");

        List<RecoveryAmount> list =
                sqlExecutor.getResultList(em, RecoveryAmount.class, "/sql/S004/selectPreviousPeriodKsRecoveryAmountAll.sql", condition);

        return list;
    }

    /**
     * 回収見込を取得
     * @param condition
     * @return
     */
    public List<RecoveryAmount> findPreviousPeriodList(Object condition) {
        logger.info("RecoveryAmountListFacade#findPreviousPeriodList");

        List<RecoveryAmount> list =
                sqlExecutor.getResultList(em, RecoveryAmount.class, "/sql/S004/selectPreviousPeriodKsRecoveryAmount.sql", condition);

        return list;
    }

    /**
     * 回収金額の翌月反映元を取得
     * @param condition
     * @return
     */
    public RecoveryAmount findTargetReflect(Object condition) {
        logger.info("RecoveryAmountListFacade#findTargetReflect");

        //RecoveryAmount recoveryAmount = sqlExecutor.getSingleResult(em, RecoveryAmount.class, "/sql/S004/selectReflectTargetKaisyuAmount.sql", condition);
        //return recoveryAmount;
        
        RecoveryAmount entity;
        List<RecoveryAmount> list = sqlExecutor.getResultList(em, RecoveryAmount.class, "/sql/S004/selectReflectTargetKaisyuAmount.sql", condition);
        if (CollectionUtils.isNotEmpty(list)) {
            entity = list.get(0);
        } else {
            entity = new RecoveryAmount();
        }
        return entity;
        
    }
}
