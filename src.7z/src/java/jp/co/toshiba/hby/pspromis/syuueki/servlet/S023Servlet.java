/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package jp.co.toshiba.hby.pspromis.syuueki.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import javax.inject.Inject;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import jp.co.toshiba.hby.pspromis.syuueki.bean.AggregateConditionBean;
import jp.co.toshiba.hby.pspromis.syuueki.bean.S023Bean;
import jp.co.toshiba.hby.pspromis.syuueki.service.S023Service;
import jp.co.toshiba.hby.pspromis.syuueki.util.ParameterBinder;

/**
 *
 * @author rnomura
 */
@WebServlet(name = "S023Servlet", urlPatterns = {"/servlet/S023", "/servlet/S023/*"})
public class S023Servlet extends AbstractServlet {

    /**
     * jsp
     */
    private static final String INDEX_JSP = "S023/detailList.jsp";
    
    @Inject
    private S023Bean s023Bean;
    
    @Inject
    private AggregateConditionBean aggregateConditionBean;
    
    @Inject
    private S023Service s023Service;
    
    /**
     * 初期表示
     * @param req
     * @param resp
     * @return
     * @throws Exception 
     */
    public String indexAction(HttpServletRequest req, HttpServletResponse resp)
    throws Exception {
        logger.info("S022Servlet#indexAction");

        // リクエストパラメータをs022Beanの同名フィールドに一括コピー
        ParameterBinder.Bind(s023Bean, req);
        //ParameterBinder.Bind(aggregateConditionBean, req);
        // 一覧検索状態をクリアしておく。
        s023Bean.setListFlg("0");
        
        // サービスの実行(トランザクション単位)
        //s023Service.indexExecute();
        s023Service.listExecute();

        return INDEX_JSP;
    }
    
    /**
     * 一覧検索処理
     * @param req
     * @param resp
     * @return 
     * @throws Exception 
     */
    public String listAction(HttpServletRequest req, HttpServletResponse resp)
    throws Exception {
        logger.info("S022Servlet#listAction");
        
        // リクエストパラメータをs022Beanの同名フィールドに一括コピー
        ParameterBinder.Bind(s023Bean, req);

        s023Service.listExecute();
        
        return INDEX_JSP;
    }

}
