package jp.co.toshiba.hby.pspromis.syuueki.service;

import java.util.HashMap;
import java.util.Map;
import javax.ejb.Stateless;
import javax.inject.Inject;
import javax.interceptor.Interceptors;
import jp.co.toshiba.hby.pspromis.syuueki.bean.DispDataGetBean;
import jp.co.toshiba.hby.pspromis.syuueki.entity.SyuBatchLog;
import jp.co.toshiba.hby.pspromis.syuueki.facade.SyuBatchLogFacade;
import jp.co.toshiba.hby.pspromis.syuueki.interceptor.TranceInterceptor;

/**
 * PS-Promis収益管理システム
 * データ更新日確認ダイアログ表示 Service
 * @author ibayashi
 */
@Stateless
@Interceptors({TranceInterceptor.class})
public class DispDataGetService {

    @Inject
    private DispDataGetBean dispDataGetBean;
    
    @Inject
    private SyuBatchLogFacade syuBatchLogFacade;

    /**
     * 初期表示 ビジネスロジック
     */
    public void indexExecute() {
        Map<String, Object> condition = new HashMap<>();
        condition.put("result", "0");

        // 一般案件     発番実績・契約実績・売上実績
        // 進行基準案件 発番実績
        Map<String, Object> conditionAnkenDaily = new HashMap<>(condition);
        conditionAnkenDaily.put("batchId", "SYU_ANKEN_MAKE_DAILY");
        SyuBatchLog batchLogEntityAnkenDaily = syuBatchLogFacade.getMaxEndDate(conditionAnkenDaily);
        if (batchLogEntityAnkenDaily != null) {
            dispDataGetBean.setIppanHatJDate(batchLogEntityAnkenDaily.getEndTime());
            dispDataGetBean.setIppanKeiyakuJDate(batchLogEntityAnkenDaily.getEndTime());
            //dispDataGetBean.setIppanUriageJDate(batchLogEntityAnkenDaily.getEndTime());
            dispDataGetBean.setShinkoHatJDate(batchLogEntityAnkenDaily.getEndTime());
        }

        // 一般案件 売上実績・受注残、進行基準案件 受注残
        Map<String, Object> conditionJyucyuZan = new HashMap<>(condition);
        conditionJyucyuZan.put("batchId", "SYU_JYUCHUZAN_UPDATE");
        SyuBatchLog batchLogEntityJyucyuZan = syuBatchLogFacade.getMaxEndDate(conditionJyucyuZan);
        if (batchLogEntityJyucyuZan != null) {
            dispDataGetBean.setIppanUriageJDate(batchLogEntityJyucyuZan.getEndTime());
            dispDataGetBean.setIppanJyuchuZanDate(batchLogEntityJyucyuZan.getEndTime());
            dispDataGetBean.setShinkoJyuchuZanDate(batchLogEntityJyucyuZan.getEndTime());
        }

        // 一般案件 中計、進行基準案件 中計
        Map<String, Object> conditionChukei = new HashMap<>(condition);
        conditionChukei.put("batchId", "SYU_CHUKEI_UPDATE");
        SyuBatchLog batchLogEntityChukei = syuBatchLogFacade.getMaxEndDate(conditionChukei);
        if (batchLogEntityChukei != null) {
            dispDataGetBean.setIppanChukeiDate(batchLogEntityChukei.getEndTime());
            dispDataGetBean.setShinkoChukeiDate(batchLogEntityChukei.getEndTime());
        }

        // 進行基準案件 契約実績・売上実績
        Map<String, Object> conditionAnkenMonthly = new HashMap<>(condition);
        conditionAnkenMonthly.put("batchId", "SYU_ANKEN_MAKE_MONTHLY_G");
        SyuBatchLog batchLogEntityAnkenMonthly = syuBatchLogFacade.getMaxEndDate(conditionAnkenMonthly);
        if (batchLogEntityAnkenMonthly != null) {
            dispDataGetBean.setShinkoKeiyakuJDate(batchLogEntityAnkenMonthly.getEndTime());
            dispDataGetBean.setShinkoUriageJDate(batchLogEntityAnkenMonthly.getEndTime());
        }
    }
}
