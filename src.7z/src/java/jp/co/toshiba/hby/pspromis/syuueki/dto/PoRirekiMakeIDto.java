/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package jp.co.toshiba.hby.pspromis.syuueki.dto;

/**
 * PS-Promis収益管理システム
 * RDBMS 月次確定(or確定解除)・履歴データ作成処理パッケージCall用パラメータdto
 * @author (NPS)S.Ibayashi
 */
public class PoRirekiMakeIDto extends PoRirekiMakeDto {

    /**
     * Ｃ部課コード
     */
    private String cBukaCd;

    /**
     * チームコード
     */
    private String teamCode;

    /**
     * 本社/支社区分
     */
    private String honsyaShisyaKbn;

    public String getcBukaCd() {
        return cBukaCd;
    }

    public void setcBukaCd(String cBukaCd) {
        this.cBukaCd = cBukaCd;
    }

    public String getTeamCode() {
        return teamCode;
    }

    public void setTeamCode(String teamCode) {
        this.teamCode = teamCode;
    }

    public String getHonsyaShisyaKbn() {
        return honsyaShisyaKbn;
    }

    public void setHonsyaShisyaKbn(String honsyaShisyaKbn) {
        this.honsyaShisyaKbn = honsyaShisyaKbn;
    }

}
