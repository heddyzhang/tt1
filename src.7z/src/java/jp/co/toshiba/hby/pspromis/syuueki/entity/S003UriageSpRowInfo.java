package jp.co.toshiba.hby.pspromis.syuueki.entity;

import java.io.Serializable;
import java.math.BigDecimal;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;

/**
 *
 * @author
 */
@Entity
public class S003UriageSpRowInfo implements Serializable {
    private static final long serialVersionUID = 1L;
    @Id
    @Column(name = "ANKEN_ID")
    private String ankenId;
    @Id
    @Column(name = "RIREKI_ID")
    private String rirekiId;
    @Id
    @Column(name = "CURRENCY_CODE")
    private String currencyCode;
    @Column(name = "CURRENCY_CODE_SEQ")
    private String currencyCodeSeq;
    @Id
    @Column(name = "RENBAN")
    private String renban;
    @Column(name = "RENBAN_SEQ")
    private BigDecimal renbanSeq;
    @Column(name = "URIAGE_YM")
    private String uriageYm;
    @Column(name = "ORDER_NO")
    private String orderNo;
    @Column(name = "RENBAN_HEAD")
    private String renbanHead;
    @Column(name = "KEIYAKU_RATE")
    private BigDecimal keiyakuRate;
    @Column(name = "ROWSPAN_COUNT")
    private BigDecimal rowspanCount;
    @Column(name = "ROWSPAN_KEY_INFO")
    private String rowspanKeyInfo;
    
    public S003UriageSpRowInfo() {
    }

    public String getAnkenId() {
        return ankenId;
    }

    public void setAnkenId(String ankenId) {
        this.ankenId = ankenId;
    }

    public String getRirekiId() {
        return rirekiId;
    }

    public void setRirekiId(String rirekiId) {
        this.rirekiId = rirekiId;
    }

    public String getCurrencyCode() {
        return currencyCode;
    }

    public void setCurrencyCode(String currencyCode) {
        this.currencyCode = currencyCode;
    }

    public String getCurrencyCodeSeq() {
        return currencyCodeSeq;
    }

    public void setCurrencyCodeSeq(String currencyCodeSeq) {
        this.currencyCodeSeq = currencyCodeSeq;
    }

    public String getRenban() {
        return renban;
    }

    public void setRenban(String renban) {
        this.renban = renban;
    }

    public BigDecimal getRenbanSeq() {
        return renbanSeq;
    }

    public void setRenbanSeq(BigDecimal renbanSeq) {
        this.renbanSeq = renbanSeq;
    }

    public String getOrderNo() {
        return orderNo;
    }

    public void setOrderNo(String orderNo) {
        this.orderNo = orderNo;
    }

    public String getUriageYm() {
        return uriageYm;
    }

    public void setUriageYm(String uriageYm) {
        this.uriageYm = uriageYm;
    }

    public String getRenbanHead() {
        return renbanHead;
    }

    public void setRenbanHead(String renbanHead) {
        this.renbanHead = renbanHead;
    }

    public BigDecimal getKeiyakuRate() {
        return keiyakuRate;
    }

    public void setKeiyakuRate(BigDecimal keiyakuRate) {
        this.keiyakuRate = keiyakuRate;
    }

    public BigDecimal getRowspanCount() {
        return rowspanCount;
    }

    public void setRowspanCount(BigDecimal rowspanCount) {
        this.rowspanCount = rowspanCount;
    }

    public String getRowspanKeyInfo() {
        return rowspanKeyInfo;
    }

    public void setRowspanKeyInfo(String rowspanKeyInfo) {
        this.rowspanKeyInfo = rowspanKeyInfo;
    }

}

