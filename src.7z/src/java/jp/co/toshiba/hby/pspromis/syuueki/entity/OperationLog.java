package jp.co.toshiba.hby.pspromis.syuueki.entity;

import java.util.Date;

/**
 * 操作ログentity<br>
 * PKが存在しないため、JPA管理のentityにはせずに、dtoとして扱う
 * @author ibayashi
 */
public class OperationLog {

    private String operationCode;

    private long objectId;

    private String objectType;

    private Date operationDate;

    private String userId;

    private String userName;

    private String jgrpId;

    private String jgrpName;

    private String departmentCd;

    private String departmentName;

    private String remarks;

    private String remarks2;

    private String remarks3;

    private String remarks4;

    private String remarks5;

    public OperationLog() {
    }

    public String getOperationCode() {
        return operationCode;
    }

    public void setOperationCode(String operationCode) {
        this.operationCode = operationCode;
    }

    public long getObjectId() {
        return objectId;
    }

    public void setObjectId(long objectId) {
        this.objectId = objectId;
    }

    public String getObjectType() {
        return objectType;
    }

    public void setObjectType(String objectType) {
        this.objectType = objectType;
    }

    public Date getOperationDate() {
        return operationDate;
    }

    public void setOperationDate(Date operationDate) {
        this.operationDate = operationDate;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getJgrpId() {
        return jgrpId;
    }

    public void setJgrpId(String jgrpId) {
        this.jgrpId = jgrpId;
    }

    public String getJgrpName() {
        return jgrpName;
    }

    public void setJgrpName(String jgrpName) {
        this.jgrpName = jgrpName;
    }

    public String getDepartmentCd() {
        return departmentCd;
    }

    public void setDepartmentCd(String departmentCd) {
        this.departmentCd = departmentCd;
    }

    public String getDepartmentName() {
        return departmentName;
    }

    public void setDepartmentName(String departmentName) {
        this.departmentName = departmentName;
    }

    public String getRemarks() {
        return remarks;
    }

    public void setRemarks(String remarks) {
        this.remarks = remarks;
    }

    public String getRemarks2() {
        return remarks2;
    }

    public void setRemarks2(String remarks2) {
        this.remarks2 = remarks2;
    }

    public String getRemarks3() {
        return remarks3;
    }

    public void setRemarks3(String remarks3) {
        this.remarks3 = remarks3;
    }

    public String getRemarks4() {
        return remarks4;
    }

    public void setRemarks4(String remarks4) {
        this.remarks4 = remarks4;
    }

    public String getRemarks5() {
        return remarks5;
    }

    public void setRemarks5(String remarks5) {
        this.remarks5 = remarks5;
    }
}
