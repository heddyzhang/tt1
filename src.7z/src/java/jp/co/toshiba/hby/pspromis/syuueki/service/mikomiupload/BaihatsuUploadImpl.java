/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package jp.co.toshiba.hby.pspromis.syuueki.service.mikomiupload;

import java.math.BigDecimal;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.ejb.Stateless;
import javax.inject.Inject;
import javax.interceptor.Interceptors;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import jp.co.toshiba.hby.pspromis.common.util.StringUtil;
import jp.co.toshiba.hby.pspromis.syuueki.bean.MikomiUploadBean;
import jp.co.toshiba.hby.pspromis.syuueki.bean.MikomiUploadErrorBean;
import jp.co.toshiba.hby.pspromis.syuueki.entity.SyuGeBukkenInfoTbl;
import jp.co.toshiba.hby.pspromis.syuueki.enums.MikomiUploadLabel;
import jp.co.toshiba.hby.pspromis.syuueki.interceptor.TranceInterceptor;
import jp.co.toshiba.hby.pspromis.syuueki.util.PoiUtil;
import jp.co.toshiba.hby.pspromis.syuueki.util.Utils;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.time.DateUtils;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * PS-Promis収益管理システム
 * 見込アップロード処理「売発費(ｳﾘﾊﾂﾋ)」
 * @author (NPC)kitajima
 */
@Stateless
@Interceptors({TranceInterceptor.class})
public class BaihatsuUploadImpl implements UploadComponent {
 
    @PersistenceContext(unitName = jp.co.toshiba.hby.pspromis.syuueki.util.ConstantString.syuuekiDataSourceName)
    private EntityManager em;

    // タイトル
    private final String THIS_SHEET_TITLE = "工事進行基準注入額一覧（工場売発費；ＬＣ扱い国内）";
    // 案件フラグ
    private final String MATOME_ANKEN_FLG = "1";
    // データの開始列
    private final int DATA_START_ROW = 10;
    // データの開始行
    private final int DATA_START_COL = 6;
    // 見出し行
    private final int HEADLINE_COL = 5;
    // カテゴリー区分
    private final String CATEGORY_KBN = "URIHATSU";
    
    /**
     * ロガー
     */
    public static final Logger logger = LoggerFactory.getLogger(BaihatsuUploadImpl.class);
    
    @Inject
    private MikomiUploadBean mikomiUploadBean;
    
    @Inject
    private MikomiUploadErrorBean mikomiUploadErrorBean;
    
    
    @Inject
    private UploadDataAccess uploadDataAccess;
    
    /**
     * 処理対象ワークシートの取得
     */
    private Sheet getTargetSheet() {
        Sheet sheet = (mikomiUploadBean.getWorkBook()).getSheetAt(1);
        return sheet;
    }
    
    /**
     * 入力内容のデータチェック
     * @return 
     * @throws java.lang.Exception
     */
    @Override
    public boolean isDataCheck() throws Exception {
        logger.info("BaihatsuUploadImpl isDataCheck");
        
        boolean isCheck = false; 
        
        // 作業対象シートを取得
        Sheet targetSheet = getTargetSheet();
        
        // Excelのタイトル(工場名)チェック
        isCheck = isCheckTitile(targetSheet);
        
        if (isCheck) {
            // Excel上の一覧を読み取って、DBに登録する値の取得/エラーチェックを行う。
            isCheck = exeGetData(targetSheet);
        }
        
        // beanに成功/失敗FLGをセット
        mikomiUploadErrorBean.setIsSuccess(isCheck);

        return isCheck;
    }

    /**
     * Excelのタイトルチェック
     */
    private boolean isCheckTitile(Sheet sheet) {
        String errorMessage = MikomiUploadLabel.getValue(MikomiUploadLabel.titleFormatError);
        
        Cell titleCell = PoiUtil.getCell(sheet, 1, 4);

        String title = (String)PoiUtil.getCellValue(titleCell);
        
        boolean isSuccess = false;

        String kbn = StringUtils.defaultString(mikomiUploadBean.getUploadKbn());

        if (!StringUtil.isEmpty(title)) {
            // 末尾が一致するか
            if (title.endsWith(this.THIS_SHEET_TITLE) && kbn.equals("08")) {
                isSuccess = true;
            }
        }
 
        if (!isSuccess) {
            mikomiUploadErrorBean.addErrorMessage(errorMessage);
        }

        return isSuccess;
    }
    
    /**
     * Excel上の一覧を読み取って、DBに登録する値の取得/エラーチェックを行う
     */
    private boolean exeGetData(Sheet sheet) throws Exception {
        int errorRow;
        boolean isSuccess = true;
        
        SyuGeBukkenInfoTbl bukkenEn = null;
        Map<String, Object> categoryMstInfo = null;
        
        ArrayList<Map<String, Object>> dataList = new ArrayList<>();
        ArrayList<Map<String, Object>> wDataList = new ArrayList<>();
        
        // エラーメッセージ
        String monthBeforeError = MikomiUploadLabel.getValue(MikomiUploadLabel.monthBeforeError);
        String monthFormatError = MikomiUploadLabel.getValue(MikomiUploadLabel.monthFormatError);
        
        Row row;
        Cell cell;
        String thisMonth ="";
        String beforeMonth ="";
        String nextMonth = "";
        String amount = "";
        int endCnt = DATA_START_ROW;
        
        //有効日付配列を取得
        row = sheet.getRow(HEADLINE_COL);
        for ( int cnt = DATA_START_ROW; cnt <=1000; cnt++ ) {

            cell = PoiUtil.getCell(row, cnt);
            if (cell == null) {
                break;
            }

            //日付取得
            String rawData = Utils.getObjToStrValue(PoiUtil.getCellValue(cell));
            if(StringUtils.isEmpty(rawData)){
                break;
            }
            
            endCnt++;
        }

        ///////// 日付取得/チェック ////////////
        if (endCnt > DATA_START_ROW) {       
            for (int cnt=endCnt; cnt>DATA_START_ROW; cnt--) {
                Map<String, Object> dataMap = new HashMap<>();

                cell = row.getCell(cnt);
                thisMonth = Utils.getObjToStrValue(PoiUtil.getCellValue(cell));

                int cnt2 = cnt - 1;
                Cell cell2 = PoiUtil.getCell(row, cnt2);
                beforeMonth = Utils.getObjToStrValue(PoiUtil.getCellValue(cell2));

                // 見出しが"前回"or"差異"は対象外
                while(beforeMonth.equals("前回") || beforeMonth.equals("差異") ){
                    cnt2 = cnt2-2;
                    cell2 = PoiUtil.getCell(row, cnt2);
                    beforeMonth = Utils.getObjToStrValue(PoiUtil.getCellValue(cell2));
                }

                String dataMonth = ConvCellDate(thisMonth, beforeMonth, mikomiUploadBean.getStartYm());            
                //日付エラーチェック
                if(dataMonth.equals(monthFormatError)){
                    isSuccess = false;
                    errorRow = row.getRowNum()+1;
                    mikomiUploadErrorBean.addErrorMessage(thisMonth + "：" + "(" + errorRow + ")行目：" + dataMonth + "(" + thisMonth + ")");
                    continue;
                }

                //注入見込集計開始年月前のデータならループを抜ける、取込不要データならcontinue
                if(dataMonth.equals("noUpdate")){
                    continue;
                }else if(dataMonth.equals("exitLoop")){
                    break;
                }

                //日付配列の並びチェック
                if(!nextMonth.equals("")){
                    DateFormat df = new SimpleDateFormat("yyyyMM");
                    if ( !nextMonth.equals(monthFormatError)
                       && !nextMonth.equals(monthBeforeError)
                       && !dataMonth.equals(monthFormatError)
                       && !dataMonth.equals(monthBeforeError)){

                        Date nextDateMonth = df.parse(nextMonth);						    	
                        Date thisDateMonth = df.parse(dataMonth);

                        if(thisDateMonth.after(nextDateMonth)){
                            dataMonth = monthBeforeError;
                        }
                    }
                }

                //日付エラーチェック
                if (dataMonth.equals(monthBeforeError)) {
                    isSuccess = false;
                    errorRow = row.getRowNum()+1;
                    mikomiUploadErrorBean.addErrorMessage(thisMonth + "：" + "(" + errorRow + ")行目：" + dataMonth + "(" + thisMonth + ")");
                    continue;
                }
/*
                else{
                    dataMap.put("colNo", String.valueOf(cnt));
                }
*/
                dataMap.put("colNo", String.valueOf(cnt));
                dataMap.put("updateDate", dataMonth);
                dataMap.put("rawDate", thisMonth);

                //配列セット
                wDataList.add(dataMap);
                nextMonth = Utils.getObjToStrValue(dataMap.get("updateDate"));
            }


            //エラー無しなら注番と金額取得
            if(mikomiUploadErrorBean.getErrorMessage() == null || mikomiUploadErrorBean.getErrorMessage().isEmpty()) {

                for ( int cnt = 6; cnt < sheet.getLastRowNum(); cnt++ ) {
                    String ankenFlg = "";
                    String orderNo = "";
                    String orderNoKbn = "";
                    String dataOrderNo = "";
                    boolean isDateSet = false;

                    Row row2 = PoiUtil.getRow(sheet, cnt);
                    cell = PoiUtil.getCell(row2, 8);

                    if ("物件計".equals(Utils.getObjToStrValue(PoiUtil.getCellValue(cell)))) {
                        cell = PoiUtil.getCell(row2, 9);
                        if ("合計".equals(Utils.getObjToStrValue(PoiUtil.getCellValue(cell)))) {
                            break;
                        }

                        cell = PoiUtil.getCell(row2, 5);
                        orderNo = Utils.getObjToStrValue(PoiUtil.getCellValue(cell));

                        // 注番セルが空のときはスルー
                        if (!UploadUtil.isTargetOrderNo(orderNo)) {
                            continue;
                        }

                        // 注番セルの上行に"代表"と書かれているか？
                        Row row3 = PoiUtil.getRow(sheet, cnt - 1);
                        cell = PoiUtil.getCell(row3, 5);
                        orderNoKbn = Utils.getObjToStrValue(PoiUtil.getCellValue(cell));
                        ankenFlg = "0";
                        // "代表"の場合は纏め案件として扱う。無い場合は子案件として扱う
                        if ("代表".equals(orderNoKbn)) {
                            ankenFlg = this.MATOME_ANKEN_FLG;
                        }

                        // 案件情報の検索
                        bukkenEn = uploadDataAccess.findOnoBuken(orderNo, ankenFlg);
                        if (bukkenEn == null || !bukkenEn.getDivisionCode().equals(mikomiUploadBean.getUploadDivisionCode())) {
                            isSuccess = false;
                            errorRow = cnt + 1;
                            mikomiUploadErrorBean.addErrorMessage("(" + errorRow + ")行目：" + MikomiUploadLabel.getValue(MikomiUploadLabel.projectError) + "(" + orderNo + ")");
                            continue;
                        }
                        dataOrderNo = ankenFlg.equals("1") ? bukkenEn.getMainOrderNo() : bukkenEn.getOrderNo();

                        // 注入金額の取得
                        for (int cnt2 = 0; cnt2 < wDataList.size(); cnt2++) {
                            Map<String, Object> wDataItem = wDataList.get(cnt2);
                            Map<String, Object> dataItem = new HashMap<>();

                            dataItem.put("updateDate", wDataItem.get("updateDate"));
                            dataItem.put("rawDate", wDataItem.get("rawDate"));
                            //dataItem.put("chuban", orderNo);
                            dataItem.put("chuban", dataOrderNo);
                            dataItem.put("ankenId", bukkenEn.getAnkenId());

                            Cell cell2 = row2.getCell(Integer.parseInt(Utils.getObjToStrValue(wDataItem.get("colNo"))));
                            String rawData = Utils.getObjToStrValue(PoiUtil.getCellValue(cell2));

                            // 注入金額の入力チェック
                            amount = changeAmountStr(rawData);

                            if ("formatError".equals(amount)) {
                                isSuccess = false;
                                //errorRow = row.getRowNum() + 1;
                                errorRow = row2.getRowNum() + 1;
                                mikomiUploadErrorBean.addErrorMessage(orderNo + "(" + errorRow + ")行目：" + dataItem.get("rawDate") + "：" + MikomiUploadLabel.getValue(MikomiUploadLabel.chunyuAmountFormatError) + "(" + rawData + ")");

                            } else if ("ketaOverError".equals(amount)) {
                                isSuccess = false;
                                //errorRow = row.getRowNum() + 1;
                                errorRow = row2.getRowNum() + 1;
                                mikomiUploadErrorBean.addErrorMessage(orderNo + "(" + errorRow + ")行目：" + dataItem.get("rawDate") + "：" + MikomiUploadLabel.getValue(MikomiUploadLabel.chunyuAmountKetaFormatError) + "(" + rawData + ")");
                            }

                            dataItem.put("chunyu", amount);
                            dataList.add(dataItem);
                            
                            isDateSet = true;
                        }

                        if (isDateSet) {
                            // 正常終了時のため、結果子画面に出力するメッセージ(案件番号/注番)を登録
                            mikomiUploadErrorBean.addMessage("■" + bukkenEn.getAnkenId() + "/" + dataOrderNo);
                        }
                    }
                }  
            }

            //エラー無しなら処理を続行
            if(mikomiUploadErrorBean.getErrorMessage() == null || mikomiUploadErrorBean.getErrorMessage().isEmpty()) {

                // 重複注番の金額合算
                for(int cnt3 = 0; cnt3 < dataList.size(); cnt3++){
                    Map<String, Object> wDataItem2 = dataList.get(cnt3);

                    for(int cnt4 = 0; cnt4 < dataList.size(); cnt4++){
                        if(cnt3 == cnt4){
                            continue;
                        }
                        Map<String, Object> checkItem = dataList.get(cnt4);

                        // 注番と日付が等しいとき合算
                        if((Utils.getObjToStrValue(wDataItem2.get("chuban")).equals(Utils.getObjToStrValue(checkItem.get("chuban")))) 
                                && (Utils.getObjToStrValue(wDataItem2.get("updateDate")).equals(Utils.getObjToStrValue(checkItem.get("updateDate"))))){
                            BigDecimal bd1 = new BigDecimal(Utils.getObjToStrValue(wDataItem2.get("chunyu")));
                            BigDecimal bd2 = new BigDecimal(Utils.getObjToStrValue(checkItem.get("chunyu")));                 
                            wDataItem2.put("chunyu", String.valueOf(bd1.add(bd2)));

                            dataList.remove(cnt3);
                            dataList.add(cnt3, wDataItem2);
                            dataList.remove(cnt4);		
                        }
                    }   
                }
                
                // 登録内容の格納
                // カテゴリマスタからCATEGORY_CODE,CATEGORY_CODE1,CATEGORY_CODE2等を取得(1回のみ)
                if (categoryMstInfo == null) {
                    categoryMstInfo = uploadDataAccess.categoryMstInfo(this.CATEGORY_KBN);
                }

                for (int i=0; i<dataList.size(); i++) {
                    Map<String, Object> dataMap = new HashMap<>();
                    Map<String, Object> dataSet = dataList.get(i);

                    dataMap.put("orderNo", dataSet.get("chuban"));
                    dataMap.put("ankenId", dataSet.get("ankenId"));
                    dataMap.put("rirekiId", 0);
                    dataMap.put("dataKbn", "M");
                    dataMap.put("syuekiYm", dataSet.get("updateDate"));
                    dataMap.put("categoryCode", categoryMstInfo.get("CATEGORY_CODE"));
                    dataMap.put("categoryKbn1", categoryMstInfo.get("CATEGORY_KBN1"));
                    dataMap.put("categoryKbn2", categoryMstInfo.get("CATEGORY_KBN2"));
                    dataMap.put("categoryName1", categoryMstInfo.get("CATEGORY_NAME1"));
                    dataMap.put("categoryName2", categoryMstInfo.get("CATEGORY_NAME2"));
                    dataMap.put("categorySeq", categoryMstInfo.get("CATEGORY_SEQ"));
                    dataMap.put("net", Utils.changeBigDecimal((String)dataSet.get("chunyu")));

                    mikomiUploadBean.addDataList(dataMap);

                }
            }
        }
        return isSuccess;
    }
        
    /**
     * 日付データの読込み<BR>
     * セルの値が「YYYY年MM月DD日」のとき使用
     * @param cell
     * @return
     */
    private String ConvCellDate(String thisMonth, String beforeMonth, Date startMonth) {
        String retStr = "";	
        String retStr2 = "";	
        int dateInt = 0;

        try {
            if(StringUtils.isEmpty(thisMonth)){
                return "noUpdate";
            }

            if (StringUtils.isNotEmpty(thisMonth)) {
                retStr = Utils.convertToHankaku(thisMonth);		
                retStr = StringUtils.replace(retStr, "/", "");
            }

            if (StringUtils.isNotEmpty(beforeMonth)) {
                retStr2 = Utils.convertToHankaku(beforeMonth);		
                retStr2 = StringUtils.replace(retStr2, "/", "");     	
            }

            if (retStr.endsWith("上実績") || retStr.endsWith("下実績")) {
                dateInt = -6;
            }else if (retStr.endsWith("1Q実績") || retStr.endsWith("1Q計画")) {
                dateInt = -3;	
            }else if (retStr.endsWith("2Q実績") || retStr.endsWith("2Q計画")) {
                dateInt = -3;
            }else if (retStr.endsWith("3Q実績") || retStr.endsWith("3Q計画")) {
                dateInt = -3;
            }else if (retStr.endsWith("4Q実績") || retStr.endsWith("4Q計画")) {
                dateInt = -3;
            }else if (retStr.endsWith("上計画") || retStr.endsWith("上")) {
                dateInt = -6;
            }else if (retStr.endsWith("下計画")|| retStr.endsWith("下")) {
                dateInt = -6;
            }else if (retStr.endsWith("年度")||retStr.endsWith("年度以降")) {
                dateInt = -12;
            }		
            
            retStr = ConvCellDateLogic(retStr);
            if(retStr.equals("noUpdate") || retStr.equals("差異") || retStr.startsWith("前回")){
                return "noUpdate";
            }

            retStr2 = ConvCellDateLogic(retStr2);
            Date date = UploadUtil.changeStrToDate(retStr);
            retStr = UploadUtil.changeDateToStr(date);

            if(StringUtils.isNotEmpty(retStr2) && !retStr2.equals("差異") && !retStr2.equals("前回")&& !retStr2.equals("費目")){
                // beforeMonth側のエラーは、エラーメッセージに追加しない
                Date date3;
                try {
                    date3 = UploadUtil.changeStrToDate(retStr2);
                } catch(Exception e) {
                    return "noUpdate";
                }
                
                if(dateInt < 0 ){
                    date = DateUtils.addMonths(date, dateInt); 
                    if(date.before(date3)){
                        return "noUpdate";
                        
                    }
                }
            }

            //  処理対象年月 > 画面.注入見込開始年月
            if(date.before(startMonth)){ 
                retStr = "exitLoop";
                return retStr;
            }

        } catch (Exception e) {
            retStr = MikomiUploadLabel.getValue(MikomiUploadLabel.monthFormatError);
        }

        return retStr;
    }
    
    /**
    * 日付データの読込み<BR>
    * セルの値が「YYYY年MM月DD日」のとき使用
    * @param cell
    * @return
    */
    private String ConvCellDateLogic(String retStr) {
        
        try {
            if (retStr.endsWith("1Q実績") || retStr.endsWith("1Q計画")) {
                retStr = StringUtils.replace(retStr, "1Q実績", "06");
                retStr = StringUtils.replace(retStr, "1Q計画", "06");
            
            } else if (retStr.endsWith("上実績")
                    || retStr.endsWith("上計画")
                    || retStr.endsWith("2Q実績")
                    || retStr.endsWith("2Q計画")
                    || retStr.endsWith("上")) {
                retStr = StringUtils.replace(retStr, "上実績", "09");
                retStr = StringUtils.replace(retStr, "上計画", "09");
                retStr = StringUtils.replace(retStr, "2Q実績", "09");
                retStr = StringUtils.replace(retStr, "2Q計画", "09");
                retStr = StringUtils.replace(retStr, "上", "09");
                
            } else if (retStr.endsWith("3Q実績")
                    || retStr.endsWith("3Q計画")) {
                retStr = StringUtils.replace(retStr, "3Q実績", "12");
                retStr = StringUtils.replace(retStr, "3Q計画", "12");

            } else if ( retStr.endsWith("下実績")
                     || retStr.endsWith("下計画")
                     || retStr.endsWith("4Q実績")
                     || retStr.endsWith("4Q計画")
                     || retStr.endsWith("下")
                     || retStr.endsWith("年度")
                     || retStr.endsWith("年度以降")) {
                retStr = StringUtils.replace(retStr, "下実績", "03");
                retStr = StringUtils.replace(retStr, "下計画", "03");
                retStr = StringUtils.replace(retStr, "4Q実績", "03");
                retStr = StringUtils.replace(retStr, "4Q計画", "03");
                retStr = StringUtils.replace(retStr, "年度以降", "03");
                retStr = StringUtils.replace(retStr, "年度", "03");
                retStr = StringUtils.replace(retStr, "下", "03");
                
                retStr = UploadUtil.nenAdd1(retStr);
                
            } else if (retStr.endsWith("実績") || retStr.endsWith("計画") ) {
                retStr = StringUtils.replace(retStr, "実績", "");		
                retStr = StringUtils.replace(retStr, "計画", "");		
                
            } else if (retStr.endsWith("差異")) {
                retStr = "差異";
                
            } else if (retStr.startsWith("前回")) {
                retStr = "前回";	
                
            }else if (retStr.startsWith("費目")) {
                retStr = "費目";

            }	

            retStr = Utils.convertToHankaku(retStr);
            retStr = StringUtils.replace(retStr, "/", "");

        } catch (Exception e) {
            retStr = "noUpdate";
        }

         return retStr;
    }

    private String changeAmountStr(String str) {
        String amount = str;

        logger.info("amount=" + amount + " isNum=" + Utils.isNumeric(amount));

        if (!Utils.isNumeric(amount)) {
            return "formatError";
        } else {
            BigDecimal dAmount = Utils.changeBigDecimal(amount);
            if (dAmount != null) {
                amount = dAmount.setScale(3, BigDecimal.ROUND_HALF_UP).multiply(new BigDecimal(1000000)).toString();
                amount = UploadUtil.changeAmountStrSub(amount);
                if (StringUtils.length(amount) > 16) {
                    return "ketaOverError";
                }
            }
        }
        return amount;
    }

    /**
     * アップロード処理の実行
     * @throws java.lang.Exception
     */
    @Override
    public void executeUpload() throws Exception {
        logger.info("BaihatsuUploadImpl executeUpload");
        
        // データの登録
        List<Map<String, Object>> dataList = mikomiUploadBean.getDataList();
        
        if (dataList == null) {
            return;
        }
        
        // データを登録
        String ankenId = "";
        String befAnkenId = "";
        
        for (Map<String, Object> data : dataList) {
            ankenId = (String)data.get("ankenId");
            
            // SYU_KI_NET_CATE_TITLE_TBLの新規登録
            if (!befAnkenId.equals(ankenId)) {
                uploadDataAccess.insertKiNetCateTitleTbl(data);
                
                // 指定案件に対して再計算FLGを立てる(進行基準画面の再計算ボタン用)。
                uploadDataAccess.setSaikeisanFlg(ankenId, (Integer)data.get("rirekiId"));
            }

            // SYU_KI_NET_CATE_TUKI_TBLの更新(or新規登録)
            uploadDataAccess.updateKiNetCateTukiTbl(data);
            
            befAnkenId = ankenId;
        }
    }
}
