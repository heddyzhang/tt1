package jp.co.toshiba.hby.pspromis.syuueki.service;

import java.math.BigDecimal;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.ejb.Stateless;
import javax.inject.Inject;
import javax.interceptor.Interceptors;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import jp.co.toshiba.hby.pspromis.syuueki.bean.S014Bean;
import jp.co.toshiba.hby.pspromis.syuueki.dto.PoRirekiMakeDto;
import jp.co.toshiba.hby.pspromis.syuueki.entity.JgrpMemberTbl;
import jp.co.toshiba.hby.pspromis.syuueki.entity.SyuWfControlTbl;
import jp.co.toshiba.hby.pspromis.syuueki.entity.StringEntity;
import jp.co.toshiba.hby.pspromis.syuueki.enums.Label;
import jp.co.toshiba.hby.pspromis.syuueki.facade.JgrpMemberTblFacade;
import jp.co.toshiba.hby.pspromis.syuueki.facade.SyuWfControlTblFacade;
import jp.co.toshiba.hby.pspromis.syuueki.interceptor.TranceInterceptor;
import jp.co.toshiba.hby.pspromis.syuueki.jdbc.DbUtilsExecutor;
import jp.co.toshiba.hby.pspromis.common.jdbc.SqlExecutor;
import jp.co.toshiba.hby.pspromis.syuueki.dto.PoRirekiMakeIDto;
//import jp.co.toshiba.hby.pspromis.syuueki.enums.Env;
import jp.co.toshiba.hby.pspromis.syuueki.facade.KanjyoMstFacade;
import jp.co.toshiba.hby.pspromis.syuueki.jdbc.SqlFile;
import jp.co.toshiba.hby.pspromis.syuueki.util.ConstantString;
import jp.co.toshiba.hby.pspromis.syuueki.util.LoginUserInfo;
import jp.co.toshiba.hby.pspromis.syuueki.util.PoiUtil;
import jp.co.toshiba.hby.pspromis.syuueki.util.SyuuekiUtils;
import jp.co.toshiba.hby.pspromis.syuueki.util.Utils;
import jp.co.toshiba.hby.pspromis.syuueki.pages.DivisonComponentPage;
import org.apache.commons.beanutils.PropertyUtils;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.poi.ss.util.CellRangeAddress;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
/**
 * PS-Promis収益管理システム
 * 月次確定詳細 Service
 * @author (NPC)S.Ibayashi
 */
@Stateless
@Interceptors({TranceInterceptor.class})
public class S014Service {

    /**
     * ステータス 確定/承認
     */
    private final String STATUS_KAKUTEI = ConstantString.wfStatusKakutei;

    /**
     * ステータス 作成中/否認
     */
    private final String STATUS_CREATING = ConstantString.wfStatusCreating;

    /**
     * ステータス 提出用
     */
    private final String STATUS_TEISHUTSU = ConstantString.wfStatusTeishutsu;

    /**
     * ロガー
     */
    public static final Logger logger = LoggerFactory.getLogger(S014Service.class);

    @PersistenceContext(unitName = jp.co.toshiba.hby.pspromis.syuueki.util.ConstantString.syuuekiDataSourceName)
    private EntityManager em;

    /**
     * パラメータ格納クラスをinjection(CDI)<br>
     * InjectアノテーションよりAPサーバー(Glassfish)側で自動的にインスタンス作成(new)される。<br>
     */
    @Inject
    private S014Bean s014Bean;

    /**
     * Injection loginUserInfo
     * (ユーザー情報(ユーザーid,名称,所属部課名)を格納したオブジェクト)
     */
    @Inject
    private LoginUserInfo loginUserInfo;

    /**
     * Injection sqlExecutor
     */
    @Inject
    protected SqlExecutor sqlExecutor;

    /**
     * Injection dbUtilsExecutor
     */
    @Inject
    private DbUtilsExecutor dbUtilsExecutor;
    
    /**
     * Injection SyuuekiUtils
     */
    @Inject
    private SyuuekiUtils syuuekiUtils;

    @Inject
    private SyuWfControlTblFacade syuWfControlTblFacade;

    @Inject
    private JgrpMemberTblFacade jgrpMemberTblFacade;
    
    @Inject
    private StoredProceduresService storedProceduresService;

    @Inject
    private KanjyoMstFacade kanjyoMstFacade;

    @Inject
    private DivisonComponentPage divisionComponentPage;

    /**
     * 確定済みであるかをチェック
     */
    private boolean isKakutei() {
        return STATUS_KAKUTEI.equals(s014Bean.getStatus());
    }

    /**
     * 提出用であるかをチェック
     */
    private boolean isTeishutsu() {
        return STATUS_TEISHUTSU.equals(s014Bean.getStatus());
    }

    /**
     * 履歴IDを取得
     */
    private Long getRirekiId() {
        //Long rirekiId = 0L;
        Long rirekiId = Long.parseLong(ConstantString.geRirekiId);
        if (isTeishutsu()) {
            // 提出用の場合は履歴id=1を使用
            rirekiId = Long.parseLong(ConstantString.teishutsuRirekiId);
        } else if (isKakutei()) {
            // 確定済の場合はWFテーブルに登録された履歴Keyを使用
            rirekiId = s014Bean.getRirekiId();
        }
        return rirekiId;
    }

    /**
     * 履歴FLGを取得
     */
    private String getRirekiFlg() {
        String rirekiFlg = "";
        if (isKakutei()) {
            rirekiFlg = "R";
        }
        return rirekiFlg;
    }

    /**
     * TOTAL・差を取得
     */
    private void setTotalDiff() throws Exception {
        // 今回
        Map<String, Object> totalInfo = s014Bean.getTotalInfo();

        s014Bean.setTotalSp1QDiff(syuuekiUtils.arari((BigDecimal)totalInfo.get("SP_1Q"), s014Bean.getTotalSp1QBefore()));
        s014Bean.setTotalNet1QDiff(syuuekiUtils.arari((BigDecimal)totalInfo.get("NET_1Q"), s014Bean.getTotalNet1QBefore()));
        s014Bean.setTotalSp2QDiff(syuuekiUtils.arari((BigDecimal)totalInfo.get("SP_2Q"), s014Bean.getTotalSp2QBefore()));
        s014Bean.setTotalNet2QDiff(syuuekiUtils.arari((BigDecimal)totalInfo.get("NET_2Q"), s014Bean.getTotalNet2QBefore()));
        s014Bean.setTotalSpKiDiff(syuuekiUtils.arari((BigDecimal)totalInfo.get("SP_K"), s014Bean.getTotalSpKiBefore()));
        s014Bean.setTotalNetKiDiff(syuuekiUtils.arari((BigDecimal)totalInfo.get("NET_K"), s014Bean.getTotalNetKiBefore()));
        s014Bean.setTotalSpGDiff(syuuekiUtils.arari((BigDecimal)totalInfo.get("SP_F"), s014Bean.getTotalSpGBefore()));
        s014Bean.setTotalNetGDiff(syuuekiUtils.arari((BigDecimal)totalInfo.get("NET_F"), s014Bean.getTotalNetGBefore()));
    }
    
    /**
     * TOTAL・前回確定値を取得
     */
    private void setTotalBefore() throws Exception {
        // WFテーブルから前月以前の最新月確定状態データを取得
        String beforeKanjyoYm = null;
        if (ConstantString.getsujiDataKbn.equals(s014Bean.getSyubetsu())) {
            // 月次確定
            beforeKanjyoYm = SyuuekiUtils.addMonth(s014Bean.getKanjyoYm(), -1);
        } else if(ConstantString.yosanDataKbn.equals(s014Bean.getSyubetsu())) {
            // 予算期
            //beforeKanjyoYm = SyuuekiUtils.addYosanKi2(s014Bean.getKanjyoYm(), -1);
            beforeKanjyoYm = SyuuekiUtils.addYosanKi(s014Bean.getKanjyoYm(), -1);
        }

        if (StringUtils.isEmpty(beforeKanjyoYm)) {
            logger.info("befor KanjyoYm No Search");
            return;
        }

        SyuWfControlTbl entity
                = syuWfControlTblFacade.findPkBefore(s014Bean.getDivisionCode(), s014Bean.getGroupCode(), s014Bean.getSalesClass(), beforeKanjyoYm, s014Bean.getSyubetsu(), s014Bean.getHonsyaShisyaKbn(), s014Bean.getTeamCode());

        if (entity == null) {
            return;
        }

        String[] quarterLabelAry = null;
        if(ConstantString.getsujiDataKbn.equals(s014Bean.getSyubetsu())){
            Date kanjyoDate = Utils.parseDate(s014Bean.getKanjyoYm());
            quarterLabelAry = syuuekiUtils.getQuarterLabel(kanjyoDate);
        }else if(ConstantString.yosanDataKbn.equals(s014Bean.getSyubetsu())){
            quarterLabelAry = syuuekiUtils.getQuarterLabel(s014Bean.getKanjyoYm().substring(0,5));
        }
        
        BigDecimal sp1Q = null;
        BigDecimal net1Q = null;
        BigDecimal sp2Q = null;
        BigDecimal net2Q = null;
        BigDecimal spKi = null;
        BigDecimal netKi = null;
        BigDecimal spG = null;
        BigDecimal netG = null;
         
        if ("1Q".equals(quarterLabelAry[0])) {
            sp1Q  = (entity.getSp1q()  == null ? null : new BigDecimal(entity.getSp1q()));
            net1Q = (entity.getNet1q() == null ? null : new BigDecimal(entity.getNet1q()));
            sp2Q  = (entity.getSp2q()  == null ? null : new BigDecimal(entity.getSp2q()));
            net2Q = (entity.getNet2q() == null ? null : new BigDecimal(entity.getNet2q()));

        } else if ("3Q".equals(quarterLabelAry[0])) {
            sp1Q  = (entity.getSp3q()  == null ? null : new BigDecimal(entity.getSp3q()));
            net1Q = (entity.getNet3q() == null ? null : new BigDecimal(entity.getNet3q()));
            sp2Q  = (entity.getSp4q()  == null ? null : new BigDecimal(entity.getSp4q()));
            net2Q = (entity.getNet4q() == null ? null : new BigDecimal(entity.getNet4q()));

        }

        spKi = Utils.add(sp1Q, sp2Q);
        netKi = Utils.add(net1Q, net2Q);
        
        s014Bean.setKanjyoYmBefore(entity.getKanjyoYm());
        s014Bean.setTotalSp1QBefore(sp1Q);
        s014Bean.setTotalNet1QBefore(net1Q);
        s014Bean.setTotalSp2QBefore(sp2Q);
        s014Bean.setTotalNet2QBefore(net2Q);
        s014Bean.setTotalSpKiBefore(spKi);
        s014Bean.setTotalNetKiBefore(netKi);
        s014Bean.setTotalSpGBefore((entity.getSpTotal() == null ? null : new BigDecimal(entity.getSpTotal())));
        s014Bean.setTotalNetGBefore((entity.getNetTotal() == null ? null : new BigDecimal(entity.getNetTotal())));
        
    }

    /**
     * 対象物件一覧を取得するSQLの条件Mapを取得
     */
    private Map<String, Object> getBukkenCondition(String beforeKiKbn, boolean ippanFlg) throws Exception {
        Map<String, Object> condition = new HashMap<>();
        String dataKbn;
        String conditionKanjyoYm = "";
        int idx = 1;
        
//        Integer nowRirekiId = null;
//        Integer teishutsuRirekiId = null;
        
        String[] syuekiYmAry = s014Bean.getSyuekiYmAry();

        conditionKanjyoYm = s014Bean.getDispBaseKanjyoYm();
        Date kanjyoDate = Utils.parseDate(conditionKanjyoYm);
        
        logger.info("wf_control_kanjyoYm=[{}], kanjyoYm=[{}]", s014Bean.getBaseKanjyoYm(), conditionKanjyoYm);

        condition.put("rirekiFlg", "");
        condition.put("groupCode", s014Bean.getGroupCode());
        condition.put("divisionCode", s014Bean.getDivisionCode());
        condition.put("salesClass", s014Bean.getSalesClass());

        // 対象月の期の各月を指定する。
        for (String ym : syuekiYmAry) {
            condition.put("syuekiYm" + idx, ym);
            if (syuuekiUtils.getJissekiFlg(kanjyoDate, ym)) {
                dataKbn = "J";
            } else {
                dataKbn = "M";
            }
            condition.put("dataKbn" + idx, dataKbn);
            idx++;
        }
        
        // 対象月の期の4半期(2回分)の合計を指定
        condition.put("syuekiYmQ1", s014Bean.getSyueki1Q());
        condition.put("syuekiYmQ2", s014Bean.getSyueki2Q());

        // 対象月の期合計を指定
        condition.put("syuekiYmK", s014Bean.getSyuekiKi());

        // ダウンロード実行の場合、SQLにダウンロード用の指定を加える
        condition.put("downloadFlg", s014Bean.getDownloadFlg());

        if ("1".equals(beforeKiKbn)) {
            // 前期表示の場合は必ず原案テーブル(_R付ではないテーブル)を参照
            condition.put("rirekiId", Integer.parseInt(ConstantString.geRirekiId));
            condition.put("rirekiFlg", "");
        } else {
            condition.put("rirekiId", getRirekiId());
            condition.put("rirekiFlg", getRirekiFlg());
        }

        // 事業部コード:(原子力)であるかを判断(原子力とそれ以外の事業部で検索条件を可変にする)
        String divisionNuclearFlg = "0";
        boolean isNuclearDivision = divisionComponentPage.isNuclearDivision(s014Bean.getDivisionCode());
        if (isNuclearDivision) {
            divisionNuclearFlg = "1";
        }
        condition.put("divisionNuclearFlg", divisionNuclearFlg);

        //////// 完成基準(一般)案件の検索時 ///////
        if (ippanFlg) {
            // 検索対象の営業課に該当する本社チームコード,支社チームコードを検索条件パラメータとして設定する
            // 設定されたチームコードはcondition内に追加される
            addTeamCodeToCondition(condition, beforeKiKbn);

//            // 対象となるデータの条件(扱いチームコード、扱いCコード、対象の履歴ID)を取得する
//            List<String> honsyaTeamCode = new ArrayList<>();
//            List<String> shisyaTeamCode = new ArrayList<>();
//            // 確定済のチームコード、履歴ID
//            List<String> kakuteiHonsyaTeamCode = new ArrayList<>();
//            List<String> kakuteiShisyaTeamCode = new ArrayList<>();
//            List<String> targetRirekiId = new ArrayList<>();
//            // 提出用のチームコード
//            List<String> teishutsuHonsyaTeamCode = new ArrayList<>();
//            List<String> teishutsuShisyaTeamCode = new ArrayList<>();
//            // 作成中のチームコード
//            List<String> creatingHonsyaTeamCode = new ArrayList<>();
//            List<String> creatingShisyaTeamCode = new ArrayList<>();
//
//            // 作成中+提出用の本社チームコード
//            List<String> geHonsyaTeamCode = new ArrayList<>();
//
//            List<SyuWfControlTbl> list
//                = syuWfControlTblFacade.findTargetBukken(s014Bean.getDivisionCode(), s014Bean.getSalesClass(), s014Bean.getKanjyoYm(), s014Bean.getcBukaCode());
//
//            int geSearchCount = 0;
//            int teishutsuSearchCount = 0;
//
//            //int rirekiSarchCount = 0;
//            for(SyuWfControlTbl entity : list){
//                String targetHonsyaTeamCode = "";
//                String targetShisyaTeamCode = "";
//
//                // GEを参照する対象となる扱いチームコード、扱いCコードを取得する。
//                if (ConstantString.honsyaKbn.equals(entity.getHonsyaShisyaKbn())) {
//                    honsyaTeamCode.add(entity.getTeamCode());
//                    targetHonsyaTeamCode = entity.getTeamCode();
//                } else if(ConstantString.shisyaKbn.equals(entity.getHonsyaShisyaKbn())){
//                    shisyaTeamCode.add(entity.getTeamCode());
//                    targetShisyaTeamCode = entity.getTeamCode();
//                }
// 
//                if (STATUS_KAKUTEI.equals(entity.getStatus())) {   // 確定済
//                    // 確定済の履歴IDを取得
//                    targetRirekiId.add(String.valueOf(entity.getRirekiId()));
//
//                    // 確定済の本社チームコードを格納(原案テーブルの検索条件から除外するため)
//                    if (StringUtils.isNotEmpty(targetHonsyaTeamCode)) {
//                        kakuteiHonsyaTeamCode.add(targetHonsyaTeamCode);
//                    }
//                    // 確定済の支社チームコードを格納(原案テーブルの検索条件から除外するため)
//                    if (StringUtils.isNotEmpty(targetShisyaTeamCode)) {
//                        kakuteiShisyaTeamCode.add(targetShisyaTeamCode);
//                    }
//                    
//                } else if (STATUS_TEISHUTSU.equals(entity.getStatus())) {   // 提出用
//                    teishutsuSearchCount++;
//  
//                    // 提出用の本社チームコードを格納
//                    if (StringUtils.isNotEmpty(targetHonsyaTeamCode)) {
//                        teishutsuHonsyaTeamCode.add(targetHonsyaTeamCode);
//                    }
//                    // 提出用の支社チームコードを格納(原案テーブルの検索条件から除外するため)
//                    if (StringUtils.isNotEmpty(targetShisyaTeamCode)) {
//                        teishutsuShisyaTeamCode.add(targetShisyaTeamCode);
//                    }
//
//                } else {    // 作成中
//                    geSearchCount++;
//                    
//                    // 作成中の本社チームコードを格納
//                    if (StringUtils.isNotEmpty(targetHonsyaTeamCode)) {
//                        creatingHonsyaTeamCode.add(targetHonsyaTeamCode);
//                    }
//                    // 作成中の支社チームコードを格納
//                    if (StringUtils.isNotEmpty(targetShisyaTeamCode)) {
//                        creatingShisyaTeamCode.add(targetShisyaTeamCode);
//                    }
//                }
//            }
//
//            condition.put("honsyaTeamCode", honsyaTeamCode);
//            logger.info("honsyaTeamCode={}", honsyaTeamCode);
//            if (CollectionUtils.isEmpty(honsyaTeamCode)) {
//                // 該当の扱いチームコードが存在しない場合、あり得ないチームコードを指定
//                honsyaTeamCode.add("@@@@@@");
//            }
//            condition.put("shisyaTeamCode", shisyaTeamCode);
//            logger.info("shisyaTeamCode={}", shisyaTeamCode);
//            if (CollectionUtils.isEmpty(shisyaTeamCode)) {
//                // 該当の扱いCコードが存在しない場合、あり得ない扱いCコードを指定
//                shisyaTeamCode.add("@@@@@@");
//            }
//
//            //s014Bean.setPartNoFixFlg("");
//            logger.info("beforeKiKbn={}", beforeKiKbn);
//            if ("1".equals(beforeKiKbn)) {
//                ////// [前期表示(beforeKiKbn=1)]の場合
//                // 参照テーブルは必ず[原案(_Rがつかない)テーブルのRIREKI_ID=0を検索
//                nowRirekiId = Integer.parseInt(ConstantString.geRirekiId);
//
//                // 提出データ(RIREKI_ID=1)や確定済データ(Rテーブル)のデータは利用しないため、提出済、確定済のチームコードも全て1まとめにする。
//                creatingHonsyaTeamCode.addAll(teishutsuHonsyaTeamCode);
//                creatingHonsyaTeamCode.addAll(kakuteiHonsyaTeamCode);
//                creatingShisyaTeamCode.addAll(teishutsuShisyaTeamCode);
//                creatingShisyaTeamCode.addAll(kakuteiShisyaTeamCode);
//
//                // 前期表示の場合は原案テーブルのみ参照のため、提出、確定されたチームコードはパラメータから除外
//                // (提出用)チームコードをクリア
//                teishutsuHonsyaTeamCode = new ArrayList();
//                teishutsuShisyaTeamCode = new ArrayList();
//                // (確定済)チームコードをクリア
//                kakuteiHonsyaTeamCode = new ArrayList<>();
//                kakuteiShisyaTeamCode = new ArrayList<>();
//
//            } else {
//                ////// [当期表示]の場合
//                if (targetRirekiId.size() > 0) {
//                    condition.put("targetRirekiId", targetRirekiId);
//                    logger.info("targetRirekiId={}", targetRirekiId);
//                }
//
//                // 作成中のチームが1件でも存在する場合、原案(_Rがつかない)テーブルのRIREKI_ID=0を検索
//                if (geSearchCount > 0) {
//                    nowRirekiId = Integer.parseInt(ConstantString.geRirekiId);
//                }
//                // 提出用のチームが1件でも存在する場合、原案(_Rがつかない)テーブルのRIREKI_ID=1を検索
//                if (teishutsuSearchCount > 0) {
//                    teishutsuRirekiId = Integer.parseInt(ConstantString.teishutsuRirekiId);
//                }
//            }
//
//            // 原案テーブル検索用の本社・支社チームコードをまとめる
//            geHonsyaTeamCode.addAll(creatingHonsyaTeamCode);
//            geHonsyaTeamCode.addAll(teishutsuHonsyaTeamCode);
//
//            if (nowRirekiId != null) {
//                condition.put("nowRirekiId", nowRirekiId);
//            }
//            if (teishutsuRirekiId != null) {
//                condition.put("teishutsuRirekiId", teishutsuRirekiId);
//            }
//
//            logger.info("nowRirekiId=[{}] teishutsuRirekiId=[{}]", nowRirekiId, teishutsuRirekiId);
//
//            condition.put("kanjyoYm", conditionKanjyoYm);
//            //20160511
//            condition.put("shisyaHonsyaKbn", s014Bean.getHonsyaShisyaKbn());
//        
//            // (確定済)本社チームコード
//            condition.put("kakuteiHonsyaTeamCode", kakuteiHonsyaTeamCode);
//            logger.info("kakuteiHonsyaTeamCode={}", kakuteiHonsyaTeamCode);
//            if (CollectionUtils.isEmpty(kakuteiHonsyaTeamCode)) {
//                kakuteiHonsyaTeamCode.add("@@@@@@");
//            }
//            // (確定済)支社チームコード
//            condition.put("kakuteiShisyaTeamCode", kakuteiShisyaTeamCode);
//            logger.info("kakuteiShisyaTeamCode={}", kakuteiShisyaTeamCode);
//            if (CollectionUtils.isEmpty(kakuteiShisyaTeamCode)) {
//                kakuteiShisyaTeamCode.add("@@@@@@");
//            }
//            
//            // (提出用)本社チームコード
//            condition.put("teishutsuHonsyaTeamCode", teishutsuHonsyaTeamCode);
//            logger.info("teishutsuHonsyaTeamCode={}", teishutsuHonsyaTeamCode);
//            if (CollectionUtils.isEmpty(teishutsuHonsyaTeamCode)) {
//                teishutsuHonsyaTeamCode.add("@@@@@@");
//            }
//            // (提出用)支社チームコード
//            condition.put("teishutsuShisyaTeamCode", teishutsuShisyaTeamCode);
//            logger.info("teishutsuShisyaTeamCode={}", teishutsuShisyaTeamCode);
//            if (CollectionUtils.isEmpty(teishutsuShisyaTeamCode)) {
//                teishutsuShisyaTeamCode.add("@@@@@@");
//            }
//
//            // (作成中)本社チームコード
//            condition.put("creatingHonsyaTeamCode", creatingHonsyaTeamCode);
//            logger.info("creatingHonsyaTeamCode={}", creatingHonsyaTeamCode);
//            if (CollectionUtils.isEmpty(creatingHonsyaTeamCode)) {
//                creatingHonsyaTeamCode.add("@@@@@@");
//            }
//            // (作成中)支社チームコード
//            condition.put("creatingShisyaTeamCode", creatingShisyaTeamCode);
//            logger.info("creatingShisyaTeamCode={}", creatingShisyaTeamCode);
//            if (CollectionUtils.isEmpty(creatingShisyaTeamCode)) {
//                creatingShisyaTeamCode.add("@@@@@@");
//            }
//
//            condition.put("geHonsyaTeamCode", geHonsyaTeamCode);
//            logger.info("geHonsyaTeamCode={}", geHonsyaTeamCode);
//            if (CollectionUtils.isEmpty(geHonsyaTeamCode)) {
//                geHonsyaTeamCode.add("@@@@@@");
//            }
//            
//            // 本社確定時の場合、本社分案件のみ出力するか？
//            condition.put("honsyaOnlyFlg", "0");
//            if (syuuekiCommonService.isKakuteiHonsyaOnly(s014Bean.getDivisionCode())) {
//                condition.put("honsyaOnlyFlg", "1");
//            }
        }

        return condition;
    }
    
    /**
     * 完成基準(一般)用(SALES_CLASS=0)の案件を検索する場合
     * 検索対象の営業課に該当する本社チームコード,支社チームコードを検索条件パラメータとして設定する
     */
    private void addTeamCodeToCondition(Map<String, Object> condition, String beforeKiKbn) throws Exception {
        // 対象となるデータの条件(扱いチームコード、扱いCコード、対象の履歴ID)を取得する
        List<String> honsyaTeamCode = new ArrayList<>();
        List<String> shisyaTeamCode = new ArrayList<>();
        // 確定済のチームコード、履歴ID
        List<String> kakuteiHonsyaTeamCode = new ArrayList<>();
        List<String> kakuteiShisyaTeamCode = new ArrayList<>();
        List<String> targetRirekiId = new ArrayList<>();
        // 提出用のチームコード
        List<String> teishutsuHonsyaTeamCode = new ArrayList<>();
        List<String> teishutsuShisyaTeamCode = new ArrayList<>();
        // 作成中のチームコード
        List<String> creatingHonsyaTeamCode = new ArrayList<>();
        List<String> creatingShisyaTeamCode = new ArrayList<>();

        // 作成中+提出用の本社チームコード
        List<String> geHonsyaTeamCode = new ArrayList<>();

        List<SyuWfControlTbl> list
            = syuWfControlTblFacade.findTargetBukken(s014Bean.getDivisionCode(), s014Bean.getSalesClass(), s014Bean.getKanjyoYm(), s014Bean.getcBukaCode());

        int geSearchCount = 0;
        int teishutsuSearchCount = 0;

        
        int honsyaTeamCodeCount = 0;
        int shisyaTeamCodeCount = 0;
        //int rirekiSarchCount = 0;
        for(SyuWfControlTbl entity : list){
            String targetHonsyaTeamCode = "";
            String targetShisyaTeamCode = "";

            // GEを参照する対象となる扱いチームコード、扱いCコードを取得する。
            if (ConstantString.honsyaKbn.equals(entity.getHonsyaShisyaKbn())) {
                // 本社営業のチームコードを取得
                honsyaTeamCode.add(entity.getTeamCode());
                targetHonsyaTeamCode = entity.getTeamCode();
                honsyaTeamCodeCount = honsyaTeamCodeCount + 1;
            } else if(ConstantString.shisyaKbn.equals(entity.getHonsyaShisyaKbn())){
                // 支社営業のチームコードを取得
                shisyaTeamCode.add(entity.getTeamCode());
                targetShisyaTeamCode = entity.getTeamCode();
                shisyaTeamCodeCount = shisyaTeamCodeCount + 1;
            }

            if (STATUS_KAKUTEI.equals(entity.getStatus())) {   // 確定済
                // 確定済の履歴IDを取得
                targetRirekiId.add(String.valueOf(entity.getRirekiId()));

                // 確定済の本社チームコードを格納(原案テーブルの検索条件から除外するため)
                if (StringUtils.isNotEmpty(targetHonsyaTeamCode)) {
                    kakuteiHonsyaTeamCode.add(targetHonsyaTeamCode);
                }
                // 確定済の支社チームコードを格納(原案テーブルの検索条件から除外するため)
                if (StringUtils.isNotEmpty(targetShisyaTeamCode)) {
                    kakuteiShisyaTeamCode.add(targetShisyaTeamCode);
                }

            } else if (STATUS_TEISHUTSU.equals(entity.getStatus())) {   // 提出用
                teishutsuSearchCount++;

                // 提出用の本社チームコードを格納
                if (StringUtils.isNotEmpty(targetHonsyaTeamCode)) {
                    teishutsuHonsyaTeamCode.add(targetHonsyaTeamCode);
                }
                // 提出用の支社チームコードを格納(原案テーブルの検索条件から除外するため)
                if (StringUtils.isNotEmpty(targetShisyaTeamCode)) {
                    teishutsuShisyaTeamCode.add(targetShisyaTeamCode);
                }

            } else {    // 作成中
                geSearchCount++;

                // 作成中の本社チームコードを格納
                if (StringUtils.isNotEmpty(targetHonsyaTeamCode)) {
                    creatingHonsyaTeamCode.add(targetHonsyaTeamCode);
                }
                // 作成中の支社チームコードを格納
                if (StringUtils.isNotEmpty(targetShisyaTeamCode)) {
                    creatingShisyaTeamCode.add(targetShisyaTeamCode);
                }
            }
        }

        condition.put("honsyaTeamCode", honsyaTeamCode);
        logger.info("honsyaTeamCode={}", honsyaTeamCode);
        if (CollectionUtils.isEmpty(honsyaTeamCode)) {
            // 該当の扱いチームコードが存在しない場合、あり得ないチームコードを指定
            honsyaTeamCode.add("@@@@@@");
        }
        condition.put("shisyaTeamCode", shisyaTeamCode);
        logger.info("shisyaTeamCode={}", shisyaTeamCode);
        if (CollectionUtils.isEmpty(shisyaTeamCode)) {
            // 該当の扱いCコードが存在しない場合、あり得ない扱いCコードを指定
            shisyaTeamCode.add("@@@@@@");
        }

        Integer nowRirekiId = null;
        Integer teishutsuRirekiId = null;

        //s014Bean.setPartNoFixFlg("");
        logger.info("beforeKiKbn={}", beforeKiKbn);
        if ("1".equals(beforeKiKbn)) {
            ////// [前期表示(beforeKiKbn=1)]の場合
            // 参照テーブルは必ず[原案(_Rがつかない)テーブルのRIREKI_ID=0を検索
            nowRirekiId = Integer.parseInt(ConstantString.geRirekiId);

            // 提出データ(RIREKI_ID=1)や確定済データ(Rテーブル)のデータは利用しないため、提出済、確定済のチームコードも全て1まとめにする。
            creatingHonsyaTeamCode.addAll(teishutsuHonsyaTeamCode);
            creatingHonsyaTeamCode.addAll(kakuteiHonsyaTeamCode);
            creatingShisyaTeamCode.addAll(teishutsuShisyaTeamCode);
            creatingShisyaTeamCode.addAll(kakuteiShisyaTeamCode);

            // 前期表示の場合は原案テーブルのみ参照のため、提出、確定されたチームコードはパラメータから除外
            // (提出用)チームコードをクリア
            teishutsuHonsyaTeamCode = new ArrayList();
            teishutsuShisyaTeamCode = new ArrayList();
            // (確定済)チームコードをクリア
            kakuteiHonsyaTeamCode = new ArrayList<>();
            kakuteiShisyaTeamCode = new ArrayList<>();

        } else {
            ////// [当期表示]の場合
            if (targetRirekiId.size() > 0) {
                condition.put("targetRirekiId", targetRirekiId);
                logger.info("targetRirekiId={}", targetRirekiId);
            }

            // 作成中のチームが1件でも存在する場合、原案(_Rがつかない)テーブルのRIREKI_ID=0を検索
            if (geSearchCount > 0) {
                nowRirekiId = Integer.parseInt(ConstantString.geRirekiId);
            }
            // 提出用のチームが1件でも存在する場合、原案(_Rがつかない)テーブルのRIREKI_ID=1を検索
            if (teishutsuSearchCount > 0) {
                teishutsuRirekiId = Integer.parseInt(ConstantString.teishutsuRirekiId);
            }
        }

        // 原案テーブル検索用の本社・支社チームコードをまとめる
        geHonsyaTeamCode.addAll(creatingHonsyaTeamCode);
        geHonsyaTeamCode.addAll(teishutsuHonsyaTeamCode);

        if (nowRirekiId != null) {
            condition.put("nowRirekiId", nowRirekiId);
        }
        if (teishutsuRirekiId != null) {
            condition.put("teishutsuRirekiId", teishutsuRirekiId);
        }

        logger.info("nowRirekiId=[{}] teishutsuRirekiId=[{}]", nowRirekiId, teishutsuRirekiId);

        condition.put("kanjyoYm", s014Bean.getDispBaseKanjyoYm());
        //20160511
        condition.put("shisyaHonsyaKbn", s014Bean.getHonsyaShisyaKbn());

        // 本社営業の案件のみ検索する場合、支社営業用案件は除外するように条件設定する
        // ※電力ジやNEPJは支社→本社の2段階の月次確定WFは利用しない(2段階の月次確定WFは201702現状は(火水ジ)のみ)ので、本社案件検索時に支社案件が検索対象に含まれないようにするための措置
        String honsyaOnlyFlg = "0";
        if (honsyaTeamCodeCount > 0 && shisyaTeamCodeCount == 0) {
            honsyaOnlyFlg = "1";
        }
        condition.put("honsyaOnlyFlg", honsyaOnlyFlg);
        logger.info("[addTeamCodeToCondition] honsyaOnlyFlg=[{}]", honsyaOnlyFlg);
        
        // (確定済)本社チームコード
        condition.put("kakuteiHonsyaTeamCode", kakuteiHonsyaTeamCode);
        logger.info("kakuteiHonsyaTeamCode={}", kakuteiHonsyaTeamCode);
        if (CollectionUtils.isEmpty(kakuteiHonsyaTeamCode)) {
            kakuteiHonsyaTeamCode.add("@@@@@@");
        }
        // (確定済)支社チームコード
        condition.put("kakuteiShisyaTeamCode", kakuteiShisyaTeamCode);
        logger.info("kakuteiShisyaTeamCode={}", kakuteiShisyaTeamCode);
        if (CollectionUtils.isEmpty(kakuteiShisyaTeamCode)) {
            kakuteiShisyaTeamCode.add("@@@@@@");
        }

        // (提出用)本社チームコード
        condition.put("teishutsuHonsyaTeamCode", teishutsuHonsyaTeamCode);
        logger.info("teishutsuHonsyaTeamCode={}", teishutsuHonsyaTeamCode);
        if (CollectionUtils.isEmpty(teishutsuHonsyaTeamCode)) {
            teishutsuHonsyaTeamCode.add("@@@@@@");
        }
        // (提出用)支社チームコード
        condition.put("teishutsuShisyaTeamCode", teishutsuShisyaTeamCode);
        logger.info("teishutsuShisyaTeamCode={}", teishutsuShisyaTeamCode);
        if (CollectionUtils.isEmpty(teishutsuShisyaTeamCode)) {
            teishutsuShisyaTeamCode.add("@@@@@@");
        }

        // (作成中)本社チームコード
        condition.put("creatingHonsyaTeamCode", creatingHonsyaTeamCode);
        logger.info("creatingHonsyaTeamCode={}", creatingHonsyaTeamCode);
        if (CollectionUtils.isEmpty(creatingHonsyaTeamCode)) {
            creatingHonsyaTeamCode.add("@@@@@@");
        }
        // (作成中)支社チームコード
        condition.put("creatingShisyaTeamCode", creatingShisyaTeamCode);
        logger.info("creatingShisyaTeamCode={}", creatingShisyaTeamCode);
        if (CollectionUtils.isEmpty(creatingShisyaTeamCode)) {
            creatingShisyaTeamCode.add("@@@@@@");
        }

        condition.put("geHonsyaTeamCode", geHonsyaTeamCode);
        logger.info("geHonsyaTeamCode={}", geHonsyaTeamCode);
        if (CollectionUtils.isEmpty(geHonsyaTeamCode)) {
            geHonsyaTeamCode.add("@@@@@@");
        }
    }

    /**
     * 対象物件の全合計SP,NETを取得
     */
    private void setTotalInfo() throws ParseException {
        List<Map<String, Object>> list = s014Bean.getBukkenList();

        Map<String, Object> totalInfo = new HashMap<>();
        String[] syuekiYmAry = s014Bean.getSyuekiYmAry();

        BigDecimal[] spYm = new BigDecimal[syuekiYmAry.length];
        BigDecimal[] netYm = new BigDecimal[syuekiYmAry.length];
        BigDecimal sp1Q = null;
        BigDecimal sp2Q = null;
        BigDecimal spK = null;
        BigDecimal spG = null;
        BigDecimal net1Q = null;
        BigDecimal net2Q = null;
        BigDecimal netK = null;
        BigDecimal netG = null;
        
        for (Map<String, Object> bukkenInfo : list) {
            for (int i=0; i<syuekiYmAry.length; i++) {
                spYm[i] = Utils.add(spYm[i], (BigDecimal)bukkenInfo.get("SP" + (i+1)));
                netYm[i] = Utils.add(netYm[i], (BigDecimal)bukkenInfo.get("NET" + (i+1)));
            }
            
            sp1Q = Utils.add(sp1Q, (BigDecimal)bukkenInfo.get("SP_1Q"));
            sp2Q = Utils.add(sp2Q, (BigDecimal)bukkenInfo.get("SP_2Q"));
            spK = Utils.add(spK, (BigDecimal)bukkenInfo.get("SP_K"));
            spG = Utils.add(spG, (BigDecimal)bukkenInfo.get("SP_F"));
            
            net1Q = Utils.add(net1Q, (BigDecimal)bukkenInfo.get("NET_1Q"));
            net2Q = Utils.add(net2Q, (BigDecimal)bukkenInfo.get("NET_2Q"));
            netK = Utils.add(netK, (BigDecimal)bukkenInfo.get("NET_K"));
            netG = Utils.add(netG, (BigDecimal)bukkenInfo.get("NET_F"));
        }

        for (int i=0; i<syuekiYmAry.length; i++) {
            totalInfo.put("SP" + (i+1), spYm[i]);
            totalInfo.put("NET" + (i+1), netYm[i]);
        }
        totalInfo.put("SP_1Q", sp1Q);
        totalInfo.put("SP_2Q", sp2Q);
        totalInfo.put("SP_K", spK);
        totalInfo.put("SP_F", spG);
        totalInfo.put("NET_1Q", net1Q);
        totalInfo.put("NET_2Q", net2Q);
        totalInfo.put("NET_K", netK);
        totalInfo.put("NET_F", netG);

        s014Bean.setTotalInfo(totalInfo);
    }
    
    /**
     * 表示対象の月、4半期、期を取得
     */
    private void setDispKikan(String beforeKiFlg) throws ParseException {
        String targetKi = null;
        String[] syuekiYmAry = null;

        String baseKanjyoYm = s014Bean.getBaseKanjyoYm();
        String dispBaseKankyoYm = s014Bean.getBaseKanjyoYm();
        
        Date kanjyoDate = Utils.parseDate(dispBaseKankyoYm);
        targetKi = SyuuekiUtils.dateToKikan(kanjyoDate);
        syuekiYmAry = syuuekiUtils.getKikanMonthAry(kanjyoDate);

        // 画面に各年月を表示する際の比較年月を取得(この年月と比較して、実績 or 見込を判定)
        if ("1".equals(beforeKiFlg)) {
            // [前期]表示の場合は表示する期の翌期はじめの勘定月を基準にする。
            String nextKiStartSyuekiYm = SyuuekiUtils.addMonth(syuekiYmAry[0], 6);
            dispBaseKankyoYm = nextKiStartSyuekiYm;
            
            logger.info("[前期実績表示] 表示対象月=[{}] 扱い勘定月=[{}]", syuekiYmAry, dispBaseKankyoYm);
        }

        s014Bean.setDispBaseKanjyoYm(dispBaseKankyoYm);
        s014Bean.setSyuekiYmAry(syuekiYmAry);
        s014Bean.setSyueki1Q(syuekiYmAry[2] + "Q");
        s014Bean.setSyueki2Q(syuekiYmAry[5] + "Q");
        s014Bean.setSyuekiKi(targetKi);
    }

    /**
     * 表示対象の月、4半期、期を取得
     */
    private void setDispKikan(String beforeKiFlg, boolean nextPeriod) throws ParseException {
        if (!nextPeriod) {
            // 当期表示(プルタウンで[前期]切り替え時は前期を表示)
            setDispKikan(beforeKiFlg);

        } else if ("1".equals(beforeKiFlg) && nextPeriod) {
            // [前期]指定されており、2シート目[来期]を表示する場合
            // 本来の期を表示する
            setDispKikan("0");
            
        } else {
            // 来期表示
            Calendar calendar = Calendar.getInstance();
            logger.info("[setDispKikan] nextPeriod=[{}], kanjyoYm=[{}]", nextPeriod, s014Bean.getBaseKanjyoYm());

            Date kanjyoDate = null;
            kanjyoDate = Utils.parseDate(s014Bean.getBaseKanjyoYm());

            calendar.setTime(kanjyoDate);
            calendar.add(Calendar.MONTH, 6);
            kanjyoDate = calendar.getTime();
                    
            String targetKi = SyuuekiUtils.dateToKikan(kanjyoDate);
            String[] syuekiYmAry = syuuekiUtils.getKikanMonthAry(kanjyoDate);

            s014Bean.setSyuekiYmAry(syuekiYmAry);
            s014Bean.setSyueki1Q(syuekiYmAry[2] + "Q");
            s014Bean.setSyueki2Q(syuekiYmAry[5] + "Q");
            s014Bean.setSyuekiKi(targetKi);
            s014Bean.setNextKanjyoYmData(kanjyoDate);
        }
    }
    
    /**
     * 対象物件一覧を取得
     */
    private void setBukkenList(String beforeKiFlg) throws Exception {
        Map<String, Object> condition = getBukkenCondition(beforeKiFlg, s014Bean.isIppan());
        logger.info("[setBukkenList] condition=[{}]", condition);
        String sqlFilePath = "";

        if(s014Bean.isIppan()){
            sqlFilePath = "/sql/S014/selectWfIppanBukkenList.sql";
        }else{
            sqlFilePath = "/sql/S014/selectWfBukkenList.sql";
        }
        // SQLを取得
        SqlFile sqlFile = new SqlFile();
        String sql = sqlFile.getSqlString(sqlFilePath, condition);
        Object[] params = sqlFile.getSqlParams(sqlFilePath, condition);

        // SQL実行
        List<Map<String, Object>> list = dbUtilsExecutor.dbUtilsGetSqlList(em, sql, params);
        s014Bean.setBukkenList(list);
        
        // SP・NET全データの集計を取得
        setTotalInfo();
    }
    
    /**
     * ワークフロー権限を取得
     */
    private void setWorkFlowFlg() throws Exception {
        // 一般案件・支社営業の場合は、C_GROUP_CODEで権限が登録されているため、それで権限参照する。
        String kengenGroupCode = s014Bean.getGroupCode();
        if (ConstantString.salesClassI.equals(s014Bean.getSalesClass()) && "S".equals(s014Bean.getHonsyaShisyaKbn())) {
            kengenGroupCode = s014Bean.getcBukaCode();
        }

        // 確定(＋解除)権限を取得
        List<JgrpMemberTbl> list
                = jgrpMemberTblFacade.getJobGrMemerInfoList(
                        s014Bean.getDivisionCode(), 
                        s014Bean.getSalesClass(), 
                        kengenGroupCode,
                        loginUserInfo.getUserId());
        
        if (list == null) {
            return;
        }
        for (JgrpMemberTbl entity : list)  {
            // ログイン者が対象JobGrのメンバーであれば、誰でも提出は可能
            s014Bean.setTeishutsuActionFlg(1);
            // JGRP_MEMBER_TBLのAPP_KBN='2'の場合、確定(+解除)権限あり
            if ("2".equals(entity.getAppKbn())) {
                s014Bean.setKakuteiFlg(1);
            }
        }

        // 2016A 過去の勘定月は確定,確定解除できないようにする
        setKakuteiControl();

        // 一般案件の場合、支社分が確定済みであるかをチェック
        boolean kakuteiActionFlg = true;

        s014Bean.setKakuteiActionFlg(kakuteiActionFlg);

        // 確定(＋解除)、提出用作成(＋解除)ボタンの表示非表示を設定
        boolean kakuteiBtnFlg = false;
        boolean kakuteiKaijoBtnFlg = false;
        boolean teishutsuBtnFlg = false;
        boolean teishutsuKaijoBtnFlg = false;
        if (s014Bean.isIppan()) {
            ////// [一般]の場合
            List<SyuWfControlTbl> groupList
                = syuWfControlTblFacade.findBukaCode(s014Bean.getDivisionCode(), s014Bean.getcBukaCode(), s014Bean.getSalesClass(), s014Bean.getKanjyoYm(), "0");

            for (SyuWfControlTbl rec : groupList) {
                if (s014Bean.getHonsyaShisyaKbn().equals(rec.getHonsyaShisyaKbn())) {
                    if (isKakuteiBtnFlg(rec.getStatus())) {
                        kakuteiBtnFlg = true;
                    }
                    if (isKakuteiKaijoBtnFlg(rec.getStatus())) {
                        kakuteiKaijoBtnFlg = true;
                    }
                    
                    if (isTeishutsuBtnFlg(rec.getStatus())) {
                        teishutsuBtnFlg = true;
                    }
                    if (isTeishutsuKaijoBtnFlg(rec.getStatus())) {
                        teishutsuKaijoBtnFlg = true;
                    }
                }
            }

        } else {
            ////// [進行基準]の場合
            kakuteiBtnFlg = isKakuteiBtnFlg(s014Bean.getStatus());
            kakuteiKaijoBtnFlg = isKakuteiKaijoBtnFlg(s014Bean.getStatus());
            teishutsuBtnFlg = isTeishutsuBtnFlg(s014Bean.getStatus());
            teishutsuKaijoBtnFlg = isTeishutsuKaijoBtnFlg(s014Bean.getStatus());
        }

        s014Bean.setKakuteiBtnFlg(kakuteiBtnFlg);
        s014Bean.setKakuteiKaijoBtnFlg(kakuteiKaijoBtnFlg);
        s014Bean.setTeishutsuBtnFlg(teishutsuBtnFlg);
        s014Bean.setTeishutsuKaijoBtnFlg(teishutsuKaijoBtnFlg);
    }

    /**
     * 過去月の確定/確定解除をできないように設定する(2016A Step3改追加)
     */
    private void setKakuteiControl() {
        String kanjyoYm;
        if (s014Bean.isYosan()) {
            //// 予算ベースの場合
            // 対象予算期が、現時点の最新予算期より前の予算期の場合は確定/確定解除できないようにする。
            kanjyoYm = syuWfControlTblFacade.getMaxKanjyoYm(s014Bean.getDivisionCode(), s014Bean.getcBukaCode(), s014Bean.getSalesClass(), s014Bean.getSyubetsu());

        } else {
            //// 月次確定の場合
            // 過去の勘定月は確定/確定解除できないようにする
            kanjyoYm = kanjyoMstFacade.getNowKanjoDate(s014Bean.getSalesClass());
        }

        if (kanjyoYm.compareTo(s014Bean.getKanjyoYm()) > 0) {
            s014Bean.setTeishutsuActionFlg(-1);
            s014Bean.setKakuteiFlg(-1);
        }
        
        logger.info("[setKakuteiControl] nowKanjyoYm=[{}] targetKankyoYm=[{}]", kanjyoYm, s014Bean.getKanjyoYm());
    }
    
    /**
     * 検索対象にする基準の勘定年月を取得
     */
    private void setBaseKanjyoYm(String beforeKiFlg) {
        logger.info("[setBaseKanjyoYm]");
        String baseKanjyoYm = s014Bean.getKanjyoYm();
        
        if (ConstantString.yosanDataKbn.equals(s014Bean.getSyubetsu())) {
            // [予算期]の場合は勘定月を期のはじめの月にする。
            baseKanjyoYm = SyuuekiUtils.getChangeBaseYm(baseKanjyoYm);
            logger.info("[setBaseKanjyoYm] yosanKi {}→{}", s014Bean.getKanjyoYm(), baseKanjyoYm);
        }

        if ("1".equals(beforeKiFlg)) {
            // [前期]指定の場合は6ヶ月前にする。
            baseKanjyoYm = SyuuekiUtils.addMonth(baseKanjyoYm, -6);
            logger.info("[setBaseKanjyoYm] before {}→{}", s014Bean.getKanjyoYm(), baseKanjyoYm);
        }

        s014Bean.setBaseKanjyoYm(baseKanjyoYm);
    }
    
    /**
     * 初期表示 ビジネスロジック
     * @throws java.lang.Exception
     */
    public void indexExecute() throws Exception {
        // WFテーブルを検索
        SyuWfControlTbl entity
                = syuWfControlTblFacade.findPk(s014Bean.getDivisionCode(), s014Bean.getGroupCode(), s014Bean.getSalesClass(), s014Bean.getKanjyoYm(), s014Bean.getHonsyaShisyaKbn(), s014Bean.getTeamCode());
        
        // WFテーブル取得情報をbeanにコピー
        PropertyUtils.copyProperties(s014Bean, entity);
        
        // 検索対象の基準の勘定年月を取得
        setBaseKanjyoYm(s014Bean.getBeforKiFlg());
        
        // 表示対象の月、4半期、期を取得
        setDispKikan(s014Bean.getBeforKiFlg());
        
        // 対象物件一覧を取得
        setBukkenList(s014Bean.getBeforKiFlg());
        
        // TOTAL・ラベルの取得
        String[] quarterLabelAry = null;
        Date kanjyoDate = Utils.parseDate(s014Bean.getBaseKanjyoYm());
        quarterLabelAry = syuuekiUtils.getQuarterLabel(kanjyoDate);

        logger.info("baseKanjyoYm=[{}], Label1Q=[{}] Label2Q=[{}]", s014Bean.getBaseKanjyoYm(), quarterLabelAry[0], quarterLabelAry[1]);
        
        s014Bean.setLabel1Q(quarterLabelAry[0]);
        s014Bean.setLabel2Q(quarterLabelAry[1]);

        // TOTAL・前回確定値を取得([前期]表示の場合は表示は不要なので処理は通さない)
        if (!"1".equals(s014Bean.getBeforKiFlg())) {
            setTotalBefore();
        }
        
        // TOTAL・差を取得
        setTotalDiff();
        
        // ワークフロー権限を取得
        setWorkFlowFlg();
        
        s014Bean.setRirekiFlg(getRirekiFlg());
    }

    /**
     * ダウンロード・SP,NETの表示単位変更
     */
    private BigDecimal getBigValue(BigDecimal val) {
        String jpyUnit = s014Bean.getJpyUnit();
        // Excelでも指定単位で表示するようにする場合、第2引数にjpyUnitを設定し直せばOK(現在は円単位のため"1"固定)
        BigDecimal result = syuuekiUtils.changeUnit(val, "1");
        return result;
    }

    /**
     * ダウンロード
     * 各月・4半期・期のSP,NET値をセット
     */
    private void writeSpNet(Sheet sheet, int rowNum, int cellNum, Map<String, Object> data, Map<String, Object> ankenCurrencyInfo, boolean isBukkenFirst, int kbn) {
        String[] syuekiYmAry = s014Bean.getSyuekiYmAry();
        String jpyUnit = s014Bean.getJpyUnit();
        
        BigDecimal spQ1 = null;
        BigDecimal netQ1 = null;
        BigDecimal spQ2 = null;
        BigDecimal netQ2 = null;
        BigDecimal spK = null;
        BigDecimal netK = null;
        
        int wkCellNum = cellNum;
        int idx = 1;
        
        String key = "";
        if (kbn == 1) {
            key = "_SBU";
        } else if (kbn == 2) {
            key = "_SUB_TOTAL";
        }
        
        // 各月の外貨,SP,NET,粗利,M率
        for (String syuekiYm : syuekiYmAry) {
            String ymKey = idx + key;
            
            BigDecimal sp = null;
            BigDecimal net = null;
            // SP,NETは物件の最初の通貨行のみ出力する。
            if (isBukkenFirst) {
                sp = (BigDecimal) data.get("SP" + ymKey);
                net = (BigDecimal) data.get("NET" + ymKey);
            }
            
            // 外貨
            PoiUtil.setCellValue(sheet, rowNum, ++wkCellNum, ankenCurrencyInfo != null ? ankenCurrencyInfo.get("URIAGE_AMOUNT" + idx) : null);
            // SP
            PoiUtil.setCellValue(sheet, rowNum, ++wkCellNum, getBigValue(sp));
            // NET
            PoiUtil.setCellValue(sheet, rowNum, ++wkCellNum, getBigValue(net));
            // 粗利
            PoiUtil.setCellValue(sheet, rowNum, ++wkCellNum, getBigValue(syuuekiUtils.arari(sp, net)));
            // M率
            PoiUtil.setCellValue(sheet, rowNum, ++wkCellNum, Utils.changeBigDecimal(syuuekiUtils.mrate(sp, net)));
            
            idx++;
        }

        // SP,NETは物件の最初の通貨行のみ出力する。
        if (isBukkenFirst) {
            spQ1 = (BigDecimal) data.get("SP_1Q" + key);
            netQ1 = (BigDecimal) data.get("NET_1Q" + key);
            spQ2 = (BigDecimal) data.get("SP_2Q" + key);
            netQ2 = (BigDecimal) data.get("NET_2Q" + key);
            spK = (BigDecimal) data.get("SP_K" + key);
            netK = (BigDecimal) data.get("NET_K" + key);
        }
        
        ////// 第1四半期
        // 外貨
        PoiUtil.setCellValue(sheet, rowNum, ++wkCellNum, ankenCurrencyInfo != null ? ankenCurrencyInfo.get("URIAGE_AMOUNT_Q1") : null);
        // SP
        PoiUtil.setCellValue(sheet, rowNum, ++wkCellNum, getBigValue(spQ1));
        // NET
        PoiUtil.setCellValue(sheet, rowNum, ++wkCellNum, getBigValue(netQ1));
        // 粗利
        PoiUtil.setCellValue(sheet, rowNum, ++wkCellNum, getBigValue(syuuekiUtils.arari(spQ1, netQ1)));
        // M率
        PoiUtil.setCellValue(sheet, rowNum, ++wkCellNum, Utils.changeBigDecimal(syuuekiUtils.mrate(spQ1, netQ1)));
            
        ////// 第2四半期
        // 外貨
        PoiUtil.setCellValue(sheet, rowNum, ++wkCellNum, ankenCurrencyInfo != null ? ankenCurrencyInfo.get("URIAGE_AMOUNT_Q2") : null);
        // SP
        PoiUtil.setCellValue(sheet, rowNum, ++wkCellNum, getBigValue(spQ2));
        // NET
        PoiUtil.setCellValue(sheet, rowNum, ++wkCellNum, getBigValue(netQ2));
        // 粗利
        PoiUtil.setCellValue(sheet, rowNum, ++wkCellNum, getBigValue(syuuekiUtils.arari(spQ2, netQ2)));
        // M率
        PoiUtil.setCellValue(sheet, rowNum, ++wkCellNum, Utils.changeBigDecimal(syuuekiUtils.mrate(spQ2, netQ2)));
            
        ////// 期合計
        // 外貨
        PoiUtil.setCellValue(sheet, rowNum, ++wkCellNum, ankenCurrencyInfo != null ? ankenCurrencyInfo.get("URIAGE_AMOUNT_K") : null);
        // SP
        PoiUtil.setCellValue(sheet, rowNum, ++wkCellNum, getBigValue(spK));
        // NET
        PoiUtil.setCellValue(sheet, rowNum, ++wkCellNum, getBigValue(netK));
        // 粗利
        PoiUtil.setCellValue(sheet, rowNum, ++wkCellNum, getBigValue(syuuekiUtils.arari(spK, netK)));
        // M率
        PoiUtil.setCellValue(sheet, rowNum, ++wkCellNum, Utils.changeBigDecimal(syuuekiUtils.mrate(spK, netK)));
        
        // 完売月
        if (kbn == 0) {
            PoiUtil.setCellValue(sheet, rowNum, ++wkCellNum, syuuekiUtils.exeFormatYm((Date)data.get("URIAGE_END_FIN")));
        }
    }
    
    /**
     * 対象物件の外貨データ一覧を取得
     */
    //private List<Map<String, Object>> getAnkenCurrencyList(String ankenId, String beforeKiFlg) throws Exception {
    private List<Map<String, Object>> getAnkenCurrencyList(Map<String, Object> data, String beforeKiFlg) throws Exception {
        String sqlFilePath = "/sql/S014/selectBukkenCurrencyList.sql";
        
        Map<String, Object> condition = getBukkenCondition(beforeKiFlg, false);
        condition.put("ankenId", data.get("ANKEN_ID"));
        condition.put("rirekiId", data.get("RIREKI_ID"));
        condition.put("rirekiFlg", data.get("RIREKI_FLG"));
        condition.put("kanjyoYm", s014Bean.getKanjyoYm());
        // 進行基準案件の場合は、SYU_KI_SP_CUR_TBL.RENBANを'0000'固定で参照
        if ("1".equals(s014Bean.getSalesClass())) {
            condition.put("renban", "0000");
        }

        // SQLを取得
        SqlFile sqlFile = new SqlFile();
        String sql = sqlFile.getSqlString(sqlFilePath, condition);
        Object[] params = sqlFile.getSqlParams(sqlFilePath, condition);
        
        // SQL実行
        List<Map<String, Object>> list = dbUtilsExecutor.dbUtilsGetSqlList(em, sql, params);
        
        // 通貨データが取得できない場合は、データが存在しない旨の情報をlistに入れておく。
        if (list == null || list.isEmpty()) {
            list = new ArrayList<>();
            Map<String, Object> info = new HashMap<>();
            info.put("ANKEN_ID", "NO_ANKEN_CURRENCY_DATE");
            list.add(info);
        }
        
        return list;
    }
    
    /**
     * ダウンロード
     * 各月・4半期・期のタイトルを設定
     */
    private void writeTitle(Sheet sheet, boolean nextPeriod) throws ParseException {
        int rowNum = 0;
        int startCell = 7;
        
        int cellNum = startCell;
        int shiftCellCount = 5;

        String[] syuekiYmAry = s014Bean.getSyuekiYmAry();
        
        Date kanjyoDate = Utils.parseDate(s014Bean.getDispBaseKanjyoYm());
        Date dispKanjyoDate = Utils.parseDate(s014Bean.getDispBaseKanjyoYm());;
        if (nextPeriod) {
            kanjyoDate = s014Bean.getNextKanjyoYmData();
        }

        if(nextPeriod){
            kanjyoDate = s014Bean.getNextKanjyoYmData();
        }
        
        int nendo = SyuuekiUtils.getIntegerYear(syuekiYmAry[0]);
        String[] quarterLabelAry = syuuekiUtils.getQuarterLabel(kanjyoDate);
        
        String yearLabel = Label.getValue(Label.year);
        String ruikeiLabel = Label.getValue(Label.ruikei2);
        
        String syueki1Q = nendo + yearLabel + quarterLabelAry[0] + ruikeiLabel;
        String syueki2Q = nendo + yearLabel + quarterLabelAry[1] + ruikeiLabel;
        String syuekiKi = nendo + yearLabel 
                + StringUtils.substring(syuuekiUtils.kikanLabel(s014Bean.getSyuekiKi()), 4, 6) + ruikeiLabel;
        
        // 各月の年月表記ラベルをセット
        for (String syuekiYm : syuekiYmAry) {
            String label = SyuuekiUtils.getIntegerYear(syuekiYm) + Label.getValue(Label.year)
                    + SyuuekiUtils.getIntegerMonth(syuekiYm) + Label.getValue(Label.month)
                    //+ syuuekiUtils.getJYLabel(kanjyoDate, syuekiYm);
                    + syuuekiUtils.getJYLabel(dispKanjyoDate, syuekiYm);
            
            PoiUtil.setCellValue(sheet, rowNum, cellNum, label);
            cellNum = cellNum + shiftCellCount;
        }

        ////// 第1四半期
        PoiUtil.setCellValue(sheet, rowNum, cellNum, syueki1Q);
        cellNum = cellNum + shiftCellCount;
        
        ////// 第2四半期
        PoiUtil.setCellValue(sheet, rowNum, cellNum, syueki2Q);
        cellNum = cellNum + shiftCellCount;
        
        ////// 期合計
        PoiUtil.setCellValue(sheet, rowNum, cellNum, syuekiKi);
    }

    /**
     * ダウンロード実行
     * @param workbook
     * @throws java.lang.Exception
     */
    public void outputDownloadExcel(Workbook workbook) throws Exception {
        int startRow;
        int rowNum;
        int listIndex;
        Sheet sheet;
        boolean nextPeriodArray[ ] = {false, true};
        
        // WFテーブルを検索
        SyuWfControlTbl entity
                = syuWfControlTblFacade.findPk(s014Bean.getDivisionCode(), s014Bean.getGroupCode(), s014Bean.getSalesClass(), s014Bean.getKanjyoYm(), s014Bean.getHonsyaShisyaKbn(), s014Bean.getTeamCode());

        // WFテーブル取得情報をbeanにコピー
        PropertyUtils.copyProperties(s014Bean, entity);
        
        // 検索対象の基準の勘定年月を取得
        //setBaseKanjyoYm(s014Bean.getBeforKiFlg());

        for (boolean nextPeriod : nextPeriodArray) {
            startRow = 2;
            rowNum = startRow;
            listIndex = 0;

            String beforeKiFlg = null;
            if (!nextPeriod) {
                // 現在表示している期のデータを出力する場合は、画面で指定した[前期]プルタウンのFLGを取得
                beforeKiFlg = s014Bean.getBeforKiFlg();
            }
            
            // 検索対象の基準の勘定年月を取得
            setBaseKanjyoYm(beforeKiFlg);
            
            // 表示対象の月、4半期、期を取得
            setDispKikan(s014Bean.getBeforKiFlg(), nextPeriod);

            // 対象物件一覧を取得
            setBukkenList(beforeKiFlg);

            List<Map<String, Object>> list = s014Bean.getBukkenList();
            Map<String, Object> totalInfo = s014Bean.getTotalInfo();

            // シート取得
            logger.info("nextPeriod=[{}], s014Bean.getSyuekiKi()=[{}]", nextPeriod, s014Bean.getSyuekiKi());
            int sheetAt = nextPeriod ? 1 : 0;
            workbook.setSheetName(sheetAt, s014Bean.getSyuekiKi().substring(0, s014Bean.getSyuekiKi().length() - 1));
            sheet = workbook.getSheetAt(sheetAt);

            // タイトル部に年月を設定
            writeTitle(sheet, nextPeriod);

            // 物件行のスタイルを取得
            Row row = PoiUtil.getRow(sheet, startRow, true);
            List<Cell> bukkenCellList = PoiUtil.getCellList(row);

            // サブBU集計行、サブ集計行のスタイルを取得
            row = PoiUtil.getRow(workbook.getSheetAt(2), 2, true);
            List<Cell> subTotalCellList = PoiUtil.getCellList(row);

            for (Map<String, Object> data : list) {
                boolean isBukkenFirst = true;

                String sbuCode = StringUtils.defaultString((String) data.get("SUB_BU_ID"));
                String sbuName = StringUtils.defaultString((String) data.get("SUB_BU_NAME"));
                String subTotalCode = StringUtils.defaultString((String) data.get("SUB_TOTAL_CODE"));
                String subTotalName = StringUtils.defaultString((String) data.get("SUB_TOTAL_NAME"));

                Map<String, Object> nextData = null;
                String nextTotalCode = "";
                String nextSbuCode = "";
                if (listIndex < list.size() - 1) {
                    nextData = list.get(listIndex + 1);
                    nextTotalCode = StringUtils.defaultString((String) nextData.get("SUB_TOTAL_CODE"));
                    nextSbuCode = StringUtils.defaultString((String) nextData.get("SUB_BU_ID"));
                }

                // 現在行の案件の外貨データ一覧を取得
                //List<Map<String, Object>> ankenCurrencyList = getAnkenCurrencyList((String)data.get("ANKEN_ID"), data.get("RIREKI_ID"), data.get("RIREKI_FLG"), beforeKiFlg);
                List<Map<String, Object>> ankenCurrencyList = getAnkenCurrencyList(data, beforeKiFlg);

                for (Map<String, Object> ankenCurrencyInfo : ankenCurrencyList) {
                    int cellNum = 0;

                    // 2行目以降は1行目のスタイルをコピー
                    if (rowNum > startRow) {
                        row = PoiUtil.getRow(sheet, rowNum, true);
                        PoiUtil.copyRowStyleValue(row, bukkenCellList, false);
                    }

                    // サブＢＵ
                    PoiUtil.setCellValue(sheet, rowNum, cellNum, sbuName);
                    // 営業部課
                    PoiUtil.setCellValue(sheet, rowNum, ++cellNum, subTotalName);
                    // チームコード
                    PoiUtil.setCellValue(sheet, rowNum, ++cellNum, data.get("TEAM_CODE"));
                    // 番号
                    PoiUtil.setCellValue(sheet, rowNum, ++cellNum, data.get("NO_LABEL"));
                    // 案件名称
                    PoiUtil.setCellValue(sheet, rowNum, ++cellNum, data.get("ANKEN_NAME"));
                    // 設置場所
                    PoiUtil.setCellValue(sheet, rowNum, ++cellNum, data.get("STCH_NAME"));
                    // 通貨
                    PoiUtil.setCellValue(sheet, rowNum, ++cellNum, ankenCurrencyInfo.get("CURRENCY_CODE"));

                    // 各月・第1四半期・第2四半期・期合計の外貨,SP,NET,粗利,M率
                    writeSpNet(sheet, rowNum, cellNum, data, ankenCurrencyInfo, isBukkenFirst, 0);
                    
                    if (ankenCurrencyList.size() - 1 == ankenCurrencyList.lastIndexOf(ankenCurrencyInfo)) {
                        // サブ集計コードが次行と異なる場合、サブ集計行を出力
                        if (listIndex == list.size() - 1 || !subTotalCode.equals(nextTotalCode) || !sbuCode.equals(nextSbuCode)) {
                            rowNum++;

                            // サブ集計行のスタイルをコピー
                            row = PoiUtil.getRow(sheet, rowNum, true);
                            PoiUtil.copyRowStyleValue(row, subTotalCellList, true);

                            sheet.addMergedRegion(new CellRangeAddress(rowNum, rowNum, 0, 6));
                            PoiUtil.setCellValue(sheet, rowNum, 0, subTotalName + "計");

                            // 各月・第1四半期・第2四半期・期合計の外貨,SP,NET,粗利,M率
                            writeSpNet(sheet, rowNum, cellNum, data, ankenCurrencyInfo, true, 2);
                        }

                        // サブBUが次行と異なる場合、サブBU集計行を出力
                        if (listIndex == list.size() - 1 || !sbuCode.equals(nextSbuCode)) {
                            rowNum++;

                            // サブ集計行のスタイルをコピー
                            row = PoiUtil.getRow(sheet, rowNum, true);
                            PoiUtil.copyRowStyleValue(row, subTotalCellList, true);

                            sheet.addMergedRegion(new CellRangeAddress(rowNum, rowNum, 0, 6));
                            PoiUtil.setCellValue(sheet, rowNum, 0, sbuName + " 合計");

                            // 各月・第1四半期・第2四半期・期合計の外貨,SP,NET,粗利,M率
                            writeSpNet(sheet, rowNum, cellNum, data, ankenCurrencyInfo, true, 1);
                        }
                    }

                    isBukkenFirst = false;
                    rowNum++;
                }

                listIndex++;
            }

            /////// 合計行の出力 /////////
            row = PoiUtil.getRow(sheet, rowNum, true);
            PoiUtil.copyRowStyleValue(row, subTotalCellList, false);

            sheet.addMergedRegion(new CellRangeAddress(rowNum, rowNum, 0, 6));
            PoiUtil.setCellValue(sheet, rowNum, 0, "合計");

            // 各月・第1四半期・第2四半期・期合計の外貨,SP,NET,粗利,M率
            writeSpNet(sheet, rowNum, 6, totalInfo, null, true, 0);
        }
    }
    
    /**
     * コメント入力子画面のデータを取得
     * @throws java.lang.Exception
     */
    public void commentxExecute() throws Exception {
        // WFテーブルを検索
       SyuWfControlTbl entity
                   = syuWfControlTblFacade.findPk(s014Bean.getDivisionCode(), s014Bean.getGroupCode(), s014Bean.getSalesClass(), s014Bean.getKanjyoYm(), s014Bean.getHonsyaShisyaKbn(), s014Bean.getTeamCode());

        List<Map<String, Object>> commentList = new ArrayList<>();
        Map<String, Object> commentInfo = new HashMap<>();
        List<SyuWfControlTbl> kakuteiJokyoList = new ArrayList<>();
        //String confirmMessage;

        commentInfo.put("name", loginUserInfo.getUserName());
        commentInfo.put("comment", "");
        commentInfo.put("kbn", s014Bean.getStatusKbn());
        commentList.add(commentInfo);
        
        // 進行基準案件
        if ("H".equals(s014Bean.getStatusKbn())) {
            ///// 確定済の場合
            // 2番目:確定者名、確定コメント
            if (entity.getSyoninAt() != null && StringUtils.isNotEmpty(entity.getSyoninComment()) && !s014Bean.isIppan()) {
                commentInfo = new HashMap<>(); 
                commentInfo.put("name", entity.getSyoninName());
                commentInfo.put("comment", entity.getSyoninComment());
                commentInfo.put("kbn", "S");
                commentList.add(commentInfo);
            }

            //confirmMessage = Label.getValue(Label.confirmFixedReleaseMessage);

        } else {
            ///// 確定済以外の場合
            // 2番目:否認者、否認コメント
            if (entity.getHininAt() != null && StringUtils.isNotEmpty(entity.getHininComment())  && !s014Bean.isIppan()) {
                commentInfo = new HashMap<>(); 
                commentInfo.put("name", entity.getHininName());
                commentInfo.put("comment", entity.getHininComment());
                commentInfo.put("kbn", "H");
                commentList.add(commentInfo);
            }

            //confirmMessage = Label.getValue(Label.confirmFixedMessage);
        }

        if (s014Bean.isIppan()) {
            ////// 一般案件
            // 確定(解除)対象のチームコード一覧を取得して、コメント画面に一覧表示
            kakuteiJokyoList = syuWfControlTblFacade.findBukaCode(s014Bean.getDivisionCode(), entity.getcBukaCode(), s014Bean.getSalesClass(), s014Bean.getKanjyoYm(), "0");
            
            // 本社確定/支社確定解除が可能であるかを設定
            this.setShisyaKakuteiFlg(kakuteiJokyoList);

        } else {
            ////// 進行基準案件
            s014Bean.setKakuteiActionFlg(true);
        }

        setCommentInfo();

        s014Bean.setCommentList(commentList);
        //s014Bean.setCommentConfirmMessage(confirmMessage);
        s014Bean.setKakuteiJokyoList(kakuteiJokyoList);
    }

    /**
     * コメント画面のタイトルを取得
     */
    private void setCommentInfo() {
        String title;
        String confirmMessage;

        if ("H".equals(s014Bean.getStatusKbn())) {
            if ("1".equals(s014Bean.getTeishutsuFlg())) {
                title = Label.dispNameWfCommentTH.getLabel();
                confirmMessage = Label.confirmTeishutsuReleaseMessage.getLabel();
            } else {
                title = Label.dispNameWfCommentH.getLabel();
                confirmMessage = Label.confirmFixedReleaseMessage.getLabel();
            }
        } else {
            if ("1".equals(s014Bean.getTeishutsuFlg())) {
                title = Label.dispNameWfCommentTS.getLabel();
                confirmMessage = Label.confirmTeishutsuMessage.getLabel();
            } else {
                title = Label.dispNameWfCommentS.getLabel();
                confirmMessage = Label.confirmFixedMessage.getLabel();
            }
        }

        s014Bean.setCommentTitle(title);
        s014Bean.setCommentConfirmMessage(confirmMessage);
    }

    /**
     * 本社確定/支社確定解除が可能であるかを設定(一般案件時)
     */
    private void setShisyaKakuteiFlg(List<SyuWfControlTbl> kakuteiJokyoList) throws Exception {
        boolean kakuteiActionFlg = true;
        boolean honsyaKakuteiFlg = false;
        boolean kakuteiActionFlgA = true;
        
        String honsyaKakuteiStatus = STATUS_CREATING;
        
        // 販直費カテゴリー別内訳
        List<HashMap<String, String>> dataCheckMapList = new ArrayList<>();
        
        //本社
        if(ConstantString.honsyaKbn.equals(s014Bean.getHonsyaShisyaKbn())){
            for (SyuWfControlTbl rec : kakuteiJokyoList) {
                kakuteiActionFlg = true;
                honsyaKakuteiFlg = false;
                HashMap<String, String> dataCheck = new HashMap<>();
                
                //本社でかつ確定ステータスならば本社で1チームのうち1つでも確定済
                if (ConstantString.honsyaKbn.equals(rec.getHonsyaShisyaKbn())) {
                    if (STATUS_KAKUTEI.equals(rec.getStatus())) {
                        honsyaKakuteiFlg = true;
                    }
                    
                    // 本社での最新ステータスを取得
                    if (StringUtils.defaultString(rec.getStatus()).compareTo(honsyaKakuteiStatus) > 0) {
                        honsyaKakuteiStatus = rec.getStatus();
                    }
                }

                // 今表示中の本社・支社区分と異なるデータのみチェック
                if (!s014Bean.getHonsyaShisyaKbn().equals(rec.getHonsyaShisyaKbn())) {
                    // 処理対象データが本社の場合
                    if (ConstantString.honsyaKbn.equals(s014Bean.getHonsyaShisyaKbn())) {
                        // 支社の未確定データが存在する場合は確定/確定解除不可
                        //if (ConstantString.shisyaKbn.equals(rec.getHonsyaShisyaKbn()) && STATUS_CREATING.equals(rec.getStatus())) {
                        if (ConstantString.shisyaKbn.equals(rec.getHonsyaShisyaKbn()) && !STATUS_KAKUTEI.equals(rec.getStatus())) {
                            kakuteiActionFlg = false;
                        }
                    }

                    // 処理対象データが支社の場合
                    if (ConstantString.shisyaKbn.equals(s014Bean.getHonsyaShisyaKbn())) {
                        // 本社確定データが存在する場合は確定/確定解除不可
                        if (honsyaKakuteiFlg) {
                            kakuteiActionFlg = false;
                        }
                    }
                }

                if (!kakuteiActionFlg){
                    dataCheck.put("kaijoFlg", "0");
                    kakuteiActionFlgA = false;    
                }else{
                    dataCheck.put("kaijoFlg", "1");
                }
                dataCheckMapList.add(dataCheck);                    
                logger.info("[setShisyaKakuteiFlg] H honsyaShisyaKbn=[{}], status=[{}] kakuteiActionFlg=[{}]", rec.getHonsyaShisyaKbn(), rec.getStatus(), kakuteiActionFlg);
            }
            s014Bean.setKaijoList(dataCheckMapList);  
        
        } else {
            //支社
            //確定確定解除を判断変更
            for (SyuWfControlTbl rec : kakuteiJokyoList) {
                kakuteiActionFlg = true;
                honsyaKakuteiFlg = false;
                HashMap<String, String> dataCheck = new HashMap<>();
         
                List<SyuWfControlTbl> groupList
                    = syuWfControlTblFacade.findGroupCode(rec.getDivisionCode(), rec.getGroupCode(), rec.getSalesClass(), rec.getKanjyoYm());

                for (SyuWfControlTbl rec2 : groupList) {

                    //本社でかつ確定ステータスならば本社で1チームのうち1つでも確定済
                    if (ConstantString.honsyaKbn.equals(rec2.getHonsyaShisyaKbn())) {
                        if (STATUS_KAKUTEI.equals(rec2.getStatus())) {
                            honsyaKakuteiFlg = true;
                        }
                        
                        // 本社での最新ステータスを取得
                        if (StringUtils.defaultString(rec.getStatus()).compareTo(honsyaKakuteiStatus) > 0) {
                            honsyaKakuteiStatus = rec.getStatus();
                        }
                    }

                    // 今表示中の本社・支社区分と異なるデータのみチェック
                    if (!s014Bean.getHonsyaShisyaKbn().equals(rec2.getHonsyaShisyaKbn())) {
                        // 処理対象データが本社の場合
                        if (ConstantString.honsyaKbn.equals(s014Bean.getHonsyaShisyaKbn())) {
                            // 支社作成中データが存在する場合は確定/確定解除不可
                            if (ConstantString.shisyaKbn.equals(rec2.getHonsyaShisyaKbn()) && STATUS_CREATING.equals(rec2.getStatus())) {
                                kakuteiActionFlg = false;
                            }
                        }

                        // 処理対象データが支社の場合
                        if (ConstantString.shisyaKbn.equals(s014Bean.getHonsyaShisyaKbn())) {
                            // 本社確定データが存在する場合は確定/確定解除不可
                            if (honsyaKakuteiFlg) {
                                kakuteiActionFlg = false;
                            }
                        }
                    }

                    logger.info("[setShisyaKakuteiFlg] S honsyaShisyaKbn=[{}], status=[{}] kakuteiActionFlg=[{}]", rec2.getHonsyaShisyaKbn(), rec2.getStatus(), kakuteiActionFlg);
                    if (!kakuteiActionFlg) {
                        kakuteiActionFlgA = false;
                        break;
                    }
               }
               
               if (!kakuteiActionFlg){
                    dataCheck.put("kaijoFlg", "0");
               }else{
                    dataCheck.put("kaijoFlg", "1");
               }
               dataCheckMapList.add(dataCheck);

            }

            s014Bean.setKaijoList(dataCheckMapList);  
        }

        /*     20160511 DEL
                //グループの取り方を変える。
                List<SyuWfControlTbl> groupList
                    = syuWfControlTblFacade.findGroupCode(rec.getDivisionCode(), rec.getGroupCode(), rec.getSalesClass(), rec.getKanjyoYm());
        
        for (SyuWfControlTbl rec : groupList) {
            if (ConstantString.honsyaKbn.equals(rec.getHonsyaShisyaKbn()) && STATUS_KAKUTEI.equals(rec.getStatus())) {
                honsyaKakuteiFlg = true;
            }

            // 今表示中の本社・支社区分と異なるデータのみチェック
            if (!s014Bean.getHonsyaShisyaKbn().equals(rec.getHonsyaShisyaKbn())) {
                // 処理対象データが本社の場合
                if (ConstantString.honsyaKbn.equals(s014Bean.getHonsyaShisyaKbn())) {
                    // 支社作成中データが存在する場合は確定/確定解除不可
                    if (ConstantString.shisyaKbn.equals(rec.getHonsyaShisyaKbn()) && STATUS_CREATING.equals(rec.getStatus())) {
                        kakuteiActionFlg = false;
                    }
                }
                
                // 処理対象データが支社の場合
                if (ConstantString.shisyaKbn.equals(s014Bean.getHonsyaShisyaKbn())) {
                    // 本社確定データが存在する場合は確定/確定解除不可
                    if (honsyaKakuteiFlg) {
                        kakuteiActionFlg = false;
                    }
                }
            }

            // 今表示中の本社・支社区分と異なるデータのみチェック
//            if (!s014Bean.getHonsyaShisyaKbn().equals(rec.getHonsyaShisyaKbn())) {
//                if (honsyaKakuteiFlg  // 本社確定済みデータが存在するかをチェック
//                // 支社作成済みデータが存在するかをチェック
//                    || (ConstantString.shisyaKbn.equals(rec.getHonsyaShisyaKbn()) && STATUS_CREATING.equals(rec.getStatus()))){
//                    kakuteiActionFlg = false;
//                }
//            }
            
            logger.info("[setShisyaKakuteiFlg] honsyaShisyaKbn=[{}], status=[{}] kakuteiActionFlg=[{}]", rec.getHonsyaShisyaKbn(), rec.getStatus(), kakuteiActionFlg);
            if (!kakuteiActionFlg) {
                break;
            }
        }
        s014Bean.setKakuteiActionFlg(kakuteiActionFlg);               
     20160511 DEL*/
        //s014Bean.setShisyaKakuteiFlg(kakuteiFlg);

        s014Bean.setKakuteiActionFlg(kakuteiActionFlgA);
        s014Bean.setHonsyaKakuteiFlg(honsyaKakuteiFlg);
        s014Bean.setHonsyaKakuteiStatus(honsyaKakuteiStatus);
    }

    
    /**
     * 区分により実行するワークフローの切り分け
     */
    private Map<String, Object> getWorkFlowCondition() {
        Map<String, Object> condition = new HashMap<>();
        
        condition.put("divisionCode", s014Bean.getDivisionCode());
        condition.put("groupCode", s014Bean.getGroupCode());
        condition.put("salesClass", s014Bean.getSalesClass());
        condition.put("kanjyoYm", s014Bean.getKanjyoYm());
        condition.put("honsyaShisyaKbn", s014Bean.getHonsyaShisyaKbn());
        condition.put("teamCode", s014Bean.getTeamCode());
        condition.put("cBukaCode", s014Bean.getcBukaCode());
        condition.put("userId", loginUserInfo.getUserId());
        condition.put("userName", loginUserInfo.getUserName());
        condition.put("comment", s014Bean.getComment());
        
        condition.put("teishutsuStatus", STATUS_TEISHUTSU);
        condition.put("teishutsuRirekiId", ConstantString.teishutsuRirekiId);
        condition.put("hininCommentFlg", getHininCommentFlg());
        
        
//        if(s014Bean.getConcatTeamCode()!=null && s014Bean.getConcatTeamCode().length()>0){
//            condition.put("concatTeamCode", s014Bean.getConcatTeamCode().split(",", 0));
//        }

        return condition;
    }

    /**
     * 履歴IDを取得(確定/確定解除の処理用)
     */
    private String getWfRirekiId(String _teamCd) throws Exception {

        String rirekiId ="";
        SyuWfControlTbl entity
                   = syuWfControlTblFacade.findPk(  s014Bean.getDivisionCode(), s014Bean.getGroupCode(), s014Bean.getSalesClass(), s014Bean.getKanjyoYm(), s014Bean.getHonsyaShisyaKbn(), _teamCd);

        rirekiId = String.valueOf(entity.getRirekiId());

        return rirekiId;
    }

     /**
     * 履歴IDを取得(確定/確定解除の処理用)
     */
    private String getWfRirekiId2(String _teamCd,String _groupCd) throws Exception {

        String rirekiId ="";

        SyuWfControlTbl entity
                   = syuWfControlTblFacade.findPk(  s014Bean.getDivisionCode(), _groupCd, s014Bean.getSalesClass(), s014Bean.getKanjyoYm(), s014Bean.getHonsyaShisyaKbn(), _teamCd);

        rirekiId = String.valueOf(entity.getRirekiId());
        
        return rirekiId;
    }
    
    
//    private List<String> getWfRirekiId() throws Exception {
//        List<String> rirekiIdList = new ArrayList<>();
//        if (s014Bean.isIppan()) {
//            // 一般
//            List<SyuWfControlTbl> list
//                = syuWfControlTblFacade.findTargetBukken(s014Bean.getDivisionCode(), s014Bean.getSalesClass(), s014Bean.getKanjyoYm(), s014Bean.getcBukaCode(), s014Bean.getConcatTeamCode());
//
//            for(SyuWfControlTbl rec : list){
//                rirekiIdList.add(String.valueOf(rec.getRirekiId()));
//            }
//
//        } else {
//            // 進行基準
//            SyuWfControlTbl entity
//                    = syuWfControlTblFacade.findPk(s014Bean.getDivisionCode(), s014Bean.getGroupCode(), s014Bean.getSalesClass(), s014Bean.getKanjyoYm(), s014Bean.getHonsyaShisyaKbn(), s014Bean.getTeamCode());
//            rirekiIdList.add(String.valueOf(entity.getRirekiId()));
//        }
//        
//        return rirekiIdList;
//    }

    /**
     * 確定・提出処理の処理順序をListで取得
     * ※(原子力)で確定した場合、提出→確定と連続で処理を行うため
     * 
     * @param 確定・提出(またはその解除)を行うための履歴作成パッケージ実行に利用する処理FLGやステータスを格納したMap
     *   key:SYORI_FLG=履歴作成パッケージに渡す処理FLG(0:確定 5:提出作成 9:確定・提出解除)
     *   key:STATUS=SYU_WF_CONTROL_TBL更新に利用するステータスコード
     */
    private List<Map<String, String>> getSyoriFlgList(SyuWfControlTbl entity) {
        List<Map<String, String>> syoriFlgList = new ArrayList<>();

        String nowStatus = entity.getStatus();   // 更新前のステータス
        String status;  // 更新対象のステータス
        
        // 事業部コード:(原子力)であるかを判断
        boolean isNuclearDivision = divisionComponentPage.isNuclearDivision(s014Bean.getDivisionCode());
        
        if ("H".equals(s014Bean.getStatusKbn())) {
            //////////////////////////////////////
            ////// 確定解除 or 提出解除の場合 /////
            //////////////////////////////////////
            Map<String, String> info = new HashMap<>();
            // (原子力)の確定解除は"提出用"に戻す それ以外((火水ジ)等)は一気に作成済まで戻す
            //if (s014Bean.getDivisionCode().equals(divGen) && !"1".equals(s014Bean.getTeishutsuFlg())) {
            if (isNuclearDivision && !"1".equals(s014Bean.getTeishutsuFlg())) {
                status = STATUS_TEISHUTSU;
            } else {
                status = STATUS_CREATING;
            }

            info.put("STATUS", status);
            info.put("SYORI_FLG", "9");
            syoriFlgList.add(info);

        } else {
            //////////////////////////////
            ////// 確定 or 提出の場合 /////
            //////////////////////////////
            //if (s014Bean.getDivisionCode().equals(divGen)) {
            if (isNuclearDivision) {
                //// (原子力)の場合
                if (  "1".equals(s014Bean.getTeishutsuFlg())   // [提出]
                   || nowStatus.equals(STATUS_CREATING) && !"1".equals(s014Bean.getTeishutsuFlg())  // 現在が作成中で一気に確定処理を行う場合
                ) {
                    Map<String, String> infoTeishutsu = new HashMap<>();
                    infoTeishutsu.put("STATUS", STATUS_TEISHUTSU);
                    infoTeishutsu.put("SYORI_FLG", "5");
                    syoriFlgList.add(infoTeishutsu);
                }

                // 確定処理
                if (!"1".equals(s014Bean.getTeishutsuFlg())) {
                    Map<String, String> infoKakutei = new HashMap<>();
                    infoKakutei.put("STATUS", STATUS_KAKUTEI);
                    infoKakutei.put("SYORI_FLG", "1");
                    syoriFlgList.add(infoKakutei);
                }

            } else {
                //// (火水ジ)の場合
                Map<String, String> infoKakutei = new HashMap<>();
                infoKakutei.put("STATUS", STATUS_KAKUTEI);
                infoKakutei.put("SYORI_FLG", "0");
                syoriFlgList.add(infoKakutei);
            }

        }

        return syoriFlgList;
    }

    /**
     * (進行基準)ワークフロー実行
     */
    private void shinkoWorkFlowExecute() throws Exception {
        logger.info("[shinkoWorkFlowExecute]");
        //List<String> rirekiIdList = null;
        String rirekiId = "";
        String updateRirekiId = "";
        String targetTeamCode = s014Bean.getTeamCode();

        // ワークフローTBLの更新用パラメータを取得
        Map<String, Object> condition = this.getWorkFlowCondition();

//        // ワークフロー種類による切り分け
//        if ("S".equals(s014Bean.getStatusKbn())) {
//            if ("1".equals(s014Bean.getTeishutsuFlg())) {
//                // 提出用作成処理
//                condition.put("status", STATUS_TEISHUTSU);
//                syoriFlg = "5";
//            } else {
//                // 確定処理
//                condition.put("status", STATUS_KAKUTEI);
//                syoriFlg = "0";
//            }
//
//        } else if ("H".equals(s014Bean.getStatusKbn())) {
//            // 否認
//            condition.put("status", STATUS_CREATING);
//            syoriFlg = "9";
//            
//            // ワークフローTBLから履歴IDを取得
//            // (否認時のみ。否認ではテーブル更新で履歴IDをクリアしてしまうため、予め取得しておく)
//            rirekiId = this.getWfRirekiId(targetTeamCode);
//        }
//        // ワークフローTBLの更新
//        syuWfControlTblFacade.updateWorkFlow(condition);
//
//        // ワークフローTBLから履歴IDを取得
//        // (確定時のみ。更新時に履歴IDを発行しているため、発行したIDはこのタイミングで取得)
//        //if (rirekiIdList == null || rirekiIdList.isEmpty()) {
//        if (StringUtils.isEmpty(rirekiId)) {
//            rirekiId = this.getWfRirekiId(targetTeamCode);
//        }
//
//        // 確定/確定解除パッケージ(進行)をCall
//        callRirekiMake(rirekiId, syoriFlg);

        SyuWfControlTbl entity
                   = syuWfControlTblFacade.findPk(s014Bean.getDivisionCode(), s014Bean.getGroupCode(), s014Bean.getSalesClass(), s014Bean.getKanjyoYm(), s014Bean.getHonsyaShisyaKbn(), targetTeamCode);

        List<Map<String, String>> syoriFlgList = getSyoriFlgList(entity);

        for (Map<String, String> syoriFlgInfo: syoriFlgList) {
            String syoriFlg = syoriFlgInfo.get("SYORI_FLG");
            String status = syoriFlgInfo.get("STATUS");

            Map<String, Object> worFlowExecuteCondition = new HashMap<>(condition);
            worFlowExecuteCondition.put("status", status);

            if ("H".equals(s014Bean.getStatusKbn())) {
                // ワークフローTBLから履歴IDを取得(履歴パッケージの実行に利用)
                // (否認時のみ。否認ではテーブル更新で履歴IDをクリアしてしまうため、予め取得しておく)
                rirekiId = this.getWfRirekiId(targetTeamCode);
                logger.info("[shinkoWorkFlowExecute] update hinin STATUS=[{}] syoriFlg=[{}] rirekiId=[{}]", status, syoriFlg, rirekiId);
                
                // "提出用"ステータスに変更される場合はRIREKI_ID=1をWF_CONTROL_TBLに登録
                if (status.equals(STATUS_TEISHUTSU)) {
                    updateRirekiId = ConstantString.teishutsuRirekiId;
                }

            } else {
                // 提出/確定時は新規の履歴IDを取得(履歴パッケージ+WF_CONTROL_TBLの登録に利用)
                rirekiId = createNewRirekiId(status);
                updateRirekiId = rirekiId;
                logger.info("[shinkoWorkFlowExecute] update kakutei STATUS=[{}] syoriFlg=[{}] rirekiId=[{}]", status, syoriFlg, rirekiId);
            }
            
            if (StringUtils.isNotEmpty(updateRirekiId)) {
                worFlowExecuteCondition.put("rirekiId", Integer.parseInt(updateRirekiId));
            }
            
            // ワークフローTBLの更新
            syuWfControlTblFacade.updateWorkFlow(worFlowExecuteCondition);

//            // ワークフローTBLから履歴IDを取得
//            // (確定時のみ。更新時に履歴IDを発行しているため、発行したIDはこのタイミングで取得)
//            if (StringUtils.isEmpty(rirekiId)) {
//                rirekiId = this.getWfRirekiId(targetTeamCode);
//            }

            // 確定/確定解除パッケージ(進行)をCall
            callRirekiMake(rirekiId, syoriFlg);
        }

    }

    /**
     * (一般)ワークフロー実行
     * @param processKbn 10:提出 20:確定
     */
    private void ippanWorkFlowExecute() throws Exception {
        logger.info("[ippanWorkFlowExecute]");
        //List<String> rirekiIdList = new ArrayList<>();
//        String syoriFlg = "0";
        
        // ワークフローTBLの更新用パラメータを取得
        Map<String, Object> condition = this.getWorkFlowCondition();

//        // ワークフロー種類による切り分け
//        if ("S".equals(s014Bean.getStatusKbn())) {
//            if ("1".equals(s014Bean.getTeishutsuFlg())) {
//                // 提出用作成処理
//                condition.put("status", STATUS_TEISHUTSU);
//                syoriFlg = "5";
//            } else {
//                // 確定処理
//                condition.put("status", STATUS_KAKUTEI);
//                syoriFlg = "0";
//            }
//        } else if ("H".equals(s014Bean.getStatusKbn())) {
//            // 否認(解除)
//            condition.put("status", STATUS_CREATING);
//            syoriFlg = "9";
//        }

        // 確定・提出(or確定解除・提出解除) 対象のチームコードを取得
        // 更新対象のチームコードがカンマ区切りで指定されてくるので分解して配列セット
        String[] targetTeamCode = StringUtils.split(s014Bean.getConcatTeamCode(), ",", 0);

        if (targetTeamCode != null) {
            // 処理対象チームコード毎に履歴IDを取得して、確定(or確定解除)処理を実施
            for (String teamCode : targetTeamCode) {
//                String rirekiId = "";
                String groupCode = s014Bean.getGroupCode();
                String[] TeamCodeWk = teamCode.split(":");

                if (s014Bean.getSalesClass().equals(ConstantString.salesClassI) && s014Bean.getHonsyaShisyaKbn().equals("S")){
                    groupCode = TeamCodeWk[1];
                    condition.put("groupCode", TeamCodeWk[1]); //DISPFLG=0のグループコードに変更
                }

                condition.put("teamCode", TeamCodeWk[0]);
                logger.info("[ippanWorkFlowExecute] update teamCode=[{}]", TeamCodeWk[0]);

                SyuWfControlTbl entity
                    = syuWfControlTblFacade.findPk(s014Bean.getDivisionCode(), groupCode, s014Bean.getSalesClass(), s014Bean.getKanjyoYm(), s014Bean.getHonsyaShisyaKbn(), TeamCodeWk[0]);

                List<Map<String, String>> syoriFlgList = getSyoriFlgList(entity);

                for (Map<String, String> syoriFlgInfo: syoriFlgList) {
                    String syoriFlg = syoriFlgInfo.get("SYORI_FLG");
                    String statsu = syoriFlgInfo.get("STATUS");

                    logger.info("[ippanWorkFlowExecute] update GROUP_CODE=[{}] TEAM_CODE=[{}] STATUS=[{}] syoriFlg=[{}]", groupCode, teamCode, statsu, syoriFlg);
                    
                    Map<String, Object> worFlowExecuteCondition = new HashMap<>(condition);
                    worFlowExecuteCondition.put("status", statsu);
                    //ippanTeamWorkFlowExecute(worFlowExecuteCondition, entity, TeamCodeWk[0], groupCode, syoriFlg);
                    ippanTeamWorkFlowExecute(worFlowExecuteCondition, TeamCodeWk[0], groupCode, syoriFlg);
                }

//                // ワークフローTBLから履歴IDを取得
//                // (否認(解除)時のみ。否認(解除)ではテーブル更新で履歴IDをクリアしてしまうため、予め取得しておく)
//                if ("H".equals(s014Bean.getStatusKbn())) {
//                    rirekiId = this.getWfRirekiId2(TeamCodeWk[0], groupCode);
//                    logger.info("[ippanWorkFlowExecute] hinin rirekiId==[{}]", rirekiId);
//                }
//
//                // ワークフローTBLの更新
//                syuWfControlTblFacade.updateWorkFlow(condition);
//
//                // ワークフローTBLから履歴IDを取得
//                // (確定時のみ。更新時に履歴IDを発行しているため、発行したIDはこのタイミングで取得)
//                if (StringUtils.isEmpty(rirekiId)) {
//                    rirekiId = this.getWfRirekiId2(TeamCodeWk[0], groupCode);
//                    logger.info("[ippanWorkFlowExecute] kakutei rirekiId==[{}]", rirekiId);
//                }
//
//                // 確定/確定解除(一般用)パッケージをCall
//                this.callPoRireki_I_Make(TeamCodeWk[0], rirekiId, syoriFlg, groupCode);
            }
        }

        // 一般データの最小ステータス、各期集計値を取得
        SyuWfControlTbl minStatusInfo = syuWfControlTblFacade.findIppanStatusInfo(condition);
        // 更新に必要なパラメータの作成
        Map<String, Object> insertParam = PropertyUtils.describe(minStatusInfo);
        insertParam.put("divisionCode", s014Bean.getDivisionCode());
        insertParam.put("groupCode", s014Bean.getGroupCode());
        insertParam.put("salesClass", s014Bean.getSalesClass());
        insertParam.put("kanjyoYm", s014Bean.getKanjyoYm());
        insertParam.put("honsyaShisyaKbn", s014Bean.getHonsyaShisyaKbn());
        insertParam.put("teamCode", s014Bean.getTeamCode());
        insertParam.put("userId", condition.get("userId"));
        insertParam.put("userName", condition.get("userName"));
        insertParam.put("comment", condition.get("comment"));
        insertParam.put("hininCommentFlg", getHininCommentFlg());
        insertParam.put("teishutsuStatus", STATUS_TEISHUTSU);

        // 一般データの場合はここでDISP_FLG='1'のデータを更新する
        syuWfControlTblFacade.updateIppanWorkFlow(insertParam);
    }

    private void ippanTeamWorkFlowExecute(Map<String, Object> condition, String targetTeamCode, String targetGroupCode, String syoriFlg)
    //private void ippanTeamWorkFlowExecute(Map<String, Object> condition, String targetTeamCode, String targetGroupCode, String syoriFlg)
    throws Exception {
        String rirekiId = "";
        String updateRirekiId = "";
        String statsu = (String)(condition.get("status"));

        // ワークフローTBLから履歴IDを取得
        // (否認(解除)時のみ。否認(解除)ではテーブル更新で履歴IDをクリアしてしまうため、予め取得しておく)
        if ("H".equals(s014Bean.getStatusKbn())) {
            //rirekiId = this.getWfRirekiId2(TeamCodeWk[0], groupCode);
            rirekiId = this.getWfRirekiId2(targetTeamCode, targetGroupCode);
            logger.info("[ippanWorkFlowExecute] hinin rirekiId=[{}]", rirekiId);
            
            // "提出用"ステータスの場合はRIREKI_ID=1をWF_CONTROL_TBLに登録
            if (statsu.equals(STATUS_TEISHUTSU)) {
                updateRirekiId = ConstantString.teishutsuRirekiId;
            }
            
        } else {
            // 提出/確定時は新規の履歴IDを取得
            rirekiId = createNewRirekiId(statsu);
            updateRirekiId = rirekiId;
            logger.info("[ippanWorkFlowExecute] kakutei rirekiId=[{}]", rirekiId);
        }

        if (StringUtils.isNotEmpty(updateRirekiId)) {
            condition.put("rirekiId", Integer.parseInt(updateRirekiId));
        }
        
        // ワークフローTBLの更新
        syuWfControlTblFacade.updateWorkFlow(condition);

//        // ワークフローTBLから履歴IDを取得
//        // (確定時のみ。更新時に履歴IDを発行しているため、発行したIDはこのタイミングで取得)
//        if (StringUtils.isEmpty(rirekiId)) {
//            rirekiId = this.getWfRirekiId2(targetTeamCode, targetGroupCode);
//            logger.info("[ippanWorkFlowExecute] kakutei rirekiId==[{}]", rirekiId);
//        }

        // 確定/確定解除(一般用)パッケージをCall
        this.callPoRireki_I_Make(targetTeamCode, rirekiId, syoriFlg, targetGroupCode);
    }

    /**
     * ワークフロー実行
     * @throws java.lang.Exception
     */
    public void workFlowExecute() throws Exception {
        if (s014Bean.isIppan()) {
            this.ippanWorkFlowExecute();
        } else {
            this.shinkoWorkFlowExecute();
        }
    }

    /**
     * (進行基準用)確定処理の履歴作成パッケージをCallする。
     * @param rirekiId 履歴ID
     * @param syoriFlg:確定=0 確定解除=9
     */
    private void callRirekiMake(String rirekiId, String syoriFlg) throws Exception {
        PoRirekiMakeDto dto = new PoRirekiMakeDto();
        dto.setDivisionCode(s014Bean.getDivisionCode());
        dto.setGroupCode(s014Bean.getGroupCode());
        dto.setSalesClass(s014Bean.getSalesClass());
        dto.setKanjyoYm(s014Bean.getKanjyoYm());
        dto.setRirekiId(rirekiId);
        dto.setSyoriFlg(syoriFlg);
        
        storedProceduresService.callPoRirekiMake(dto);
        
        if (!"0".equals(dto.getErrFlg())) {
            String errorInfo = "divisionCode=" + s014Bean.getDivisionCode()
                    + " groupCode=" + s014Bean.getGroupCode()
                    + " salesClass=" + s014Bean.getSalesClass()
                    + " kanjyoYm=" + s014Bean.getKanjyoYm()
                    + " rirekiId=" + rirekiId
                    + " syoriFlg=" + syoriFlg
                    + " errorFlg=" + dto.getErrFlg();
                    
            throw new Exception("(進行)履歴作成処理[SYU_P0_RIREKI_MAKE]でエラーが発生しました。" + errorInfo);
        }
    }
    
    /**
     * (一般用)確定処理の履歴作成パッケージをCallする。
     * @param rirekiId 履歴ID
     * @param syoriFlg:確定=0 確定解除=9
     */
    private void callPoRireki_I_Make(String teamCode, String rirekiId, String syoriFlg,  String groupCode  ) throws Exception {
        PoRirekiMakeIDto dto = new PoRirekiMakeIDto();
        dto.setDivisionCode(s014Bean.getDivisionCode());
        //dto.setGroupCode(s014Bean.getGroupCode());
        dto.setGroupCode(groupCode);
        dto.setcBukaCd(s014Bean.getcBukaCode());
        dto.setTeamCode(teamCode);
        dto.setHonsyaShisyaKbn(s014Bean.getHonsyaShisyaKbn());
        dto.setKanjyoYm(s014Bean.getKanjyoYm());
        dto.setRirekiId(rirekiId);
        dto.setSyoriFlg(syoriFlg);
        
        storedProceduresService.callPoRireki_I_Make(dto);
        
        if (!"0".equals(dto.getErrFlg())) {
            String errorInfo = "divisionCode=" + s014Bean.getDivisionCode()
                    + " groupCode=" + s014Bean.getGroupCode()
                    + " cBukaCode=" + s014Bean.getcBukaCode()
                    + " teamCode=" + teamCode
                    + " honsyaShisyaKbn=" + s014Bean.getHonsyaShisyaKbn()
                    + " kanjyoYm=" + s014Bean.getKanjyoYm()
                    + " rirekiId=" + rirekiId
                    + " syoriFlg=" + syoriFlg
                    + " errorFlg=" + dto.getErrFlg();
                    
            throw new Exception("(一般)履歴作成処理[SYU_P0_RIREKI_I_MAKE]でエラーが発生しました。" + errorInfo);
        }
    }

    /**
     * 確定ボタン表示判定
     */
    private boolean isKakuteiBtnFlg(String status) {
        return !STATUS_KAKUTEI.equals(status);
    }

    /**
     * 確定解除ボタン表示判定
     */
    private boolean isKakuteiKaijoBtnFlg(String status) {
        return STATUS_KAKUTEI.equals(status);
    }

    /**
     * 提出用作成ボタン表示判定
     */
    private boolean isTeishutsuBtnFlg(String status) {
        return STATUS_CREATING.equals(status);
    }

    /**
     * 提出用解除ボタン表示判定
     */
    private boolean isTeishutsuKaijoBtnFlg(String status) {
        return STATUS_TEISHUTSU.equals(status);
    }

    /**
     * 否認コメントをSYU_WF_CONTROL_TBLに登録するかを決定
     * (確定解除の場合のみ登録する。提出解除の場合はコメント入力欄をつぶすためコメント入力しない)
     */
   private String getHininCommentFlg() {
        String hininCommentFlg = "0";
        if ("H".equals(s014Bean.getStatusKbn())) {
            // 確定解除の場合は否認コメントを登録
            if (!"1".equals(s014Bean.getTeishutsuFlg())) {
                hininCommentFlg = "1";
            }
        }

        return hininCommentFlg;
    }
    
    /**
     * 新規履歴IDを発行
     */
    private String createNewRirekiId(String status) {
        String newRirekiId = "";
        
        if (status.equals(STATUS_TEISHUTSU)) {
            // 提出用作成時の履歴ID
            newRirekiId = ConstantString.teishutsuRirekiId;

        } else {
            List<StringEntity> list 
                    = sqlExecutor.getResultList(em, StringEntity.class, "/sql/sequence/selectRirekiSeq.sql", null);
            StringEntity entity = list.get(0);
        
            newRirekiId = entity.getString();
        }
        
        return newRirekiId;
    }
}
