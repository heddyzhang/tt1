package jp.co.toshiba.hby.pspromis.syuueki.entity;

import java.io.Serializable;
import java.util.Date;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

/**
 *
 * @author kitajima
 */
@Entity
@Table(name = "SYU_KI_NET_CATE_TITLE_TBL")
@NamedQueries({
    @NamedQuery(name = "KiNetCateTitleTbl.PKCount", query = "Select count(t) from SyuKiNetCateTitleTbl t "
            + "where t.ankenId = :ankenId "
            + "and t.rirekiId = :rirekiId "
            + "and t.categoryCode = :categoryCode "
            + "and t.categoryKbn1 = :categoryKbn1 "
            + "and t.categoryKbn2 = :categoryKbn2"),
    @NamedQuery(name = "KiNetCateTitleTbl.findPk", query = "Select t from SyuKiNetCateTitleTbl t "
            + "where t.ankenId = :ankenId "
            + "and t.rirekiId = :rirekiId "
            + "and t.categoryCode = :categoryCode "
            + "and t.categoryKbn1 = :categoryKbn1 "
            + "and t.categoryKbn2 = :categoryKbn2")
})
public class SyuKiNetCateTitleTbl implements Serializable {
    private static final long serialVersionUID = 1L;
    @NotNull
    @Size(max = 32)
    @Column(name = "ANKEN_ID")
    @Id
    private String ankenId;
    @NotNull
    @Column(name = "RIREKI_ID")
    @Id
    private int rirekiId;
    @NotNull
    @Size(max = 10)
    @Column(name = "CATEGORY_CODE")
    @Id
    private String categoryCode;
    @NotNull
    @Size(max = 10)
    @Column(name = "CATEGORY_KBN1")
    @Id
    private String categoryKbn1;
    @NotNull
    @Size(max = 10)
    @Column(name = "CATEGORY_KBN2")
    @Id
    private String categoryKbn2;
    @Size(max = 256)
    @Column(name = "CATEGORY_NAME1")
    private String categoryName1;
    @Size(max = 256)
    @Column(name = "CATEGORY_NAME2")
    private String categoryName2;
    @Size(max = 7)
    @Column(name = "CATEGORY_SEQ")
    private String categorySeq;
    @Column(name = "CREATED_AT")
    @Temporal(TemporalType.TIMESTAMP)
    private Date createdAt;
    @Size(max = 32)
    @Column(name = "CREATED_BY")
    private String createdBy;
    @Column(name = "UPDATED_AT")
    @Temporal(TemporalType.TIMESTAMP)
    private Date updatedAt;
    @Size(max = 32)
    @Column(name = "UPDATED_BY")
    private String updatedBy;
    @Column(name = "UPDATED_BATCH_AT")
    @Temporal(TemporalType.TIMESTAMP)
    private Date updatedBatchAt;
    @Size(max = 32)
    @Column(name = "UPDATED_BATCH_BY")
    private String updatedBatchBy;
    @Size(max = 1)
    @Column(name = "INPUT_FLG")
    private String inputFlg;

    public SyuKiNetCateTitleTbl() {
    }

    public String getAnkenId() {
        return ankenId;
    }

    public void setAnkenId(String ankenId) {
        this.ankenId = ankenId;
    }
    
    public int getRirekiId() {
        return rirekiId;
    }

    public void setRirekiId(int rirekiId) {
        this.rirekiId = rirekiId;
    }
    
    public String getCategoryCode() {
        return categoryCode;
    }

    public void setCategoryCode(String categoryCode) {
        this.categoryCode = categoryCode;
    }
    
    public String getCategoryKbn1() {
        return categoryKbn1;
    }

    public void setCategoryKbn1(String categoryKbn1) {
        this.categoryKbn1 = categoryKbn1;
    }
    
    public String getCategoryKbn2() {
        return categoryKbn2;
    }

    public void setCategoryKbn2(String categoryKbn2) {
        this.categoryKbn2 = categoryKbn2;
    }
    
    public String getCategoryName1() {
        return categoryName1;
    }

    public void setCategoryName1(String categoryName1) {
        this.categoryName1 = categoryName1;
    }

    public String getCategoryName2() {
        return categoryName2;
    }

    public void setCategoryName2(String categoryName2) {
        this.categoryName2 = categoryName2;
    }

    public String getCategorySeq() {
        return categorySeq;
    }

    public void setCategorySeq(String categorySeq) {
        this.categorySeq = categorySeq;
    }

    public Date getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(Date createdAt) {
        this.createdAt = createdAt;
    }

    public String getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    public Date getUpdatedAt() {
        return updatedAt;
    }

    public void setUpdatedAt(Date updatedAt) {
        this.updatedAt = updatedAt;
    }

    public String getUpdatedBy() {
        return updatedBy;
    }

    public void setUpdatedBy(String updatedBy) {
        this.updatedBy = updatedBy;
    }

    public Date getUpdatedBatchAt() {
        return updatedBatchAt;
    }

    public void setUpdatedBatchAt(Date updatedBatchAt) {
        this.updatedBatchAt = updatedBatchAt;
    }

    public String getUpdatedBatchBy() {
        return updatedBatchBy;
    }

    public void setUpdatedBatchBy(String updatedBatchBy) {
        this.updatedBatchBy = updatedBatchBy;
    }

    public String getInputFlg() {
        return inputFlg;
    }

    public void setInputFlg(String inputFlg) {
        this.inputFlg = inputFlg;
    }

}