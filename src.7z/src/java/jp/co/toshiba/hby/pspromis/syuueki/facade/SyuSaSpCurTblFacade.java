package jp.co.toshiba.hby.pspromis.syuueki.facade;

import java.util.List;
import java.util.Map;
import javax.ejb.Stateless;
import javax.interceptor.Interceptors;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import jp.co.toshiba.hby.pspromis.common.util.BeanUtil;
import jp.co.toshiba.hby.pspromis.syuueki.entity.SyuSaSpCurTbl;
import jp.co.toshiba.hby.pspromis.syuueki.interceptor.TranceInterceptor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * 最終見込損益TBL
 *
 * @author ganryu
 */
@Stateless
@Interceptors({TranceInterceptor.class})
public class SyuSaSpCurTblFacade extends AbstractFacade<SyuSaSpCurTbl> {
    private static final Logger logger = LoggerFactory.getLogger(SyuSaSpCurTblFacade.class);

    @PersistenceContext(unitName = jp.co.toshiba.hby.pspromis.syuueki.util.ConstantString.syuuekiDataSourceName)
    private EntityManager em;

    @Override
    protected EntityManager getEntityManager() {
        return em;
    }

    public SyuSaSpCurTblFacade() {
        super(SyuSaSpCurTbl.class);
    }

    public void merge(SyuSaSpCurTbl facade) {
        this.em.merge(BeanUtil.createAndCopy(SyuSaSpCurTbl.class, facade));
    }

    /**
     * 契約金額更新
     *
     * @param entity
     */
    public void setKeiyakuAmount(SyuSaSpCurTbl entity) {
        logger.info("SyuSaSpCurTblFacade#setKeiyakuAmount");
        sqlExecutor.executeUpdateSql(em, "/sql/syuSaSpCurTbl/updateKeiyakuAmount.sql", entity);
    }
    
    /**
     * 新規通貨を登録(登録済の場合は何もしない)
     * @param _param
     * @return 
     */
    public Integer insertNotExistsSyuSaSpCurTbl(Map<String, Object> _param) {
        return sqlExecutor.executeUpdateSql(em, "/sql/syuSaSpCurTbl/insertNotExistsSyuSaSpCurTbl.sql", _param);
    }

    /**
     * 通貨情報を削除
     * @param _params
     * @return 
     */
    public Integer deleteSyuSaSpCurTbl(Map<String, Object> _params) {
        Integer count = sqlExecutor.executeUpdateSql(em, "/sql/syuSaSpCurTbl/deleteSyuSaSpCurTbl.sql", _params);
        return count;
    }
    
    /**
     * コピー(複写)対象の通貨/レート/契約金額一覧を取得
     * @param _params
     * @return 
     */
    public List<SyuSaSpCurTbl> findCopyList(Map<String, Object> _params) {
        List<SyuSaSpCurTbl> list = sqlExecutor.getResultList(em, SyuSaSpCurTbl.class, "/sql/syuSaSpCurTbl/copyListSyuSaSpCurTbl.sql", _params);
        return list;
    }
    
}
