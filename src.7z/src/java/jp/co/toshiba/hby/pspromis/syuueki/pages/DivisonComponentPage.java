package jp.co.toshiba.hby.pspromis.syuueki.pages;

import java.util.List;
import javax.inject.Named;
import javax.enterprise.context.SessionScoped;
import java.io.Serializable;
import java.util.ArrayList;
import javax.inject.Inject;
import lombok.Getter;
import lombok.Setter;
import jp.co.toshiba.hby.pspromis.syuueki.dto.DivisionDto;
import jp.co.toshiba.hby.pspromis.syuueki.entity.DivisionMst;
//import jp.co.toshiba.hby.pspromis.syuueki.facade.DivisionMstFacade;
import jp.co.toshiba.hby.pspromis.syuueki.util.LoginUserInfo;
import jp.co.toshiba.hby.pspromis.syuueki.util.Utils;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;

/**
 * ES-Promis収益管理システム
 * 事業部情報定義
 * 初期アクセス時、フィルターでマスタから取得しておく
 * @author ibayashi
 */
@Named(value = "divisonComponentPage")
@SessionScoped
public class DivisonComponentPage implements Serializable {

    // 処理タイプ:原子力
    private static final String SYORI_TYPE_NUCLEAR = "2";
    
    // 処理タイプ:火水ジ
    private static final String SYORI_TYPE_THERMAL = "1";
    
    @Inject
    private LoginUserInfo loginUserInfo;
    
    @Inject
    private Utils utils;
    
    @Getter @Setter
    private List<DivisionDto> divisionList;
    
    @Getter @Setter
    private List<DivisionDto> loginUserDivisionList;

    /**
     * 事業部情報を取得
     * @param divisionEntityList
     */
    public void setDivisionMst(List<DivisionMst> divisionEntityList) {
        this.divisionList = new ArrayList<>();
        this.loginUserDivisionList = new ArrayList<>();
        if (CollectionUtils.isNotEmpty(divisionEntityList)) {
            String[] loginDivisionCode = loginUserInfo.getJobGrSyokusyuArrayInfo("division");
            for (DivisionMst entity: divisionEntityList) {
                DivisionDto dto = new DivisionDto();
                dto.setDivisionCode(entity.getDivisionCode());
                dto.setDivisionSubCode(entity.getDivisionSubCode());
                dto.setDivisionName(entity.getDivisionName());
                dto.setDivisionNameEng(entity.getDivisionNameEng());
                dto.setCAnkenHead(entity.getcAnkenHead());
                dto.setSyoriType(entity.getSyoriType());
                dto.setAnkenEditAuthKbn(entity.getAnkenEditAuthKbn());
                dto.setPrioritySeq(entity.getPrioritySeq());
                dto.setDashBoardUrl(entity.getDashBoardUrl());
                dto.setQlikViewgGraphUrl(entity.getQlikViewgGraphUrl());
                dto.setAllAnkenViewSyokusyuCd(entity.getAllAnkenViewSyokusyuCd());

                if (utils.isArrayValue(entity.getDivisionCode(), loginDivisionCode)) {
                    dto.setEnableDivision(true);
                } else {
                    dto.setEnableDivision(false);
                }
                
                this.divisionList.add(dto);
                if (dto.isEnableDivision()) {
                    this.loginUserDivisionList.add(dto);
                }
            }
        }
    }

    /**
     * 引数で指定した事業部情報を取得
     * @param divisionCode 事業部コード
     * @return 引数の事業部コードに該当する事業部情報
     */
    public DivisionDto getTargetDivision(String divisionCode) {
        DivisionDto dto = null;
        if (CollectionUtils.isNotEmpty(this.divisionList)) {
            for (DivisionDto listDto: this.divisionList) {
                if (listDto.getDivisionCode().equals(divisionCode)) {
                    dto = listDto;
                    break;
                }
            }
        }
        return dto;
    }

    /**
     * ログイン者が所属している事業部内で、一番優先順位の高い事業部情報を取得
     * @return 
     */
    public DivisionDto getPriorityDivision() {
        DivisionDto dto = null;
        if (CollectionUtils.isNotEmpty(this.loginUserDivisionList)) {
            for (DivisionDto listDto: this.loginUserDivisionList) {
                if (dto == null) {
                    dto = listDto;
                } else {
                    if (listDto.getPrioritySeq() < dto.getPrioritySeq()) {
                        dto = listDto;
                    }
                }
            }
        }
        return dto;
    }

    /**
     * 指定事業部のダッシュボードURLを取得
     * @param divisionCode
     * @return 
     */
    public String getDashBoardUrl(String divisionCode) {
        String dashBoardUrl = "";
        DivisionDto dto = getTargetDivision(divisionCode);
        if (dto != null) {
            dashBoardUrl = dto.getDashBoardUrl();
        }
        return dashBoardUrl;
    }

    /**
     * 指定事業部のグラフ表示用URLを取得
     * @param divisionCode
     * @return 
     */
    public String getQlikViewGraphUrl(String divisionCode) {
        String url = "";
        DivisionDto dto = getTargetDivision(divisionCode);
        if (dto != null) {
            url = dto.getQlikViewgGraphUrl();
        }
        return url;
    }
    
    /**
     * 引数の事業部が(原子力)タイプであるかをチェック
     * @param divisionCode
     * @return 
     */
    public boolean isNuclearDivision(String divisionCode) {
        boolean isNuclear = false;
        DivisionDto dto = getTargetDivision(divisionCode);
        if (dto != null) {
            if (SYORI_TYPE_NUCLEAR.equals(dto.getSyoriType())) {
                isNuclear = true;
            }
        }
        return isNuclear;
    }

    /**
     * (原子力)タイプの事業部コードを配列で取得
     * @return 
     */
    public String[] getNuclearDivisions() {
        return getChangeDivisionCodeAry(this.divisionList, SYORI_TYPE_NUCLEAR);
    }
    /**
     * ログイン者が所属する(原子力)タイプの事業部コードを配列で取得
     * @return 
     */
    public String[] getLoginUserNuclearDivisions() {
        return getChangeDivisionCodeAry(this.loginUserDivisionList, SYORI_TYPE_NUCLEAR);
    }

    /**
     * (火水ジ)タイプの事業部コードを配列で取得
     * @return 
     */
    public String[] getThermalDivisions() {
        return getChangeDivisionCodeAry(this.divisionList, SYORI_TYPE_THERMAL);
    }
    /**
     * ログイン者が所属する(火水ジ)タイプの事業部コードを配列で取得
     * @return 
     */
    public String[] getLoginUserThermalDivisions() {
        return getChangeDivisionCodeAry(this.loginUserDivisionList, SYORI_TYPE_THERMAL);
    }

    private String[] getChangeDivisionCodeAry(List<DivisionDto> list, String syoriType) {
        List<String> nuclearDivisionList = new ArrayList<>();
        if (CollectionUtils.isNotEmpty(list)) {
            for (DivisionDto dto: list) {
                if (syoriType.equals(dto.getSyoriType())) {
                    nuclearDivisionList.add(dto.getDivisionCode());
                }
            }
        }
        return nuclearDivisionList.toArray(new String[nuclearDivisionList.size()]);
    }
    
    
    /**
     * (原子力)タイプの事業部コードを指定文字で分解した文字列で取得
     * (例)原子力事業部コードがN7とN1の場合で、カンマ区切りにする場合→N7,N1
     * @param splitString
     * @return 
     */
    public String getNuclearDivisionCodes(String splitString) {
        String[] nuclearDivisionCodeAry = getNuclearDivisions();
        String ret  = "";
        for (String divisionCode: nuclearDivisionCodeAry) {
            if (StringUtils.isEmpty(ret)) {
                ret = divisionCode;
            } else {
                ret = ret + splitString + divisionCode;
            }
        }
        return ret;
    }
    
    /**
     * (火水ジ)タイプの事業部コードを指定文字で分解した文字列で取得
     * (例)火水ジ事業部コードがN8とNAとN9の場合で、カンマ区切りにする場合→N8,NA,N9
     * @param splitString
     * @return 
     */
    public String getThermalDivisionCodes(String splitString) {
        String[] thermalDivisionCodeAry = getThermalDivisions();
        String ret  = "";
        for (String divisionCode: thermalDivisionCodeAry) {
            if (StringUtils.isEmpty(ret)) {
                ret = divisionCode;
            } else {
                ret = ret + splitString + divisionCode;
            }
        }
        return ret;
    }
    
}
