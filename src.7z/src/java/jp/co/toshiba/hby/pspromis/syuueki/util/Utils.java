package jp.co.toshiba.hby.pspromis.syuueki.util;

import java.util.List;
import java.util.ArrayList;
import java.util.Map;
import java.io.Serializable;
import java.io.UnsupportedEncodingException;
import java.math.BigDecimal;
import java.text.ParseException;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.Random;
import javax.enterprise.context.ApplicationScoped;
import javax.inject.Named;
import jp.co.toshiba.hby.pspromis.common.util.StringUtil;
import jp.co.toshiba.hby.pspromis.syuueki.enums.Env;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.time.DateUtils;

/**
 * 収益管理 共通ユーティリティ<br>
 * ELからも使用可能なようにCDI管理する(ApplicationScoped)
 * @author (NPC)S.Ibayashi
 */
@Named(value = "utl")
@ApplicationScoped
public class Utils implements Serializable {

    private static final int DIFF = 'Ａ' - 'A';

    /**
     * 変更対象全角記号配列
     */
    private static char[] SIGNS2 =
            {
                    '！',
                    '＃',
                    '＄',
                    '％',
                    '＆',
                    '（',
                    '）',
                    '＊',
                    '＋',
                    '，',
                    '?',
                    '．',
                    '／',
                    '：',
                    '；',
                    '＜',
                    '＝',
                    '＞',
                    '？',
                    '＠',
                    '［',
                    '］',
                    '＾',
                    '＿',
                    '｛',
                    '｜',
                    '｝'
                    };

    /**
     * 一覧データ表示用<br>
     * 1ページに表示するデータ件数を取得
     */
    public int getPageDataCount() {
        String page = Env.getValue(Env.PageCount);
        return Integer.parseInt(page);
    }

    /**
     * 一覧データ表示用<br>
     * 1ページに表示するデータ件数を取得
     *
     * ※2015A SQLExecutorをPSPromisCommonLib.jarのものに変更したため、それに合わせたロジックに変更
     */
    public int getPageLimit() {
        String page = Env.getValue(Env.PageCount);
        int limit = Integer.parseInt(page) - 1;
        return limit;
    }

    /**
     * 一覧データ表示用<br>
     * 該当ページの表示開始データindexを取得
     *
     * ※2015A SQLExecutorをPSPromisCommonLib.jarのものに変更したため、それに合わせたロジックに変更
     */
    public int getPageOffset(int page) {
        int limit = getPageDataCount();

        int offset = (limit * (page - 1)) + 1;

        return offset;
    }

    /**
     * 日付文字列→日付(java.sql.date)に変換<br>
     * パラメータがnull or 空白の場合はnullにする。
     * @param str 日付文字列
     * @param format フォーマット
     * @throws java.text.ParseException
     */
    public static Date parseDate(String str, String... format) throws ParseException {
        String[] parseFormat = null;
        String target = str;

        if (StringUtil.isEmpty(target)) {
            return null;
        }

        if (format != null && format.length > 0) {
            parseFormat = format;
        } else {
            target= StringUtils.replace(target, "/", "");
            target = StringUtils.replace(target, "-", "");
            if (target.length() == 6) {
                String y = StringUtils.substring(target, 0, 4);
                String m = StringUtils.substring(target, 4, 6);
                String d = "01";
                target = y + "/" + m + "/" + d;
            }

            parseFormat = new String[9];
            parseFormat[0] = "dd-MM-yyyy HH:mm:ss";
            parseFormat[1] = "dd-MM-yyyy HH:mm";
            parseFormat[2] = "dd-MM-yyyy";
            parseFormat[3] = "yyyy-MM-dd HH:mm:ss";
            parseFormat[4] = "yyyy-MM-dd HH:mm";
            parseFormat[5] = "yyyy-MM-dd";
            parseFormat[6] = "yyyy/MM/dd HH:mm:ss";
            parseFormat[7] = "yyyy/MM/dd HH:mm";
            parseFormat[8] = "yyyy/MM/dd";
        }

        Date date = DateUtils.parseDateStrictly(target, parseFormat);
        return date;
    }

    /**
     * 2017/11/14 ADD #5 #12 #22 納期を年月日に変更
     * 日付文字列→日付(java.sql.date)に変換<br>
     * パラメータがnull or 空白の場合はnullにする。
     * @param str 日付文字列
     * @param format フォーマット
     * @throws java.text.ParseException
     */
    public static Date parseDateWithDate(String str, String... format) throws ParseException {
        String[] parseFormat = null;
        String target = str;

        if (StringUtil.isEmpty(target)) {
            return null;
        }

        if (format != null && format.length > 0) {
            parseFormat = format;
        } else {
            target= StringUtils.replace(target, "/", "");
            target = StringUtils.replace(target, "-", "");
            if (target.length() == 8) {
                String y = StringUtils.substring(target, 0, 4);
                String m = StringUtils.substring(target, 4, 6);
                String d = StringUtils.substring(target, 6, 8);
                target = y + "/" + m + "/" + d;
            }

            parseFormat = new String[9];
            parseFormat[0] = "dd-MM-yyyy HH:mm:ss";
            parseFormat[1] = "dd-MM-yyyy HH:mm";
            parseFormat[2] = "dd-MM-yyyy";
            parseFormat[3] = "yyyy-MM-dd HH:mm:ss";
            parseFormat[4] = "yyyy-MM-dd HH:mm";
            parseFormat[5] = "yyyy-MM-dd";
            parseFormat[6] = "yyyy/MM/dd HH:mm:ss";
            parseFormat[7] = "yyyy/MM/dd HH:mm";
            parseFormat[8] = "yyyy/MM/dd";
        }

        Date date = DateUtils.parseDateStrictly(target, parseFormat);
        return date;
    }

    public Date elParseDate(String str) throws ParseException {
        String[] parseFormat = null;
        return parseDate(str, parseFormat);
    }

    /**
     * 半角数値であるかをチェック(commons langのチェックでは全角数値も数値とみなしてしまうため作成)<br>
     * パラメータがnull or 空白の場合はチェックしない
     * @param str チェック文字列
     * @return true：半角数値 false:半角数値でない
     */
/*
    public static boolean isNumeric(String str) {
        boolean isValid = true;
        if (StringUtil.isNotEmpty(str)) {
            Pattern p = Pattern.compile("^[0-9]+$");
            Matcher match = p.matcher(str);
            if (!match.find()) {
                isValid = false;
            }
        }
        return isValid;
    }
*/
    /**
     * 乱数を取得
     * @return 乱数
     */
    public int random() {
        Random wheel = new Random() ;
        int unique = ( wheel.nextInt() & Integer. MAX_VALUE ) % 90000000 + 10000000;
        return unique;
    }

    /**
     * 指定値が配列内に存在するかをチェック
     * @param target 対象オブジェクト
     * @param ary 比較する配列
     * @return 対象オブジェクトが比較配列内に存在すればtrue,そうでなければfalse
     */
    public boolean isArrayValue(Object target, Object ary[]) {
    //public boolean isArrayValue(Object target, Object... ary) {
        if (target == null || ary == null) {
            return false;
        }

        String strTarget;
        String strValue;
        if (target instanceof String) {
            strTarget = (String)target;
        } else {
            strTarget = target.toString();
        }

        for(Object value : ary) {
            if (value instanceof String) {
                strValue = (String)value;
            } else {
                strValue = value.toString();
            }

            if (strTarget.equals(strValue)) {
                return true;
            }
        }
        return false;
    }

    /**
     * 指定値(第1引数)が指定値(第2引数)と等しいかをチェック
     * @param target 対象オブジェクト
     * @param compareTarget 比較するオブジェクト(通常のオブジェクトか配列であるかは不明)
     * @return 対象オブジェクトが比較オブジェクトと等しければ(配列であれば配列内に存在すれば)true,そうでなければfalse
     */
    public boolean isSameValue(Object target, Object compareTarget) {
        if (target == null || compareTarget == null) {
            return false;
        }

        Class<?> compareClass = compareTarget.getClass();
        Object[] aryObj;
        if (compareClass.isArray()) {
           aryObj = (Object[])compareTarget;
        } else {
            aryObj = new Object[1];
            aryObj[0] = compareTarget;
        }

        return isArrayValue(target, aryObj);
    }

    /**
     * CSV出力文字を加工(間にダブルクォートで囲む)
     */
    public String stringCsv(Object value) {
        return stringCsv(value, 0);
    }

    /**
     * CSV出力文字を加工(間にダブルクォートで囲む)
     * @param value：値
     * @param quartKbn:囲み文字区分(0:ダブルクォート(両脇に付加) 1:頭にイコール(=)を付ける(数値のみの場合、頭0がかけないようにするための対応))
     */
    public String stringCsv(Object value, int quartKbn) {
        if (value == null) {
            return "";
        }
        if (value instanceof String) {
            if (value.equals("")) {
                return "";
            }
        }

        String returnValue;
//        if (quartKbn == 1) {
//            returnValue = "'" + value;
//        } else {
//            returnValue = "\"" + value + "\"";
//        }

        returnValue = "\"" + value + "\"";
        if (quartKbn == 1) {
            returnValue = "=" + returnValue;
        }

        return returnValue;
    }


    /**
     * nvl関数
     */
    public String nvl(String value, String replaceValue) {
        String ret = value;
        if (StringUtils.isEmpty(value)) {
            ret = replaceValue;
        }
        return ret;
    }

    /**
     * 指定文字列を数値変換(String→BigDecimal)<br>
     * null及び空文字はnullを戻す。<br>
     * 文字列等が入っていた場合はエラー<br>
     * @param num:変換対象文字列
     * @return 変換後オブジェクト
     */
    public static BigDecimal changeBigDecimal(String num) {
        if (StringUtil.isEmpty(num)) {
            return null;
        }

        String changeStr = StringUtils.replace(StringUtils.defaultString(num), ",", "");
        BigDecimal big = new BigDecimal(changeStr);
        return big;
    }
    public static BigDecimal changeBigDecimal(Object num) {
        if (num == null) {
            return null;
        }
        if (num instanceof BigDecimal) {
            return (BigDecimal)num;
        }
        if (num instanceof String) {
            return changeBigDecimal((String)num);
        }
        return null;
    }

    /**
     * 指定文字列の数値チェック(カンマ編集やnull,空文字列でもok)
     * @param num:チェック対象文字列
     * @return true:数値 false:数値でない
     */
    public static boolean isNumeric(String num) {
        return isNumeric(num, false);
    }

    /**
     * 指定文字列の数値チェック(カンマ編集されていてもok)
     * @param num:チェック対象文字列
     * @param blankFlg:null,空文字をチェック対象とするか？ true:チェックする(nullや空文字の場合は数値としない) false:nullや空文字も数値と見なす
     * @return true:数値 false:数値でない
     */
    public static boolean isNumeric(String num, boolean blankFlg) {
        boolean bool = true;
        String checkString;

        if (blankFlg && StringUtil.isEmpty(num)) {
            return false;
        }
        if (!blankFlg && StringUtil.isEmpty(num)) {
            return true;
        }

        checkString = StringUtils.replace(StringUtils.defaultString(num), ",", "");
        try {
            Double.parseDouble(checkString);
        } catch(NumberFormatException e){
            bool = false;
        }

        return bool;
    }

    /**
     * Objectをjava.lang.String型に変換
     * @param obj
     * @return
     */
    public static String getObjToStrValue(Object obj) {
        String value = "";
        boolean isString = false;

        if (obj == null) {
            return "";
        }

        if (obj instanceof String) {
            value = (String) obj;
            isString = true;
        } else {
            boolean isBig = true;
            BigDecimal big = null;

            try {
                big = new BigDecimal(String.valueOf(obj));
            } catch(NumberFormatException e) {
                isBig = false;
            }

            if (isBig) {
                value = big.toString();
                isString = true;
            }
        }

        if (!isString) {
            value = String.valueOf(obj);
        }

        return value;
    }

    /**
     * 変換対象全角記号かを判定する。
     * @param pc
     * @return
     */
    private static boolean is2Sign(char pc) {
        for(int i=0; i < SIGNS2.length; i++) {
            if(SIGNS2[i] == pc) {
                return true;
            }
        }
        return false;
    }

    /**
     * 文字列のアルファベット・数値を半角文字に変換する。
     * @param str
     * @return
     */
    public static String convertToHankaku(String str) {
        if (StringUtils.isEmpty(str)) {
            return "";
        }

        char[] cc = str.toCharArray();
        StringBuilder sb = new StringBuilder();

        for (int i=0; i < cc.length; i++){
            char newChar = cc[i];
            if ((('Ａ' <= cc[i]) && (cc[i] <= 'Ｚ')) || (('ａ' <= cc[i]) && (cc[i] <= 'ｚ'))
                    || (('１' <= cc[i]) && (cc[i] <= '９')) || is2Sign(cc[i])) {
                newChar = (char) (cc[i]- DIFF);
            }

            sb.append(newChar);
        }
        return sb.toString();
    }

    /**
     * 値の足し算(可変長引数で指定し、そのすべてを足した結果を返す)
     * @param valAry
     * @return
     */
    public static BigDecimal add(BigDecimal... valAry) {
        BigDecimal result = null;
        if (valAry == null) {
            return null;
        }

        for (BigDecimal val : valAry) {
            if (val == null) {
                continue;
            }
            if (result == null) {
                result = val;
            } else {
                result = result.add(val);
            }
        }

        return result;
    }

    /**
     * java.util.Dateをjava.sql.Timestampに変換
     * @param date
     * @return
     */
    public static java.sql.Timestamp changeSqlDate(java.util.Date date) {
        if (date == null) {
            return null;
        }

        Calendar cal = Calendar.getInstance();
        cal.setTime(date);
        /*
        cal.set(Calendar.YEAR, 1970);
        cal.set(Calendar.MONTH, Calendar.JANUARY);
        cal.set(Calendar.DATE, 1);
        */
        /*
        cal.set(Calendar.HOUR_OF_DAY, 0);
        cal.set(Calendar.MINUTE, 0);
        cal.set(Calendar.SECOND, 0);
        cal.set(Calendar.MILLISECOND, 0);
        */
        java.sql.Timestamp d2 = new java.sql.Timestamp(cal.getTimeInMillis());

        return d2;
    }

    /**
     * バイト配列を取得
     */
    public static byte[] getBytes(String str) throws UnsupportedEncodingException {
        if (StringUtils.isEmpty(str)) {
            return new byte[0];
        }

        byte[] buff = str.getBytes("utf-8");
        return buff;
    }


    public static void setNameMapCount(Map<String, Integer> nameMapCount, String target) {
        Integer count = 0;
        if (nameMapCount.containsKey(target)) {
            count = nameMapCount.get(target);
            count = count + 1;
        }
        nameMapCount.put(target, count);
    }

    /**
     * 文字列を指定区切り文字で連結
     * @param baseStr 基準文字列
     * @param addStr 追加文字列
     * @param spritStr 区切り文字列
     */
    public static String addStringBuff(String baseStr, String addStr, String spritStr) {
        String result;

        if (addStr == null || addStr.equals("")) {
            return baseStr;
        }

        if (baseStr != null && !baseStr.equals("")) {
            result = baseStr + spritStr + addStr;
        } else {
            result = addStr;
        }

        return result;
    }
}
