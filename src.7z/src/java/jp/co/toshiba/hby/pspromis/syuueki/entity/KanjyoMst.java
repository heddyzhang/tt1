/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package jp.co.toshiba.hby.pspromis.syuueki.entity;

import java.io.Serializable;
import java.util.Date;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

/**
 *
 * @author ibayashi
 */
@Entity
@Table(name = "KANJYO_MST")
public class KanjyoMst implements Serializable {
    private static final long serialVersionUID = 1L;
    @Id
    @Basic(optional = false)
    @NotNull
    @Column(name = "KANJYO_DT")
    @Temporal(TemporalType.TIMESTAMP)
    private Date kanjyoDt;
    @Size(max = 2)
    @Column(name = "JITSUDO_DT")
    private String jitsudoDt;
    @Size(max = 4)
    @Column(name = "KANJYO_YR")
    private String kanjyoYr;
    @Size(max = 6)
    @Column(name = "KANJYO_MH")
    private String kanjyoMh;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 2)
    @Column(name = "SCHEDULE_TYPE")
    private String scheduleType;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 8)
    @Column(name = "UPDATE_ID")
    private String updateId;
    @Basic(optional = false)
    @NotNull
    @Column(name = "UPDATE_DT")
    @Temporal(TemporalType.TIMESTAMP)
    private Date updateDt;

    public KanjyoMst() {
    }

    public KanjyoMst(Date kanjyoDt) {
        this.kanjyoDt = kanjyoDt;
    }

    public Date getKanjyoDt() {
        return kanjyoDt;
    }

    public void setKanjyoDt(Date kanjyoDt) {
        this.kanjyoDt = kanjyoDt;
    }

    public String getJitsudoDt() {
        return jitsudoDt;
    }

    public void setJitsudoDt(String jitsudoDt) {
        this.jitsudoDt = jitsudoDt;
    }

    public String getKanjyoYr() {
        return kanjyoYr;
    }

    public void setKanjyoYr(String kanjyoYr) {
        this.kanjyoYr = kanjyoYr;
    }

    public String getKanjyoMh() {
        return kanjyoMh;
    }

    public void setKanjyoMh(String kanjyoMh) {
        this.kanjyoMh = kanjyoMh;
    }

    public String getScheduleType() {
        return scheduleType;
    }

    public void setScheduleType(String scheduleType) {
        this.scheduleType = scheduleType;
    }

    public String getUpdateId() {
        return updateId;
    }

    public void setUpdateId(String updateId) {
        this.updateId = updateId;
    }

    public Date getUpdateDt() {
        return updateDt;
    }

    public void setUpdateDt(Date updateDt) {
        this.updateDt = updateDt;
    }

}
