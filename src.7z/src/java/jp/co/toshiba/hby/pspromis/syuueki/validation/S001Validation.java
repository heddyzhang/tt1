package jp.co.toshiba.hby.pspromis.syuueki.validation;

import java.util.Map;
import jp.co.toshiba.hby.pspromis.syuueki.bean.S001Bean;
import jp.co.toshiba.hby.pspromis.syuueki.bean.ValidationInfoBean;
import jp.co.toshiba.hby.pspromis.syuueki.enums.Label;
import jp.co.toshiba.hby.pspromis.syuueki.util.Utils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 *
 * @author ibayashi
 */
public class S001Validation extends AbstractValidation<S001Bean> {
    public static final Logger logger = LoggerFactory.getLogger(S001Validation.class);
    
    /**
     * コンストラクタ
     */
    public S001Validation(S001Bean bean) {
        super(bean);
    }

    /**
     * 検索処理時のバリデーション
     */
    public void execListValidation(ValidationInfoBean vBean) {
        annotationValidate();
        
        Map<String, String> messages = getValidateMessagess();
        S001Bean bean = getBean();
        String message;

        boolean is = true;
        boolean isJuchuYmFrom = true;
        boolean isJuchuYmTo = true;
        boolean isUriageStartYmFrom = true;
        boolean isUriageStartYmTo = true;
        boolean isUriagYmFrom = true;
        boolean isUriagYmTo = true;
        boolean isKaisyuYmFrom = true;
        boolean isKaisyuYmTo = true;
        boolean isForwardTermYmFrom = true;
        boolean isForwardTermYmTo = true;
        boolean isRecoveryYoteiYmFrom = true;
        boolean isRecoveryYoteiYmTo = true;

        //// 独自チェック
        // データ種別(対象月)
        if ("M".equals(bean.getDataKbn())) {
            // 対象月(月次確定)
            if (StringUtils.isEmpty(bean.getTaishoYm())) {
                message = StringUtils.replace(getValidationMessage("required"), "{0}", Label.getValue(Label.fixedYm));
                messages.put("taishoYm", message);
            } else if (!isValidYm(bean.getTaishoYm())) {
                message = StringUtils.replace(getValidationMessage("ymError"), "{0}", Label.getValue(Label.fixedYm));
                messages.put("taishoYm", message);
            }
        } else if ("Y".equals(bean.getDataKbn())) {
            // 対象月(予算ベース)
            if (StringUtils.isEmpty(bean.getTaishoYm())) {
                message = StringUtils.replace(getValidationMessage("required"), "{0}", Label.getValue(Label.taisho));
                messages.put("taishoYm", message);
            }
            // リストボックス化に伴い不要
            /*
            else if (!isValidYki(bean.getTaishoYm())) {
                message = getValidationMessage("yosanTaishoError");
                messages.put("taishoYm", message);
            }
            */
        }

        // 受注年月from
        isJuchuYmFrom = isValidYm(bean.getJuchuYmFrom());
        // 受注年月to
        isJuchuYmTo = isValidYm(bean.getJuchuYmTo());
        if (!isJuchuYmFrom || !isJuchuYmTo) {
            message = StringUtils.replace(getValidationMessage("ymError"), "{0}", Label.getValue(Label.juchuYm));
            messages.put("juchuYm", message);
        }

        // 売上開始年月from
        isUriageStartYmFrom = isValidYm(bean.getUriageStartYmFrom());
        // 売上開始年月to
        isUriageStartYmTo = isValidYm(bean.getUriageStartYmTo());
        if (!isUriageStartYmFrom || !isUriageStartYmTo) {
            message = StringUtils.replace(getValidationMessage("ymError"), "{0}", Label.getValue(Label.uriageStartYm));
            messages.put("uriageStartYm", message);
        }

        // 売上年月from
        isUriagYmFrom = isValidYm(bean.getUriageYoteiYmFrom());
        // 売上年月to
        isUriagYmTo = isValidYm(bean.getUriageYoteiYmTo());
        if (!isUriagYmFrom || !isUriagYmTo) {
            message = StringUtils.replace(getValidationMessage("ymError"), "{0}", Label.getValue(Label.uriageYoteiYm));
            messages.put("uriageYoteiYm", message);
        }

        // 回収年月from
        isKaisyuYmFrom = isValidYm(bean.getKaisyuYmFrom());
        // 回収年月to
        isKaisyuYmTo = isValidYm(bean.getKaisyuYmTo());
        if (!isKaisyuYmFrom || !isKaisyuYmTo) {
            message = StringUtils.replace(getValidationMessage("ymError"), "{0}", Label.recoveryYm2.getLabel());
            messages.put("recoveryYm2", message);
        }

        // 定件回数
        if (!Utils.isNumeric(bean.getTeiken())) {
            message = StringUtils.replace(getValidationMessage("integerError"), "{0}", Label.getValue(Label.teiken));
            messages.put("teiken", message);
        }

        // 出荷日限from
        isForwardTermYmFrom = isValidYm(bean.getForwardTermYmFrom());
        // 出荷日限to
        isForwardTermYmTo = isValidYm(bean.getForwardTermYmTo());
        if (!isForwardTermYmFrom || !isForwardTermYmTo) {
            message = StringUtils.replace(getValidationMessage("ymError"), "{0}", Label.getValue(Label.forwardTermYm));
            messages.put("forwardTermYm", message);
        }

        // 回収予定from
        isRecoveryYoteiYmFrom = isValidYm(bean.getRecoveryYoteiYmFrom());
        // 回収予定to
        isRecoveryYoteiYmTo = isValidYm(bean.getRecoveryYoteiYmTo());
        if (!isRecoveryYoteiYmFrom || !isRecoveryYoteiYmTo) {
            message = StringUtils.replace(getValidationMessage("ymError"), "{0}", Label.getValue(Label.recoveryYoteiYm));
            messages.put("recoveryYoteiYm", message);
        }

        vBean.setMessages(messages);
    }
}
