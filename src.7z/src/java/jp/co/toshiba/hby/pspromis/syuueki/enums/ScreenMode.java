package jp.co.toshiba.hby.pspromis.syuueki.enums;

/**
 *
 * @author ibayashi
 */
public enum ScreenMode {
    NEW("new"),
    READ("read"),
    EDIT("edit");
    
    private final String value;
    
    private ScreenMode(final String value) {
        this.value = value;
    }
    
    public String getValue() {
        return value;
    }
}
