/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package jp.co.toshiba.hby.pspromis.syuueki.entity;

import java.io.Serializable;
import java.math.BigDecimal;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;

/**
 *
 * @author sano
 */
@Entity
public class SalesAmount implements Serializable {
    private static final long serialVersionUID = 1L;
    
    @Id
    @Column(name = "SEQ")
    private Integer seq;
    
    @Id
    @Column(name = "CURRENCY_CODE")
    private String currencyCode;
    
    @Column(name = "URIAGE_RATE")
    private String uriageRate;
    
    @Column(name = "URIAGE_AMOUNT_1")
    private BigDecimal uriageAmount1;
    @Column(name = "URIAGE_AMOUNT_2")
    private BigDecimal uriageAmount2;
    @Column(name = "URIAGE_AMOUNT_3")
    private BigDecimal uriageAmount3;
    @Column(name = "URIAGE_AMOUNT_4")
    private BigDecimal uriageAmount4;
    @Column(name = "URIAGE_AMOUNT_5")
    private BigDecimal uriageAmount5;
    @Column(name = "URIAGE_AMOUNT_6")
    private BigDecimal uriageAmount6;
    @Column(name = "URIAGE_AMOUNT_7")
    private BigDecimal uriageAmount7;
    @Column(name = "URIAGE_AMOUNT_8")
    private BigDecimal uriageAmount8;
    @Column(name = "URIAGE_AMOUNT_9")
    private BigDecimal uriageAmount9;
    @Column(name = "URIAGE_AMOUNT_10")
    private BigDecimal uriageAmount10;
    @Column(name = "URIAGE_AMOUNT_11")
    private BigDecimal uriageAmount11;
    @Column(name = "URIAGE_AMOUNT_12")
    private BigDecimal uriageAmount12;;
    @Column(name = "URIAGE_AMOUNT_TM")
    private BigDecimal uriageAmountTm;
    @Column(name = "URIAGE_AMOUNT_K1")
    private BigDecimal uriageAmountK1;
    @Column(name = "URIAGE_AMOUNT_K2")
    private BigDecimal uriageAmountK2;
    @Column(name = "URIAGE_AMOUNT_G")
    private BigDecimal uriageAmountG;
    @Column(name = "URIAGE_AMOUNT_F")
    private BigDecimal uriageAmountF;
    @Column(name = "URIAGE_AMOUNT_K1_DIFF")
    private BigDecimal uriageAmountK1Diff;
    @Column(name = "URIAGE_AMOUNT_K2_DIFF")
    private BigDecimal uriageAmountK2Diff;
    @Column(name = "URIAGE_AMOUNT_G_DIFF")
    private BigDecimal uriageAmountGDiff;
    @Column(name = "URIAGE_AMOUNT_DIFF")
    private BigDecimal uriageAmountDiff;
    
    @Column(name = "URIAGE_AMOUNT_1Q")
    private BigDecimal uriageAmount1Q;
    @Column(name = "URIAGE_AMOUNT_2Q")
    private BigDecimal uriageAmount2Q;
    @Column(name = "URIAGE_AMOUNT_3Q")
    private BigDecimal uriageAmount3Q;
    @Column(name = "URIAGE_AMOUNT_4Q")
    private BigDecimal uriageAmount4Q;
    @Column(name = "URIAGE_AMOUNT_1Q_DIFF")
    private BigDecimal uriageAmount1QDiff;
    @Column(name = "URIAGE_AMOUNT_2Q_DIFF")
    private BigDecimal uriageAmount2QDiff;
    @Column(name = "URIAGE_AMOUNT_3Q_DIFF")
    private BigDecimal uriageAmount3QDiff;
    @Column(name = "URIAGE_AMOUNT_4Q_DIFF")
    private BigDecimal uriageAmount4QDiff;
    
    @Column(name = "URIAGE_AMOUNT_TOTAL")
    private BigDecimal uriageAmountTotal;
    @Column(name = "URIAGE_KAWASESA_TOTAL")
    private BigDecimal uriageKawaseTotal;
    @Column(name = "URI_RATE_TOTAL")
    private BigDecimal uriRateTotal;
    
    @Column(name = "URIAGE_RUIKEI_AMOUNT")
    private BigDecimal uriageRuikeiAmount;
    
    public SalesAmount() {
    }

    public Integer getSeq() {
        return this.seq;
    }

    public void setSeq(Integer seq) {
        this.seq = seq;
    }
    
    public String getCurrencyCode() {
        return this.currencyCode;
    }

    public void setCurrencyCode(String currencyCode) {
        this.currencyCode = currencyCode;
    }

    public String getUriageRate() {
        return this.uriageRate;
    }

    public void setUriageRate(String uriageRate) {
        this.uriageRate = uriageRate;
    }

    public BigDecimal getUriageAmount1() {
        return this.uriageAmount1;
    }

    public void setUriageAmount1(BigDecimal uriageAmount1) {
        this.uriageAmount1 = uriageAmount1;
    }
    
    public BigDecimal getUriageAmount2() {
        return this.uriageAmount2;
    }

    public void setUriageAmount2(BigDecimal uriageAmount2) {
        this.uriageAmount2 = uriageAmount2;
    }
    
    public BigDecimal getUriageAmount3() {
        return this.uriageAmount3;
    }

    public void setUriageAmount3(BigDecimal uriageAmount3) {
        this.uriageAmount3 = uriageAmount3;
    }
    
    public BigDecimal getUriageAmount4() {
        return this.uriageAmount4;
    }

    public void setUriageAmount4(BigDecimal uriageAmount4) {
        this.uriageAmount4 = uriageAmount4;
    }
    
    public BigDecimal getUriageAmount5() {
        return this.uriageAmount5;
    }

    public void setUriageAmount5(BigDecimal uriageAmount5) {
        this.uriageAmount5 = uriageAmount5;
    }
    
    public BigDecimal getUriageAmount6() {
        return this.uriageAmount6;
    }

    public void setUriageAmount6(BigDecimal uriageAmount6) {
        this.uriageAmount6 = uriageAmount6;
    }
    
    public BigDecimal getUriageAmount7() {
        return this.uriageAmount7;
    }

    public void setUriageAmount7(BigDecimal uriageAmount7) {
        this.uriageAmount7 = uriageAmount7;
    }
    
    public BigDecimal getUriageAmount8() {
        return this.uriageAmount8;
    }

    public void setUriageAmount8(BigDecimal uriageAmount8) {
        this.uriageAmount8 = uriageAmount8;
    }
    
    public BigDecimal getUriageAmount9() {
        return this.uriageAmount9;
    }

    public void setUriageAmount9(BigDecimal uriageAmount9) {
        this.uriageAmount9 = uriageAmount9;
    }
    
    public BigDecimal getUriageAmount10() {
        return this.uriageAmount10;
    }

    public void setUriageAmount10(BigDecimal uriageAmount10) {
        this.uriageAmount10 = uriageAmount10;
    }
    
    public BigDecimal getUriageAmount11() {
        return this.uriageAmount11;
    }

    public void setUriageAmount11(BigDecimal uriageAmount11) {
        this.uriageAmount11 = uriageAmount11;
    }
    
    public BigDecimal getUriageAmount12() {
        return this.uriageAmount12;
    }

    public void setUriageAmount12(BigDecimal uriageAmount12) {
        this.uriageAmount12 = uriageAmount12;
    }
    
    public BigDecimal getUriageAmountTm() {
        return this.uriageAmountTm;
    }

    public void setUriageAmountTm(BigDecimal uriageAmountTm) {
        this.uriageAmountTm = uriageAmountTm;
    }
    
    public BigDecimal getUriageAmountK1() {
        return this.uriageAmountK1;
    }

    public void setUriageAmountK1(BigDecimal uriageAmountK1) {
        this.uriageAmountK1 = uriageAmountK1;
    }
    
    public BigDecimal getUriageAmountK2() {
        return this.uriageAmountK2;
    }

    public void setUriageAmountK2(BigDecimal uriageAmountK2) {
        this.uriageAmountK2 = uriageAmountK2;
    }
    
    public BigDecimal getUriageAmountG() {
        return this.uriageAmountG;
    }

    public void setUriageAmountG(BigDecimal uriageAmountG) {
        this.uriageAmountG = uriageAmountG;
    }

    public BigDecimal getUriageAmountF() {
        return this.uriageAmountF;
    }

    public void setUriageAmountF(BigDecimal uriageAmountF) {
        this.uriageAmountF = uriageAmountF;
    }
    
    public BigDecimal getUriageAmountK1Diff() {
        return this.uriageAmountK1Diff;
    }

    public void setUriageAmountK1Diff(BigDecimal uriageAmountK1Diff) {
        this.uriageAmountK1Diff = uriageAmountK1Diff;
    }
    
    public BigDecimal getUriageAmountK2Diff() {
        return this.uriageAmountK2Diff;
    }

    public void setUriageAmountK2Diff(BigDecimal uriageAmountK2Diff) {
        this.uriageAmountK2Diff = uriageAmountK2Diff;
    }
    
    public BigDecimal getUriageAmountGDiff() {
        return this.uriageAmountGDiff;
    }

    public void setUriageAmountGDiff(BigDecimal uriageAmountGDiff) {
        this.uriageAmountGDiff = uriageAmountGDiff;
    }
    
    public BigDecimal getUriageAmountDiff() {
        return this.uriageAmountDiff;
    }

    public void setUriageAmountDiff(BigDecimal uriageAmountDiff) {
        this.uriageAmountDiff = uriageAmountDiff;
    }

    public BigDecimal getUriageAmount1Q() {
        return uriageAmount1Q;
    }

    public void setUriageAmount1Q(BigDecimal uriageAmount1Q) {
        this.uriageAmount1Q = uriageAmount1Q;
    }

    public BigDecimal getUriageAmount2Q() {
        return uriageAmount2Q;
    }

    public void setUriageAmount2Q(BigDecimal uriageAmount2Q) {
        this.uriageAmount2Q = uriageAmount2Q;
    }

    public BigDecimal getUriageAmount3Q() {
        return uriageAmount3Q;
    }

    public void setUriageAmount3Q(BigDecimal uriageAmount3Q) {
        this.uriageAmount3Q = uriageAmount3Q;
    }

    public BigDecimal getUriageAmount4Q() {
        return uriageAmount4Q;
    }

    public void setUriageAmount4Q(BigDecimal uriageAmount4Q) {
        this.uriageAmount4Q = uriageAmount4Q;
    }

    public BigDecimal getUriageAmount1QDiff() {
        return uriageAmount1QDiff;
    }

    public void setUriageAmount1QDiff(BigDecimal uriageAmount1QDiff) {
        this.uriageAmount1QDiff = uriageAmount1QDiff;
    }

    public BigDecimal getUriageAmount2QDiff() {
        return uriageAmount2QDiff;
    }

    public void setUriageAmount2QDiff(BigDecimal uriageAmount2QDiff) {
        this.uriageAmount2QDiff = uriageAmount2QDiff;
    }

    public BigDecimal getUriageAmount3QDiff() {
        return uriageAmount3QDiff;
    }

    public void setUriageAmount3QDiff(BigDecimal uriageAmount3QDiff) {
        this.uriageAmount3QDiff = uriageAmount3QDiff;
    }

    public BigDecimal getUriageAmount4QDiff() {
        return uriageAmount4QDiff;
    }

    public void setUriageAmount4QDiff(BigDecimal uriageAmount4QDiff) {
        this.uriageAmount4QDiff = uriageAmount4QDiff;
    }

    /**
     * @return the uriageAmountTotal
     */
    public BigDecimal getUriageAmountTotal() {
        return uriageAmountTotal;
    }

    /**
     * @param uriageAmountTotal the uriageAmountTotal to set
     */
    public void setUriageAmountTotal(BigDecimal uriageAmountTotal) {
        this.uriageAmountTotal = uriageAmountTotal;
    }

    /**
     * @return the uriageKawaseTotal
     */
    public BigDecimal getUriageKawaseTotal() {
        return uriageKawaseTotal;
    }

    /**
     * @param uriageKawaseTotal the uriageKawaseTotal to set
     */
    public void setUriageKawaseTotal(BigDecimal uriageKawaseTotal) {
        this.uriageKawaseTotal = uriageKawaseTotal;
    }

    /**
     * @return the uriageRuikeiAmount
     */
    public BigDecimal getUriageRuikeiAmount() {
        return uriageRuikeiAmount;
    }

    /**
     * @param uriageRuikeiAmount the uriageRuikeiAmount to set
     */
    public void setUriageRuikeiAmount(BigDecimal uriageRuikeiAmount) {
        this.uriageRuikeiAmount = uriageRuikeiAmount;
    }

    /**
     * @return the uriRateTotal
     */
    public BigDecimal getUriRateTotal() {
        return uriRateTotal;
    }

    /**
     * @param uriRateTotal the uriRateTotal to set
     */
    public void setUriRateTotal(BigDecimal uriRateTotal) {
        this.uriRateTotal = uriRateTotal;
    }

}
