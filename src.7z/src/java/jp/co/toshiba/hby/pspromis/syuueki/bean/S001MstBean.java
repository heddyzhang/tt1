package jp.co.toshiba.hby.pspromis.syuueki.bean;

import java.io.Serializable;
import java.util.List;
import javax.enterprise.context.SessionScoped;
import javax.inject.Named;
import jp.co.toshiba.hby.pspromis.syuueki.entity.BuMst;
import jp.co.toshiba.hby.pspromis.syuueki.entity.JgrpMemberTbl;
import jp.co.toshiba.hby.pspromis.syuueki.entity.JgrpTbl;
import jp.co.toshiba.hby.pspromis.syuueki.entity.M0130BunruiOrg;
import jp.co.toshiba.hby.pspromis.syuueki.entity.PlantMst;
import jp.co.toshiba.hby.pspromis.syuueki.entity.StageMst;
import jp.co.toshiba.hby.pspromis.syuueki.entity.SyuGyotaiMst;
import jp.co.toshiba.hby.pspromis.syuueki.entity.EstContractTypeMst;
import jp.co.toshiba.hby.pspromis.syuueki.entity.M0130LineEigJobgr;
import jp.co.toshiba.hby.pspromis.syuueki.entity.TeamEntity;
import jp.co.toshiba.hby.pspromis.syuueki.entity.MSectionView;
import lombok.Getter;
import lombok.Setter;

/**
 *
 * @author ibayashi
 */
@Named(value = "s001MstBean")
@SessionScoped
@Getter @Setter
public class S001MstBean extends AbstractBean implements Serializable {

    /**
     * BUマスタ
     */
    private List<BuMst> buMstList;

    /**
     * ステージマスタ
     */
    private List<StageMst> stageList;

    /**
     * 収益分類マスタ
     */
    private List<M0130BunruiOrg> bunruiList;

    /**
     * サイトマスタ
     */
    private List<PlantMst> siteList;

    /**
     * My案件検索・JobGr一覧
     */
    private List<JgrpTbl> myJobGrList;
   
    /**
     * My案件検索・担当者一覧
     */
    private List<JgrpMemberTbl> myJobGrMemberList; 
    
    /**
     * 業態マスタ
     */
    private List<SyuGyotaiMst> gyotaiList;

    /**
     * チームコードマスタ
     */
    private List<TeamEntity> teamMstList;

    /**
     * 営業担当マスタ(Step4)
     */
    private List<M0130LineEigJobgr> lineEigJobGrList;

    /**
     * 契約形態マスタ(Step4)
     */
    private List<EstContractTypeMst> contraceTypeMstList;

    /**
     * 主管化条件マスタ(電力ジ対応)
     */
    //private List<JgrpTbl> syukanJobGrList;
    private List<MSectionView> syukanSectList;
    
    /**
     * Creates a new instance of S001MstBean
     */
    public S001MstBean() {
    }

    public List<BuMst> getBuMstList() {
        return buMstList;
    }

    public void setBuMstList(List<BuMst> buMstList) {
        this.buMstList = buMstList;
    }

    public List<PlantMst> getSiteList() {
        return siteList;
    }

    public void setSiteList(List<PlantMst> siteList) {
        this.siteList = siteList;
    }

    public List<StageMst> getStageList() {
        return stageList;
    }

    public void setStageList(List<StageMst> stageList) {
        this.stageList = stageList;
    }

    public List<M0130BunruiOrg> getBunruiList() {
        return bunruiList;
    }

    public void setBunruiList(List<M0130BunruiOrg> bunruiList) {
        this.bunruiList = bunruiList;
    }

    public List<JgrpTbl> getMyJobGrList() {
        return myJobGrList;
    }

    public void setMyJobGrList(List<JgrpTbl> myJobGrList) {
        this.myJobGrList = myJobGrList;
    }

    public List<JgrpMemberTbl> getMyJobGrMemberList() {
        return myJobGrMemberList;
    }

    public void setMyJobGrMemberList(List<JgrpMemberTbl> myJobGrMemberList) {
        this.myJobGrMemberList = myJobGrMemberList;
    }

    public List<SyuGyotaiMst> getGyotaiList() {
        return gyotaiList;
    }

    public void setGyotaiList(List<SyuGyotaiMst> gyotaiList) {
        this.gyotaiList = gyotaiList;
    }

    public List<TeamEntity> getTeamMstList() {
        return teamMstList;
    }

    public void setTeamMstList(List<TeamEntity> teamMstList) {
        this.teamMstList = teamMstList;
    }

}
