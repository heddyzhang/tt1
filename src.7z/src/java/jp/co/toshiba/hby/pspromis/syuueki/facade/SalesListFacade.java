package jp.co.toshiba.hby.pspromis.syuueki.facade;

import java.util.List;
//import java.util.Map;
import javax.ejb.Stateless;
import javax.interceptor.Interceptors;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import jp.co.toshiba.hby.pspromis.syuueki.entity.SalesAmount;
import jp.co.toshiba.hby.pspromis.syuueki.interceptor.TranceInterceptor;
import org.apache.commons.collections4.CollectionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 *
 * @author sano
 */
@Stateless
@Interceptors({TranceInterceptor.class})
public class SalesListFacade extends AbstractFacade<SalesAmount> {

    /**
     * ロガ－
     */
    private static final Logger logger = LoggerFactory.getLogger(SalesListFacade.class);

    @PersistenceContext(unitName = jp.co.toshiba.hby.pspromis.syuueki.util.ConstantString.syuuekiDataSourceName)
    private EntityManager em;

    public SalesListFacade() {
        super(SalesAmount.class);
    }

    @Override
    protected EntityManager getEntityManager() {
        return em;
    }
    
    /**
     * 売上高の合計を取得
     * @param condition
     * @return 
     */
    public SalesAmount findTotalSales(Object condition) {
        logger.info("CostListFacade#findTotalSales");

        //SalesAmount list = sqlExecutor.getSingleResult(em, SalesAmount.class, "/sql/S004/selectKsTotalSales.sql", condition);
        //return list;
        
        SalesAmount entity;
        List<SalesAmount> list = sqlExecutor.getResultList(em, SalesAmount.class, "/sql/S004/selectKsTotalSales.sql", condition);
        if (CollectionUtils.isNotEmpty(list)) {
            entity = list.get(0);
        } else {
            entity = new SalesAmount();
        }
        
        return entity;
    }
    
    /**
     * 売上高の合計を取得
     * @param condition
     * @return 
     */
    public SalesAmount findPreviousPeriodTotalSales(Object condition) {
        logger.info("CostListFacade#findPreviousPeriodTotalSales");

        //SalesAmount list = sqlExecutor.getSingleResult(em, SalesAmount.class, "/sql/S004/selectPreviousPeriodKsTotalSales.sql", condition);
        //return list;
        
        SalesAmount entity;
        List<SalesAmount> list = sqlExecutor.getResultList(em, SalesAmount.class, "/sql/S004/selectPreviousPeriodKsTotalSales.sql", condition);
        if (CollectionUtils.isNotEmpty(list)) {
            entity = list.get(0);
        } else {
            entity = new SalesAmount();
        }
        
        return entity;
    }
    
    /**
     * 売上高の詳細を取得
     * @param condition
     * @return 
     */
    public List<SalesAmount> findSalesDetail(Object condition) {
        logger.info("CostListFacade#findSalesDetail");

        List<SalesAmount> list = sqlExecutor.getResultList(em, SalesAmount.class, "/sql/S004/selectKsCurrencySalesDetail.sql", condition);
        
        return list;
    }

    /**
     * 売上高の詳細を取得
     * @param condition
     * @return 
     */
    public List<SalesAmount> findPreviousPeriodTotalSalesDetail(Object condition) {
        logger.info("CostListFacade#findPreviousPeriodTotalSalesDetail");

        List<SalesAmount> list = sqlExecutor.getResultList(em, SalesAmount.class, "/sql/S004/selectPreviousPeriodKsCurrencySalesDetail.sql", condition);
        
        return list;
    }
    
    /**
     * 売上高累計の合計を取得
     * @param condition
     * @return 
     */
    public SalesAmount findTotalSalesRuikei(Object condition) {
        logger.info("CostListFacade#findTotalSalesRuikei");

        //SalesAmount list = sqlExecutor.getSingleResult(em, SalesAmount.class, "/sql/S004/selectKsTotalRuikeiSales.sql", condition);
        //return list;
        
        SalesAmount entity;
        List<SalesAmount> list = sqlExecutor.getResultList(em, SalesAmount.class, "/sql/S004/selectKsTotalRuikeiSales.sql", condition);
        if (CollectionUtils.isNotEmpty(list)) {
            entity = list.get(0);
        } else {
            entity = new SalesAmount();
        }
        
        return entity;
    }
    
    /**
     * 売上高累計の合計を取得
     * @param condition
     * @return 
     */
    public SalesAmount findPreviousPeriodTotalSalesRuikei(Object condition) {
        logger.info("CostListFacade#findPreviousPeriodTotalSalesRuikei");

        //SalesAmount list = sqlExecutor.getSingleResult(em, SalesAmount.class, "/sql/S004/selectPreviousPeriodKsTotalRuikeiSales.sql", condition);
        //return list;
        
        SalesAmount entity;
        List<SalesAmount> list = sqlExecutor.getResultList(em, SalesAmount.class, "/sql/S004/selectPreviousPeriodKsTotalRuikeiSales.sql", condition);
        if (CollectionUtils.isNotEmpty(list)) {
            entity = list.get(0);
        } else {
            entity = new SalesAmount();
        }
        
        return entity;
    }

    /**
     * 売上高累計の詳細を取得
     * @param condition
     * @return 
     */
    public List<SalesAmount> findSalesRuikeiDetail(Object condition) {
        logger.info("CostListFacade#findSalesRuikeiDetail");

        List<SalesAmount> list = sqlExecutor.getResultList(em, SalesAmount.class, "/sql/S004/selectKsCurrencySalesRuikei.sql", condition);
        
        return list;
    }

    /**
     * 売上高累計の詳細を取得
     * @param condition
     * @return 
     */
    public List<SalesAmount> findPreviousPeriodSalesRuikeiDetail(Object condition) {
        logger.info("CostListFacade#findPreviousPeriodSalesRuikeiDetail");

        List<SalesAmount> list = sqlExecutor.getResultList(em, SalesAmount.class, "/sql/S004/selectPreviousPeriodKsCurrencySalesRuikei.sql", condition);
        
        return list;
    }
    /**
     * 売上原価の合計を取得
     * @param condition
     * @return 
     */
    public SalesAmount findTotalSalesCost(Object condition) {
        logger.info("CostListFacade#findTotalSalesCost");

        //SalesAmount list = sqlExecutor.getSingleResult(em, SalesAmount.class, "/sql/S004/selectKsTotalSalesCost.sql", condition);
        //return list;
        
        SalesAmount entity;
        List<SalesAmount> list = sqlExecutor.getResultList(em, SalesAmount.class, "/sql/S004/selectKsTotalSalesCost.sql", condition);
        if (CollectionUtils.isNotEmpty(list)) {
            entity = list.get(0);
        } else {
            entity = new SalesAmount();
        }
        
        return entity;
    }
    
    /**
     * 売上原価の合計を取得
     * @param condition
     * @return 
     */
    public SalesAmount findPreviousPeriodTotalSalesCost(Object condition) {
        logger.info("CostListFacade#findPreviousPeriodTotalSalesCost");

        //SalesAmount list = sqlExecutor.getSingleResult(em, SalesAmount.class, "/sql/S004/selectPreviousPeriodKsTotalSalesCost.sql", condition);
        //return list;

        SalesAmount entity;
        List<SalesAmount> list = sqlExecutor.getResultList(em, SalesAmount.class, "/sql/S004/selectPreviousPeriodKsTotalSalesCost.sql", condition);
        if (CollectionUtils.isNotEmpty(list)) {
            entity = list.get(0);
        } else {
            entity = new SalesAmount();
        }
        
        return entity;
    }

    /**
     * 売上原価累計の合計を取得
     * @param condition
     * @return 
     */
    public SalesAmount findTotalSalesCostRuikei(Object condition) {
        logger.info("CostListFacade#findTotalSalesCostRuikei");

        //SalesAmount list = sqlExecutor.getSingleResult(em, SalesAmount.class, "/sql/S004/selectKsTotalRuikeiSalesCost.sql", condition);
        //return list;
        
        SalesAmount entity;
        List<SalesAmount> list = sqlExecutor.getResultList(em, SalesAmount.class, "/sql/S004/selectKsTotalRuikeiSalesCost.sql", condition);
        if (CollectionUtils.isNotEmpty(list)) {
            entity = list.get(0);
        } else {
            entity = new SalesAmount();
        }
        
        return entity;
    }
    
    /**
     * 売上原価累計の合計を取得
     * @param condition
     * @return 
     */
    public SalesAmount findPreviousPeriodTotalSalesCostRuikei(Object condition) {
        logger.info("CostListFacade#findPreviousPeriodTotalSalesCostRuikei");

        //SalesAmount list = sqlExecutor.getSingleResult(em, SalesAmount.class, "/sql/S004/selectPreviousPeriodKsTotalRuikeiSalesCost.sql", condition);
        //return list;
        
        SalesAmount entity;
        List<SalesAmount> list = sqlExecutor.getResultList(em, SalesAmount.class, "/sql/S004/selectPreviousPeriodKsTotalRuikeiSalesCost.sql", condition);
        if (CollectionUtils.isNotEmpty(list)) {
            entity = list.get(0);
        } else {
            entity = new SalesAmount();
        }
        
        return entity;
    }

}
