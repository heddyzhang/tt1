package jp.co.toshiba.hby.pspromis.syuueki.entity;

import java.io.Serializable;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

@Entity
@Table(name = "String")
public class StringEntity implements Serializable {
    @Id
    @NotNull
    @Column(name = "STRING")
    private String string;
    
    /**
     * 
     */
    public StringEntity(){
        super();
    }

    public String getString() {
        return string;
    }

    public void setString(String string) {
        this.string = string;
    }

}