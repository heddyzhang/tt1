package jp.co.toshiba.hby.pspromis.syuueki.service.download;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import javax.ejb.Stateless;
import javax.inject.Inject;
import javax.interceptor.Interceptors;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import jp.co.toshiba.hby.pspromis.syuueki.bean.S001Bean;
import jp.co.toshiba.hby.pspromis.syuueki.interceptor.TranceInterceptor;
import jp.co.toshiba.hby.pspromis.common.jdbc.SqlExecutor;
import jp.co.toshiba.hby.pspromis.syuueki.bean.S014Bean;
import jp.co.toshiba.hby.pspromis.syuueki.entity.OperationLog;
import jp.co.toshiba.hby.pspromis.syuueki.entity.SyuWfControlTbl;
import jp.co.toshiba.hby.pspromis.syuueki.enums.Label;
import jp.co.toshiba.hby.pspromis.syuueki.facade.KanjyoMstFacade;
import jp.co.toshiba.hby.pspromis.syuueki.facade.SysdateEntityFacade;
import jp.co.toshiba.hby.pspromis.syuueki.facade.SyuWfControlTblFacade;
import jp.co.toshiba.hby.pspromis.syuueki.jdbc.DbUtilsExecutor;
import jp.co.toshiba.hby.pspromis.syuueki.jdbc.SqlFile;
import jp.co.toshiba.hby.pspromis.syuueki.service.OperationLogService;
import jp.co.toshiba.hby.pspromis.syuueki.service.S001Service;
import jp.co.toshiba.hby.pspromis.syuueki.util.PoiUtil;
import jp.co.toshiba.hby.pspromis.syuueki.util.ConstantString;
import jp.co.toshiba.hby.pspromis.syuueki.util.EscapeUtils;
import jp.co.toshiba.hby.pspromis.syuueki.util.LoginUserInfo;
import jp.co.toshiba.hby.pspromis.syuueki.util.SyuuekiUtils;
import jp.co.toshiba.hby.pspromis.syuueki.util.Utils;
import jp.co.toshiba.hby.pspromis.syuueki.pages.DivisonComponentPage;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Row;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
/**
 * PS-Promis収益管理システム
 * 案件検索 Service
 * @author (NPC)S.Ibayashi
 */
@Stateless
@Interceptors({TranceInterceptor.class})
public class SummaryListService implements DownloadIfc {

    public static final Logger logger = LoggerFactory.getLogger(SummaryListService.class);

    @PersistenceContext(unitName = jp.co.toshiba.hby.pspromis.syuueki.util.ConstantString.syuuekiDataSourceName)
    private EntityManager em;

    @Inject
    private S001Service s001Service;
    
    @Inject
    private KanjyoMstFacade kanjyoMstFacade;

    @Inject
    private SyuWfControlTblFacade syuWfControlTblFacade;
    
    @Inject
    private DbUtilsExecutor dbUtilsExecutor;
    
    @Inject
    private OperationLogService operationLogService;

    /**
     * パラメータ格納クラスをinjection(CDI)<br>
     * InjectアノテーションよりAPサーバー(Glassfish)側で自動的にインスタンス作成(new)される。<br>
     */
    @Inject
    private S001Bean s001Bean;

    @Inject
    private S014Bean s014Bean;
    
    /**
     * Injection loginUserInfo
     * (ユーザー情報(ユーザーid,名称,所属部課名)を格納したオブジェクト)
     */
    @Inject
    private LoginUserInfo loginUserInfo;

    /**
     * Injection sqlExecutor
     */
    @Inject
    protected SqlExecutor sqlExecutor;

    @Inject
    private SysdateEntityFacade sysdateFacade;
    
    /**
     * Injection SyuuekiUtils
     */
    @Inject
    private SyuuekiUtils syuuekiUtils;

    @Inject
    private DivisonComponentPage divisionComponentPage;
    
    private static final String SHEETNAME = "list";
    private static final String STYLESHEETNAME = "style";
    private static final int FIRST_ROW_INDEX = 3;
    private static final int GROUP_TOTAL_ROW_COUNT = (5 * 3);
    private static final int HS_ROW_COUNT = 3;
    private static final int TEAM_ROW_COUNT = 3;
    private static final int ANKEN_ROW_COUNT = 3;
    private static final int TITLE_CELL_INDEX = 1;

    /**
     * 指定した受注残一覧Excelテンプレートにデータを書き込む
     * @param workbook
     * @throws java.lang.Exception
     */
    @Override
    public void downloadExecute(Workbook workbook) throws Exception {
        logger.info("[SummaryListService#downloadExecute]");

        // 前処理
        if (this.monthyKakuteiFlg() == 0) {
            ////// 受注売上見込一覧からの出力
            // 対象年月が未指定(検索条件：データ種別=原案)の場合は、現在の勘定年月を使用する。
            if (StringUtils.isEmpty(s001Bean.getTaishoYm())) {
                String taishoYm = kanjyoMstFacade.getNowKanjoDate(ConstantString.salesClassI);
                s001Bean.setTaishoYm(taishoYm);
            }
        }
        
        // ヘッダ部の出力
        this.outputHeader(workbook);
        
        // 一覧部の出力
        this.outputMainList(workbook);
        
        // Excel計算式の実行
        this.exeFormulaSheet(workbook);
        
        // 操作ログを登録
        this.registOperationLog();
    }

    /**
     * ヘッダの出力
     */
    private void outputHeader(Workbook workbook) throws Exception {
        logger.info("[SummaryListService#outputHeader]");
        Sheet dataSheet = workbook.getSheet(SHEETNAME);
        Sheet styleSheet = workbook.getSheet(STYLESHEETNAME);
        Cell cell;
        String value;
        String halfLabel;
        
        String baseYm = this.getBaseYm();
        Date baseYmDate = Utils.parseDate(baseYm);

        // 年度＋帳票タイトル
        value = s001Bean.getTaishoY() + Label.getValue(Label.year);
        if ("S".equals(s001Bean.getTaishoKi())) {
            value = value + Label.getValue(Label.secondHalf);
            halfLabel = Label.getValue(Label.secondHalf) + Label.getValue(Label.total);
        } else {
            value = value + Label.getValue(Label.firstHalf);
            halfLabel = Label.getValue(Label.firstHalf) + Label.getValue(Label.total);
        }
        cell = PoiUtil.getCell(dataSheet, 1, 0);
        PoiUtil.setCellValue(cell, value + "　サマリ表");

        // (受注 or 売上)展開
        if ("J".equals(s001Bean.getTenkaiKbn() )) {
            value = Label.getValue(Label.jyuchu);
        } else {
            value = Label.getValue(Label.uriage);
        }
        value = "(" + value + Label.getValue(Label.tenkai) + ")";
        cell = PoiUtil.getCell(dataSheet, 2, 0);
        PoiUtil.setCellValue(cell, value);

        // 出力者名
        value = loginUserInfo.getUserName();
        cell = PoiUtil.getCell(dataSheet, 0, 4);
        PoiUtil.setCellValue(cell, value);
        
        // 出力日時
        Date outputDate = sysdateFacade.getSysdate();
        cell = PoiUtil.getCell(dataSheet, 0, 6);
        PoiUtil.setCellValue(cell, outputDate);
        
        // 単位
        value = Label.getValue(Label.jpyUnit1);
        String jpyUnitKbn = "1";
        if (this.monthyKakuteiFlg() == 1) {
            jpyUnitKbn = s014Bean.getJpyUnit();
            // 月次確定画面から出力
            if("2".equals(s014Bean.getJpyUnit())){
                value = Label.getValue(Label.jpyUnit2);
            } else if("3".equals(s014Bean.getJpyUnit())){
                value = Label.getValue(Label.jpyUnit3);
            }
            
        } else {
            // 案件一覧(受注売上見込画面)から出力
            if(s001Bean.getJpyUnit() == 1000){
                value = Label.getValue(Label.jpyUnit2);
                jpyUnitKbn = "2";
            } else if(s001Bean.getJpyUnit() == 1000000){
                value = Label.getValue(Label.jpyUnit3);
                jpyUnitKbn = "3";
            }
        }
        s001Bean.setJpyUnitKbn(jpyUnitKbn);
        
        value = Label.getValue(Label.unitLabel) + ":" + value;
        cell = PoiUtil.getCell(dataSheet, 0, 8);
        PoiUtil.setCellValue(cell, value);
        if( jpyUnitKbn.equals("1")){
            cell = PoiUtil.getCell(dataSheet, 0, 9);
            PoiUtil.setCellValue(cell, "");
        }

        // 指定した期の年月を配列取得
        String[] kikanMonthAry = SyuuekiUtils.getKikanMonthAry(s001Bean.getTaishoY() + s001Bean.getTaishoKi());
        
        // 4半期ラベルを取得
        Date baseYmDateQ = Utils.parseDate(kikanMonthAry[0]);
        String[] quarterLabelAry = syuuekiUtils.getQuarterLabel(baseYmDateQ);
        int quarterLabelIndex = 0;
        
        // 各月の表示
        String jyLabel = "";
        int ymIndex = 3;
        for (int i=0; i<kikanMonthAry.length; i++) {
            // 年月(yyyy/MM)を出力
            cell = PoiUtil.getCell(dataSheet, 1, ymIndex);
            PoiUtil.setCellValue(cell, syuuekiUtils.exeFormatYm(Utils.parseDate(kikanMonthAry[i])));

            // 見込/実績 ラベルを出力
            jyLabel = syuuekiUtils.getJYLabel(baseYmDate, kikanMonthAry[i]);
            cell = PoiUtil.getCell(dataSheet, 2, (ymIndex + 1));
            // 実績月であれば、背景色変更([style:テンプレートシートより取得)
            CellStyle jissekiStyleCell = null;
            boolean jissekiFlg = syuuekiUtils.getJissekiFlg(baseYmDate, kikanMonthAry[i]);
            if (jissekiFlg) {
                Cell styleCell = PoiUtil.getCell(styleSheet, 44, 3);
                jissekiStyleCell = styleCell.getCellStyle();
            }
            PoiUtil.setCellValue(cell, jyLabel, jissekiStyleCell);

            // 月をシフト
            if (i == 2 || i == 5) {
                // Quater列分を飛ばしてシフトし、 Quater列ラベルを出力
                ymIndex = ymIndex + 3;
                cell = PoiUtil.getCell(dataSheet, 1, ymIndex);
                PoiUtil.setCellValue(cell, quarterLabelAry[quarterLabelIndex] + "　" + Label.getValue(Label.ruikei2));
                quarterLabelIndex++;
                
                cell = PoiUtil.getCell(dataSheet, 2, (ymIndex + 1));
                PoiUtil.setCellValue(cell, jyLabel);
            }
            ymIndex = ymIndex + 3;
        }

        // 期合計
        cell = PoiUtil.getCell(dataSheet, 1, ymIndex);
        PoiUtil.setCellValue(cell, halfLabel);
        // 期合計の実績/見込ラベルを表示
        cell = PoiUtil.getCell(dataSheet, 2, (ymIndex + 1));
        PoiUtil.setCellValue(cell, jyLabel);
    }
    
    /**
     * 操作ログを登録
     */
    private void registOperationLog() throws Exception{
        // 操作ログを出力
        OperationLog operationLog = operationLogService.getOperationLog();
        operationLog.setOperationCode("DL_JOB");
        operationLog.setObjectType("ANKEN");
        operationLog.setObjectId(10);
        operationLog.setRemarks("サマリ表(月別)");
        operationLogService.insertOperationLogSearch(operationLog);
    }

    /**
     * 月次確定画面からの出力か？
     */
    private int monthyKakuteiFlg() {
        if ("S014".equals(s014Bean.getDispId())) {
            return 1;
        } else {
            return 0;
        }
    }

    /**
     * 一覧の出力
     */
    private void outputMainList(Workbook workbook) throws Exception {
        logger.info("[SummaryListService#outputMainList]");

        Integer startRowIndex = FIRST_ROW_INDEX;
        
        // 抽出した全案件データの各月・各項目の合計
        //  key:引渡し基準案件=IPPAN 引渡し基準案件(ISP)=ISP 進行基準案件=案件番号 白地案件=SHIRAJI
        Map<String, Map<String, Object>> totalDataRowInfo = new LinkedHashMap<>();
        // SYU_WF_CONTROL_TBLから対象のGROUP_CODEを取得する。
        List<SyuWfControlTbl> groupList = this.findGroupCodeList();

        //// グループコード単位の集計値のサマリ対象行
        // key説明:IPPAN
        Map<String, Set<Integer>> formulaTotalRowIndexInfo = new HashMap<>();

        // SYU_WF_CONTROL_TBLから取得したGROUP_CODE毎に処理を行う。
        for (SyuWfControlTbl groupInfo : groupList) {
            // GROUP_CODEに該当するチームコードを取得する。
            List<SyuWfControlTbl> targetTeamList = this.findTeamList(groupInfo, "");

            if (CollectionUtils.isEmpty(targetTeamList)) {
                logger.info("[SummaryListService#outputMainList] GROUP_CODE=[{}] TeamCode is Empty", groupInfo.getGroupCode());
            } else {
                // GROUP_CODE単位の案件を取得して、データ出力
                logger.info("[SummaryListService#outputMainList] GROUP_CODE=[{}] TeamCode is [{}] size", groupInfo.getGroupCode(), targetTeamList.size());

                startRowIndex = this.outputAnkenList(workbook, startRowIndex, groupInfo, targetTeamList, totalDataRowInfo, formulaTotalRowIndexInfo);
            }
        }

        // 全データの総合計を出力
        this.outputTotal(workbook, startRowIndex, totalDataRowInfo, formulaTotalRowIndexInfo);
    }

    /**
     * 基準年月を取得
     */
    private String getBaseYm() {
        String baseYm;
        if (this.monthyKakuteiFlg() == 1) {
            //baseYm = SyuuekiUtils.getChangeBaseYm(s014Bean.getKanjyoYm());
            baseYm = SyuuekiUtils.getChangeBaseYm(s014Bean.getDispBaseKanjyoYm());
        } else {
            baseYm = SyuuekiUtils.getChangeBaseYm(s001Bean.getTaishoYm());
        }
        baseYm = StringUtils.replace(baseYm, "/", "");
        logger.info("[getWfControlCondition] baseYm=[{}]", baseYm);
        return baseYm;
    }

    /**
     * SYU_WF_CONTROL_TBLを参照するための検索条件を取得
     */
    private Map<String, Object> getWfControlCondition() throws Exception {
        Map<String, Object> condition = new HashMap<>();
        
        String[] divitionCode;
        String[] salesClass;
        String kanjyoYm;
        String groupCode = null;
        String dispFlg = null;
 
        // 検索条件の指定
        if (this.monthyKakuteiFlg() == 1) {
            logger.info("[getWfControlCondition] monthyKakutei");
            ////// 月次確定画面から出力する場合 Start //////
            divitionCode = new String[1];
            divitionCode[0] = s014Bean.getDivisionCode();
            
            salesClass = new String[1];
            salesClass[0] = s014Bean.getSalesClass();
            
            kanjyoYm = s014Bean.getKanjyoYm();
            groupCode = s014Bean.getGroupCode();
            //dispFlg = "0";
            ////// 月次確定画面から出力する場合 End //////
 
        } else {
            logger.info("[getWfControlCondition] jyuchuUriage");
            ////// 案件一覧(受注売上見込一覧) Start //////
            // 事業部が選択されていない場合
            divitionCode = new String[1];
            divitionCode[0] = s001Bean.getDivisionCode();
            //if (s001Bean.getDivisionCode() == null) {
            if (StringUtils.isEmpty(s001Bean.getDivisionCode())) {
                // ログイン者の優先事業部を強制セット
                divitionCode = new String[]{loginUserInfo.getPriorityDivCode()};
            }

            salesClass = s001Bean.getSalesClass();
            
            kanjyoYm = s001Bean.getTaishoYm();
//            if (StringUtils.isEmpty(kanjyoYm)) {
//                kanjyoYm = kanjyoMstFacade.getNowKanjoDate(ConstantString.salesClassI);
//            }
            ////// 案件一覧(受注売上見込一覧) End //////
        }

        condition.put("divisionCode", divitionCode);
        condition.put("salesClass", salesClass);
        condition.put("kanjyoYm", StringUtils.replace(kanjyoYm, "/", ""));
        condition.put("groupCode", groupCode);
        condition.put("dispFlg", dispFlg);
        
        logger.info("[getWfControlCondition] divisionCode=[{}] salesClass=[{}] kanjyoYm=[{}] groupCode=[{}] dispFlg=[{}]", divitionCode, salesClass, kanjyoYm, groupCode, dispFlg);

        return condition;
    }
    
    /**
     * 対象の(GROUP_CODE)一覧を取得
     */
    private List<SyuWfControlTbl> findGroupCodeList() throws Exception {
        Map<String, Object> condition = this.getWfControlCondition();

        // 案件一覧からの出力時は、進行基準FLGは指定すると取得するGROUP_CODEが限定されてしまい、正しく検索できないかもしれないので指定から除外
        //変更(２０１６０４２８）　進行基準フラグは一般のみに変更
        if (this.monthyKakuteiFlg() != 1) {
            //condition.remove("salesClass");
            condition.put("salesClass","0"); 
            condition.put("shisyaHonsyaKbn","H" ); //一覧画面から来た場合は固定で本社
        }else{
             condition.put("shisyaHonsyaKbn",s014Bean.getHonsyaShisyaKbn()); //            
        }
        
        List<SyuWfControlTbl> list = syuWfControlTblFacade.findSummaryGroupList(condition);
        return list;
    }
    
    /**
     * 対象の(GROUP_CODE)に該当するチームコード一覧データを取得
     * @return チームコードの配列を格納したMap key=H 本社チームコード key=S:支社チームコード
     */
    private List<SyuWfControlTbl> findTeamList(SyuWfControlTbl groupInfo, String syubetsu) throws Exception {
        Map<String, Object> condition = this.getWfControlCondition();
        // 案件一覧からの出力時は、進行基準FLGは指定すると取得するチームコードが限定されてしまい、正しく検索できないかもしれないので指定から除外
        if (this.monthyKakuteiFlg() != 1) {
            //condition.remove("salesClass");
            condition.put("salesClass","0"); 
        }
        condition.put("dispFlg", "0");    // 一般案件の対象チームコードを取得するので、DISP_FLG=0のデータのみを対象とする。
                
//        String[] divitionCode = (String[])condition.get("divitionCode");
//        String[] salesClass = (String[])condition.get("salesClass");
//        String kanjyoYm = (String)condition.get("kanjyoYm");

        String ki = s001Bean.getTaishoY() + s001Bean.getTaishoKi();
        // 本社 or 支社グループコード(cBukaCode)の指定
        String cBukaCode;
        if (this.monthyKakuteiFlg() == 1) {
            // 月次確定画面から出力する場合
            cBukaCode = s014Bean.getcBukaCode();
            
        } else {
            // 案件一覧(受注売上見込一覧) から出力する場合
            cBukaCode = groupInfo.getGroupCode();
        }

        condition.put("cBukaCode", cBukaCode);
        // syubetsuが'Y'の場合は予算ベースデータ取得用の履歴IDを取得するためにSYU_WF_CONTROL_TBLを検索
        condition.put("syubetsu", syubetsu);
        condition.put("ki", ki);

        List<SyuWfControlTbl> list = syuWfControlTblFacade.findBukaCode(condition);

        logger.info("[findTeamMap] cBukaCode=[{}] syubetsu=[{}] ki=[{}]", cBukaCode, syubetsu, ki);

        return list;
    }

    /**
     * 一覧の出力(GROUP_CODE単位)
     */
    private Integer outputAnkenList(
            Workbook workbook, Integer startRowIndex, 
            SyuWfControlTbl groupInfo, List<SyuWfControlTbl> targetTeamList, 
            Map<String, Map<String, Object>> totalDataRowInfo,
            Map<String, Set<Integer>> formulaTotalRowIndexInfo
    ) throws Exception {
        logger.info("[SummaryListService#outputAnkenList]");
        
        // 案件一覧を検索
        List<Map<String, Object>> list = null;
        if (this.monthyKakuteiFlg() == 1) {
            // 月次確定一覧から出力
            list = this.findAnkenListKakutei(groupInfo, targetTeamList);
        } else {
            // 受注売上見込一覧から出力
            list = this.findAnkenList(groupInfo, targetTeamList);
        }

        if (CollectionUtils.isEmpty(list)) {
            return startRowIndex;
        }
        
        Sheet dataSheet = workbook.getSheet(SHEETNAME);
        Sheet styleSheet = workbook.getSheet(STYLESHEETNAME);

        // 案件データの各月・各項目の合計
        Map<String, Object> ankenRowInfo = new HashMap<>();
        // チームコード単位データの各月・各項目の合計値レコード
        Map<String, Object> teamRowInfo = new HashMap<>();
        // 本社/支社データの各月・各項目の合計値レコード
        Map<String, Object> hsRowInfo = new HashMap<>();

        // 対象GROUP_CODE案件データの各月・各項目の合計
        //  key:引渡し基準案件=IPPAN 引渡し基準案件(ISP)=ISP 進行基準案件=案件番号 白地案件=SHIRAJI
        Map<String, Map<String, Object>> gTotalAnkenRowInfoMap = new LinkedHashMap<>();
        
        boolean isFirst = true;
        int hsRowIndex = startRowIndex + GROUP_TOTAL_ROW_COUNT;   // 本社/支社情報を出力する行index
        int teamRowIndex = hsRowIndex + HS_ROW_COUNT;             // チームコード情報を出力する行index
        int ankenRowIndex = teamRowIndex + TEAM_ROW_COUNT;        // 案件情報を出力する行index
        
        Map<String, Object> baseData = null;
        String baseAnkenKey = "";
        String baseHSKbn = "";
        String baseTeamCode = "";
        
        /////////// スタイル定義(S) //////////////
        // GROUP_CODE単位の合計行データ・出力スタイル
        //   (GROUP_CODE合計、引渡し基準案件、引渡し基準案件(ISP)、進行基準案件、白地案件の5カテゴリ)
        //   (カテゴリ毎に、SP,粗利,M率の3行分)
        //   以上、合計5×3=15行分
        List<List<Cell>> gTotalCellStyleList = new ArrayList<>();
        for (int i=0; i<(0 + GROUP_TOTAL_ROW_COUNT); i++) {
            List<Cell> gTotalCellStyleListRow = PoiUtil.getCellList(PoiUtil.getRow(styleSheet, i));
            gTotalCellStyleList.add(gTotalCellStyleListRow);
        }
        
        // 本社/支社単位の合計行データ・出力スタイル(SP,粗利,M率の3行分)
        List<List<Cell>> hsCellStyleList = new ArrayList<>();
        for (int i=16; i<(16 + HS_ROW_COUNT); i++) {
            List<Cell> hsCellStyleListRow = PoiUtil.getCellList(PoiUtil.getRow(styleSheet, i));
            hsCellStyleList.add(hsCellStyleListRow);
        }
        
        // チームコード合計行データ・出力スタイル(SP,粗利,M率の3行分)
        List<List<Cell>> teamCellStyleList = new ArrayList<>();
        for (int i=20; i<(20 + TEAM_ROW_COUNT); i++) {
            List<Cell> teamCellStyleListRow = PoiUtil.getCellList(PoiUtil.getRow(styleSheet, i));
            teamCellStyleList.add(teamCellStyleListRow);
        }
        
        // 案件データ・出力スタイル(SP,粗利,M率の3行分)
        List<List<Cell>> ankenCellStyleList = new ArrayList<>();
        for (int i=24; i<(24 + ANKEN_ROW_COUNT); i++) {
            List<Cell> ankenCellStyleListRow = PoiUtil.getCellList(PoiUtil.getRow(styleSheet, i));
            ankenCellStyleList.add(ankenCellStyleListRow);
        }
        /////////// スタイル定義(E) //////////////

        // チームコードに対する部門名をMapに紐付
        Map<String, String> teamNameInfo = new HashMap<>();
        for (SyuWfControlTbl wfTeamInfo : targetTeamList) {
            teamNameInfo.put(wfTeamInfo.getTeamCode(), wfTeamInfo.getTantoNm());
        }

        ////// (計算式出力の場合) サマリする行を確保するCollection(S)
        // チームコード単位の集計値のサマリ対象行
        Set<Integer> teamRowIndexList = new LinkedHashSet<>();
        teamRowIndexList.add(ankenRowIndex);
        
        // 本社/支社単位の集計値のサマリ対象行
        Set<Integer> honsyaShisyaRowIndexList = new LinkedHashSet<>();
        honsyaShisyaRowIndexList.add(teamRowIndex);
        
        //// グループコード単位の集計値のサマリ対象行
        Map<String, Set<Integer>> formulaGroupRowIndexInfo = new HashMap<>();
        ////// (計算式出力の場合) サマリする行を確保するCollection(E)
        
        /////////// 一覧データを出力 //////////
        for (Map<String, Object> data : list) {
            boolean isHsChange = false;
            boolean isTeamChange = false;
            boolean iaAnkenChange = false;
            
            ////// キーブレイク判定
            // データ種別
            String nowAnkenKey = this.getAnkenKey(data);
            // 本社/支社区分
            String nowHSKbn = StringUtils.defaultString((String)data.get("HONSYA_SHISYA_KBN"));
            // チームコード
            String nowTeamCode = StringUtils.defaultString((String)data.get("TEAM_CODE"));

            // 2行目以降isKeyBreak
            if (!isFirst) {
                if (!nowHSKbn.equals(baseHSKbn)) {
                    isHsChange = true;
                }
                if (!nowTeamCode.equals(baseTeamCode)) {
                    isTeamChange = true;
                }
                if (!nowAnkenKey.equals(baseAnkenKey)) {
                    iaAnkenChange = true;
                }

                // 案件データを出力 → 案件 or チーム or 本社/支社いずれかが変更される場合にこれまでの集計値を出力
                if (iaAnkenChange || isTeamChange || isHsChange) {
                    this.writeLineAnken(dataSheet, ankenRowIndex, baseAnkenKey, baseData, ankenRowInfo, ankenCellStyleList, formulaGroupRowIndexInfo);
                    ankenRowIndex = ankenRowIndex + ANKEN_ROW_COUNT;
                    
                    // 案件データが変更される場合、これまでの計算値をクリアする。
                    ankenRowInfo = new HashMap();
                }
                // 本社/支社データを出力 → 本社/支社区分が変更される場合にこれまでの集計値を出力
                if (isHsChange) {
                    this.writeLineHonsyaShisya(dataSheet, hsRowIndex, baseHSKbn, hsRowInfo, hsCellStyleList, honsyaShisyaRowIndexList);
                    hsRowIndex = ankenRowIndex;
                    ankenRowIndex = hsRowIndex + HS_ROW_COUNT;
                    
                    // 本社/支社区分が変更される場合、本社/支社単位データは別になるため、これまでの集計値をクリアする。
                    hsRowInfo = new HashMap();
                    
                    honsyaShisyaRowIndexList = new LinkedHashSet<>();
                }
                // チームコード単位行データを出力 → チームコード or 本社/支社区分が変更される場合にこれまでの集計値を出力
                if (isTeamChange || isHsChange) {
                    this.writeLineTeam(dataSheet, teamRowIndex, baseTeamCode, teamNameInfo, teamRowInfo, teamCellStyleList, teamRowIndexList);
                    teamRowIndex = ankenRowIndex;
                    ankenRowIndex = teamRowIndex + TEAM_ROW_COUNT;

                    // チームコード or 本社/支社区分が変更される場合、チームコードデータは別枠になるため、これまでの集計値をクリアする。
                    teamRowInfo = new HashMap();
                    
                    teamRowIndexList = new LinkedHashSet<>();
                }
                
                teamRowIndexList.add(ankenRowIndex);
                honsyaShisyaRowIndexList.add(teamRowIndex);
            }
            
            ////// [案件データ]値を集計する。
            this.addRowData(ankenRowInfo, data);
            ////// [チームコードデータ]値を集計する。
            this.addRowData(teamRowInfo, data);
            ////// [本社/支社]値を集計する。
            this.addRowData(hsRowInfo, data);

            ////// [案件データ]値を集計する。
            Map<String, Object> gTotalRowData = gTotalAnkenRowInfoMap.get(nowAnkenKey);
            if (gTotalRowData == null) {
                gTotalRowData = new HashMap<>();
            }
            this.addRowData(gTotalRowData, data);
            gTotalAnkenRowInfoMap.put(nowAnkenKey, gTotalRowData);

            // キーブレイク判定情報を更新
            baseAnkenKey = nowAnkenKey;
            baseHSKbn = nowHSKbn;
            baseTeamCode = nowTeamCode;
            
            baseData = data;

            isFirst = false;
            //logger.info("[outputAnkenList] ankenRowIndex=[{}] ankenId=[{}] hsKbn=[{}] teamCode=[{}] ankenKey=[{}]", ankenRowIndex, data.get("ANKEN_ID"), data.get("HONSYA_SHISYA_KBN"), data.get("TEAM_CODE"), nowAnkenKey);
        }

        // 最終データの合計行を出力
        if (baseData != null) {
            this.writeLineAnken(dataSheet, ankenRowIndex, baseAnkenKey, baseData, ankenRowInfo, ankenCellStyleList, formulaGroupRowIndexInfo);   // 案件単位の行データ
            ankenRowIndex = ankenRowIndex + ANKEN_ROW_COUNT;
        }
        this.writeLineTeam(dataSheet, teamRowIndex, baseTeamCode, teamNameInfo, teamRowInfo, teamCellStyleList, teamRowIndexList);  // チームコード毎の合計
        this.writeLineHonsyaShisya(dataSheet, hsRowIndex, baseHSKbn, hsRowInfo, hsCellStyleList, honsyaShisyaRowIndexList);   // 本社/支社合計
        
        // GROUP_CODE全体の合計データを出力
        this.writeLineGroup(dataSheet, startRowIndex, groupInfo, gTotalAnkenRowInfoMap, gTotalCellStyleList, formulaGroupRowIndexInfo);
        // [総合計]欄に計算式を埋め込むための行数をカテゴリ毎に確保
        this.setFormulaTotalRowIndexInfo(formulaTotalRowIndexInfo, startRowIndex);
        
        
        // 総合計行に出力するデータの合計値を加算(総合計行のデータはtotalDataRowInfoに格納される)
        Set<String> ankenKeySet = gTotalAnkenRowInfoMap.keySet();
        Iterator<String> ite = ankenKeySet.iterator();
        while(ite.hasNext()) {
            String key = ite.next();
 
            Map<String, Object> baseTotalMap = totalDataRowInfo.get(key);
            if (baseTotalMap == null) {
                baseTotalMap = new HashMap<>();
            }
            totalDataRowInfo.put(key, baseTotalMap);
            
            Map<String, Object> valueMap = gTotalAnkenRowInfoMap.get(key);

            this.addRowData(baseTotalMap, valueMap);
        }

        // 次のGROUP_CODEデータ処理のために、行をシフトする。
        startRowIndex = ankenRowIndex + 1;
        return startRowIndex;
    }

    /**
     * [総合計]欄に計算式を埋め込むための行数をカテゴリ毎に確保
     */
    private void setFormulaTotalRowIndexInfo(Map<String, Set<Integer>> formulaTotalRowIndexInfo, int startRowIndex) {
        int rowIndex = startRowIndex;
        
        // [引渡し基準案件]行
        Set<Integer> formulaTotalIppanRowIndexInfo = formulaTotalRowIndexInfo.get("IPPAN");
        if (formulaTotalIppanRowIndexInfo == null) {
            formulaTotalIppanRowIndexInfo = new LinkedHashSet<>();
        }
        rowIndex = rowIndex + ANKEN_ROW_COUNT;
        formulaTotalIppanRowIndexInfo.add(rowIndex);
        formulaTotalRowIndexInfo.put("IPPAN", formulaTotalIppanRowIndexInfo);
        
        // [引渡し基準案件(ISP)]行
        Set<Integer> formulaTotalIspRowIndexInfo = formulaTotalRowIndexInfo.get("ISP");
        if (formulaTotalIspRowIndexInfo == null) {
            formulaTotalIspRowIndexInfo = new LinkedHashSet<>();
        }
        rowIndex = rowIndex + ANKEN_ROW_COUNT;
        formulaTotalIspRowIndexInfo.add(rowIndex);
        formulaTotalRowIndexInfo.put("ISP", formulaTotalIspRowIndexInfo);
        
        // [進行基準案件]行
        Set<Integer> formulaTotalShinkoRowIndexInfo = formulaTotalRowIndexInfo.get("SHINKO");
        if (formulaTotalShinkoRowIndexInfo == null) {
            formulaTotalShinkoRowIndexInfo = new LinkedHashSet<>();
        }
        rowIndex = rowIndex + ANKEN_ROW_COUNT;
        formulaTotalShinkoRowIndexInfo.add(rowIndex);
        formulaTotalRowIndexInfo.put("SHINKO", formulaTotalShinkoRowIndexInfo);
        
        // [白地案件]行
        Set<Integer> formulaTotalShirajRowIndexInfo = formulaTotalRowIndexInfo.get("SHIRAJI");
        if (formulaTotalShirajRowIndexInfo == null) {
            formulaTotalShirajRowIndexInfo = new LinkedHashSet<>();
        }
        rowIndex = rowIndex + ANKEN_ROW_COUNT;
        formulaTotalShirajRowIndexInfo.add(rowIndex);
        formulaTotalRowIndexInfo.put("SHIRAJI", formulaTotalShirajRowIndexInfo);
    }
    
    /**
     * 案件のデータ種別(引渡し基準案件、引渡し基準案件(ISP)、進行基準案件の案件番号、白地案件)を取得
     */
    private String getAnkenKey(Map<String, Object> data) {
        if (data == null) {
            return "";
        }
        
        // 進行基準FLG(0:一般 1:進行基準)
        String salesClass = StringUtils.defaultString((String)data.get("SALES_CLASS"));
        // ISP区分(2:ISP 2以外:通常案件)
        String ispKbn = StringUtils.defaultString((String)data.get("ISP_KBN"));
        // 白地案件FLG(1:白地案件)
        String shirajiFlg = StringUtils.defaultString((String)data.get("SHIRAJI_FLG"));
        
        String ankenKey = "";
        // 案件のデータ種別を取得
        if ("2".equals(ispKbn)) {
            // ISP案件(1行にまとめるため、キーを固定化)
            ankenKey = "ISP";            
        } else if ("1".equals(salesClass)) {
            // 進行基準案件は案件毎に一覧出力するため、案件番号をキーにする。
            ankenKey = StringUtils.defaultString((String)data.get("ANKEN_ID"));
        } else if ("1".equals(shirajiFlg) ) {
            // 白地案件(1行にまとめるため、キーを固定化)
            ankenKey = "SHIRAJI";
        } else {
            // 上記以外は一般案件(1行にまとめるため、キーを固定化)
            ankenKey = "IPPAN";
        }
        
        /*
        // 案件のデータ種別を取得
        if ("1".equals(shirajiFlg)) {
            // 白地案件(1行にまとめるため、キーを固定化)
            ankenKey = "SHIRAJI";
        } else if ("1".equals(salesClass)) {
            // 進行基準案件は案件毎に一覧出力するため、案件番号をキーにする。
            ankenKey = StringUtils.defaultString((String)data.get("ANKEN_ID"));
        } else if ("2".equals(ispKbn)) {
            // ISP案件(1行にまとめるため、キーを固定化)
            ankenKey = "ISP";
        } else {
            // 上記以外は一般案件(1行にまとめるため、キーを固定化)
            ankenKey = "IPPAN";
        }
        */
        
        return ankenKey;
    }
    
    /**
     * データ一覧出力(GROUP_CODEの合計行を出力)
     */
    private void writeLineGroup(
            Sheet dataSheet
          , int rowIndex
          , SyuWfControlTbl groupInfo
          , Map<String, Map<String, Object>> gTotalAnkenRowInfoMap
          , List<List<Cell>> gTotalCellStyleList
          , Map<String, Set<Integer>> formulaGroupRowIndexInfo
    )
    throws Exception {
        // データを出力(SP,粗利,M率3行分を出力)
        for (int i=0; i<GROUP_TOTAL_ROW_COUNT; i++) {
            int targetRowIndex = rowIndex + i;

            //// 行にスタイルを設定
            Row targetRow = PoiUtil.getRow(dataSheet, targetRowIndex, true);
            PoiUtil.copyRowStyleValue(targetRow, gTotalCellStyleList.get(i), true, this.isSummaryCalc());

            // 2行目にタイトルを出力
            if (i == 1) {
                Cell cell = PoiUtil.getCell(targetRow, TITLE_CELL_INDEX);
                PoiUtil.setCellValue(cell, groupInfo.getTantoNm() + "　合計");
            }
        }

        // 合計行データの出力
        this.writeTotalRowData(dataSheet, rowIndex, gTotalAnkenRowInfoMap, formulaGroupRowIndexInfo);
    }

    /**
     * データ一覧出力(本社/支社毎の合計行)
     */
    private void writeLineHonsyaShisya(Sheet dataSheet, int rowIndex, String hsKbn, Map<String, Object> hsRowInfo, List<List<Cell>> hsCellStyleList, Set<Integer> formulaRowIndexList) throws Exception {
        String honsyaShisyaName = "";

        if ("S".equals(hsKbn)) {
            honsyaShisyaName = "支社　計";
        } else {
            honsyaShisyaName = "本社　計";
        }

        // スタイルを出力(SP,粗利,M率3行分を出力)
        for (int i=0; i<HS_ROW_COUNT; i++) {
            int targetRowIndex = rowIndex + i;

            //// 行にスタイルを設定
            Row targetRow = PoiUtil.getRow(dataSheet, targetRowIndex, true);
            PoiUtil.copyRowStyleValue(targetRow, hsCellStyleList.get(i), true, this.isSummaryCalc());
            
            // 2行目にタイトルを出力
            if (i == 1) {
                Cell cell = PoiUtil.getCell(targetRow, TITLE_CELL_INDEX);
                PoiUtil.setCellValue(cell, honsyaShisyaName);
            }
        }
        
        // データの出力
        this.writeRowData(dataSheet, rowIndex, hsRowInfo, false, formulaRowIndexList);
    }

    /**
     * データ一覧出力(チームコード合計行)
     */
    private void writeLineTeam(Sheet dataSheet, int rowIndex, String teamCode, Map<String, String> teamNameInfo, Map<String, Object> teamRowInfo, List<List<Cell>> teamCellStyleList, Set<Integer> formulaRowIndexList) throws Exception {
        Cell cell;
        String teamCodeName = teamCode + " " + Label.getValue(Label.ruikei2);

        // スタイルを出力(SP,粗利,M率3行分を出力)
        for (int i=0; i<TEAM_ROW_COUNT; i++) {
            int targetRowIndex = rowIndex + i;

            //// 行にスタイルを設定
            Row targetRow = PoiUtil.getRow(dataSheet, targetRowIndex, true);
            PoiUtil.copyRowStyleValue(targetRow, teamCellStyleList.get(i), true, this.isSummaryCalc());
            
            cell = PoiUtil.getCell(targetRow, TITLE_CELL_INDEX);
            
            // 一行目にチームコードに対応する部門名を表示
            if (i == 0) {
                PoiUtil.setCellValue(cell, StringUtils.defaultString(teamNameInfo.get(teamCode)));
            }
            // 2行目にタイトルを出力
            if (i == 1) {
                PoiUtil.setCellValue(cell, teamCodeName);
            }
        }
        
        // データの出力
        this.writeRowData(dataSheet, rowIndex, teamRowInfo, false, formulaRowIndexList);
    }

    /**
     * データ一覧出力(案件の出力)
     */
    private void writeLineAnken(
          Sheet dataSheet, int rowIndex, String ankenKey
        , Map<String, Object> data, Map<String, Object> ankenRowInfo
        , List<List<Cell>> ankenCellStyleList
        , Map<String, Set<Integer>> groupRowIndexInfo
    ) throws Exception {
        String rowTitle = "";
        String rowIndexKey = ankenKey;
        Cell cell;

        // 案件のデータ種別を取得
        if (ankenKey.equals("SHIRAJI")) {
            // 白地案件(1行にまとめるため、キーを固定化)
            rowTitle = "白地案件";

        } else if (ankenKey.equals("ISP")) {
            // ISP案件(1行にまとめるため、キーを固定化)
            rowTitle = "引渡し基準案件(ISP)";

        } else if (ankenKey.equals("IPPAN")) {
            // 上記以外は一般案件(
            rowTitle = "引渡し基準案件";

        } else {
            // 進行基準案件は案件毎に一覧出力するため、案件番号をキーにする。
            rowTitle = StringUtils.defaultString((String)data.get("ANKEN_NAME"));
            
            rowIndexKey = "SHINKO";
        }

        // スタイル出力(必要なデータ束で集計した後に出力する。SP,粗利,M率3行分を出力)
        for (int i=0; i<ANKEN_ROW_COUNT; i++) {
            int targetRowIndex = rowIndex + i;

            //// 行にスタイルを設定
            Row targetRow = PoiUtil.getRow(dataSheet, targetRowIndex, true);
            PoiUtil.copyRowStyleValue(targetRow, ankenCellStyleList.get(i), true, this.isSummaryCalc());

            // 2行目にタイトルを出力
            if (i == 1) {
                cell = PoiUtil.getCell(targetRow, TITLE_CELL_INDEX);
                PoiUtil.setCellValue(cell, rowTitle);
            }
        }

        // データの出力
        this.writeRowData(dataSheet, rowIndex, ankenRowInfo, true, null);

        // 合計行に設定する計算式を作成するするための行番号を格納
        // "計算式出力"の場合のみ利用される
        Set<Integer> rowIndexList = groupRowIndexInfo.get(rowIndexKey);
        if (rowIndexList == null) {
            rowIndexList = new LinkedHashSet<>();
        }
        rowIndexList.add(rowIndex);
        groupRowIndexInfo.put(rowIndexKey, rowIndexList);
    }
    
    /**
     * 全データの総合計を出力
     */
    private void outputTotal(
            Workbook workbook
          , Integer startRowIndex
          , Map<String, Map<String, Object>> totalDataRowInfo
          , Map<String, Set<Integer>> formulaTotalRowIndexInfo
    ) throws Exception {
        Sheet dataSheet = workbook.getSheet(SHEETNAME);
        Sheet styleSheet = workbook.getSheet(STYLESHEETNAME);
        
        /////////// スタイル定義(S) //////////////
        // GROUP_CODE単位の合計行データ・出力スタイルを定義
        //   (GROUP_CODE合計、引渡し基準案件、引渡し基準案件(ISP)、進行基準案件、白地案件の5カテゴリ)
        //   (カテゴリ毎に、SP,粗利,M率の3行分)
        //   以上、合計5×3=15行分
        List<List<Cell>> totalCellStyleList = new ArrayList<>();
        for (int i=28; i<(28 + GROUP_TOTAL_ROW_COUNT); i++) {
            List<Cell> totalCellStyleListRow = PoiUtil.getCellList(PoiUtil.getRow(styleSheet, i));
            totalCellStyleList.add(totalCellStyleListRow);
        }

        // 総合計行のスタイルを出力
        for (int i=0; i<GROUP_TOTAL_ROW_COUNT; i++) {
            int targetRowIndex = startRowIndex + i;

            //// 行にスタイルを設定
            Row targetRow = PoiUtil.getRow(dataSheet, targetRowIndex, true);
            PoiUtil.copyRowStyleValue(targetRow, totalCellStyleList.get(i), true, this.isSummaryCalc());
        }

        // 総合計行データの出力
        this.writeTotalRowData(dataSheet, startRowIndex, totalDataRowInfo, formulaTotalRowIndexInfo);
    }

    /**
     * 行の値を加算
     */
    private void addRowData(Map<String, Object> baseData, Map<String, Object> addData) {
        String spKey;
        String netKey;
        
        String nowSpKey;
        String nowNetKey;
        String befSpKey;
        String befNetKey;

        for (int j=1; j<=6; j++) {
            nowSpKey = "SP" + j + "_NOW";
            nowNetKey = "NET" + j + "_NOW";
            befSpKey = "SP" + j + "_BEF";
            befNetKey = "NET" + j + "_BEF";

            // 実績/見込SP,NETを加算
            baseData.put(nowSpKey, Utils.add((BigDecimal)baseData.get(nowSpKey), (BigDecimal)addData.get(nowSpKey)));
            baseData.put(nowNetKey, Utils.add((BigDecimal)baseData.get(nowNetKey), (BigDecimal)addData.get(nowNetKey)));
            // 予算ベースSP,NETを加算
            baseData.put(befSpKey, Utils.add((BigDecimal)baseData.get(befSpKey), (BigDecimal)addData.get(befSpKey)));
            baseData.put(befNetKey, Utils.add((BigDecimal)baseData.get(befNetKey), (BigDecimal)addData.get(befNetKey)));
        }
        
        // Qデータを加算
        for (int i=1; i<=2; i++) {
            spKey = "SP" + i + "Q";
            netKey = "NET" + i + "Q";
            
            nowSpKey = spKey + "_NOW";
            nowNetKey = netKey + "_NOW";
            befSpKey = spKey + "_BEF";
            befNetKey = netKey + "_BEF";
            
            // 今回SP Qデータ
            baseData.put(nowSpKey, Utils.add((BigDecimal)baseData.get(nowSpKey), (BigDecimal)addData.get(nowSpKey)));
            // 今回NET Qデータ
            baseData.put(nowNetKey, Utils.add((BigDecimal)baseData.get(nowNetKey), (BigDecimal)addData.get(nowNetKey)));
            // 予算ベースSP Qデータ
            baseData.put(befSpKey, Utils.add((BigDecimal)baseData.get(befSpKey), (BigDecimal)addData.get(befSpKey)));
            // 予算ベースNET Qデータ
            baseData.put(befNetKey, Utils.add((BigDecimal)baseData.get(befNetKey), (BigDecimal)addData.get(befNetKey)));
        }

        // 期合計データを加算
        nowSpKey = "SP_K_NOW";
        nowNetKey = "NET_K_NOW";
        befSpKey = "SP_K_BEF";
        befNetKey = "NET_K_BEF";
        
        // 今回SP 期合計(K)データ
        baseData.put(nowSpKey, Utils.add((BigDecimal)baseData.get(nowSpKey), (BigDecimal)addData.get(nowSpKey)));
        // 今回NET 期合計(K)データ
        baseData.put(nowNetKey, Utils.add((BigDecimal)baseData.get(nowNetKey), (BigDecimal)addData.get(nowNetKey)));
        // 予算ベースSP 期合計(K)データ
        baseData.put(befSpKey, Utils.add((BigDecimal)baseData.get(befSpKey), (BigDecimal)addData.get(befSpKey)));
        // 予算ベースNET 期合計(K)データ
        baseData.put(befNetKey, Utils.add((BigDecimal)baseData.get(befNetKey), (BigDecimal)addData.get(befNetKey)));
    }

    /**
     * データ出力
     */
    private void writeRowData(Sheet dataSheet, int startRowIndex, Map<String, Object> data, boolean isJissekiStyle, Set<Integer> formulaRowIndexList) throws Exception {
        if (data == null) {
            return;
        }
        //logger.info("[writeRowData] startRowIndex=[{}]", startRowIndex);
        
        Workbook workbook = dataSheet.getWorkbook();
        Sheet styleSheet = workbook.getSheet(STYLESHEETNAME);
        
        Date baseYmDate = null;
        
        int yosanColNumber = 3;
        int jissekiColNumer = yosanColNumber + 1;
        int diffColNumber = jissekiColNumer + 1;

        BigDecimal yosanSp;
        BigDecimal yosanNet;
        BigDecimal yosanArari;
        BigDecimal yosanMrate;
        
        BigDecimal sp;
        BigDecimal net;
        BigDecimal arari;
        BigDecimal mrate;
        
        int qIndex = 1;
        // 月をループ
        for (int j=1; j<=6; j++) {
            String nowSpKey;
            String nowNetKey;
            String befSpKey;
            String befNetKey;

            int kk = 1;
            if (j == 3) {
                // 3月目の後にQ列を出力
                kk = 2;
            } else if (j == 6) {
                // 6月目の後にQ列,期合計列を出力
                kk = 3;
            }
            
            for (int k=1; k<=kk; k++) {
                if (k == 3) {
                    // 期合計をセット
                    nowSpKey = "SP_K_NOW";
                    nowNetKey = "NET_K_NOW";
                    befSpKey = "SP_K_BEF";
                    befNetKey = "NET_K_BEF";
                    
                } else if (k == 2) {
                    // Q合計をセット
                    nowSpKey = "SP" + qIndex + "Q_NOW";
                    nowNetKey = "NET" + qIndex + "Q_NOW";
                    befSpKey = "SP" + qIndex + "Q_BEF";
                    befNetKey = "NET" + qIndex + "Q_BEF";
                    qIndex++;
                
                } else {
                    // 各月データをセット
                    nowSpKey = "SP" + j + "_NOW";
                    nowNetKey = "NET" + j + "_NOW";
                    befSpKey = "SP" + j + "_BEF";
                    befNetKey = "NET" + j + "_BEF";
                }

                // 予算SP,NET,粗利,M率
                yosanSp = (BigDecimal)data.get(befSpKey);
                yosanNet = (BigDecimal)data.get(befNetKey);
                yosanArari = syuuekiUtils.arari(yosanSp, yosanNet);
                yosanMrate = Utils.changeBigDecimal(syuuekiUtils.mrate(yosanSp, yosanNet));
                // 実績(見込)SP,NET,粗利,M率
                sp = (BigDecimal)data.get(nowSpKey);
                net = (BigDecimal)data.get(nowNetKey);
                arari = syuuekiUtils.arari(sp, net);
                mrate = Utils.changeBigDecimal(syuuekiUtils.mrate(sp, net));

                // SP,粗利,M率を出力(i=0:SP i=1:粗利 i=2:M率)
                for (int i=0; i<ANKEN_ROW_COUNT; i++) {
                    int targetRowIndex = startRowIndex + i;
                    Row targetRow = PoiUtil.getRow(dataSheet, targetRowIndex, true);

                    Cell yosanCell = PoiUtil.getCell(targetRow, yosanColNumber);
                    Cell jissekiCell = PoiUtil.getCell(targetRow, jissekiColNumer);
                    Cell diffCell = PoiUtil.getCell(targetRow, diffColNumber);

                    Cell jissekiStyleCell = null;
                    
                    if (i == 0) {         // [Ｓ Ｐ]出力
                        PoiUtil.setCellValue(yosanCell, syuuekiUtils.changeUnit(yosanSp, s001Bean.getJpyUnitKbn()));
                        PoiUtil.setCellValue(jissekiCell, syuuekiUtils.changeUnit(sp, s001Bean.getJpyUnitKbn()));
                        if (this.isSummaryCalc() && formulaRowIndexList != null) {  // "計算式の出力"の場合
                            if (k == 1) {
                                // 各月の列の場合のみ、計算式を設定する
                                //   (Q列・期合計列は既にテンプレートで計算式が埋め込まれている(各月の合計(横方向の合計)式が埋め込まれている)ため、計算式セットは行わない)
                                PoiUtil.setCellFormula(yosanCell, this.getExcelPlusRowFormula(formulaRowIndexList, yosanColNumber, 0));
                                PoiUtil.setCellFormula(jissekiCell, this.getExcelPlusRowFormula(formulaRowIndexList, jissekiColNumer, 0));
                            }

                        } else {   // "値の出力"の場合
                            // 差異
                            PoiUtil.setCellValue(diffCell, syuuekiUtils.changeUnit(syuuekiUtils.arari(sp, yosanSp), s001Bean.getJpyUnitKbn()));
                        }
                        
                        jissekiStyleCell = PoiUtil.getCell(styleSheet, 46, 3);

                    } else if (i == 1) {  // [粗 利]出力
                        PoiUtil.setCellValue(yosanCell, syuuekiUtils.changeUnit(yosanArari, s001Bean.getJpyUnitKbn()));
                        PoiUtil.setCellValue(jissekiCell, syuuekiUtils.changeUnit(arari, s001Bean.getJpyUnitKbn()));
                        if (this.isSummaryCalc() && formulaRowIndexList != null) {  // "計算式の出力"の場合
                            if (k == 1) {
                                // 各月の列の場合のみ、計算式を設定する
                                //   (Q列・期合計列は既にテンプレートで計算式が埋め込まれている(各月の合計(横方向の合計)式が埋め込まれている)ため、計算式セットは行わない)
                                PoiUtil.setCellFormula(yosanCell, this.getExcelPlusRowFormula(formulaRowIndexList, yosanColNumber, 1));
                                PoiUtil.setCellFormula(jissekiCell, this.getExcelPlusRowFormula(formulaRowIndexList, jissekiColNumer, 1));
                            }
                            
                        } else {   // "値の出力"の場合
                            // 差異
                            PoiUtil.setCellValue(diffCell, syuuekiUtils.changeUnit(syuuekiUtils.arari(arari, yosanArari), s001Bean.getJpyUnitKbn()));
                        }
                        
                        jissekiStyleCell = PoiUtil.getCell(styleSheet, 47, 3);

                    } else if (i == 2) {  // [Ｍ 率]出力
                        if (!this.isSummaryCalc()) {    // "値の出力"の場合のみ設定
                            PoiUtil.setCellValue(yosanCell, yosanMrate);
                            PoiUtil.setCellValue(jissekiCell, mrate);
                        }
                        
                        jissekiStyleCell = PoiUtil.getCell(styleSheet, 48, 3);
                    }

                    // 実績月の場合は、背景色をグレー(スタイル変更)にする。
                    if (isJissekiStyle && k == 1) {
                        if (baseYmDate == null) {
                            baseYmDate = Utils.parseDate(this.getBaseYm());
                        }
                        // 対象の月を取得
                        Cell ymCell = PoiUtil.getCell(dataSheet, 1, yosanColNumber);
                        String targetYm = StringUtils.replace((String)(PoiUtil.getCellValue(ymCell)), "/", "");

                        // 実績月であればグレーにする。
                        boolean jissekiFlg = syuuekiUtils.getJissekiFlg(baseYmDate, targetYm);
                        if (jissekiFlg) {
                            jissekiCell.setCellStyle(jissekiStyleCell.getCellStyle());
                        }
                    }
                }

                // 次の月へシフト
                yosanColNumber = yosanColNumber + 3;
                jissekiColNumer = yosanColNumber + 1;
                diffColNumber = jissekiColNumer + 1;
            }
        }
    }
    
    /**
     * データ出力(合計行データ)
     */
    private void writeTotalRowData(
            Sheet dataSheet
          , int startRowIndex
          , Map<String, Map<String, Object>> totalDataMap
          , Map<String, Set<Integer>> formulaGroupRowIndexInfo
    ) throws Exception {
        int rowIndex = startRowIndex;
        
        Map<String, Object> targetRow; 
        
        Map<String, Object> gTotalRow = new HashMap<>();       // GROUP_CODE単位の総合計データ
        Map<String, Object> shinkoTotalRow = new HashMap<>();  // 進行基準案件の総合計データ
        // GROUP_CODE単位の総合計データ、進行基準案件の総合計データを算出
        Set<String> ankenKeySet = totalDataMap.keySet();
        Iterator<String> ite = ankenKeySet.iterator();
        while(ite.hasNext()) {
            String key = ite.next();
            Map<String, Object> valueMap = totalDataMap.get(key);
            // GROUP_CODE単位の総合計データを算出
            this.addRowData(gTotalRow, valueMap);
            // 進行基準単位の総合計データを算出
            if (!"IPPAN".equals(key) && !"ISP".equals(key) && !"SHIRAJI".equals(key)) {
                this.addRowData(shinkoTotalRow, valueMap);
            }
        }

        // 計算式を格納するための行番号リストを各案件カテゴリ毎に取得。
        // (これらはメソッドwriteLineAnkenで予め設定されたため、それを利用する)
        Set<Integer> formulaIppanRowList = formulaGroupRowIndexInfo.get("IPPAN");
        Set<Integer> formulaIspRowList = formulaGroupRowIndexInfo.get("ISP");
        Set<Integer> formulaShinkoRowList = formulaGroupRowIndexInfo.get("SHINKO");
        Set<Integer> formulaShirajiRowList = formulaGroupRowIndexInfo.get("SHIRAJI");
        
        // データ出力(グループコード単位の総合計)
        this.writeRowData(dataSheet, rowIndex, gTotalRow, false, null);
        
        // データ出力(引き渡し基準案件)
        rowIndex = rowIndex + ANKEN_ROW_COUNT;
        targetRow = totalDataMap.get("IPPAN");
        this.writeRowData(dataSheet, rowIndex, targetRow, false, formulaIppanRowList);
        
        // データ出力(ISP)
        rowIndex = rowIndex + ANKEN_ROW_COUNT;
        targetRow = totalDataMap.get("ISP");
        this.writeRowData(dataSheet, rowIndex, targetRow, false, formulaIspRowList);

        // データ出力(進行基準案件)
        rowIndex = rowIndex + ANKEN_ROW_COUNT;
        this.writeRowData(dataSheet, rowIndex, shinkoTotalRow, false, formulaShinkoRowList);
        
        // データ出力(白地案件)
        rowIndex = rowIndex + ANKEN_ROW_COUNT;
        targetRow = totalDataMap.get("SHIRAJI");
        this.writeRowData(dataSheet, rowIndex, targetRow, false, formulaShirajiRowList);
    }

    /**
     * SQL文の共通指定パラメータを取得
     */
    private Map<String, Object> getBaseCondition(StringBuilder sortGroupCode) throws Exception {
        Map<String, Object> condition = new HashMap<>();
        
        // 基準年月
        condition.put("baseYm", this.getBaseYm());
        // 年月指定
        String[] kikanMonthAry = SyuuekiUtils.getKikanMonthAry(s001Bean.getTaishoY() + s001Bean.getTaishoKi());  // 指定した期の年月を配列取得
        int ymIndex = 1;
        for (String month : kikanMonthAry) {
            condition.put("syuekiYm" + ymIndex, month);
            ymIndex++;
        }
        // Quater指定
        condition.put("syuekiYmQ1", kikanMonthAry[2] + "Q");
        condition.put("syuekiYmQ2", kikanMonthAry[5] + "Q");
        // 期合計指定
        String targetKi = SyuuekiUtils.dateToKikan(Utils.parseDate(kikanMonthAry[0]));
        condition.put("syuekiYmK", targetKi);
        // 月次確定画面からの出力か？(この場合、画面と同じ検索条件を付加)
        condition.put("monthyKakuteiFlg", String.valueOf(this.monthyKakuteiFlg()));

        if (sortGroupCode.length() > 0) {
            condition.put("sortGroupCode", "CASE " + String.valueOf(sortGroupCode) + " END");
        } else {
            condition.put("sortGroupCode", "NULL");
        }

        if (this.monthyKakuteiFlg() == 1) {
            // 月次確定画面から出力
            logger.info("[getWfControlCondition] shisyaHonsyaKbn:" + s014Bean.getHonsyaShisyaKbn());
            if (s014Bean.getHonsyaShisyaKbn().equals("H")) {
                condition.put("shisyaHonsyaKbn","1" ); //       
            } else {
                condition.put("shisyaHonsyaKbn","0" ); //   
            }

        } else {
            // 受注売上見込一覧から出力
            logger.info("[getWfControlCondition] shisyaHonsyaKbn:H");
            condition.put("shisyaHonsyaKbn","1" ); //
        }

        return condition;
    }

    /**
     * SQL文のWHERE句を取得するためのパラメータを取得
     */
    private Map<String, Object> getWhereParameter(String rirekiFlg, List<Object> nowRirekiIdList) throws Exception {
        Map<String, Object> wfControlCondition = this.getWfControlCondition();
        
        // WHERE句に指定するパラメータを取得
        Map<String, Object> conditionWhere;
        if (monthyKakuteiFlg() == 1) {
            // 月次確定画面から出力
            conditionWhere = new HashMap<>();
        } else {
            // 案件一覧(受注売上見込一覧) から出力
            conditionWhere = s001Service.getCondition();
        }
        conditionWhere.put("divisionCode", wfControlCondition.get("divisionCode"));
        conditionWhere.put("salesClass", wfControlCondition.get("salesClass"));
        conditionWhere.put("kanjyoYm", this.getBaseYm());
        conditionWhere.put("rirekiFlg", rirekiFlg);
        conditionWhere.put("rirekiId", nowRirekiIdList);
        conditionWhere.put("syuekiControlKbn", "1");
        conditionWhere.put("whereOnlyFlg", "1");      // WHERE句のみ抜き出すFLG(SQL文内でこの条件でWHERE句のみ取得できるようにした)

        return conditionWhere;
    }
    
    /**
     * SQLのORDER BY句を取得
     */
    private String getSelectOrderBy() {
        StringBuilder sb = new StringBuilder();
        sb.append("ORDER BY A.HONSYA_SHISYA_KBN ");
        sb.append("       , A.SORT_GROUP_CODE ");
        sb.append("       , A.TEAM_CODE ");
        sb.append("       , NVL(A.SHIRAJI_FLG, '0') ");
        sb.append("       , A.SALES_CLASS ");
        sb.append("       , A.ISP_KBN ");
        return String.valueOf(sb);
    }
    
    /**
     * 原案データの履歴ID取得
     */
    private List<Object> getGenanRirekiIdList() {
        List<Object> rirekiIdList = new ArrayList<>();
        rirekiIdList.add(Integer.parseInt(ConstantString.geRirekiId));
        rirekiIdList.add(Integer.parseInt(ConstantString.teishutsuRirekiId));
        return rirekiIdList;
    }

    /**
     * SQL文を実行(月次確定画面から出力する場合)
     */
    private List<Map<String, Object>> findAnkenListKakutei(SyuWfControlTbl groupInfo, List<SyuWfControlTbl> targetTeamList) throws Exception {
        logger.info("[SummaryListService#findAnkenListKakutei]");
        SqlFile sqlFile = new SqlFile();

        // 指定する履歴ID、(本社/支社)チームコードを取得
        List<Object> nowRirekiIdList = new ArrayList<>();                 // 履歴id(予算ベース)

        // 原案テーブルを検索する履歴ID(原案データ)
        Integer geNowRirekiId = null;
        // 原案テーブルを検索する履歴ID(提出用データ)
        Integer teishutsuRirekiId = null;
        
        List<String> honsyaTeamCodeList = new ArrayList<>();              // 本社チームコード(未確定)
        List<String> shisyaTeamCodeList = new ArrayList<>();              // 支社チームコード(未確定)
        List<String> kakuteiHonsyaTeamCodeList = new ArrayList<>();       // 本社チームコード(確定)
        List<String> kakuteiShisyaTeamCodeList = new ArrayList<>();       // 支社チームコード(確定)
        List<String> teishutsuHonsyaTeamCodeList = new ArrayList<>();     // 本社チームコード(提出用)
        List<String> teishutsuShisyaTeamCodeList = new ArrayList<>();     // 支社チームコード(提出用)

        List<String> geHonsyaTeamCode = new ArrayList<>();                // 作成中+提出用の本社チームコード
        //List<String> geShisyaTeamCode = new ArrayList<>();                // 作成中+提出用の支社チームコード

        StringBuilder sortGroupCode = new StringBuilder();

        int honsyaTeamCodeCount = 0;
        int shisyaTeamCodeCount = 0;
        for (SyuWfControlTbl wfControlTeamInfo : targetTeamList) {
            String honsyaShisyaKbn = wfControlTeamInfo.getHonsyaShisyaKbn();
            String teamCode = "";
            String status = wfControlTeamInfo.getStatus();
            
            if (StringUtils.isNotEmpty(wfControlTeamInfo.getTeamCode())) {
                if ("H".equals(honsyaShisyaKbn)) {
                    // 本社チームコード
                    honsyaTeamCodeCount = honsyaTeamCodeCount + 1;
                    if (ConstantString.wfStatusKakutei.equals(status)) {
                        // 確定済データ
                        kakuteiHonsyaTeamCodeList.add(wfControlTeamInfo.getTeamCode());
                    } else if (ConstantString.wfStatusTeishutsu.equals(status)) {
                        // 提出用データ
                        teishutsuHonsyaTeamCodeList.add(wfControlTeamInfo.getTeamCode());
                    } else {
                        // 未確定データ
                        honsyaTeamCodeList.add(wfControlTeamInfo.getTeamCode());
                    }
                    teamCode = wfControlTeamInfo.getTeamCode();

                } else if ("S".equals(honsyaShisyaKbn)) {
                    // 支社チームコード
                    shisyaTeamCodeCount = shisyaTeamCodeCount + 1;
                    if (ConstantString.wfStatusKakutei.equals(status)) {
                        // 確定済データ
                        kakuteiShisyaTeamCodeList.add(wfControlTeamInfo.getTeamCode());
                    } else if (ConstantString.wfStatusTeishutsu.equals(status)) {
                        // 提出用データ
                        teishutsuShisyaTeamCodeList.add(wfControlTeamInfo.getTeamCode());
                    } else {
                        // 未確定データ
                        shisyaTeamCodeList.add(wfControlTeamInfo.getTeamCode());
                    }
                    teamCode = wfControlTeamInfo.getTeamCode();
                }
            }
            
            // 履歴ID
            Long rirekiId = wfControlTeamInfo.getRirekiId();
            if (ConstantString.wfStatusKakutei.equals(status)) {
                // 確定済のチームコードは、その履歴idを検索対象とする。
                nowRirekiIdList.add(rirekiId);
            }
            
            // SQL実行時に、チームコードに該当するC_BUKA_CODEを取得できるようにしておく(ソート順で利用)
            if (StringUtils.isNotEmpty(wfControlTeamInfo.getcBukaCode()) && StringUtils.isNotEmpty(teamCode)) {
                sortGroupCode.append("WHEN TEAM_CODE = '")
                        .append(EscapeUtils.escapeSql(teamCode))
                        .append("' THEN '")
                        .append(EscapeUtils.escapeSql(wfControlTeamInfo.getcBukaCode()))
                        .append("' ");
            }
        }

        int genanSearchFlg = 0;
        int rirekiSearchFlg = 0;
        if (honsyaTeamCodeList.size() > 0 || shisyaTeamCodeList.size() > 0 || teishutsuHonsyaTeamCodeList.size() > 0 || teishutsuShisyaTeamCodeList.size() > 0) {
            genanSearchFlg = 1;
        }
        if (kakuteiHonsyaTeamCodeList.size() > 0 || kakuteiShisyaTeamCodeList.size() > 0) {
            rirekiSearchFlg = 1;
        }

        // 月次確定画面で、[前期]検索中の場合
        //   ※[前期]検索中は原案テーブル(R_がつかないテーブル)を検索するため、SQLパラメータもそれに合わせて変更する。
        if ("1".equals(s014Bean.getBeforKiFlg())) {
            // 本社チームコード、支社チームコードは確定/提出/未確定関わらず1まとめにする。
            honsyaTeamCodeList.addAll(kakuteiHonsyaTeamCodeList);
            honsyaTeamCodeList.addAll(teishutsuHonsyaTeamCodeList);
            shisyaTeamCodeList.addAll(kakuteiShisyaTeamCodeList);
            shisyaTeamCodeList.addAll(teishutsuShisyaTeamCodeList);
            
            // (提出用)チームコードをクリア
            teishutsuHonsyaTeamCodeList = new ArrayList();
            teishutsuShisyaTeamCodeList = new ArrayList();
            // (確定用)チームコードをクリア
            kakuteiHonsyaTeamCodeList = new ArrayList();
            kakuteiShisyaTeamCodeList = new ArrayList();

            // 原案テーブルのみ参照/履歴テーブルは参照しない 設定にする。
            genanSearchFlg = 1;
            rirekiSearchFlg = 0;
        }

        if (honsyaTeamCodeList.size() > 0 || shisyaTeamCodeList.size() > 0) {
            geNowRirekiId = Integer.parseInt(ConstantString.geRirekiId);
        }
        if (teishutsuHonsyaTeamCodeList.size() > 0 || teishutsuShisyaTeamCodeList.size() > 0) {
            teishutsuRirekiId = Integer.parseInt(ConstantString.teishutsuRirekiId);
        }

        // 原案テーブル検索用の本社・支社チームコードをまとめる
        geHonsyaTeamCode.addAll(honsyaTeamCodeList);
        geHonsyaTeamCode.addAll(teishutsuHonsyaTeamCodeList);

        // 履歴ID(予算ベース)
        //   表示対象期(YYYY + K or S)の予算ベース履歴ID群をSYU_WF_CONTROL_TBLから取得する。
        //   この履歴IDを使用して、各月予算ベース確定のSP,NETを取得する。
        List<Object> beforeRirekiIdList = new ArrayList<>();
        List<SyuWfControlTbl> yosanRirekiIdList = this.findTeamList(groupInfo, "Y");
        if (CollectionUtils.isNotEmpty(yosanRirekiIdList)) {
            for (SyuWfControlTbl yosanRirekiIdEntity : yosanRirekiIdList) {
                beforeRirekiIdList.add(yosanRirekiIdEntity.getRirekiId());
            }
        }

        logger.info("[SummaryListService#findAnkenListKakutei] rirekiId=[{}], yosanRirekiId=[{}]",  nowRirekiIdList, beforeRirekiIdList);
        logger.info("[SummaryListService#findAnkenListKakutei] honsyaTeamCode=[{}], shisyaTeamCode=[{}] kakuteiHonsyaTeamCode=[{}] kakuteiShisyaTeamCode=[{}] teishutsuHonsyaTeamCodeList=[{}] teishutsuShisyaTeamCodeList=[{}]",  honsyaTeamCodeList, shisyaTeamCodeList, kakuteiHonsyaTeamCodeList, kakuteiShisyaTeamCodeList, teishutsuHonsyaTeamCodeList, teishutsuShisyaTeamCodeList);
        logger.info("[SummaryListService#findAnkenListKakutei] genanSearchFlg=[{}], rirekiSearchFlg=[{}]", genanSearchFlg, rirekiSearchFlg);
        logger.info("[SummaryListService#findAnkenListKakutei] geRirekiId=[{}], teishutsuRirekiId=[{}]", geNowRirekiId, teishutsuRirekiId);

        ///////////////////////////////////////////////////////
        ////////////// SELECT句、FROM句作成(S) /////////////////
        ///////////////////////////////////////////////////////
        String splFilePath;
        String sqlFilePathRireki;
        if ("J".equals(s001Bean.getTenkaiKbn())) {
            // 「出力時オプション選択」ダイアログ [展開]で、"受注"を選択
            splFilePath = "/sql/download/summaryListJyuchu.sql";
            sqlFilePathRireki = "/sql/download/summaryListJyuchuRireki.sql";
        } else {
            // 「出力時オプション選択」ダイアログ [展開]で、"売上"を選択
            splFilePath = "/sql/download/summaryListUriage.sql";
            sqlFilePathRireki = "/sql/download/summaryListUriageRireki.sql";
        }
        String splFilePathWhere = "/sql/selectListSyuueki.sql";
        
        logger.info("[SummaryListService#findAnkenListKakutei] SQL_FILE=[{}] SQL_FILE_RIREKI=[{}]", splFilePath, sqlFilePathRireki);
        
        ///////////////////////////////////////////
        // 原案テーブルを検索する場合(S)
        ///////////////////////////////////////////
        String genanSelect = "";
        Object[] genanSelectFromParam = null;
        String genanWhere = "";
        Object[] genanWhereParam = null;
        if (genanSearchFlg == 1) {
            Map<String, Object> condition = this.getBaseCondition(sortGroupCode);

            if (geNowRirekiId == null && teishutsuRirekiId == null) {
                geNowRirekiId = Integer.parseInt(ConstantString.geRirekiId);
            }

            condition.put("geNowRirekiId", geNowRirekiId);
            condition.put("teishutsuRirekiId", teishutsuRirekiId);
            
            // 本社営業の案件のみ検索する場合、支社営業用案件は除外するように条件設定する
            // ※電力ジやNEPJは支社→本社の2段階WFは利用しないので、本社案件検索時に支社案件が検索対象に含まれないようにするための措置
            String honsyaOnlyFlg = "0";
            if (honsyaTeamCodeCount > 0 && shisyaTeamCodeCount == 0) {
                honsyaOnlyFlg = "1";
            }
            condition.put("honsyaOnlyFlg", honsyaOnlyFlg);
            logger.info("[SummaryListService#findAnkenListKakutei] honsyaOnlyFlg=[{}]", honsyaOnlyFlg);
            
            // 事業部コード:(原子力)であるかを判断(原子力とそれ以外の事業部で検索条件を可変にする)
            String divisionNuclearFlg = "0";
            boolean isNuclearDivision = divisionComponentPage.isNuclearDivision(s014Bean.getDivisionCode());
            if (isNuclearDivision) {
                divisionNuclearFlg = "1";
            }
            condition.put("divisionNuclearFlg", divisionNuclearFlg);
            
            // (未確定)本社チームコード
            if (CollectionUtils.isEmpty(honsyaTeamCodeList)) {
                honsyaTeamCodeList.add("@@@@@@");
            }
            // (未確定)支社チームコード
            condition.put("honsyaTeamCode", honsyaTeamCodeList);
            if (CollectionUtils.isEmpty(shisyaTeamCodeList)) {
                shisyaTeamCodeList.add("@@@@@@");
            }
            condition.put("shisyaTeamCode", shisyaTeamCodeList);
            // (提出用)本社チームコード
            if (CollectionUtils.isEmpty(teishutsuHonsyaTeamCodeList)) {
                teishutsuHonsyaTeamCodeList.add("@@@@@@");
            }
            condition.put("teishutsuHonsyaTeamCode", teishutsuHonsyaTeamCodeList);
            // (提出用)支社チームコード
            if (CollectionUtils.isEmpty(teishutsuShisyaTeamCodeList)) {
                teishutsuShisyaTeamCodeList.add("@@@@@@");
            }
            condition.put("teishutsuShisyaTeamCode", teishutsuShisyaTeamCodeList);
            // (確定済)本社チームコード
            if (CollectionUtils.isEmpty(kakuteiHonsyaTeamCodeList)) {
                kakuteiHonsyaTeamCodeList.add("@@@@@@");
            }
            condition.put("kakuteiHonsyaTeamCode", kakuteiHonsyaTeamCodeList);
            // (確定済)支社チームコード
            if (CollectionUtils.isEmpty(kakuteiShisyaTeamCodeList)) {
                kakuteiShisyaTeamCodeList.add("@@@@@@");
            }
            condition.put("kakuteiShisyaTeamCode", kakuteiShisyaTeamCodeList);

            // (作成中＋提出用)本社チームコード
            if (CollectionUtils.isEmpty(geHonsyaTeamCode)) {
                geHonsyaTeamCode.add("@@@@@@");
            }
            condition.put("geHonsyaTeamCode", geHonsyaTeamCode);

            // (予算ベース用データ検索)履歴IDを指定
            if (CollectionUtils.isNotEmpty(beforeRirekiIdList)) {
                condition.put("beforeRirekiId", this.getRirekiIdString(beforeRirekiIdList));
            }

            // SELECT+FROM句まで作成
            genanSelect = sqlFile.getSqlString(splFilePath, condition);
            // SELECT+FROM句までのパラメータ
            genanSelectFromParam = sqlFile.getSqlParams(splFilePath, condition);
            
            // WHERE句作成
            Map<String, Object> whereCondition = this.getWhereParameter("", this.getGenanRirekiIdList());
            genanWhere = sqlFile.getSqlString(splFilePathWhere, whereCondition);
            genanWhereParam = sqlFile.getSqlParams(splFilePathWhere, whereCondition);
            
            genanSelect = genanSelect + " " + genanWhere;
        }
        ///////////////////////////////////////////
        // 原案テーブルを検索する場合(E)
        ///////////////////////////////////////////
        
        ///////////////////////////////////////////
        // 履歴テーブルを検索する場合(S)
        ///////////////////////////////////////////
        String rirekiSelect = "";
        Object[] rirekiSelectFromParam = null;
        String rirekiWhere = "";
        Object[] rirekiWhereParam = null;
        if (rirekiSearchFlg == 1) {
            Map<String, Object> condition = this.getBaseCondition(sortGroupCode);
            
            condition.put("rirekiId", nowRirekiIdList);
            condition.put("nowRirekiId", this.getRirekiIdString(nowRirekiIdList));
            
            // (確定)本社チームコード
            if (CollectionUtils.isEmpty(kakuteiHonsyaTeamCodeList)) {
                kakuteiHonsyaTeamCodeList.add("@@@@@@");
            }
            condition.put("honsyaTeamCode", kakuteiHonsyaTeamCodeList);
            // (確定)支社チームコード
            if (CollectionUtils.isEmpty(kakuteiShisyaTeamCodeList)) {
                kakuteiShisyaTeamCodeList.add("@@@@@@");
            }
            condition.put("shisyaTeamCode", kakuteiShisyaTeamCodeList);
            // (予算ベース用データ検索)履歴IDを指定
            if (CollectionUtils.isNotEmpty(beforeRirekiIdList)) {
                condition.put("beforeRirekiId", this.getRirekiIdString(beforeRirekiIdList));
            }

            // SELECT+FROM句まで作成
            rirekiSelect = sqlFile.getSqlString(sqlFilePathRireki, condition);
            // SELECT+FROM句までのパラメータ
            rirekiSelectFromParam = sqlFile.getSqlParams(sqlFilePathRireki, condition);
            
            // WHERE句作成
            Map<String, Object> whereCondition = this.getWhereParameter("R", nowRirekiIdList);
            rirekiWhere = sqlFile.getSqlString(splFilePathWhere, whereCondition);
            rirekiWhereParam = sqlFile.getSqlParams(splFilePathWhere, whereCondition);
            
            rirekiSelect = rirekiSelect + " " + rirekiWhere;
        }
        
        ////////////// ORDER BY句を取得(S) ////////////////////
        String orderBy = this.getSelectOrderBy();
        ////////////// ORDER BY句を取得(E) ////////////////////
        
        ////////////// 実行するSELECT文を作成(S) ////////////////////
        String executeSql = "SELECT A.* FROM ( #genanSelect# #UNIONALL# #rirekiSelect# ) A #ORDERBY#";
        int selectCount = 0;
        // 実行SQLを作成(原案)
        String changeGenanSelect = "";
        if (StringUtils.isNotEmpty(genanSelect)) {
            changeGenanSelect = genanSelect;
            selectCount++;
        }
        executeSql = StringUtils.replace(executeSql, "#genanSelect#", changeGenanSelect);
        // 実行SQLを作成(履歴)
        String changeRirekiSelect = "";
        if (StringUtils.isNotEmpty(rirekiSelect)) {
            changeRirekiSelect = rirekiSelect;
            selectCount++;
        }
        executeSql = StringUtils.replace(executeSql, "#rirekiSelect#", changeRirekiSelect);
        // 原案と履歴を両方検索する場合、UNION ALLする
        //   ※このケースは一部チームコードの確定(支社確定＋本社未確定)の場合に発生
        String changeUnionAll = "";
        if (selectCount == 2) {
            changeUnionAll = "UNION ALL";
            executeSql = StringUtils.replace(executeSql, "#UNIONALL#", "UNION ALL");
        }
        executeSql = StringUtils.replace(executeSql, "#UNIONALL#", changeUnionAll);
        // ORDER BY句を付加
        executeSql = StringUtils.replace(executeSql, "#ORDERBY#", orderBy);
        ////////////// 実行するSELECT文を作成(E) ////////////////////

        ///////// パラメータ設定(S) ////////
        // 実行するSQL文のパラメータを作成(SELECT+FROM句と、WHERE句のパラメータを統合する)
        List<Object> executeSqlParamsList = new ArrayList<>();
        if (genanSelectFromParam != null) {
            executeSqlParamsList.addAll(Arrays.asList(genanSelectFromParam));
        }
        if (genanWhereParam != null) {
            executeSqlParamsList.addAll(Arrays.asList(genanWhereParam));
        }
        if (rirekiSelectFromParam != null) {
            executeSqlParamsList.addAll(Arrays.asList(rirekiSelectFromParam));
        }
        if (rirekiWhereParam != null) {
            executeSqlParamsList.addAll(Arrays.asList(rirekiWhereParam));
        }
        Object[] executeSqlParams = (Object[])executeSqlParamsList.toArray(new Object[executeSqlParamsList.size()]);
        ///////// パラメータ設定(E) ////////
        
        // SQLを実行(Commons DbUtilで実行)
        List<Map<String, Object>> list = dbUtilsExecutor.dbUtilsGetSqlList(em, executeSql, executeSqlParams);
        return list;
    }

    /**
     * SQL文を実行(受注売上見込一覧から出力する場合)
     */
    private List<Map<String, Object>> findAnkenList(SyuWfControlTbl groupInfo, List<SyuWfControlTbl> targetTeamList) throws Exception {
        logger.info("[SummaryListService#findAnkenList]");
        SqlFile sqlFile = new SqlFile();

        Map<String, Object> wfControlCondition = this.getWfControlCondition();

        String rirekiFlg = "";
        String baseYm = this.getBaseYm();
        //Integer monthryKakuteiFlg = this.monthyKakuteiFlg();

        // 指定する履歴ID、(本社/支社)チームコードを取得
        List<Object> nowRirekiIdList = new ArrayList<>();      // 履歴id
        Integer geNowRirekiId = new Integer(ConstantString.geRirekiId);   // 原案テーブルを参照する履歴ID

        //boolean isRirekiId = true;
        List<String> honsyaTeamCodeList = new ArrayList<>();   // 本社チームコード
        List<String> shisyaTeamCodeList = new ArrayList<>();   // 支社チームコード

        StringBuilder sortGroupCode = new StringBuilder();

        for (SyuWfControlTbl wfControlTeamInfo : targetTeamList) {
            String honsyaShisyaKbn = wfControlTeamInfo.getHonsyaShisyaKbn();
            String teamCode = "";
            
            if (StringUtils.trimToNull(wfControlTeamInfo.getTeamCode()) != null) {
                if ("H".equals(honsyaShisyaKbn)) {
                    // 本社チームコード
                    honsyaTeamCodeList.add(wfControlTeamInfo.getTeamCode());
                    teamCode = wfControlTeamInfo.getTeamCode();
                } else if ("S".equals(honsyaShisyaKbn)) {
                    // 支社チームコード
                    shisyaTeamCodeList.add(wfControlTeamInfo.getTeamCode());
                    teamCode = wfControlTeamInfo.getTeamCode();
                }
            }
            
            // 履歴ID
            Long rirekiId = wfControlTeamInfo.getRirekiId();
            String status = wfControlTeamInfo.getStatus();
            if (ConstantString.wfStatusKakutei.equals(status)) {
                // 確定済のチームコードは、その履歴idを検索対象とする。
                nowRirekiIdList.add(rirekiId);
            }
            
            // SQL実行時に、チームコードに該当するC_BUKA_CODEを取得できるようにしておく(ソート順で利用)
            if (StringUtils.isNotEmpty(wfControlTeamInfo.getcBukaCode()) && StringUtils.isNotEmpty(teamCode)) {
                sortGroupCode.append("WHEN TEAM_CODE = '")
                        .append(EscapeUtils.escapeSql(teamCode))
                        .append("' THEN '")
                        .append(EscapeUtils.escapeSql(wfControlTeamInfo.getcBukaCode()))
                        .append("' ");
            }
        }
        
        rirekiFlg = s001Bean.getRirekiFlg();
        if (!"R".equals(rirekiFlg)) {
            // 原案テーブル(_Rがつかないテーブル)を検索する場合、履歴idは0(最新)固定
            nowRirekiIdList = new ArrayList();
            nowRirekiIdList.add(new Integer(ConstantString.geRirekiId));
        }

        // ここまでで履歴ID(今回)が取得できない場合、該当データ存在しないので検索しない
        if (CollectionUtils.isEmpty(nowRirekiIdList)) {
            return null;
        }
        
        // 履歴ID(予算ベース)
        //   表示対象期(YYYY + K or S)の予算ベース履歴ID群をSYU_WF_CONTROL_TBLから取得する。
        //   この履歴IDを使用して、各月予算ベース確定のSP,NETを取得する。
        List<Object> beforeRirekiIdList = new ArrayList<>();
        List<SyuWfControlTbl> yosanRirekiIdList = this.findTeamList(groupInfo, "Y");
        if (CollectionUtils.isNotEmpty(yosanRirekiIdList)) {
            for (SyuWfControlTbl yosanRirekiIdEntity : yosanRirekiIdList) {
                beforeRirekiIdList.add(yosanRirekiIdEntity.getRirekiId());
            }
        }

        logger.info("[SummaryListService#findAnkenList] rirekiId=[{}], yosanRirekiId=[{}]",  nowRirekiIdList, beforeRirekiIdList);

        ///////////////////////////////////////////////////////
        ////////////// SELECT句、FROM句作成(S) /////////////////
        ///////////////////////////////////////////////////////
        String splFilePath = "";
        if ("J".equals(s001Bean.getTenkaiKbn())) {
            // 「出力時オプション選択」ダイアログ [展開]で、"受注"を選択
            if ("R".equals(rirekiFlg)) {
                // 月次確定/予算ベースのデータを出力
                splFilePath = "/sql/download/summaryListJyuchuRireki.sql";
            } else {
                // "原案"のデータを取得
                splFilePath = "/sql/download/summaryListJyuchu.sql";
            }
           
        } else {
            // 「出力時オプション選択」ダイアログ [展開]で、"売上"を選択
            if ("R".equals(rirekiFlg)) {
                // 月次確定/予算ベースのデータを出力
                splFilePath = "/sql/download/summaryListUriageRireki.sql";
            } else {
                // "原案"のデータを取得
                splFilePath = "/sql/download/summaryListUriage.sql";
            }

        }
        logger.info("[findSummaryList] SQL_FILE=[{}]", splFilePath);
        
        Map<String, Object> condition = this.getBaseCondition(sortGroupCode);
        condition.put("geNowRirekiId", geNowRirekiId);
        // 本社チームコード
        if (CollectionUtils.isEmpty(honsyaTeamCodeList)) {
            honsyaTeamCodeList.add("@@@@@@");
        }
        condition.put("honsyaTeamCode", honsyaTeamCodeList);
        // 支社チームコード
        if (CollectionUtils.isEmpty(shisyaTeamCodeList)) {
            shisyaTeamCodeList.add("@@@@@@");
        }
        condition.put("shisyaTeamCode", shisyaTeamCodeList);
        // (作成中＋提出用)本社チームコード  ※案件一覧からの出力は提出用データは出力しないため、ここでは本社チームコードと同じものをセット
        condition.put("geHonsyaTeamCode", honsyaTeamCodeList);

        // (提出用)本社チームコード   ※ここでは利用しないがSQLでパラメータ利用しているのでありえない固定値を設定しておく
        ArrayList teishutsuHonsyaTeamCodeList = new ArrayList();
        teishutsuHonsyaTeamCodeList.add("@@@@@@");
        condition.put("teishutsuHonsyaTeamCode", teishutsuHonsyaTeamCodeList);
        // (提出用)支社チームコード   ※ここでは利用しないがSQLでパラメータ利用しているのでありえない固定値を設定しておく
        ArrayList teishutsuShisyaTeamCodeList = new ArrayList();
        teishutsuShisyaTeamCodeList.add("@@@@@@");
        condition.put("teishutsuShisyaTeamCode", teishutsuShisyaTeamCodeList);
        // (確定用)本社チームコード   ※ここでは利用しないがSQLでパラメータ利用しているのでありえない固定値を設定しておく
        ArrayList kakuteiHonsyaTeamCodeList = new ArrayList();
        kakuteiHonsyaTeamCodeList.add("@@@@@@");
        condition.put("kakuteiHonsyaTeamCode", kakuteiHonsyaTeamCodeList);
        // (確定用)支社チームコード   ※ここでは利用しないがSQLでパラメータ利用しているのでありえない固定値を設定しておく
        ArrayList kakuteiShisyaTeamCodeList = new ArrayList();
        kakuteiShisyaTeamCodeList.add("@@@@@@");
        condition.put("kakuteiShisyaTeamCode", kakuteiShisyaTeamCodeList);

        condition.put("rirekiFlg", rirekiFlg);
        condition.put("rirekiId", nowRirekiIdList);
        condition.put("nowRirekiId", this.getRirekiIdString(nowRirekiIdList));
        if (CollectionUtils.isNotEmpty(beforeRirekiIdList)) {
            condition.put("beforeRirekiId", this.getRirekiIdString(beforeRirekiIdList));
        }

        // SELECT+FROM句まで作成
        String sqlSelectFrom = sqlFile.getSqlString(splFilePath, condition);
        // SELECT+FROM句までのパラメータ
        Object[] params = sqlFile.getSqlParams(splFilePath, condition);
        ///////////////////////////////////////////////////////
        ////////////// SELECT句、FROM句作成(E) /////////////////
        ///////////////////////////////////////////////////////

        ///////////////////////////////////////////////////////
        ////////////// WHERE句作成(S) /////////////////////////
        ///////////////////////////////////////////////////////
        // WHERE句とWHERE句に指定するパラメータを取得
        // (selectListSyuueki.sqlからWHERE句と、そこに指定するパラメータのみ取得)
        splFilePath = "/sql/selectListSyuueki.sql";
        // WHERE句に指定するパラメータを取得
        Map<String, Object> conditionWhere = s001Service.getCondition();

        conditionWhere.put("divisionCode", wfControlCondition.get("divisionCode"));
        conditionWhere.put("salesClass", wfControlCondition.get("salesClass"));
        conditionWhere.put("kanjyoYm", baseYm);
        conditionWhere.put("rirekiFlg", rirekiFlg);
        conditionWhere.put("rirekiId", nowRirekiIdList);
        conditionWhere.put("syuekiControlKbn", "1");
        conditionWhere.put("whereOnlyFlg", "1");      // WHERE句のみ抜き出すFLG(SQL文内でこの条件でWHERE句のみ取得できるようにした)

        String whereString = sqlFile.getSqlString(splFilePath, conditionWhere);
        Object[] whereParams = sqlFile.getSqlParams(splFilePath, conditionWhere);
        ///////////////////////////////////////////////////////
        ////////////// WHERE句作成(E) /////////////////////////
        ///////////////////////////////////////////////////////

        ////////////// ORDER BY句を取得(S) ////////////////////
        String orderBy = this.getSelectOrderBy();
        ////////////// ORDER BY句を取得(E) ////////////////////
        
        ///////////////////////////////////////////////////////
        ////////////// 実行するSQL文を取得(S) //////////////////
        ///////////////////////////////////////////////////////
        // WHERE句を固定文字列#where#に変換(後ほどselectListSyuueki.sqlから抜き出したWHERE句に置換する)
        //String executeSql = StringUtils.replace(sqlSelectFrom, "#where#", whereString);
        String executeSql = sqlSelectFrom + " " + whereString + " " + orderBy;

        // 実行するSQL文のパラメータを作成(SELECT+FROM句と、WHERE句のパラメータを統合する)
        List<Object> executeSqlParamsList = Arrays.asList(params);
        executeSqlParamsList = new ArrayList<>(executeSqlParamsList);
        executeSqlParamsList.addAll(Arrays.asList(whereParams));
        Object[] executeSqlParams = (Object[])executeSqlParamsList.toArray(new Object[executeSqlParamsList.size()]);
        ///////////////////////////////////////////////////////
        ////////////// 実行するSQL文を取得(E) //////////////////
        ///////////////////////////////////////////////////////
        
        // SQLを実行(Commons DbUtilで実行)
        List<Map<String, Object>> list = dbUtilsExecutor.dbUtilsGetSqlList(em, executeSql, executeSqlParams);
        return list;
    }

    /**
     * 履歴idをカンマ区切りの文字列に変換
     */
    private String getRirekiIdString(List<Object> rirekiIdList) {
        if (rirekiIdList == null || rirekiIdList.isEmpty()) {
            return null;
        }
        
        boolean isFirst = true;
        StringBuilder rirekiIdString = new StringBuilder();
        for (Object rirekiId : rirekiIdList) {
            if (!isFirst) {
                rirekiIdString.append(",");
            }
            rirekiIdString.append(String.valueOf(rirekiId));
            isFirst = false;
        }
        
        return String.valueOf(rirekiIdString);
    }
    
    /**
     * 計算式を実行
     */
    private void exeFormulaSheet(Workbook workbook) {
        Sheet dataSheet = workbook.getSheet(SHEETNAME);
        dataSheet.setForceFormulaRecalculation(true);
    }
    
    /**
     * SetよりExcel計算式(足し算)を取得
     */
    private String getExcelPlusRowFormula(Set<Integer> formulaIndexRowList, int cellIndex, int shiftRowIndex) {
        String formulaString = "";
        for (Integer index: formulaIndexRowList) {
            Integer rowIndex = index + shiftRowIndex;
            if (StringUtils.isEmpty(formulaString)) {
                formulaString = PoiUtil.getCellReferenceStr(rowIndex, cellIndex);
            } else {
                formulaString = formulaString + "," + PoiUtil.getCellReferenceStr(rowIndex, cellIndex);
            }
        }
        if (StringUtils.isNotEmpty(formulaString)) {
            formulaString = "SUM(" + formulaString + ")";
        }
        return formulaString;
    }
    
    /**
     * 合計行は計算式出力か？
     */
    private boolean isSummaryCalc() {
        return ("1".equals(s001Bean.getOptionSummaryKbn()));
    }
}
