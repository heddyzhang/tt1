package jp.co.toshiba.hby.pspromis.syuueki.entity;

import java.io.Serializable;
import java.math.BigInteger;
import java.util.Date;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.NotNull;
/**
 *
 * @author ibayashi
 */
@Entity
@Table(name = "M0130_BUNRUI_ORG")
public class M0130BunruiOrg implements Serializable {
    private static final long serialVersionUID = 1L;
    @Id
    @Basic(optional = false)
    @NotNull
    @Column(name = "BUNRUI_CD")
    private String bunruiCd;
    @Column(name = "BU_CD")
    private String buCd;
    @Column(name = "BUNRUI_NM")
    private String bunruiNm;
    @Column(name = "DEL_FLG")
    private Short delFlg;
    @Column(name = "UPDATE_ID")
    private String updateId;
    @Column(name = "UPDATE_DT")
    @Temporal(TemporalType.TIMESTAMP)
    private Date updateDt;
    @Column(name = "TEIKEN_FLG")
    private String teikenFlg;
    @Column(name = "PLANT_SUM_FLG")
    private String plantSumFlg;
    @Column(name = "BUNRUI_SORT")
    private BigInteger bunruiSort;

    public M0130BunruiOrg() {
    }

    public M0130BunruiOrg(String bunruiCd) {
        this.bunruiCd = bunruiCd;
    }

    public String getBunruiCd() {
        return bunruiCd;
    }

    public void setBunruiCd(String bunruiCd) {
        this.bunruiCd = bunruiCd;
    }

    public String getBuCd() {
        return buCd;
    }

    public void setBuCd(String buCd) {
        this.buCd = buCd;
    }

    public String getBunruiNm() {
        return bunruiNm;
    }

    public void setBunruiNm(String bunruiNm) {
        this.bunruiNm = bunruiNm;
    }

    public Short getDelFlg() {
        return delFlg;
    }

    public void setDelFlg(Short delFlg) {
        this.delFlg = delFlg;
    }

    public String getUpdateId() {
        return updateId;
    }

    public void setUpdateId(String updateId) {
        this.updateId = updateId;
    }

    public Date getUpdateDt() {
        return updateDt;
    }

    public void setUpdateDt(Date updateDt) {
        this.updateDt = updateDt;
    }

    public String getTeikenFlg() {
        return teikenFlg;
    }

    public void setTeikenFlg(String teikenFlg) {
        this.teikenFlg = teikenFlg;
    }

    public String getPlantSumFlg() {
        return plantSumFlg;
    }

    public void setPlantSumFlg(String plantSumFlg) {
        this.plantSumFlg = plantSumFlg;
    }

    public BigInteger getBunruiSort() {
        return bunruiSort;
    }

    public void setBunruiSort(BigInteger bunruiSort) {
        this.bunruiSort = bunruiSort;
    }
}
