package jp.co.toshiba.hby.pspromis.syuueki.facade;

import java.util.List;
import javax.ejb.Stateless;
import javax.interceptor.Interceptors;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import jp.co.toshiba.hby.pspromis.syuueki.entity.SyuInfoMessageMst;
import jp.co.toshiba.hby.pspromis.syuueki.interceptor.TranceInterceptor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 *
 * @author watabe
 */
@Stateless
@Interceptors({TranceInterceptor.class})
public class SyuInfoMessageMstFacade extends AbstractFacade<SyuInfoMessageMst> {

    /**
     * ロガ－
     */
    private static final Logger logger = LoggerFactory.getLogger(SyuInfoMessageMstFacade.class);

    @PersistenceContext(unitName = jp.co.toshiba.hby.pspromis.syuueki.util.ConstantString.syuuekiDataSourceName)
    private EntityManager em;
    
    public SyuInfoMessageMstFacade() {
        super(SyuInfoMessageMst.class);
    }

    @Override
    protected EntityManager getEntityManager() {
        return em;
    }
    
    public List getMessageData(){

        List<SyuInfoMessageMst> list = sqlExecutor.getResultList(em, SyuInfoMessageMst.class, "/sql/syuInfoMessageMst/selectUpdateInformation.sql", null);
        
        return list;
    }
    
}
