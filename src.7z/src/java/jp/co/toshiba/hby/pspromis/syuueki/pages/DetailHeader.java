package jp.co.toshiba.hby.pspromis.syuueki.pages;

import java.io.Serializable;
import java.math.BigInteger;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.enterprise.context.RequestScoped;
import javax.inject.Inject;
import javax.inject.Named;
import jp.co.toshiba.hby.pspromis.common.exception.PspRunTimeExceotion;
import jp.co.toshiba.hby.pspromis.common.util.StringUtil;
import jp.co.toshiba.hby.pspromis.syuueki.entity.SyuBatchLog;
import jp.co.toshiba.hby.pspromis.syuueki.entity.SyuGeBukkenInfoTbl;
import jp.co.toshiba.hby.pspromis.syuueki.entity.SyuGeRirekiInfoTbl;
import jp.co.toshiba.hby.pspromis.syuueki.enums.Label;
import jp.co.toshiba.hby.pspromis.syuueki.facade.JgrpMemberTblFacade;
import jp.co.toshiba.hby.pspromis.syuueki.facade.KanjyoMstFacade;
import jp.co.toshiba.hby.pspromis.syuueki.facade.SyokusyuEntityFacade;
import jp.co.toshiba.hby.pspromis.syuueki.facade.SyuBatchLogFacade;
import jp.co.toshiba.hby.pspromis.syuueki.facade.SyuGeBukenInfoTblFacade;
import jp.co.toshiba.hby.pspromis.syuueki.facade.SyuGeRirekiInfoTblFacade;
import jp.co.toshiba.hby.pspromis.syuueki.service.UriageRangeService;
import jp.co.toshiba.hby.pspromis.syuueki.service.SyuuekiCommonService;
//import jp.co.toshiba.hby.pspromis.syuueki.util.AuthorityCheck;
import jp.co.toshiba.hby.pspromis.syuueki.util.ConstantString;
import jp.co.toshiba.hby.pspromis.syuueki.util.LoginUserInfo;
import jp.co.toshiba.hby.pspromis.syuueki.util.SyuuekiUtils;
import jp.co.toshiba.hby.pspromis.syuueki.util.Utils;
import jp.co.toshiba.hby.pspromis.syuueki.exception.NoSyuekiFlgException;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.time.DateUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * PS-Promis収益管理システム 物件詳細情報検索
 *
 * @author (NPC)S.Ibayashi
 */
@Named(value = "detailHeader")
@RequestScoped
public class DetailHeader implements Serializable {

    private static final long serialVersionUID = 1L;

    private static final Logger logger = LoggerFactory.getLogger(DetailHeader.class);

    @Inject
    private SyuGeBukenInfoTblFacade syuGeBukenInfoTblFacade;

    @Inject
    private SyuGeRirekiInfoTblFacade syuGeRirekiInfoTblFacade;

    @Inject
    private JgrpMemberTblFacade jgrpMemberTblFacade;

    @Inject
    private SyokusyuEntityFacade syokusyuEntityFacade;

    @Inject
    private KanjyoMstFacade kanjyoMstFacade;

    @Inject
    private SyuBatchLogFacade syuBatchLogFacade;

    @Inject
    private LoginUserInfo loginUserInfo;

    @Inject
    private UriageRangeService uriageRangeService;
    
    @Inject
    private SyuuekiCommonService syuuekiCommonService;

    @Inject
    private SyuuekiUtils syuuekiUtils;

    @Inject
    private Utils utils;

    /**
     * 画面id
     */
    private String id;

    /**
     * 物件key
     */
    private String ankenId;

    /**
     * 履歴id
     */
    private String rirekiId = "0";

    /**
     * 前回履歴Id
     */
    private String zenkaiId;

    /**
     * 履歴FLG
     */
    private String rirekiFlg;

    /**
     * 収益物件情報entity
     */
    private SyuGeBukkenInfoTbl ankenEntity;

    /**
     * 見積番号(複数あるためカンマ区切り)
     */
    private String mitumoriNo;

    /**
     * 営業担当JobGr(複数あるためカンマ区切り)
     */
    private String eigyoTanJobGrName;

    /**
     * 原価/バック営業担当JobGr(複数あるためカンマ区切り)
     */
    private String genkaTanJobGrName;

    /**
     * 履歴表示名(最新/前回/履歴)
     */
    private String rirekiDispName;

    /**
     * 履歴タイトル
     */
    private String rirekiTitle;

    /**
     * 確定日
     */
    private Date fixedDate;

    /**
     * 確定者
     */
    private String fixedByName;

    /**
     * 備考
     */
    private String biko;

    /**
     * 備考表示FLG
     */
    private Boolean isBikoFlg = false;

    /**
     * 勘定月
     */
    private Date kanjoDate;

    /**
     * 実績更新日時
     */
    private Date jissekiUpdateDate;

    /**
     * 4半期(Q)表示FLG
     */
    private String quarterDispFlg;

    /**
     * 期間損益画面の累計表示FLG
     */
    private String maeruikeiDispFlg;

    /**
     * 完売FLG(2:完売 1:売上中 0:未売上)
     */
    private String uriageEndFlg;

    /**
     * 案件まとめFLG(0:一般 1:まとめ案件)
     */
    private String ankenFlg;

    /**
     * 編集FLG(1:編集 0:参照)
     */
    private String editFlg;

    /**
     * 案件の期間が正常かを判定するFLG 0:正常 9:案件の開始年月>終了年月の場合
     */
    private int uriageRangeNormalFlg = 0;

    /**
     * 白地調整案件FLG(1:白地案件 0:通常案件)
     */
    private String shirajiFlg = "0";

    /**
     * 削除FLG(0:通常 2:白地案件取消)
     */
    private String deleteFlg = "0";

    /**
     * 最終見込への発番情報自動反映(SP/NET) (する:1 しない:0)
     */
    private String hatLinkSpNetFlg = "0";

    /**
     * ポテンシャル管理要（不要:0　要:1）
     */
    private String potentialFlg = "0";

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getAnkenId() {
        return ankenId;
    }

    public void setAnkenId(String ankenId) {
        this.ankenId = ankenId;
    }

    public String getRirekiId() {
        return rirekiId;
    }

    public void setRirekiId(String rirekiId) {
        if (StringUtils.isNumeric(rirekiId)) {
            this.rirekiId = rirekiId;
        }
    }

    public SyuGeBukkenInfoTbl getAnkenEntity() {
        return ankenEntity;
    }

    public void setAnkenEntity(SyuGeBukkenInfoTbl ankenEntity) {
        this.ankenEntity = ankenEntity;
    }

    public String getMitumoriNo() {
        return mitumoriNo;
    }

    public void setMitumoriNo(String mitumoriNo) {
        this.mitumoriNo = mitumoriNo;
    }

    public Date getKanjoDate() {
        return kanjoDate;
    }

    public void setKanjoDate(Date kanjoDate) {
        this.kanjoDate = kanjoDate;
    }

    public String getRirekiDispName() {
        return rirekiDispName;
    }

    public void setRirekiDispName(String rirekiDispName) {
        this.rirekiDispName = rirekiDispName;
    }

    public String getRirekiTitle() {
        return rirekiTitle;
    }

    public void setRirekiTitle(String rirekiTitle) {
        this.rirekiTitle = rirekiTitle;
    }

    public Date getFixedDate() {
        return fixedDate;
    }

    public void setFixedDate(Date fixedDate) {
        this.fixedDate = fixedDate;
    }

    public String getFixedByName() {
        return fixedByName;
    }

    public void setFixedByName(String fixedByName) {
        this.fixedByName = fixedByName;
    }

    public String getRirekiFlg() {
        return rirekiFlg;
    }

    public void setRirekiFlg(String rirekiFlg) {
        this.rirekiFlg = rirekiFlg;
    }

    public String getBiko() {
        return biko;
    }

    public void setBiko(String biko) {
        this.biko = biko;
    }

    public Boolean isIsBikoFlg() {
        return isBikoFlg;
    }

    public void setIsBikoFlg(Boolean isBikoFlg) {
        this.isBikoFlg = isBikoFlg;
    }

    public String getEigyoTanJobGrName() {
        return eigyoTanJobGrName;
    }

    public void setEigyoTanJobGrName(String eigyoTanJobGrName) {
        this.eigyoTanJobGrName = eigyoTanJobGrName;
    }

    public String getGenkaTanJobGrName() {
        return genkaTanJobGrName;
    }

    public void setGenkaTanJobGrName(String genkaTanJobGrName) {
        this.genkaTanJobGrName = genkaTanJobGrName;
    }

    public Date getJissekiUpdateDate() {
        return jissekiUpdateDate;
    }

    public void setJissekiUpdateDate(Date jissekiUpdateDate) {
        this.jissekiUpdateDate = jissekiUpdateDate;
    }

    public String getShirajiFlg() {
        return shirajiFlg;
    }

    public void setShirajiFlg(String shirajiFlg) {
        this.shirajiFlg = shirajiFlg;
    }

    public String getDeleteFlg() {
        return deleteFlg;
    }

    public void setDeleteFlg(String deleteFlg) {
        this.deleteFlg = deleteFlg;
    }

    public String getPotentialFlg() {
        return potentialFlg;
    }

    public void setPotentialFlg(String potentialFlg) {
        this.potentialFlg = potentialFlg;
    }

    /**
     * ロスコン対象かどうかをチェック
     */
    public boolean isLossControlFlag() {
        if (ConstantString.lossControlTargetFlg.equals(ankenEntity.getLossControlFlag())) {
            return true;
        }
        return false;
    }

    /**
     * 収益物件参照の権限チェック
     *
     * @return
     */
    private void checkAuthority(Object condition) {
        String divisionCode = ankenEntity.getDivisionCode();
        Integer ret = syokusyuEntityFacade.getSyokusyuRole(condition);
        // 収益物件参照の権限チェックを行う。
        if (!syuuekiCommonService.isDivisionAnkenViewOk(divisionCode) && ret == 0) {
            // 職種権限がなければエラーとする。
            String errorMessage = Label.getValue(Label.errorNoAnkenAuthority);
            logger.error(errorMessage);
            throw new PspRunTimeExceotion(errorMessage);
        }
//        String[] syokusyuAry = loginUserInfo.getJobGrSyokusyuArrayInfo("syokusyuCd");
//        Integer ret = syokusyuEntityFacade.getSyokusyuRole(condition);
//        if (!AuthorityCheck.isSyokushu(syokusyuAry) && ret == 0) {
//            // 職種権限がなければエラーとする。
//            String errorMessage = Label.getValue(Label.errorNoAnkenAuthority);
//            logger.error(errorMessage);
//            throw new PspRunTimeExceotion(errorMessage);
//        }
    }

    /**
     * 案件情報取得のためのキー情報Mapを作成
     *
     * @return
     */
    public Map<String, Object> getBasePkCondition() {
        Map<String, Object> condition = new HashMap<>();
        condition.put("ankenId", ankenId);

        if (StringUtil.isEmpty(rirekiId)) {
            rirekiId = "0";
        }
        condition.put("rirekiId", new BigInteger(rirekiId).intValue());

        if (StringUtil.isEmpty(rirekiFlg)) {
            rirekiFlg = "";
        }
        condition.put("rirekiFlg", rirekiFlg);

        return condition;
    }

    /**
     * 案件情報取得のためのキー情報Mapを作成
     *
     * @return
     */
    public Map<String, Object> getPkCondition() {
        Map<String, Object> condition = getBasePkCondition();

        List<String> memberJobGrList
                = jgrpMemberTblFacade.getMemberJobGrList(loginUserInfo.getUserId());
        condition.put("memberJobGr", memberJobGrList);

        return condition;
    }

    /**
     * 収益物件情報を取得
     */
    public void findAnkenPk() {
        Map<String, Object> condition = getPkCondition();

        // 対象案件をentityにセット
        ankenEntity = syuGeBukenInfoTblFacade.findPk(condition);
        if (ankenEntity == null || StringUtil.isEmpty(ankenEntity.getAnkenId())) {
            // 案件情報が見つからない場合はエラーとする。
            String errorMessage = Label.getValue(Label.errorNoAnkenDate);
            logger.error(errorMessage + " ankenId=" + ankenId + " rirekiId=" + rirekiId + " rirekiFlg=" + rirekiFlg);
            throw new PspRunTimeExceotion(errorMessage);
        }

        // 4半期表示FLGをセット
        quarterDispFlg = StringUtils.defaultString(ankenEntity.getQuarterDispFlg(), "0");

        // 期間損益画面の累計表示FLGをセット
        maeruikeiDispFlg = StringUtils.defaultString(ankenEntity.getMaeruikeiDispFlg(), "0");

        // 完売FLGをセット
        uriageEndFlg = StringUtils.defaultString(ankenEntity.getUriageEndFlg(), "0");

        // 案件纏めFLGをセット
        ankenFlg = StringUtils.defaultString(ankenEntity.getAnkenFlg(), "0");

        // 白地調整案件FLGをセット
        shirajiFlg = StringUtils.defaultString(ankenEntity.getShirajiFlg(), "0");

        // 削除FLGをセット
        deleteFlg = StringUtils.defaultString(ankenEntity.getIsDeleted(), "0");

        // 最終見込への発番情報自動反映(SP/NET)をセット
        hatLinkSpNetFlg = StringUtils.defaultString(ankenEntity.getHatlinkSpnetFlg(), "0");

        // 前回(履歴)IDをセット(履歴IDが0(原案)以外の場合)
        if (!ConstantString.geRirekiId.equals(StringUtils.defaultString(String.valueOf(ankenEntity.getZenkaiId()), ConstantString.geRirekiId))) {
            zenkaiId = String.valueOf(ankenEntity.getZenkaiId());
        }

        // ポテンシャル管理をセット
        potentialFlg = StringUtils.defaultString(ankenEntity.getPotentialFlg(), "0");

        // 勘定月の取得
        findoKanjoDate();
    }

    /**
     * 対象案件の参照権限チェック 参照できない場合はエラーメッセージを返す
     */
    private String checkAuthAnkenDisp() {
        String errorMessage = "";

        String[] loginDivisions = loginUserInfo.getJobGrSyokusyuArrayInfo("division");
        String[] loginsSyokusyus = loginUserInfo.getJobGrSyokusyuArrayInfo("syokusyuCd");

        logger.info("checkAuthAnkenDisp ankenId=[{}] rirekiId=[{}] rirekiFlg=[{}] loginDivisions={} loginsSyokusyus={}", ankenId, rirekiId, rirekiFlg, loginDivisions, loginsSyokusyus);
        logger.info("checkAuthAnkenDisp syuekiFlg=[{}] divisionCode=[{}] isDeleted=[{}]", ankenEntity.getSyuekiFlg(), ankenEntity.getDivisionCode(), ankenEntity.getIsDeleted());

        // ユーザーの所属事業部外の案件は参照不可
        if (!utils.isArrayValue(ankenEntity.getDivisionCode(), loginDivisions)) {
            logger.info("Anken Disp No Auth Diff Division");
            errorMessage = Label.errorNoAnkenDate.getLabel();
            return errorMessage;
        }
        // 削除済案件は参照不可(白地取り消し(2)は参照OK)
        if (!("0".equals(ankenEntity.getIsDeleted()) || "2".equals(ankenEntity.getIsDeleted()))) {
            logger.info("Anken Disp is Deleted");
            errorMessage = Label.errorNoAnkenDate.getLabel();
            return errorMessage;
        }
        // 収益対象外の案件の参照は不可
        if (!"1".equals(ankenEntity.getSyuekiFlg())) {
            logger.info("Anken Disp No Auth SyuekiFlg");
            errorMessage = "NO_SYUEKI_FLG";
            return errorMessage;
        }
//        // ユーザーの所属事業部外の案件は参照不可
//        if (!utils.isArrayValue(ankenEntity.getDivisionCode(), loginDivisions)) {
//            logger.info("Anken Disp No Auth Diff Division");
//            errorMessage = Label.errorNoAnkenDate.getLabel();
//            return errorMessage;
//        }

        return errorMessage;
    }

    /**
     * 収益物件情報を取得
     */
    public void findPk() {
        // 対象案件をentityにセット
        findAnkenPk();

        // 収益物件参照の権限チェックを行う。
        Map<String, Object> condition = getPkCondition();
        checkAuthority(condition);

        // ログイン者が対象案件を参照可能であるか権限チェック。参照できない場合はエラーにする
        String errorMessage = checkAuthAnkenDisp();
        if (StringUtils.isNotEmpty(errorMessage)) {
            if (errorMessage.equals("NO_SYUEKI_FLG")) {
                // (2018A)収益対象外の場合は同一注番の別案件のリンク画面へ飛ばす
                throw new NoSyuekiFlgException(StringUtils.defaultString(ankenEntity.getOrderNo()));
            } else {
                logger.error(errorMessage + " ankenId=" + ankenId + " rirekiId=" + rirekiId + " rirekiFlg=" + rirekiFlg);
                throw new PspRunTimeExceotion(errorMessage);
            }
        }
        
        // 対象物件の見積番号を取得
        condition.put("ankenFlg", ankenEntity.getAnkenFlg());
        mitumoriNo = syuGeBukenInfoTblFacade.findMitumoriNo(condition);

        // 対象物件の営業担当JobGrを取得
        eigyoTanJobGrName = syuGeBukenInfoTblFacade.findSyokusyuJobGrName(ankenEntity.getAnkenId(), "L");

        // 対象物件の原価/バック営業担当JobGrを取得
        genkaTanJobGrName = syuGeBukenInfoTblFacade.findSyokusyuJobGrName(ankenEntity.getAnkenId(), "M");

        // 備考の取得
        if (ankenEntity != null) {
            if ("S002".equals(id)) {
                // 最終見込損益画面の表示
                biko = ankenEntity.getBikouFixedMikomi();
                isBikoFlg = true;
            } else if ("S003".equals(id) || "S004".equals(id)) {
                // 期間損益画面の表示
                biko = ankenEntity.getBikouKikan();
                isBikoFlg = true;
            }
        }

        // 履歴情報を取得
        findRireki();

        // 実績更新日時を取得
        findJissekiUpdateDate();
    }

    /**
     * 勘定月の取得
     */
    private void findoKanjoDate() {
        boolean isKanjyo = true;
        String kanjoYm = "";

        try {
            // 勘定月の取得
            if (!"R".equals(rirekiFlg)) {
                //// 履歴以外(原稿データ取得)
                // システム日付を勘定月とする(Step3.一般案件/進行基準案件で勘定月の管理が異なるため、参照先マスタを切り替える)
                // kanjoDate = sysdateEntityFacade.getSysdate();
                kanjoYm = kanjyoMstFacade.getNowKanjoDate(ankenEntity.getSalesClass());
            } else {
                //// 履歴表示時
                // 収益物件履歴テーブルより勘定月を取得(日付に変換できなかった場合はエラーにはせずにログファイルに吐き出す)
                kanjoYm = ankenEntity.getKanjoYm();
            }

            kanjoDate = Utils.parseDate(kanjoYm);
            if (kanjoDate == null) {
                isKanjyo = false;
            }

        } catch (ParseException pe) {
            logger.error("error parse kanjo date ankenId=" + ankenId + " rirekiId=" + rirekiId
                    + " rirekiFlg=" + rirekiFlg + " kanjoDate=" + ankenEntity.getKanjoYm(), pe);
            isKanjyo = false;
        }

        if (!isKanjyo) {
            String errorMessage = Label.getValue(Label.errorKanjoDate);
            kanjoYm = StringUtils.defaultString(kanjoYm);
            kanjoYm = StringUtils.replace(kanjoYm, "", " ");
            errorMessage = StringUtils.replace(errorMessage, "#kanjoDate#", kanjoYm);
            throw new PspRunTimeExceotion(errorMessage);
        }
    }

    /**
     * 履歴情報を取得
     */
    private void findRireki() {
        boolean isRireki = false;

        // 履歴タイトル
        if (StringUtil.isNotEmpty(rirekiFlg) && rirekiFlg.equals("R")) {
            rirekiDispName = Label.getValue(Label.history);
            isRireki = true;
        } else if (ConstantString.teishutsuRirekiId.equals (rirekiId)) {
            rirekiDispName = Label.statusTeishutsu.getLabel();
        } else {
            rirekiDispName = Label.getValue(Label.now);
        }

        // 履歴タイトル、確定日、確定者
        SyuGeRirekiInfoTbl rirekiEntity = null;
        if (isRireki) {
            // 履歴表示時は、履歴管理テーブルから情報を取得
            rirekiEntity = syuGeRirekiInfoTblFacade.findPk(ankenId, (new Integer(rirekiId)));
            if (rirekiEntity != null) {
                rirekiTitle = rirekiEntity.getRirekiTitle();
                fixedDate = rirekiEntity.getFixedDate();
                fixedByName = rirekiEntity.getFixedBy();
            }

        } else {
            // 最新情報表示時は、案件の最終更新日と更新者を表示
            SyuGeBukkenInfoTbl aEntity = getAnkenEntity();

            fixedDate = aEntity.getUpdatedAt();
            fixedByName = jgrpMemberTblFacade.getMemberName(aEntity.getUpdatedBy());
        }
    }

    /**
     * 実績更新日時を取得
     */
    private void findJissekiUpdateDate() {
        Map<String, Object> condition = new HashMap<>();

        // 一般案件と進行基準案件で実績取込処理が異なるようなので、バッチIDを分ける。
        String batchId = "SYU_ANKEN_MAKE_DAILY";
        if (ConstantString.salesClassS.equals(ankenEntity.getSalesClass())) {
            batchId = "SYU_ANKEN_MAKE_MONTHLY_G";
        }

        //condition.put("batchId", "SYU_P0_TEMPTBL_GAIA");
        condition.put("batchId", batchId);
        condition.put("result", "0");

        SyuBatchLog batchLogEntity = syuBatchLogFacade.getMaxEndDate(condition);
        jissekiUpdateDate = batchLogEntity.getEndTime();
    }

    /**
     * 物件の開始年月-終了年月の選択候補を取得(yyyy/MMとなっている)
     *
     * @return
     * @throws java.text.ParseException
     * @throws java.sql.SQLException
     */
    public List<String> findNengetsuList() throws Exception {
        List<String> kikanFromList = new ArrayList<>();
        int index = 0;

        Map<String, String> uriageRangeInfo = uriageRangeService.getUriageStartEndInfo(ankenEntity, rirekiFlg);

        String selectYmFrom = uriageRangeInfo.get("URIAGE_START");
        String selectYmEnd = uriageRangeInfo.get("URIAGE_END");

        // 開始月 > 終了月の場合、開始月も終了月にする。
        if (selectYmFrom.compareTo(selectYmEnd) > 0) {
            // 案件の期間正常FLGを異常設定する。
            uriageRangeNormalFlg = 9;
            selectYmFrom = selectYmEnd;
        }

        Date ymEndDate = Utils.parseDate(selectYmEnd);

        while (true) {
            Date dateYmFrom = Utils.parseDate(selectYmFrom);
            Date nextMonthDate = DateUtils.addMonths(dateYmFrom, index);
            selectYmFrom = syuuekiUtils.exeFormatYm(nextMonthDate);

            if (nextMonthDate.after(ymEndDate)) {
                break;
            }

            index = 1;
            kikanFromList.add(selectYmFrom);
        }

        return kikanFromList;
    }

    /**
     * (期間損益進行基準)物件の開始年月-終了年月の選択候補を取得(yyyy/MMとなっている) 実績月および見込月の完売月Or売上予定月の＋年
     * @param addMonth
     * @return
     * @throws java.text.ParseException
     * @throws java.sql.SQLException
     */
    public List<String> findNengetsuListKikanShinko(int addMonth) throws Exception {
        List<String> kikanFromList = new ArrayList<>();
        int index = 0;

        Map<String, String> uriageRangeInfo = uriageRangeService.getUriageStartEndInfoKikanShinko(ankenEntity, rirekiFlg, addMonth);

        String selectYmFrom = uriageRangeInfo.get("URIAGE_START");
        String selectYmEnd = uriageRangeInfo.get("URIAGE_END");

        // 開始月 > 終了月の場合、開始月も終了月にする。
        if (selectYmFrom.compareTo(selectYmEnd) > 0) {
            // 案件の期間正常FLGを異常設定する。
            uriageRangeNormalFlg = 9;
            selectYmFrom = selectYmEnd;
        }

        Date ymEndDate = Utils.parseDate(selectYmEnd);

        while (true) {
            Date dateYmFrom = Utils.parseDate(selectYmFrom);
            Date nextMonthDate = DateUtils.addMonths(dateYmFrom, index);
            selectYmFrom = syuuekiUtils.exeFormatYm(nextMonthDate);

            if (nextMonthDate.after(ymEndDate)) {
                break;
            }

            index = 1;
            kikanFromList.add(selectYmFrom);
        }

        return kikanFromList;
    }

    /**
     * (期間損益進行基準)物件の開始年月-終了年月の選択候補を取得(yyyy/MMとなっている) 実績月および見込月の完売月Or売上予定月の＋年
     * @return
     * @throws java.text.ParseException
     * @throws java.sql.SQLException
     */
    public List<String> findNengetsuListKikanShinkoDownload() throws Exception {
        List<String> kikanFromList = new ArrayList<>();
        int index = 0;

        Map<String, String> uriageRangeInfo = uriageRangeService.getUriageStartEndInfoKikanShinkoDownLoad(ankenEntity, rirekiFlg);

        String selectYmFrom = uriageRangeInfo.get("URIAGE_START");
        String selectYmEnd = uriageRangeInfo.get("URIAGE_END");

        // 開始月 > 終了月の場合、開始月も終了月にする。
        if (selectYmFrom.compareTo(selectYmEnd) > 0) {
            // 案件の期間正常FLGを異常設定する。
            uriageRangeNormalFlg = 9;
            selectYmFrom = selectYmEnd;
        }

        Date ymEndDate = Utils.parseDate(selectYmEnd);

        while (true) {
            Date dateYmFrom = Utils.parseDate(selectYmFrom);
            Date nextMonthDate = DateUtils.addMonths(dateYmFrom, index);
            selectYmFrom = syuuekiUtils.exeFormatYm(nextMonthDate);

            if (nextMonthDate.after(ymEndDate)) {
                break;
            }

            index = 1;
            kikanFromList.add(selectYmFrom);
        }

        return kikanFromList;
    }
    
    /**
     * 期間Fromの選択候補を取得(2014上 add)
     * @return
     */
    public List<String> findKikanFromList() throws Exception {
        List<String> nengetsuList = findNengetsuList();
        List<String> kikanFromList = new ArrayList<>();

        String beforeKikan = "";
        for (String ym : nengetsuList) {
            String kikan = SyuuekiUtils.dateToKikan(Utils.parseDate(ym));

            if (!kikan.equals(beforeKikan)) {
                kikanFromList.add(kikan);
            }

            beforeKikan = kikan;
        }

        return kikanFromList;
    }

    /**
     * (期間損益・進行基準)期間Fromの選択候補を取得
     * @param addMonth
     * @return
     */
    public List<String> findSelectKikanFromList(int addMonth) throws Exception {
        List<String> nengetsuList = findNengetsuListKikanShinko(addMonth);
        List<String> kikanFromList = new ArrayList<>();

        String beforeKikan = "";
        for (String ym : nengetsuList) {
            String kikan = SyuuekiUtils.dateToKikan(Utils.parseDate(ym));

            if (!kikan.equals(beforeKikan)) {
                kikanFromList.add(kikan);
            }

            beforeKikan = kikan;
        }

        return kikanFromList;
    }

    /**
     * 初期表示を行う期を取得
     */
    public String getDefaultKikan(List<String> _kikanFromList) throws Exception {
        String result = "";
        boolean check = false;

        // 期間の選択候補リストを取得
        List<String> kikanFromList = _kikanFromList;
        if (kikanFromList == null) {
            kikanFromList = findKikanFromList();
        }

        // 勘定日付の期を取得
        Date kanjyoDate = getKanjoDate();
        String kanjyoKikan = SyuuekiUtils.dateToKikan(kanjyoDate);

        result = kanjyoKikan;
        for (String kikanFrom : kikanFromList) {
            if (kikanFrom.equals(kanjyoKikan)) {
                check = true;
                break;
            }
        }

        if (!check) {
            result = kikanFromList.get(kikanFromList.size() - 1);
        }

        return result;
    }

    /**
     * 売上予定年月を取得(完了している場合は売上完了年月)
     *
     * @return
     */
    public Date getAnkenUriageEndDate() {
        SyuGeBukkenInfoTbl ankenEn = getAnkenEntity();
        if (ankenEn == null) {
            return null;
        }

        String uriageEndFlg = StringUtils.defaultString(ankenEn.getUriageEndFlg(), "0");

        if (uriageEndFlg.equals("0") || uriageEndFlg.equals("1")) {
            return ankenEn.getUriageEnd();
        } else {
            return ankenEn.getUriageEndFin();
        }
    }

    /**
     * 事業部を取得
     *
     * @return
     */
    public String getDivisionCode() {
        SyuGeBukkenInfoTbl ankenEn = getAnkenEntity();
        String divisionCode = "DUMMY";
        if (ankenEn == null) {
            return divisionCode;
        }

        divisionCode = StringUtils.defaultString(ankenEn.getDivisionCode(), divisionCode);
        return divisionCode;
    }

    /**
     * 4半期表示FLGを取得
     *
     * @return
     */
    public String getQuarterDispFlg() {
        return quarterDispFlg;
    }

    /**
     * 完売FLGを取得
     *
     * @return
     */
    public String getUriageEndFlg() {
        return uriageEndFlg;
    }

    /**
     * 備考入力可能FLGを取得
     */
    public boolean isBikoInput() {
        // 期間損益(一般/進行基準画面)を開いていて、かつ最新データ表示・編集モード時に備考入力可能とする。
        if (("S003".equals(id) || "S004".equals(id)) && !"R".equals(rirekiFlg) && "1".equals(editFlg)) {
            return true;
        } else {
            return false;
        }
    }

    public String getEditFlg() {
        return editFlg;
    }

    public void setEditFlg(String editFlg) {
        this.editFlg = editFlg;
    }

    public int getUriageRangeNormalFlg() {
        return uriageRangeNormalFlg;
    }

    public void setUriageRangeNormalFlg(int uriageRangeNormalFlg) {
        this.uriageRangeNormalFlg = uriageRangeNormalFlg;
    }

    public String getAnkenFlg() {
        return ankenFlg;
    }

    public void setAnkenFlg(String ankenFlg) {
        this.ankenFlg = ankenFlg;
    }

    /**
     * @return the maeruikeiDispFlg
     */
    public String getMaeruikeiDispFlg() {
        return maeruikeiDispFlg;
    }

    /**
     * @param maeruikeiDispFlg the maeruikeiDispFlg to set
     */
    public void setMaeruikeiDispFlg(String maeruikeiDispFlg) {
        this.maeruikeiDispFlg = maeruikeiDispFlg;
    }

    public String getHatLinkSpNetFlg() {
        return hatLinkSpNetFlg;
    }

    public void setHatLinkSpNetFlg(String hatLinkSpNetFlg) {
        this.hatLinkSpNetFlg = hatLinkSpNetFlg;
    }

    public String getZenkaiId() {
        return zenkaiId;
    }

    public void setZenkaiId(String zenkaiId) {
        this.zenkaiId = zenkaiId;
    }

}
