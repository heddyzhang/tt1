package jp.co.toshiba.hby.pspromis.syuueki.bean;

import javax.enterprise.context.RequestScoped;
import javax.inject.Named;

/**
 *
 * @author ibayashi
 */
@Named(value = "shirajiEditBean")
@RequestScoped
public class ShirajiEditBean extends AbstractBean {
    
    /**
     * 取消/復活FLG(0:復活 1:取消)
     */
    private String deleteFlg = "1";
    
    /**
     * Creates a new instance of BookMarkBean
     */
    public ShirajiEditBean() {
    }

    public String getDeleteFlg() {
        return deleteFlg;
    }

    public void setDeleteFlg(String deleteFlg) {
        this.deleteFlg = deleteFlg;
    }

}
