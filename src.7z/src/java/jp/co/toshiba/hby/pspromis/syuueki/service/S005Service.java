package jp.co.toshiba.hby.pspromis.syuueki.service;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
//import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.HashSet;
import java.util.Iterator;
import javax.ejb.Stateless;
import javax.inject.Inject;
import javax.interceptor.Interceptors;
import javax.persistence.EntityManager;
//import javax.persistence.EntityTransaction;
import javax.persistence.PersistenceContext;
import jp.co.toshiba.hby.pspromis.common.util.StringUtil;
import jp.co.toshiba.hby.pspromis.syuueki.bean.S005Bean;
import jp.co.toshiba.hby.pspromis.syuueki.bean.S005MstBean;
import jp.co.toshiba.hby.pspromis.syuueki.entity.OperationLog;
import jp.co.toshiba.hby.pspromis.syuueki.entity.SyuGeNetItemTblBuka;
import jp.co.toshiba.hby.pspromis.syuueki.entity.SyuGeNetItemTblView;
import jp.co.toshiba.hby.pspromis.syuueki.entity.TeamEntity;
import jp.co.toshiba.hby.pspromis.syuueki.entity.SyuGeNetItemTbl;
//import jp.co.toshiba.hby.pspromis.syuueki.entity.SyuKiNetCateTitleTbl;
//import jp.co.toshiba.hby.pspromis.syuueki.entity.SyuSaNetCateTitleTbl;
//import jp.co.toshiba.hby.pspromis.syuueki.enums.Env;
import jp.co.toshiba.hby.pspromis.syuueki.enums.Label;
import jp.co.toshiba.hby.pspromis.syuueki.facade.SysdateEntityFacade;
import jp.co.toshiba.hby.pspromis.syuueki.facade.SyuGeBukenInfoTblFacade;
import jp.co.toshiba.hby.pspromis.syuueki.facade.SyuGeNetItemTblBukaFacade;
import jp.co.toshiba.hby.pspromis.syuueki.facade.SyuGeNetItemTblViewFacade;
import jp.co.toshiba.hby.pspromis.syuueki.facade.SyuKiNetCateTitleTblFacade;
import jp.co.toshiba.hby.pspromis.syuueki.facade.SyuSaNetCateTitleTblFacade;
//import jp.co.toshiba.hby.pspromis.syuueki.facade.TeamMstFacade;
import jp.co.toshiba.hby.pspromis.syuueki.interceptor.TranceInterceptor;
//import jp.co.toshiba.hby.pspromis.syuueki.jdbc.ResultSetManeger;
import jp.co.toshiba.hby.pspromis.common.jdbc.SqlExecutor;
import jp.co.toshiba.hby.pspromis.syuueki.bean.ValidationInfoBean;
import jp.co.toshiba.hby.pspromis.syuueki.entity.SyuCurMst;
import jp.co.toshiba.hby.pspromis.syuueki.entity.SyuGeBukkenInfoTbl;
import jp.co.toshiba.hby.pspromis.syuueki.entity.SyuKiNetCateTitleTblView;
import jp.co.toshiba.hby.pspromis.syuueki.entity.SyuSaNetCateTitleTblView;
import jp.co.toshiba.hby.pspromis.syuueki.enums.Env;
import jp.co.toshiba.hby.pspromis.syuueki.facade.KanjyoMstFacade;
import jp.co.toshiba.hby.pspromis.syuueki.facade.SyuCurMstFacade;
import jp.co.toshiba.hby.pspromis.syuueki.facade.SyuKiNetItemTukiTblFacade;
import jp.co.toshiba.hby.pspromis.syuueki.facade.SyuSaNetItemTblFacade;
import jp.co.toshiba.hby.pspromis.syuueki.facade.SyuWfControlTblFacade;
import jp.co.toshiba.hby.pspromis.syuueki.pages.DetailHeader;
import jp.co.toshiba.hby.pspromis.syuueki.pages.DivisonComponentPage;
import jp.co.toshiba.hby.pspromis.syuueki.util.ConstantString;
import jp.co.toshiba.hby.pspromis.syuueki.util.DateUtils;
import jp.co.toshiba.hby.pspromis.syuueki.util.EntityUtils;
import jp.co.toshiba.hby.pspromis.syuueki.util.LoginUserInfo;
import jp.co.toshiba.hby.pspromis.syuueki.util.SyuuekiUtils;
import jp.co.toshiba.hby.pspromis.syuueki.util.Utils;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * PS-Promis収益管理システム
 * 項番一覧 Service
 * @author (NPC)T.Wakamatsu
 */
@Stateless
@Interceptors({TranceInterceptor.class})
public class S005Service {

    /**
     * ロガー
     */
    public static final Logger logger = LoggerFactory.getLogger(S005Service.class);

    @PersistenceContext(unitName = jp.co.toshiba.hby.pspromis.syuueki.util.ConstantString.syuuekiDataSourceName)
    private EntityManager em;

    /**
     * パラメータ格納クラスをinjection(CDI)<br>
     * InjectアノテーションよりAPサーバー(Glassfish)側で自動的にインスタンス作成(new)される。<br>
     */
    @Inject
    private S005Bean s005Bean;
    /**
     * Injection loginUserInfo
     * (ユーザー情報(ユーザーid,名称,所属部課名)を格納したオブジェクト)
     */
    @Inject
    private LoginUserInfo loginUserInfo;
    /**
     * Injection sqlExecutor
     */
    @Inject
    protected SqlExecutor sqlExecutor;
    /**
     * Injection S005MstBean
     */
    @Inject
    private S005MstBean s005MstBean;
    /**
     * Injection DetailHeader
     */
    @Inject
    private DetailHeader detailHeader;
    /**
     * Injection Utils
     */
    @Inject
    private Utils utils;
    /**
     * Injection syuuekiUtils
     */
    @Inject
    private SyuuekiUtils syuuekiUtils;
    /**
     * Injection SyuGeNetItemTblViewFacade
     */
    @Inject
    private SyuGeNetItemTblViewFacade syuGeNetItemTblViewFacade;
    /**
     * Injection SyuWfControlTblFacade
     */
    @Inject
    private SyuWfControlTblFacade syuWfControlTblFacade;
    /**
     * Injection SyuGeNetItemTblBuka
     */
    @Inject
    private SyuGeNetItemTblBukaFacade syuGeNetItemTblBukaFacade;

    /**
     * Injection SyuGeBukenInfoTblFacade
     */
    @Inject
    private SyuGeBukenInfoTblFacade syuGeBukenInfoTblFacade;

    /**
     * Injection SyuGeBukenInfoTblFacade
     */
    @Inject
    private SyuKiNetItemTukiTblFacade syuKiNetItemTukiTblFacade;

    /**
     * Injection SyuGeBukenInfoTblFacade
     */
    @Inject
    private SyuSaNetItemTblFacade syuSaNetItemTblFacade;

    /**
     * Injection SysdateEntityFacade
     */
    @Inject
    private SysdateEntityFacade sysdateFacade;

    //@Inject
    //private TeamMstFacade teamMstFacade;

    @Inject
    private SyuuekiCommonService syuuekiCommonService;
    
    /**
     * Injection OperationLogService
     */
    @Inject
    private OperationLogService operationLogService;

    /**
     * Injection SyuSaNetCateTitleTblFacade
     */
    @Inject
    private SyuSaNetCateTitleTblFacade syuSaNetCateTitleTblFacade;

    /**
     * Injection SyuKiNetCateTitleTblFacade
     */
    @Inject
    private SyuKiNetCateTitleTblFacade syuKiNetCateTitleTblFacade;

    @Inject
    private SyuCurMstFacade syuCurMstFacade;

    @Inject
    private StoredProceduresService storedProceduresService;

    @Inject
    private KanjyoMstFacade kanjyoMstFacade;

    @Inject
    private S018Service s018Service;

    @Inject
    private DivisonComponentPage divisionComponentPage;
    
    /**
     * 案件基本情報のPKセット
     */
    private void findAnkenSetPk() {
        detailHeader.setAnkenId(s005Bean.getAnkenId());
        detailHeader.setRirekiId(s005Bean.getRirekiId());
        detailHeader.setRirekiFlg(s005Bean.getRirekiFlg());
        detailHeader.setId("S005");
    }

    /**
     * 案件基本情報の検索
     */
    public void findAnkenInfo() {
        findAnkenSetPk();
        detailHeader.findPk();
    }

    /**
     * 案件基本情報の検索(不要な情報をselectしないようにした)
     */
    private void findAnkenInfoOnly() {
        findAnkenSetPk();
        detailHeader.findAnkenPk();
    }

    /**
     * 表示期間切り替え時
     */
    private void changeKikan() {
        // 期間の変更処理でなければこのメソッドはスル―
        if (StringUtil.isEmpty(s005Bean.getKikanChangeFlg())) {
            return;
        }

        String kikanForm = s005Bean.getKikanForm();
        if ("B".equals(s005Bean.getKikanChangeFlg())) {
            // 一期前に移動
            kikanForm = syuuekiUtils.calcKikan(kikanForm, -1);
        } else if ("A".equals(s005Bean.getKikanChangeFlg())) {
            // 一期後に移動
            kikanForm = syuuekiUtils.calcKikan(kikanForm, 1);
        }

        // 変更した期間(from)をbeanに詰め直す(画面再表示時にこの期間が使用される)
        s005Bean.setKikanForm(kikanForm);
    }

    /**
     * 期間をBeanにセット
     */
    public void setKikan() {
        // 期間を取得
        logger.info("S005Service#setKikan");
        String Form = s005Bean.getKikanForm();
                logger.info("S005Service#setKikan" + Form);
        String To = syuuekiUtils.calcKikan(Form, 1);
                logger.info("S005Service#setKikan");
        logger.info("setKikan:FROM=" + Form);
        logger.info("setKikan:TO=" + To);

        // 上期および下期の年月を配列として取得
        String[] kikanForm = SyuuekiUtils.getKikanMonthAry(Form);
        String[] kikanTo   = SyuuekiUtils.getKikanMonthAry(To);

        s005Bean.setKikan01(kikanForm[0]);
        s005Bean.setKikan02(kikanForm[1]);
        s005Bean.setKikan03(kikanForm[2]);
        s005Bean.setKikan04(kikanForm[3]);
        s005Bean.setKikan05(kikanForm[4]);
        s005Bean.setKikan06(kikanForm[5]);
        s005Bean.setKikan07(kikanTo[0]);
        s005Bean.setKikan08(kikanTo[1]);
        s005Bean.setKikan09(kikanTo[2]);
        s005Bean.setKikan10(kikanTo[3]);
        s005Bean.setKikan11(kikanTo[4]);
        s005Bean.setKikan12(kikanTo[5]);
    }

    /**
     * 子案件のリストを取得(まとめ案件時)
     */
    private List<String> findChildAnkenList() {
        List<String> childAnkenList = null;
        
        Map<String, Object> condition = new HashMap<>();
        // 物件key
        condition.put("ankenId", s005Bean.getAnkenId());
        // 履歴key
        condition.put("rirekiId", s005Bean.getRirekiId());
        // 履歴Flg
        condition.put("rirekiFlg", s005Bean.getRirekiFlg());

        String ankenFlg = "0";
        ankenFlg = StringUtils.defaultString(detailHeader.getAnkenEntity().getAnkenFlg());
        
        if (ankenFlg.equals("1")) {
            // 案件フラグが1の場合はまとめ案件のため、子案件を取得
            childAnkenList = syuGeBukenInfoTblFacade.findChildAnkenNo(condition);
        } else {
            childAnkenList = new ArrayList<String>();
        }
        
        return childAnkenList;
    }
    
    /**
     * メインのkey情報を設定
     */
    private void setAnkenId(Map<String, Object> condition) {
        // 物件key(指定物件のKEY)
        condition.put("targetAnkenId", s005Bean.getAnkenId());
        // 物件key
        condition.put("ankenId", s005Bean.getAnkenId());
        // 履歴key
        condition.put("rirekiId", s005Bean.getRirekiId());
        // 履歴Flg
        condition.put("rirekiFlg", s005Bean.getRirekiFlg());

        List<String> childAnkenList = s005Bean.getChildAnkenIdList();
        if (childAnkenList == null) {
            childAnkenList = findChildAnkenList();
        }
        if (childAnkenList != null && childAnkenList.size() > 0) {
            condition.put("ankenId", childAnkenList);
            // (2018/01/18)まとめ案件idセット
            condition.put("matomeAnkenId", s005Bean.getAnkenId());
        }

//        String ankenFlg = "0";
//        ankenFlg = StringUtils.defaultString(detailHeader.getAnkenEntity().getAnkenFlg());
//
//        if(ankenFlg.equals("1")){
//            // 案件フラグが1の場合はまとめ案件のため、子案件を取得
//            List<String> childAnkenList = syuGeBukenInfoTblFacade.findChildAnkenNo(condition);
//            if (childAnkenList != null && childAnkenList.size() > 0) {
//                condition.put("ankenId", childAnkenList);
//            }
//        }

    }

    /**
     * 検索条件用Mapを作成
     */
    public Map<String, Object> getCondition() throws ParseException {
        Map<String, Object> condition = new LinkedHashMap<>();

        // メインkey情報
        setAnkenId(condition);

        // 注番
        condition.put("orderNo", s005Bean.getOrderNo());
        // 項番1
        condition.put("orderItemFrom", s005Bean.getOrderItemFrom());
        // 項番2
        condition.put("orderItemTo", s005Bean.getOrderItemTo());
        // 製番記号
        condition.put("seiban", s005Bean.getSeiban());
        // 売上残
        condition.put("uriageEndFlg", s005Bean.getUriageEndFlg());
        // （技）/IEC(設計）
        condition.put("giBukaCd", s005Bean.getGiBukaCd());
        // 工場設計課
        condition.put("sekkeiBukaCd", s005Bean.getSekkeiBukaCd());
        // カテゴリ(最終)
        condition.put("saCate1", s005Bean.getSaCate1());
        // カテゴリ(期間)
        condition.put("kiCate1", s005Bean.getKiCate1());
        // カテゴリ(最終)
        condition.put("saCate2", s005Bean.getSaCate2());
        // カテゴリ(期間)
        condition.put("kiCate2", s005Bean.getKiCate2());
        // 発番発行
        condition.put("hatHako", s005Bean.getHatHako());
        // (2018A)差分チェック(発番と最終見込)
        condition.put("diffCheckKbnHatFixedMikomi", s005Bean.getDiffCheckKbnHatFixedMikomi());
        // (2018A)差分チェック(発番と注入累計)
        condition.put("diffCheckKbnHatChunyu", s005Bean.getDiffCheckKbnHatChunyu());
        
        
        
        // ソート順(最優先)
        condition.put("sort1", s005Bean.getSort1());
        condition.put("sort1kbn", s005Bean.getSort1Kbn());
        // ソート順(２番目)
        condition.put("sort2", s005Bean.getSort2());
        condition.put("sort2kbn", s005Bean.getSort2Kbn());
        // 表示内容
        condition.put("dispKbn", s005Bean.getDispKbn());
        // 期間
        // 勘定月の取得
        SimpleDateFormat ymSd = new SimpleDateFormat("yyyyMM");
        String strDate = ymSd.format(detailHeader.getKanjoDate());
        Date date;

        condition.put("kikan01", s005Bean.getKikan01());
        condition.put("kikan02", s005Bean.getKikan02());
        condition.put("kikan03", s005Bean.getKikan03());
        condition.put("kikan04", s005Bean.getKikan04());
        condition.put("kikan05", s005Bean.getKikan05());
        condition.put("kikan06", s005Bean.getKikan06());
        date = Utils.parseDate(s005Bean.getKikan06());
        condition.put("kikanK",  SyuuekiUtils.dateToKikan(date));
        condition.put("kikan07", s005Bean.getKikan07());
        condition.put("kikan08", s005Bean.getKikan08());
        condition.put("kikan09", s005Bean.getKikan09());
        condition.put("kikan10", s005Bean.getKikan10());
        condition.put("kikan11", s005Bean.getKikan11());
        condition.put("kikan12", s005Bean.getKikan12());
        date = Utils.parseDate(s005Bean.getKikan12());
        condition.put("kikanS",  SyuuekiUtils.dateToKikan(date));
        condition.put("kikanG", "999900G");
        condition.put("kikanNow", strDate);

        if(StringUtil.isEmpty(s005Bean.getZenkaiId())){
            condition.put("zenkaiId", s005Bean.getZenkaiId());
        } else {
            condition.put("zenkaiId", Integer.valueOf(s005Bean.getZenkaiId()));
        }


        return condition;
    }

    /**
     * 検索時のログ出力用
     * @param condition
     */
    private void removeForm(Map<String, Object> condition){
        condition.remove("listFlg");
        condition.remove("netFlg");
        condition.remove("dispKbn");
        condition.remove("kikan01");
        condition.remove("kikan02");
        condition.remove("kikan03");
        condition.remove("kikan04");
        condition.remove("kikan05");
        condition.remove("kikan06");
        condition.remove("kikanK");
        condition.remove("kikan07");
        condition.remove("kikan08");
        condition.remove("kikan09");
        condition.remove("kikan10");
        condition.remove("kikan11");
        condition.remove("kikan12");
        condition.remove("kikanS");
        condition.remove("kikanG");
        condition.remove("kikanNow");
    }

    /**
     * 期間Fromの選択候補を取得(2014上 add)
     */
    private void createKikanFromList() throws Exception {
        List<String> kikanFromList = detailHeader.findKikanFromList();
        s005Bean.setKikanFromList(kikanFromList);
    }

    /**
     * 子案件情報をbeanに設定
     */
    private void setBeanChildAnkenList() {
        List childAnkenList = findChildAnkenList();
        if (childAnkenList != null && childAnkenList.size() > 0) {
            logger.info("setBeanChildAnkenList childAnkenList=" + childAnkenList.toString());
            s005Bean.setChildAnkenIdList(childAnkenList);
        } else {
            logger.info("setBeanChildAnkenList childAnkenList is empty");
        }
    }
    
    /**
     * 画面表示に必要な情報を取得してbeanにセット
     */
    private void setDispInfoBean() throws Exception {
        Map<String, Object> condition = new HashMap<>();
        condition.put("ankenId", s005Bean.getAnkenId());
        condition.put("rirekiId", s005Bean.getRirekiId());
        condition.put("rirekiFlg", s005Bean.getRirekiFlg());

        // 物件基本情報を取得(ヘッダ部＋履歴管理・備考部＋勘定月の取得)
        findAnkenInfo();

        // 対象の子案件を取得してs005Beanにセット(まとめ案件の場合のみ取得できるはず)
        setBeanChildAnkenList();

        // 子案件が存在すれば、
        Map<String, Object> categoryListCondition = new HashMap<>(condition);
        if (s005Bean.getChildAnkenIdList() != null && s005Bean.getChildAnkenIdList().size() > 0) {
            categoryListCondition.put("childAnkenId", s005Bean.getChildAnkenIdList());
        }
        
        // カテゴリ(最終)の選択候補を取得(2014下 add)
        List<SyuSaNetCateTitleTblView> saList1 = syuSaNetCateTitleTblFacade.getSearchList1(categoryListCondition);
        s005MstBean.setCateSaList1(saList1);

        List<SyuSaNetCateTitleTblView> cateSaList2 = syuSaNetCateTitleTblFacade.getSearchList2(categoryListCondition);
        s005MstBean.setCateSaList2(cateSaList2);

        // カテゴリ(期間)の選択候補を取得(2014下 add)
        List<SyuKiNetCateTitleTblView> kiList1 = syuKiNetCateTitleTblFacade.getSearchList1(categoryListCondition);
        s005MstBean.setCateKiList1(kiList1);

        List<SyuKiNetCateTitleTblView> cateKiList2 = syuKiNetCateTitleTblFacade.getSearchList2(categoryListCondition);
        s005MstBean.setCateKiList2(cateKiList2);

        // 期間Fromの選択候補を取得(2014下 add)
        createKikanFromList();

        //項番一覧(最終)の場合、通貨用リストを取得する
        List<SyuCurMst> list = syuCurMstFacade.findAll();
        s005Bean.setCurrencyCodeList(list);

        // 前回値取得用の前回IDを取得しておく
        String id = syuGeBukenInfoTblFacade.getZenkaiId(condition);
        s005Bean.setZenkaiId(id);

        // 対象案件の売上基準
        s005Bean.setSalesClass(StringUtils.defaultString(detailHeader.getAnkenEntity().getSalesClass()));

        if(StringUtils.isNotEmpty(id)){
            // 前回確定月の取得を行う
            SyuGeBukkenInfoTbl entity = detailHeader.getAnkenEntity();
            condition.put("divisionCode", entity.getDivisionCode());
            condition.put("salesClass", entity.getSalesClass());
            condition.put("zenkaiId", id);

            String month = syuWfControlTblFacade.getSyoninAt(condition);
            if(StringUtils.isNotEmpty(month)){
                month = month.substring(0, 4) + "/" + month.substring(5, 7);
            }
            s005Bean.setBefMonth(month);
        }

    }

    /**
     * 検索条件のデフォルトを設定
     * @throws Exception
     */
    public void initCondition() throws Exception {
        logger.info("S005Service#initCondition");

        //
        s005Bean.setOrderNo("");
        s005Bean.setOrderItemFrom("");
        s005Bean.setOrderItemTo("");
        s005Bean.setSeiban("");
        s005Bean.setUriageEndFlg("");
        s005Bean.setGiBukaCd("");
        s005Bean.setSekkeiBukaCd("");
        s005Bean.setSort1Kbn("0");
        s005Bean.setSort2Kbn("0");
        s005Bean.setSort1("orderNo");
        s005Bean.setSort2("orderItem");

        if (s005Bean.isIsIkkatsuFlg()) {
            // 一括DLのときは、表示内容＝売上 固定
            s005Bean.setDispKbn("1");
        } else if ("1".equals(s005Bean.getMikomiItemSearchFlg())) {
            // 見込項番の検索の場合、パラメータのdispKbnをそのまま引き継ぐ

        } else {
            // 項番一覧の画面を初期表示時
            String ankenFlg = "0";
            ankenFlg = StringUtils.defaultString(detailHeader.getAnkenEntity().getAnkenFlg());
            s005Bean.setAnkenFlg(ankenFlg);
            if(ankenFlg.equals("1")){
                s005Bean.setDispKbn("0");
            }else{
                s005Bean.setDispKbn("1");
            }
        }

        // 発番発行
        String[] hatHako = {"0", "1"};
        // 2018/01/18 (NPC)S.Ibayashi
        // 進行基準まとめ案件は見込項番は参照しないようなので、[未発番]選択をデフォルト指定から外す
        SyuGeBukkenInfoTbl ankenEntity = detailHeader.getAnkenEntity();
        //if (StringUtils.isEmpty(s005Bean.getSaCategory()) && StringUtils.isEmpty(s005Bean.getKiCategory())) {
            if (ConstantString.salesClassS.equals(ankenEntity.getSalesClass()) && "1".equals(ankenEntity.getAnkenFlg())) {
                hatHako = new String[1];
                hatHako[0] = "0";
            }
        //}
        s005Bean.setHatHako(hatHako);
    }

    /**
     * データ編集可否FLGを取得
     * @return 1:編集可能 0:編集不可
     */
    private void setEditAuthFlg() {
        String editAuthFlg = "0";
        String saisyuUpdeteBtnFlg = "0";

        SyuGeBukkenInfoTbl geEntity = detailHeader.getAnkenEntity();

        // 事業部:原子力か？
        boolean isNuclearDivision = divisionComponentPage.isNuclearDivision(geEntity.getDivisionCode());
        
        // ログイン者が権限を保有していれば編集可能
        //List<TeamEntity> teamMstList = teamMstFacade.findUserTeamList(loginUserInfo.getUserId());
        //boolean isEdit = loginUserInfo.isAnkenEdit(geEntity, teamMstList);
        boolean isEdit = syuuekiCommonService.isAnkenEditOk(geEntity);
        if (isEdit) {
            // 編集ボタン/最新値更新ボタンの編集制御
            if (ConstantString.salesClassS.equals(geEntity.getSalesClass())) {
                //// 進行基準の案件(基本は編集不可だが、以下の条件を満たす案件のみ編集可能とする)
                if (isNuclearDivision && !"1".equals(geEntity.getAnkenFlg())) {
                    // 原子力案件+子案件の場合
                    if ("1".equals(s005Bean.getViewFlg())) {
                        // 項番一覧(最終)は編集可能とする。
                        editAuthFlg = "1";
                    }
                    saisyuUpdeteBtnFlg = "1";
                }

            } else {
                //// 進行基準以外(一般)の案件
                editAuthFlg = "1";
                saisyuUpdeteBtnFlg = "1";
            }
        }

        // 2017/01/30 最終見込NETの入力権限をチェック
        s005Bean.setInputSaisyuMikomiNetFlg("0");
        if ("1".equals(s005Bean.getEditFlg()) && ConstantString.salesClassS.equals(s005Bean.getSalesClass())) {
            // 編集モード　かつ 進行基準案件(実際は子案件のみ)の場合、編集可能とする(一般案件は再計算処理で各月の実績＋見込の合計を自動的に最終見込NETに自動設定するようにしたので、入力不可とする)
            s005Bean.setInputSaisyuMikomiNetFlg("1");
        }

        s005Bean.setEditAuthFlg(editAuthFlg);
        s005Bean.setSaisyuUpdeteBtnFlg(saisyuUpdeteBtnFlg);
    }

    /**
     * 画面表示　ビジネスロジック
     * @throws Exception
     */
    public void indexExecute() throws Exception {
        logger.info("S005Service#indexExecute");

        // 物件基本情報を取得(ヘッダ部＋履歴管理・備考部＋勘定月の取得)
        //findAnkenInfo();
        // 画面表示に必要な情報を取得してbeanにセット
        setDispInfoBean();

        // 勘定月から現在の期を取得
        String nowKikan = detailHeader.getDefaultKikan(s005Bean.getKikanFromList());

        // 画面に表示する値をbeanにセット(期間(FROM))
        if (StringUtil.isEmpty(s005Bean.getKikanForm())) {
            s005Bean.setKikanForm(nowKikan);
        } else {
            // 引数で指定された期間が選択候補に存在しない場合は、初期表示の期をセットする。
            // (期間損益(進行基準)で期間の指定範囲が広がっているため、この画面で指定できない期間が渡ってくる可能性がある)
            boolean isDefaultKikanFrom = false;
            if (CollectionUtils.isNotEmpty(s005Bean.getKikanFromList())) {
                if (s005Bean.getKikanFromList().contains(s005Bean.getKikanForm())) {
                    isDefaultKikanFrom = true;
                }
//                for (String kikanFrom : s005Bean.getKikanFromList()) {
//                    if (kikanFrom.equals(s005Bean.getKikanForm())) {
//                        isDefaultKikanFrom = true;
//                        break;
//                    }
//                }
            }

            if (!isDefaultKikanFrom) {
                s005Bean.setKikanForm(nowKikan);
            }
        }

        // 検索条件のデフォルトを設定
        initCondition();

        //if(s005Bean.getViewFlg().equals("1")){
        //    //画面表示を円価にする
        //    s005Bean.setDispFlg("1");
        //}

        s005Bean.setPotenFlg(detailHeader.getAnkenEntity().getPotentialFlg());

    }

    /**
     * 検索条件・選択部課取得
     * @throws Exception
     */
    public void selectBukaList() throws Exception {
        //findAnkenInfo();
        findAnkenInfoOnly();

        // 検索条件を作成
        Map<String, Object> condition = new HashMap<>();
        // メインkey情報を設定
        setAnkenId(condition);

        // （技）/IEC(設計）部課を取得
        List<SyuGeNetItemTblBuka> sekkeiBukaList
                = syuGeNetItemTblBukaFacade.getSekkeiBukaList(condition);

        // （工場）設計部課を取得
        List<SyuGeNetItemTblBuka> kojoBukaList
                = syuGeNetItemTblBukaFacade.getKojosBukaList(condition);

        s005MstBean.setSekkeiBukaList(sekkeiBukaList);
        s005MstBean.setKojoBukaList(kojoBukaList);
    }

    /**
     * 一覧表示　ビジネスロジック
     * @throws Exception
     */
    public void listExecute() throws Exception {
        logger.info("S005Service#listExecute");

        // 物件基本情報を取得(ヘッダ部＋履歴管理・備考部＋勘定月の取得)
        //findAnkenInfo();
        // 画面表示に必要な情報を取得してbeanにセット
        setDispInfoBean();

        // 見込項番検索の場合の検索条件設定
        overrideSearhMitItemCondition();
        
        // 案件の編集可否チェック
        setEditAuthFlg();

        // 期間切り替え時
        changeKikan();
        
        // ページ切り替えか否かを判定
        boolean isPageing = true;
        if (s005Bean.getPage() == null || s005Bean.getPage() <= 0) {
            isPageing = false;
            s005Bean.setPage(1);
        }

        // 期間が変更されたかを判定
        boolean isKikan = true;
        if (StringUtil.isEmpty(s005Bean.getKikanChangeFlg())) {
            isKikan = false;
        }

        // 期間をセット
        if(!s005Bean.getViewFlg().equals("1")){
            setKikan();
        }

        // 検索条件をセット
        Map<String, Object> condition = getCondition();

        // 一覧データの総件数を取得(ページ切り替え時は省略)
        Integer totalCount = s005Bean.getCount();
        SyuGeNetItemTblView totalResultEntity = new SyuGeNetItemTblView();

        List<SyuGeNetItemTblView> list = null;
        if(s005Bean.getViewFlg().equals("0")){
            s005Bean.setKikanFlg(1);
            s005Bean.setSaishuFlg(0);
            condition.put("kikanFlg", s005Bean.getKikanFlg());
            condition.put("saishuFlg", s005Bean.getSaishuFlg());
            // 項番一覧(期間)の場合
            if (!isPageing || isKikan || !s005Bean.getDispKbn().equals(s005Bean.getOldDispKbn()) || "1".equals(s005Bean.getEditFlg())) {
                // 検索ボタン
                condition.put("listFlg", "1");
                totalResultEntity = syuGeNetItemTblViewFacade.getItemSum(condition);
                totalCount = totalResultEntity.getCount();
                s005Bean.setOldDispKbn(s005Bean.getDispKbn());
                s005Bean.setSumCyunyuNet(totalResultEntity.getCyunyuNet());
                s005Bean.setSumFixedMikomiNet(totalResultEntity.getFixedMikomiNet());
                s005Bean.setSumHachuAmount(totalResultEntity.getHachuAmount());
                s005Bean.setSumHatNet(totalResultEntity.getHatNet());
                s005Bean.setSumUriageNet(totalResultEntity.getUriageNet());
                s005Bean.setSumSeibanSonekiNet(totalResultEntity.getSeibanSonekiNet());
                s005Bean.setSumNet01(totalResultEntity.getNet01());
                s005Bean.setSumNet02(totalResultEntity.getNet02());
                s005Bean.setSumNet03(totalResultEntity.getNet03());
                s005Bean.setSumNet04(totalResultEntity.getNet04());
                s005Bean.setSumNet05(totalResultEntity.getNet05());
                s005Bean.setSumNet06(totalResultEntity.getNet06());
                s005Bean.setSumNetFrom(totalResultEntity.getNetFrom());
                s005Bean.setSumNet07(totalResultEntity.getNet07());
                s005Bean.setSumNet08(totalResultEntity.getNet08());
                s005Bean.setSumNet09(totalResultEntity.getNet09());
                s005Bean.setSumNet10(totalResultEntity.getNet10());
                s005Bean.setSumNet11(totalResultEntity.getNet11());
                s005Bean.setSumNet12(totalResultEntity.getNet12());
                s005Bean.setSumNetTo(totalResultEntity.getNetTo());
                s005Bean.setSumNetG(totalResultEntity.getNetG());

                if (!isPageing) {
                    // 操作ログを出力
                    OperationLog operationLog = getOperationLogDto(condition);
                    operationLogService.insertOperationLogSearch(operationLog);
                }
            }

        } else {
            s005Bean.setKikanFlg(0);
            s005Bean.setSaishuFlg(1);
            condition.put("kikanFlg", s005Bean.getKikanFlg());
            condition.put("saishuFlg", s005Bean.getSaishuFlg());
            condition.put("editFlg", s005Bean.getEditFlg());
            // 項番一覧(最終)の場合
            if (!isPageing || "1".equals(s005Bean.getEditFlg())) {
                // 検索ボタン
                condition.put("listFlg", "1");
                totalResultEntity = syuGeNetItemTblViewFacade.getItemSum(condition);
                totalCount = totalResultEntity.getCount();

                // 取得したデータのセット
                s005Bean.setSumGenjoHat(totalResultEntity.getHatNet());
                s005Bean.setSumZenkaiHat(totalResultEntity.getHatNetBef());
                s005Bean.setSumJusei(totalResultEntity.getJuseiEnka());
                s005Bean.setSumJutyu(totalResultEntity.getJutyuEnka());
                s005Bean.setSumMokuhyo(totalResultEntity.getMokuhyoEnka());
                s005Bean.setSumSaishinMitumori(totalResultEntity.getSaishinmitumoriEnka());
                s005Bean.setSumSekeisatei(totalResultEntity.getSekeisateiEnka());
                s005Bean.setSumChotatusatei(totalResultEntity.getChotatusateiEnka());
                s005Bean.setSumSaishuMikomiNow(totalResultEntity.getFixedMikomiNet());
                s005Bean.setSumSaishuMikomiBef(totalResultEntity.getFixedMikomiNetBef());
                s005Bean.setSumPotenDai(totalResultEntity.getPotenDaiEnka());
                s005Bean.setSumPotenTyu(totalResultEntity.getPotenTyuEnka());
                s005Bean.setSumPotenSho(totalResultEntity.getPotenShoEnka());
                s005Bean.setSumCyunyuNet(totalResultEntity.getCyunyuNet());
                s005Bean.setSumSeibanSonekiNet(totalResultEntity.getSeibanSonekiNet());
                s005Bean.setSumUriageNet(totalResultEntity.getUriageNet());
                s005Bean.setSumHachu(totalResultEntity.getHachuEnka());
                s005Bean.setSumKenshu(totalResultEntity.getKenshuEnka());
                s005Bean.setSumMikenshu(totalResultEntity.getMikenshuEnka());


                // 操作ログを出力
                OperationLog operationLog = getOperationLogDto(condition);
                operationLogService.insertOperationLogSearch(operationLog);

            }
        }
        // 一覧検索実行(データが存在する場合のみ実行)
        if (totalCount != null && totalCount > 0) {
            condition.put("listFlg", "0");
            list = syuGeNetItemTblViewFacade.getItemList(condition, s005Bean.getPage());
            if(s005Bean.getViewFlg().equals("1")){
                checkDispFlg(list);
            }
        }
        // 結果をbeanセット
        s005Bean.setCount(totalCount);
        s005Bean.setSyuGeNetItemTblViewList(list);

    }

    /**
     * 項番一覧(最終) 表示内容チェック
     * @param list
     */
    private void checkDispFlg(List<SyuGeNetItemTblView> list){
        boolean flg = false;
        for(SyuGeNetItemTblView entity : list){
            if(StringUtils.isNotEmpty(entity.getJuseiCurrencyCode()) && !entity.getJuseiCurrencyCode().equals(ConstantString.currencyCodeEn)){
                flg = true;
                break;
            }
            if(StringUtils.isNotEmpty(entity.getJutyuCurrencyCode()) && !entity.getJutyuCurrencyCode().equals(ConstantString.currencyCodeEn)){
                flg = true;
                break;
            }
            if(StringUtils.isNotEmpty(entity.getMokuhyoCurrencyCode()) && !entity.getMokuhyoCurrencyCode().equals(ConstantString.currencyCodeEn)){
                flg = true;
                break;
            }
            if(StringUtils.isNotEmpty(entity.getSaishinmitumoriCurrencyCode()) && !entity.getSaishinmitumoriCurrencyCode().equals(ConstantString.currencyCodeEn)){
                flg = true;
                break;
            }
            if(StringUtils.isNotEmpty(entity.getSekeisateiCurrencyCode()) && !entity.getSekeisateiCurrencyCode().equals(ConstantString.currencyCodeEn)){
                flg = true;
                break;
            }
            if(StringUtils.isNotEmpty(entity.getChotatusateiCurrencyCode()) && !entity.getChotatusateiCurrencyCode().equals(ConstantString.currencyCodeEn)){
                flg = true;
                break;
            }
            if(StringUtils.isNotEmpty(entity.getFixedMikomiCurrecyCode()) && !entity.getFixedMikomiCurrecyCode().equals(ConstantString.currencyCodeEn)){
                flg = true;
                break;
            }
            if(StringUtils.isNotEmpty(entity.getFixedMikomiBefCurrencyCode()) && !entity.getFixedMikomiBefCurrencyCode().equals(ConstantString.currencyCodeEn)){
                flg = true;
                break;
            }
            if(StringUtils.defaultString(detailHeader.getAnkenEntity().getPotentialFlg(), "0").equals("1")){
                if(StringUtils.isNotEmpty(entity.getPotenDaiCurrencyCode()) && !entity.getPotenDaiCurrencyCode().equals(ConstantString.currencyCodeEn)){
                    flg = true;
                    break;
                }
                if(StringUtils.isNotEmpty(entity.getPotenTyuCurrencyCode()) && !entity.getPotenTyuCurrencyCode().equals(ConstantString.currencyCodeEn)){
                    flg = true;
                    break;
                }
                if(StringUtils.isNotEmpty(entity.getPotenShoCurrencyCode()) && !entity.getPotenShoCurrencyCode().equals(ConstantString.currencyCodeEn)){
                    flg = true;
                    break;
                }
            }
            if(StringUtils.isNotEmpty(entity.getHachuCurrencyCode()) && !entity.getHachuCurrencyCode().equals(ConstantString.currencyCodeEn)){
                flg = true;
                break;
            }
            if(StringUtils.isNotEmpty(entity.getKenshuCurrencyCode()) && !entity.getKenshuCurrencyCode().equals(ConstantString.currencyCodeEn)){
                flg = true;
                break;
            }
            if(StringUtils.isNotEmpty(entity.getMikenshuCurrencyCode()) && !entity.getMikenshuCurrencyCode().equals(ConstantString.currencyCodeEn)){
                flg = true;
                break;
            }
        }

        // 画面表示データにJPY以外の通貨が含まれている場合
        if(flg){
            // 表示内容を「外貨含」にセット
            s005Bean.setDispFlg("0");
        }
    }

    /**
     * 見込項番を検索するために、検索条件を書き換え
     */
    private void overrideSearhMitItemCondition() throws Exception {
        // 見込項番の検索以外はこのメソッドの処理は行わない。
        //   ※以下のFLGは見込項番作成直後にこの画面で再検索が行われた際に設定されます。
        if (!"1".equals(s005Bean.getMikomiItemSearchFlg())) {
            return;
        }

        // 注番,項番,製番記号を保持しておく
        String orderItemFrom = s005Bean.getOrderItemFrom();
        String orderItemTo = s005Bean.getOrderItemTo();
        String orderNo = s005Bean.getOrderNo();
        String seiban = s005Bean.getSeiban();

        // 検索条件のデフォルトを設定
        initCondition();

        // 検索条件に項番,注番,製番記号を元に戻す。
        s005Bean.setOrderItemFrom(orderItemFrom);
        s005Bean.setOrderItemTo(orderItemTo);
        s005Bean.setOrderNo(orderNo);
        s005Bean.setSeiban(seiban);

        // カテゴリ(最終)(期間)はinitConditionで初期化されないので、ここで初期化しておく
        s005Bean.setSaCate1("");
        s005Bean.setSaCate2("");
        s005Bean.setSaCategory("");
        s005Bean.setKiCate1("");
        s005Bean.setKiCate2("");
        s005Bean.setKiCategory("");
    }

    /**
     * 操作ログ登録用dtoの取得
     */
    private OperationLog getOperationLogDto(Map<String, Object> condition) {
        OperationLog operationLog = operationLogService.getOperationLog();
        operationLog.setObjectType("KOUBAN");

        // 操作ログに記録の必要がない情報をmapから削除。
        Map<String, Object> cloneCondtion = new LinkedHashMap<>(condition);
        removeForm(cloneCondtion);

        String stringConditon = syuuekiUtils.changeStringCondtion(cloneCondtion);
        operationLog.setRemarks(stringConditon);

        return operationLog;
    }

    /**
     * 編集値保存処理
     * @param processFlg 処理区分(0:通常の保存処理 1:最新値更新)
     * @throws Exception
     */
    public void saveExecute(int processFlg) throws Exception {
        logger.info("S005Service#saveExecute");

        // 保存処理
        if(s005Bean.getViewFlg().equals("0")){
            saveKikan();
        } else {
            saveSaishu();
        }

        // 操作ログを出力
        OperationLog operationLog = setKikanOperationLog();
        operationLogService.insertOperationLogSearch(operationLog);

        // 再計算パッケージを実施
        reCalc(processFlg);

        // 不要な項番見込月データ(各見込月の項番が全てnull)のデータを削除
        deketeMikomiTukiEmptyNet();
    }

    /**
     * 項番一覧(期間)　保存処理
     */
    private void saveKikan() throws Exception{
        logger.info("S005Service#saveKikan");

        // 期間の取得
        String kan1 = s005Bean.getKikanForm();
        String kan2 = syuuekiUtils.calcKikan(kan1, 1);

        // 期間の前半および後半の年月を配列として取得
        String[] kikan1 = SyuuekiUtils.getKikanMonthAry(kan1);
        String[] kikan2   = SyuuekiUtils.getKikanMonthAry(kan2);
        Date kanjo = DateUtils.getDate(s005Bean.getTargetKanjoDate().replace("/", ""), "yyyyMM");

        // 画面のデータ行をループ
        for(int num = 0; num < s005Bean.getDispList().size(); num ++){
            Map<String, String> list = s005Bean.getDispList().get(num);

            // 編集されていない行は処理を行わない
            if(!"1".equals(s005Bean.getListSaveFlg()[num])){
                continue;
            }

            Map<String, Object> condition = getSaveCondition(list);
            condition.put("enkaFM", Utils.changeBigDecimal(list.get("fixedMikomiNet")));
            condition.put("dataKbn", "M");
            if(StringUtils.isNotEmpty(list.get("kariNetFlg"))){
                condition.put("kariNetFlg", list.get("kariNetFlg"));
            } else {
                condition.put("kariNetFlg", "0");
            }


            // 最終見込入力値の更新(見込項番なら製番、項番、品名も)
            syuGeNetItemTblViewFacade.updateSeibanSyuGeNetItem(condition);

            // 表示内容が売上の場合のみ更新
            if(s005Bean.getDispKbn().equals("1")){
                // 各月の入力値を登録
                for(int i = 0; i < 12; i++){
                    String net = "net" + String.valueOf(i+1);
                    if(i < 6){
                        if(!syuuekiUtils.getJissekiFlg(kanjo, kikan1[i])){
                            condition.put("syuekiYm", kikan1[i]);
                            condition.put("uriageNet", Utils.changeBigDecimal(list.get(net)));
                            int cnt = syuKiNetItemTukiTblFacade.updateNetItem(condition);
                            if(cnt == 0 && StringUtils.isNotEmpty(list.get(net))){
                                syuKiNetItemTukiTblFacade.insertNetItem(condition);
                            }
                            //syuKiNetItemTukiTblFacade.deleteNetItem(condition);
                        }
                    } else {
                        int j = i - 6;
                        if(!syuuekiUtils.getJissekiFlg(kanjo, kikan2[j])){
                            condition.put("syuekiYm", kikan2[j]);
                            condition.put("uriageNet", Utils.changeBigDecimal(list.get(net)));
                            int cnt = syuKiNetItemTukiTblFacade.updateNetItem(condition);
                            if(cnt == 0 && StringUtils.isNotEmpty(list.get(net))){
                                syuKiNetItemTukiTblFacade.insertNetItem(condition);
                            }
                            //syuKiNetItemTukiTblFacade.deleteNetItem(condition);
                        }
                    }
                }
            }

            // 見込項番なら他のテーブルの項番も更新
            if(StringUtils.isNotEmpty(list.get("mikomiFlg")) && StringUtils.equals(list.get("mikomiFlg"), "1")){
                updateKoban(condition);
            }
        }
    }

    /**
     * 項番一覧(最終)　保存処理
     */
    private void saveSaishu() {
        logger.info("S005Service#saveSaishu");

        int num = 0;
        String flg = StringUtils.defaultString(s005Bean.getPotenFlg(), "0");

        String[] dataKbnAry = {"JS", "JT", "MH", "SM", "PD", "PT", "PS"};
        for(Map<String, String> info: s005Bean.getDispList()){
            // 編集されていない行は処理を行わない
            if(!"1".equals(s005Bean.getListSaveFlg()[num])){
                num++;
                continue;
            }
            num++;

            Map<String, Object> condition = getSaveCondition(info);
            if(StringUtils.isNotEmpty(info.get("kakuteiFlg"))){
                condition.put("kakuteiFlg", info.get("kakuteiFlg"));
            } else {
                condition.put("kakuteiFlg", "0");
            }
            condition.put("enkaFM", Utils.changeBigDecimal(info.get("enkaFM")));

            if(s005Bean.getDispFlg().equals("0")){
                condition.put("currencyCodeFM", info.get("currencyCodeFM"));
                condition.put("rateFM", Utils.changeBigDecimal(info.get("rateFM")));
                condition.put("gaikaFM", Utils.changeBigDecimal(info.get("gaikaFM")));
            } else {
                condition.put("currencyCodeFM", ConstantString.currencyCodeEn);
                condition.put("rateFM", Utils.changeBigDecimal("1.00"));
                condition.put("gaikaFM", Utils.changeBigDecimal(info.get("enkaFM")));
            }


            // SYU_GE_NET_ITEM の更新
            syuGeNetItemTblViewFacade.updateSeibanSyuGeNetItem(condition);

            // SYU_SA_NET_ITEM の更新
            for (String dataKbn: dataKbnAry) {
                if((dataKbn.equals("PD") || dataKbn.equals("PT") || dataKbn.equals("PS")) && !flg.equals("1")){
                    continue;
                }
                condition.put("dataKbn", dataKbn);
                condition.put("enka", Utils.changeBigDecimal(info.get("enka" + dataKbn)));
                if(s005Bean.getDispFlg().equals("0")){
                    condition.put("currencyCode", info.get("currencyCode" + dataKbn));
                    condition.put("rate", Utils.changeBigDecimal(info.get("rate" + dataKbn)));
                    condition.put("gaika", Utils.changeBigDecimal(info.get("gaika" + dataKbn)));
                } else {
                    condition.put("currencyCode", ConstantString.currencyCodeEn);
                    condition.put("rate", Utils.changeBigDecimal("1.00"));
                    condition.put("gaika", Utils.changeBigDecimal(info.get("enka" + dataKbn)));
                }

                int cnt = syuSaNetItemTblFacade.updateNetItem(condition);
                if(cnt == 0){
                    syuSaNetItemTblFacade.insertNetItem(condition);
                }
            }

            // 見込項番なら他のテーブルの項番も更新
            if(StringUtils.isNotEmpty(info.get("mikomiFlg")) && StringUtils.equals(info.get("mikomiFlg"), "1")){
                updateKoban(condition);
            }

        }
    }

    /**
     * 不要な項番の見込月データ(全てのNETがNULLの月データ)を削除
     * ※これを削除しておかないと、案件詳細画面の[(収益)売上年月]が分割売ではないにも関わらず分割売上とみなされてしまい変更できない支障が発生するために処置を行っておく
     */
    private void deketeMikomiTukiEmptyNet() {
        Map<String, Object> condition = new HashMap<>();
        condition.put("ankenId", s005Bean.getAnkenId());
        condition.put("rirekiId", s005Bean.getRirekiId());
        condition.put("dataKbn", "M");

        SyuGeBukkenInfoTbl geEntity = syuGeBukenInfoTblFacade.findPk(condition);
        String kanjyoYm = kanjyoMstFacade.getNowKanjoDate(geEntity.getSalesClass());

        condition.put("kanjyoYm", kanjyoYm);

        syuKiNetItemTukiTblFacade.deleteNetItem(condition);
    }

    private void updateKoban(Map<String, Object> condition){
        // 見込項番の更新
        syuKiNetItemTukiTblFacade.updateSeibanSyuKiNetItem(condition);
        syuSaNetItemTblFacade.updateSeibanSyuSaNetItem(condition);
    }

    /**
     * 操作ログ登録用dtoの取得(項番一覧（期間）保存用)
     */
    private OperationLog setKikanOperationLog() {
        OperationLog operationLog = operationLogService.getOperationLog();
        operationLog.setOperationCode("SAVE_ONLINE");
        operationLog.setObjectId(20);
        operationLog.setObjectType("KOUBAN");

        return operationLog;
    }

    /**
     * 再計算パッケージ呼び出し
     * @param processFlg 処理区分(0:通常の保存処理 1:最新値更新)
     */
    public void reCalc(int processFlg) throws Exception{
        String recalProcFlg;

        if(s005Bean.getViewFlg().equals("0")){
            // 期間の場合
            recalProcFlg = "1";
        } else {
            // 最終の場合
            recalProcFlg = "3";
        }

        // 最新値更新パッケージ(TSIS様作成)呼出し
        if (processFlg == 1) {
            storedProceduresService.callUpdateNewData(s005Bean.getAnkenId(), s005Bean.getRirekiId(), s005Bean.getUpdateNewDataKbn());
            recalProcFlg = "4";  // 最新値更新パッケージ実行の場合、後続の再計算処理の処理フラグ(PROC_FLG)は"4"にする。
        }

        storedProceduresService.callAnkenRecalAuto(s005Bean.getAnkenId(), s005Bean.getRirekiId(), recalProcFlg);
    }

    /**
     * 見込項番削除処理
     * @throws Exception
     */
    public void deleteExecute() throws Exception {
        logger.info("S005Service#deleteExecute");

        String koban = "";
        Set<String> categoryCodeSet = new HashSet<>();
        for(String i : s005Bean.getCheckIndex()){
            int num = Integer.valueOf(i);
            Map<String, String> list = s005Bean.getDispList().get(num);
            Map<String, Object> condition = getDeleteCondition(list);

            if(!"".equals(koban)){
                koban = koban + "," + list.get("befOrderItem");
            } else {
                koban = list.get("befOrderItem");
            }

            // 2017/10/04NPC 削除前アイテムのカテゴリを取得
            SyuGeNetItemTbl itemEntity = syuGeNetItemTblViewFacade.getDispKoban(s005Bean.getAnkenId(), s005Bean.getRirekiId(), koban, s005Bean.getRirekiFlg());
            if (itemEntity != null) {
                String categoryCode = StringUtils.defaultString(itemEntity.getKiCategoryCode());
                if (StringUtils.isNotEmpty(categoryCode)) {
                    categoryCodeSet.add(categoryCode);
                }
            }

            //削除処理実行
            syuGeNetItemTblViewFacade.deleteKobanSyuGeNetItem(condition);
            syuKiNetItemTukiTblFacade.deleteKobanSyuKiNetItem(condition);
            syuSaNetItemTblFacade.deleteKobanSyuSaNetItem(condition);
        }

        // 2017/10/04NPC
        // 削除前アイテムのカテゴリの期間損益/最終見込NETの積み上げをクリア
        clearCategoryNetSummary(categoryCodeSet);

        // 操作ログを出力
        OperationLog operationLog = setDeleteOperationLog(koban);
        operationLogService.insertOperationLogSearch(operationLog);

        // 再計算処理実行
        reCalc(0);
    }

    /**
     * 削除対象カテゴリの期間損益/最終見込NETをクリアする(アイテム件数が0件の場合のみ)
     */
    private void clearCategoryNetSummary(Set<String> categoryCodeSet) {
        if (CollectionUtils.isEmpty(categoryCodeSet)) {
            return;
        }

        Map<String, Object> condition = new HashMap<>();
        condition.put("ankenId", s005Bean.getAnkenId());
        condition.put("rirekiId", s005Bean.getRirekiId());
        SyuGeBukkenInfoTbl geEntity = syuGeBukenInfoTblFacade.findPk(condition);

        String kanjyoYm = kanjyoMstFacade.getNowKanjoDate(geEntity.getSalesClass());

        Iterator<String> ite = categoryCodeSet.iterator();
        while (ite.hasNext()) {
            String categoryCode = ite.next();
            s018Service.clearCategoryNetSummary(s005Bean.getAnkenId(), s005Bean.getRirekiId(), categoryCode, kanjyoYm);
        }
    }

    /**
     * 操作ログ登録用dtoの取得(項番一覧（最終）項番削除用)
     */
    private OperationLog setDeleteOperationLog(String koban) {
        OperationLog operationLog = operationLogService.getOperationLog();
        operationLog.setOperationCode("DEL_KOUBAN");
        operationLog.setObjectId(20);
        operationLog.setObjectType("KOUBAN");
        operationLog.setRemarks(s005Bean.getAnkenId());
        operationLog.setRemarks2(koban);

        return operationLog;
    }

    private Map<String, Object> getDeleteCondition(Map<String, String> list){
        Map<String, Object> condition = new HashMap<>();
        condition.put("ankenId", s005Bean.getAnkenId());
        condition.put("rirekiId", s005Bean.getRirekiId());
        condition.put("orderNo", list.get("orderNo"));
        condition.put("orderItem", list.get("orderItem"));

        return condition;
    }

    private Map<String, Object> getSaveCondition(Map<String, String> list){
        Map<String, Object> condition = new HashMap<>();
        condition.put("ankenId", s005Bean.getAnkenId());
        condition.put("rirekiId", s005Bean.getRirekiId());
        condition.put("viewFlg", s005Bean.getViewFlg());
        condition.put("orderNo", list.get("orderNo"));
        condition.put("befOrderItem", list.get("befOrderItem"));
        condition.put("mikomiFlg", list.get("mikomiFlg"));
        if(StringUtils.isNotEmpty(list.get("mikomiFlg")) && StringUtils.equals(list.get("mikomiFlg"), "1")){
            condition.put("seiban", list.get("seiban"));
            condition.put("orderItem", list.get("orderItem"));
            condition.put("hinmei", list.get("hinmei"));
        }
        EntityUtils.setCreatedInfo(condition, loginUserInfo.getUserId());

        return condition;
    }

    /**
     * バリデーション処理
     * @throws Exception
     */
    public boolean validationExecute(ValidationInfoBean validationInfoBean) throws Exception {
        logger.info("S005Service#validationExecute");

        String koban = "";
        int num = 0;

        for(Map<String, String> items : s005Bean.getDispList()){
            if(!"1".equals(s005Bean.getListSaveFlg()[num]) || (items.get("orderItem").equals(items.get("befOrderItem")))){
                num++;
                continue;
            }
            num++;
            if(StringUtils.isNotEmpty(items.get("mikomiFlg")) && StringUtils.equals(items.get("mikomiFlg"), "1")){
                Map<String, Object> condition = getSaveCondition(items);
                int cnt = syuGeNetItemTblViewFacade.getKobanCount(condition);

                if(cnt != 0){
                    if(StringUtil.isNotEmpty(koban)){
                        koban = koban + "," + items.get("orderItem");
                    } else {
                        koban = items.get("orderItem");
                    }
                }
            }
        }

        if(StringUtils.isNotEmpty(koban)){
            Map<String, String> message = new HashMap<>();
            String msg = Label.validKoban.getLabel().replace("{0}", koban);
            message.put("errorMsg", msg);
            // エラーメッセージのセット
            validationInfoBean.setMessages(message);
            validationInfoBean.setSuccess(false);
        }

        return validationInfoBean.isSuccess();
    }

    /**
     * 操作ログ登録用dtoの取得(項番一覧（項番最終見込反映）)
     */
    private OperationLog setMikokmiSetOperationLog() {
        OperationLog operationLog = operationLogService.getOperationLog();
        operationLog.setOperationCode("MIKOMI_SET");
        operationLog.setObjectId(20);
        operationLog.setObjectType("KOUBAN");
        operationLog.setRemarks(s005Bean.getAnkenId());

        return operationLog;
    }

    // 2017/12/07 #013 #023 ADD 項番最終見込設定
    private Map<String, Object> getMikokmiSetCondition(Map<String, String> rec){
        Map<String, Object> condition = new HashMap<>();
        condition.put("ankenId", s005Bean.getAnkenId());
        condition.put("rirekiId", s005Bean.getRirekiId());
        condition.put("dataKbn", "M");
        condition.put("kanjyoYm", rec.get("kanjyoYm"));
        condition.put("orderNo", rec.get("orderNo"));
        condition.put("orderItem", rec.get("befOrderItem"));
        condition.put("syuekiYm", rec.get("syuekiYm"));
        condition.put("hatKbn", rec.get("hatKbn"));
        condition.put("mikomiFlg", rec.get("mikomiFlg"));
        condition.put("userId", loginUserInfo.getUserId());

        return condition;
    }

    /**
     * 2017/12/07 #013 #023 ADD 項番最終見込設定
     * 項番最終見込設定
     * @param actFlg (0:選択した分だけ 1:全部)
     * @throws Exception
     */
    public void mikokmiSetExecute(int actFlg) throws Exception {
        logger.info("S005Service#mikokmiSetExecute");
        Map<String, Object> pkCondition = new HashMap<>();
        pkCondition.put("ankenId", s005Bean.getAnkenId());
        pkCondition.put("rirekiId", s005Bean.getRirekiId());
        pkCondition.put("dataKbn", "M");
        SimpleDateFormat ymSd = new SimpleDateFormat("yyyyMM");
        SyuGeBukkenInfoTbl geEntity = syuGeBukenInfoTblFacade.findPk(pkCondition);
        String kanjyoYm = kanjyoMstFacade.getNowKanjoDate(geEntity.getSalesClass());
        String syuekiYm = ymSd.format(geEntity.getUriageEnd());

        if (actFlg == 0) {
            for(String i : s005Bean.getCheckIndex()){
                int num = Integer.valueOf(i);
                Map<String, String> rec = s005Bean.getDispList().get(num);
                rec.put("kanjyoYm", kanjyoYm);
                rec.put("syuekiYm", syuekiYm);
                Map<String, Object> condition = getMikokmiSetCondition(rec);
                
                updateHatToMikomi(condition);
            }
        } else if (actFlg == 1) {
            // 検索条件をセット
            setDispInfoBean();
            if(!s005Bean.getViewFlg().equals("1")){
                setKikan();
            }
            Map<String, Object> searchCondition = getCondition();
            searchCondition.put("kikanFlg", s005Bean.getKikanFlg());
            searchCondition.put("saishuFlg", s005Bean.getSaishuFlg());
            searchCondition.put("listFlg", "0");
            if(s005Bean.getViewFlg().equals("0")){
                s005Bean.setKikanFlg(1);
                s005Bean.setSaishuFlg(0);
            } else {
                s005Bean.setKikanFlg(0);
                s005Bean.setSaishuFlg(1);
                searchCondition.put("editFlg", s005Bean.getEditFlg());
            }
            List<SyuGeNetItemTblView> list = syuGeNetItemTblViewFacade.getItemList(searchCondition);
            for(SyuGeNetItemTblView target : list){
                Map<String, String> rec = new HashMap<>();
                rec.put("orderNo", target.getOrderNo());
                rec.put("befOrderItem", target.getOrderItem());
                rec.put("hatKbn", target.getHatKbn());
                rec.put("mikomiFlg", target.getMikomiFlg());
                rec.put("kanjyoYm", kanjyoYm);
                rec.put("syuekiYm", syuekiYm);
                Map<String, Object> condition = getMikokmiSetCondition(rec);
                
                updateHatToMikomi(condition);
            }
        }

        OperationLog operationLog = setMikokmiSetOperationLog();
        operationLogService.insertOperationLogSearch(operationLog);

        reCalc(0); // 通常保存

        // NULLを削除
        deketeMikomiTukiEmptyNet();
    }

    /**
     * 見込月に発番値を反映する処理を実施する
     */
    private void updateHatToMikomi(Map<String, Object> condition) {
        String hatKbn = StringUtils.defaultString((String)condition.get("hatKbn"));
        String mikomiFlg = StringUtils.defaultString((String)condition.get("mikomiFlg"));
        
        // 発番取消,見込項番は反映処理の対象外とする
        if (!"1".equals(mikomiFlg)) {
            // 見込をNULLでアップデート
            syuKiNetItemTukiTblFacade.updateClearNetItemMikomiAll(condition);
        }

        // 発番取消,見込項番は反映処理の対象外とする
        if (!"D".equals(hatKbn) && !"1".equals(mikomiFlg)) {
            // 計算更新
            syuKiNetItemTukiTblFacade.mergeMikomiSet(condition);
        }
    }

}
