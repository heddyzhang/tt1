package jp.co.toshiba.hby.pspromis.syuueki.entity;

import java.io.Serializable;
import java.math.BigDecimal;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.validation.constraints.NotNull;

/**
 *
 * @author sano
 */
@Entity
public class CostList implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @NotNull
    @Column(name = "ANKEN_ID")
    private String ankenId;

    @Id
    @Column(name = "CATEGORY_CODE")
    private String categoryCode;
    @Id
    @Column(name = "CATEGORY_KBN1")
    private String categoryKbn1;
    @Id
    @Column(name = "CATEGORY_KBN2")
    private String categoryKbn2;
    @Column(name = "CATEGORY_NAME1")
    private String categoryName1;
    @Column(name = "CATEGORY_NAME2")
    private String categoryName2;
    @Column(name = "URIAGE_NET_JS")
    private BigDecimal uriageNetJs;
    @Column(name = "URIAGE_NET_JT")
    private BigDecimal uriageNetJt;
    @Column(name = "URIAGE_NET_MH")
    private BigDecimal uriageNetMh;
    @Column(name = "URIAGE_NET_SM")
    private BigDecimal uriageNetSm;
    @Column(name = "URIAGE_NET_ST")
    private BigDecimal uriageNetSt;
    @Column(name = "URIAGE_NET_HB")
    private BigDecimal uriageNetHb;
    @Column(name = "URIAGE_NET_TR")
    private BigDecimal uriageNetTr;
    @Column(name = "URIAGE_NET_FM")
    private BigDecimal uriageNetFm;
    @Column(name = "URIAGE_NET_DIFF")
    private BigDecimal uriageNetDiff;
    @Column(name = "URIAGE_NET_PD")
    private BigDecimal uriageNetPd;
    @Column(name = "URIAGE_NET_PT")
    private BigDecimal uriageNetPt;
    @Column(name = "URIAGE_NET_PS")
    private BigDecimal uriageNetPs;
    @Column(name = "URIAGE_NET_PREV")
    private BigDecimal uriageNetPrev;
    @Column(name = "ITEM_FLG_JS")
    private String itemFlgJs;
    @Column(name = "ITEM_FLG_JT")
    private String itemFlgJt;
    @Column(name = "ITEM_FLG_MH")
    private String itemFlgMh;
    @Column(name = "ITEM_FLG_SM")
    private String itemFlgSm;
    @Column(name = "ITEM_FLG_ST")
    private String itemFlgSt;
    @Column(name = "ITEM_FLG_HB")
    private String itemFlgHb;
    @Column(name = "ITEM_FLG_TR")
    private String itemFlgTr;
    @Column(name = "ITEM_FLG_FM")
    private String itemFlgFm;
    @Column(name = "ITEM_FLG_DIFF")
    private String itemFlgDiff;
    @Column(name = "ITEM_FLG_PD")
    private String itemFlgPd;
    @Column(name = "ITEM_FLG_PT")
    private String itemFlgPt;
    @Column(name = "ITEM_FLG_PS")
    private String itemFlgPs;
    @Column(name = "ITEM_FLG_PREV")
    private String itemFlgPrev;
    @Column(name = "MITFLG")
    private String mitFlg;

    public CostList() {
    }

    public String getAnkenId() {
        return this.ankenId;
    }

    public void setAnkenId(String ankenId) {
        this.ankenId = ankenId;
    }

    public String getCategoryCode() {
        return this.categoryCode;
    }

    public void setCategoryCode(String categoryCode) {
        this.categoryCode = categoryCode;
    }

    public String getCategoryKbn1() {
        return this.categoryKbn1;
    }

    public void setCategoryKbn1(String categoryKbn1) {
        this.categoryKbn1 = categoryKbn1;
    }

    public String getCategoryKbn2() {
        return this.categoryKbn2;
    }

    public void setCategoryKbn2(String categoryKbn2) {
        this.categoryKbn2 = categoryKbn2;
    }

    public String getCategoryName1() {
        return this.categoryName1;
    }

    public void setCategoryName1(String categoryName1) {
        this.categoryName1 = categoryName1;
    }

    public String getCategoryName2() {
        return this.categoryName2;
    }

    public void setCategoryName2(String categoryName2) {
        this.categoryName2 = categoryName2;
    }

    public BigDecimal getUriageNetJs() {
        return this.uriageNetJs;
    }

    public void setUriageNetJs(BigDecimal uriageNetJs) {
        this.uriageNetJs = uriageNetJs;
    }

    public BigDecimal getUriageNetJt() {
        return this.uriageNetJt;
    }

    public void setUriageNetJt(BigDecimal uriageNetJt) {
        this.uriageNetJt = uriageNetJt;
    }

    public BigDecimal getUriageNetMh() {
        return this.uriageNetMh;
    }

    public void setUriageNetMh(BigDecimal uriageNetMh) {
        this.uriageNetMh = uriageNetMh;
    }

    public BigDecimal getUriageNetSm() {
        return this.uriageNetSm;
    }

    public void setUriageNetSm(BigDecimal uriageNetSm) {
        this.uriageNetSm = uriageNetSm;
    }

    public BigDecimal getUriageNetSt() {
        return this.uriageNetSt;
    }

    public void setUriageNetSt(BigDecimal uriageNetSt) {
        this.uriageNetSt = uriageNetSt;
    }

    public BigDecimal getUriageNetHb() {
        return this.uriageNetHb;
    }

    public void setUriageNetHb(BigDecimal uriageNetHb) {
        this.uriageNetHb = uriageNetHb;
    }

    public BigDecimal getUriageNetTr() {
        return this.uriageNetTr;
    }

    public void setUriageNetTr(BigDecimal uriageNetTr) {
        this.uriageNetTr = uriageNetTr;
    }

    public BigDecimal getUriageNetFm() {
        return this.uriageNetFm;
    }

    public void setUriageNetFm(BigDecimal uriageNetFm) {
        this.uriageNetFm = uriageNetFm;
    }

    public BigDecimal getUriageNetDiff() {
        return this.uriageNetDiff;
    }

    public void setUriageNetDiff(BigDecimal uriageNetDiff) {
        this.uriageNetDiff = uriageNetDiff;
    }

    public BigDecimal getUriageNetPd() {
        return uriageNetPd;
    }

    public void setUriageNetPd(BigDecimal uriageNetPd) {
        this.uriageNetPd = uriageNetPd;
    }

    public BigDecimal getUriageNetPt() {
        return uriageNetPt;
    }

    public void setUriageNetPt(BigDecimal uriageNetPt) {
        this.uriageNetPt = uriageNetPt;
    }

    public BigDecimal getUriageNetPs() {
        return uriageNetPs;
    }

    public void setUriageNetPs(BigDecimal uriageNetPs) {
        this.uriageNetPs = uriageNetPs;
    }

    public BigDecimal getUriageNetPrev() {
        return uriageNetPrev;
    }

    public void setUriageNetPrev(BigDecimal uriageNetPrev) {
        this.uriageNetPrev = uriageNetPrev;
    }

    public String getItemFlgJs() {
        return itemFlgJs;
    }

    public void setItemFlgJs(String itemFlgJs) {
        this.itemFlgJs = itemFlgJs;
    }

    public String getItemFlgJt() {
        return itemFlgJt;
    }

    public void setItemFlgJt(String itemFlgJt) {
        this.itemFlgJt = itemFlgJt;
    }

    public String getItemFlgMh() {
        return itemFlgMh;
    }

    public void setItemFlgMh(String itemFlgMh) {
        this.itemFlgMh = itemFlgMh;
    }

    public String getItemFlgSm() {
        return itemFlgSm;
    }

    public void setItemFlgSm(String itemFlgSm) {
        this.itemFlgSm = itemFlgSm;
    }

    public String getItemFlgSt() {
        return itemFlgSt;
    }

    public void setItemFlgSt(String itemFlgSt) {
        this.itemFlgSt = itemFlgSt;
    }

    public String getItemFlgHb() {
        return itemFlgHb;
    }

    public void setItemFlgHb(String itemFlgHb) {
        this.itemFlgHb = itemFlgHb;
    }

    public String getItemFlgTr() {
        return itemFlgTr;
    }

    public void setItemFlgTr(String itemFlgTr) {
        this.itemFlgTr = itemFlgTr;
    }

    public String getItemFlgFm() {
        return itemFlgFm;
    }

    public void setItemFlgFm(String itemFlgFm) {
        this.itemFlgFm = itemFlgFm;
    }

    public String getItemFlgDiff() {
        return itemFlgDiff;
    }

    public void setItemFlgDiff(String itemFlgDiff) {
        this.itemFlgDiff = itemFlgDiff;
    }

    public String getItemFlgPd() {
        return itemFlgPd;
    }

    public void setItemFlgPd(String itemFlgPd) {
        this.itemFlgPd = itemFlgPd;
    }

    public String getItemFlgPt() {
        return itemFlgPt;
    }

    public void setItemFlgPt(String itemFlgPt) {
        this.itemFlgPt = itemFlgPt;
    }

    public String getItemFlgPs() {
        return itemFlgPs;
    }

    public void setItemFlgPs(String itemFlgPs) {
        this.itemFlgPs = itemFlgPs;
    }

    public String getItemFlgPrev() {
        return itemFlgPrev;
    }

    public void setItemFlgPrev(String itemFlgPrev) {
        this.itemFlgPrev = itemFlgPrev;
    }

    public String getMitFlg() {
        return mitFlg;
    }

    public void setMitFlg(String mitFlg) {
        this.mitFlg = mitFlg;
    }
}
