package jp.co.toshiba.hby.pspromis.syuueki.bean;

//import java.util.ArrayList;
//import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.enterprise.context.RequestScoped;
import javax.inject.Named;
import jp.co.toshiba.hby.pspromis.syuueki.entity.S003TargetYm;
import jp.co.toshiba.hby.pspromis.syuueki.entity.S003UriageSpRowInfo;
import jp.co.toshiba.hby.pspromis.syuueki.entity.SyuKiNetCateTitleTbl;
import lombok.Getter;
import lombok.Setter;

/**
 *
 * @author sano
 */
@Named(value = "s003Bean")
@RequestScoped
@Getter @Setter
public class S003Bean extends AbstractBean {

    /**
     * 円貨表示単位
     */
    private Integer jpyUnit = 1;

    private String jpyUnitKbn = "1";

    /**
     * 一括見込SP・連番
     */
    private String ikkatsuSpRenban;

    /**
     * 一括見込SP・連番SEQ
     */
    private String ikkatsuSpRenbanSeq;

    /**
     * データ編集 可否FLG(編集ボタン等のデータ更新系機能が利用可能か否かの判断に利用)
     */
    private String editAuthFlg = "0";

    /**
     * 受注管理・受注SP・内訳ツリー展開openフラグ
     */
    private String juchuSpListOpenFlg = "1";

    /**
     * 受注管理・受注NET・内訳ツリー展開openフラグ
     */
    private String juchuNetListOpenFlg = "1";

    /**
     * 売上高(SP)・内訳ツリー展開openフラグ
     */
    private String spListOpenFlg = "1";

    /**
     * 売上管理・受注通知一覧ツリー展開openフラグ(デフォルトは閉じた状態にしておく)
     */
    private String juchuTuchiListOpenFlg = "0";

    /**
     * 売上原価(売上原価)・内訳ツリー展開openフラグ
     */
    private String netListOpenFlg = "1";

    /**
     * 表示対象年月
     */
    private List<S003TargetYm> targetYm;

    /**
     * 表示対象通貨
     */
    private List<String> targetCurrencyList;

    /**
     * 見出し
     */
    //private ArrayList<Map<String,String>> titleList;

    /**
     * 売上高合計
     */
    //private HashMap<String, String> totalSales;

    /**
     * 売上高合計
     */
    //private ArrayList<String> totalSalesYm;

    /**
     * 売上高詳細
     */
    //private List<HashMap<String, String>> salesList;

    /**
     * 売上高詳細
     */
    //private ArrayList<ArrayList<String>> salesListYm;

    /**
     * 売上原価合計
     */
    //private HashMap<String, String> totalSalesCost;

    /**
     * 売上高合計
     */
    //private ArrayList<String> totalSalesCostYm;

    /**
     * 売上原価詳細
     */
    //private List<HashMap<String, String>> salesCostList;

    /**
     * 売上原価詳細
     */
    //private ArrayList<ArrayList<String>> salesCostListYm;

    /**
     * 回収金額
     */
    //private List<HashMap<String, String>> recoveryAmountList;

    /**
     * 回収金額
     */
    //private ArrayList<ArrayList<String>> recoveryAmountListYm;
    /**
     * 累計回収金額
     */
    //private ArrayList<ArrayList<String>> ruikeiRecoveryAmountListYm;
    /**
     * 未回収金額
     */
    //private ArrayList<ArrayList<String>> notRecoveryAmountListYm;

    /**
     * 一括カテゴリNET情報
     */
    private Map<String, Object> ikkatsuCategoryInfo;

    /**
     * 受注SP/NET 合計
     */
    private Map<String, Object> jyuchuInfoTotal;

    /**
     * 受注レート/SP データ(Key:通貨 value:通貨毎の各月の受注SP等が格納されたオブジェクト(Map))
     */
    private Map<String, Object> jyuchuSpInfo;

    /**
     * 受注NET(一括見込NET)
     */
    private Map<String, Object> jyuchuNetInfo;

    /**
     * 粗利
     */
    //private HashMap<String, String> arari;

    /**
     * 粗利
     */
    //private ArrayList<String> arariYm;

    /**
     * M率
     */
    //private HashMap<String, String> mrate;

    /**
     * M率
     */
    //private ArrayList<String> mrateYm;

    ////// 売上管理SP情報 //////
    /**
     * 売上管理SP Total行情報
     */
    Map<String, Object> uriageSpTotalInfo;

    /**
     * 売上管理SP・縦情報
     */
    private List<S003UriageSpRowInfo> uriageSpRowInfoList;

    /**
     * 売上管理SP・通貨毎の合計情報(key:通貨コード value:通貨毎の各カテゴリ・各月のSP)
     */
    private Map<String, Object> uriageSpInfoSum;

    /**
     * 売上管理SP・通貨毎の一括SP情報(key:通貨コード value:通貨毎の各カテゴリ・各月のSP)
     */
    private Map<String, Object> uriageIkkatsuSpInfo;

    /**
     * 売上管理SP・受注通知SP情報(key:通貨コード_連番 value:通貨、連番毎の各カテゴリ・各月のSP)
     */
    private Map<String, Object> uriageSpInfoJyuchuTuti;


    ////// 売上管理NET情報 //////
    /**
     * 売上管理NET・Total行情報(key:各列毎のNETキー value:NET値)
     */
    private Map<String, Object> uriageNetTotalInfo;

    /**
     * 売上管理NET内訳・カテゴリ情報(縦)
     */
    private List<SyuKiNetCateTitleTbl> uriageNetCateList;

    /**
     * 売上管理NET内訳・カテゴリ・各データ区分毎のNET情報(key:カテゴリコード_カテゴリ区分1_カテゴリ区分2 value:NET情報)
     */
    private Map<String, Object> uriageNetCateInfo;

    ////// 回収情報 //////
    /**
     * (2017A)削除
     * 回収情報(key:通貨 value:通貨毎の各回収・累計回収・未回収情報格納オブジェクト(Map))
     */
    //private Map<String, Object> kaisyuCurInfo;
    // 2017/11/20 #072 ADD 回収Total行追加
    private Map<String, Object> kaisyuTotalInfo;

    /**
     * 回収情報(key:通貨 value:通貨毎の各回収・累計回収・未回収情報格納オブジェクト(Map))
     */
    private List<Map<String, Object>> kaisyuInfoList;



    ////////////////// 受注管理 保存時関連情報(S) /////////////////////
    ////// 最終見込SP //////
    /**
     * 受注管理/最終見込　処理対象の通貨コード
     */
    private String[] jyuchuCurF;

    /**
     * 受注管理/最終見込 受注レート
     */
    private String[] jyuchuSpRateCurF;

    /**
     * 受注管理/最終見込 受注金額(SP)
     */
    private String[] jyuchuSpCurF;

    ////// 最終見込NET //////
    /**
     * 受注管理/最終見込 受注NET(一括受注NETのカテゴリコード)
     */
    private String[] jyuchuNetCategoryCodeF;

    /**
     * 受注管理/最終見込 受注NET(一括受注NETのカテゴリ区分1)
     */
    private String[] jyuchuNetCategoryKbn1F;

    /**
     * 受注管理/最終見込 受注NET(一括受注NETのカテゴリ区分2)
     */
    private String[] jyuchuNetCategoryKbn2F;

    /**
     * 受注管理/最終見込 受注NET(一括見込NETのNET)
     */
    private String[] jyuchuNetF;

    ////// 各見込月 KEY情報 //////
    /**
     * 受注管理/各見込月 年月(編集対象項目)
     */
    private String[] jyuchuSyuekiYmM;

    /**
     * 受注管理/各見込月 年月(画面初期表示時のデータ)
     */
    private String[] orgJyuchuSyuekiYmM;

    /**
     * 受注管理/各見込月 削除FLG
     */
    private String[] jyuchuSyuekiYmMDelFlg;

    /**
     * 受注管理/各見込月 データ区分
     */
    private String[] jyuchuDataKbnM;

    ////// 各見込月SP //////
    /**
     * 受注管理/各見込月 通貨コード
     */
    private String[] jyuchuCurM;

    /**
     * 受注管理/各見込月 受注レート
     */
    private String[] jyuchuSpRateCurM;

    /**
     * 受注管理/各見込月 受注金額
     */
    private String[] jyuchuSpCurM;

    ////// 各見込月NET //////
    /**
     * 受注管理/最終見込 受注NET(一括受注NETのカテゴリコード)
     */
    private String[] jyuchuNetCategoryCodeM;

    /**
     * 受注管理/最終見込 受注NET(一括受注NETのカテゴリ区分1)
     */
    private String[] jyuchuNetCategoryKbn1M;

    /**
     * 受注管理/各見込月 受注NET(一括受注NETのカテゴリ区分2)
     */
    private String[] jyuchuNetCategoryKbn2M;

    /**
     * 受注管理/各見込月 一括受注見込NET
     */
    private String[] jyuchuNetM;
    ////////////////// 受注管理 保存時関連情報(E) /////////////////////


    ////////////////// 売上管理 保存時関連情報(S) /////////////////////
    ////// 最終見込SP //////
    /**
     * 売上管理/最終見込SP　処理対象の通貨コード
     */
    private String[] uriageCurF;

    /**
     * 売上管理/最終見込SP　処理対象の連番
     */
    private String[] uriageRenbanF;

    /**
     * 売上管理/最終見込SP　処理対象の連番SEQ
     */
    private String[] uriageRenbanSeqF;

    /**
     * 売上管理/最終見込 売上レート
     */
    private String[] uriageRateF_Currency;

    /**
     * 売上管理/最終見込SP 売上SP
     */
    private String[] uriageSpF;

    ////// 最終見込NET //////
    /**
     * 売上管理/最終見込NET カテゴリコード
     */
    private String[] uriageCategoryCodeF;

    /**
     * 売上管理/最終見込NET カテゴリ区分1
     */
    private String[] uriageCategoryKbn1F;

    /**
     * 売上管理/最終見込NET カテゴリ区分2
     */
    private String[] uriageCategoryKbn2F;

    /**
     * 売上管理/最終見込NET カテゴリ毎のNET
     */
    private String[] uriageNetF;

    ////// 各見込月 KEY情報 //////
    /**
     * 売上管理 見込月(入力)
     */
    private String[] uriageSyuekiYmM;

    /**
     * 売上管理 見込月(初期値)
     */
    private String[] orgUriageSyuekiYmM;

    /**
     * 売上管理 見込月(画面での削除FLG)
     */
    private String[] uriageSyuekiYmMDelFlg;

    /**
     * 売上管理 見込月(データ区分)
     */
    private String[] uriageDataKbnM;

    ////// 各見込月SP //////
    /**
     * 売上管理/各見込月 通貨コード
     */
    private String[] uriageCurM;

    /**
     * 売上管理/各見込月 連番
     */
    private String[] uriageRenbanM;

    /**
     * 売上管理/各見込月 売上レート
     */
    private String[] uriageRateM_Currency;

    /**
     * 売上管理/各見込月 売上SP
     */
    private String[] uriageSpM;

    ////// 各見込月NET //////
    /**
     * 売上管理/各見込月 カテゴリコード
     */
    private String[] uriageCategoryCodeM;

    /**
     * 売上管理/各見込月 カテゴリ区分1
     */
    private String[] uriageCategoryKbn1M;

    /**
     * 売上管理/各見込月 カテゴリ区分2
     */
    private String[] uriageCategoryKbn2M;

    /**
     * 売上管理/各見込月 カテゴリ毎のNET
     */
    private String[] uriageNetM;
    ////////////////// 売上管理 保存時関連情報(E) /////////////////////



    ////// 各見込月SP //////
    /**
     * 売上管理 見込月(入力)
     */
    private String[] uriageSyuekiYmJ;


    /**
     * 売上管理 見込月(データ区分)
     */
    private String[] uriageDataKbnJ;

    /**
     * 売上管理/各見込月 通貨コード
     */
    private String[] kaisyuCurJ;

    /**
     * 売上管理/各見込月 通貨コード
     */
    private String[] kaisyuCurM;

    /**
     * 売上管理/各見込月 回収金額
     */
    private String[] kaisyuM;

    /**
     * 売上管理/各見込月 回収金額
     */
    private String[] kaisyuJ;

    /**
     * 売上管理/各見込月 未回収金額
     */
    private String[] kaisyuRuiM;

    /**
     *
     * 売上管理/各見込月 回収金額
     */
    private String[] kaisyuMiM;
    ////////////////// 売上管理 保存時関連情報(E) /////////////////////


    ////////////////// 回収管理 保存時関連情報(S) /////////////////////
    /**
     * 回収管理/各年月の入力値
     */
    private String[] kaisyuSyuekiYmM;

    /**
     * 回収管理/各年月(入力変更前の年月)
     */
    private String[] orgKaisyuSyuekiYmM;

    /**
     * 回収管理/各年月のデータ区分(J:実績月 M;見込月)
     * ※回収年月変更前のデータ区分が入っている
     */
    private String[] orgKaisyuDataKbnM;

    /**
     * 回収管理/各年月(画面で削除処理が行われたかどうかの判断)
     * 1:削除処理が行われた
     */
    private String[] kaisyuSyuekiYmMDelFlg;

//    /**
//     * 回収管理/各年月のデータ区分(J:実績月 M;見込月)
//     */
//    private String[] kaisyuDataKbnM;

    /**
     * 回収管理/各年月の回収金額入力欄の対象通貨
     */
    private String[] kaisyuCur;

    /**
     * 回収管理/各年月の税区分
     */
    private String[] kaisyuZeiKbn;

    /**
     * 回収管理/各年月の金種区分
     */
    private String[] kaisyuKinsyuKbn;

    /**
     * 回収管理/各年月の回収区分(通常/前受け)
     */
    private String[] kaisyuKbn;


    /**
     * 回収管理/各年月・通貨の回収金額入力欄
     */
    private String[] kaisyu;

    /**
     * 回収管理/各年月・通貨の回収金額(円貨)入力欄
     */
    private String[] kaisyuEnka;
    ////////////////// 回収管理 保存時関連情報(E) /////////////////////


    ////////////////// 見込レート反映処理(S) /////////////////////
    /**
     * 見込レート反映時 見込レート情報Map
     *   (内Map = key:value(currencyCode:通貨 syuekiYm:見込月 rate:レート))
     */
    //private List<Map<String, String>> mikomiRateInfoList;

    /**
     * 見込レート反映時 見込レート情報Map
     *   (外Map = key:通貨 value:対象通貨の各見込月のレート情報(Map))
     *   (内Map = key:見込月 value:レート)
     */
    private Map<String, Map<String, String>> mikomiRateInfo;


    /**
     * 参照・編集FLG(0:参照 1:編集)
     */
    private String editFlg = "0";

    /**
     * 受注売上バランスFLG(0:通常の保存処理 1:受注売上バランス処理)
     */
    private String saveBalanceFlg = "0";

    /**
     * 案件の備考
     */
    private String bikou;

    /**
     * 勘定年月
     */
    private String kanjyoYm;

    /**
     * 表示する勘定年月データの件数(2件であれば実績と見込を表示するとみなす)
     */
    private Integer kanjyoYmCount = 0;

    /**
     * 最新値更新区分(1:発番取込 2:契約取込 3:見積取込)
     */
    private String updateNewDataKbn;

    /**
     * Creates a new instance of S003Bean
     */
    public S003Bean() {
    }

    public Integer getJpyUnit() {
        return jpyUnit;
    }

    public void setJpyUnit(Integer jpyUnit) {
        this.jpyUnit = jpyUnit;
    }

    public String getSpListOpenFlg() {
        return spListOpenFlg;
    }

    public void setSpListOpenFlg(String spListOpenFlg) {
        this.spListOpenFlg = spListOpenFlg;
    }

    public String getNetListOpenFlg() {
        return netListOpenFlg;
    }

    public void setNetListOpenFlg(String netListOpenFlg) {
        this.netListOpenFlg = netListOpenFlg;
    }

    public List<S003TargetYm> getTargetYm() {
        return targetYm;
    }

    public void setTargetYm(List<S003TargetYm> targetYm) {
        this.targetYm = targetYm;
    }

//    public ArrayList<Map<String,String>> getTitleList() {
//        return titleList;
//    }
//
//    public void setTitleList(ArrayList<Map<String,String>> titleList) {
//        this.titleList = titleList;
//    }
//
//    public HashMap<String, String> getTotalSales() {
//        return totalSales;
//    }
//
//    public void setTotalSales(HashMap<String, String> totalSales) {
//        this.totalSales = totalSales;
//    }
//
//    public ArrayList<String> getTotalSalesYm() {
//        return totalSalesYm;
//    }
//
//    public void setTotalSalesYm(ArrayList<String> totalSalesYm) {
//        this.totalSalesYm = totalSalesYm;
//    }
//
//    public List<HashMap<String, String>> getSalesList() {
//        return salesList;
//    }
//
//    public void setSalesList(List<HashMap<String, String>> salesList) {
//        this.salesList = salesList;
//    }
//
//    public ArrayList<ArrayList<String>> getSalesListYm() {
//        return salesListYm;
//    }
//
//    public void setSalesListYm(ArrayList<ArrayList<String>> salesListYm) {
//        this.salesListYm = salesListYm;
//    }
//
//    public HashMap<String, String> getTotalSalesCost() {
//        return totalSalesCost;
//    }
//
//    public void setTotalSalesCost(HashMap<String, String> totalSalesCost) {
//        this.totalSalesCost = totalSalesCost;
//    }
//
//    public ArrayList<String> getTotalSalesCostYm() {
//        return totalSalesCostYm;
//    }
//
//    public void setTotalSalesCostYm(ArrayList<String> totalSalesCostYm) {
//        this.totalSalesCostYm = totalSalesCostYm;
//    }
//
//    public List<HashMap<String, String>> getSalesCostList() {
//        return salesCostList;
//    }
//
//    public void setSalesCostList(List<HashMap<String, String>> salesCostList) {
//        this.salesCostList = salesCostList;
//    }
//
//    public ArrayList<ArrayList<String>> getSalesCostListYm() {
//        return salesCostListYm;
//    }
//
//    public void setSalesCostListYm(ArrayList<ArrayList<String>> salesCostListYm) {
//        this.salesCostListYm = salesCostListYm;
//    }
//
//    public List<HashMap<String, String>> getRecoveryAmountList() {
//        return recoveryAmountList;
//    }
//
//    public void setRecoveryAmountList(List<HashMap<String, String>> recoveryAmountList) {
//        this.recoveryAmountList = recoveryAmountList;
//    }
//
//    public ArrayList<ArrayList<String>> getRecoveryAmountListYm() {
//        return recoveryAmountListYm;
//    }
//
//    public void setRecoveryAmountListYm(ArrayList<ArrayList<String>> recoveryAmountListYm) {
//        this.recoveryAmountListYm = recoveryAmountListYm;
//    }
//
//    public ArrayList<ArrayList<String>> getRuikeiRecoveryAmountListYm() {
//        return ruikeiRecoveryAmountListYm;
//    }
//
//    public void setRuikeiRecoveryAmountListYm(ArrayList<ArrayList<String>> ruikeiRecoveryAmountListYm) {
//        this.ruikeiRecoveryAmountListYm = ruikeiRecoveryAmountListYm;
//    }
//
//    public ArrayList<ArrayList<String>> getNotRecoveryAmountListYm() {
//        return notRecoveryAmountListYm;
//    }
//
//    public void setNotRecoveryAmountListYm(ArrayList<ArrayList<String>> notRecoveryAmountListYm) {
//        this.notRecoveryAmountListYm = notRecoveryAmountListYm;
//    }
//
//    public HashMap<String, String> getArari() {
//        return arari;
//    }
//
//    public void setArari(HashMap<String, String> arari) {
//        this.arari = arari;
//    }
//
//    public ArrayList<String> getArariYm() {
//        return arariYm;
//    }
//
//    public void setArariYm(ArrayList<String> arariYm) {
//        this.arariYm = arariYm;
//    }
//
//    public HashMap<String, String> getMrate() {
//        return mrate;
//    }
//
//    public void setMrate(HashMap<String, String> mrate) {
//        this.mrate = mrate;
//    }
//
//    public ArrayList<String> getMrateYm() {
//        return mrateYm;
//    }
//
//    public void setMrateYm(ArrayList<String> mrateYm) {
//        this.mrateYm = mrateYm;
//    }

    public String getEditFlg() {
        return editFlg;
    }

    public void setEditFlg(String editFlg) {
        this.editFlg = editFlg;
    }

    public String getJuchuSpListOpenFlg() {
        return juchuSpListOpenFlg;
    }

    public void setJuchuSpListOpenFlg(String juchuSpListOpenFlg) {
        this.juchuSpListOpenFlg = juchuSpListOpenFlg;
    }

    public String getJuchuNetListOpenFlg() {
        return juchuNetListOpenFlg;
    }

    public void setJuchuNetListOpenFlg(String juchuNetListOpenFlg) {
        this.juchuNetListOpenFlg = juchuNetListOpenFlg;
    }

    public String getEditAuthFlg() {
        return editAuthFlg;
    }

    public void setEditAuthFlg(String editAuthFlg) {
        this.editAuthFlg = editAuthFlg;
    }

    public List<String> getTargetCurrencyList() {
        return targetCurrencyList;
    }

    public void setTargetCurrencyList(List<String> targetCurrencyList) {
        this.targetCurrencyList = targetCurrencyList;
    }

    public Map<String, Object> getJyuchuSpInfo() {
        return jyuchuSpInfo;
    }

    public void setJyuchuSpInfo(Map<String, Object> jyuchuSpInfo) {
        this.jyuchuSpInfo = jyuchuSpInfo;
    }

    public String getJpyUnitKbn() {
        return jpyUnitKbn;
    }

    public void setJpyUnitKbn(String jpyUnitKbn) {
        this.jpyUnitKbn = jpyUnitKbn;
    }

    public Map<String, Object> getJyuchuInfoTotal() {
        return jyuchuInfoTotal;
    }

    public void setJyuchuInfoTotal(Map<String, Object> jyuchuInfoTotal) {
        this.jyuchuInfoTotal = jyuchuInfoTotal;
    }

    public Map<String, Object> getJyuchuNetInfo() {
        return jyuchuNetInfo;
    }

    public void setJyuchuNetInfo(Map<String, Object> jyuchuNetInfo) {
        this.jyuchuNetInfo = jyuchuNetInfo;
    }

    public String[] getJyuchuCurF() {
        return jyuchuCurF;
    }

    public void setJyuchuCurF(String[] jyuchuCurF) {
        this.jyuchuCurF = jyuchuCurF;
    }

    public String[] getJyuchuSpRateCurF() {
        return jyuchuSpRateCurF;
    }

    public void setJyuchuSpRateCurF(String[] jyuchuSpRateCurF) {
        this.jyuchuSpRateCurF = jyuchuSpRateCurF;
    }

    public String[] getJyuchuSpCurF() {
        return jyuchuSpCurF;
    }

    public void setJyuchuSpCurF(String[] jyuchuSpCurF) {
        this.jyuchuSpCurF = jyuchuSpCurF;
    }

    public String[] getJyuchuNetF() {
        return jyuchuNetF;
    }

    public void setJyuchuNetF(String[] jyuchuNetF) {
        this.jyuchuNetF = jyuchuNetF;
    }

    public String[] getJyuchuSyuekiYmM() {
        return jyuchuSyuekiYmM;
    }

    public void setJyuchuSyuekiYmM(String[] jyuchuSyuekiYmM) {
        this.jyuchuSyuekiYmM = jyuchuSyuekiYmM;
    }

    public String[] getOrgJyuchuSyuekiYmM() {
        return orgJyuchuSyuekiYmM;
    }

    public void setOrgJyuchuSyuekiYmM(String[] orgJyuchuSyuekiYmM) {
        this.orgJyuchuSyuekiYmM = orgJyuchuSyuekiYmM;
    }

    public String[] getJyuchuDataKbnM() {
        return jyuchuDataKbnM;
    }

    public void setJyuchuDataKbnM(String[] jyuchuDataKbnM) {
        this.jyuchuDataKbnM = jyuchuDataKbnM;
    }

    public String[] getJyuchuCurM() {
        return jyuchuCurM;
    }

    public void setJyuchuCurM(String[] jyuchuCurM) {
        this.jyuchuCurM = jyuchuCurM;
    }

    public String[] getJyuchuSpRateCurM() {
        return jyuchuSpRateCurM;
    }

    public void setJyuchuSpRateCurM(String[] jyuchuSpRateCurM) {
        this.jyuchuSpRateCurM = jyuchuSpRateCurM;
    }

    public String[] getJyuchuSpCurM() {
        return jyuchuSpCurM;
    }

    public void setJyuchuSpCurM(String[] jyuchuSpCurM) {
        this.jyuchuSpCurM = jyuchuSpCurM;
    }

    public String[] getJyuchuNetM() {
        return jyuchuNetM;
    }

    public void setJyuchuNetM(String[] jyuchuNetM) {
        this.jyuchuNetM = jyuchuNetM;
    }

    public String[] getJyuchuNetCategoryCodeF() {
        return jyuchuNetCategoryCodeF;
    }

    public void setJyuchuNetCategoryCodeF(String[] jyuchuNetCategoryCodeF) {
        this.jyuchuNetCategoryCodeF = jyuchuNetCategoryCodeF;
    }

    public String[] getJyuchuNetCategoryKbn1F() {
        return jyuchuNetCategoryKbn1F;
    }

    public void setJyuchuNetCategoryKbn1F(String[] jyuchuNetCategoryKbn1F) {
        this.jyuchuNetCategoryKbn1F = jyuchuNetCategoryKbn1F;
    }

    public String[] getJyuchuNetCategoryKbn2F() {
        return jyuchuNetCategoryKbn2F;
    }

    public void setJyuchuNetCategoryKbn2F(String[] jyuchuNetCategoryKbn2F) {
        this.jyuchuNetCategoryKbn2F = jyuchuNetCategoryKbn2F;
    }

    public String[] getJyuchuNetCategoryCodeM() {
        return jyuchuNetCategoryCodeM;
    }

    public void setJyuchuNetCategoryCodeM(String[] jyuchuNetCategoryCodeM) {
        this.jyuchuNetCategoryCodeM = jyuchuNetCategoryCodeM;
    }

    public String[] getJyuchuNetCategoryKbn1M() {
        return jyuchuNetCategoryKbn1M;
    }

    public void setJyuchuNetCategoryKbn1M(String[] jyuchuNetCategoryKbn1M) {
        this.jyuchuNetCategoryKbn1M = jyuchuNetCategoryKbn1M;
    }

    public String[] getJyuchuNetCategoryKbn2M() {
        return jyuchuNetCategoryKbn2M;
    }

    public void setJyuchuNetCategoryKbn2M(String[] jyuchuNetCategoryKbn2M) {
        this.jyuchuNetCategoryKbn2M = jyuchuNetCategoryKbn2M;
    }

    public String[] getJyuchuSyuekiYmMDelFlg() {
        return jyuchuSyuekiYmMDelFlg;
    }

    public void setJyuchuSyuekiYmMDelFlg(String[] jyuchuSyuekiYmMDelFlg) {
        this.jyuchuSyuekiYmMDelFlg = jyuchuSyuekiYmMDelFlg;
    }

    public List<S003UriageSpRowInfo> getUriageSpRowInfoList() {
        return uriageSpRowInfoList;
    }

    public void setUriageSpRowInfoList(List<S003UriageSpRowInfo> uriageSpRowInfoList) {
        this.uriageSpRowInfoList = uriageSpRowInfoList;
    }

    public Map<String, Object> getUriageSpInfoJyuchuTuti() {
        return uriageSpInfoJyuchuTuti;
    }

    public void setUriageSpInfoJyuchuTuti(Map<String, Object> uriageSpInfoJyuchuTuti) {
        this.uriageSpInfoJyuchuTuti = uriageSpInfoJyuchuTuti;
    }

    public Map<String, Object> getUriageIkkatsuSpInfo() {
        return uriageIkkatsuSpInfo;
    }

    public void setUriageIkkatsuSpInfo(Map<String, Object> uriageIkkatsuSpInfo) {
        this.uriageIkkatsuSpInfo = uriageIkkatsuSpInfo;
    }

    public String getIkkatsuSpRenban() {
        return ikkatsuSpRenban;
    }

    public void setIkkatsuSpRenban(String ikkatsuSpRenban) {
        this.ikkatsuSpRenban = ikkatsuSpRenban;
    }

    public Map<String, Object> getUriageSpInfoSum() {
        return uriageSpInfoSum;
    }

    public void setUriageSpInfoSum(Map<String, Object> uriageSpInfoSum) {
        this.uriageSpInfoSum = uriageSpInfoSum;
    }

    public List<SyuKiNetCateTitleTbl> getUriageNetCateList() {
        return uriageNetCateList;
    }

    public void setUriageNetCateList(List<SyuKiNetCateTitleTbl> uriageNetCateList) {
        this.uriageNetCateList = uriageNetCateList;
    }

    public Map<String, Object> getUriageNetCateInfo() {
        return uriageNetCateInfo;
    }

    public void setUriageNetCateInfo(Map<String, Object> uriageNetCateInfo) {
        this.uriageNetCateInfo = uriageNetCateInfo;
    }

    public Map<String, Object> getUriageSpTotalInfo() {
        return uriageSpTotalInfo;
    }

    public void setUriageSpTotalInfo(Map<String, Object> uriageSpTotalInfo) {
        this.uriageSpTotalInfo = uriageSpTotalInfo;
    }

    public Map<String, Object> getUriageNetTotalInfo() {
        return uriageNetTotalInfo;
    }

    public void setUriageNetTotalInfo(Map<String, Object> uriageNetTotalInfo) {
        this.uriageNetTotalInfo = uriageNetTotalInfo;
    }

    public String[] getUriageCurF() {
        return uriageCurF;
    }

    public void setUriageCurF(String[] uriageCurF) {
        this.uriageCurF = uriageCurF;
    }

    public String[] getUriageRenbanF() {
        return uriageRenbanF;
    }

    public void setUriageRenbanF(String[] uriageRenbanF) {
        this.uriageRenbanF = uriageRenbanF;
    }

    public String[] getUriageSpF() {
        return uriageSpF;
    }

    public void setUriageSpF(String[] uriageSpF) {
        this.uriageSpF = uriageSpF;
    }

    public String[] getUriageCategoryCodeF() {
        return uriageCategoryCodeF;
    }

    public void setUriageCategoryCodeF(String[] uriageCategoryCodeF) {
        this.uriageCategoryCodeF = uriageCategoryCodeF;
    }

    public String[] getUriageCategoryKbn1F() {
        return uriageCategoryKbn1F;
    }

    public void setUriageCategoryKbn1F(String[] uriageCategoryKbn1F) {
        this.uriageCategoryKbn1F = uriageCategoryKbn1F;
    }

    public String[] getUriageCategoryKbn2F() {
        return uriageCategoryKbn2F;
    }

    public void setUriageCategoryKbn2F(String[] uriageCategoryKbn2F) {
        this.uriageCategoryKbn2F = uriageCategoryKbn2F;
    }

    public String[] getUriageNetF() {
        return uriageNetF;
    }

    public void setUriageNetF(String[] uriageNetF) {
        this.uriageNetF = uriageNetF;
    }

    public String[] getUriageSyuekiYmM() {
        return uriageSyuekiYmM;
    }

    public void setUriageSyuekiYmM(String[] uriageSyuekiYmM) {
        this.uriageSyuekiYmM = uriageSyuekiYmM;
    }

    public String[] getOrgUriageSyuekiYmM() {
        return orgUriageSyuekiYmM;
    }

    public void setOrgUriageSyuekiYmM(String[] orgUriageSyuekiYmM) {
        this.orgUriageSyuekiYmM = orgUriageSyuekiYmM;
    }

    public String[] getUriageSyuekiYmMDelFlg() {
        return uriageSyuekiYmMDelFlg;
    }

    public void setUriageSyuekiYmMDelFlg(String[] uriageSyuekiYmMDelFlg) {
        this.uriageSyuekiYmMDelFlg = uriageSyuekiYmMDelFlg;
    }

    public String[] getUriageDataKbnM() {
        return uriageDataKbnM;
    }

    public void setUriageDataKbnM(String[] uriageDataKbnM) {
        this.uriageDataKbnM = uriageDataKbnM;
    }

    public String[] getUriageCurM() {
        return uriageCurM;
    }

    public void setUriageCurM(String[] uriageCurM) {
        this.uriageCurM = uriageCurM;
    }

    public String[] getUriageRenbanM() {
        return uriageRenbanM;
    }

    public void setUriageRenbanM(String[] uriageRenbanM) {
        this.uriageRenbanM = uriageRenbanM;
    }

    public String[] getUriageSpM() {
        return uriageSpM;
    }

    public void setUriageSpM(String[] uriageSpM) {
        this.uriageSpM = uriageSpM;
    }

    public String[] getUriageCategoryCodeM() {
        return uriageCategoryCodeM;
    }

    public void setUriageCategoryCodeM(String[] uriageCategoryCodeM) {
        this.uriageCategoryCodeM = uriageCategoryCodeM;
    }

    public String[] getUriageCategoryKbn1M() {
        return uriageCategoryKbn1M;
    }

    public void setUriageCategoryKbn1M(String[] uriageCategoryKbn1M) {
        this.uriageCategoryKbn1M = uriageCategoryKbn1M;
    }

    public String[] getUriageCategoryKbn2M() {
        return uriageCategoryKbn2M;
    }

    public void setUriageCategoryKbn2M(String[] uriageCategoryKbn2M) {
        this.uriageCategoryKbn2M = uriageCategoryKbn2M;
    }

    public String[] getUriageNetM() {
        return uriageNetM;
    }

    public void setUriageNetM(String[] uriageNetM) {
        this.uriageNetM = uriageNetM;
    }

    public String[] getUriageRenbanSeqF() {
        return uriageRenbanSeqF;
    }

    public void setUriageRenbanSeqF(String[] uriageRenbanSeqF) {
        this.uriageRenbanSeqF = uriageRenbanSeqF;
    }

    public String getIkkatsuSpRenbanSeq() {
        return ikkatsuSpRenbanSeq;
    }

    public void setIkkatsuSpRenbanSeq(String ikkatsuSpRenbanSeq) {
        this.ikkatsuSpRenbanSeq = ikkatsuSpRenbanSeq;
    }

//    public List<Map<String, String>> getMikomiRateInfoList() {
//        return mikomiRateInfoList;
//    }
//
//    public void setMikomiRateInfoList(List<Map<String, String>> mikomiRateInfoList) {
//        this.mikomiRateInfoList = mikomiRateInfoList;
//    }
    public Map<String, Map<String, String>> getMikomiRateInfo() {
        return mikomiRateInfo;
    }

    public void setMikomiRateInfo(Map<String, Map<String, String>> mikomiRateInfo) {
        this.mikomiRateInfo = mikomiRateInfo;
    }

    public String getJuchuTuchiListOpenFlg() {
        return juchuTuchiListOpenFlg;
    }

    public void setJuchuTuchiListOpenFlg(String juchuTuchiListOpenFlg) {
        this.juchuTuchiListOpenFlg = juchuTuchiListOpenFlg;
    }

    public String getSaveBalanceFlg() {
        return saveBalanceFlg;
    }

    public void setSaveBalanceFlg(String saveBalanceFlg) {
        this.saveBalanceFlg = saveBalanceFlg;
    }

    public String getBikou() {
        return bikou;
    }

    public void setBikou(String bikou) {
        this.bikou = bikou;
    }

    public Map<String, Object> getIkkatsuCategoryInfo() {
        return ikkatsuCategoryInfo;
    }

    public void setIkkatsuCategoryInfo(Map<String, Object> ikkatsuCategoryInfo) {
        this.ikkatsuCategoryInfo = ikkatsuCategoryInfo;
    }

    public String[] getUriageRateF_Currency() {
        return uriageRateF_Currency;
    }

    public void setUriageRateF_Currency(String[] uriageRateF_Currency) {
        this.uriageRateF_Currency = uriageRateF_Currency;
    }

    public String[] getUriageRateM_Currency() {
        return uriageRateM_Currency;
    }

    public void setUriageRateM_Currency(String[] uriageRateM_Currency) {
        this.uriageRateM_Currency = uriageRateM_Currency;
    }

    /**
     * @return the kaisyuCurM
     */
    public String[] getKaisyuCurM() {
        return kaisyuCurM;
    }

    /**
     * @param kaisyuCurM the kaisyuCurM to set
     */
    public void setKaisyuCurM(String[] kaisyuCurM) {
        this.kaisyuCurM = kaisyuCurM;
    }

    /**
     * @return the kaisyuM
     */
    public String[] getKaisyuM() {
        return kaisyuM;
    }

    /**
     * @param kaisyuM the kaisyuM to set
     */
    public void setKaisyuM(String[] kaisyuM) {
        this.kaisyuM = kaisyuM;
    }

    /**
     * @return the kaisyuRuiM
     */
    public String[] getKaisyuRuiM() {
        return kaisyuRuiM;
    }

    /**
     * @param kaisyuRuiM the kaisyuRuiM to set
     */
    public void setKaisyuRuiM(String[] kaisyuRuiM) {
        this.kaisyuRuiM = kaisyuRuiM;
    }

    /**
     * @return the kaisyuMiM
     */
    public String[] getKaisyuMiM() {
        return kaisyuMiM;
    }

    /**
     * @param kaisyuMiM the kaisyuMiM to set
     */
    public void setKaisyuMiM(String[] kaisyuMiM) {
        this.kaisyuMiM = kaisyuMiM;
    }

    /**
     * @return the uriageSyuekiYmJ
     */
    public String[] getUriageSyuekiYmJ() {
        return uriageSyuekiYmJ;
    }

    /**
     * @param uriageSyuekiYmJ the uriageSyuekiYmJ to set
     */
    public void setUriageSyuekiYmJ(String[] uriageSyuekiYmJ) {
        this.uriageSyuekiYmJ = uriageSyuekiYmJ;
    }

    /**
     * @return the uriageDataKbnJ
     */
    public String[] getUriageDataKbnJ() {
        return uriageDataKbnJ;
    }

    /**
     * @param uriageDataKbnJ the uriageDataKbnJ to set
     */
    public void setUriageDataKbnJ(String[] uriageDataKbnJ) {
        this.uriageDataKbnJ = uriageDataKbnJ;
    }

    /**
     * @return the kaisyuCurJ
     */
    public String[] getKaisyuCurJ() {
        return kaisyuCurJ;
    }

    /**
     * @param kaisyuCurJ the kaisyuCurJ to set
     */
    public void setKaisyuCurJ(String[] kaisyuCurJ) {
        this.kaisyuCurJ = kaisyuCurJ;
    }

    /**
     * @return the kaisyuJ
     */
    public String[] getKaisyuJ() {
        return kaisyuJ;
    }

    /**
     * @param kaisyuJ the kaisyuJ to set
     */
    public void setKaisyuJ(String[] kaisyuJ) {
        this.kaisyuJ = kaisyuJ;
    }

    public String getKanjyoYm() {
        return kanjyoYm;
    }

    public void setKanjyoYm(String kanjyoYm) {
        this.kanjyoYm = kanjyoYm;
    }

    public Integer getKanjyoYmCount() {
        return kanjyoYmCount;
    }

    public void setKanjyoYmCount(Integer kanjyoYmCount) {
        this.kanjyoYmCount = kanjyoYmCount;
    }
}
