package jp.co.toshiba.hby.pspromis.common.entity;

import java.io.Serializable;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

@Entity
@Table(name = "COUNT")
public class CountEntity implements Serializable {
    /** カウント */
    @Id
    @NotNull
    @Column(name = "COUNT")
    private Integer count = 0;
    
    /**
     * 
     */
    public CountEntity(){
        super();
    }

    public int getCount() {
        return count;
    }

    public void setCount(int count) {
        this.count = count;
    }    
}