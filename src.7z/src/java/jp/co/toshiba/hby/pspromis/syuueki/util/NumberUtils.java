package jp.co.toshiba.hby.pspromis.syuueki.util;

import java.math.BigDecimal;
import java.math.BigInteger;
import org.apache.commons.lang3.StringUtils;

/**
 *
 * @author ganryu
 */
public class NumberUtils {

    /**
     * オブジェクトをBigDecimalに変換 カンマ編集されていても変換する
     *
     * @param obj
     * @return
     */
    public static BigDecimal changeBigDecimal(Object obj) {
        if (obj == null) {
            return null;
        }

        BigDecimal big = null;
        if (obj instanceof BigDecimal) {
            return (BigDecimal) obj;
        }

        if (obj instanceof String) {
            String targetStr = (String) obj;
            if (StringUtils.isEmpty(targetStr)) {
                return null;
            }
            // カンマ編集されている場合は取り除く
            targetStr = StringUtils.replace(targetStr, ",", "");
            big = new BigDecimal(targetStr);
            return big;
        }

        if (obj instanceof Integer) {
            big = new BigDecimal((Integer) obj);
            return big;
        }
        if (obj instanceof Double) {
            big = new BigDecimal((Double) obj);
            return big;
        }
        if (obj instanceof Float) {
            big = new BigDecimal((Float) obj);
            return big;
        }
        if (obj instanceof Long) {
            big = new BigDecimal((Long) obj);
            return big;
        }
        if (obj instanceof BigInteger) {
            big = new BigDecimal((BigInteger) obj);
            return big;
        }

        throw new NumberFormatException(obj + " is Not Change BigDecimal");
    }

    /**
     * 文字列のLong型変換
     *
     * @param strLong
     * @return
     */
    public static Long convLong(String strLong) {
        Long rtnL = null;

        if (StringUtils.isNotEmpty(strLong)) {
            rtnL = (changeBigDecimal(strLong)).longValue();
        }

        return rtnL;
    }

    /**
     * 値の足し算(可変長引数で指定し、そのすべてを足した結果を返す)
     *
     * @param valAry
     * @return
     */
    public static BigDecimal add(BigDecimal... valAry) {
        BigDecimal result = null;
        if (valAry == null) {
            return null;
        }

        for (BigDecimal val : valAry) {
            if (val == null) {
                continue;
            }
            if (result == null) {
                result = val;
            } else {
                result = result.add(val);
            }
        }

        return result;
    }

    /**
     * 値の足し算(可変長引数で指定し、そのすべてを足した結果を返す)
     *
     * @param valAry
     * @return
     */
    public static BigInteger add(BigInteger... valAry) {
        BigInteger result = null;
        if (valAry == null) {
            return null;
        }

        for (BigInteger val : valAry) {
            if (val == null) {
                continue;
            }
            if (result == null) {
                result = val;
            } else {
                result = result.add(val);
            }
        }

        return result;
    }

    /**
     * 割り算(指定桁数で四捨五入)
     * @param div1 分母
     * @param div2 分子
     * @param scale 指定桁数
     * @return 計算結果
     */
    public static BigDecimal div(BigDecimal div1, BigDecimal div2, int scale) {
        // 分子がnull or 0の場合は計算できないのでnullを戻す。
        if (div2 == null || div2.intValue() == 0) {
            return null;
        }

        // 分母がnullの場合は0に変換
        BigDecimal calcDiv1 = (div1 == null ? (new BigDecimal(0)) : div1);

        //　割り算実行
        BigDecimal divResult = calcDiv1.divide(div2, scale, BigDecimal.ROUND_HALF_UP);
        
        return divResult;
    }
    
}
