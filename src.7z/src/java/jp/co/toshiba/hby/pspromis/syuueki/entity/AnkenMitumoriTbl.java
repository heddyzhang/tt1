package jp.co.toshiba.hby.pspromis.syuueki.entity;

import java.io.Serializable;
import java.util.Date;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

/**
 *
 * @author ganryu
 */
@Entity
@Table(name = "ANKEN_MITUMORI_TBL")
public class AnkenMitumoriTbl implements Serializable {

    private static final long serialVersionUID = 1L;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 32)
    @Column(name = "ANKEN_NO")
    private String ankenNo;
    @Id
    @Basic(optional = false)
    @NotNull
    @Column(name = "MITUMORI_SEQ")
    private Short mitumoriSeq;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 10)
    @Column(name = "MITUMORI_NO")
    private String mitumoriNo;
    @Column(name = "CREATED_AT")
    @Temporal(TemporalType.DATE)
    private Date createdAt;
    @Size(max = 32)
    @Column(name = "CREATED_BY")
    private String createdBy;
    @Column(name = "UPDATED_AT")
    @Temporal(TemporalType.DATE)
    private Date updatedAt;
    @Size(max = 32)
    @Column(name = "UPDATED_BY")
    private String updatedBy;

    public AnkenMitumoriTbl() {
    }

    public String getAnkenNo() {
        return ankenNo;
    }

    public void setAnkenNo(String ankenNo) {
        this.ankenNo = ankenNo;
    }

    public Short getMitumoriSeq() {
        return mitumoriSeq;
    }

    public void setMitumoriSeq(Short mitumoriSeq) {
        this.mitumoriSeq = mitumoriSeq;
    }

    public String getMitumoriNo() {
        return mitumoriNo;
    }

    public void setMitumoriNo(String mitumoriNo) {
        this.mitumoriNo = mitumoriNo;
    }

    public Date getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(Date createdAt) {
        this.createdAt = createdAt;
    }

    public String getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    public Date getUpdatedAt() {
        return updatedAt;
    }

    public void setUpdatedAt(Date updatedAt) {
        this.updatedAt = updatedAt;
    }

    public String getUpdatedBy() {
        return updatedBy;
    }

    public void setUpdatedBy(String updatedBy) {
        this.updatedBy = updatedBy;
    }

}
