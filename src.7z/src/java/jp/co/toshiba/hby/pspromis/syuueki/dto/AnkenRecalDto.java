/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package jp.co.toshiba.hby.pspromis.syuueki.dto;

/**
 * PS-Promis収益管理システム
 * RDBMS 再計算パッケージCall用パラメータdto
 * @author (NPS)S.Ibayashi
 */
public class AnkenRecalDto {
   
    /**
     * 案件id
     */
    private String ankenId;
    
    /**
     * 履歴id(最新:0/履歴:1)
     */
    private Integer rirekiId;

    /**
     * 処理FLG
     * 0 ：期間損益(一般)の最新情報取込時以外の再計算時
     * 1 ：項番一覧の最新情報取込時以外の再計算時
     * 2 ：最終見込の最新情報取込時以外の再計算時
     * 3 ：項番一覧（最終)の最新情報取込時以外の再計算時
     * 4 ：最新情報取込実行時（期間損益、最終見込、項番一覧）
     */
    private String procFlg;
    
    /**
     * 処理結果ステータス(０:正常/9：異常)
     */
    private String status;

    /**
     * 処理結果メッセージ
     */
    private String resultMessage;
    
    /**
     * 実行したパッケージ名
     */
    private String exeProcedureName;

    public String getAnkenId() {
        return ankenId;
    }

    public void setAnkenId(String ankenId) {
        this.ankenId = ankenId;
    }
/*
    public String getKbn() {
        return kbn;
    }

    public void setKbn(String kbn) {
        this.kbn = kbn;
    }
*/
    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public Integer getRirekiId() {
        return rirekiId;
    }

    public void setRirekiId(Integer rirekiId) {
        this.rirekiId = rirekiId;
    }

    public String getProcFlg() {
        return procFlg;
    }

    public void setProcFlg(String procFlg) {
        this.procFlg = procFlg;
    }

    public String getExeProcedureName() {
        return exeProcedureName;
    }

    public void setExeProcedureName(String exeProcedureName) {
        this.exeProcedureName = exeProcedureName;
    }

    public String getResultMessage() {
        return resultMessage;
    }

    public void setResultMessage(String resultMessage) {
        this.resultMessage = resultMessage;
    }

}
