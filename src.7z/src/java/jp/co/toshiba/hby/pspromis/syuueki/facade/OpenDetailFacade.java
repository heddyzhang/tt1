package jp.co.toshiba.hby.pspromis.syuueki.facade;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.ejb.Stateless;
import javax.inject.Inject;
import javax.interceptor.Interceptors;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import jp.co.toshiba.hby.pspromis.common.jdbc.SqlExecutor;
import jp.co.toshiba.hby.pspromis.syuueki.entity.SyuGeBukkenInfoTbl;
import jp.co.toshiba.hby.pspromis.syuueki.interceptor.TranceInterceptor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 *
 * @author koga
 */
@Stateless
@Interceptors({TranceInterceptor.class})
public class OpenDetailFacade extends AbstractFacade<SyuGeBukkenInfoTbl>{
    /**
     * ロガ－
     */
    private static final Logger logger = LoggerFactory.getLogger(OpenDetailFacade.class);
    
    @PersistenceContext(unitName = jp.co.toshiba.hby.pspromis.syuueki.util.ConstantString.syuuekiDataSourceName)
    private EntityManager em;

//    @Inject
//    protected SqlExecutor sqlExecutor;
    
    @Override
    protected EntityManager getEntityManager() {
        return em;
    }
    
     public OpenDetailFacade() {
        super(SyuGeBukkenInfoTbl.class);
    }
     
    /**
     * @param condition
     * @return
     */ 
    public List<SyuGeBukkenInfoTbl> getSyuGeBukkenInfo(Object condition){
        logger.info("OpenDetailFacade#getSyuGeBukkenInfo");

        List<SyuGeBukkenInfoTbl> syuGeBukkenInfoTbl = sqlExecutor.getResultList(em, SyuGeBukkenInfoTbl.class, "/sql/selectAnkenChuban.sql", condition);
        return syuGeBukkenInfoTbl;
    }
}
