package jp.co.toshiba.hby.pspromis.syuueki.facade;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import javax.ejb.Stateless;
import javax.inject.Inject;
import javax.interceptor.Interceptors;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import jp.co.toshiba.hby.pspromis.syuueki.entity.PlantTypeMst;
import jp.co.toshiba.hby.pspromis.syuueki.entity.PlantMst;
import jp.co.toshiba.hby.pspromis.syuueki.interceptor.TranceInterceptor;
import jp.co.toshiba.hby.pspromis.syuueki.util.Utils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
/**
 *
 * @author horie
 */
@Stateless
@Interceptors({TranceInterceptor.class})
public class PlantTypeMstFacade extends AbstractFacade<PlantTypeMst> {
    
    private static final Logger logger = LoggerFactory.getLogger(PlantTypeMstFacade.class);
    
    @PersistenceContext(unitName = jp.co.toshiba.hby.pspromis.syuueki.util.ConstantString.syuuekiDataSourceName)
    private EntityManager em;

    @Override
    protected EntityManager getEntityManager() {
        return em;
    }
    
    public PlantTypeMstFacade() {
        super(PlantTypeMst.class);
    }

    /**
     * プラント種別を取得
     * @param condition
     * @return 
     */
    public List<PlantTypeMst> getPlantTypeMstList(Object condition) {
        List<PlantTypeMst> list
                = sqlExecutor.getResultList(em, PlantTypeMst.class, "/sql/plantTypeMst/selectPlantTypeMst.sql", condition);

        return list;
    }

}
