package jp.co.toshiba.hby.pspromis.syuueki.facade;

import java.util.List;
import javax.ejb.Stateless;
import javax.interceptor.Interceptors;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import jp.co.toshiba.hby.pspromis.syuueki.entity.CurrencyRateList;
import jp.co.toshiba.hby.pspromis.syuueki.interceptor.TranceInterceptor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 *
 * @author sano
 */
@Stateless
@Interceptors({TranceInterceptor.class})
public class CurrencyRateListFacade extends AbstractFacade<CurrencyRateList> {

    /**
     * ロガ－
     */
    private static final Logger logger = LoggerFactory.getLogger(CurrencyRateListFacade.class);

    @PersistenceContext(unitName = jp.co.toshiba.hby.pspromis.syuueki.util.ConstantString.syuuekiDataSourceName)
    private EntityManager em;

    public CurrencyRateListFacade() {
        super(CurrencyRateList.class);
    }

    @Override
    protected EntityManager getEntityManager() {
        return em;
    }

    /**
     * レート表の一覧を取得
     * @param condition
     * @return 
     */
    public List<CurrencyRateList> findList(Object condition) {
        logger.info("CurrencyRateListFacade#findList");

        List<CurrencyRateList> list =
                sqlExecutor.getResultList(em, CurrencyRateList.class, "/sql/S002/selectCurrencyRateList.sql", condition);
        
        return list;
    }
}
