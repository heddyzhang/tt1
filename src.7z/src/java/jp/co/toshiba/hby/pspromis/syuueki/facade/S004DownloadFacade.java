/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package jp.co.toshiba.hby.pspromis.syuueki.facade;

import java.math.BigDecimal;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.ejb.Stateless;
import javax.inject.Inject;
import javax.interceptor.Interceptors;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import jp.co.toshiba.hby.pspromis.syuueki.entity.Cost;
import jp.co.toshiba.hby.pspromis.syuueki.entity.S004DownloadEntity;
import jp.co.toshiba.hby.pspromis.syuueki.interceptor.TranceInterceptor;
import jp.co.toshiba.hby.pspromis.syuueki.jdbc.DbUtilsExecutor;
import jp.co.toshiba.hby.pspromis.common.jdbc.SqlExecutor;
import jp.co.toshiba.hby.pspromis.syuueki.entity.S004DownloadKaisyuEntity;
import jp.co.toshiba.hby.pspromis.syuueki.jdbc.SqlFile;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 *
 * @author kitajima
 */
@Stateless
@Interceptors({TranceInterceptor.class}) 
public class S004DownloadFacade extends AbstractFacade<S004DownloadEntity> {
    
    /**
     * ロガ－
     */
    private static final Logger logger = LoggerFactory.getLogger(S004UpdateFacade.class);

    @PersistenceContext(unitName = jp.co.toshiba.hby.pspromis.syuueki.util.ConstantString.syuuekiDataSourceName)
    private EntityManager em;

    public S004DownloadFacade() {
        super(S004DownloadEntity.class);
    }

    @Override
    protected EntityManager getEntityManager() {
        return em;
    }
    
    @Inject
    protected SqlExecutor sqlExecutor;
    
    @Inject
    private DbUtilsExecutor dbUtilsExecutor;
    
    /**
     * 通貨の種類を取得
     * @param condition 
     * @return  
     */
    public List<S004DownloadEntity> selectCurrencyList(Object condition){
        logger.info("S004DownloadFacade#selectCurrencyList");

        List<S004DownloadEntity> currencyList = sqlExecutor.getResultList(em, S004DownloadEntity.class, "/sql/S004/selectCurrencyList.sql", condition);
        
        return currencyList;
    }
    
    
    /**
     * 売上原価の種類を取得
     * @param condition 
     * @return  
     */
    public List<Cost> selectCateTitleList(Object condition){
        logger.info("S004DownloadFacade#selectCateTitleList");

        List<Cost> dlEntityList = sqlExecutor.getResultList(em, Cost.class, "/sql/S004/selectCateTitleList.sql", condition);
        
        return dlEntityList;
    }
    
    /**
     * 通貨別・期間損益TBL月別詳細(進行基準)を取得
     * @param condition 
     * @return  
     */
    public S004DownloadEntity selectKsTsukiCurrency(Object condition){
        logger.info("S004DownloadFacade#selectKsTsukiCurrency");

        S004DownloadEntity ksTsukiCurrency = sqlExecutor.getSingleResult(em, S004DownloadEntity.class, "/sql/S004/selectKsTsukiCurrency.sql", condition);
        
        return ksTsukiCurrency;
    }
    
    /**
     * 通貨別・期間損益TBL月別詳細(進行基準)を取得
     * @param condition 
     * @return  
     */
     public Map<String, Object> selectKsTsukiCurrency2(Object condition) throws SQLException {
        String sqlFilePath = "/sql/S004/selectKsTsukiCurrency.sql";

        // SQLを取得
        SqlFile sqlFile = new SqlFile();
        String sql = sqlFile.getSqlString(sqlFilePath, condition);
        Object[] params = sqlFile.getSqlParams(sqlFilePath, condition);

        // SQL実行
        Map<String, Object> item = dbUtilsExecutor.dbUtilsGetSql(em, sql, params);
        
        if (item == null) {
            item = new HashMap<>();
        } 
        
        return item;
     }

    /**
     * 通貨別・期間損益TBL 見積総原価 月別詳細を取得
     * @param condition 
     * @return  
     */
     public Map<String, Object> selectKnSogenkaTsuki(Object condition) throws SQLException {
        String sqlFilePath = "/sql/S004/selectKnSogenkaTsuki.sql";

        // SQLを取得
        SqlFile sqlFile = new SqlFile();
        String sql = sqlFile.getSqlString(sqlFilePath, condition);
        Object[] params = sqlFile.getSqlParams(sqlFilePath, condition);

        // SQL実行
        Map<String, Object> item = dbUtilsExecutor.dbUtilsGetSql(em, sql, params);
        
        if (item == null) {
            item = new HashMap<>();
        } 
        
        return item;
     }

    /**
     * 見積総原価合計を取得
     * @param ankenId
     * @param rirekiId
     * @param dataKbn
     * @param syuekiYm
     * @param rirekiFlg
     * @return  
     * @throws java.sql.SQLException  
     */
     public BigDecimal getTotalSougenka(String ankenId, Integer rirekiId, String dataKbn, String syuekiYm, String rirekiFlg) throws SQLException {
        BigDecimal totalSougenka = null;
         
        Map<String, Object> condition = new HashMap<>();
        condition.put("ankenId", ankenId);
        condition.put("rirekiId", rirekiId);
        condition.put("dataKbn", dataKbn);
        condition.put("syuekiYm", syuekiYm);
        condition.put("rirekiFlg", rirekiFlg);
         
        // SQLを取得
        String sqlFilePath = "/sql/S004/selectKnSogenkaTotal.sql";
        SqlFile sqlFile = new SqlFile();
        String sql = sqlFile.getSqlString(sqlFilePath, condition);
        Object[] params = sqlFile.getSqlParams(sqlFilePath, condition);
        
        // SQL実行
        Map<String, Object> item = dbUtilsExecutor.dbUtilsGetSql(em, sql, params);
        
        if (item != null) {
            totalSougenka = (BigDecimal) item.get("MITSUMORI_GENKA_NET");
        }
        
        return totalSougenka;
     }
 
    /**
     * 期間損益TBL（原価）カテゴリ別－月別詳細を取得
     * @param condition 
     * @return  
     */
     public List<Map<String, Object>> selectCateTsuki(Object condition) throws SQLException {
        String sqlFilePath = "/sql/S004/selectCateTsuki.sql";

        // SQLを取得
        SqlFile sqlFile = new SqlFile();
        String sql = sqlFile.getSqlString(sqlFilePath, condition);
        Object[] params = sqlFile.getSqlParams(sqlFilePath, condition);

        // SQL実行
        List<Map<String, Object>> list = dbUtilsExecutor.dbUtilsGetSqlList(em, sql, params);
        
        if (list == null) {
            list = new ArrayList<>();
        } 
        return list;
     } 
     
    
    /**
     * 勘定年月を取得
     * @param condition 
     * @return  
     */
    public String selectKanjoYm(Object condition){
        logger.info("S004DownloadFacade#selectKanjoYm");

        String kanjoYm = sqlExecutor.getSingleResult(em, String.class, "/sql/S004/selectKanjoYm.sql", condition);
        
        return kanjoYm;
    }

    /**
     * 回収管理の種類を取得
     * @param condition 
     * @return  
     */
    public List<S004DownloadKaisyuEntity> selectKaisyuCurrencyList(Object condition){
        logger.info("S004DownloadFacade#selectKaisyuCurrencyList");

        List<S004DownloadKaisyuEntity> kaisyuCurrencyList = sqlExecutor.getResultList(em, S004DownloadKaisyuEntity.class, "/sql/S004/selectKaisyuCurrencyList.sql", condition);
        
        return kaisyuCurrencyList;
    }

    /**
     * 回収管理－月別詳細金額を取得
     * @param condition 
     * @return  
     */
     public List<Map<String, Object>> selectKaisyuTsuki(Object condition) throws SQLException {
        String sqlFilePath = "/sql/S004/selectKaisyuCurrencyList.sql";

        // SQLを取得
        SqlFile sqlFile = new SqlFile();
        String sql = sqlFile.getSqlString(sqlFilePath, condition);
        Object[] params = sqlFile.getSqlParams(sqlFilePath, condition);

        // SQL実行
        List<Map<String, Object>> list = dbUtilsExecutor.dbUtilsGetSqlList(em, sql, params);
        
        if (list == null) {
            list = new ArrayList<>();
        } 
        return list;
     }
     
    /**
     * ロスコン対象の最小年月を取得
     * @param ankenId
     * @param rirekiId
     * @param kanjyoYm
     * @param rirekiFlg
     * @return  
     * @throws SQLException
     */
     public String selectLossTargetYm(String ankenId, Integer rirekiId, String kanjyoYm, String rirekiFlg) throws SQLException {
        Map<String, Object> condition = new HashMap<>();
        condition.put("ankenId", ankenId);
        condition.put("rirekiId", rirekiId);
        condition.put("kanjyoYm", kanjyoYm);
        condition.put("rirekiFlg", rirekiFlg);
        
        String sqlFilePath = "/sql/S004/selectLossControlYm.sql";
        SqlFile sqlFile = new SqlFile();
        String sql = sqlFile.getSqlString(sqlFilePath, condition);
        Object[] params = sqlFile.getSqlParams(sqlFilePath, condition);
        
        // SQL実行
        String losssTargetYm = "";
        Map<String, Object> item = dbUtilsExecutor.dbUtilsGetSql(em, sql, params);
        if (item != null) {
            losssTargetYm = StringUtils.defaultString((String)item.get("SYUEKI_YM"));
        }
        
        return losssTargetYm;
     }

}
