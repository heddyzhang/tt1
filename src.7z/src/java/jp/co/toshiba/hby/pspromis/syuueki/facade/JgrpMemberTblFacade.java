package jp.co.toshiba.hby.pspromis.syuueki.facade;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import javax.ejb.Stateless;
import javax.interceptor.Interceptors;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import jp.co.toshiba.hby.pspromis.syuueki.entity.JgrpMemberTbl;
import jp.co.toshiba.hby.pspromis.syuueki.entity.StringEntity;
import jp.co.toshiba.hby.pspromis.syuueki.interceptor.TranceInterceptor;
import org.apache.commons.lang3.StringUtils;

/**
 *
 * @author ibayashi
 */
@Stateless
@Interceptors({TranceInterceptor.class})
public class JgrpMemberTblFacade extends AbstractFacade<JgrpMemberTbl> {

    @PersistenceContext(unitName = jp.co.toshiba.hby.pspromis.syuueki.util.ConstantString.syuuekiDataSourceName)
    private EntityManager em;

    @Override
    protected EntityManager getEntityManager() {
        return em;
    }

    public JgrpMemberTblFacade() {
        super(JgrpMemberTbl.class);
    }

    /**
     * 指定ユーザーの所属JobGr一覧を取得
     *
     * @param tuid
     * @return
     */
    public List<String> getMemberJobGrList(String tuid) {
        Map<String, String> condition = new HashMap<>();
        condition.put("tuid", tuid);

        List<JgrpMemberTbl> list
                = sqlExecutor.getResultList(em, JgrpMemberTbl.class, "/sql/jgrpMemberTbl/selectMemberJgrp.sql", condition);

        List<String> jobGrList = new ArrayList<>();
        for (JgrpMemberTbl entity : list) {
            jobGrList.add(entity.getJgrpId());
        }

        return jobGrList;
    }

    /**
     * 指定JobGrの担当者一覧を取得
     *
     * @param jgrpId
     * @return 指定JobGrの担当者一覧
     */
    public List<JgrpMemberTbl> getJobGrMemerInfoList(String jgrpId) {
        List<String> list = new ArrayList<>();
        list.add(jgrpId);

        return getJobGrMemerInfoList(list);
    }

    /**
     * 指定JobGrの担当者一覧を取得(JobGrを複数指定)
     *
     * @param jgrpIdList JobGr一覧
     * @return 指定JobGrの担当者一覧
     */
    public List<JgrpMemberTbl> getJobGrMemerInfoList(List<String> jgrpIdList) {
        Map<String, Object> condition = new HashMap<>();
        condition.put("jgrpIdList", jgrpIdList);

        List<JgrpMemberTbl> list
                = sqlExecutor.getResultList(em, JgrpMemberTbl.class, "/sql/jgrpMemberTbl/selectMemberJgrp.sql", condition);

        // 重複除去を行う(兼務しているメンバーが存在するため、同一ユーザーを1レコードとする)
        Set<String> checkSet = new HashSet<>();
        if (list != null && list.size() > 0) {
            for (int i = 0; i < list.size(); i++) {
                JgrpMemberTbl en = list.get(i);
                if (checkSet.contains(en.getMemberId())) {
                    list.remove(i);
                    i--;
                } else {
                    checkSet.add(en.getMemberId());
                }
            }
        }

        checkSet = null;

        return list;
    }

    /**
     * 指定ユーザーの部課コードを取得(兼務の場合は最小seqのデータ)
     */
    public String getBukaCd(String tuid) {
        Map<String, Object> condition = new HashMap<>();
        condition.put("tuid", tuid);

        String bukaCd = "";

        List<JgrpMemberTbl> list
                = sqlExecutor.getResultList(em, JgrpMemberTbl.class, "/sql/jgrpMemberTbl/selectMemberJgrp.sql", condition);

        for (JgrpMemberTbl entity : list) {
            bukaCd = entity.getMemberBukaCd();
            break;
        }

        return bukaCd;
    }

    /**
     * 指定ユーザーの名称を取得
     *
     * @param tuid
     * @return
     */
    public String getMemberName(String tuid) {
        Map<String, Object> condition = new HashMap<>();
        condition.put("tuid", tuid);

        StringEntity entity
                = sqlExecutor.getSingleResult(em, StringEntity.class, "/sql/jgrpMemberTbl/selectMemberName.sql", condition);

        return entity.getString();
    }

    /**
     * 指定事業部,進行基準FLG,グループコード,ユーザーのワークフロー権限一覧を取得
     *
     * @param divisionCode
     * @param salesClass
     * @param tuid
     * @param groupCode
     * @return
     */
    public List<JgrpMemberTbl> getJobGrMemerInfoList(String divisionCode, String salesClass, String groupCode, String tuid) {
        Map<String, Object> condition = new HashMap<>();
        condition.put("divisionCode", divisionCode);
        condition.put("salesClass", salesClass);
        condition.put("groupCode", groupCode);
        if (StringUtils.isNotEmpty(tuid)) {
            condition.put("tuid", tuid);
        }

        List<JgrpMemberTbl> list
                = sqlExecutor.getResultList(em, JgrpMemberTbl.class, "/sql/jgrpMemberTbl/selectWorkFlowKengen.sql", condition);

        return list;
    }

    /**
     *
     * @param syokusyuCd
     * @param divisionCode
     * @param jobGrCode
     * @return
     */
    public List<JgrpMemberTbl> getEmpNoList(String syokusyuCd, String divisionCode, String jobGrCode) {
        Map<String, Object> condition = new HashMap<>();
        condition.put("syokusyuCd", syokusyuCd);
        condition.put("divisionCode", divisionCode);
        condition.put("jobGrCode", jobGrCode);

        List<JgrpMemberTbl> list = sqlExecutor.getResultList(em, JgrpMemberTbl.class, "/sql/jgrpMemberTbl/selectEmpNoList.sql", condition);

        return list;
    }
}
