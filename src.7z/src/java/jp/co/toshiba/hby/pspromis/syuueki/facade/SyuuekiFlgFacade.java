package jp.co.toshiba.hby.pspromis.syuueki.facade;

import javax.ejb.Stateless;
import javax.interceptor.Interceptors;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import jp.co.toshiba.hby.pspromis.syuueki.interceptor.TranceInterceptor;

/**
 *
 * @author sekiguchi
 */
@Stateless
@Interceptors({TranceInterceptor.class})
public class SyuuekiFlgFacade extends AbstractFacade<String> {

    @PersistenceContext(unitName = jp.co.toshiba.hby.pspromis.syuueki.util.ConstantString.syuuekiDataSourceName)
    private EntityManager em;

    @Override
    protected EntityManager getEntityManager() {
        return em;
    }

    public SyuuekiFlgFacade() {
        super(String.class);
    }

    public Integer getSyokusyuRole(Object condition) {
        Integer count = sqlExecutor.getCount(em, "/sql/S002/selectSyuekiFlg.sql", condition);
        return count;
    }
}
