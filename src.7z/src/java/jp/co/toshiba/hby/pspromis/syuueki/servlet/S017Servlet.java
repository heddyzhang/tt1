package jp.co.toshiba.hby.pspromis.syuueki.servlet;

import java.util.HashMap;
import java.util.Map;
import javax.inject.Inject;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import jp.co.toshiba.hby.pspromis.syuueki.bean.ResultMessageBean;
import jp.co.toshiba.hby.pspromis.syuueki.bean.S017Bean;
import jp.co.toshiba.hby.pspromis.syuueki.bean.ValidationMessageBean;
import jp.co.toshiba.hby.pspromis.syuueki.service.S017Service;
import jp.co.toshiba.hby.pspromis.syuueki.util.CdiUtils;
import jp.co.toshiba.hby.pspromis.syuueki.util.ParameterBinder;

/**
 *
 * @author ganryu
 */
@WebServlet(name = "S017", urlPatterns = {"/servlet/S017", "/servlet/S017/*"})
public class S017Servlet extends AbstractServlet {

    /**
     * jsp
     */
    private static final String INDEX_JSP = "S017/s017.jsp";

    /**
     * 使用serviceクラスをinjection(CDI)<br>
     * InjectアノテーションよりAPサーバー(Glassfish)側で自動的にインスタンス作成(new)される。<br>
     * service側はステートレスセッションbeanにするため、Statelessアノテーションをつけておくこと。<br>
     */
    @Inject
    private S017Service s017Service;
    @Inject
    private S017Bean s017Bean;
    @Inject
    private ValidationMessageBean validationMessageBean;
    
    /**
     *
     * @param req
     * @param resp
     * @return
     * @throws Exception
     */
    public String indexAction(HttpServletRequest req, HttpServletResponse resp)
            throws Exception {
        logger.info("S017Servlet#indexAction");

        // リクエストパラメータをs017Beanの同名フィールドに一括コピー
        ParameterBinder.Bind(s017Bean, req);

        s017Service.indexExecute();

        return INDEX_JSP;
    }
    
    /**
     * バリデーションチェック
     */
    public boolean validation() {
        return true;
    }
    
    /**
     * 保存処理
     * @param req
     * @param resp
     * @return
     * @throws Exception
     */
    public String saveAction(HttpServletRequest req, HttpServletResponse resp)
    throws Exception {
        logger.info("S017Servlet#saveAction");
        
        // リクエストパラメータをs017Beanの同名フィールドに一括コピー
        ParameterBinder.Bind(s017Bean, req);
        
        // バリデーションチェックしてから保存処理
        if (!s017Service.validation()) {
            // 入力エラーが存在する場合はエラー情報を返す
            resopnseDecodeJson(resp, validationMessageBean.errorJsonInfo());
        } else {
            // 保存処理の実行
            s017Service.saveExecute();
            
            // 処理結果を戻す。
            Map<String, Object> jsonMap = new HashMap<>();
            ResultMessageBean resultMessageBean = CdiUtils.getBean(ResultMessageBean.class);
            resultMessageBean.createResultMessage(jsonMap);
            resopnseDecodeJson(resp, jsonMap);
        }

        return null;
    }
    
}
