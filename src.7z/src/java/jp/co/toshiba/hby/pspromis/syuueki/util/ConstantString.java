package jp.co.toshiba.hby.pspromis.syuueki.util;


/**
 * PS-Promis収益管理 定数定義クラス<br>
 *
 * @author (NPC)S.Ibayashi
 */
public interface ConstantString {

    /**
     * 収益管理DB JPAデータリソース名
     */
    public String syuuekiDataSourceName = "syuuekiDataSource";

    /**
     * 本社区分
     */
    public String honsyaKbn = "H";

    /**
     * 支社区分
     */
    public String shisyaKbn = "S";

    /**
     * 進行基準FLG(進行)
     */
    public String salesClassS = "1";

    /**
     * 進行基準FLG(一般)
     */
    public String salesClassI = "0";

    /**
     * 一括見込のカテゴリコード
     */
    public String ikkatsuCategoryCode = "B0000";

    /**
     * 最終見込/データ区分
     */
    public String finalDataKbn = "F";

    /**
     * 月次確定/データ区分
     */
    public String getsujiDataKbn = "G";

    /**
     * 予算ベース/データ区分
     */
    public String yosanDataKbn = "Y";

    /**
     * 最終見込/収益年月
     */
    public String finalSyuekiYm = "999900F";

    /**
     * 一括見込SP 連番(完成基準案件用)
     */
    public String finalRenban = "0001";

    /**
     * 進行(原価回収)基準用の連番
     */
    public String shinkoRenban = "0000";
    
    /**
     * 一括見込SP 連番シーク
     */
    public String finalRenbanSeq = "90000";

    /**
     * 通貨/円
     */
    public String currencyCodeEn = "JPY";

    /**
     * 月次確定ステータス 確定/承認
     */
    public String wfStatusKakutei = "10";

    /**
     * 月次確定ステータス 提出
     */
    public String wfStatusTeishutsu = "03";

    /**
     * 月次確定ステータス 作成中
     */
    public String wfStatusCreating = "01";
    
    /**
     * 履歴ID(原案)
     */
    public String geRirekiId = "0";

    /**
     * 履歴ID(提出用データ)
     */
    public String teishutsuRirekiId = "1";

    /**
     * ISP区分 ISP分割
     */
    public String ispKbn1 = "1";

    /**
     * ISP区分 ISPのみ
     */
    public String ispKbn2 = "2";
    
    /**
     * 回収情報/金種区分 現金
     */
    public String kaisyuKinsyuGenkin = "1";
    
    /**
     * 回収情報/回収区分 通常
     */
    public String kaisyuKbnNormal = "0";
    
    /**
     * 税区分(輸出免税)
     */
    public String menzeiZeiKbn = "3";

    /**
     * 取消注番のステージID
     */
    public String cancelStageId = "5";
    
    /**
     * 回収レート NG最小値
     */
    public String ngKaisyuRateMini = "10000";
    
    /**
     * ロスコン対象FLG
     */
    public String lossControlTargetFlg = "Y";
}
