package jp.co.toshiba.hby.pspromis.syuueki.service;

import java.util.List;
import java.util.Map;
import javax.ejb.Stateless;
import javax.inject.Inject;
import javax.interceptor.Interceptors;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import jp.co.toshiba.hby.pspromis.syuueki.entity.OperationLog;
import jp.co.toshiba.hby.pspromis.syuueki.interceptor.TranceInterceptor;
import jp.co.toshiba.hby.pspromis.common.jdbc.SqlExecutor;
import jp.co.toshiba.hby.pspromis.syuueki.util.LoginUserInfo;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * PS-Promis収益管理システム
 * 操作ログ登録 Service
 * @author (NPC)S.Ibayashi
 */
@Stateless
@Interceptors({TranceInterceptor.class})
public class OperationLogService {

    @PersistenceContext(unitName = jp.co.toshiba.hby.pspromis.syuueki.util.ConstantString.syuuekiDataSourceName)
    private EntityManager em;

    /**
     * ロガー
     */
    public static final Logger logger = LoggerFactory.getLogger(OperationLogService.class);

    /**
     * ログイン者情報
     */
    @Inject
    private LoginUserInfo loginUserInfo;

    /**
     * Injection sqlExecutor
     */
    @Inject
    protected SqlExecutor sqlExecutor;
    
    /**
     * 操作ログ用dtoの取得
     * @return 
     */
    public OperationLog getOperationLog() {
        OperationLog operationLog = new OperationLog();

        // 無条件に設定可能なものは設定しておく
        operationLog.setOperationCode("SEARCH_JOB");
        operationLog.setObjectId(0);
        operationLog.setObjectType("no edit");
        operationLog.setUserId(loginUserInfo.getUserId());
        operationLog.setUserName(loginUserInfo.getUserName());
        operationLog.setDepartmentCd(loginUserInfo.getDepartmentCd());
        operationLog.setDepartmentName(loginUserInfo.getDepartmentName());

        // ログイン者JobGrを取得(兼務していない場合のみ設定)
        List<Map<String, Object>> jobGrList = loginUserInfo.getJobGrList();
        if (jobGrList != null && jobGrList.size() == 1) {
            String jgrpId = StringUtils.defaultString((String)(jobGrList.get(0).get("JgrpId")));
            String jgrpPetName = StringUtils.defaultString((String)(jobGrList.get(0).get("jgrpPetName")));

            operationLog.setJgrpId(jgrpId);
            operationLog.setJgrpName(jgrpPetName);
        }
        
        return operationLog;
    }

    /**
     * 操作ログ(検索画面)登録　ビジネスロジック
     * @param condition
     * @throws Exception 
     */
    public void insertOperationLogSearch(OperationLog condition) throws Exception {
        sqlExecutor.executeUpdateSql(em, "/sql/operationLog/insertOperationLogSearch.sql", condition);
    }

    /**
     * 画面idに対応するobjectTypeを取得
     * @param procId
     * @return 
     */
    public String getObjectType(String procId) {
        String objectType = " ";
        if ("S003".equals(procId)) {
            objectType = "KIKAN_I";
        } else if ("S004".equals(procId)) {
            objectType = "KIKAN_S";
        } else if ("S001".equals(procId)) {
            objectType = "ICHIRAN_I";
        } else if ("S002".equals(procId)) {
            objectType = "SAISYU";
        } else if ("S005".equals(procId)) {
            objectType = "KOUBAN";
        }
        
        return objectType;
    }
}
