package jp.co.toshiba.hby.pspromis.syuueki.servlet;

import java.util.HashMap;
import java.util.Map;
import javax.inject.Inject;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import jp.co.toshiba.hby.pspromis.syuueki.bean.TakeAnkenInfoBean;
import jp.co.toshiba.hby.pspromis.syuueki.service.TakeAnkenInfoService;
import jp.co.toshiba.hby.pspromis.syuueki.util.ParameterBinder;

/**
 *
 * @author ibayashi
 */
@WebServlet(name="TakeAnkenInfo", urlPatterns={"/servlet/TakeAnkenInfo/*"})
public class TakeAnkenInfoServlet extends AbstractServlet {

    @Inject
    private TakeAnkenInfoBean takeAnkenInfoBean;
    
    @Inject
    private TakeAnkenInfoService takeAnkenInfoService;
    
    /**
     * 発番見合/中計取込(操作ログ登録)
     * @param req
     * @param resp
     * @return
     * @throws Exception 
     */
    public String copyInfoAction(HttpServletRequest req, HttpServletResponse resp) 
    throws Exception {
        logger.info("TakeAnkenInfoServlet#copyInfo");

        // リクエストパラメータをs001Beanの同名フィールドに一括コピー
        ParameterBinder.Bind(takeAnkenInfoBean, req);

        takeAnkenInfoService.copyInfoExecute();

        // ここでは戻すjspが存在しないため、nullを返す。
        return null;
    }

}
