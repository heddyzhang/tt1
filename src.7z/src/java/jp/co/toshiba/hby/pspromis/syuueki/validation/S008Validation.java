package jp.co.toshiba.hby.pspromis.syuueki.validation;

import java.util.HashMap;
import java.util.Map;
import javax.inject.Inject;
import jp.co.toshiba.hby.pspromis.common.util.StringUtil;
import jp.co.toshiba.hby.pspromis.syuueki.bean.S008Bean;
import jp.co.toshiba.hby.pspromis.syuueki.bean.ValidationInfoBean;
import jp.co.toshiba.hby.pspromis.syuueki.entity.SyuGeBukkenInfoTbl;
import jp.co.toshiba.hby.pspromis.syuueki.enums.Env;
import jp.co.toshiba.hby.pspromis.syuueki.enums.Label;
import jp.co.toshiba.hby.pspromis.syuueki.util.Utils;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 *
 * @author
 */
public class S008Validation extends AbstractValidation<S008Bean> {

    public static final Logger logger = LoggerFactory.getLogger(S008Validation.class);

    /**
     * コンストラクタ
     * @param bean
     */
    public S008Validation(S008Bean bean) {
        super(bean);
    }

   /**
     * 検索処理時のバリデーション
     * @param vBean
     * @throws java.lang.Exception
     */
    public void execListValidation(ValidationInfoBean vBean) throws Exception {
        annotationValidate();

        Map<String, String> messages = getValidateMessagess();
        S008Bean bean = getBean();
        String message;

        // 事業部コード:(原子力)であるかを判断
        boolean isNuclearDivision = bean.isNuclearDivision();
        
        //// 独自チェック
        // 白地案件のとき
        if ("2".equals(bean.getEditFlg())) {
            // 案件名称
            //必須チェック
            if (StringUtils.isEmpty(bean.getAnkenName())) {
                message = StringUtils.replace(getValidationMessage("required"), "{0}", Label.getValue(Label.ankenName));
                messages.put("ankenName", message);
                //バイト数チェック
            } else if (Utils.getBytes(bean.getAnkenName()).length > 256) {
                message = StringUtils.replace(getValidationMessage("byteOverError"), "{0}", Label.getValue(Label.ankenName));
                message = StringUtils.replace(message, "{1}", "256");
                messages.put("ankenName", message);
            }

            // 注文主
            //必須チェック
            if (StringUtils.isEmpty(bean.getTradeName())) {
                message = StringUtils.replace(getValidationMessage("required"), "{0}", Label.getValue(Label.tradeName));
                messages.put("tradeName", message);
                //バイト数チェック
            } else if (Utils.getBytes(bean.getTradeName()).length > 256) {
                message = StringUtils.replace(getValidationMessage("byteOverError"), "{0}", Label.getValue(Label.tradeName));
                message = StringUtils.replace(message, "{1}", "256");
                messages.put("tradeName", message);
            }

            // 設置場所
            //必須チェック
            if (StringUtils.isEmpty(bean.getStchName())) {
                message = StringUtils.replace(getValidationMessage("required"), "{0}", Label.getValue(Label.stchName));
                messages.put("stchName", message);
                //バイト数チェック
            } else if (Utils.getBytes(bean.getStchName()).length > 256) {
                message = StringUtils.replace(getValidationMessage("byteOverError"), "{0}", Label.getValue(Label.stchName));
                message = StringUtils.replace(message, "{1}", "256");
                messages.put("stchName", message);
            }

            // 取扱店コード
            //バイト数チェック
            if (!StringUtils.isEmpty(bean.getToriatsuCd())) {
                if (Utils.getBytes(bean.getToriatsuCd()).length > 33) {
                    message = StringUtils.replace(getValidationMessage("byteOverError"), "{0}", Label.getValue(Label.toriatsuCd));
                    message = StringUtils.replace(message, "{1}", "33");
                    messages.put("toriatsuCd", message);
                }
            }

            // サブBU
            //必須チェック
            if (StringUtils.isEmpty(bean.getSubBu())) {
                message = StringUtils.replace(getValidationMessage("requiredSelect"), "{0}", Label.getValue(Label.subBu));
                messages.put("subBu", message);
            }

            // 実施年度/定検回数
            if (isNuclearDivision) {
                // 組み合わせチェック
                if ((StringUtils.isNotEmpty(bean.getJissiNendo())) && (StringUtils.isNotEmpty(bean.getTeiken()))) {
                    messages.put("jissiNendo", getValidationMessage("teikenError"));
                } else if (StringUtils.isNotEmpty(bean.getJissiNendo())) {
                    // 数値チェック
                    if (!isValidNumber(bean.getJissiNendo(), 4, 0)) {
                        message = StringUtils.replace(getValidationMessage("integerKetaError"), "{0}", Label.getValue(Label.jisshiNendo));
                        message = StringUtils.replace(message, "{1}", "4");
                        messages.put("jissiNendo", message);
                    }
                } else if (StringUtils.isNotEmpty(bean.getTeiken())) {
                    // 数値チェック
                    if (!isValidNumber(bean.getTeiken(), 5, 0)) {
                        message = StringUtils.replace(getValidationMessage("integerKetaError"), "{0}", Label.getValue(Label.teiken));
                        message = StringUtils.replace(message, "{1}", "5");
                        messages.put("teiken", message);
                    }
                }
            }

            // 販売チーム
            //必須チェック
            if (StringUtils.isEmpty(bean.getEgTeamCd())) {
                message = StringUtils.replace(getValidationMessage("required"), "{0}", Label.getValue(Label.salesTeam));
                messages.put("egTeamCd", message);
                //バイト数チェック    扱いチームコードのバイト数に合わせて最大10とする
            } else if (Utils.getBytes(bean.getEgTeamCd()).length > 10) {
                message = StringUtils.replace(getValidationMessage("byteOverError"), "{0}", Label.getValue(Label.salesTeam));
                message = StringUtils.replace(message, "{1}", "10");
                messages.put("egTeamCd", message);
            }

            // 販売C
            //必須チェック
            if (StringUtils.isEmpty(bean.getHbCCd())) {
                message = StringUtils.replace(getValidationMessage("required"), "{0}", Label.getValue(Label.salesCSE));
                messages.put("hbCCd", message);
                //バイト数チェック
            } else if (Utils.getBytes(bean.getHbCCd()).length > 15) {
                message = StringUtils.replace(getValidationMessage("byteOverError"), "{0}", Label.getValue(Label.salesCSE));
                message = StringUtils.replace(message, "{1}", "15");
                messages.put("hbCCd", message);
            }

            // 販売S
            //必須チェック
            if (StringUtils.isEmpty(bean.getHbSCd())) {
                message = StringUtils.replace(getValidationMessage("required"), "{0}", Label.getValue(Label.salesCSE));
                messages.put("hbCCd", message);
                //バイト数チェック
            } else if (Utils.getBytes(bean.getHbSCd()).length > 15) {
                message = StringUtils.replace(getValidationMessage("byteOverError"), "{0}", Label.getValue(Label.salesCSE));
                message = StringUtils.replace(message, "{1}", "15");
                messages.put("hbCCd", message);
            }

            // 販売E
            //必須チェック
            if (StringUtils.isEmpty(bean.getHbECd())) {
                message = StringUtils.replace(getValidationMessage("required"), "{0}", Label.getValue(Label.salesCSE));
                messages.put("hbCCd", message);
                //バイト数チェック
            } else if (Utils.getBytes(bean.getHbECd()).length > 15) {
                message = StringUtils.replace(getValidationMessage("byteOverError"), "{0}", Label.getValue(Label.salesCSE));
                message = StringUtils.replace(message, "{1}", "15");
                messages.put("hbCCd", message);
            }

            // 製造チーム
            //必須チェック
            if (StringUtils.isEmpty(bean.getSzTeamCd())) {
                message = StringUtils.replace(getValidationMessage("required"), "{0}", Label.getValue(Label.seizouTeam));
                messages.put("szTeamCd", message);
                //バイト数チェック    扱いチームコードのバイト数に合わせて最大10とする
            } else if (Utils.getBytes(bean.getSzTeamCd()).length > 10) {
                message = StringUtils.replace(getValidationMessage("byteOverError"), "{0}", Label.getValue(Label.seizouTeam));
                message = StringUtils.replace(message, "{1}", "10");
                messages.put("szTeamCd", message);
            }

            // 製造C
            //バイト数チェック
            if (!StringUtils.isEmpty(bean.getSzCCd())) {
                if (Utils.getBytes(bean.getSzCCd()).length > 15) {
                    message = StringUtils.replace(getValidationMessage("byteOverError"), "{0}", Label.getValue(Label.seizouCSE));
                    message = StringUtils.replace(message, "{1}", "15");
                    messages.put("szCCd", message);
                }
            }

            // 製造S
            //バイト数チェック
            if (!StringUtils.isEmpty(bean.getSzSCd())) {
                if (Utils.getBytes(bean.getSzSCd()).length > 15) {
                    message = StringUtils.replace(getValidationMessage("byteOverError"), "{0}", Label.getValue(Label.seizouCSE));
                    message = StringUtils.replace(message, "{1}", "15");
                    messages.put("szCCd", message);
                }
            }

            // 製造E
            //バイト数チェック
            if (!StringUtils.isEmpty(bean.getSzECd())) {
                if (Utils.getBytes(bean.getSzECd()).length > 15) {
                    message = StringUtils.replace(getValidationMessage("byteOverError"), "{0}", Label.getValue(Label.seizouCSE));
                    message = StringUtils.replace(message, "{1}", "15");
                    messages.put("szCCd", message);
                }
            }

            //業態
            //バイト数チェック
            if (!StringUtils.isEmpty(bean.getGyotai())) {
                if (Utils.getBytes(bean.getGyotai()).length > 6) {
                    message = StringUtils.replace(getValidationMessage("byteOverError"), "{0}", Label.getValue(Label.businessCategory));
                    message = StringUtils.replace(message, "{1}", "6");
                    messages.put("gyotai", message);
                }
            }

            //営業JobGr
            //必須チェック
            if (StringUtils.isEmpty(bean.getEigJobgrCd())) {
                message = StringUtils.replace(getValidationMessage("requiredSelect"), "{0}", Label.getValue(Label.eigyoJobGroupId2));
                messages.put("eigJobgrCd", message);
            }

            // (発番)受注年月
            //必須チェック
            if (StringUtils.isEmpty(bean.getHatJyuchuDateI())) {
                message = StringUtils.replace(getValidationMessage("required"), "{0}", Label.getValue(Label.hatJuchuYm));
                messages.put("hatJyuchuDateI", message);
                //日付型チェック
            } else if (!isValidYm(bean.getHatJyuchuDateI())) {
                message = StringUtils.replace(getValidationMessage("ymError"), "{0}", Label.getValue(Label.hatJuchuYm));
                messages.put("hatJyuchuDateI", message);
                //過去月チェック (2017/10/04NPC)過去月チェックは外す
            }
//            else if (bean.getNowYm().compareTo(bean.getHatJyuchuDateI()) > 0) {
//               message = StringUtils.replace(getValidationMessage("kakoYmError"), "{0}", Label.getValue(Label.juchuYm));
//                messages.put("hatJyuchuDateI", message);
//            }

            // (発番)出荷日限
            //日付型チェック
            if (!StringUtils.isEmpty(bean.getHatSyukkaNichigenI())) {
                if (!isValidYm(bean.getHatSyukkaNichigenI())) {
                    message = StringUtils.replace(getValidationMessage("ymError"), "{0}", Label.getValue(Label.hatForwardTermYm));
                    messages.put("hatSyukkaNichigenI", message);
                }
            }

            // (発番)売上予定
            //必須チェック
            if (StringUtils.isEmpty(bean.getUriageEndI())) {
                message = StringUtils.replace(getValidationMessage("required"), "{0}", Label.getValue(Label.hatUriageYotei));
                messages.put("uriageEndI", message);
                //日付型チェック
            } else if (!isValidYm(bean.getUriageEndI())) {
                message = StringUtils.replace(getValidationMessage("ymError"), "{0}", Label.getValue(Label.hatUriageYotei));
                messages.put("uriageEndI", message);
                //過去月チェック (2017/10/04NPC)売上予定が変更されていない場合は過去月でもOKにする
            } else if (bean.getNowYm().compareTo(bean.getUriageEndI()) > 0 && !(StringUtils.defaultString(bean.getUriageEndI()).equals(bean.getUriageEndIDefault())) ) {
                message = StringUtils.replace(getValidationMessage("kakoYmError"), "{0}", Label.getValue(Label.hatUriageYotei));
                messages.put("uriageEndI", message);
            }

            // (発番)回収予定
            //日付型チェック
            if (!StringUtils.isEmpty(bean.getHatKaisyuYoteiI())) {
                if (!isValidYm(bean.getHatKaisyuYoteiI())) {
                    message = StringUtils.replace(getValidationMessage("ymError"), "{0}", Label.getValue(Label.hatRecoveryYoteiYm));
                    messages.put("hatKaisyuYoteiI", message);
                }
            }

            // ISP事業部
            //バイト数チェック
            if (!StringUtils.isEmpty(bean.getIspDivisionNm())) {
                if (Utils.getBytes(bean.getIspDivisionNm()).length > 12) {
                    String lbl = Label.getValue(Label.isp) + Label.getValue(Label.division);
                    message = StringUtils.replace(getValidationMessage("byteOverError"), "{0}", lbl);
                    message = StringUtils.replace(message, "{1}", "12");
                    messages.put("ispDivisionNm", message);
                }
            }

            // ISP区分
            //必須チェック
            if (StringUtils.isEmpty(bean.getIspKbn())) {
                message = StringUtils.replace(getValidationMessage("requiredSelect"), "{0}", Label.getValue(Label.ispKbn));
                messages.put("ispKbn", message);
            }

            // 関連ISP案件
            //必須・バイト数チェック
            if ("1".equals(bean.getIspKbn()) && StringUtils.isEmpty(bean.getIspRelateId())) {
                // ISP区分が"ISP分割"の場合、必須にする。
                message = getValidationMessage("requiredIspRelateIdForSplit");
                messages.put("ispRelateId", message);
            }
            if (!StringUtils.isEmpty(bean.getIspRelateId())) {
                if (Utils.getBytes(bean.getIspRelateId()).length > 32) {
                    message = StringUtils.replace(getValidationMessage("byteOverError"), "{0}", Label.getValue(Label.ispRelateId));
                    message = StringUtils.replace(message, "{1}", "32");
                    messages.put("ispRelateId", message);
                }
            }


        }

        // 問題案件_コメント
        //バイト数チェック
        if (!StringUtils.isEmpty(bean.getMondaiComment())) {
            if (Utils.getBytes(bean.getMondaiComment()).length > 2000) {
                message = StringUtils.replace(getValidationMessage("byteOverError"), "{0}", Label.getValue(Label.ankenJyokyoMondaiComment));
                message = StringUtils.replace(message, "{1}", "2000");
                messages.put("mondaiComment", message);
            }
        }

        // 収益分類
        if (isNuclearDivision) {
            //必須チェック
            if (StringUtils.isEmpty(bean.getBunruiCd())) {
                message = StringUtils.replace(getValidationMessage("requiredSelect"), "{0}", Label.getValue(Label.syuuekiBunrui));
                messages.put("bunruiCd", message);
            }
        }

        // 設備分類
         if (isNuclearDivision) {
            //必須チェック
            if (StringUtils.isEmpty(bean.getSetuBunruiCd())) {
                message = StringUtils.replace(getValidationMessage("requiredSelect"), "{0}", Label.getValue(Label.setuBunrui));
                messages.put("setuBunruiCd", message);
            }
        }

        // 2017/11/14 ADD #5 #12 #22 （収益）受注年月と（収益）売上予定を加える
        // (収益)受注年月
        //日付型チェック
        if (!StringUtils.isEmpty(bean.getJyuchuEnd())) {
            if (!isValidYm(bean.getJyuchuEnd())) {
                message = StringUtils.replace(getValidationMessage("ymError"), "{0}", Label.getValue(Label.syuJuchuYm));
                messages.put("jyuchuEnd", message);
            //} else if ((!"1".equals(bean.getJyuchuEndEditFlg())) && (!bean.getJyuchuEnd().equals(bean.getOldJyuchuEnd()))) {
            } else if ((!"1".equals(bean.getJyuchuSplitFlg())) && (!bean.getJyuchuEnd().equals(bean.getOldJyuchuEnd()))) {
                message = StringUtils.replace(getValidationMessage("splitExpectation"), "{0}", Label.getValue(Label.syuJuchuYm));
                messages.put("jyuchuEnd", message);
            } else if ((bean.getNowYm().compareTo(bean.getJyuchuEnd()) > 0) && (!bean.getJyuchuEnd().equals(bean.getOldJyuchuEnd()))) {
                message = StringUtils.replace(getValidationMessage("kakoYmError"), "{0}", Label.getValue(Label.syuJuchuYm));
                messages.put("jyuchuEnd", message);
            }
        } else if (StringUtil.isNotEmpty(bean.getOldJyuchuEnd())) {
            message = StringUtils.replace(getValidationMessage("existAndRequired"), "{0}", Label.getValue(Label.syuJuchuYm));
            messages.put("jyuchuEnd", message);
        }

        // 2017/11/14 ADD #5 #12 #22 （収益）受注年月と（収益）売上予定を加える
        // (収益)売上予定
        //日付型チェック
        if (!StringUtils.isEmpty(bean.getUriageEnd())) {
            if (!isValidYm(bean.getUriageEnd())) {
                message = StringUtils.replace(getValidationMessage("ymError"), "{0}", Label.getValue(Label.syuUriageYotei));
                messages.put("uriageEnd", message);
            //} else if ((!"1".equals(bean.getUriageEndEditFlg())) && (!bean.getUriageEnd().equals(bean.getOldUriageEnd()))) {
            } else if ((!"1".equals(bean.getUriageSplitFlg())) && (!bean.getUriageEnd().equals(bean.getOldUriageEnd()))) {
                message = StringUtils.replace(getValidationMessage("splitExpectation"), "{0}", Label.getValue(Label.syuUriageYotei));
                messages.put("uriageEnd", message);
            } else if ((bean.getNowYm().compareTo(bean.getUriageEnd()) > 0) && (!bean.getUriageEnd().equals(bean.getOldUriageEnd()))) {
                message = StringUtils.replace(getValidationMessage("kakoYmError"), "{0}", Label.getValue(Label.syuUriageYotei));
                messages.put("uriageEnd", message);
            }
        } else if (StringUtil.isNotEmpty(bean.getOldUriageEnd())) {
            message = StringUtils.replace(getValidationMessage("existAndRequired"), "{0}", Label.getValue(Label.syuUriageYotei));
            messages.put("uriageEnd", message);
        }

        // 2017/11/14 MOD #5 #12 #22 （収益）受注年月と（収益）売上予定を加える
        // (収益)回収月
        //日付型チェック
        if (!StringUtils.isEmpty(bean.getKaisyuEnd())) {
            if (!isValidYm(bean.getKaisyuEnd())) {
                message = StringUtils.replace(getValidationMessage("ymError"), "{0}", Label.getValue(Label.syuRecoveryYm2));
                messages.put("kaisyuEnd", message);
            //} else if ((!"1".equals(bean.getKaisyuEndEditFlg())) && (!bean.getKaisyuEnd().equals(bean.getOldKaisyuEnd()))) {
            } else if ((!"1".equals(bean.getKaisyuSplitFlg())) && (!bean.getKaisyuEnd().equals(bean.getOldKaisyuEnd()))) {
                message = StringUtils.replace(getValidationMessage("splitExpectation"), "{0}", Label.getValue(Label.syuRecoveryYm2));
                messages.put("kaisyuEnd", message);
            } else if ((bean.getNowYm().compareTo(bean.getKaisyuEnd()) > 0) && (!bean.getKaisyuEnd().equals(bean.getOldKaisyuEnd()))) {
                message = StringUtils.replace(getValidationMessage("kakoYmError"), "{0}", Label.getValue(Label.syuRecoveryYm2));
                messages.put("kaisyuEnd", message);
            }
        } else if (StringUtil.isNotEmpty(bean.getOldKaisyuEnd())) {
            message = StringUtils.replace(getValidationMessage("existAndRequired"), "{0}", Label.getValue(Label.syuRecoveryYm2));
            messages.put("kaisyuEnd", message);
        }

        // 2017/11/14 MOD #5 #12 #22 納期を年月日に変更
        // 納期
        //日付型チェック
        if (!StringUtils.isEmpty(bean.getNoki())) {
            if (!isValidYmd(bean.getNoki())) {
                message = StringUtils.replace(getValidationMessage("ymdError"), "{0}", Label.getValue(Label.noki));
                messages.put("noki", message);
            }
        }

        // 検収月
        //日付型チェック
        if (!StringUtils.isEmpty(bean.getKensyutuki())) {
            if (!isValidYm(bean.getKensyutuki())) {
                message = StringUtils.replace(getValidationMessage("ymError"), "{0}", Label.getValue(Label.kensyutuki));
                messages.put("kensyutuki", message);
            }
        }

        // 注入開始年月
        //日付型チェック
        if (!StringUtils.isEmpty(bean.getChunyuStartYm())) {
            if (!isValidYm(bean.getChunyuStartYm())) {
                message = StringUtils.replace(getValidationMessage("ymError"), "{0}", Label.getValue(Label.chunyuStartYm));
                messages.put("chunyuStartYm", message);
            }
        }

        vBean.setMessages(messages);
    }
}
