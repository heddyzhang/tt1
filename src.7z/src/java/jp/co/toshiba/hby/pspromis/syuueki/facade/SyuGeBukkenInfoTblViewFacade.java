package jp.co.toshiba.hby.pspromis.syuueki.facade;

import java.util.List;
import javax.ejb.Stateless;
import javax.inject.Inject;
import javax.interceptor.Interceptors;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import jp.co.toshiba.hby.pspromis.syuueki.entity.SyuGeBukkenInfoTblView;
import jp.co.toshiba.hby.pspromis.syuueki.interceptor.TranceInterceptor;
import jp.co.toshiba.hby.pspromis.syuueki.util.Utils;
import org.apache.commons.beanutils.PropertyUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 *
 * @author ibayashi
 */
@Stateless
@Interceptors({TranceInterceptor.class})
public class SyuGeBukkenInfoTblViewFacade extends AbstractFacade<SyuGeBukkenInfoTblView> {

    private static final Logger logger = LoggerFactory.getLogger(SyuGeBukkenInfoTblViewFacade.class);

    @PersistenceContext(unitName = jp.co.toshiba.hby.pspromis.syuueki.util.ConstantString.syuuekiDataSourceName)
    private EntityManager em;

    @Override
    protected EntityManager getEntityManager() {
        return em;
    }

    /**
     * Injection util
     */
    @Inject
    private Utils util;

    public SyuGeBukkenInfoTblViewFacade() {
        super(SyuGeBukkenInfoTblView.class);
    }

    /**
     * 案件一覧データのサマリ値(件数、SP、NET合計)を取得
     * @param condition
     * @return
     */
    public SyuGeBukkenInfoTblView getAnkenSum(Object condition) {
        SyuGeBukkenInfoTblView entity = new SyuGeBukkenInfoTblView();

        List<SyuGeBukkenInfoTblView> list
                = sqlExecutor.getResultList(em, SyuGeBukkenInfoTblView.class, "/sql/selectListSyuueki.sql", condition);
        
        if (list.size() > 0) {
            entity = list.get(0);
        }
        
        //sqlExecutor.getSingleResultは現状同一SQLが2度実行されてしまう作りとなっているため、上記のsqlExecutor.getResultListに変更した。
//        SyuGeBukkenInfoTblView entity =
//                sqlExecutor.getSingleResult(em, SyuGeBukkenInfoTblView.class, "/sql/selectListSyuueki.sql", condition);

        return entity;
    }

    /**
     * 案件一覧データを取得
     * @param condition
     * @param page
     * @return
     * @throws Exception 
     */
    public List<SyuGeBukkenInfoTblView> getAnkenList(Object condition, Integer page) throws Exception {
        int limit = util.getPageLimit();
        int offset = util.getPageOffset(page);
        int end = offset + limit;

        PropertyUtils.setProperty(condition, "offset", offset);
        PropertyUtils.setProperty(condition, "end", end);

//        List<SyuGeBukkenInfoTblView> list
//                = sqlExecutor.getResultList(em, SyuGeBukkenInfoTblView.class, "/sql/selectListSyuueki.sql", condition, limit, offset);

        List<SyuGeBukkenInfoTblView> list
                = sqlExecutor.getResultList(em, SyuGeBukkenInfoTblView.class, "/sql/selectListSyuueki.sql", condition);
        
        return list;
    }

    /**
     * 前回分の案件データを取得
     * @param condition
     * @return
     * @throws Exception 
     */
    public SyuGeBukkenInfoTblView getOldAnken(Object condition) throws Exception {
        SyuGeBukkenInfoTblView rec
                = sqlExecutor.getSingleResult(em, SyuGeBukkenInfoTblView.class, "/sql/selectOldListSyuueki.sql", condition);

        return rec;
    }
}
