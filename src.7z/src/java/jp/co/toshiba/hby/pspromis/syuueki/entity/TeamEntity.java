package jp.co.toshiba.hby.pspromis.syuueki.entity;

import java.math.BigInteger;
import java.io.Serializable;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;

/**
 *
 * @author ibayashi
 */
@Entity
public class TeamEntity implements Serializable {
    private static final long serialVersionUID = 1L;
    
    @Id
    @Column(name = "DATA_SEQ")
    private BigInteger dataSeq;
    
    @Column(name = "USER_ID")
    private String userId;

    @Column(name = "TEAM_CD")
    private String teamCd;
    
    //@Column(name = "HS_KBN")
    //private String hsKbn;

    public TeamEntity() {
    }

    public BigInteger getDataSeq() {
        return dataSeq;
    }

    public void setDataSeq(BigInteger dataSeq) {
        this.dataSeq = dataSeq;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public String getTeamCd() {
        return teamCd;
    }

    public void setTeamCd(String teamCd) {
        this.teamCd = teamCd;
    }

//    public String getHsKbn() {
//        return hsKbn;
//    }
//
//    public void setHsKbn(String hsKbn) {
//        this.hsKbn = hsKbn;
//    }

}
