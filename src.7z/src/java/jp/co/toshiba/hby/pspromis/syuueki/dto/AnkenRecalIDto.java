
package jp.co.toshiba.hby.pspromis.syuueki.dto;

/**
 * PS-Promis収益管理システム
 * RDBMS 一般案件用の再計算パッケージCall用パラメータdto
 * @author (NPS)S.Ibayashi
 */
public class AnkenRecalIDto extends AnkenRecalDto{
}
