/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package jp.co.toshiba.hby.pspromis.syuueki.service;

import java.util.List;
import javax.ejb.Stateless;
import javax.inject.Inject;
import javax.interceptor.Interceptors;
import jp.co.toshiba.hby.pspromis.syuueki.bean.S026Bean;
import jp.co.toshiba.hby.pspromis.syuueki.entity.SyuInfoMessageMst;
import jp.co.toshiba.hby.pspromis.syuueki.facade.SyuInfoMessageMstFacade;
import jp.co.toshiba.hby.pspromis.syuueki.interceptor.TranceInterceptor;

/**
 *
 * @author watabe
 */
@Stateless
@Interceptors({TranceInterceptor.class})
public class S026Service {
    
    @Inject
    private S026Bean s026Bean;
    
    @Inject
    private SyuInfoMessageMstFacade syuInfoMessageMstFacade;

    public void getUpdateInformation(){
        //SQLの結果をBeanのListに格納
        List<SyuInfoMessageMst> list = syuInfoMessageMstFacade.getMessageData();
        
        s026Bean.setSyuInfoMessageMst(list);
    }
}
