package jp.co.toshiba.hby.pspromis.syuueki.servlet;

import java.util.HashMap;
import java.util.Map;
import javax.inject.Inject;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpServletRequest;
import jp.co.toshiba.hby.pspromis.syuueki.bean.ResultMessageBean;
import jp.co.toshiba.hby.pspromis.syuueki.bean.S019Bean;
import jp.co.toshiba.hby.pspromis.syuueki.service.S019Service;
import jp.co.toshiba.hby.pspromis.syuueki.util.CdiUtils;
import jp.co.toshiba.hby.pspromis.syuueki.util.ParameterBinder;

/**
 * ES-Promis収益管理システム
 * 発番引当処理
 * @author 
 */
@WebServlet(name="S019", urlPatterns={"/servlet/S019", "/servlet/S019/*"})
public class S019Servlet extends AbstractServlet {

    private static final String INDEX_JSP = "S019/hatHikiate.jsp";
    
    @Inject
    private S019Bean s019Bean;

    @Inject
    private S019Service s019Service;

    /**
     * 初期表示
     * @param req
     * @param resp
     * @return
     * @throws Exception 
     */
    public String indexAction(HttpServletRequest req, HttpServletResponse resp)
    throws Exception {
        // リクエストパラメータをS019Beanの同名フィールドに一括コピー
        ParameterBinder.Bind(s019Bean, req);

        // サービスの実行(トランザクションの単位にもなる)
        s019Service.indexExecute();

        return INDEX_JSP;
    }

    /**
     * 検索表示
     * @param req
     * @param resp
     * @return
     * @throws Exception 
     */
    public String searchAction(HttpServletRequest req, HttpServletResponse resp)
    throws Exception {
        // リクエストパラメータをS019Beanの同名フィールドに一括コピー
        ParameterBinder.Bind(s019Bean, req);

        // サービスの実行(トランザクションの単位にもなる)
        s019Service.searchExecute();

        return INDEX_JSP;
    }

    /**
     * 保存(実行)処理
     * @param req
     * @param resp
     * @return
     * @throws Exception 
     */
    public String saveAction(HttpServletRequest req, HttpServletResponse resp) throws Exception {
        // リクエストパラメータをS018Beanの同名フィールドに一括コピー
        ParameterBinder.Bind(s019Bean, req);

        s019Service.saveExecute();

        Map<String, Object> jsonMap = new HashMap<>();
        ResultMessageBean resultMessageBean = CdiUtils.getBean(ResultMessageBean.class);
        resultMessageBean.createResultMessage(jsonMap);
        jsonMap.put("orderNo", s019Bean.getSelectedOrderNo());
        jsonMap.put("orderItem", s019Bean.getSelectorderItem());
        resopnseDecodeJson(resp, jsonMap);
        return null;
    }

}
