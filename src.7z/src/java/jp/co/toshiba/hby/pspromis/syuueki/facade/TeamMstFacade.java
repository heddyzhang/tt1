package jp.co.toshiba.hby.pspromis.syuueki.facade;

import java.util.List;
import java.util.ArrayList;
import java.util.Set;
import java.util.HashSet;
import javax.ejb.Stateless;
import javax.inject.Inject;
import javax.interceptor.Interceptors;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import jp.co.toshiba.hby.pspromis.common.jdbc.SqlExecutor;
import jp.co.toshiba.hby.pspromis.syuueki.entity.TeamEntity;
import jp.co.toshiba.hby.pspromis.syuueki.interceptor.TranceInterceptor;
import org.apache.commons.collections.CollectionUtils;

/**
 * チームコード取得関連
 * @author ibayashi
 */
@Stateless
@Interceptors({TranceInterceptor.class})
public class TeamMstFacade {

    @PersistenceContext(unitName = jp.co.toshiba.hby.pspromis.syuueki.util.ConstantString.syuuekiDataSourceName)
    private EntityManager em;
    
    @Inject
    protected SqlExecutor sqlExecutor;
    
    public List<TeamEntity> findUserTeamList(String userId) {
        TeamEntity condition = new TeamEntity();
        condition.setUserId(userId);
        
        List<TeamEntity> list = sqlExecutor.getResultList(em, TeamEntity.class, "/sql/teamMst/selectUserTeamList.sql", condition);
        return changeDistinctList(list);
    }

    private List<TeamEntity> changeDistinctList(List<TeamEntity> list) {
        // チームコード一覧の同一チームコード重複除去
        List<TeamEntity> distinctList = new ArrayList<>();
        if (CollectionUtils.isNotEmpty(list)) {
            Set<String> teamCodeSet = new HashSet<>();
            for (TeamEntity entity: list) {
                if (!teamCodeSet.contains(entity.getTeamCd())) {
                    distinctList.add(entity);
                    teamCodeSet.add(entity.getTeamCd());
                }
            }
        }
        return distinctList;
    }
}
