/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package jp.co.toshiba.hby.pspromis.syuueki.facade;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.ejb.Stateless;
import javax.inject.Inject;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import jp.co.toshiba.hby.pspromis.syuueki.entity.TradeMst;
import jp.co.toshiba.hby.pspromis.syuueki.util.Utils;

/**
 *
 * @author ibayashi
 */
@Stateless
public class TradeMstFacade extends AbstractFacade<TradeMst> {
    @PersistenceContext(unitName = "syuuekiDataSource")
    private EntityManager em;

    @Inject
    private Utils util;
    
    @Override
    protected EntityManager getEntityManager() {
        return em;
    }

    public TradeMstFacade() {
        super(TradeMst.class);
    }

    /**
     * 設置先場所の件数を取得
     * @param condition
     * @return 
     */
    public Integer getCount(Object condition) {
        if (condition == null) {
            condition = new HashMap<>();
        }
        if (condition instanceof Map) {
            ((Map)condition).put("listFlg", "1");
        }
        Integer count = sqlExecutor.getCount(em, "/sql/selectTradeMst.sql", condition);
        return count;
    }
    
    /**
     * 設置先場所の一覧を取得
     * @param condition
     * @param page
     * @return 
     */
    public List<TradeMst> getList(Object condition, Integer page) {
        if (condition == null) {
            condition = new HashMap<>();
        }
        if (condition instanceof Map) {
            ((Map)condition).put("listFlg", "0");
        }

        int limit = util.getPageLimit();
        int offset = util.getPageOffset(page);

        List<TradeMst> list = sqlExecutor.getResultList(em, TradeMst.class, "/sql/selectTradeMst.sql", condition, limit, offset);
        return list;
    }

}
