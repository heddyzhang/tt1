package jp.co.toshiba.hby.pspromis.syuueki.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.lang.reflect.Method;
import javax.servlet.ServletException;
import javax.servlet.RequestDispatcher;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import jp.co.toshiba.hby.pspromis.common.util.StringUtil;
import jp.co.toshiba.hby.pspromis.syuueki.enums.Env;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import com.fasterxml.jackson.databind.ObjectMapper;
import java.io.UnsupportedEncodingException;
import jp.co.toshiba.hby.pspromis.common.exception.PspRunTimeExceotion;
import jp.co.toshiba.hby.pspromis.syuueki.exception.NoSyuekiFlgException;

/**
 * Servlet3.0 基底クラス
 * @author (NPC)S.Ibayasi
 */
//@WebServlet(name="AbstractServlet")
public abstract class AbstractServlet extends HttpServlet {

    /**
     * ロガー
     */
    public final Logger logger = LoggerFactory.getLogger(this.getClass());

    /**
     * 
     * @param req
     * @param resp
     * @throws ServletException
     * @throws IOException 
     */
    public void process(HttpServletRequest req, HttpServletResponse resp)
    throws ServletException, IOException, PspRunTimeExceotion {

        try {
            // URIを取得
            String requestUri = req.getRequestURI();
            String actionMethodName;

            logger.info("URI=" + requestUri);

            String separatorAry[] = StringUtil.split(requestUri, "/");

            if (separatorAry.length <= 3) {
                actionMethodName = "index";
            } else if (separatorAry.length > 4) {
                throw new ServletException();
            } else {
                int pathSeparatorIndex  = requestUri.lastIndexOf("/") + 1;
                actionMethodName = requestUri.substring(pathSeparatorIndex);
            }

            logger.debug("actionMethodName=" + actionMethodName);

            // Actionメソッド実行
            // URL+"Action"名を継承元で実装し、それを実行する。
            Method method = this.getClass().getMethod(actionMethodName + "Action",
                    new Class[]{HttpServletRequest.class, HttpServletResponse.class});

            Object jsp = method.invoke(this, new Object[]{req, resp});

            if (jsp != null && !String.valueOf(jsp).equals("")) {
                String strJsp = String.valueOf(jsp);
                strJsp = "/WEB-INF/view/" + strJsp;
                RequestDispatcher dispatch = req.getRequestDispatcher(strJsp);
                dispatch.forward(req, resp);
            }

        } catch (Throwable e) {
            ////// 通常のエラー
            logger.error("エラー発生", e);
            resp.setHeader("X-ERROR-PAGE", "1");

            if (e instanceof ServletException) {
                throw (ServletException)e;
            } else {
                Throwable rte = null;
                rte = e.getCause();
                if (rte.getCause() != null) {
                    rte = e.getCause().getCause();
                }
                if (rte instanceof NoSyuekiFlgException) {
                    ////// (2018A)収益対象外の案件を開こうとしたとき、同一注番の別案件を開く
                    NoSyuekiFlgException noSyuekiFlgException = (NoSyuekiFlgException)rte;
                    resp.sendRedirect(req.getContextPath() + "/servlet/OrderNoLink?orderNo=" + noSyuekiFlgException.getOrderNo());
                    return;
                }
                if (rte instanceof PspRunTimeExceotion) {
                    req.setAttribute("ERROR_MESSAGE", rte.getMessage());
                    throw (PspRunTimeExceotion) rte;
                }

                throw new ServletException(e);
            }
        }
    }

    /**
     * 指定URLにリダイレクトする
     * @param resp
     * @param redirectUrl
     * @throws java.io.IOException
     */
    protected void redirect(HttpServletResponse resp, String redirectUrl) throws IOException {
        resp.sendRedirect(redirectUrl);
    }
 
    /**
     * csvファイルダウンロード用のresopnse header設定
     * @param resp
     * @param fileName
     * @throws java.io.UnsupportedEncodingException
     */
    protected void setDownloadCsvHeader(HttpServletResponse resp, String fileName) throws UnsupportedEncodingException {
        String charset = Env.getValue(Env.CsvCharSet);

        // 文字コード設定
        resp.setContentType("text/html; charset=" + charset);
        // ファイル名設定（ファイル名を設定しないと、htmlとして画面に表示されてしまいます
        resp.setHeader("Content-Disposition", "attachment; filename=\"" + (new String(fileName.getBytes("Windows-31J"), "ISO8859_1")) + "\"");
    }

    /**
     * 指定オブジェクトをjsonにencodeして出力
     * @param resp
     * @param jsonObj
     * @throws java.io.IOException
     */
    protected void resopnseDecodeJson(HttpServletResponse resp, Object jsonObj) throws IOException {
        String charset = Env.getValue(Env.Charset);
        
        resp.setContentType("application/json;charset=" + charset);
        resp.setHeader("Cache-Control", "no-cache");
        resp.setHeader("Pragma", "no-cache");
        PrintWriter pWriter = resp.getWriter();

        ObjectMapper objectMapper = new ObjectMapper();
        String json = objectMapper.writeValueAsString(jsonObj);

        logger.debug("json response=" + json);
        
        pWriter.write(json);
 
        pWriter.flush();
    }

    /**
     * 指定オブジェクトをplain textにencodeして出力
     * @param resp
     */
    protected void resopnseText(HttpServletResponse resp, String text) throws IOException {
        String charset = Env.getValue(Env.Charset);
        
        resp.setContentType("text/plain;charset=" + charset);
        resp.setHeader("Cache-Control", "no-cache");
        resp.setHeader("Pragma", "no-cache");
        PrintWriter pWriter = resp.getWriter();
        
        logger.debug("text response=" + text);

        pWriter.write(text);
 
        pWriter.flush();
    }
    
    /**
     * service
     * この中で直接ビジネスロジック実装を禁止するため、finalにする。
     * @param req
     * @param resp
     * @throws ServletException
     * @throws IOException 
     */
    @Override
    protected final void service(HttpServletRequest req, HttpServletResponse resp)
    throws ServletException, IOException {
        process(req, resp);
    }
    
    /**
     * doPost
     * この中で直接ビジネスロジック実装を禁止するため、finalにする。
     * @param req
     * @param resp
     * @throws ServletException
     * @throws IOException 
     */
    @Override
    protected final void doPost(HttpServletRequest req, HttpServletResponse resp)
    throws ServletException, IOException {
        process(req, resp);
    }

    /**
     * doGet
     * この中で直接ビジネスロジック実装を禁止するため、finalにする。
     * @param req
     * @param resp
     * @throws ServletException
     * @throws IOException 
     */
    @Override
    protected final void doGet(HttpServletRequest req, HttpServletResponse resp)
    throws ServletException, IOException {
        process(req, resp);
    }

}
