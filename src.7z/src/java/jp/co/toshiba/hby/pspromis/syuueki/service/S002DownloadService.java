package jp.co.toshiba.hby.pspromis.syuueki.service;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.inject.Inject;
import javax.interceptor.Interceptors;
import jp.co.toshiba.hby.pspromis.syuueki.bean.S002Bean;
import jp.co.toshiba.hby.pspromis.syuueki.entity.OperationLog;
import jp.co.toshiba.hby.pspromis.syuueki.entity.SyuGeBukkenInfoTbl;
import jp.co.toshiba.hby.pspromis.syuueki.enums.Label;
import jp.co.toshiba.hby.pspromis.syuueki.facade.SysdateEntityFacade;
import jp.co.toshiba.hby.pspromis.syuueki.interceptor.TranceInterceptor;
import jp.co.toshiba.hby.pspromis.syuueki.pages.DetailHeader;
import jp.co.toshiba.hby.pspromis.syuueki.util.ConstantString;
import jp.co.toshiba.hby.pspromis.syuueki.util.LoginUserInfo;
import jp.co.toshiba.hby.pspromis.syuueki.util.PoiUtil;
import jp.co.toshiba.hby.pspromis.syuueki.util.SyuuekiUtils;
import jp.co.toshiba.hby.pspromis.syuueki.util.Utils;
import jp.co.toshiba.hby.pspromis.syuueki.util.NumberUtils;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.util.Iterator;
import java.util.Map.Entry;
import jp.co.toshiba.hby.pspromis.common.util.StringUtil;
import jp.co.toshiba.hby.pspromis.syuueki.entity.IspDivisionList;

/**
 * PS-Promis収益管理システム 最終見込損益 Service
 *
 * @author (NPC)Y.Kitajima
 */
@Stateless
@Interceptors({TranceInterceptor.class})
public class S002DownloadService {

    public static final Logger log = LoggerFactory.getLogger(S002DownloadService.class);
    
    private final String SAVE_ONLINE = "SAVE_ONLINE";
    private final String DL_TPL = "DL_TPL";
    private final String UP_TPL = "UP_TPL";
    private final String ADD_CHOUSEI = "ADD_CHOUSEI";
    private final String COPY_SABUN = "COPY_SABUN";
    private final String DL_PDF = "DL_PDF";

    private final String SAVE_ONLINE_ID = "20";
    private final String DL_TPL_ID = "10";
    private final String UP_TPL_ID = "15";
    private final String ADD_CHOUSEI_ID = "20";
    private final String COPY_SABUN_ID = "20";
    private final String DL_PDF_ID = "10";

    // 左部項目タイトル開始行
    private final int DATA_START_ROW = 4;
    // 左部項目名表示列
    private final int TITLE_START_COL = 2;
    
    // 右部開始列
    //private final int DATA_START_COL = 3;
    private final int DATA_START_COL = 4;

    /**
     * 各項目開始位置
     */
    private Map<String, Object> headStartMap;

    private final int CHILD_STYLE_START_ROW = 23;
    //private final int PARENTS_ANKEN_STYLE_START_COL = 3;
    private final int PARENTS_ANKEN_STYLE_START_COL = 4;

    @Inject
    private LoginUserInfo loginUserInfo;

    @Inject
    private OperationLogService operationLogService;

    @Inject
    private SysdateEntityFacade sysdateFacade;

    @Inject
    private S002Bean s002Bean;

    @Inject
    private DetailHeader detailHeader;
    @Inject
    private S002Service s002Service;

    /**
     * Injection SyuuekiUtils
     */
    @Inject
    private SyuuekiUtils sUtils;

    /**
     * 事業部コード
     */
    private String divisionCode;

    /**
     * ロガー
     */
    public static final Logger logger = LoggerFactory.getLogger(S002DownloadService.class);

    /**
     * インスタンス変数を全て初期化
     */
    private void initInstanceValue() {
        this.headStartMap = null;
    }

    /**
     * 画面表示　ビジネスロジック
     *
     * @throws Exception
     */
    @TransactionAttribute(TransactionAttributeType.NOT_SUPPORTED)
    public void indexExecute() throws Exception {
        logger.info("S002DownloadService#indexExecute");
        logger.info("jpyUnit=" + s002Bean.getJpyUnit());
    }

    /**
     * 操作ログの登録
     *
     * @param operationCode
     * @throws Exception
     */
    public void registOperationLog(String operationCode) throws Exception {
        OperationLog operationLog = this.operationLogService.getOperationLog();

        operationLog.setOperationCode(operationCode);
        operationLog.setObjectId((new Integer(this.getObjectId(operationCode))));
        operationLog.setObjectType("KIKAN_S");
        operationLog.setRemarks(s002Bean.getAnkenId());

        operationLogService.insertOperationLogSearch(operationLog);
    }

    /**
     * 操作対象IDの取得
     *
     * @param operationCode
     * @return
     */
    private String getObjectId(String operationCode) {
        if (this.ADD_CHOUSEI.equals(operationCode)) {
            return this.ADD_CHOUSEI_ID;
        } else if (this.COPY_SABUN.equals(operationCode)) {
            return this.COPY_SABUN_ID;
        } else if (this.DL_PDF.equals(operationCode)) {
            return this.DL_PDF_ID;
        } else if (this.DL_TPL.equals(operationCode)) {
            return this.DL_TPL_ID;
        } else if (this.SAVE_ONLINE.equals(operationCode)) {
            return this.SAVE_ONLINE_ID;
        } else if (this.UP_TPL.equals(operationCode)) {
            return this.UP_TPL_ID;
        }
        return null;
    }

    /**
     * Excelダウンロードのデータ埋め込み(一括ダウンロードより実行)
     *
     * @param workbook
     * @param param
     * @throws Exception
     */
    public void outputDownloadExcel(Workbook workbook, S002Bean param) throws Exception {
        s002Bean = param;
        outputDownloadExcel(workbook);
    }

    /**
     * Excelダウンロードのデータ埋め込み
     *
     * @param workbook
     * @throws Exception
     */
    public void outputDownloadExcel(Workbook workbook) throws Exception {

        // インスタンス変数を全て初期化
        initInstanceValue();

        // データの取得
        s002Service.indexExecute();

        // シート取得
        Sheet sheet;
        final String ankenNotExsit = "saisyu_ankenNotExsit";
        final String potentialNotExsit = "saisyu_potentialNotExsit";
        final String childTemplateExsit = "saisyu_childTemplateExsit";
        int selectSeet = 0;

        // ポテンシャル管理の要否でテンプレートを分ける
        if (s002Bean.getPotentialFlg().equals("1")) {
            selectSeet = workbook.getSheetIndex(ankenNotExsit);
            sheet = workbook.getSheetAt(selectSeet);
            workbook.removeSheetAt(workbook.getSheetIndex(potentialNotExsit));
        } else {
            selectSeet = workbook.getSheetIndex(potentialNotExsit);
            sheet = workbook.getSheetAt(selectSeet);
            workbook.removeSheetAt(workbook.getSheetIndex(ankenNotExsit));
        }

        // 回収ありの場合
        int childRow = CHILD_STYLE_START_ROW;
        int templateSeet = workbook.getSheetIndex(childTemplateExsit);
        Sheet templatesheet = workbook.getSheetAt(templateSeet);
        childRow = setKaisyuList(sheet, childRow, templatesheet);

        // まとめ案件がある場合は先に出力
        if (s002Bean.getSalesClass().equals("1")) {
            // 進行基準案件のまとめ案件
            if (s002Bean.getAnkenFlg().equals("1")) {
                setChildAnken(sheet, childRow, templatesheet);
            }

            // 進行基準案件の子案件
            if (s002Bean.getAnkenFlg().equals("0")) {
                setParentsAnken(sheet, childRow, templatesheet);
            }
        } else if (s002Bean.getSalesClass().equals("0")) {
            // 他事業部ISP案件の自事業部案件
            if ((s002Bean.getAnkenFlg().equals("0")) && (s002Bean.getIspKbn().equals("1"))) {
                setIspDivision(sheet, childRow, templatesheet);
            }
        }
        workbook.removeSheetAt(workbook.getSheetIndex(childTemplateExsit));

        // ヘッダ情報をセット
        setHeadData(sheet);

        // 左部項目のデータ
        setLeftData(sheet);

        // 右部合計のデータ
        setRightData(sheet);

        // シート名の設定
        String sheetName = StringUtils.defaultString(s002Bean.getOrderNo()) + "_" + Label.getValue(Label.excelSheetLast);
        workbook.setSheetName(workbook.getSheetIndex(sheet), sheetName);

        // 操作ログへの書き込み
        // (案件一覧の一括出力処理から出力した場合はここでのログ書き込みは行わない)
        if (!s002Bean.isIsIkkatsuFlg()) {
            registOperationLog(DL_TPL);
        }
    }

    /**
     * 回収
     *
     * @param sheet
     * @param wkRow
     * @param templatesheet
     * @param kaisyuList
     * @return
     */
    private int setKaisyuList(Sheet sheet, int wkRow, Sheet templatesheet) {
        ArrayList<HashMap<String, String>> kaisyuList = s002Bean.getKaisyuList();
        if (CollectionUtils.isNotEmpty(kaisyuList)) {
            // テンプレートからタイトルをコピー
            wkRow++;// 空行
            PoiUtil.copyRowStyleValue(PoiUtil.getRow(sheet, wkRow, true), PoiUtil.getRow(templatesheet, 0), true, false);
            PoiUtil.addMergedRegion(sheet, wkRow, 0, wkRow, (TITLE_START_COL + 1));
            wkRow++;

            for (HashMap<String, String> kaisyu : kaisyuList) {
                PoiUtil.copyRowStyleValue(PoiUtil.getRow(sheet, wkRow, true), PoiUtil.getRow(templatesheet, 1), false);
                for (Iterator ite = kaisyu.entrySet().iterator(); ite.hasNext();) {
                    Entry<String, String> entry = (Map.Entry) ite.next();
                    switch (entry.getKey()) {
                        case "currencyCode":
                            PoiUtil.setCellValue(PoiUtil.getCell(sheet, wkRow, 0), entry.getValue());
                            break;
                        case "ruikeiKaisyuAmount":
                            setCellBigDecimal(PoiUtil.getCell(sheet, wkRow, (TITLE_START_COL + 2)), entry.getValue());
                            break;
                        case "kaisyuAmount":
                            setCellBigDecimal(PoiUtil.getCell(sheet, wkRow, (TITLE_START_COL + 3)), entry.getValue());
                            break;
                        case "miKaisyuAmount":
                            setCellBigDecimal(PoiUtil.getCell(sheet, wkRow, (TITLE_START_COL + 4)), entry.getValue());
                            break;
                        case "kaisyuRate":
                            setCellBigDecimal(PoiUtil.getCell(sheet, wkRow, (TITLE_START_COL + 5)), entry.getValue());
                            break;
                    }
                }

                PoiUtil.addMergedRegion(sheet, wkRow, 0, wkRow, (TITLE_START_COL + 1));// 通貨コード
                wkRow++;
            }
        }

        return wkRow;
    }

    /**
     * 案件データの埋め込み<br>
     * 進行基準案件のまとめ案件の場合、子案件一覧を表示
     *
     * @param sheet
     * @throws Exception
     */
    private void setChildAnken(Sheet sheet, int wkRow, Sheet templatesheet) throws Exception {
        ArrayList<HashMap<String, String>> childAnkenList = s002Bean.getChildAnkenList();
        if (CollectionUtils.isNotEmpty(childAnkenList)) {
            // テンプレートからタイトルをコピー
            wkRow++;// 空行
            PoiUtil.copyRowStyleValue(PoiUtil.getRow(sheet, wkRow, true), PoiUtil.getRow(templatesheet, 3), true, false);
            String labelIndex = (wkRow == CHILD_STYLE_START_ROW ? "２" : "３");
            PoiUtil.replaceCellValue(sheet, wkRow, 0, "#LABEL_INDEX#", labelIndex);

            PoiUtil.addMergedRegion(sheet, wkRow, 0, wkRow, (TITLE_START_COL + 1));
            wkRow++;

            PoiUtil.copyRowStyleValue(PoiUtil.getRow(sheet, wkRow, true), PoiUtil.getRow(templatesheet, 4), true, false);
            PoiUtil.copyRowStyleValue(PoiUtil.getRow(sheet, wkRow + 1, true), PoiUtil.getRow(templatesheet, 5), true, false);

            PoiUtil.addMergedRegion(sheet, wkRow, 0, wkRow + 1, TITLE_START_COL); // 案件番号

            int orderNoStartCol = TITLE_START_COL + 1;
            PoiUtil.addMergedRegion(sheet, wkRow, orderNoStartCol, (wkRow + 1), orderNoStartCol); // 注番

            int ankenNameStartCol = TITLE_START_COL + 2;
            PoiUtil.addMergedRegion(sheet, wkRow, ankenNameStartCol, (wkRow + 1), (ankenNameStartCol + 4)); // 案件名称

            int uriageGenkaStartCol = TITLE_START_COL + 8;
            PoiUtil.addMergedRegion(sheet, wkRow, uriageGenkaStartCol, wkRow, (uriageGenkaStartCol + 1)); // 売上原価(NET)

            wkRow += 2;

            for (HashMap<String, String> childLst : childAnkenList) {
                PoiUtil.copyRowStyleValue(PoiUtil.getRow(sheet, wkRow, true), PoiUtil.getRow(templatesheet, 6), false);
                for (Iterator ite = childLst.entrySet().iterator(); ite.hasNext();) {
                    Entry<String, String> e = (Map.Entry) ite.next();
                    switch (e.getKey()) {
                        case "ankenId":
                            PoiUtil.setCellValue(PoiUtil.getCell(sheet, wkRow, 0), e.getValue());
                            break;
                        case "orderNo":
                            if (e.getValue() != null) {
                                if (e.getValue().matches("\\d+")) {
                                    setCellBigDecimal(PoiUtil.getCell(sheet, wkRow, orderNoStartCol), e.getValue());
                                } else {
                                    PoiUtil.setCellValue(PoiUtil.getCell(sheet, wkRow, orderNoStartCol), e.getValue());
                                }
                            }
                            break;
                        case "ankenName":
                            PoiUtil.setCellValue(PoiUtil.getCell(sheet, wkRow, ankenNameStartCol), e.getValue());
                            break;
                        case "keiyakuAmountFm":
                            setCellBigDecimal(PoiUtil.getCell(sheet, wkRow, (TITLE_START_COL + 7)), e.getValue());
                            break;
                        case "uriageNetHb":
                            setCellBigDecimal(PoiUtil.getCell(sheet, wkRow, (TITLE_START_COL + 8)), e.getValue());
                            break;
                        case "uriageNetFm":
                            setCellBigDecimal(PoiUtil.getCell(sheet, wkRow, (TITLE_START_COL + 9)), e.getValue());
                            break;
                        case "arari":
                            setCellBigDecimal(PoiUtil.getCell(sheet, wkRow, (TITLE_START_COL + 10)), e.getValue());
                            break;
                        case "mrate":
                            setCellBigDecimal(PoiUtil.getCell(sheet, wkRow, (TITLE_START_COL + 11)), e.getValue());
                            break;
                    }
                }
                PoiUtil.addMergedRegion(sheet, wkRow, 0, wkRow, TITLE_START_COL); // 案件番号
                PoiUtil.addMergedRegion(sheet, wkRow, ankenNameStartCol, wkRow, (ankenNameStartCol + 4)); // 案件名称
                wkRow++;
            }
        }
    }

    /**
     * 案件データの埋め込み<br>
     * 進行基準案件の子案件の場合、親案件を表示
     *
     * @param sheet
     * @throws Exception
     */
    private void setParentsAnken(Sheet sheet, int wkRow, Sheet templatesheet) throws Exception {
        if (s002Bean.getParentAnken() != null && !s002Bean.getParentAnken().isEmpty()) {
            wkRow++; // 空行
            PoiUtil.copyRowStyleValue(PoiUtil.getRow(sheet, wkRow, true), PoiUtil.getRow(templatesheet, 3), true, false);
            String labelIndex = (wkRow == CHILD_STYLE_START_ROW ? "２" : "３");
            PoiUtil.replaceCellValue(sheet, wkRow, 0, "#LABEL_INDEX#", labelIndex);
            PoiUtil.addMergedRegion(sheet, wkRow, 0, wkRow, (TITLE_START_COL + 1));
            wkRow++;
            // テンプレートの開始位置
            int startTemplate = (s002Bean.getParentPotentialFlg().equals("1") ? 7 : 20);
            // テンプレートのみコピー
            for (int i = 0; i < 12; i++) {
                PoiUtil.copyRowStyleValue(PoiUtil.getRow(sheet, wkRow + i, true), PoiUtil.getRow(templatesheet, startTemplate + i), true, false);
            }
            
            int titleCol = TITLE_START_COL;
            PoiUtil.addMergedRegion(sheet, wkRow, 0, wkRow, titleCol); // まとめ案件
            PoiUtil.addMergedRegion(sheet, wkRow + 1, 0, wkRow + 1, titleCol); // 代表注番(O/#)
            PoiUtil.addMergedRegion(sheet, wkRow + 2, 0, wkRow + 2, titleCol); // 契約金額(SP) 
            PoiUtil.addMergedRegion(sheet, wkRow + 3, 0, wkRow + 3, titleCol); // 売上原価(NET) 
            PoiUtil.addMergedRegion(sheet, wkRow + 4, 0, wkRow + 4, titleCol); // 粗利
            PoiUtil.addMergedRegion(sheet, wkRow + 5, 0, wkRow + 5, titleCol); // M率
            PoiUtil.addMergedRegion(sheet, wkRow + 6, 0, wkRow + 6, titleCol); // 経費
            PoiUtil.addMergedRegion(sheet, wkRow + 7, 0, wkRow + 7, titleCol); // 総原価（NET＋経費）
            PoiUtil.addMergedRegion(sheet, wkRow + 8, 0, wkRow + 8, titleCol); // 営業外損益
            PoiUtil.addMergedRegion(sheet, wkRow + 9, 0, wkRow + 9, titleCol); // 経常損益
            PoiUtil.addMergedRegion(sheet, wkRow + 10, 0, wkRow + 10, titleCol); // 経常損益率

            // まとめ案件
            PoiUtil.setCellValue(PoiUtil.getCell(sheet, wkRow, (TITLE_START_COL + 1)), s002Bean.getAnkenMatomeNo());
            wkRow++;

            // 代表注番(O/#)
            if (StringUtils.defaultString(s002Bean.getAnkenMatomeOrderNo()).matches("\\d+")) {
                setCellBigDecimal(PoiUtil.getCell(sheet, wkRow, (TITLE_START_COL + 1)), s002Bean.getAnkenMatomeOrderNo());
            } else {
                PoiUtil.setCellValue(PoiUtil.getCell(sheet, wkRow, (TITLE_START_COL + 1)), s002Bean.getAnkenMatomeOrderNo());
            }
            wkRow++;

            // 契約金額(SP) _合計
            int wkCol = PARENTS_ANKEN_STYLE_START_COL;
            setCellBigDecimal(PoiUtil.getCell(sheet, wkRow, wkCol++), s002Bean.getParentAnken().get("keiyakuAmountSm"));
            setCellBigDecimal(PoiUtil.getCell(sheet, wkRow, wkCol++), s002Bean.getParentAnken().get("keiyakuAmountJs"));
            setCellBigDecimal(PoiUtil.getCell(sheet, wkRow, wkCol++), s002Bean.getParentAnken().get("keiyakuAmountJt"));
            setCellBigDecimal(PoiUtil.getCell(sheet, wkRow, wkCol++), s002Bean.getParentAnken().get("keiyakuAmountMh"));
            //setCellBigDecimal(PoiUtil.getCell(sheet, wkRow, wkCol++), s002Bean.getParentAnken().get("keiyakuAmountSm"));
            setCellBigDecimal(PoiUtil.getCell(sheet, wkRow, wkCol++), s002Bean.getParentAnken().get("keiyakuAmountSt"));
            setCellBigDecimal(PoiUtil.getCell(sheet, wkRow, wkCol++), s002Bean.getParentAnken().get("keiyakuAmountHb"));
            setCellBigDecimal(PoiUtil.getCell(sheet, wkRow, wkCol++), s002Bean.getParentAnken().get("keiyakuAmountTr"));
            setCellBigDecimal(PoiUtil.getCell(sheet, wkRow, wkCol++), s002Bean.getParentAnken().get("keiyakuAmountFm"));
//            if (s002Bean.getParentPotentialFlg().equals("1")) {
//                setCellBigDecimal(PoiUtil.getCell(sheet, wkRow, wkCol++), s002Bean.getParentAnken().get("keiyakuAmountPd"));
//                setCellBigDecimal(PoiUtil.getCell(sheet, wkRow, wkCol++), s002Bean.getParentAnken().get("keiyakuAmountPt"));
//                setCellBigDecimal(PoiUtil.getCell(sheet, wkRow, wkCol++), s002Bean.getParentAnken().get("keiyakuAmountPs"));
//            }
            wkRow++;

            // 売上原価(NET) _合計
            wkCol = PARENTS_ANKEN_STYLE_START_COL;
            setCellBigDecimal(PoiUtil.getCell(sheet, wkRow, wkCol++), s002Bean.getParentAnken().get("uriageNetSm"));
            setCellBigDecimal(PoiUtil.getCell(sheet, wkRow, wkCol++), s002Bean.getParentAnken().get("uriageNetJs"));
            setCellBigDecimal(PoiUtil.getCell(sheet, wkRow, wkCol++), s002Bean.getParentAnken().get("uriageNetJt"));
            setCellBigDecimal(PoiUtil.getCell(sheet, wkRow, wkCol++), s002Bean.getParentAnken().get("uriageNetMh"));
            //setCellBigDecimal(PoiUtil.getCell(sheet, wkRow, wkCol++), s002Bean.getParentAnken().get("uriageNetSm"));
            setCellBigDecimal(PoiUtil.getCell(sheet, wkRow, wkCol++), s002Bean.getParentAnken().get("uriageNetSt"));
            setCellBigDecimal(PoiUtil.getCell(sheet, wkRow, wkCol++), s002Bean.getParentAnken().get("uriageNetHb"));
            setCellBigDecimal(PoiUtil.getCell(sheet, wkRow, wkCol++), s002Bean.getParentAnken().get("uriageNetTr"));
            setCellBigDecimal(PoiUtil.getCell(sheet, wkRow, wkCol++), s002Bean.getParentAnken().get("uriageNetFm"));
//            if (s002Bean.getParentPotentialFlg().equals("1")) {
//                setCellBigDecimal(PoiUtil.getCell(sheet, wkRow, wkCol++), s002Bean.getParentAnken().get("uriageNetPd"));
//                setCellBigDecimal(PoiUtil.getCell(sheet, wkRow, wkCol++), s002Bean.getParentAnken().get("uriageNetPt"));
//                setCellBigDecimal(PoiUtil.getCell(sheet, wkRow, wkCol++), s002Bean.getParentAnken().get("uriageNetPs"));
//            }
            wkRow++;

            // 粗利
            wkCol = PARENTS_ANKEN_STYLE_START_COL;
            setCellBigDecimal(PoiUtil.getCell(sheet, wkRow, wkCol++), s002Bean.getParentAnken().get("arariSm"));
            setCellBigDecimal(PoiUtil.getCell(sheet, wkRow, wkCol++), s002Bean.getParentAnken().get("arariJs"));
            setCellBigDecimal(PoiUtil.getCell(sheet, wkRow, wkCol++), s002Bean.getParentAnken().get("arariJt"));
            setCellBigDecimal(PoiUtil.getCell(sheet, wkRow, wkCol++), s002Bean.getParentAnken().get("arariMh"));
            //setCellBigDecimal(PoiUtil.getCell(sheet, wkRow, wkCol++), s002Bean.getParentAnken().get("arariSm"));
            setCellBigDecimal(PoiUtil.getCell(sheet, wkRow, wkCol++), s002Bean.getParentAnken().get("arariSt"));
            setCellBigDecimal(PoiUtil.getCell(sheet, wkRow, wkCol++), s002Bean.getParentAnken().get("arariHb"));
            wkCol++; // 空セル
            setCellBigDecimal(PoiUtil.getCell(sheet, wkRow, wkCol++), s002Bean.getParentAnken().get("arariFm"));
//            if (s002Bean.getParentPotentialFlg().equals("1")) {
//                setCellBigDecimal(PoiUtil.getCell(sheet, wkRow, wkCol++), s002Bean.getParentAnken().get("arariPd"));
//                setCellBigDecimal(PoiUtil.getCell(sheet, wkRow, wkCol++), s002Bean.getParentAnken().get("arariPt"));
//                setCellBigDecimal(PoiUtil.getCell(sheet, wkRow, wkCol++), s002Bean.getParentAnken().get("arariPs"));
//            }
            wkRow++;

            // M率
            wkCol = PARENTS_ANKEN_STYLE_START_COL;
            setCellConvMrate(PoiUtil.getCell(sheet, wkRow, wkCol++), s002Bean.getParentAnken().get("mrateSm"));
            setCellConvMrate(PoiUtil.getCell(sheet, wkRow, wkCol++), s002Bean.getParentAnken().get("mrateJs"));
            setCellConvMrate(PoiUtil.getCell(sheet, wkRow, wkCol++), s002Bean.getParentAnken().get("mrateJt"));
            setCellConvMrate(PoiUtil.getCell(sheet, wkRow, wkCol++), s002Bean.getParentAnken().get("mrateMh"));
            //setCellConvMrate(PoiUtil.getCell(sheet, wkRow, wkCol++), s002Bean.getParentAnken().get("mrateSm"));
            setCellConvMrate(PoiUtil.getCell(sheet, wkRow, wkCol++), s002Bean.getParentAnken().get("mrateSt"));
            setCellConvMrate(PoiUtil.getCell(sheet, wkRow, wkCol++), s002Bean.getParentAnken().get("mrateHb"));
            setCellConvMrate(PoiUtil.getCell(sheet, wkRow, wkCol++), s002Bean.getParentAnken().get("mrateTr"));
            setCellConvMrate(PoiUtil.getCell(sheet, wkRow, wkCol++), s002Bean.getParentAnken().get("mrateFm"));
//            if (s002Bean.getParentPotentialFlg().equals("1")) {
//                setCellConvMrate(PoiUtil.getCell(sheet, wkRow, wkCol++), s002Bean.getParentAnken().get("mratePd"));
//                setCellConvMrate(PoiUtil.getCell(sheet, wkRow, wkCol++), s002Bean.getParentAnken().get("mratePt"));
//                setCellConvMrate(PoiUtil.getCell(sheet, wkRow, wkCol++), s002Bean.getParentAnken().get("mratePs"));
//            }
            wkRow++;

            // 経費
            wkCol = PARENTS_ANKEN_STYLE_START_COL;
            setCellBigDecimal(PoiUtil.getCell(sheet, wkRow, wkCol++), s002Bean.getParentAnken().get("keihiNetSm"));
            setCellBigDecimal(PoiUtil.getCell(sheet, wkRow, wkCol++), s002Bean.getParentAnken().get("keihiNetJs"));
            setCellBigDecimal(PoiUtil.getCell(sheet, wkRow, wkCol++), s002Bean.getParentAnken().get("keihiNetJt"));
            setCellBigDecimal(PoiUtil.getCell(sheet, wkRow, wkCol++), s002Bean.getParentAnken().get("keihiNetMh"));
            //setCellBigDecimal(PoiUtil.getCell(sheet, wkRow, wkCol++), s002Bean.getParentAnken().get("keihiNetSm"));
            setCellBigDecimal(PoiUtil.getCell(sheet, wkRow, wkCol++), s002Bean.getParentAnken().get("keihiNetSt"));
            setCellBigDecimal(PoiUtil.getCell(sheet, wkRow, wkCol++), s002Bean.getParentAnken().get("keihiNetHb"));
            setCellBigDecimal(PoiUtil.getCell(sheet, wkRow, wkCol++), s002Bean.getParentAnken().get("keihiNetTr"));
            setCellBigDecimal(PoiUtil.getCell(sheet, wkRow, wkCol++), s002Bean.getParentAnken().get("keihiNetFm"));
//            if (s002Bean.getParentPotentialFlg().equals("1")) {
//                setCellBigDecimal(PoiUtil.getCell(sheet, wkRow, wkCol++), s002Bean.getParentAnken().get("keihiNetPd"));
//                setCellBigDecimal(PoiUtil.getCell(sheet, wkRow, wkCol++), s002Bean.getParentAnken().get("keihiNetPt"));
//                setCellBigDecimal(PoiUtil.getCell(sheet, wkRow, wkCol++), s002Bean.getParentAnken().get("keihiNetPs"));
//            }
            wkRow++;

            // 総原価(NET+経費)
            wkCol = PARENTS_ANKEN_STYLE_START_COL;
            setCellBigDecimal(PoiUtil.getCell(sheet, wkRow, wkCol++), s002Bean.getParentAnken().get("sougenkaNetSm"));
            setCellBigDecimal(PoiUtil.getCell(sheet, wkRow, wkCol++), s002Bean.getParentAnken().get("sougenkaNetJs"));
            setCellBigDecimal(PoiUtil.getCell(sheet, wkRow, wkCol++), s002Bean.getParentAnken().get("sougenkaNetJt"));
            setCellBigDecimal(PoiUtil.getCell(sheet, wkRow, wkCol++), s002Bean.getParentAnken().get("sougenkaNetMh"));
            //setCellBigDecimal(PoiUtil.getCell(sheet, wkRow, wkCol++), s002Bean.getParentAnken().get("sougenkaNetSm"));
            setCellBigDecimal(PoiUtil.getCell(sheet, wkRow, wkCol++), s002Bean.getParentAnken().get("sougenkaNetSt"));
            setCellBigDecimal(PoiUtil.getCell(sheet, wkRow, wkCol++), s002Bean.getParentAnken().get("sougenkaNetHb"));
            setCellBigDecimal(PoiUtil.getCell(sheet, wkRow, wkCol++), s002Bean.getParentAnken().get("sougenkaNetTr"));
            setCellBigDecimal(PoiUtil.getCell(sheet, wkRow, wkCol++), s002Bean.getParentAnken().get("sougenkaNetFm"));
//            if (s002Bean.getParentPotentialFlg().equals("1")) {
//                setCellBigDecimal(PoiUtil.getCell(sheet, wkRow, wkCol++), s002Bean.getParentAnken().get("sougenkaNetPd"));
//                setCellBigDecimal(PoiUtil.getCell(sheet, wkRow, wkCol++), s002Bean.getParentAnken().get("sougenkaNetPt"));
//                setCellBigDecimal(PoiUtil.getCell(sheet, wkRow, wkCol++), s002Bean.getParentAnken().get("sougenkaNetPs"));
//            }
            wkRow++;

            // 営業外損益
            wkCol = PARENTS_ANKEN_STYLE_START_COL;
            setCellBigDecimal(PoiUtil.getCell(sheet, wkRow, wkCol++), s002Bean.getParentAnken().get("eigyogaiSm"));
            setCellBigDecimal(PoiUtil.getCell(sheet, wkRow, wkCol++), s002Bean.getParentAnken().get("eigyogaiJs"));
            setCellBigDecimal(PoiUtil.getCell(sheet, wkRow, wkCol++), s002Bean.getParentAnken().get("eigyogaiJt"));
            setCellBigDecimal(PoiUtil.getCell(sheet, wkRow, wkCol++), s002Bean.getParentAnken().get("eigyogaiMh"));
            //setCellBigDecimal(PoiUtil.getCell(sheet, wkRow, wkCol++), s002Bean.getParentAnken().get("eigyogaiSm"));
            setCellBigDecimal(PoiUtil.getCell(sheet, wkRow, wkCol++), s002Bean.getParentAnken().get("eigyogaiSt"));
            setCellBigDecimal(PoiUtil.getCell(sheet, wkRow, wkCol++), s002Bean.getParentAnken().get("eigyogaiHb"));
            setCellBigDecimal(PoiUtil.getCell(sheet, wkRow, wkCol++), s002Bean.getParentAnken().get("eigyogaiTr"));
            setCellBigDecimal(PoiUtil.getCell(sheet, wkRow, wkCol++), s002Bean.getParentAnken().get("eigyogaiFm"));
//            if (s002Bean.getParentPotentialFlg().equals("1")) {
//                setCellBigDecimal(PoiUtil.getCell(sheet, wkRow, wkCol++), s002Bean.getParentAnken().get("eigyogaiPd"));
//                setCellBigDecimal(PoiUtil.getCell(sheet, wkRow, wkCol++), s002Bean.getParentAnken().get("eigyogaiPt"));
//                setCellBigDecimal(PoiUtil.getCell(sheet, wkRow, wkCol++), s002Bean.getParentAnken().get("eigyogaiPs"));
//            }
            wkRow++;

            // 経常損益_合計
            wkCol = PARENTS_ANKEN_STYLE_START_COL;
            setCellBigDecimal(PoiUtil.getCell(sheet, wkRow, wkCol++), s002Bean.getParentAnken().get("seibanSonekiNetSm"));
            setCellBigDecimal(PoiUtil.getCell(sheet, wkRow, wkCol++), s002Bean.getParentAnken().get("seibanSonekiNetJs"));
            setCellBigDecimal(PoiUtil.getCell(sheet, wkRow, wkCol++), s002Bean.getParentAnken().get("seibanSonekiNetJt"));
            setCellBigDecimal(PoiUtil.getCell(sheet, wkRow, wkCol++), s002Bean.getParentAnken().get("seibanSonekiNetMh"));
            //setCellBigDecimal(PoiUtil.getCell(sheet, wkRow, wkCol++), s002Bean.getParentAnken().get("seibanSonekiNetSm"));
            setCellBigDecimal(PoiUtil.getCell(sheet, wkRow, wkCol++), s002Bean.getParentAnken().get("seibanSonekiNetSt"));
            setCellBigDecimal(PoiUtil.getCell(sheet, wkRow, wkCol++), s002Bean.getParentAnken().get("seibanSonekiNetHb"));
            setCellBigDecimal(PoiUtil.getCell(sheet, wkRow, wkCol++), s002Bean.getParentAnken().get("seibanSonekiNetTr"));
            setCellBigDecimal(PoiUtil.getCell(sheet, wkRow, wkCol++), s002Bean.getParentAnken().get("seibanSonekiNetFm"));
//            if (s002Bean.getParentPotentialFlg().equals("1")) {
//                setCellBigDecimal(PoiUtil.getCell(sheet, wkRow, wkCol++), s002Bean.getParentAnken().get("seibanSonekiNetPd"));
//                setCellBigDecimal(PoiUtil.getCell(sheet, wkRow, wkCol++), s002Bean.getParentAnken().get("seibanSonekiNetPt"));
//                setCellBigDecimal(PoiUtil.getCell(sheet, wkRow, wkCol++), s002Bean.getParentAnken().get("seibanSonekiNetPs"));
//            }
            wkRow++;

            // 経常損益率_ROS
            wkCol = PARENTS_ANKEN_STYLE_START_COL;
            setCellConvMrate(PoiUtil.getCell(sheet, wkRow, wkCol++), s002Bean.getParentAnken().get("rosSm"));
            setCellConvMrate(PoiUtil.getCell(sheet, wkRow, wkCol++), s002Bean.getParentAnken().get("rosJs"));
            setCellConvMrate(PoiUtil.getCell(sheet, wkRow, wkCol++), s002Bean.getParentAnken().get("rosJt"));
            setCellConvMrate(PoiUtil.getCell(sheet, wkRow, wkCol++), s002Bean.getParentAnken().get("rosMh"));
            //setCellConvMrate(PoiUtil.getCell(sheet, wkRow, wkCol++), s002Bean.getParentAnken().get("rosSm"));
            setCellConvMrate(PoiUtil.getCell(sheet, wkRow, wkCol++), s002Bean.getParentAnken().get("rosSt"));
            setCellConvMrate(PoiUtil.getCell(sheet, wkRow, wkCol++), s002Bean.getParentAnken().get("rosHb"));
            setCellConvMrate(PoiUtil.getCell(sheet, wkRow, wkCol++), s002Bean.getParentAnken().get("rosTr"));
            setCellConvMrate(PoiUtil.getCell(sheet, wkRow, wkCol++), s002Bean.getParentAnken().get("rosFm"));
//            if (s002Bean.getParentPotentialFlg().equals("1")) {
//                setCellConvMrate(PoiUtil.getCell(sheet, wkRow, wkCol++), s002Bean.getParentAnken().get("rosPd"));
//                setCellConvMrate(PoiUtil.getCell(sheet, wkRow, wkCol++), s002Bean.getParentAnken().get("rosPt"));
//                setCellConvMrate(PoiUtil.getCell(sheet, wkRow, wkCol++), s002Bean.getParentAnken().get("rosPs"));
//            }
        }
    }

    /**
     * 他事業部ISP案件の自事業部案件の場合、ISP一覧を表示
     *
     * @param sheet
     * @param wkRow
     * @param templatesheet
     * @throws Exception
     */
    private void setIspDivision(Sheet sheet, int wkRow, Sheet templatesheet) throws Exception {
        if (CollectionUtils.isNotEmpty(s002Bean.getIspDivisionList())) {
            // テンプレートからタイトルをコピー
            wkRow++;// 空行
            PoiUtil.copyRowStyleValue(PoiUtil.getRow(sheet, wkRow, true), PoiUtil.getRow(templatesheet, 32), true, false);
            String labelIndex = (wkRow == CHILD_STYLE_START_ROW ? "２" : "３");
            PoiUtil.replaceCellValue(sheet, wkRow, 0, "#LABEL_INDEX#", labelIndex);

            PoiUtil.addMergedRegion(sheet, wkRow, 0, wkRow, (TITLE_START_COL + 1));

            int saisyuMikomiTitleCol = TITLE_START_COL + 7;
            PoiUtil.addMergedRegion(sheet, wkRow, saisyuMikomiTitleCol, wkRow, (saisyuMikomiTitleCol + 3));// 最終見込

            int uriageJTitleCol = TITLE_START_COL + 11;
            PoiUtil.addMergedRegion(sheet, wkRow, uriageJTitleCol, wkRow, (uriageJTitleCol + 2));// 売上実績

            wkRow++;
            PoiUtil.copyRowStyleValue(PoiUtil.getRow(sheet, wkRow, true), PoiUtil.getRow(templatesheet, 33), true, false);

            PoiUtil.addMergedRegion(sheet, wkRow, 0, wkRow, TITLE_START_COL); // 案件番号

            int ankenNameCol = TITLE_START_COL + 3;
            PoiUtil.addMergedRegion(sheet, wkRow, ankenNameCol, wkRow, (ankenNameCol + 3)); // 案件名称

            wkRow++;

            for (IspDivisionList ispDivision : s002Bean.getIspDivisionList()) {
                PoiUtil.copyRowStyleValue(PoiUtil.getRow(sheet, wkRow, true), PoiUtil.getRow(templatesheet, 34), false);
                PoiUtil.setCellValue(PoiUtil.getCell(sheet, wkRow, 0), ispDivision.getAnkenId());         
                PoiUtil.setCellValue(PoiUtil.getCell(sheet, wkRow, (TITLE_START_COL + 1)), ispDivision.getOrderNo());
                PoiUtil.setCellValue(PoiUtil.getCell(sheet, wkRow, (TITLE_START_COL + 2)), ispDivision.getIspDivisionNm());
                PoiUtil.setCellValue(PoiUtil.getCell(sheet, wkRow, (TITLE_START_COL + 3)), ispDivision.getAnkenName());
                setCellBigDecimal(PoiUtil.getCell(sheet, wkRow, (TITLE_START_COL + 7)), ispDivision.getSaisyuSp());
                setCellBigDecimal(PoiUtil.getCell(sheet, wkRow, (TITLE_START_COL + 8)), ispDivision.getSaisyuNet());
                setCellBigDecimal(PoiUtil.getCell(sheet, wkRow, (TITLE_START_COL + 9)), ispDivision.getArari());
                setCellConvMrate(PoiUtil.getCell(sheet, wkRow, (TITLE_START_COL + 10)), ispDivision.getMrate());
                setCellBigDecimal(PoiUtil.getCell(sheet, wkRow, (TITLE_START_COL + 11)), ispDivision.getUriageSp());
                setCellBigDecimal(PoiUtil.getCell(sheet, wkRow, (TITLE_START_COL + 12)), ispDivision.getUriageNet());
                setCellBigDecimal(PoiUtil.getCell(sheet, wkRow, (TITLE_START_COL + 13)), ispDivision.getUriageTov());

                PoiUtil.addMergedRegion(sheet, wkRow, 0, wkRow, TITLE_START_COL); // 案件番号
                PoiUtil.addMergedRegion(sheet, wkRow, ankenNameCol, wkRow, (ankenNameCol + 3)); // 案件名称
                wkRow++;
            }

            // 合計行
            IspDivisionList ispTotal = s002Bean.getIspDivisionTotal();
            PoiUtil.copyRowStyleValue(PoiUtil.getRow(sheet, wkRow, true), PoiUtil.getRow(templatesheet, 35), true, false);
            setCellBigDecimal(PoiUtil.getCell(sheet, wkRow, (TITLE_START_COL + 7)), ispTotal.getSaisyuSp());
            setCellBigDecimal(PoiUtil.getCell(sheet, wkRow, (TITLE_START_COL + 8)), ispTotal.getSaisyuNet());
            setCellBigDecimal(PoiUtil.getCell(sheet, wkRow, (TITLE_START_COL + 9)), ispTotal.getArari());
            setCellConvMrate(PoiUtil.getCell(sheet, wkRow, (TITLE_START_COL + 10)), ispTotal.getMrate());
            setCellBigDecimal(PoiUtil.getCell(sheet, wkRow, (TITLE_START_COL + 11)), ispTotal.getUriageSp());
            setCellBigDecimal(PoiUtil.getCell(sheet, wkRow, (TITLE_START_COL + 12)), ispTotal.getUriageNet());
            
        }
    }

    /**
     * ヘッダ情報のデータ埋め込み
     *
     * @param sheet
     * @throws Exception
     */
    private void setHeadData(Sheet sheet) throws Exception {
        SyuGeBukkenInfoTbl ankenEntity = detailHeader.getAnkenEntity();

        // 出力日時取得
        Date now = sysdateFacade.getSysdate();

        ////// ヘッダ情報セット
        // タイトル(一般 or 進行)
        String salesClassName;
        if (ConstantString.salesClassS.equals(ankenEntity.getSalesClass())) {
            salesClassName = Label.shinkoLabelShort.getLabel();
        } else {
            salesClassName = Label.ippan.getLabel();
        }
        //PoiUtil.replaceCellValue(sheet, 0, 1, "#DATA#", salesClassName);
        PoiUtil.replaceCellValue(sheet, 0, 2, "#DATA#", salesClassName);

        //// ログイン者名
        //PoiUtil.setCellValue(sheet, 0, 3, loginUserInfo.getUserName());
        PoiUtil.setCellValue(sheet, 0, 4, loginUserInfo.getUserName());
        //// 現在日時
        //PoiUtil.setCellValue(sheet, 0, 5, now);
        PoiUtil.setCellValue(sheet, 0, 6, now);
        //// 案件番号
        //PoiUtil.setCellValue(sheet, 1, 2, s002Bean.getAnkenId());
        PoiUtil.setCellValue(sheet, 1, 3, s002Bean.getAnkenId());
        //// 強制フラグ
        //PoiUtil.setCellValue(sheet, 1, 5, "OFF");
        PoiUtil.setCellValue(sheet, 1, 6, "OFF");

        // 事業部を取得
        this.setDivisionCode(ankenEntity.getDivisionCode());

        //// 注番
        String orderNo;
        if ("1".equals(ankenEntity.getAnkenFlg())) {
            orderNo = ankenEntity.getMainOrderNo();
        } else {
            orderNo = ankenEntity.getOrderNo();
        }
        // シート名設定用にORDER_NOを保持
        s002Bean.setOrderNo(ankenEntity.getOrderNo());
        PoiUtil.replaceCellValue(sheet, 2, 2, "#ORDER_NO#", orderNo);
        //PoiUtil.replaceCellValue(sheet, 2, 1, "#ORDER_NO#", orderNo);

        //// 案件名称
        //PoiUtil.replaceCellValue(sheet, 2, 4, "#ANKEN_NAME#", ankenEntity.getAnkenName());
        PoiUtil.replaceCellValue(sheet, 2, 5, "#ANKEN_NAME#", ankenEntity.getAnkenName());

        // 勘定月
//        PoiUtil.setCellValue(sheet, 3, 2, new SimpleDateFormat("yyyy/MM").format(detailHeader.getKanjoDate()));
        // 単位
        StringBuilder unitLabel = new StringBuilder();
        unitLabel.append(Label.getValue(Label.jpyUnitLabel));
        unitLabel.append(Label.getValue(Label.unitLabel));
        unitLabel.append(": ");
        //int cols = (s002Bean.getPotentialFlg().equals("1") ? 16 : 13);
        int cols = (s002Bean.getPotentialFlg().equals("1") ? 17 : 14);
        switch (s002Bean.getJpyUnit()) {
            case 1:
                unitLabel.append(Label.getValue(Label.jpyUnit1));
                PoiUtil.setCellValue(sheet, 3, cols, unitLabel.toString());
                break;
            case 1000:
                unitLabel.append(Label.getValue(Label.jpyUnit2));
                PoiUtil.setCellValue(sheet, 3, cols, unitLabel.toString());
                break;
            case 1000000:
                unitLabel.append(Label.getValue(Label.jpyUnit3));
                PoiUtil.setCellValue(sheet, 3, cols, unitLabel.toString());
                break;
        }
        unitLabel.delete(0, unitLabel.length());

        // 最終見込_前回値
        String zenkaiKanjyoYm = "";
        if (StringUtil.isNotBlank(s002Bean.getZenkaiKanjyoYm())) {
            zenkaiKanjyoYm = Label.getValue(Label.bracketStart) + s002Bean.getZenkaiKanjyoYm() + Label.getValue(Label.bracketEnd);
        }
        //PoiUtil.replaceCellValue(sheet, 3, 10, "#ZENKAI_KANJYO_YM#", zenkaiKanjyoYm);
        PoiUtil.replaceCellValue(sheet, 3, 11, "#ZENKAI_KANJYO_YM#", zenkaiKanjyoYm);

        // 差分
        if (s002Bean.getCalcDiffFlg() != null
                && !s002Bean.getCalcDiffFlg().isEmpty()
                && s002Bean.getCalcDiffFlg().trim().matches("^[0-9]*$")) {
            String calcDiffLabel = calcDiff();
            unitLabel.append(Label.getValue(Label.diff));
            unitLabel.append("\n");
            unitLabel.append(calcDiffLabel);
            //PoiUtil.setCellValue(sheet, 3, 12, unitLabel.toString());
            PoiUtil.setCellValue(sheet, 3, 13, unitLabel.toString());
        }
    }

    /**
     * 左部項目のデータ埋め込み
     */
    private void setLeftData(Sheet sheet) throws Exception {
        int wkRow = DATA_START_ROW;

        // 初期化
        headStartMap = new HashMap<>();

        // 契約金額(SP) 合計
        headStartMap.put("keiyakuSp", wkRow++);
        if (s002Bean.getCurrencyRateMapList() == null || s002Bean.getCurrencyRateMapList().isEmpty()) {
            PoiUtil.delRow(sheet, wkRow, 2);
        } else {
            wkRow = setCurrencyCode(sheet, wkRow, s002Bean.getCurrencyRateMapList());
        }

        // 売上原価(NET) 合計
        headStartMap.put("keiyakuUriageNet", wkRow++);
        if (s002Bean.getCostList() == null || s002Bean.getCostList().isEmpty()) {
            PoiUtil.delRow(sheet, wkRow, 1);
        } else {
            wkRow = setCostList(sheet, wkRow, s002Bean.getCostList());
        }

        // 粗利
        headStartMap.put("arari", wkRow++);

        // M率
        headStartMap.put("mritsu", wkRow++);

        // 経費
        headStartMap.put("keihi", wkRow++);

        // 販売直接費合計
        headStartMap.put("hanbaiChokuGoukei", wkRow++);
        if (s002Bean.getCategoryHanchokuList() == null || s002Bean.getCategoryHanchokuList().isEmpty()) {
            PoiUtil.delRow(sheet, wkRow, 1);
        } else {
            wkRow = setCategoryName(sheet, wkRow, s002Bean.getCategoryHanchokuList());
        }

        // ISP
        headStartMap.put("isp", wkRow++);

        // 販売間接費
        headStartMap.put("hanbaikansetsu", wkRow++);

        // 総原価
        headStartMap.put("sogenka", wkRow++);

        // 営業外損益
        headStartMap.put("egyogison", wkRow++);

        // 為替予約
        headStartMap.put("kawaseYoyaku", wkRow++);

//        // 製番損益 合計
//        headStartMap.put("seibansonekiGokei", wkRow++);
//        if (s002Bean.getProductSonekiList() == null || s002Bean.getProductSonekiList().isEmpty()) {
//            PoiUtil.delRow(sheet, wkRow, 1);
//        } else {
//            wkRow = setProductSoneki(sheet, wkRow, s002Bean.getProductSonekiList());
//        }
        // 経常損益 合計
        headStartMap.put("keijoSoneki", wkRow++);

        // 経常損益率 ROS
        headStartMap.put("keijoSonekiRitsuRos", wkRow);
    }

    /**
     * 右部項目のデータ埋め込み
     */
    private void setRightData(Sheet sheet) throws Exception {
        int wkRow = convInteger(headStartMap.get("keiyakuSp"));
        int wkCol = DATA_START_COL;
        // 契約金額合計
        setCellBigDecimal(PoiUtil.getCell(sheet, wkRow, wkCol++), s002Bean.getTotalContractAmount().get("KeiyakuAmountSm"));
        setCellBigDecimal(PoiUtil.getCell(sheet, wkRow, wkCol++), s002Bean.getTotalContractAmount().get("KeiyakuAmountJs"));
        setCellBigDecimal(PoiUtil.getCell(sheet, wkRow, wkCol++), s002Bean.getTotalContractAmount().get("KeiyakuAmountJt"));
        setCellBigDecimal(PoiUtil.getCell(sheet, wkRow, wkCol++), s002Bean.getTotalContractAmount().get("KeiyakuAmountMh"));
        setCellBigDecimal(PoiUtil.getCell(sheet, wkRow, wkCol++), s002Bean.getTotalContractAmount().get("KeiyakuAmountSt"));
        setCellBigDecimal(PoiUtil.getCell(sheet, wkRow, wkCol++), s002Bean.getTotalContractAmount().get("KeiyakuAmountHb"));
        setCellBigDecimal(PoiUtil.getCell(sheet, wkRow, wkCol++), s002Bean.getTotalContractAmount().get("KeiyakuAmountTr"));
        setCellBigDecimal(PoiUtil.getCell(sheet, wkRow, wkCol++), s002Bean.getTotalContractAmount().get("KeiyakuAmountPrev"));
        setCellBigDecimal(PoiUtil.getCell(sheet, wkRow, wkCol++), s002Bean.getTotalContractAmount().get("KeiyakuAmountFm"));
        setCellBigDecimal(PoiUtil.getCell(sheet, wkRow, wkCol++), s002Bean.getTotalContractAmount().get("KeiyakuAmountDiff"));
        if (s002Bean.getPotentialFlg().equals("1")) {
            setCellBigDecimal(PoiUtil.getCell(sheet, wkRow, wkCol++), s002Bean.getTotalContractAmount().get("KeiyakuAmountPd"));
            setCellBigDecimal(PoiUtil.getCell(sheet, wkRow, wkCol++), s002Bean.getTotalContractAmount().get("KeiyakuAmountPt"));
            setCellBigDecimal(PoiUtil.getCell(sheet, wkRow, wkCol++), s002Bean.getTotalContractAmount().get("KeiyakuAmountPs"));
        }

        wkRow = convInteger(headStartMap.get("keiyakuUriageNet"));
        wkCol = DATA_START_COL;
        setCellBigDecimal(PoiUtil.getCell(sheet, wkRow, wkCol++), s002Bean.getTotalCost().get("UriageNetSm"));
        setCellBigDecimal(PoiUtil.getCell(sheet, wkRow, wkCol++), s002Bean.getTotalCost().get("UriageNetJs"));
        setCellBigDecimal(PoiUtil.getCell(sheet, wkRow, wkCol++), s002Bean.getTotalCost().get("UriageNetJt"));
        setCellBigDecimal(PoiUtil.getCell(sheet, wkRow, wkCol++), s002Bean.getTotalCost().get("UriageNetMh"));
        setCellBigDecimal(PoiUtil.getCell(sheet, wkRow, wkCol++), s002Bean.getTotalCost().get("UriageNetSt"));
        setCellBigDecimal(PoiUtil.getCell(sheet, wkRow, wkCol++), s002Bean.getTotalCost().get("UriageNetHb"));
        setCellBigDecimal(PoiUtil.getCell(sheet, wkRow, wkCol++), s002Bean.getTotalCost().get("UriageNetTr"));
        setCellBigDecimal(PoiUtil.getCell(sheet, wkRow, wkCol++), s002Bean.getTotalCost().get("UriageNetPrev"));
        setCellBigDecimal(PoiUtil.getCell(sheet, wkRow, wkCol++), s002Bean.getTotalCost().get("UriageNetFm"));
        setCellBigDecimal(PoiUtil.getCell(sheet, wkRow, wkCol++), s002Bean.getTotalCost().get("UriageNetDiff"));
        if (s002Bean.getPotentialFlg().equals("1")) {
            setCellBigDecimal(PoiUtil.getCell(sheet, wkRow, wkCol++), s002Bean.getTotalCost().get("UriageNetPd"));
            setCellBigDecimal(PoiUtil.getCell(sheet, wkRow, wkCol++), s002Bean.getTotalCost().get("UriageNetPt"));
            setCellBigDecimal(PoiUtil.getCell(sheet, wkRow, wkCol++), s002Bean.getTotalCost().get("UriageNetPs"));
        }

        // 粗利
        wkRow = convInteger(headStartMap.get("arari"));
        wkCol = DATA_START_COL;
        setCellBigDecimal(PoiUtil.getCell(sheet, wkRow, wkCol++), s002Bean.getArariSm());
        setCellBigDecimal(PoiUtil.getCell(sheet, wkRow, wkCol++), s002Bean.getArariJs());
        setCellBigDecimal(PoiUtil.getCell(sheet, wkRow, wkCol++), s002Bean.getArariJt());
        setCellBigDecimal(PoiUtil.getCell(sheet, wkRow, wkCol++), s002Bean.getArariMh());
        setCellBigDecimal(PoiUtil.getCell(sheet, wkRow, wkCol++), s002Bean.getArariSt());
        setCellBigDecimal(PoiUtil.getCell(sheet, wkRow, wkCol++), s002Bean.getArariHb());
        wkCol++; // 空白セル
        setCellBigDecimal(PoiUtil.getCell(sheet, wkRow, wkCol++), s002Bean.getArariPrev());
        setCellBigDecimal(PoiUtil.getCell(sheet, wkRow, wkCol++), s002Bean.getArariFm());
        setCellBigDecimal(PoiUtil.getCell(sheet, wkRow, wkCol++), s002Bean.getArariDiff());
        if (s002Bean.getPotentialFlg().equals("1")) {
            setCellBigDecimal(PoiUtil.getCell(sheet, wkRow, wkCol++), s002Bean.getArariPd());
            setCellBigDecimal(PoiUtil.getCell(sheet, wkRow, wkCol++), s002Bean.getArariPt());
            setCellBigDecimal(PoiUtil.getCell(sheet, wkRow, wkCol++), s002Bean.getArariPs());
        }

        // M率
        wkRow = convInteger(headStartMap.get("mritsu"));
        wkCol = DATA_START_COL;
        setCellConvMrate(PoiUtil.getCell(sheet, wkRow, wkCol++), s002Bean.getMrateSm());
        setCellConvMrate(PoiUtil.getCell(sheet, wkRow, wkCol++), s002Bean.getMrateJs());
        setCellConvMrate(PoiUtil.getCell(sheet, wkRow, wkCol++), s002Bean.getMrateJt());
        setCellConvMrate(PoiUtil.getCell(sheet, wkRow, wkCol++), s002Bean.getMrateMh());
        setCellConvMrate(PoiUtil.getCell(sheet, wkRow, wkCol++), s002Bean.getMrateSt());
        setCellConvMrate(PoiUtil.getCell(sheet, wkRow, wkCol++), s002Bean.getMrateHb());
        setCellConvMrate(PoiUtil.getCell(sheet, wkRow, wkCol++), s002Bean.getMrateTr());
        setCellConvMrate(PoiUtil.getCell(sheet, wkRow, wkCol++), s002Bean.getMratePrev());
        setCellConvMrate(PoiUtil.getCell(sheet, wkRow, wkCol++), s002Bean.getMrateFm());
        setCellConvMrate(PoiUtil.getCell(sheet, wkRow, wkCol++), s002Bean.getMrateDiff());
        if (s002Bean.getPotentialFlg().equals("1")) {
            setCellConvMrate(PoiUtil.getCell(sheet, wkRow, wkCol++), s002Bean.getMratePd());
            setCellConvMrate(PoiUtil.getCell(sheet, wkRow, wkCol++), s002Bean.getMratePt());
            setCellConvMrate(PoiUtil.getCell(sheet, wkRow, wkCol++), s002Bean.getMratePs());
        }

        // 販売直接費合計
        wkRow = convInteger(headStartMap.get("hanbaiChokuGoukei"));
        wkCol = DATA_START_COL;
        setCellBigDecimal(PoiUtil.getCell(sheet, wkRow, wkCol++), s002Bean.getSonekiList().get("HanChokuNetSm"));
        setCellBigDecimal(PoiUtil.getCell(sheet, wkRow, wkCol++), s002Bean.getSonekiList().get("HanChokuNetJs"));
        setCellBigDecimal(PoiUtil.getCell(sheet, wkRow, wkCol++), s002Bean.getSonekiList().get("HanChokuNetJt"));
        setCellBigDecimal(PoiUtil.getCell(sheet, wkRow, wkCol++), s002Bean.getSonekiList().get("HanChokuNetMh"));
        setCellBigDecimal(PoiUtil.getCell(sheet, wkRow, wkCol++), s002Bean.getSonekiList().get("HanChokuNetSt"));
        setCellBigDecimal(PoiUtil.getCell(sheet, wkRow, wkCol++), s002Bean.getSonekiList().get("HanChokuNetHb"));
        setCellBigDecimal(PoiUtil.getCell(sheet, wkRow, wkCol++), s002Bean.getSonekiList().get("HanChokuNetTr"));
        setCellBigDecimal(PoiUtil.getCell(sheet, wkRow, wkCol++), s002Bean.getSonekiList().get("HanChokuNetPrev"));
        setCellBigDecimal(PoiUtil.getCell(sheet, wkRow, wkCol++), s002Bean.getSonekiList().get("HanChokuNetFm"));
        setCellBigDecimal(PoiUtil.getCell(sheet, wkRow, wkCol++), s002Bean.getSonekiList().get("HanChokuNetDiff"));
        if (s002Bean.getPotentialFlg().equals("1")) {
            setCellBigDecimal(PoiUtil.getCell(sheet, wkRow, wkCol++), s002Bean.getSonekiList().get("HanChokuNetPd"));
            setCellBigDecimal(PoiUtil.getCell(sheet, wkRow, wkCol++), s002Bean.getSonekiList().get("HanChokuNetPt"));
            setCellBigDecimal(PoiUtil.getCell(sheet, wkRow, wkCol++), s002Bean.getSonekiList().get("HanChokuNetPs"));
        }

        // ISP
        wkRow = convInteger(headStartMap.get("isp"));
        wkCol = DATA_START_COL;
        setCellBigDecimal(PoiUtil.getCell(sheet, wkRow, wkCol++), s002Bean.getSonekiList().get("IspNetSm"));
        setCellBigDecimal(PoiUtil.getCell(sheet, wkRow, wkCol++), s002Bean.getSonekiList().get("IspNetJs"));
        setCellBigDecimal(PoiUtil.getCell(sheet, wkRow, wkCol++), s002Bean.getSonekiList().get("IspNetJt"));
        setCellBigDecimal(PoiUtil.getCell(sheet, wkRow, wkCol++), s002Bean.getSonekiList().get("IspNetMh"));
        setCellBigDecimal(PoiUtil.getCell(sheet, wkRow, wkCol++), s002Bean.getSonekiList().get("IspNetSt"));
        setCellBigDecimal(PoiUtil.getCell(sheet, wkRow, wkCol++), s002Bean.getSonekiList().get("IspNetHb"));
        setCellBigDecimal(PoiUtil.getCell(sheet, wkRow, wkCol++), s002Bean.getSonekiList().get("IspNetTr"));
        setCellBigDecimal(PoiUtil.getCell(sheet, wkRow, wkCol++), s002Bean.getSonekiList().get("IspNetPrev"));
        setCellBigDecimal(PoiUtil.getCell(sheet, wkRow, wkCol++), s002Bean.getSonekiList().get("IspNetFm"));
        setCellBigDecimal(PoiUtil.getCell(sheet, wkRow, wkCol++), s002Bean.getSonekiList().get("IspNetDiff"));
        if (s002Bean.getPotentialFlg().equals("1")) {
            setCellBigDecimal(PoiUtil.getCell(sheet, wkRow, wkCol++), s002Bean.getSonekiList().get("IspNetPd"));
            setCellBigDecimal(PoiUtil.getCell(sheet, wkRow, wkCol++), s002Bean.getSonekiList().get("IspNetPt"));
            setCellBigDecimal(PoiUtil.getCell(sheet, wkRow, wkCol++), s002Bean.getSonekiList().get("IspNetPs"));
        }

        // 販売間接費
        wkRow = convInteger(headStartMap.get("hanbaikansetsu"));
        wkCol = DATA_START_COL;
        setCellBigDecimal(PoiUtil.getCell(sheet, wkRow, wkCol++), s002Bean.getSonekiList().get("HanKanNetSm"));
        setCellBigDecimal(PoiUtil.getCell(sheet, wkRow, wkCol++), s002Bean.getSonekiList().get("HanKanNetJs"));
        setCellBigDecimal(PoiUtil.getCell(sheet, wkRow, wkCol++), s002Bean.getSonekiList().get("HanKanNetJt"));
        setCellBigDecimal(PoiUtil.getCell(sheet, wkRow, wkCol++), s002Bean.getSonekiList().get("HanKanNetMh"));
        setCellBigDecimal(PoiUtil.getCell(sheet, wkRow, wkCol++), s002Bean.getSonekiList().get("HanKanNetSt"));
        setCellBigDecimal(PoiUtil.getCell(sheet, wkRow, wkCol++), s002Bean.getSonekiList().get("HanKanNetHb"));
        setCellBigDecimal(PoiUtil.getCell(sheet, wkRow, wkCol++), s002Bean.getSonekiList().get("HanKanNetTr"));
        setCellBigDecimal(PoiUtil.getCell(sheet, wkRow, wkCol++), s002Bean.getSonekiList().get("HanKanNetPrev"));
        setCellBigDecimal(PoiUtil.getCell(sheet, wkRow, wkCol++), s002Bean.getSonekiList().get("HanKanNetFm"));
        setCellBigDecimal(PoiUtil.getCell(sheet, wkRow, wkCol++), s002Bean.getSonekiList().get("HanKanNetDiff"));
        if (s002Bean.getPotentialFlg().equals("1")) {
            setCellBigDecimal(PoiUtil.getCell(sheet, wkRow, wkCol++), s002Bean.getSonekiList().get("HanKanNetPd"));
            setCellBigDecimal(PoiUtil.getCell(sheet, wkRow, wkCol++), s002Bean.getSonekiList().get("HanKanNetPt"));
            setCellBigDecimal(PoiUtil.getCell(sheet, wkRow, wkCol++), s002Bean.getSonekiList().get("HanKanNetPs"));
        }

        // 経費
        wkRow = convInteger(headStartMap.get("keihi"));
        wkCol = DATA_START_COL;
        setCellBigDecimal(PoiUtil.getCell(sheet, wkRow, wkCol++), s002Bean.getSonekiList().get("KeihiNetSm"));
        setCellBigDecimal(PoiUtil.getCell(sheet, wkRow, wkCol++), s002Bean.getSonekiList().get("KeihiNetJs"));
        setCellBigDecimal(PoiUtil.getCell(sheet, wkRow, wkCol++), s002Bean.getSonekiList().get("KeihiNetJt"));
        setCellBigDecimal(PoiUtil.getCell(sheet, wkRow, wkCol++), s002Bean.getSonekiList().get("KeihiNetMh"));
        setCellBigDecimal(PoiUtil.getCell(sheet, wkRow, wkCol++), s002Bean.getSonekiList().get("KeihiNetSt"));
        setCellBigDecimal(PoiUtil.getCell(sheet, wkRow, wkCol++), s002Bean.getSonekiList().get("KeihiNetHb"));
        setCellBigDecimal(PoiUtil.getCell(sheet, wkRow, wkCol++), s002Bean.getSonekiList().get("KeihiNetTr"));
        setCellBigDecimal(PoiUtil.getCell(sheet, wkRow, wkCol++), s002Bean.getSonekiList().get("KeihiNetPrev"));
        setCellBigDecimal(PoiUtil.getCell(sheet, wkRow, wkCol++), s002Bean.getSonekiList().get("KeihiNetFm"));
        setCellBigDecimal(PoiUtil.getCell(sheet, wkRow, wkCol++), s002Bean.getSonekiList().get("KeihiNetDiff"));
        if (s002Bean.getPotentialFlg().equals("1")) {
            setCellBigDecimal(PoiUtil.getCell(sheet, wkRow, wkCol++), s002Bean.getSonekiList().get("KeihiNetPd"));
            setCellBigDecimal(PoiUtil.getCell(sheet, wkRow, wkCol++), s002Bean.getSonekiList().get("KeihiNetPt"));
            setCellBigDecimal(PoiUtil.getCell(sheet, wkRow, wkCol++), s002Bean.getSonekiList().get("KeihiNetPs"));
        }

        // 総原価
        wkRow = convInteger(headStartMap.get("sogenka"));
        wkCol = DATA_START_COL;
        setCellBigDecimal(PoiUtil.getCell(sheet, wkRow, wkCol++), s002Bean.getSonekiList().get("SougenkaNetSm"));
        setCellBigDecimal(PoiUtil.getCell(sheet, wkRow, wkCol++), s002Bean.getSonekiList().get("SougenkaNetJs"));
        setCellBigDecimal(PoiUtil.getCell(sheet, wkRow, wkCol++), s002Bean.getSonekiList().get("SougenkaNetJt"));
        setCellBigDecimal(PoiUtil.getCell(sheet, wkRow, wkCol++), s002Bean.getSonekiList().get("SougenkaNetMh"));
        setCellBigDecimal(PoiUtil.getCell(sheet, wkRow, wkCol++), s002Bean.getSonekiList().get("SougenkaNetSt"));
        setCellBigDecimal(PoiUtil.getCell(sheet, wkRow, wkCol++), s002Bean.getSonekiList().get("SougenkaNetHb"));
        setCellBigDecimal(PoiUtil.getCell(sheet, wkRow, wkCol++), s002Bean.getSonekiList().get("SougenkaNetTr"));
        setCellBigDecimal(PoiUtil.getCell(sheet, wkRow, wkCol++), s002Bean.getSonekiList().get("SougenkaNetPrev"));
        setCellBigDecimal(PoiUtil.getCell(sheet, wkRow, wkCol++), s002Bean.getSonekiList().get("SougenkaNetFm"));
        setCellBigDecimal(PoiUtil.getCell(sheet, wkRow, wkCol++), s002Bean.getSonekiList().get("SougenkaNetDiff"));
        if (s002Bean.getPotentialFlg().equals("1")) {
            setCellBigDecimal(PoiUtil.getCell(sheet, wkRow, wkCol++), s002Bean.getSonekiList().get("SougenkaNetPd"));
            setCellBigDecimal(PoiUtil.getCell(sheet, wkRow, wkCol++), s002Bean.getSonekiList().get("SougenkaNetPt"));
            setCellBigDecimal(PoiUtil.getCell(sheet, wkRow, wkCol++), s002Bean.getSonekiList().get("SougenkaNetPs"));
        }

        // 営業外損益
        wkRow = convInteger(headStartMap.get("egyogison"));
        wkCol = DATA_START_COL;
        setCellBigDecimal(PoiUtil.getCell(sheet, wkRow, wkCol++), s002Bean.getSonekiList().get("EigyogaiSm"));
        setCellBigDecimal(PoiUtil.getCell(sheet, wkRow, wkCol++), s002Bean.getSonekiList().get("EigyogaiJs"));
        setCellBigDecimal(PoiUtil.getCell(sheet, wkRow, wkCol++), s002Bean.getSonekiList().get("EigyogaiJt"));
        setCellBigDecimal(PoiUtil.getCell(sheet, wkRow, wkCol++), s002Bean.getSonekiList().get("EigyogaiMh"));
        setCellBigDecimal(PoiUtil.getCell(sheet, wkRow, wkCol++), s002Bean.getSonekiList().get("EigyogaiSt"));
        setCellBigDecimal(PoiUtil.getCell(sheet, wkRow, wkCol++), s002Bean.getSonekiList().get("EigyogaiHb"));
        setCellBigDecimal(PoiUtil.getCell(sheet, wkRow, wkCol++), s002Bean.getSonekiList().get("EigyogaiTr"));
        setCellBigDecimal(PoiUtil.getCell(sheet, wkRow, wkCol++), s002Bean.getSonekiList().get("EigyogaiPrev"));
        setCellBigDecimal(PoiUtil.getCell(sheet, wkRow, wkCol++), s002Bean.getSonekiList().get("EigyogaiFm"));
        setCellBigDecimal(PoiUtil.getCell(sheet, wkRow, wkCol++), s002Bean.getSonekiList().get("EigyogaiDiff"));
        if (s002Bean.getPotentialFlg().equals("1")) {
            setCellBigDecimal(PoiUtil.getCell(sheet, wkRow, wkCol++), s002Bean.getSonekiList().get("EigyogaiPd"));
            setCellBigDecimal(PoiUtil.getCell(sheet, wkRow, wkCol++), s002Bean.getSonekiList().get("EigyogaiPt"));
            setCellBigDecimal(PoiUtil.getCell(sheet, wkRow, wkCol++), s002Bean.getSonekiList().get("EigyogaiPs"));
        }

        // 為替予約
        wkRow = convInteger(headStartMap.get("kawaseYoyaku"));
        wkCol = DATA_START_COL;
        setCellBigDecimal(PoiUtil.getCell(sheet, wkRow, wkCol++), s002Bean.getSonekiList().get("KawaseYoyakuNetSm"));
        setCellBigDecimal(PoiUtil.getCell(sheet, wkRow, wkCol++), s002Bean.getSonekiList().get("KawaseYoyakuNetJs"));
        setCellBigDecimal(PoiUtil.getCell(sheet, wkRow, wkCol++), s002Bean.getSonekiList().get("KawaseYoyakuNetJt"));
        setCellBigDecimal(PoiUtil.getCell(sheet, wkRow, wkCol++), s002Bean.getSonekiList().get("KawaseYoyakuNetMh"));
        setCellBigDecimal(PoiUtil.getCell(sheet, wkRow, wkCol++), s002Bean.getSonekiList().get("KawaseYoyakuNetSt"));
        setCellBigDecimal(PoiUtil.getCell(sheet, wkRow, wkCol++), s002Bean.getSonekiList().get("KawaseYoyakuNetHb"));
        setCellBigDecimal(PoiUtil.getCell(sheet, wkRow, wkCol++), s002Bean.getSonekiList().get("KawaseYoyakuNetTr"));
        setCellBigDecimal(PoiUtil.getCell(sheet, wkRow, wkCol++), s002Bean.getSonekiList().get("KawaseYoyakuNetPrev"));
        setCellBigDecimal(PoiUtil.getCell(sheet, wkRow, wkCol++), s002Bean.getSonekiList().get("KawaseYoyakuNetFm"));
        setCellBigDecimal(PoiUtil.getCell(sheet, wkRow, wkCol++), s002Bean.getSonekiList().get("KawaseYoyakuNetDiff"));
        if (s002Bean.getPotentialFlg().equals("1")) {
            setCellBigDecimal(PoiUtil.getCell(sheet, wkRow, wkCol++), s002Bean.getSonekiList().get("KawaseYoyakuNetPd"));
            setCellBigDecimal(PoiUtil.getCell(sheet, wkRow, wkCol++), s002Bean.getSonekiList().get("KawaseYoyakuNetPt"));
            setCellBigDecimal(PoiUtil.getCell(sheet, wkRow, wkCol++), s002Bean.getSonekiList().get("KawaseYoyakuNetPs"));
        }

//        // 製番損益 合計
//        wkRow = convInteger(headStartMap.get("seibansonekiGokei"));
//        wkCol = DATA_START_COL;
//        setCellBigDecimal(PoiUtil.getCell(sheet, wkRow, wkCol++), s002Bean.getSonekiList().get("SeibanSonekiNetSm"));
//        setCellBigDecimal(PoiUtil.getCell(sheet, wkRow, wkCol++), s002Bean.getSonekiList().get("SeibanSonekiNetJs"));
//        setCellBigDecimal(PoiUtil.getCell(sheet, wkRow, wkCol++), s002Bean.getSonekiList().get("SeibanSonekiNetJt"));
//        setCellBigDecimal(PoiUtil.getCell(sheet, wkRow, wkCol++), s002Bean.getSonekiList().get("SeibanSonekiNetMh"));
//        setCellBigDecimal(PoiUtil.getCell(sheet, wkRow, wkCol++), s002Bean.getSonekiList().get("SeibanSonekiNetSt"));
//        setCellBigDecimal(PoiUtil.getCell(sheet, wkRow, wkCol++), s002Bean.getSonekiList().get("SeibanSonekiNetHb"));
//        setCellBigDecimal(PoiUtil.getCell(sheet, wkRow, wkCol++), s002Bean.getSonekiList().get("SeibanSonekiNetTr"));
//        setCellBigDecimal(PoiUtil.getCell(sheet, wkRow, wkCol++), s002Bean.getSonekiList().get("SeibanSonekiNetPrev"));
//        setCellBigDecimal(PoiUtil.getCell(sheet, wkRow, wkCol++), s002Bean.getSonekiList().get("SeibanSonekiNetFm"));
//        setCellBigDecimal(PoiUtil.getCell(sheet, wkRow, wkCol++), s002Bean.getSonekiList().get("SeibanSonekiNetDiff"));
//        if (s002Bean.getPotentialFlg().equals("1")) {
//            setCellBigDecimal(PoiUtil.getCell(sheet, wkRow, wkCol++), s002Bean.getSonekiList().get("SeibanSonekiNetPd"));
//            setCellBigDecimal(PoiUtil.getCell(sheet, wkRow, wkCol++), s002Bean.getSonekiList().get("SeibanSonekiNetPt"));
//            setCellBigDecimal(PoiUtil.getCell(sheet, wkRow, wkCol++), s002Bean.getSonekiList().get("SeibanSonekiNetPs"));
//        }
        // 経常損益 合計
        wkRow = convInteger(headStartMap.get("keijoSoneki"));
        wkCol = DATA_START_COL;
        setCellBigDecimal(PoiUtil.getCell(sheet, wkRow, wkCol++), s002Bean.getOrdinarySm());
        setCellBigDecimal(PoiUtil.getCell(sheet, wkRow, wkCol++), s002Bean.getOrdinaryJs());
        setCellBigDecimal(PoiUtil.getCell(sheet, wkRow, wkCol++), s002Bean.getOrdinaryJt());
        setCellBigDecimal(PoiUtil.getCell(sheet, wkRow, wkCol++), s002Bean.getOrdinaryMh());
        setCellBigDecimal(PoiUtil.getCell(sheet, wkRow, wkCol++), s002Bean.getOrdinarySt());
        setCellBigDecimal(PoiUtil.getCell(sheet, wkRow, wkCol++), s002Bean.getOrdinaryHb());
        setCellBigDecimal(PoiUtil.getCell(sheet, wkRow, wkCol++), s002Bean.getOrdinaryTr());
        setCellBigDecimal(PoiUtil.getCell(sheet, wkRow, wkCol++), s002Bean.getOrdinaryPrev());
        setCellBigDecimal(PoiUtil.getCell(sheet, wkRow, wkCol++), s002Bean.getOrdinaryFm());
        setCellBigDecimal(PoiUtil.getCell(sheet, wkRow, wkCol++), s002Bean.getOrdinaryDiff());
        if (s002Bean.getPotentialFlg().equals("1")) {
            setCellBigDecimal(PoiUtil.getCell(sheet, wkRow, wkCol++), s002Bean.getOrdinaryPd());
            setCellBigDecimal(PoiUtil.getCell(sheet, wkRow, wkCol++), s002Bean.getOrdinaryPt());
            setCellBigDecimal(PoiUtil.getCell(sheet, wkRow, wkCol++), s002Bean.getOrdinaryPs());
        }

        // 経常損益率 ROS
        wkRow = convInteger(headStartMap.get("keijoSonekiRitsuRos"));
        wkCol = DATA_START_COL;
        setCellConvMrate(PoiUtil.getCell(sheet, wkRow, wkCol++), s002Bean.getRosSm());
        setCellConvMrate(PoiUtil.getCell(sheet, wkRow, wkCol++), s002Bean.getRosJs());
        setCellConvMrate(PoiUtil.getCell(sheet, wkRow, wkCol++), s002Bean.getRosJt());
        setCellConvMrate(PoiUtil.getCell(sheet, wkRow, wkCol++), s002Bean.getRosMh());
        setCellConvMrate(PoiUtil.getCell(sheet, wkRow, wkCol++), s002Bean.getRosSt());
        setCellConvMrate(PoiUtil.getCell(sheet, wkRow, wkCol++), s002Bean.getRosHb());
        setCellConvMrate(PoiUtil.getCell(sheet, wkRow, wkCol++), s002Bean.getRosTr());
        setCellConvMrate(PoiUtil.getCell(sheet, wkRow, wkCol++), s002Bean.getRosPrev());
        setCellConvMrate(PoiUtil.getCell(sheet, wkRow, wkCol++), s002Bean.getRosFm());
        setCellConvMrate(PoiUtil.getCell(sheet, wkRow, wkCol++), s002Bean.getRosDiff());
        if (s002Bean.getPotentialFlg().equals("1")) {
            setCellConvMrate(PoiUtil.getCell(sheet, wkRow, wkCol++), s002Bean.getRosPd());
            setCellConvMrate(PoiUtil.getCell(sheet, wkRow, wkCol++), s002Bean.getRosPt());
            setCellConvMrate(PoiUtil.getCell(sheet, wkRow, wkCol++), s002Bean.getRosPs());
        }
    }

    /**
     * 通貨の埋め込み
     */
    private int setCurrencyCode(Sheet sheet, int wkRow, List<HashMap<String, String>> currencyList) {
        if (!currencyList.isEmpty()) {
            int wkCol = DATA_START_COL;
            int wkTitleCol = TITLE_START_COL;
            // レート
            boolean rateFlg = false;
            int startRow = wkRow;
            for (HashMap<String, String> currencyRateMap : currencyList) {
                if (currencyRateMap.containsKey("currencyCode")) {
                    String currencyCode = currencyRateMap.get("currencyCode");
                    if (!currencyCode.equals(s002Bean.getCurrencyCodeEn())) {
                        // 2行目以降は行追加（Excel計算式保持のため）
                        if (rateFlg) {
                            sheet.shiftRows(wkRow, sheet.getLastRowNum(), 1);
                            sheet.createRow(wkRow);
                            // 行のコピー
                            PoiUtil.copyRowStyleValue(sheet.getRow(wkRow), sheet.getRow(wkRow - 1), false);
                        }
                        // 通貨コードをセット
                        PoiUtil.setCellValue(PoiUtil.getCell(sheet, wkRow, wkTitleCol++), Label.getValue(Label.rate));
                        PoiUtil.setCellValue(PoiUtil.getCell(sheet, wkRow, wkTitleCol++), currencyCode);

                        // 右辺データセット
                        setCellBigDecimal(PoiUtil.getCell(sheet, wkRow, wkCol++), currencyRateMap.get("KeiyakuRateSm"));
                        setCellBigDecimal(PoiUtil.getCell(sheet, wkRow, wkCol++), currencyRateMap.get("KeiyakuRateJs"));
                        setCellBigDecimal(PoiUtil.getCell(sheet, wkRow, wkCol++), currencyRateMap.get("KeiyakuRateJt"));
                        setCellBigDecimal(PoiUtil.getCell(sheet, wkRow, wkCol++), currencyRateMap.get("KeiyakuRateMh"));
                        setCellBigDecimal(PoiUtil.getCell(sheet, wkRow, wkCol++), currencyRateMap.get("KeiyakuRateSt"));
                        setCellBigDecimal(PoiUtil.getCell(sheet, wkRow, wkCol++), currencyRateMap.get("KeiyakuRateHb"));
                        setCellBigDecimal(PoiUtil.getCell(sheet, wkRow, wkCol++), currencyRateMap.get("KeiyakuRateTr"));
                        setCellBigDecimal(PoiUtil.getCell(sheet, wkRow, wkCol++), currencyRateMap.get("KeiyakuRatePrev"));
                        setCellBigDecimal(PoiUtil.getCell(sheet, wkRow, wkCol++), currencyRateMap.get("KeiyakuRateFm"));
                        wkCol++; // 空セル
                        if (s002Bean.getPotentialFlg().equals("1")) {
                            setCellBigDecimal(PoiUtil.getCell(sheet, wkRow, wkCol++), currencyRateMap.get("KeiyakuRatePd"));
                            setCellBigDecimal(PoiUtil.getCell(sheet, wkRow, wkCol++), currencyRateMap.get("KeiyakuRatePt"));
                            setCellBigDecimal(PoiUtil.getCell(sheet, wkRow, wkCol++), currencyRateMap.get("KeiyakuRatePs"));
                        }
                        wkCol = DATA_START_COL;
                        wkTitleCol = TITLE_START_COL;

                        wkRow++; // 行加算
                        rateFlg = true;
                    }
                }
            }
            if (!rateFlg) {
                PoiUtil.delRow(sheet, startRow, 1);
            } else {
                PoiUtil.addMergedRegion(sheet, startRow, TITLE_START_COL, (wkRow - 1), TITLE_START_COL);
            }

            // 金額
            rateFlg = false;
            startRow = wkRow;
            for (HashMap<String, String> currencyRateMap : currencyList) {
                if (currencyRateMap.containsKey("currencyCode")) {
                    String currencyCode = currencyRateMap.get("currencyCode");
                    // 2行目以降は行追加（Excel計算式保持のため）
                    if (rateFlg) {
                        sheet.shiftRows(wkRow, sheet.getLastRowNum(), 1);
                        sheet.createRow(wkRow);
                        // 行のコピー
                        PoiUtil.copyRowStyleValue(sheet.getRow(wkRow), sheet.getRow(wkRow - 1), false);
                    }
                    // 通貨コードをセット
                    PoiUtil.setCellValue(PoiUtil.getCell(sheet, wkRow, wkTitleCol++), Label.getValue(Label.keiyaku));
                    PoiUtil.setCellValue(PoiUtil.getCell(sheet, wkRow, wkTitleCol++), currencyCode);

                    // 右辺データセット
                    setCellBigDecimal(PoiUtil.getCell(sheet, wkRow, wkCol++), currencyRateMap.get("KeiyakuAmountSm"));
                    setCellBigDecimal(PoiUtil.getCell(sheet, wkRow, wkCol++), currencyRateMap.get("KeiyakuAmountJs"));
                    setCellBigDecimal(PoiUtil.getCell(sheet, wkRow, wkCol++), currencyRateMap.get("KeiyakuAmountJt"));
                    setCellBigDecimal(PoiUtil.getCell(sheet, wkRow, wkCol++), currencyRateMap.get("KeiyakuAmountMh"));
                    setCellBigDecimal(PoiUtil.getCell(sheet, wkRow, wkCol++), currencyRateMap.get("KeiyakuAmountSt"));
                    setCellBigDecimal(PoiUtil.getCell(sheet, wkRow, wkCol++), currencyRateMap.get("KeiyakuAmountHb"));
                    setCellBigDecimal(PoiUtil.getCell(sheet, wkRow, wkCol++), currencyRateMap.get("KeiyakuAmountTr"));
                    setCellBigDecimal(PoiUtil.getCell(sheet, wkRow, wkCol++), currencyRateMap.get("KeiyakuAmountPrev"));
                    setCellBigDecimal(PoiUtil.getCell(sheet, wkRow, wkCol++), currencyRateMap.get("KeiyakuAmountFm"));
                    setCellBigDecimal(PoiUtil.getCell(sheet, wkRow, wkCol++), currencyRateMap.get("KeiyakuAmountDiff"));
                    if (s002Bean.getPotentialFlg().equals("1")) {
                        setCellBigDecimal(PoiUtil.getCell(sheet, wkRow, wkCol++), currencyRateMap.get("KeiyakuAmountPd"));
                        setCellBigDecimal(PoiUtil.getCell(sheet, wkRow, wkCol++), currencyRateMap.get("KeiyakuAmountPt"));
                        setCellBigDecimal(PoiUtil.getCell(sheet, wkRow, wkCol++), currencyRateMap.get("KeiyakuAmountPs"));
                    }
                    wkCol = DATA_START_COL;
                    wkTitleCol = TITLE_START_COL;

                    wkRow++; // 行加算
                    rateFlg = true;
                }
            }
            PoiUtil.addMergedRegion(sheet, startRow, TITLE_START_COL, (wkRow - 1), TITLE_START_COL);
        } else {
            wkRow += 2;
        }

        return wkRow;
    }

    /**
     * 売上原価(NET)項目名の埋め込み
     */
    private int setCostList(Sheet sheet, int wkRow, List<HashMap<String, String>> costList) {
        if (!costList.isEmpty()) {
            int wkCol = DATA_START_COL;
            int wkTitleCol = TITLE_START_COL;
            int idx = 0;
            for (HashMap<String, String> cost : costList) {
                if (cost.containsKey("categoryName1")) {
                    String currencyCode = cost.get("categoryName1");
                    // 2行目以降は行追加（Excel計算式保持のため）
                    if (idx != 0) {
                        sheet.shiftRows(wkRow, sheet.getLastRowNum(), 1);
                        sheet.createRow(wkRow);
                        // 行のコピー
                        PoiUtil.copyRowStyleValue(sheet.getRow(wkRow), sheet.getRow(wkRow - 1), false);
                    }
                    // タイトルをセット
                    PoiUtil.setCellValue(PoiUtil.getCell(sheet, wkRow, wkTitleCol++), currencyCode);

                    if (cost.containsKey("categoryName2")) {
                        // タイトルをセット
                        currencyCode = cost.get("categoryName2");
                        PoiUtil.setCellValue(PoiUtil.getCell(sheet, wkRow, wkTitleCol++), currencyCode);
                    }

//                    PoiUtil.setCellValue(sheet, wkRow, wkCol++, Label.getValue(Label.mit));
//                    setCellBigDecimal(PoiUtil.getCell(sheet, wkRow, wkCol++), cost.get("UriageNetSm"));
//                    StringBuilder mit = new StringBuilder(Label.getValue(Label.mit));
//                    if (StringUtil.isNotEmpty(cost.get("UriageNetSm"))) {
//                        mit.append(cost.get("UriageNetJs"));
//                    }
//                    PoiUtil.setCellValue(PoiUtil.getCell(sheet, wkRow, wkCol++), mit);

                    setCellBigDecimal(PoiUtil.getCell(sheet, wkRow, wkCol++), cost.get("UriageNetSm"));
                    setCellBigDecimal(PoiUtil.getCell(sheet, wkRow, wkCol++), cost.get("UriageNetJs"));
                    setCellBigDecimal(PoiUtil.getCell(sheet, wkRow, wkCol++), cost.get("UriageNetJt"));
                    setCellBigDecimal(PoiUtil.getCell(sheet, wkRow, wkCol++), cost.get("UriageNetMh"));
                    setCellBigDecimal(PoiUtil.getCell(sheet, wkRow, wkCol++), cost.get("UriageNetSt"));
                    setCellBigDecimal(PoiUtil.getCell(sheet, wkRow, wkCol++), cost.get("UriageNetHb"));
                    setCellBigDecimal(PoiUtil.getCell(sheet, wkRow, wkCol++), cost.get("UriageNetTr"));
                    setCellBigDecimal(PoiUtil.getCell(sheet, wkRow, wkCol++), cost.get("UriageNetPrev"));
                    setCellBigDecimal(PoiUtil.getCell(sheet, wkRow, wkCol++), cost.get("UriageNetFm"));
                    setCellBigDecimal(PoiUtil.getCell(sheet, wkRow, wkCol++), cost.get("UriageNetDiff"));
                    if (s002Bean.getPotentialFlg().equals("1")) {
                        setCellBigDecimal(PoiUtil.getCell(sheet, wkRow, wkCol++), cost.get("UriageNetPd"));
                        setCellBigDecimal(PoiUtil.getCell(sheet, wkRow, wkCol++), cost.get("UriageNetPt"));
                        setCellBigDecimal(PoiUtil.getCell(sheet, wkRow, wkCol++), cost.get("UriageNetPs"));
                    }
                    wkCol = DATA_START_COL;
                    wkTitleCol = TITLE_START_COL;
                    wkRow++; // 行加算
                }
                idx++;
            }
        } else {
            wkRow += 1;
        }

        return wkRow;
    }

    /**
     * 販売直接費項目名の埋め込み
     */
    private int setCategoryName(Sheet sheet, int wkRow, List<HashMap<String, String>> categoryHanchokuList) {
        if (!categoryHanchokuList.isEmpty()) {
            int wkCol = DATA_START_COL;
            int wkTitleCol = TITLE_START_COL;
            int idx = 0;
            for (HashMap<String, String> categoryHanchoku : categoryHanchokuList) {
                if (categoryHanchoku.containsKey("categoryName")) {

                    String currencyCode = categoryHanchoku.get("categoryName");
                    // 2行目以降は行追加（Excel計算式保持のため）
                    if (idx != 0) {
                        sheet.shiftRows(wkRow, sheet.getLastRowNum(), 1);
                        sheet.createRow(wkRow);
                        // 行のコピー
                        PoiUtil.copyRowStyleValue(sheet.getRow(wkRow), sheet.getRow(wkRow - 1), false);
                    }

                    PoiUtil.addMergedRegion(sheet, wkRow, TITLE_START_COL, wkRow, (TITLE_START_COL + 1));
                    // タイトルをセット
                    PoiUtil.setCellValue(PoiUtil.getCell(sheet, wkRow, wkTitleCol), currencyCode);

                    setCellBigDecimal(PoiUtil.getCell(sheet, wkRow, wkCol++), categoryHanchoku.get("HanChokuNetSm"));
                    setCellBigDecimal(PoiUtil.getCell(sheet, wkRow, wkCol++), categoryHanchoku.get("HanChokuNetJs"));
                    setCellBigDecimal(PoiUtil.getCell(sheet, wkRow, wkCol++), categoryHanchoku.get("HanChokuNetJt"));
                    setCellBigDecimal(PoiUtil.getCell(sheet, wkRow, wkCol++), categoryHanchoku.get("HanChokuNetMh"));
                    setCellBigDecimal(PoiUtil.getCell(sheet, wkRow, wkCol++), categoryHanchoku.get("HanChokuNetSt"));
                    setCellBigDecimal(PoiUtil.getCell(sheet, wkRow, wkCol++), categoryHanchoku.get("HanChokuNetHb"));
                    setCellBigDecimal(PoiUtil.getCell(sheet, wkRow, wkCol++), categoryHanchoku.get("HanChokuNetTr"));
                    setCellBigDecimal(PoiUtil.getCell(sheet, wkRow, wkCol++), categoryHanchoku.get("HanChokuNetPrev"));
                    setCellBigDecimal(PoiUtil.getCell(sheet, wkRow, wkCol++), categoryHanchoku.get("HanChokuNetFm"));
                    setCellBigDecimal(PoiUtil.getCell(sheet, wkRow, wkCol++), categoryHanchoku.get("HanChokuNetDiff"));
                    if (s002Bean.getPotentialFlg().equals("1")) {
                        setCellBigDecimal(PoiUtil.getCell(sheet, wkRow, wkCol++), categoryHanchoku.get("HanChokuNetPd"));
                        setCellBigDecimal(PoiUtil.getCell(sheet, wkRow, wkCol++), categoryHanchoku.get("HanChokuNetPt"));
                        setCellBigDecimal(PoiUtil.getCell(sheet, wkRow, wkCol++), categoryHanchoku.get("HanChokuNetPs"));
                    }
                    wkCol = DATA_START_COL;
                    wkTitleCol = TITLE_START_COL;
                    wkRow++; // 行加算
                }
                idx++;
            }
        } else {
            wkRow += 1;
        }

        return wkRow;
    }

    /**
     * 製番損益項目名の埋め込み
     */
//    private int setProductSoneki(Sheet sheet, int wkRow, List<HashMap<String, String>> productSonekiList) {
//        if (!productSonekiList.isEmpty()) {
//            int wkCol = DATA_START_COL;
//            int idx = 0;
//            for (HashMap<String, String> productSoneki : productSonekiList) {
//                if (productSoneki.containsKey("kojoName")) {
//
//                    String currencyCode = productSoneki.get("kojoName");
//                    // 2行目以降は行追加（Excel計算式保持のため）
//                    if (idx != 0) {
//                        sheet.shiftRows(wkRow, sheet.getLastRowNum(), 1);
//                        sheet.createRow(wkRow);
//                        // 行のコピー
//                        PoiUtil.copyRowStyleValue(sheet.getRow(wkRow), sheet.getRow(wkRow - 1), false);
//                    }
//                    PoiUtil.addMergedRegion(sheet, wkRow, 1, wkRow, 2);
//                    // タイトルをセット
//                    PoiUtil.setCellValue(PoiUtil.getCell(sheet, wkRow, 1), currencyCode);
//
//                    setCellBigDecimal(PoiUtil.getCell(sheet, wkRow, wkCol++), productSoneki.get("SeibanSonekiNetSm"));
//                    setCellBigDecimal(PoiUtil.getCell(sheet, wkRow, wkCol++), productSoneki.get("SeibanSonekiNetJs"));
//                    setCellBigDecimal(PoiUtil.getCell(sheet, wkRow, wkCol++), productSoneki.get("SeibanSonekiNetJt"));
//                    setCellBigDecimal(PoiUtil.getCell(sheet, wkRow, wkCol++), productSoneki.get("SeibanSonekiNetMh"));
//                    setCellBigDecimal(PoiUtil.getCell(sheet, wkRow, wkCol++), productSoneki.get("SeibanSonekiNetSt"));
//                    setCellBigDecimal(PoiUtil.getCell(sheet, wkRow, wkCol++), productSoneki.get("SeibanSonekiNetHb"));
//                    setCellBigDecimal(PoiUtil.getCell(sheet, wkRow, wkCol++), productSoneki.get("SeibanSonekiNetTr"));
//                    setCellBigDecimal(PoiUtil.getCell(sheet, wkRow, wkCol++), productSoneki.get("SeibanSonekiNetPrev"));
//                    setCellBigDecimal(PoiUtil.getCell(sheet, wkRow, wkCol++), productSoneki.get("SeibanSonekiNetFm"));
//                    setCellBigDecimal(PoiUtil.getCell(sheet, wkRow, wkCol++), productSoneki.get("SeibanSonekiNetDiff"));
//                    if (s002Bean.getPotentialFlg().equals("1")) {
//                        setCellBigDecimal(PoiUtil.getCell(sheet, wkRow, wkCol++), productSoneki.get("SeibanSonekiNetPd"));
//                        setCellBigDecimal(PoiUtil.getCell(sheet, wkRow, wkCol++), productSoneki.get("SeibanSonekiNetPt"));
//                        setCellBigDecimal(PoiUtil.getCell(sheet, wkRow, wkCol++), productSoneki.get("SeibanSonekiNetPs"));
//                    }
//                    wkCol = DATA_START_COL;
//                    wkRow++; // 行加算
//                }
//                idx++;
//            }
//        } else {
//            wkRow += 1;
//        }
//
//        return wkRow;
//    }

    /**
     *
     * @param cell
     * @param value
     */
    private void setCellBigDecimal(Cell cell, Object value) {
        PoiUtil.setCellValue(cell, NumberUtils.changeBigDecimal(value));
    }

    /**
     * ObjectをInteger型に変換
     *
     * @param obj
     * @return
     * @throws Exception
     */
    private Integer convInteger(Object obj) throws Exception {
        if (obj == null) {
            return null;
        }
        return new Integer(obj.toString()).intValue();
    }

    /**
     *
     * @param cell
     * @param value
     * @throws Exception
     */
    private void setCellConvMrate(Cell cell, String value) throws Exception {
        PoiUtil.setCellValue(cell, Utils.changeBigDecimal(sUtils.exeFormatRate(NumberUtils.changeBigDecimal(value))));
    }

    /**
     * @return the divisionCode
     */
    public String getDivisionCode() {
        return divisionCode;
    }

    /**
     * @param divisionCode the divisionCode to set
     */
    public void setDivisionCode(String divisionCode) {
        this.divisionCode = divisionCode;
    }

    /**
     *
     * @return
     */
    private String calcDiff() {
        StringBuilder ret = new StringBuilder("");
        if (s002Bean.getCalcDiffFlg() != null
                && !s002Bean.getCalcDiffFlg().isEmpty()
                && s002Bean.getCalcDiffFlg().trim().matches("^[0-9]*$")) {
        }
        switch (Integer.valueOf(s002Bean.getCalcDiffFlg())) {
            case 1:
                ret.append("(");
                ret.append(Label.getValue(Label.mokuhyo));
                ret.append("-");
                ret.append(Label.getValue(Label.mikomi));
                ret.append(")");
                break;
            case 2:
                ret.append("(");
                ret.append(Label.getValue(Label.jyusei));
                ret.append("-");
                ret.append(Label.getValue(Label.mikomi));
                ret.append(")");
                break;
            case 3:
                ret.append("(");
                ret.append(Label.getValue(Label.jyuchu));
                ret.append("-");
                ret.append(Label.getValue(Label.mikomi));
                ret.append(")");
                break;
            case 4:
                ret.append("(");
                ret.append(Label.getValue(Label.mit));
                ret.append("-");
                ret.append(Label.getValue(Label.mikomi));
                ret.append(")");
                break;
            case 5:
                ret.append("(");
                ret.append(Label.getValue(Label.hatsuban));
                ret.append("-");
                ret.append(Label.getValue(Label.mikomi));
                ret.append(")");
                break;
            case 6:
                ret.append("(");
                ret.append(Label.getValue(Label.currentValue));
                ret.append("-");
                ret.append(Label.getValue(Label.previousValue));
                ret.append(")");
                break;
        }
        return ret.toString();
    }
}
