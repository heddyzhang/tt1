/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package jp.co.toshiba.hby.pspromis.syuueki.facade;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.ejb.Stateless;
import javax.inject.Inject;
import javax.interceptor.Interceptors;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import jp.co.toshiba.hby.pspromis.syuueki.entity.SyuGeNetItemTbl;
import jp.co.toshiba.hby.pspromis.syuueki.entity.SyuGeNetItemTblView;
import jp.co.toshiba.hby.pspromis.syuueki.entity.SyuKiBikou;
import jp.co.toshiba.hby.pspromis.syuueki.interceptor.TranceInterceptor;
import jp.co.toshiba.hby.pspromis.syuueki.util.Utils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 *
 * @author wakamatsu
 */
@Stateless
@Interceptors({TranceInterceptor.class})
public class SyuGeNetItemTblViewFacade extends AbstractFacade<SyuGeNetItemTblView> {

    private static final Logger logger = LoggerFactory.getLogger(SyuGeNetItemTblViewFacade.class);

    @PersistenceContext(unitName = jp.co.toshiba.hby.pspromis.syuueki.util.ConstantString.syuuekiDataSourceName)
    private EntityManager em;

    @Override
    protected EntityManager getEntityManager() {
        return em;
    }

    /**
     * Injection util
     */
    @Inject
    private Utils util;

    public SyuGeNetItemTblViewFacade() {
        super(SyuGeNetItemTblView.class);
    }

    /**
     * 項番一覧(期間)データのサマリ値(件数、現状発番、NET合計、発注外貨)を取得
     * @param condition
     * @return
     */
    public SyuGeNetItemTblView getItemSum(Object condition) {
        logger.info("SyuGeNetItemTblViewFacade#getItemSum");

        SyuGeNetItemTblView entity = null;
        List<SyuGeNetItemTblView> list
                = sqlExecutor.getResultList(em, SyuGeNetItemTblView.class, "/sql/S005/selectSyuGeNetItemTbl.sql", condition);
        
//        SyuGeNetItemTblView entity = 
//                sqlExecutor.getSingleResult(em, SyuGeNetItemTblView.class, "/sql/S005/selectSyuGeNetItemTbl.sql", condition);
        
        if (list.size() > 0) {
            entity = list.get(0);
        }

        return entity;
    }

    /**
     * 項番一覧(期間)データを取得
     * @param condition
     * @param page
     * @return
     * @throws Exception 
     */
    public List<SyuGeNetItemTblView> getItemList(Object condition, Integer page) throws Exception {
        logger.info("SyuGeNetItemTblViewFacade#getItemList");
        int limit = util.getPageLimit();
        int offset = util.getPageOffset(page);

        List<SyuGeNetItemTblView> list
                = sqlExecutor.getResultList(em, SyuGeNetItemTblView.class, "/sql/S005/selectSyuGeNetItemTbl.sql", condition, limit, offset);

        return list;
    }
    
    /**
     * 項番一覧データを取得(ページ制御を考慮しない)
     * @param condition
     * @return
     * @throws Exception 
     */
    public List<SyuGeNetItemTblView> getItemList(Object condition) throws Exception {
        logger.info("SyuGeNetItemTblViewFacade#getItemList");
        
        List<SyuGeNetItemTblView> list
                = sqlExecutor.getResultList(em, SyuGeNetItemTblView.class, "/sql/S005/selectSyuGeNetItemTbl.sql", condition);

        return list;
    }
    
    /**
     * 項番一覧(最終)データのサマリ値(件数、合計値)を取得
     * @param condition
     * @return
     */
//    public SyuGeNetItemTblView getItemSumLast(Object condition) {
//        logger.info("SyuGeNetItemTblViewFacade#getItemSumLast");
//
//        SyuGeNetItemTblView entity = null;
//        List<SyuGeNetItemTblView> list
//                = sqlExecutor.getResultList(em, SyuGeNetItemTblView.class, "/sql/S005/selectSyuGeNetItemTblLast.sql", condition);
//        
//        if (list.size() > 0) {
//            entity = list.get(0);
//        }
//
//        return entity;
//    }
    
    /**
     * 項番一覧(最終)データを取得
     * @param condition
     * @param page
     * @return
     * @throws Exception 
     */
//    public List<SyuGeNetItemTblView> getItemListLast(Object condition, Integer page) throws Exception {
//        logger.info("SyuGeNetItemTblViewFacade#getItemListLast");
//        int limit = util.getPageLimit();
//        int offset = util.getPageOffset(page);
//
//        List<SyuGeNetItemTblView> list
//                = sqlExecutor.getResultList(em, SyuGeNetItemTblView.class, "/sql/S005/selectSyuGeNetItemTblLast.sql", condition, limit, offset);
//
//        return list;
//    }
    
    /**
     * 項番一覧(期間)保存処理(最新見込)
     * @param condition
     */
    public int updateSeibanSyuGeNetItem(Map<String, Object> condition) {
        // 更新
        int count = sqlExecutor.executeUpdateSql(em, "/sql/S005/updateSeibanSyuGeNetItem.sql", condition);
        return count;
    }
    
    /**
     * 見込項番削除処理
     * @param condition
     */
    public int deleteKobanSyuGeNetItem(Map<String, Object> condition) {
        // 更新
        int count = sqlExecutor.executeUpdateSql(em, "/sql/S005/deleteKobanSyuGeNetItem.sql", condition);
        return count;
    }
    
    /**
     * 備考取得処理
     * @param ankenId
     * @param rirekiId
     * @param rirekiFlg
     * @param orderItem
     * @return 
     */
    public SyuKiBikou getBikou(String ankenId, Integer rirekiId, String orderItem, String rirekiFlg){
        logger.info("SyuGeNetItemTblViewFacade#getBikou");
        
        SyuKiBikou entity = null;
        
        Map<String, Object> condition = new HashMap<>();
        condition.put("ankenId", ankenId);
        condition.put("rirekiId", rirekiId);
        condition.put("rirekiFlg", rirekiFlg);
        condition.put("orderItem", orderItem);
        
        List<SyuKiBikou> list = sqlExecutor.getResultList(em, SyuKiBikou.class, "/sql/syuGeNetItemTbl/selectBikou.sql", condition);
        
        if(list.size() > 0) {
            entity = list.get(0);
        }
        
        return entity;
    }
    
    public SyuGeNetItemTbl getDispKoban(String ankenId, String rirekiId, String orderItem, String rirekiFlg) {
       logger.info("SyuGeNetItemTblViewFacade#getDispKoban");
       
        SyuGeNetItemTbl entity = null;
        
        Map<String, Object> condition = new HashMap<>();
        condition.put("ankenId", ankenId);
        condition.put("rirekiId", Integer.parseInt(rirekiId));
        condition.put("rirekiFlg", rirekiFlg);
        condition.put("orderItem", orderItem);
        
        List<SyuGeNetItemTbl> list = sqlExecutor.getResultList(em, SyuGeNetItemTbl.class, "/sql/syuGeNetItemTbl/selectKoban.sql", condition);
        if(list.size() > 0){
            entity = list.get(0);
        }
        
        return entity;
    }
    
    /**
     * 備考更新処理
     * @param condition
     */
    public int updateBikou(Object condition){
        logger.info("SyuGeNetItemTblViewFacade#updateBikou");

        // GE_NET_ITEMの更新
        int count = sqlExecutor.executeUpdateSql(em, "/sql/syuGeNetItemTbl/updateBikou.sql", condition);
        return count;
    }
    
    /**
     * 項番件数取得処理
     */
    public int getKobanCount(Object condition){
        logger.info("SyuGeNetItemTblViewFacade#getKobanCount");
        
        int cnt = 0;
        List<SyuGeNetItemTbl> list = sqlExecutor.getResultList(em, SyuGeNetItemTbl.class, "/sql/syuGeNetItemTbl/selectKoban.sql", condition);
        if(list.size() > 0){
            cnt = 1;
        }
        
        return cnt;
    }

    /**
     * 各子画面で表示/更新を行う対象項番の表示(複数件データ)
     * @param condition
     * @return 
     */
    public List<SyuGeNetItemTblView> getSubTargetItemList(Object condition) {
        logger.info("SyuGeNetItemTblViewFacade#getSubTargetItemList");

        List<SyuGeNetItemTblView> list
                = sqlExecutor.getResultList(em, SyuGeNetItemTblView.class, "/sql/syuGeNetItemTbl/selectSubTargetOrderItem.sql", condition);

        return list;
    }
    
    /**
     * 各子画面で表示/更新を行う対象項番の表示(1データのみ)
     * @param condition
     * @return 
     */
    public SyuGeNetItemTblView getSubTargetItem(Object condition) {
        logger.info("SyuGeNetItemTblViewFacade#getSubTargetItem");

        SyuGeNetItemTblView entity = null;
        List<SyuGeNetItemTblView> list = getSubTargetItemList(condition);

        if (list.size() > 0) {
            entity = list.get(0);
        }

        return entity;
    }
    
    /**
     * カテゴリ更新処理
     * @param condition
     */
    public int updateCategory(Object condition){
        logger.info("SyuGeNetItemTblViewFacade#updateCategory");

        // GE_NET_ITEMの更新
        int count = sqlExecutor.executeUpdateSql(em, "/sql/syuGeNetItemTbl/updateCategory.sql", condition);
        return count;
    }

    /**
     * 見込項番作成
     * @param condition
     */
    public int insertMikomiKobn(Object condition){
        logger.info("SyuGeNetItemTblViewFacade#insertMikomiKobn");

        // GE_NET_ITEMの更新
        int count = sqlExecutor.executeUpdateSql(em, "/sql/syuGeNetItemTbl/insertKoban.sql", condition);
        return count;
    }
    
    /**
     * 項番のカテゴリチェック(NETカテゴリ編集画面)
     * @param ankenId
     * @param rirekiId
     * @param cateCode
     * @return 
     */
    public SyuGeNetItemTbl checkCateCode(String ankenId, Integer rirekiId, String cateCode){
        SyuGeNetItemTbl entity = null;
        
        Map<String, Object> condition = new HashMap<>();
        condition.put("ankenId", ankenId);
        condition.put("rirekiId", rirekiId);
        condition.put("categoryCode", cateCode);
        
        List<SyuGeNetItemTbl> list = sqlExecutor.getResultList(em, SyuGeNetItemTbl.class, "/sql/syuGeNetItemTbl/checkCateCode.sql", condition);
        
        if(list.size() > 0){
            entity = list.get(0);
        }
        
        return entity;
    }

    /**
     * 発番引当画面で発番済対象項番の表示
     * @param condition
     * @return 
     */
    public List<SyuGeNetItemTblView> getHatsubanItemList(Object condition) {
        logger.info("SyuGeNetItemTblViewFacade#getHatsubanItemList");

        List<SyuGeNetItemTblView> list
                = sqlExecutor.getResultList(em, SyuGeNetItemTblView.class, "/sql/syuGeNetItemTbl/selectHatsubanOrderItem.sql", condition);

        return list;
    }
    
    /**
     * 各子画面で表示/更新を行う対象項番の表示
     * @param condition
     * @return 
     */
    public SyuGeNetItemTbl getMikomiItem(Object condition) {
        logger.info("SyuGeNetItemTblFacade#getMikomiItem");

        SyuGeNetItemTbl entity = null;
        List<SyuGeNetItemTbl> list
                = sqlExecutor.getResultList(em, SyuGeNetItemTbl.class, "/sql/syuGeNetItemTbl/selectMikomiItem.sql", condition);

        if (list.size() > 0) {
            entity = list.get(0);
        }

        return entity;
    }
    
    /**
     * 最終見込データ更新処理
     * @param condition
     */
    public int updateSaisyuMikomi(Object condition){
        logger.info("SyuGeNetItemTblViewFacade#updateSaisyuMikomi");

        // SYU_GE_NET_ITEM_TBLの更新
        int count = sqlExecutor.executeUpdateSql(em, "/sql/syuGeNetItemTbl/updateSaisyuMikomi.sql", condition);
        return count;
    }

    /**
     * 見積管理連携用keyの更新
     * @param condition
     */
    public int updateMitsumoriKey(Object condition){
        logger.info("SyuGeNetItemTblViewFacade#updateMitsumoriKey");

        // SYU_GE_NET_ITEM_TBLの更新
        int count = sqlExecutor.executeUpdateSql(em, "/sql/syuGeNetItemTbl/updateMitsumoriKey.sql", condition);
        return count;
    }

    /**
     * 指定カテゴリに紐づくアイテム件数を取得
     */
    public Integer countCategoryItem(Object condition) {
        logger.info("SyuGeNetItemTblViewFacade#updateSaisyuMikomi");

        // SYU_GE_NET_ITEM_TBLの更新
        int count = sqlExecutor.getCount(em, "/sql/syuGeNetItemTbl/selectCategoryItemCount.sql", condition);
        return count;
    }
    
}

