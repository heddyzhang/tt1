package jp.co.toshiba.hby.pspromis.syuueki.bean;

import java.util.List;
import java.util.Map;
import javax.enterprise.context.RequestScoped;
import javax.inject.Named;
import jp.co.toshiba.hby.pspromis.syuueki.entity.SyuAttachTbl;
import jp.co.toshiba.hby.pspromis.syuueki.enums.ScreenMode;
import lombok.Getter;
import lombok.Setter;
import org.apache.commons.lang3.StringUtils;
/**
 *
 * @author 
 */
@Named(value = "s015Bean")
@RequestScoped
@Getter @Setter
public class S015Bean extends AbstractBean {

    /**
     * 参照/編集モード
     */
    private String screenMode = ScreenMode.READ.getValue();

    /**
     * 添付ファイルのダウンロード対象のSEQ
     */
    private String targetSeq;

    /**
     * ダウンロード対象ファイルのサーバー保管パス
     */
    private String attFileFullPath;
    
    /**
     * ダウンロード対象ファイルのオリジナル名称
     */
    private String attFileName;
    
    /**
     * 一覧表示データ
     */
    private List<SyuAttachTbl> dispList;
    
    /**
     * 保存データ
     */
    private List<Map<String, Object>> attachList;

    /**
     * 事業部コード
     */
    private String divisionCode;
    
    /**
     * 新規追加行であるかを判断
     */
    public int getNewEntryKbn(SyuAttachTbl entity) {
        if (entity.getSeq() == null) {
            return 1;
        } else {
            return 0;
        }
    }
    
    /**
     * 添付ファイルの区分を取得
     */
    public String getAttachKbn(SyuAttachTbl entity) {
        if (StringUtils.isNotEmpty(entity.getAttFileName())) {
            return "1";
        } else {
            return "0";
        }
    }
    
    /**
     * リンクを取得
     */
//    public String getLinkLabel(SyuAttachTbl entity, String attachKbn) {
//        if ("1".equals(attachKbn)) {
//            return StringUtils.defaultString(entity.getAttFileName());
//        } else {
//            return StringUtils.defaultString(entity.getUrlName());
//        }
//    }

    /**
     * 画面が参照モードであるかを確認
     */
    public boolean isRead() {
        return ScreenMode.READ.getValue().equals(screenMode);
    }
    
    /**
     * 画面が編集ードであるかを確認
     */
    public boolean isEdit() {
        return ScreenMode.EDIT.getValue().equals(screenMode);
    }
}
