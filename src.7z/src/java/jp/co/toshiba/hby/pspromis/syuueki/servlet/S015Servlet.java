package jp.co.toshiba.hby.pspromis.syuueki.servlet;

import javax.inject.Inject;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpServletRequest;
import jp.co.toshiba.hby.pspromis.syuueki.bean.S015Bean;
import jp.co.toshiba.hby.pspromis.syuueki.bean.ValidationMessageBean;
import jp.co.toshiba.hby.pspromis.syuueki.service.S015Service;
import jp.co.toshiba.hby.pspromis.syuueki.util.FileUtils;
import jp.co.toshiba.hby.pspromis.syuueki.util.ParameterBinder;

/**
 * ES-Promis収益管理システム
 * 添付ファイル
 * @author 
 */
@WebServlet(name="S015", urlPatterns={"/servlet/S015", "/servlet/S015/*"})
public class S015Servlet extends AbstractServlet {

    private static final String INDEX_JSP = "S015/attachment.jsp";
    
    @Inject
    private S015Bean s015Bean;

    @Inject
    private S015Service s015Service;
    
    @Inject
    private ValidationMessageBean validationMessageBean;
    
    /**
     * 初期表示
     * @param req
     * @param resp
     * @return
     * @throws Exception 
     */
    public String indexAction(HttpServletRequest req, HttpServletResponse resp)
    throws Exception {
        // リクエストパラメータをS015Beanの同名フィールドに一括コピー
        ParameterBinder.Bind(s015Bean, req);
        
//        // この画面は履歴関係ないため、履歴idは常に最新(0)を用いる。
//        s015Bean.setRirekiId(ConstantString.geRirekiId);
//        s015Bean.setRirekiFlg("");
        
        // サービスの実行(トランザクションの単位にもなる)
        s015Service.indexExecute();

        return INDEX_JSP;
    }

    /**
     * 添付ファイル保存処理
     * @param req
     * @param resp
     * @return
     * @throws Exception 
     */
    public String saveAction(HttpServletRequest req, HttpServletResponse resp) throws Exception {
        // リクエストパラメータをS015Beanの同名フィールドに一括コピー
        ParameterBinder.Bind(s015Bean, req);

        // バリデーションチェック
        if (!s015Service.validation()) {
            // 入力エラーが存在する場合はエラー情報を返す
            resopnseDecodeJson(resp, validationMessageBean.errorJsonInfo());
        } else {
            s015Service.saveExecute();
        }
        
        return null;
    }
    
    /**
     * 指定添付ファイルをダウンロード
     * @param req
     * @param resp
     * @return
     * @throws Exception 
     */
    public String downloadAttachmentAction(HttpServletRequest req, HttpServletResponse resp)
    throws Exception {
        // パラメータを取得
        ParameterBinder.Bind(s015Bean, req);

        // 添付資料の取得(サービス実行)
        s015Service.getAttachmentFileExecute();
        
        // 添付ファイルをダウンロード
        FileUtils.httpDownloadResponse(s015Bean.getAttFileFullPath(), s015Bean.getAttFileName(), resp);
        
        return null;
    }

}
