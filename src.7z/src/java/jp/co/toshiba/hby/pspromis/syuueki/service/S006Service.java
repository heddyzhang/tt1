package jp.co.toshiba.hby.pspromis.syuueki.service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.ejb.Stateless;
import javax.inject.Inject;
import javax.interceptor.Interceptors;
import jp.co.toshiba.hby.pspromis.common.exception.PspRunTimeExceotion;
import jp.co.toshiba.hby.pspromis.syuueki.bean.S006Bean;
import jp.co.toshiba.hby.pspromis.syuueki.entity.SyuGeBukkenInfoTbl;
import jp.co.toshiba.hby.pspromis.syuueki.entity.SyuGeRirekiInfoTbl;
import jp.co.toshiba.hby.pspromis.syuueki.enums.Label;
import jp.co.toshiba.hby.pspromis.syuueki.facade.SyuGeBukenInfoTblFacade;
import jp.co.toshiba.hby.pspromis.syuueki.facade.SyuGeRirekiInfoTblFacade;
import jp.co.toshiba.hby.pspromis.syuueki.interceptor.TranceInterceptor;
import jp.co.toshiba.hby.pspromis.syuueki.util.ConstantString;
//import static jp.co.toshiba.hby.pspromis.syuueki.service.S016Service.log;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * PS-Promis収益管理システム
 * 履歴検索 Service
 * @author (NPC)T.Wakamatsu
 */
@Stateless
@Interceptors({TranceInterceptor.class})
public class S006Service {

    /**
     * ロガー
     */
    public static final Logger logger = LoggerFactory.getLogger(S006Service.class);

    /**
     * パラメータ格納クラスをinjection(CDI)<br>
     * InjectアノテーションよりAPサーバー(Glassfish)側で自動的にインスタンス作成(new)される。<br>
     */
    @Inject
    private S006Bean s006Bean;
    
    @Inject
    private SyuGeRirekiInfoTblFacade syuGeRirekiInfoTblFacade;

    @Inject
    private SyuGeBukenInfoTblFacade syuGeBukenInfoTblFacade;
    
    /**
     * 画面表示　ビジネスロジック
     * @throws Exception 
     */
    public void indexExecute() throws Exception {
        setGeAnkenInfo();
        rirekiListExecute();
    }
    
    /**
     * 履歴データ取得
     * @throws Exception 
     */
    public void rirekiListExecute() throws Exception {
        Map<String, Object> paramMap = new HashMap<>();
        paramMap.put("ankenId", s006Bean.getAnkenId());
        
        // 履歴データ取得
        List<SyuGeRirekiInfoTbl> rirekiList = syuGeRirekiInfoTblFacade.getList(paramMap);
        
        // 取得データをbeanにセット
        s006Bean.setRirekiList(rirekiList);
    }
    
    /**
     * 案件の基本情報を取得
     */
    private void setGeAnkenInfo() {
        Map<String, Object> condition = getBaseCondition();
        SyuGeBukkenInfoTbl geEntity = syuGeBukenInfoTblFacade.findPk(condition);
        if (geEntity == null) {
            String errorMessage = Label.errorNoAnkenDate.getLabel();
            logger.error(errorMessage + " ankenId=" + s006Bean.getAnkenId() + " rirekiId=" + ConstantString.geRirekiId);
            throw new PspRunTimeExceotion(errorMessage);
        }
        
        s006Bean.setDivisionCode(StringUtils.defaultString(geEntity.getDivisionCode()));
    }
    
    /**
     * ベースの条件を作成
     */
    private Map<String, Object> getBaseCondition() {
        Map<String, Object> condition = new HashMap<>();
        condition.put("ankenId", s006Bean.getAnkenId());
        condition.put("rirekiId", Integer.parseInt(ConstantString.geRirekiId));
        return condition;
    }
    
}
