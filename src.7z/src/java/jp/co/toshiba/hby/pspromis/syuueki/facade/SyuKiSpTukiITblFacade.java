package jp.co.toshiba.hby.pspromis.syuueki.facade;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.interceptor.Interceptors;
import javax.ejb.Stateless;
import javax.inject.Inject;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import jp.co.toshiba.hby.pspromis.syuueki.entity.SyuKiSpTukiITbl;
import jp.co.toshiba.hby.pspromis.syuueki.entity.StringEntity;
import jp.co.toshiba.hby.pspromis.syuueki.interceptor.TranceInterceptor;
import jp.co.toshiba.hby.pspromis.syuueki.util.LoginUserInfo;
import org.apache.commons.collections.CollectionUtils;
//import org.apache.commons.beanutils.BeanUtils;

/**
 *
 * @author ibayashi
 */
@Stateless
@Interceptors({TranceInterceptor.class})
public class SyuKiSpTukiITblFacade extends AbstractFacade<SyuKiSpTukiITbl> {
    @PersistenceContext(unitName = jp.co.toshiba.hby.pspromis.syuueki.util.ConstantString.syuuekiDataSourceName)
    private EntityManager em;

    @Override
    protected EntityManager getEntityManager() {
        return em;
    }

    public SyuKiSpTukiITblFacade() {
        super(SyuKiSpTukiITbl.class);
    }
    
    @Inject
    private LoginUserInfo loginUserInfo;
    
    /**
     * パラメータにログイン者idをセット
     */
    private Map<String, Object> addParamLoginId(Map<String, Object> _params) {
        Map<String, Object> ret = _params;
        if (ret == null) {
            ret = new HashMap<>();
        }
        ret.put("userId", loginUserInfo.getUserId());
        return ret;
    }

    /**
     * 期間損益・月別詳細(一般) 削除
     * @param _params
     * @return 
     */
    public int deleteSyuKiSpTukiITbl(Map<String, Object> _params) {
        int count= sqlExecutor.executeUpdateSql(em, "/sql/syuKiSpTukiITbl/deleteSyuKiSpTukiITbl.sql", _params);
        return count;
    }
    
    /**
     * 期間損益・月別詳細(一般) (更新/新規登録)
     * @param _params
     * @return 
     */
    public int entrySyuKiSpTukiITbl(Map<String, Object> _params) throws Exception {
        return entrySyuKiSpTukiITbl(_params, false);
    }
    
    /**
     * 期間損益・月別詳細(一般) (更新/新規登録)
     * @param _params
     * @param isForceEntryFlg SPが未登録(null)でも強制的にレコードを作成するFLG
     */
    public int entrySyuKiSpTukiITbl(Map<String, Object> _params, boolean isForceEntryFlg) throws Exception {
        int count;
        Object amount = _params.get("uriageAmount");   // 売上SP

        // 更新
        count = this.updateSyuKiSpTukiITbl(_params);
        // 更新データ存在しない場合は新規登録
        if (count == 0 && (amount != null || isForceEntryFlg)) {
            count = this.insertSyuKiSpTukiITbl(_params);
        }
        
        // 画面から入力したSPが存在しない場合は削除 2017/11/21 add
        if (amount == null && !isForceEntryFlg) {
            this.deleteSyuKiSpTukiITbl(_params);
            count = 0;
        }

        return count;
    }
    
    /**
     * 期間損益・月別詳細(一般) 登録
     * @param _params
     * @return 
     */
    public int insertSyuKiSpTukiITbl(Map<String, Object> _params) throws Exception {
        Map<String, Object> params = addParamLoginId(_params);
        int count = sqlExecutor.executeUpdateSql(em, "/sql/syuKiSpTukiITbl/insertSyuKiSpTukiITbl.sql", params);
        return count;
    }
    
    /**
     * 期間損益・月別詳細(一般) 更新
     * @param _params
     * @return 
     */
    public int updateSyuKiSpTukiITbl(Map<String, Object> _params) throws Exception {
        Map<String, Object> params = addParamLoginId(_params);
        int count = sqlExecutor.executeUpdateSql(em, "/sql/syuKiSpTukiITbl/updateSyuKiSpTukiITbl.sql", _params);
        return count;
    }

    /**
     * 最新の年月を取得
     * @param params
     * @return 
     */
    public String getMaxSyuekiYm(Map<String, Object> params){
        List<StringEntity> list = sqlExecutor.getResultList(em, StringEntity.class, "/sql/syuKiSpTukiITbl/selectMaxSyuekiYm.sql", params);
        
        if (CollectionUtils.isNotEmpty(list)) {
            return list.get(0).getString().trim();
        } else {
            return "";
        }
    }

    /**
     * 売上年月の更新
     * @param _params
     */
    public int changeSyuekiYm(Map<String, Object> _params){
        Map<String, Object> params = addParamLoginId(_params);
        int count = sqlExecutor.executeUpdateSql(em, "/sql/syuKiSpTukiITbl/changeSyuekiYm.sql", params);
        return count;
    }

}
