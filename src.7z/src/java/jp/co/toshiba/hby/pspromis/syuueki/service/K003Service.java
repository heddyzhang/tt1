package jp.co.toshiba.hby.pspromis.syuueki.service;

import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.ejb.Stateless;
import javax.inject.Inject;
import javax.interceptor.Interceptors;
import jp.co.toshiba.hby.pspromis.syuueki.bean.K003Bean;
import jp.co.toshiba.hby.pspromis.syuueki.entity.PlantMst;
import jp.co.toshiba.hby.pspromis.syuueki.facade.PlantMstFacade;
import jp.co.toshiba.hby.pspromis.syuueki.interceptor.TranceInterceptor;
import jp.co.toshiba.hby.pspromis.syuueki.util.LoginUserInfo;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * PS-Promis収益管理システム
 * プラントコード選択 Service
 * @author (NPC)S.horie
 */
@Stateless
@Interceptors({TranceInterceptor.class})
public class K003Service {
    
    public static final Logger logger = LoggerFactory.getLogger(K003Service.class);
    
    @Inject
    private K003Bean k003Bean;

    @Inject
    private LoginUserInfo loginUserInfo;

    @Inject
    private PlantMstFacade plantMstFacade;

    /**
     * 検索条件用Mapを作成
     */
    private Map getCondition() {
        Map<String, Object> condition = new HashMap<>();

        // 事業部
        if (k003Bean.getDivisionCode() != null) {
            condition.put("division", Arrays.asList(k003Bean.getDivisionCode()));
        }
        // プラントコード
        condition.put("plantCode", k003Bean.getPlantCode());
        
        return condition;
    }
    
    /**
     * 初期表示時機能
     * @throws Exception
     */
    public void indexExecute() throws Exception {
        searchExecute();
    }
    
    /**
     * 検索機能
     * @throws Exception
     */
    public void searchExecute() throws Exception {
        // ページ切り替えか否かを判定
        boolean isPageing = true;
        if (k003Bean.getPage() == null || k003Bean.getPage() <= 0) {
            isPageing = false;
            k003Bean.setPage(1);
        }

        // 事業部が選択されていない場合
        if (k003Bean.getDivisionCode() == null) {
            // ログイン者の事業部を強制セット
            k003Bean.setDivisionCode(loginUserInfo.getJobGrSyokusyuArrayInfo("division"));
        }

        // 検索条件をセット
        Map condition = getCondition();
      
        if (!isPageing) {
            // 検索ボタン
            condition.put("listFlg", "1");
            getListCount(condition);
        }

       if (k003Bean.getCount() > 0) {
           plantListExecute(condition);
       }
    }

    /**
     * プラントデータ一覧取得
     * @param condition
     * @throws Exception 
     */
    public void plantListExecute(Map condition) throws Exception {
        // STCH一覧データ取得
        condition.put("listFlg", "0");
        List<PlantMst> plantList = plantMstFacade.getList(condition, k003Bean.getPage());

        // 取得データをbeanにセット
        k003Bean.setPlantList(plantList);
    }

    /**
     * 一覧データの件数を取得
     * @param condition
     * @throws Exception
     */
    public void getListCount(Map condition) throws Exception {
        // 一覧データ件数を取得
        Integer count = plantMstFacade.getCount(condition);

        // 取得データをbeanにセット
        k003Bean.setCount(count);
    }
    
}
