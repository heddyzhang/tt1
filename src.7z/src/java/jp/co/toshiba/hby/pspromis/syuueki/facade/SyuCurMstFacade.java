package jp.co.toshiba.hby.pspromis.syuueki.facade;

import java.util.Map;
import java.util.HashMap;
import java.util.List;
import javax.ejb.Stateless;
import javax.interceptor.Interceptors;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import jp.co.toshiba.hby.pspromis.syuueki.entity.SyuCurMst;
import jp.co.toshiba.hby.pspromis.syuueki.interceptor.TranceInterceptor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 *
 * @author horie
 */
@Stateless
@Interceptors({TranceInterceptor.class})
public class SyuCurMstFacade extends AbstractFacade<SyuCurMst> {
    /**
     * ロガ－
     */
    private static final Logger logger = LoggerFactory.getLogger(SyuCurMstFacade.class);

    @PersistenceContext(unitName = jp.co.toshiba.hby.pspromis.syuueki.util.ConstantString.syuuekiDataSourceName)
    private EntityManager em;

    @Override
    protected EntityManager getEntityManager() {
        return em;
    }

    public SyuCurMstFacade() {
        super(SyuCurMst.class);
    }

    /**
     * 通貨マスタを取得
     * @return 
     */
    @Override
    public List<SyuCurMst> findAll() {
       logger.info("SyuCurMstFacade#findAll");

       List<SyuCurMst> list
                = sqlExecutor.getResultList(em, SyuCurMst.class, "/sql/selectSyuCurMst.sql", null);
       
       return list;
    }

    /**
     * 指定通貨
     * @return 
     */
    public SyuCurMst findPk(String currencyCode) {
       logger.info("SyuCurMstFacade#findPk");

       SyuCurMst condition = new SyuCurMst();
       condition.setCurrencyCode(currencyCode);
       
       SyuCurMst entity
                = sqlExecutor.getSingleResult(em, SyuCurMst.class, "/sql/syuCurMst/selectSyuCurMst.sql", condition);
       
       return entity;
    }
    
    /**
     * 案件ごとの通貨リストを取得
     * @return 
     */
    public List<SyuCurMst> findByAnken(String ankenId, Integer rirekiId) {
       logger.info("SyuCurMstFacade#findByAnken");

       Map<String, Object> condition = new HashMap<>();
       condition.put("ankenId", ankenId);
       condition.put("rirekiId", rirekiId);
       
       List<SyuCurMst> list
                = sqlExecutor.getResultList(em, SyuCurMst.class, "/sql/syuCurMst/selectSyuCurMstByAnken.sql", condition);
       
       return list;
    }
    
    
}
