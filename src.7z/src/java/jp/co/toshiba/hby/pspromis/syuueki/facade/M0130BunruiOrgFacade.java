package jp.co.toshiba.hby.pspromis.syuueki.facade;

import java.util.List;
import javax.ejb.Stateless;
import javax.interceptor.Interceptors;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import jp.co.toshiba.hby.pspromis.syuueki.entity.M0130BunruiOrg;
import jp.co.toshiba.hby.pspromis.syuueki.interceptor.TranceInterceptor;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 *
 * @author ibayashi
 */
@Stateless
@Interceptors({TranceInterceptor.class})
public class M0130BunruiOrgFacade extends AbstractFacade<M0130BunruiOrg> {

    private static final Logger logger = LoggerFactory.getLogger(M0130BunruiOrgFacade.class);

    @PersistenceContext(unitName = jp.co.toshiba.hby.pspromis.syuueki.util.ConstantString.syuuekiDataSourceName)
    private EntityManager em;

    @Override
    protected EntityManager getEntityManager() {
        return em;
    }

    public M0130BunruiOrgFacade() {
        super(M0130BunruiOrg.class);
    }

    /**
     * 分類マスタの一覧を取得
     *
     * @param condition
     * @return
     */
    public List<M0130BunruiOrg> getList(Object condition) {
        logger.info("M0130BunruiOrgFacade#getList");

        List<M0130BunruiOrg> list = sqlExecutor.getResultList(em, M0130BunruiOrg.class, "/sql/bunruiMst/selectBunruiMst.sql", condition);

        return list;
    }

    /**
     * 分類名称を取得
     *
     * @param condition
     * @return
     */
    public String selectBunruiNm(Object condition) {
        logger.info("M0130BunruiOrgFacade#selectBunruiNm");

        String bunruiNm = "";
        List<M0130BunruiOrg> list
                = sqlExecutor.getResultList(em, M0130BunruiOrg.class, "/sql/bunruiMst/selectBunruiNm.sql", condition);

        if (CollectionUtils.isNotEmpty(list)) {
            bunruiNm = StringUtils.defaultString(list.get(0).getBunruiNm());
        }

        return bunruiNm;
    }
}
