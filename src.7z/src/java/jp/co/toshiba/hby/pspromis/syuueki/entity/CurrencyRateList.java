package jp.co.toshiba.hby.pspromis.syuueki.entity;

import java.io.Serializable;
import java.math.BigDecimal;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.validation.constraints.NotNull;

/**
 *
 * @author sano
 */
@Entity
public class CurrencyRateList implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @NotNull
    @Column(name = "ANKEN_ID")
    private String ankenId;
    @Id
    @Column(name = "CURRENCY_CODE")
    private String currencyCode;
    @Column(name = "KEIYAKU_RATE_JS")
    private BigDecimal keiyakuRateJs;
    @Column(name = "KEIYAKU_RATE_JT")
    private BigDecimal keiyakuRateJt;
    @Column(name = "KEIYAKU_RATE_MH")
    private BigDecimal keiyakuRateMh;
    @Column(name = "KEIYAKU_RATE_SM")
    private BigDecimal keiyakuRateSm;
    @Column(name = "KEIYAKU_RATE_ST")
    private BigDecimal keiyakuRateSt;
    @Column(name = "KEIYAKU_RATE_HB")
    private BigDecimal keiyakuRateHb;
    @Column(name = "KEIYAKU_RATE_TR")
    private BigDecimal keiyakuRateTr;
    @Column(name = "KEIYAKU_RATE_FM")
    private BigDecimal keiyakuRateFm;
    @Column(name = "KEIYAKU_RATE_DIFF")
    private BigDecimal keiyakuRateDiff;
    @Column(name = "KEIYAKU_RATE_PD")
    private BigDecimal keiyakuRatePd;
    @Column(name = "KEIYAKU_RATE_PT")
    private BigDecimal keiyakuRatePt;
    @Column(name = "KEIYAKU_RATE_PS")
    private BigDecimal keiyakuRatePs;
    @Column(name = "KEIYAKU_RATE_PREV")
    private BigDecimal keiyakuRatePrev;
    @Column(name = "KEIYAKU_AMOUNT_JS")
    private BigDecimal keiyakuAmountJs;
    @Column(name = "KEIYAKU_AMOUNT_JT")
    private BigDecimal keiyakuAmountJt;
    @Column(name = "KEIYAKU_AMOUNT_MH")
    private BigDecimal keiyakuAmountMh;
    @Column(name = "KEIYAKU_AMOUNT_SM")
    private BigDecimal keiyakuAmountSm;
    @Column(name = "KEIYAKU_AMOUNT_ST")
    private BigDecimal keiyakuAmountSt;
    @Column(name = "KEIYAKU_AMOUNT_HB")
    private BigDecimal keiyakuAmountHb;
    @Column(name = "KEIYAKU_AMOUNT_TR")
    private BigDecimal keiyakuAmountTr;
    @Column(name = "KEIYAKU_AMOUNT_FM")
    private BigDecimal keiyakuAmountFm;
    @Column(name = "KEIYAKU_AMOUNT_DIFF")
    private BigDecimal keiyakuAmountDiff;
    @Column(name = "KEIYAKU_AMOUNT_PD")
    private BigDecimal keiyakuAmountPd;
    @Column(name = "KEIYAKU_AMOUNT_PT")
    private BigDecimal keiyakuAmountPt;
    @Column(name = "KEIYAKU_AMOUNT_PS")
    private BigDecimal keiyakuAmountPs;
    @Column(name = "KEIYAKU_AMOUNT_PREV")
    private BigDecimal keiyakuAmountPrev;

    public CurrencyRateList() {
    }

    public String getAnkenId() {
        return ankenId;
    }

    public void setAnkenId(String ankenId) {
        this.ankenId = ankenId;
    }

    public String getCurrencyCode() {
        return currencyCode;
    }

    public void setCurrencyCode(String currencyCode) {
        this.currencyCode = currencyCode;
    }

    public BigDecimal getKeiyakuRateJs() {
        return keiyakuRateJs;
    }

    public void setKeiyakuRateJs(BigDecimal keiyakuRateJs) {
        this.keiyakuRateJs = keiyakuRateJs;
    }

    public BigDecimal getKeiyakuRateJt() {
        return keiyakuRateJt;
    }

    public void setKeiyakuRateJt(BigDecimal keiyakuRateJt) {
        this.keiyakuRateJt = keiyakuRateJt;
    }

    public BigDecimal getKeiyakuRateMh() {
        return keiyakuRateMh;
    }

    public void setKeiyakuRateMh(BigDecimal keiyakuRateMh) {
        this.keiyakuRateMh = keiyakuRateMh;
    }

    public BigDecimal getKeiyakuRateSm() {
        return keiyakuRateSm;
    }

    public void setKeiyakuRateSm(BigDecimal keiyakuRateSm) {
        this.keiyakuRateSm = keiyakuRateSm;
    }

    public BigDecimal getKeiyakuRateSt() {
        return keiyakuRateSt;
    }

    public void setKeiyakuRateSt(BigDecimal keiyakuRateSt) {
        this.keiyakuRateSt = keiyakuRateSt;
    }

    public BigDecimal getKeiyakuRateHb() {
        return keiyakuRateHb;
    }

    public void setKeiyakuRateHb(BigDecimal keiyakuRateHb) {
        this.keiyakuRateHb = keiyakuRateHb;
    }

    public BigDecimal getKeiyakuRateTr() {
        return keiyakuRateTr;
    }

    public void setKeiyakuRateTr(BigDecimal keiyakuRateTr) {
        this.keiyakuRateTr = keiyakuRateTr;
    }

    public BigDecimal getKeiyakuRateFm() {
        return keiyakuRateFm;
    }

    public void setKeiyakuRateFm(BigDecimal keiyakuRateFm) {
        this.keiyakuRateFm = keiyakuRateFm;
    }

    public BigDecimal getKeiyakuRateDiff() {
        return keiyakuRateDiff;
    }

    public void setKeiyakuRateDiff(BigDecimal keiyakuRateDiff) {
        this.keiyakuRateDiff = keiyakuRateDiff;
    }

    public BigDecimal getKeiyakuRatePd() {
        return keiyakuRatePd;
    }

    public void setKeiyakuRatePd(BigDecimal keiyakuRatePd) {
        this.keiyakuRatePd = keiyakuRatePd;
    }

    public BigDecimal getKeiyakuRatePt() {
        return keiyakuRatePt;
    }

    public void setKeiyakuRatePt(BigDecimal keiyakuRatePt) {
        this.keiyakuRatePt = keiyakuRatePt;
    }

    public BigDecimal getKeiyakuRatePs() {
        return keiyakuRatePs;
    }

    public void setKeiyakuRatePs(BigDecimal keiyakuRatePs) {
        this.keiyakuRatePs = keiyakuRatePs;
    }

    public BigDecimal getKeiyakuAmountJs() {
        return keiyakuAmountJs;
    }

    public void setKeiyakuAmountJs(BigDecimal keiyakuAmountJs) {
        this.keiyakuAmountJs = keiyakuAmountJs;
    }

    public BigDecimal getKeiyakuAmountJt() {
        return keiyakuAmountJt;
    }

    public void setKeiyakuAmountJt(BigDecimal keiyakuAmountJt) {
        this.keiyakuAmountJt = keiyakuAmountJt;
    }

    public BigDecimal getKeiyakuAmountMh() {
        return keiyakuAmountMh;
    }

    public void setKeiyakuAmountMh(BigDecimal keiyakuAmountMh) {
        this.keiyakuAmountMh = keiyakuAmountMh;
    }

    public BigDecimal getKeiyakuAmountSm() {
        return keiyakuAmountSm;
    }

    public void setKeiyakuAmountSm(BigDecimal keiyakuAmountSm) {
        this.keiyakuAmountSm = keiyakuAmountSm;
    }

    public BigDecimal getKeiyakuAmountSt() {
        return keiyakuAmountSt;
    }

    public void setKeiyakuAmountSt(BigDecimal keiyakuAmountSt) {
        this.keiyakuAmountSt = keiyakuAmountSt;
    }

    public BigDecimal getKeiyakuAmountHb() {
        return keiyakuAmountHb;
    }

    public void setKeiyakuAmountHb(BigDecimal keiyakuAmountHb) {
        this.keiyakuAmountHb = keiyakuAmountHb;
    }

    public BigDecimal getKeiyakuAmountTr() {
        return keiyakuAmountTr;
    }

    public void setKeiyakuAmountTr(BigDecimal keiyakuAmountTr) {
        this.keiyakuAmountTr = keiyakuAmountTr;
    }

    public BigDecimal getKeiyakuAmountFm() {
        return keiyakuAmountFm;
    }

    public void setKeiyakuAmountFm(BigDecimal keiyakuAmountFm) {
        this.keiyakuAmountFm = keiyakuAmountFm;
    }

    public BigDecimal getKeiyakuAmountDiff() {
        return keiyakuAmountDiff;
    }

    public void setKeiyakuAmountDiff(BigDecimal keiyakuAmountDiff) {
        this.keiyakuAmountDiff = keiyakuAmountDiff;
    }

    public BigDecimal getKeiyakuAmountPd() {
        return keiyakuAmountPd;
    }

    public void setKeiyakuAmountPd(BigDecimal keiyakuAmountPd) {
        this.keiyakuAmountPd = keiyakuAmountPd;
    }

    public BigDecimal getKeiyakuAmountPt() {
        return keiyakuAmountPt;
    }

    public void setKeiyakuAmountPt(BigDecimal keiyakuAmountPt) {
        this.keiyakuAmountPt = keiyakuAmountPt;
    }

    public BigDecimal getKeiyakuAmountPs() {
        return keiyakuAmountPs;
    }

    public void setKeiyakuAmountPs(BigDecimal keiyakuAmountPs) {
        this.keiyakuAmountPs = keiyakuAmountPs;
    }

    public BigDecimal getKeiyakuAmountPrev() {
        return keiyakuAmountPrev;
    }

    public void setKeiyakuAmountPrev(BigDecimal keiyakuAmountPrev) {
        this.keiyakuAmountPrev = keiyakuAmountPrev;
    }

    public BigDecimal getKeiyakuRatePrev() {
        return keiyakuRatePrev;
    }

    public void setKeiyakuRatePrev(BigDecimal keiyakuRatePrev) {
        this.keiyakuRatePrev = keiyakuRatePrev;
    }
}
