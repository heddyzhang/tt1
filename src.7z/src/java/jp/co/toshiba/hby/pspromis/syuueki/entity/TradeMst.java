package jp.co.toshiba.hby.pspromis.syuueki.entity;

import java.io.Serializable;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 *
 * @author ibayashi
 */
@Entity
@Table(name = "ES86031")
public class TradeMst implements Serializable {

    @Id
    @Column(name = "TRADE_CD")
    private String tradeCd;

    @Column(name = "TRADE_NM")
    private String tradeNm;

    public TradeMst() {
    }

    public String getTradeCd() {
        return tradeCd;
    }

    public void setTradeCd(String tradeCd) {
        this.tradeCd = tradeCd;
    }

    public String getTradeNm() {
        return tradeNm;
    }

    public void setTradeNm(String tradeNm) {
        this.tradeNm = tradeNm;
    }

}
