/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package jp.co.toshiba.hby.pspromis.syuueki.service;

import java.util.ArrayList;
//import java.util.Calendar;
//import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.ejb.Stateless;
import javax.inject.Inject;
import javax.interceptor.Interceptors;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import jp.co.toshiba.hby.pspromis.common.util.StringUtil;
import jp.co.toshiba.hby.pspromis.syuueki.entity.SyuGeBukkenInfoTbl;
import jp.co.toshiba.hby.pspromis.syuueki.facade.KanjyoMstFacade;
import jp.co.toshiba.hby.pspromis.syuueki.facade.SyuGeBukenInfoTblFacade;
import jp.co.toshiba.hby.pspromis.syuueki.interceptor.TranceInterceptor;
import jp.co.toshiba.hby.pspromis.syuueki.jdbc.DbUtilsExecutor;
import jp.co.toshiba.hby.pspromis.common.jdbc.SqlExecutor;
import jp.co.toshiba.hby.pspromis.syuueki.jdbc.SqlFile;
import jp.co.toshiba.hby.pspromis.syuueki.util.ConstantString;
import jp.co.toshiba.hby.pspromis.syuueki.util.SyuuekiUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 *
 * @author ibayashi
 */
@Stateless
@Interceptors({TranceInterceptor.class})
public class UriageRangeService {

    @PersistenceContext(unitName = jp.co.toshiba.hby.pspromis.syuueki.util.ConstantString.syuuekiDataSourceName)
    private EntityManager em;
    
    /**
     * ロガー
     */
    public static final Logger logger = LoggerFactory.getLogger(UriageRangeService.class);
    
    /**
     * Injection sqlExecutor
     */
    @Inject
    protected SqlExecutor sqlExecutor;
    
    /**
     * Injection dbUtilsExecutor
     */
    @Inject
    private DbUtilsExecutor dbUtilsExecutor;

    /**
     * Injection SyuGeBukenInfoTblFacade
     */
    @Inject
    private SyuGeBukenInfoTblFacade syuGeBukenInfoTblFacade;
    
    @Inject
    private KanjyoMstFacade kanjyoMstFacade;
    
    @Inject
    private SyuuekiUtils syuuekiUtils;

    /**
     * 現在の勘定年月を取得
     */
    private String getNowKanjoYm(SyuGeBukkenInfoTbl ankenEntity, String rirekiFlg) {
        String nowKanjoYm = "";
        if ("R".equals(rirekiFlg)) {
            nowKanjoYm = ankenEntity.getKanjoYm();
        } else {
            nowKanjoYm = kanjyoMstFacade.getNowKanjoDate(ankenEntity.getSalesClass());
        }
        return nowKanjoYm;
    }

    /**
     * PK情報Mapを作成
     */
    private Map<String, Object> getPkCondition(SyuGeBukkenInfoTbl ankenEntity, String rirekiFlg) {
        Map<String, Object> condition = new HashMap<>();
        condition.put("ankenId", ankenEntity.getAnkenId());
        condition.put("rirekiId", ankenEntity.getRirekiId());
        
        if (StringUtil.isEmpty(rirekiFlg)) {
            rirekiFlg = "";
        }
        condition.put("rirekiFlg", rirekiFlg);
        
        return condition;
    }

    /**
     * 物件key情報を取得
     */
    private List<String> getAnkenId(SyuGeBukkenInfoTbl ankenEntity, String rirekiFlg) {
        List<String> childAnkenList = null;
        
        Map<String, Object> condition = getPkCondition(ankenEntity, rirekiFlg);
        
        String ankenFlg = StringUtils.defaultString(ankenEntity.getAnkenFlg(), "0");

        if(ankenFlg.equals("1")){
            // 案件フラグが1の場合はまとめ案件のため、子案件を取得
            childAnkenList = syuGeBukenInfoTblFacade.findChildAnkenNo(condition);
        }
        
        if (childAnkenList == null || childAnkenList.isEmpty()) {
            childAnkenList = new ArrayList();
            childAnkenList.add(ankenEntity.getAnkenId());
        }

        return childAnkenList;
    }
    
    /**
     * 案件基本情報の売上予定(完売)年月を取得
     */
    private String getAnkenUriageEnd(SyuGeBukkenInfoTbl ankenEntity) {
        String uriageEndFlg = StringUtils.defaultString(ankenEntity.getUriageEndFlg(), "0");
        String uriageEnd;
        if ("2".equals(uriageEndFlg)) {
            // 完売している場合、完売月を利用
            uriageEnd = syuuekiUtils.exeFormatYm(ankenEntity.getUriageEndFin());
        } else {
            // 完売していない場合は売上予定年月を利用
            uriageEnd = syuuekiUtils.exeFormatYm(ankenEntity.getUriageEnd());
        }
        uriageEnd = StringUtils.replace(uriageEnd, "/", "");
        return uriageEnd;
    }
    
    /**
     * 進行基準の最新実績データを取得
     */
    private String getShinkoJissekiMaxYm(SyuGeBukkenInfoTbl ankenEntity, Map<String, Object> condition) throws Exception {
        String sqlFilePath = "/sql/uriageRange/selectMaxUriage.sql";
        Map<String, Object> minCondition = new HashMap<>();
        minCondition.put("ankenId", ankenEntity.getAnkenId());
        minCondition.put("rirekiId", condition.get("rirekiId"));
        minCondition.put("rirekiFlg", condition.get("rirekiFlg"));
        minCondition.put("addMonth", condition.get("addMonth"));
        // 回収情報(見込込)も参照するために勘定月もSQLパラメータとして渡す。
        // (電力ジ)では、完売後に回収が上がるのが数年後になる可能性があるらしく、その分を展開できるようにしておく必要があるため回収見込含めて参照する
        minCondition.put("kanjyoYm", condition.get("kanjyoYm"));
        
        SqlFile sqlFile = new SqlFile();
        String sql = sqlFile.getSqlString(sqlFilePath, minCondition);
        Object[] params = sqlFile.getSqlParams(sqlFilePath, minCondition);
        
        // SQL実行
        List<Map<String, Object>> list = dbUtilsExecutor.dbUtilsGetSqlList(em, sql, params);
        String ym = (String) (list.get(0).get("SYUEKI_YM"));
        return ym;
    }

    /**
     * 進行基準の最新実績データを取得
     * →(2017/12/14)項番の見込月変更機能で、売上NETを実績を含む年月の範囲外に移動される可能性が発生したため、
     */
    private String getJissekiItemMaxYm(SyuGeBukkenInfoTbl ankenEntity, Map<String, Object> condition) throws Exception {
        String sqlFilePath = "/sql/uriageRange/selectMaxUriageItem.sql";
        Map<String, Object> minCondition = new HashMap<>();
        minCondition.put("ankenId", ankenEntity.getAnkenId());
        minCondition.put("childAnkenId", condition.get("ankenId"));
        minCondition.put("rirekiId", condition.get("rirekiId"));
        minCondition.put("rirekiFlg", condition.get("rirekiFlg"));
        
        SqlFile sqlFile = new SqlFile();
        String sql = sqlFile.getSqlString(sqlFilePath, minCondition);
        Object[] params = sqlFile.getSqlParams(sqlFilePath, minCondition);
        
        // SQL実行
        List<Map<String, Object>> list = dbUtilsExecutor.dbUtilsGetSqlList(em, sql, params);
        String ym = (String) (list.get(0).get("SYUEKI_YM"));
        return ym;
    }
    
    /**
     * 項番の最小実績年月を取得
     */
    private String getItemMinYm(Map<String, Object> condition) throws Exception {
        String ym = "";
        
        String sqlFilePath = "/sql/syuKiNetItemTukiTbl/selectMaxMinTuki.sql";
        Map<String, Object> minCondition = new HashMap<>();
        minCondition.put("ankenId", condition.get("ankenId"));
        minCondition.put("rirekiId", condition.get("rirekiId"));
        minCondition.put("rirekiFlg", condition.get("rirekiFlg"));
        minCondition.put("ymKbn", "MIN");

        List<String> dataKbn = new ArrayList();
        dataKbn.add("J");
        minCondition.put("dataKbn", dataKbn);

        // SQLを取得
        SqlFile sqlFile = new SqlFile();
        String sql = sqlFile.getSqlString(sqlFilePath, minCondition);
        Object[] params = sqlFile.getSqlParams(sqlFilePath, minCondition);

        // SQL実行
        List<Map<String, Object>> list = dbUtilsExecutor.dbUtilsGetSqlList(em, sql, params);
        
        if (list != null && list.size() > 0) {
            ym = (String) (list.get(0).get("SYUEKI_YM"));
        }
        
        return ym;
    }

    /**
     * 項番の実績/見込がある最大年月を取得(勘定年月を基準にする)
     */
    private String getItemMaxYm(Map<String, Object> condition, String kanjyoYm) throws Exception {
        String ym = "";
        
        String sqlFilePath = "/sql/syuKiNetItemTukiTbl/selectMaxMinTuki.sql";
        Map<String, Object> maxCondition = new HashMap<>();
        maxCondition.put("ankenId", condition.get("ankenId"));
        maxCondition.put("rirekiId", condition.get("rirekiId"));
        maxCondition.put("rirekiFlg", condition.get("rirekiFlg"));
        maxCondition.put("ymKbn", "MAX");
        maxCondition.put("kanjyoYm", kanjyoYm);

//        List<String> dataKbn = new ArrayList();
//        dataKbn.add("J");
//        dataKbn.add("M");
//        maxCondition.put("dataKbn", dataKbn);

        // SQLを取得
        SqlFile sqlFile = new SqlFile();
        String sql = sqlFile.getSqlString(sqlFilePath, maxCondition);
        Object[] params = sqlFile.getSqlParams(sqlFilePath, maxCondition);

        // SQL実行
        List<Map<String, Object>> list = dbUtilsExecutor.dbUtilsGetSqlList(em, sql, params);
        
        if (list != null && list.size() > 0) {
            ym = (String) (list.get(0).get("SYUEKI_YM"));
        }
        
        return ym;
    }

    /**
     * 対象物件の開始年月を取得(yyyyMM形式) ※[一般案件]用
     * @param ankenEntity
     * @param condition
     * @return 
     * @throws java.sql.SQLException 
     */
//    public String getStartYmI(SyuGeBukkenInfoTbl ankenEntity, Map<String, Object> condition) throws Exception {
//        String startYm;
//        String uriageEndFlg = StringUtils.defaultString(ankenEntity.getUriageEndFlg(), "0");
//        String rirekiFlg = StringUtils.defaultString((String)condition.get("rirekiFlg"));
//        
//        String kanjyoYm = getNowKanjoYm(ankenEntity, rirekiFlg);
//        
//        if ("0".equals(uriageEndFlg)) {
//            // 実績なしの場合
//            startYm = kanjyoYm;
//        } else {
//            // 実績ありの場合
//            startYm = StringUtils.defaultString(getItemMinYm(condition));
//            if (StringUtils.isEmpty(startYm)) {
//                startYm = kanjyoYm;
//            }
//        }
//        return startYm;
//    }

    /**
     * 対象物件の終了年月を取得(yyyyMM形式) ※[一般案件]用
     * @param ankenEntity
     * @param condition
     * @return 
     * @throws java.sql.SQLException
     */
    public String getEndYmI(SyuGeBukkenInfoTbl ankenEntity, Map<String, Object> condition) throws Exception {
        String endYm;
        String kanjyoYm = getNowKanjoYm(ankenEntity, (String)condition.get("rirekiFlg"));
        //String uriageEndStr = StringUtils.replace(syuuekiUtils.exeFormatYm(ankenEntity.getUriageEnd()), "/", "");
        String uriageEndStr = getAnkenUriageEnd(ankenEntity);

        // 項番の実績/見込がある最大年月を取得
        String itemMaxYm = StringUtils.defaultString(getItemMaxYm(condition, kanjyoYm));
        
        if (StringUtils.isEmpty(itemMaxYm) && StringUtils.isEmpty(uriageEndStr)) {
            return kanjyoYm;
        }
        if (StringUtils.isNotEmpty(itemMaxYm) && StringUtils.isEmpty(uriageEndStr)) {
            return itemMaxYm;
        }
        if (StringUtils.isEmpty(itemMaxYm) && StringUtils.isNotEmpty(uriageEndStr)) {
            return uriageEndStr;
        }

        if (uriageEndStr.compareTo(itemMaxYm) > 0) {
            // 項番売上月 < 売上予定月
            //endYm = itemMaxYm;
            endYm = uriageEndStr;
        } else {
            // 項番売上月 > 売上予定月
            //endYm = uriageEndStr;
            endYm = itemMaxYm;
        }

        return endYm;
    }

    /**
     * 対象物件の開始年月を取得(yyyyMM形式) ※[進行基準案件]用
     * @param ankenEntity
     * @param condition
     * @return 
     * @throws java.sql.SQLException 
     */
    public String getStartYm(SyuGeBukkenInfoTbl ankenEntity, Map<String, Object> condition) throws Exception {
        String startYm = "";
        
        // 項番の最小実績年月を取得
        String itemMinYm = StringUtils.defaultString(getItemMinYm(condition));

        // 売上開始年月を取得
        String uriageStartYm = syuuekiUtils.exeFormatYm(ankenEntity.getUriageStart());
        uriageStartYm = StringUtils.replace(uriageStartYm, "/", "");

        //候補月のうち、一番前の月を利用するように変更 2018/04/25 N.Naka
        // 当月勘定をとりあえずセット（必ずあるので）
        String rirekiFlg = (String) condition.get("rirekiFlg");
        startYm = getNowKanjoYm(ankenEntity, rirekiFlg);    
        //収益物件の売上開始年月が存在する場合に比較し、小さい方を利用
        if (StringUtils.isNotEmpty(uriageStartYm)) {
            if (startYm.compareTo(uriageStartYm) > 0) {
                startYm = uriageStartYm;
            }
        }
        //項番の最小実績月が存在する場合に比較し、小さい方を利用
        if (StringUtils.isNotEmpty(itemMinYm)) {
            if (startYm.compareTo(itemMinYm) > 0) {
                startYm = itemMinYm;
            }
        }

        return startYm;
    }

    /**
     * 対象物件の終了年月を取得(期間損益(進行基準))(yyyyMM形式)
     * @param ankenEntity
     * @param condition
     * @return getEndYmS
     * @throws java.sql.SQLException
     */
    private String getEndYmS(SyuGeBukkenInfoTbl ankenEntity, Map<String, Object> condition) throws Exception {
        // 現在の勘定年月を取得
        String rirekiFlg = (String)condition.get("rirekiFlg");
        String nowKanjoYm = getNowKanjoYm(ankenEntity, rirekiFlg);
        
        // 最新実績の売上年月を取得
        Map<String, Object> jissekiMaxCondition = new HashMap<>(condition);
        jissekiMaxCondition.put("kanjyoYm", nowKanjoYm);
        String endYm = this.getShinkoJissekiMaxYm(ankenEntity, jissekiMaxCondition);

        if (StringUtils.isEmpty(endYm)) {
            // 最新実績の売上年月が未登録なら、勘定月を設定
            endYm = nowKanjoYm;
        }

        return endYm;
    }
    
    /**
     * 対象物件の終了年月を取得(期間損益(進行基準))(yyyyMM形式)
     * @param ankenEntity
     * @param condition
     * @return 
     * @throws java.sql.SQLException
     */
    private String getEndYmItemS(SyuGeBukkenInfoTbl ankenEntity, Map<String, Object> condition, boolean kobanMikomiFlg) throws Exception {
        // 項番の最新実績の売上年月を取得
        String endYm = this.getJissekiItemMaxYm(ankenEntity, condition);

        // 現在の勘定年月を取得
        String rirekiFlg = (String) condition.get("rirekiFlg");
        String nowKanjoYm = getNowKanjoYm(ankenEntity, rirekiFlg);
        
        String maxEndItemYm = endYm;
        if (kobanMikomiFlg) {
            // 項番の見込を含む最新年月を取得(注入NETや製番損益の見込月も考慮した)
            maxEndItemYm = StringUtils.defaultString(getItemMaxYm(condition, nowKanjoYm));
        }

        if (StringUtils.isEmpty(endYm) && StringUtils.isEmpty(maxEndItemYm)) {
            // 最新実績の売上年月が未登録なら、勘定月を設定
            return nowKanjoYm;
        } else if (StringUtils.isNotEmpty(endYm) && StringUtils.isEmpty(maxEndItemYm)) {
            return endYm;
        } else if (StringUtils.isEmpty(endYm) && StringUtils.isNotEmpty(maxEndItemYm)) {
            return maxEndItemYm;
        }

        if (endYm.compareTo(maxEndItemYm) > 0) {
            // 最新実績の売上年月 > 項番の見込を含む最新年月
            return endYm;
        } else {
            // 最新実績の売上年月 < 項番の見込を含む最新年月
            return maxEndItemYm;
        }
    }
    
    /**
     * 対象物件の終了年月を取得(yyyyMM形式)
     * @param ankenEntity
     * @param condition
     * @return 
     * @throws java.sql.SQLException
     */
//    public String getEndYm(SyuGeBukkenInfoTbl ankenEntity, Map<String, Object> condition) throws Exception {
//        String endYm;
//        
//        if ("2".equals(ankenEntity.getUriageEndFlg()) && ankenEntity.getUriageEndFin() != null) {
//            //// 完売済(uriageEndFlg=2)の場合は完売日を取得
//            if(condition.containsKey("addYear")){
//                endYm = syuuekiUtils.exeFormatYm(addYear(ankenEntity.getUriageEndFin(), (int)condition.get("addYear")));
//            }else{
//                endYm = syuuekiUtils.exeFormatYm(ankenEntity.getUriageEndFin());
//            }
//        } else {
//            //// 完売していない場合
//            // 案件の売上予定年月を取得
//            String ankenUirageEnd;
//            if(condition.containsKey("addYear")){
//                ankenUirageEnd = syuuekiUtils.exeFormatYm(addYear(ankenEntity.getUriageEnd(), (int)condition.get("addYear")));
//            }else{
//                ankenUirageEnd = syuuekiUtils.exeFormatYm(ankenEntity.getUriageEnd());
//            }
//            
//            ankenUirageEnd = StringUtils.replace(ankenUirageEnd, "/", "");
//            
//            // 現在の勘定年月を取得
//            String rirekiFlg = (String) condition.get("rirekiFlg");
//            String nowKanjoYm = getNowKanjoYm(ankenEntity, rirekiFlg);
//            
//            if (StringUtils.isEmpty(ankenUirageEnd) || nowKanjoYm.compareTo(ankenUirageEnd) > 0) {
//                // 売上予定年月が未登録 or 勘定月 > 売上予定年月なら、勘定月を設定
//                endYm = nowKanjoYm;
//            } else {
//                endYm = ankenUirageEnd;
//            }
//        }
//
//        return endYm;
//    }
    
//    private Date addYear(Date date, int addYear){
//        Calendar cal = Calendar.getInstance();
//        cal.setTime(date);
//        cal.add(Calendar.YEAR, addYear);
//        return cal.getTime();
//    }

    /**
     * 売上開始・終了をMapで取得(項番一覧)<br>
     * 売上開始Key:URIAGE_START<br>
     * 売上終了Key:URIAGE_END
     * @param ankenEntity
     * @param rirekiFlg
     * @return 
     * @throws java.lang.Exception 
     */
    public Map<String, String> getUriageStartEndInfo(SyuGeBukkenInfoTbl ankenEntity, String rirekiFlg) throws Exception {
        List<String> getAnkenId = getAnkenId(ankenEntity, rirekiFlg);

        Map<String, Object> condition = getPkCondition(ankenEntity, rirekiFlg);
        condition.put("ankenId", getAnkenId);

        String start;
        String end;

        start = getStartYm(ankenEntity, condition);   // 項番の注入・製番損益も考慮して参照する必要があるため、開始年月は売上基準にかかわらず共通化する
        if (ConstantString.salesClassS.equals(ankenEntity.getSalesClass())) {
            // 進行基準案件
            //start = getStartYm(ankenEntity, condition);
            end = getEndYmItemS(ankenEntity, condition, true);

        } else {
            // 一般案件
            //start = getStartYmI(ankenEntity, condition);
            end = getEndYmI(ankenEntity, condition);
        }

        Map<String, String> result = new HashMap<>();
        result.put("URIAGE_START", start);
        result.put("URIAGE_END", end);
 
        return result;
    }
    
    /**
     * 売上開始・終了をMapで取得(期間損益(進行基準))<br>
     * 売上開始Key:URIAGE_START<br>
     * 売上終了Key:URIAGE_END
     * @param ankenEntity
     * @param rirekiFlg
     * @param addMonth
     * @return 
     * @throws java.lang.Exception 
     */
    public Map<String, String> getUriageStartEndInfoKikanShinko(SyuGeBukkenInfoTbl ankenEntity, String rirekiFlg, int addMonth) throws Exception {
        List<String> getAnkenId = getAnkenId(ankenEntity, rirekiFlg);

        Map<String, Object> condition = getPkCondition(ankenEntity, rirekiFlg);
        condition.put("ankenId", getAnkenId);
        condition.put("addMonth", addMonth);

        String start = getStartYm(ankenEntity, condition);
        String end = getEndYmS(ankenEntity, condition);

        Map<String, String> result = new HashMap<>();
        result.put("URIAGE_START", start);
        result.put("URIAGE_END", end);
 
        return result;
    }

    /**
     * 売上開始・終了をMapで取得(期間損益(進行基準) Excelダウンロード)<br>
     * 売上開始Key:URIAGE_START<br>
     * 売上終了Key:URIAGE_END
     * @param ankenEntity
     * @param rirekiFlg
     * @return 
     * @throws java.lang.Exception 
     */
    public Map<String, String> getUriageStartEndInfoKikanShinkoDownLoad(SyuGeBukkenInfoTbl ankenEntity, String rirekiFlg) throws Exception {
        List<String> getAnkenId = getAnkenId(ankenEntity, rirekiFlg);

        Map<String, Object> condition = getPkCondition(ankenEntity, rirekiFlg);
        condition.put("ankenId", getAnkenId);

        String start = getStartYm(ankenEntity, condition);
        String end = getEndYmItemS(ankenEntity, condition, false);

        Map<String, String> result = new HashMap<>();
        result.put("URIAGE_START", start);
        result.put("URIAGE_END", end);
 
        return result;
    }

}
