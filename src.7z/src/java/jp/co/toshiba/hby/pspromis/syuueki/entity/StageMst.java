/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package jp.co.toshiba.hby.pspromis.syuueki.entity;

import java.io.Serializable;
import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.Date;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

/**
 *
 * @author ibayashi
 */
@Entity
@Table(name = "STAGE_MST")
public class StageMst implements Serializable {
    private static final long serialVersionUID = 1L;
    @Id
    @Basic(optional = false)
    @NotNull
    @Column(name = "ID")
    private BigDecimal id;
    @Size(max = 2)
    @Column(name = "DIVISION_CODE")
    private String divisionCode;
    @Size(max = 40)
    @Column(name = "N8_STAGE_CODE")
    private String n8StageCode;
    @Size(max = 40)
    @Column(name = "STAGE_NAME")
    private String stageName;
    @Size(max = 40)
    @Column(name = "STAGE_NAME_ENG")
    private String stageNameEng;
    @Column(name = "SORT_ORDER")
    private BigInteger sortOrder;
    @Column(name = "CREATED_AT")
    @Temporal(TemporalType.TIMESTAMP)
    private Date createdAt;
    @Size(max = 8)
    @Column(name = "CREATED_BY")
    private String createdBy;
    @Column(name = "UPDATED_AT")
    @Temporal(TemporalType.TIMESTAMP)
    private Date updatedAt;
    @Size(max = 8)
    @Column(name = "UPDATED_BY")
    private String updatedBy;
    @Column(name = "DELETED_AT")
    @Temporal(TemporalType.TIMESTAMP)
    private Date deletedAt;
    @Size(max = 8)
    @Column(name = "DELETED_BY")
    private String deletedBy;
    @Basic(optional = false)
    @NotNull
    @Column(name = "IS_DELETED")
    private short isDeleted;

    public StageMst() {
    }

    public StageMst(BigDecimal id) {
        this.id = id;
    }

    public StageMst(BigDecimal id, short isDeleted) {
        this.id = id;
        this.isDeleted = isDeleted;
    }

    public BigDecimal getId() {
        return id;
    }

    public void setId(BigDecimal id) {
        this.id = id;
    }

    public String getDivisionCode() {
        return divisionCode;
    }

    public void setDivisionCode(String divisionCode) {
        this.divisionCode = divisionCode;
    }

    public String getN8StageCode() {
        return n8StageCode;
    }

    public void setN8StageCode(String n8StageCode) {
        this.n8StageCode = n8StageCode;
    }

    public String getStageName() {
        return stageName;
    }

    public void setStageName(String stageName) {
        this.stageName = stageName;
    }

    public String getStageNameEng() {
        return stageNameEng;
    }

    public void setStageNameEng(String stageNameEng) {
        this.stageNameEng = stageNameEng;
    }

    public BigInteger getSortOrder() {
        return sortOrder;
    }

    public void setSortOrder(BigInteger sortOrder) {
        this.sortOrder = sortOrder;
    }

    public Date getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(Date createdAt) {
        this.createdAt = createdAt;
    }

    public String getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    public Date getUpdatedAt() {
        return updatedAt;
    }

    public void setUpdatedAt(Date updatedAt) {
        this.updatedAt = updatedAt;
    }

    public String getUpdatedBy() {
        return updatedBy;
    }

    public void setUpdatedBy(String updatedBy) {
        this.updatedBy = updatedBy;
    }

    public Date getDeletedAt() {
        return deletedAt;
    }

    public void setDeletedAt(Date deletedAt) {
        this.deletedAt = deletedAt;
    }

    public String getDeletedBy() {
        return deletedBy;
    }

    public void setDeletedBy(String deletedBy) {
        this.deletedBy = deletedBy;
    }

    public short getIsDeleted() {
        return isDeleted;
    }

    public void setIsDeleted(short isDeleted) {
        this.isDeleted = isDeleted;
    }
    
}
