package jp.co.toshiba.hby.pspromis.syuueki.exception;

/**
 *
 * @author ibayashi
 */
public class NoSyuekiFlgException extends RuntimeException {
    
    private String orderNo;
    
    public NoSyuekiFlgException(String orderNo) {
        this.orderNo = orderNo;
    }

    public String getOrderNo() {
        return orderNo;
    }
}
