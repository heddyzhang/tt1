/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package jp.co.toshiba.hby.pspromis.syuueki.facade;

import javax.ejb.Stateless;
import javax.interceptor.Interceptors;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import jp.co.toshiba.hby.pspromis.syuueki.entity.SyuGeBookmarkTbl;
import jp.co.toshiba.hby.pspromis.syuueki.interceptor.TranceInterceptor;

/**
 *
 * @author ibayashi
 */
@Stateless
@Interceptors({TranceInterceptor.class})
public class SyuGeBookmarkTblFacade extends AbstractFacade<SyuGeBookmarkTbl> {
    @PersistenceContext(unitName = jp.co.toshiba.hby.pspromis.syuueki.util.ConstantString.syuuekiDataSourceName)
    private EntityManager em;

    @Override
    protected EntityManager getEntityManager() {
        return em;
    }

    public SyuGeBookmarkTblFacade() {
        super(SyuGeBookmarkTbl.class);
    }
    
    public Long getCount(String tuid, String ankenId) {
        Query q = em.createNamedQuery("BookMark.KeyCount");
        q.setParameter("idtuid", tuid);
        q.setParameter("ankenId", ankenId);
        return (Long)q.getSingleResult();
    }
}
