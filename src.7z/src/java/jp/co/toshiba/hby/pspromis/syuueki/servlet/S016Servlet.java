package jp.co.toshiba.hby.pspromis.syuueki.servlet;

import java.util.HashMap;
import java.util.Map;
import javax.inject.Inject;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpServletRequest;
import jp.co.toshiba.hby.pspromis.syuueki.bean.ResultMessageBean;
import jp.co.toshiba.hby.pspromis.syuueki.bean.S016Bean;
import jp.co.toshiba.hby.pspromis.syuueki.service.S016Service;
import jp.co.toshiba.hby.pspromis.syuueki.service.StoredProceduresService;
import jp.co.toshiba.hby.pspromis.syuueki.util.CdiUtils;
import jp.co.toshiba.hby.pspromis.syuueki.util.ParameterBinder;

/**
 * ES-Promis収益管理システム
 * 見込列複写
 * @author 
 */
@WebServlet(name="S016", urlPatterns={"/servlet/S016", "/servlet/S016/*"})
public class S016Servlet extends AbstractServlet {

    private static final String INDEX_JSP = "S016/mikomiCopy.jsp";
    
    @Inject
    private S016Bean s016Bean;

    @Inject
    private S016Service s016Service;
    
    @Inject
    private StoredProceduresService storedProceduresService;
    
    /**
     * 初期表示
     * @param req
     * @param resp
     * @return
     * @throws Exception 
     */
    public String indexAction(HttpServletRequest req, HttpServletResponse resp)
    throws Exception {
        // リクエストパラメータをS016Beanの同名フィールドに一括コピー
        ParameterBinder.Bind(s016Bean, req);
        
        // サービスの実行(トランザクションの単位にもなる)
        s016Service.indexExecute();

        return INDEX_JSP;
    }

    /**
     * 保存(実行)処理
     * @param req
     * @param resp
     * @return
     * @throws Exception 
     */
    public String saveAction(HttpServletRequest req, HttpServletResponse resp) throws Exception {
        // リクエストパラメータをS016Beanの同名フィールドに一括コピー
        ParameterBinder.Bind(s016Bean, req);

        s016Service.saveExecute();
        
        // (原子力)連携バッチを実行
        //storedProceduresService.callN7RenkeiBatchJudge(s016Bean.getAnkenId(), s016Bean.getRirekiId());
        
        // 処理結果を戻す。
        Map<String, Object> jsonMap = new HashMap<>();
        ResultMessageBean resultMessageBean = CdiUtils.getBean(ResultMessageBean.class);
        resultMessageBean.createResultMessage(jsonMap);
        resopnseDecodeJson(resp, jsonMap);

        return null;
    }

}
