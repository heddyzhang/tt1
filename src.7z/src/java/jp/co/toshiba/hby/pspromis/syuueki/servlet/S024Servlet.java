package jp.co.toshiba.hby.pspromis.syuueki.servlet;

import java.util.HashMap;
import java.util.Map;
import javax.inject.Inject;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.annotation.WebServlet;
import jp.co.toshiba.hby.pspromis.syuueki.bean.ResultMessageBean;
import jp.co.toshiba.hby.pspromis.syuueki.bean.S024Bean;
import jp.co.toshiba.hby.pspromis.syuueki.bean.ValidationMessageBean;
import jp.co.toshiba.hby.pspromis.syuueki.service.S024Service;
import jp.co.toshiba.hby.pspromis.syuueki.util.CdiUtils;
import jp.co.toshiba.hby.pspromis.syuueki.util.ParameterBinder;

/**
 *
 * @author ibayashi
 */
@WebServlet(name = "S024Servlet", urlPatterns = {"/servlet/S024", "/servlet/S024/*"})
public class S024Servlet extends AbstractServlet {
    
    private static final String INDEX_JSP = "S024/kaisyuEdit.jsp";
    
    @Inject
    private S024Bean s024Bean;

    @Inject
    private S024Service s024Service;
    
    @Inject
    private ValidationMessageBean validationMessageBean;
    
    /**
     * 初期表示
     * @param req
     * @param resp
     * @return
     * @throws Exception 
     */
    public String indexAction(HttpServletRequest req, HttpServletResponse resp)
    throws Exception {
        logger.info("S024Servlet#indexAction");

        ParameterBinder.Bind(s024Bean, req);
        
        s024Service.indexExecute();
        
        return INDEX_JSP;
    }
    
    /**
     * 保存(実行)処理
     * @param req
     * @param resp
     * @return
     * @throws Exception 
     */
    public String saveAction(HttpServletRequest req, HttpServletResponse resp) throws Exception {
        logger.info("S024Servlet#saveAction");
        
        ParameterBinder.Bind(s024Bean, req);

        if (s024Service.validation()) {
            s024Service.saveExecute();
            
            // 処理結果を戻す。
            Map<String, Object> jsonMap = new HashMap<>();
            ResultMessageBean resultMessageBean = CdiUtils.getBean(ResultMessageBean.class);
            resultMessageBean.createResultMessage(jsonMap);
            resopnseDecodeJson(resp, jsonMap);
            
        } else {
            resopnseDecodeJson(resp, validationMessageBean.errorJsonInfo());
        }
        
        return null;
    }
 
}
