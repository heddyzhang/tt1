package jp.co.toshiba.hby.pspromis.syuueki.servlet;

import java.util.HashMap;
import java.util.Map;
import javax.inject.Inject;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import jp.co.toshiba.hby.pspromis.syuueki.bean.ShirajiEditBean;
import jp.co.toshiba.hby.pspromis.syuueki.service.ShirajiEditService;
import jp.co.toshiba.hby.pspromis.syuueki.util.ParameterBinder;

/**
 * PS-Promis収益管理システム
 * 白地調整案件 取消/復活 Servlet
 * @author ibayashi
 */
@WebServlet(name = "ShirajiEdit", urlPatterns = {"/servlet/ShirajiEdit", "/servlet/ShirajiEdit/*"})
public class ShirajiEditServlet extends AbstractServlet {
    /**
     * パラメータ格納クラスをinjection(CDI)<br>
     */
    @Inject
    private ShirajiEditBean shirajiEditBean;

    /**
     * 使用serviceクラスをinjection(CDI)<br>
     */
    @Inject
    private ShirajiEditService shirajiEditService;


    /**
     * 白地調整案件 復活・取消 更新
     * @param req
     * @param resp
     * @return
     * @throws Exception 
     */
    public String updateAction(HttpServletRequest req, HttpServletResponse resp)
    throws Exception {
        logger.info("ShirajiEditServlet#updateAction");
        
        // リクエストパラメータをshirajiEditBeanの同名フィールドに一括コピー
        ParameterBinder.Bind(shirajiEditBean, req);

        // 更新処理を実行
        shirajiEditService.updateExecute();
        
        // 結果セットをjson出力
        Map<String, Object> jsonMap = new HashMap<>();
        jsonMap.put("shirajiDeleteFlg", shirajiEditBean.getDeleteFlg());
        resopnseDecodeJson(resp, jsonMap);

        // ここでは戻すjspが存在しないため、nullを返す。
        return null;
    }

}
