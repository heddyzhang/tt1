/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package jp.co.toshiba.hby.pspromis.syuueki.entity;

import java.io.Serializable;
import java.util.Date;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author horie
 */
@Entity
@Table(name = "SYU_GYOTAI_MST")
public class SyuGyotaiMst implements Serializable {
    private static final long serialVersionUID = 1L;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 5)
    @Column(name = "GYOTAI_CD")
    @Id
    private String gyotaiCd;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 1)
    @Column(name = "GYOTAI_KK")
    private String gyotaiKk;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 2)
    @Column(name = "GYOTAI_ISP")
    private String gyotaiIsp;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 200)
    @Column(name = "GYOTAI_NM")
    private String gyotaiNm;

    @Column(name = "CREATED_AT")
    @Temporal(TemporalType.TIMESTAMP)
    private Date createdAt;
    @Size(max = 32)
    @Column(name = "CREATED_BY")
    private String createdBy;
    @Column(name = "UPDATED_AT")
    @Temporal(TemporalType.TIMESTAMP)
    private Date updatedAt;
    @Size(max = 32)
    @Column(name = "UPDATED_BY")
    private String updatedBy;
    @Column(name = "UPDATED_BATCH_AT")
    @Temporal(TemporalType.TIMESTAMP)
    private Date updatedBatchAt;
    @Size(max = 32)
    @Column(name = "UPDATED_BATCH_BY")
    private String updatedBatchBy;

    public SyuGyotaiMst() {
    }

     public String getGyotaiCd() {
        return gyotaiCd;
    }

    public void setGyotaiCd(String gyotaiCd) {
        this.gyotaiCd = gyotaiCd;
    }

    public String getGyotaiKk() {
        return gyotaiKk;
    }

    public void setGyotaiKk(String gyotaiKk) {
        this.gyotaiKk = gyotaiKk;
    }

    public String getGyotaiIsp() {
        return gyotaiIsp;
    }

    public void setGyotaiIsp(String gyotaiIsp) {
        this.gyotaiIsp = gyotaiIsp;
    }

    public String getGyotaiNm() {
        return gyotaiNm;
    }

    public void setGyotaiNm(String gyotaiNm) {
        this.gyotaiNm = gyotaiNm;
    }

    public Date getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(Date createdAt) {
        this.createdAt = createdAt;
    }

    public String getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    public Date getUpdatedAt() {
        return updatedAt;
    }

    public void setUpdatedAt(Date updatedAt) {
        this.updatedAt = updatedAt;
    }

    public String getUpdatedBy() {
        return updatedBy;
    }

    public void setUpdatedBy(String updatedBy) {
        this.updatedBy = updatedBy;
    }

    public Date getUpdatedBatchAt() {
        return updatedBatchAt;
    }

    public void setUpdatedBatchAt(Date updatedBatchAt) {
        this.updatedBatchAt = updatedBatchAt;
    }

    public String getUpdatedBatchBy() {
        return updatedBatchBy;
    }

    public void setUpdatedBatchBy(String updatedBatchBy) {
        this.updatedBatchBy = updatedBatchBy;
    }

}
