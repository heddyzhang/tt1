/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package jp.co.toshiba.hby.pspromis.syuueki.facade;

import javax.ejb.Stateless;
import javax.inject.Inject;
import javax.interceptor.Interceptors;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import jp.co.toshiba.hby.pspromis.syuueki.interceptor.TranceInterceptor;
import jp.co.toshiba.hby.pspromis.common.jdbc.SqlExecutor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 *
 * @author sano
 */
@Stateless
@Interceptors({TranceInterceptor.class})
public class S003UpdateFacade {
    
    /**
     * ロガ－
     */
    private static final Logger logger = LoggerFactory.getLogger(S003UpdateFacade.class);

    @PersistenceContext(unitName = jp.co.toshiba.hby.pspromis.syuueki.util.ConstantString.syuuekiDataSourceName)
    private EntityManager em;

    @Inject
    protected SqlExecutor sqlExecutor;

    public S003UpdateFacade() {
    }
    
   
    /**
     * 回収金額の更新
     * 
     * @param condition 
     */
    public int updateRecoveryJissekiAmount(Object condition){
        logger.info("S004UpdateFacade#updateJissekiRecoveryAmount");

        return sqlExecutor.executeUpdateSql(em, "/sql/S004/updateKaisyuJissekiAmount.sql", condition);
    }
    
     /* 回収金額の更新
     * 
     * @param condition 
     */
    public int updateRecoveryAmount(Object condition){
        logger.info("S004UpdateFacade#updateJissekiRecoveryAmount");

        return sqlExecutor.executeUpdateSql(em, "/sql/S004/updateKaisyuAmount.sql", condition);
    }
    
    
    /**
     * 回収金額の登録
     * 
     * @param condition 
     */
    public int insertRecoveryAmount(Object condition){
        logger.info("S004UpdateFacade#insertRecoveryAmount");

        return sqlExecutor.executeUpdateSql(em, "/sql/S004/insertKaisyuAmount.sql", condition);
    }
    
    /**
     * 回収金額の登録
     * 
     * @param condition 
     */
    public int insertRecoveryJissekiAmount(Object condition){
        logger.info("S004UpdateFacade#insertRecoveryJissekiAmount");

        return sqlExecutor.executeUpdateSql(em, "/sql/S004/insertKaisyuJissekiAmount.sql", condition);
    }
 
}
