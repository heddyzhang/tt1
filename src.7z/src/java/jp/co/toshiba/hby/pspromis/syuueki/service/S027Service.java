package jp.co.toshiba.hby.pspromis.syuueki.service;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.ejb.Stateless;
import javax.inject.Inject;
import javax.interceptor.Interceptors;
import jp.co.toshiba.hby.pspromis.common.exception.PspRunTimeExceotion;
import jp.co.toshiba.hby.pspromis.syuueki.bean.S027Bean;
import jp.co.toshiba.hby.pspromis.syuueki.dto.IspHikiateDto;
import jp.co.toshiba.hby.pspromis.syuueki.entity.IspJissekiData;
import jp.co.toshiba.hby.pspromis.syuueki.entity.SyuGeBukkenInfoTbl;
import jp.co.toshiba.hby.pspromis.syuueki.enums.Label;
import jp.co.toshiba.hby.pspromis.syuueki.facade.KanjyoMstFacade;
import jp.co.toshiba.hby.pspromis.syuueki.facade.SyuGeBukenInfoTblFacade;
import jp.co.toshiba.hby.pspromis.syuueki.interceptor.TranceInterceptor;
import static jp.co.toshiba.hby.pspromis.syuueki.util.Utils.changeBigDecimal;
import org.apache.commons.lang3.time.DateUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 *
 * @author watabe
 */
@Stateless
@Interceptors({TranceInterceptor.class})
public class S027Service {
    
    /**
     * ロガー
     */
    public static final Logger logger = LoggerFactory.getLogger(S027Service.class);
    @Inject
    private S027Bean s027Bean;
    
    @Inject
    private KanjyoMstFacade kanjyoMstFacade;
    
    @Inject
    private SyuGeBukenInfoTblFacade syuGeBukenInfoTblFacade;
    
    @Inject
    private IspJissekiData entity;
    
    @Inject
    private StoredProceduresService storedProceduresService;
    
    @Inject
    private IspHikiateDto dto;
    
    //初期表示用処理
    public void getIspData()throws ParseException{
        //一般は"1"以外
        String salesClass = "";
        String date = kanjyoMstFacade.getNowKanjoDate(salesClass);
        String calDate = this.DateCal(date);
        
        s027Bean.setKanjyoYm(date);
        s027Bean.setSyuekiYm(calDate);
        entity.setSyuekiYm(calDate);
        
        //事業部コードの取得、Beanに格納
        getSyuBukkenInfo();
        
        Map<String, Object> condition = new HashMap<>();
        condition.put("ankenId", s027Bean.getAnkenId());
        condition.put("rirekiId", s027Bean.getRirekiId());
        condition.put("syuekiYm", s027Bean.getSyuekiYm());
        condition.put("orderNo", s027Bean.getOrderNo());
        condition.put("divisionCode", s027Bean.getDivisionCode());
        
        List<IspJissekiData> list = syuGeBukenInfoTblFacade.getDataList(condition); 
        s027Bean.setIspJissekiDataList(list);
        //setBean();
    }
    
    //事業部コードの取得
    private void getSyuBukkenInfo(){
        Map<String, Object> map = new HashMap<>();
        map.put("rirekiFlg",s027Bean.getRirekiFlg());
        map.put("ankenId", s027Bean.getAnkenId());
        map.put("rirekiId", s027Bean.getRirekiId());
        
        SyuGeBukkenInfoTbl bukkenEntity = syuGeBukenInfoTblFacade.findPk(map);
        if (bukkenEntity == null) {
            String errorMessage = Label.errorNoAnkenDate.getLabel();
            logger.error(errorMessage + " ankenId=" + s027Bean.getAnkenId() + " rirekiId=" + s027Bean.getRirekiId());
            throw new PspRunTimeExceotion(errorMessage);
        }
        s027Bean.setDivisionCode(bukkenEntity.getDivisionCode());
    }

    //検索ボタン処理
    public void getSearchData()throws ParseException{
        //売上月をyyyy/mmからyyyymmへフォーマット変換
        String syuekiYm = s027Bean.getSyuekiYm();
        String kanjyoYm = s027Bean.getKanjyoYm();
        s027Bean.setSyuekiYm(syuekiYm.replace("/",""));
        s027Bean.setKanjyoYm(kanjyoYm.replace("/",""));
        
        getSyuBukkenInfo();
        
        Map<String, Object> condition = new HashMap<>();
        condition.put("ankenId", s027Bean.getAnkenId());
        condition.put("rirekiId", s027Bean.getRirekiId());
        condition.put("syuekiYm", s027Bean.getSyuekiYm());
        condition.put("orderNo", s027Bean.getOrderNo());
        condition.put("divisionCode", s027Bean.getDivisionCode());
        
        List<IspJissekiData> list = syuGeBukenInfoTblFacade.getDataList(condition); 
        s027Bean.setIspJissekiDataList(list);
    }
    
    //引当ボタン用処理
    public void ispHikiate()throws Exception{
        int n = Integer.parseInt(s027Bean.getFlag());
         String syuekiYm = s027Bean.getSyuekiYm();

        //パッケージの実行
        dto.setTaisyoAnkenId(s027Bean.getAnkenId());
        dto.setHikiateAnkenId(s027Bean.getHikiAnkenId()[n]);
        dto.setRirekiId(Integer.parseInt(s027Bean.getRirekiId()));
        dto.setTaisyoYm(syuekiYm.replace("/",""));
        dto.setShiteiKbn(s027Bean.getShiteiKbn());
        dto.setHikiateIsp(changeBigDecimal(s027Bean.getIsp()));
        dto.setHikiateNet(changeBigDecimal(s027Bean.getNet()));
        
        storedProceduresService.callIspHikiate(dto);
        logger.info("callIspHikiate errFlg=[{}] errMsg=[{}]", dto.getErrFlg(), dto.getErrMsg());
        
        //再計算
        //固定"0"
        String recalProcFlg = "0";
         // 元案件：再計算パッケージ(TSIS様作成)呼び出し
        storedProceduresService.callAnkenRecalAuto(s027Bean.getAnkenId(), s027Bean.getRirekiId(), recalProcFlg);
         // 引当側案件：再計算パッケージ(TSIS様作成)呼び出し
        storedProceduresService.callAnkenRecalAuto(s027Bean.getHikiAnkenId()[n], s027Bean.getRirekiId(), recalProcFlg);
    }
    
    //勘定月ー1か月
    private String DateCal (String date)throws ParseException{
        SimpleDateFormat sdf = new SimpleDateFormat("yyyyMM");
        // Date型変換
        Date formatDate = sdf.parse(date);
        formatDate = DateUtils.addMonths(formatDate, -1);
        
        String result = sdf.format(formatDate);
        
        return result;
    }
}
