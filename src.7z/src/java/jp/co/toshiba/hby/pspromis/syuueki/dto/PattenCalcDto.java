/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package jp.co.toshiba.hby.pspromis.syuueki.dto;

/**
 * PS-Promis収益管理システム
 * RDBMS NET計算パッケージCall用パラメータdto
 * @author (NPC)masaki
 */
public class PattenCalcDto {
   
    /**
     * 案件id
     */
    private String ankenId;
    
    /**
     * 区分(最新:0/履歴:1)
     */
    private String kbn;

    /**
     * ユーザID
     */
    private String userId;
    
    /**
     * 処理結果ステータス(０:正常/9：異常)
     */
    private int status;

    /**
     * 処理結果メッセージ
     */
    private String statusMessage;
    
    public String getAnkenId() {
        return ankenId;
    }

    public void setAnkenId(String ankenId) {
        this.ankenId = ankenId;
    }

    public String getKbn() {
        return kbn;
    }

    public void setKbn(String kbn) {
        this.kbn = kbn;
    }
    
    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }
    
    public Integer getStatus() {
        return status;
    }

    public void setStatus(Integer status) {
        this.status = status;
    }
    
    public String getStatusMessage() {
        return statusMessage;
    }

    public void setStatusMessage(String statusMessage) {
        this.statusMessage = statusMessage;
    }
    
}
