package jp.co.toshiba.hby.pspromis.syuueki.facade;

import java.util.List;
import java.util.Map;
import javax.ejb.Stateless;
import javax.interceptor.Interceptors;
import javax.persistence.EntityManager;
import jp.co.toshiba.hby.pspromis.syuueki.interceptor.TranceInterceptor;
import javax.persistence.PersistenceContext;
import jp.co.toshiba.hby.pspromis.syuueki.entity.SyuGeBukkenInfoTbl;
import jp.co.toshiba.hby.pspromis.syuueki.entity.KaisyuList;

/**
 *
 * @author ganryu
 */
@Stateless
@Interceptors({TranceInterceptor.class})
public class S002Facade extends AbstractFacade<KaisyuList> {

    @PersistenceContext(unitName = jp.co.toshiba.hby.pspromis.syuueki.util.ConstantString.syuuekiDataSourceName)
    private EntityManager em;

    @Override
    protected EntityManager getEntityManager() {
        return em;
    }

    public S002Facade() {
        super(KaisyuList.class);
    }

    /**
     * 期間損益・月別詳細(一般) 回収　一覧
     *
     * @param condition
     * @return
     */
    public List<KaisyuList> findKaisyuList(Object condition) {
        List<KaisyuList> list = sqlExecutor.getResultList(em, KaisyuList.class, "/sql/S002/selectKaisyuAmountList.sql", condition);
        return list;
    }

    /**
     * 他事業部ISP案件を取得
     *
     * @param _params
     * @return
     */
    public List<SyuGeBukkenInfoTbl> findIspDivisionList(Map<String, Object> _params) {
        List<SyuGeBukkenInfoTbl> list = sqlExecutor.getResultList(em, SyuGeBukkenInfoTbl.class, "/sql/S002/selectIspDivisionList.sql", _params);
        return list;
    }
}
