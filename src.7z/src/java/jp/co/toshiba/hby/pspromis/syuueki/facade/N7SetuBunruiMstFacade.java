package jp.co.toshiba.hby.pspromis.syuueki.facade;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.ejb.Stateless;
import javax.interceptor.Interceptors;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import jp.co.toshiba.hby.pspromis.syuueki.entity.N7SetuBunruiMst;
import jp.co.toshiba.hby.pspromis.syuueki.interceptor.TranceInterceptor;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 *
 * @author ganryu
 */
@Stateless
@Interceptors({TranceInterceptor.class})
public class N7SetuBunruiMstFacade extends AbstractFacade<N7SetuBunruiMst> {

    private static final Logger logger = LoggerFactory.getLogger(N7SetuBunruiMst.class);

    @PersistenceContext(unitName = jp.co.toshiba.hby.pspromis.syuueki.util.ConstantString.syuuekiDataSourceName)
    private EntityManager em;

    @Override
    protected EntityManager getEntityManager() {
        return em;
    }

    public N7SetuBunruiMstFacade() {
        super(N7SetuBunruiMst.class);
    }

    /**
     * 設備分類一覧取得
     *
     * @param condition
     * @return
     */
    public List<N7SetuBunruiMst> getSetuBunruiNmList(Object condition) {
        logger.info("N7SetuBunruiMstFacade#getSetuBunruiNmList");
        List<N7SetuBunruiMst> list = sqlExecutor.getResultList(em, N7SetuBunruiMst.class, "/sql/setuBunruiMst/selectSetuBunruiMst.sql", condition);

        return list;
    }

    /**
     * 設備分類名取得
     *
     * @param condition
     * @return
     */
    public String selectSetuBunruiNm(Object condition) {
        logger.info("N7SetuBunruiMstFacade#selectSetuBunruiNm");
        String setuBunruiNm = "";
        List<N7SetuBunruiMst> list
                = sqlExecutor.getResultList(em, N7SetuBunruiMst.class, "/sql/setuBunruiMst/selectSetuBunruiNm.sql", condition);

        if (CollectionUtils.isNotEmpty(list)) {
            setuBunruiNm = StringUtils.defaultString(list.get(0).getSetuBunruiNm());
        }

        return setuBunruiNm;
    }
}
