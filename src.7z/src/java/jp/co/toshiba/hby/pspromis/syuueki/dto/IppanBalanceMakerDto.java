/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package jp.co.toshiba.hby.pspromis.syuueki.dto;

/**
 *
 * @author ibayashi
 */
public class IppanBalanceMakerDto {
    /**
     * 案件id
     */
    private String ankenId;
    
    /**
     * 履歴ID(通常は0,提出用データ作成時は1がくる)
     */
    private String rirekiId;

    /**
     * 処理FLG(0：バランス調整時、1：案件詳細一覧での保存時 VARCHAR2)
     */
    private String syoriFlg;
    
    /**
     * 処理結果ステータス(０:正常/9：異常)
     */
    private String status;

    public String getAnkenId() {
        return ankenId;
    }

    public void setAnkenId(String ankenId) {
        this.ankenId = ankenId;
    }

    public String getSyoriFlg() {
        return syoriFlg;
    }

    public void setSyoriFlg(String syoriFlg) {
        this.syoriFlg = syoriFlg;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getRirekiId() {
        return rirekiId;
    }

    public void setRirekiId(String rirekiId) {
        this.rirekiId = rirekiId;
    }

}
