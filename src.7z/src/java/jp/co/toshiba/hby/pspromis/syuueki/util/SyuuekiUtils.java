package jp.co.toshiba.hby.pspromis.syuueki.util;

import java.io.Serializable;
import java.math.BigDecimal;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import javax.enterprise.context.ApplicationScoped;
import javax.inject.Inject;
import javax.inject.Named;
import jp.co.toshiba.hby.pspromis.common.util.StringUtil;
import jp.co.toshiba.hby.pspromis.syuueki.enums.Env;
import jp.co.toshiba.hby.pspromis.syuueki.enums.Label;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.time.DateFormatUtils;

/**
 * PS-Promis収益管理システム 収益管理 共通ユーティリティ<br>
 * ELからも使用可能なようにCDI管理する(ApplicationScoped)
 *
 * @author (NPC)S.Ibayashi
 */
@Named(value = "sUtil")
@ApplicationScoped
public class SyuuekiUtils implements Serializable {

    @Inject
    private DateFormatDefin dateFormatDefin;

    /**
     * Ｍ率計算
     *
     * @param sp
     * @param net
     * @return M率
     */
    public String mrate(BigDecimal sp, BigDecimal net) {
        // 両方ともnullの場合は計算せずに終了
        if ((sp == null || sp.intValue() == 0) || (net == null || net.intValue() == 0)) {
            return null;
        }

        // NETがnull or 0の場合は計算できないのでnullを戻す。
        if (net == null || net.intValue() == 0) {
            return null;
        }

        // SPがnullの場合は0に変換
        BigDecimal calcSp = (sp == null ? (new BigDecimal(0)) : sp);

        // M率計算((SP / NET) * 100)
        //BigDecimal bigMrate = (calcSp.divide(net)).multiply((new BigDecimal(100)));
        double bigMrate = (calcSp.doubleValue() / net.doubleValue()) * 100;

        DecimalFormat mratDf = new DecimalFormat(dateFormatDefin.getMratFmt());
//        if (mratDf == null) {
//            mratDf = new DecimalFormat(dateFormatDefin.getMratFmt());
//        }
        String mrate = mratDf.format(bigMrate);

        return mrate;
    }

    /**
     * 粗利計算
     *
     * @param sp
     * @param net
     * @return
     */
    public BigDecimal arari(BigDecimal sp, BigDecimal net) {
        if (sp == null && net == null) {
            return null;
        }

        // 片方がnullの場合は0に変換
        BigDecimal calcSp = (sp == null ? (new BigDecimal(0)) : sp);
        BigDecimal calcNet = (net == null ? (new BigDecimal(0)) : net);

        // 粗利(SP - NET)を計算
        BigDecimal arari = calcSp.add(calcNet.negate());

        return arari;
    }

    /**
     * 粗利計算(文字列指定) el式でBigDecimalで渡すと0扱いされてしまうため、nullで返せるようにメソッドを追加
     *
     * @param sp
     * @param net
     * @return
     */
    public BigDecimal arariString(String _sp, String _net) {
        if (StringUtils.isEmpty(_sp) && StringUtils.isEmpty(_net)) {
            return null;
        }

        boolean isSpDecimal = false;
        boolean isNetDecimal = false;

        // 引数のsp,netが数値変換できない場合はエラー
        try {
            Double.parseDouble(_sp);
            isSpDecimal = true;
        } catch (Exception e) {
        }
        try {
            Double.parseDouble(_net);
            isNetDecimal = true;
        } catch (Exception e) {
        }

        String sp = _sp;
        if (!isSpDecimal && StringUtils.isEmpty(sp)) {
            sp = "0";
        }
        String net = _net;
        if (!isNetDecimal && StringUtils.isEmpty(net)) {
            net = "0";
        }

        return arari(new BigDecimal(sp), new BigDecimal(net));
    }

    /**
     * 粗利計算
     *
     * @param sp
     * @param net
     * @return
     */
    public BigDecimal keijokeisan(BigDecimal sp, BigDecimal net, BigDecimal seibanSoneki, BigDecimal sougenka) {
        if (sp == null && net == null) {
            return null;
        }

        // 片方がnullの場合は0に変換
        BigDecimal calcSp = (sp == null ? (new BigDecimal(0)) : sp);
        BigDecimal calcNet = (net == null ? (new BigDecimal(0)) : net);
        BigDecimal calcSougenka = (sougenka == null ? (new BigDecimal(0)) : sougenka);
        BigDecimal calcSeibanSoneki = (seibanSoneki == null ? (new BigDecimal(0)) : seibanSoneki);

        // 粗利(SP - NET)を計算
        BigDecimal arari = calcSp.add(calcNet.negate()).add(calcSougenka).add(calcSeibanSoneki);

        return arari;
    }

    /**
     * 円貨計算の割合(円,千円,百万円)を取得<br/>
     * param kbn(円:1,千円:2,百万円:3) return 割合
     */
    public String changeUnitStr(String strSpNet, String kbn) {
        if (StringUtil.isEmpty(strSpNet)) {
            return null;
        }

        BigDecimal big = changeUnit(strSpNet, kbn);
        return big.toString();
    }

    /**
     * SP,NETを画面表示表に整形 円貨計算の割合(円,千円,百万円)を取得<br/>
     * param kbn(円:1,千円:2,百万円:3) param currencyCode 通貨 return 割合
     */
    public String changeDispCurrencyFormat(String strSpNet, String kbn, String currencyCode) {
        if (StringUtil.isEmpty(strSpNet)) {
            return null;
        }

        BigDecimal big = null;
        String ret = null;
        //if (StringUtils.isEmpty(currencyCode) || "JPY".equals(currencyCode)) {
        if (StringUtils.isEmpty(currencyCode) || ConstantString.currencyCodeEn.equals(currencyCode)) {
            // 邦貨(or 通貨指定なし)
            big = changeUnit(strSpNet, kbn);
            ret = exeFormatUnit(big);

        } else {
            // 外貨
            big = new BigDecimal(strSpNet);
            DecimalFormat foreignUnitDf = new DecimalFormat(dateFormatDefin.getForeignUnitFmt());
            ret = foreignUnitDf.format(big.setScale(3, BigDecimal.ROUND_HALF_UP));

        }

        return ret;
    }

    public String changeDispCurrencyFormat(String strSpNet, String kbn) {
        return changeDispCurrencyFormat(strSpNet, kbn, null);
    }

    /**
     * 円貨計算の割合(円,千円,百万円)を取得<br/>
     * param kbn(円:1,千円:2,百万円:3) return 割合
     */
    public BigDecimal changeUnit(String strSpNet, String kbn) {
        if (StringUtil.isEmpty(strSpNet)) {
            return null;
        }

        BigDecimal spNet = new BigDecimal(strSpNet);
        return changeUnit(spNet, kbn);
    }

    /**
     * 円貨計算の割合(円,千円,百万円)を取得<br/>
     * param kbn(円:1,千円:2,百万円:3) return 割合
     */
    public BigDecimal changeUnit(BigDecimal spNet, String kbn) {
        if (spNet == null) {
            return null;
        }
        if (spNet.intValue() == 0) {
            return spNet;
        }

        Integer rate = 1;

        if ("2".equals(kbn)) {
            // 千円
            rate = 1000;
        } else if ("3".equals(kbn)) {
            // 百万円
            rate = 1000000;
        }

        BigDecimal big = spNet.divide(new BigDecimal(rate));
        big = big.setScale(0, BigDecimal.ROUND_HALF_UP);

        return big;
    }

    /**
     * 年をIntegerで取得
     *
     * @param _targetYm
     * @return
     */
    public static Integer getIntegerYear(String _targetYm) {
        if (StringUtil.isEmpty(_targetYm)) {
            return null;
        }

        String targetYm = StringUtils.replace(_targetYm, "/", "");
        targetYm = StringUtils.substring(targetYm, 0, 4);
        Integer year = new Integer(targetYm);
        return year;
    }

    /**
     * 月をIntegerで取得
     *
     * @param _targetYm
     * @return
     */
    public static Integer getIntegerMonth(String _targetYm) {
        if (StringUtil.isEmpty(_targetYm)) {
            return null;
        }

        String targetYm = StringUtils.replace(_targetYm, "/", "");
        targetYm = StringUtils.substring(targetYm, 4, 6);
        Integer month = new Integer(targetYm);
        return month;
    }

    /**
     * 指定日付の期間(YYYYMM(MMは期の最終月) + 'K'(上期) or 'S'(下期))を取得<br>
     * (例)2014上期=201409K 2014下期='201503S'
     *
     * @param date 指定日付
     * @return 指定日付の期間
     */
    public static String dateToKikan(Date date) {
        if (date == null) {
            return "";
        }

        SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");
        String strDate = sdf.format(date);
        String kikan;

        int year = getIntegerYear(strDate);
        int month = getIntegerMonth(strDate);

        if (month >= 4 && month <= 9) {
            kikan = year + "K";
        } else if (month >= 1 && month <= 3) {
            kikan = (year - 1) + "S";
        } else {
            kikan = year + "S";
        }

        return labelKikan(kikan);
    }
    
    /**
     * 年月から年度の上期と下期を配列で取得
     * (例) "201604"→{"201609K", "201703S"}  "201701"→{"201609K", "201703S"}
     * @param ym
     * @return 
     */
    public static String[] getKikanFromYm(String ym){
        List<String> list = new ArrayList<>();
        int year = getIntegerYear(ym);
        int month = getIntegerMonth(ym);

        String kamiki;
        String shimoki;

        if(month >= 4 && month <= 12){
            kamiki = year + "09K";
            shimoki = (year + 1) + "03S";
        } else {
            kamiki = (year - 1) + "09K";
            shimoki = year + "03S";
        }

        list.add(kamiki);
        list.add(shimoki);
        
        String[] monthAry = (String[]) list.toArray(new String[0]);

        return monthAry;
    }

    /**
     * 年、期(K or S)から、期間ラベルを取得
     *
     * @param kikan
     * @return
     */
    public static String labelKikan(String kikan) {
        if (!isCheckKikan(kikan)) {
            return null;
        }

        String label = "";
        int year = getIntegerYear(kikan);
        String ki = kikan.substring(4);
        switch (ki) {
            case "K":
                label = String.valueOf(year) + "09" + ki;
                break;
            case "S":
                label = String.valueOf(year + 1) + "03" + ki;
                break;
        }

        return label;
    }

    /**
     * 指定予算期(2015K0,2015K1,2015S0...)の期間(YYYYMM(MMは期の最終月) + 'K'(上期) or
     * 'S'(下期))を取得<br>
     * (例)2014上期(2014K0,2014K1...)=201409K 2014下期(2014S0,2014S1...)='201503S'
     *
     * @param yosanki 指定した予算期
     * @return 指定日付の期間
     */
    public String yosankiLabelKikan(String yosanki) {
        if (yosanki == null) {
            return "";
        }
        return labelKikan(StringUtils.substring(yosanki, 0, 5));
    }

    /**
     * 期間の表記変更<br>
     * (YYYYMM + 'K'(上期) or 'S'(下期)) →　(YYYY + K or S)<br>
     * 例:2014上期 201409K → 2014K 2014下期 201503S → 2014S
     *
     * @param beforeKikan
     * @return
     */
    public static String changeDecodeKikanLabel(String beforeKikan) {
        if (StringUtil.isEmpty(beforeKikan)) {
            return null;
        }
        if (beforeKikan.length() != 7) {
            return null;
        }
        if (isCheckKikan(beforeKikan)) {
            return beforeKikan;
        }

        String afterKikan = beforeKikan;
        int year = getIntegerYear(afterKikan);
        String ki = afterKikan.substring(6);

        switch (ki) {
            case "S":
                afterKikan = (String.valueOf(year - 1)) + ki;
                break;
            case "K":
                afterKikan = (String.valueOf(year)) + ki;
                break;
            default:
                afterKikan = null;
                break;
        }

        return afterKikan;
    }

    /**
     * 指定年月のQ(4半期表記) ※(○Q)を要素2個の配列で取得 例:201504 → 1Q,2Q 201510 → 3Q,4Q
     */
    public String[] getQuarterLabel(Date date) {
        String kikan = dateToKikan(date);
        return getQuarterLabel(kikan);
    }

    public String[] getQuarterLabel(String kikan) {
        String[] quarterLabelAry = {"", ""};
        kikan = StringUtils.substring(kikan, kikan.length() - 1);

        if (kikan.equals("S")) {
            // 下期の場合
            quarterLabelAry[0] = "3Q";
            quarterLabelAry[1] = "4Q";
        } else if (kikan.equals("K")) {
            // 上期の場合
            quarterLabelAry[0] = "1Q";
            quarterLabelAry[1] = "2Q";
        }

        return quarterLabelAry;
    }

    /**
     * 期間指定が正常であるかを判定
     *
     * @param kikan
     * @return
     */
    public static boolean isCheckKikan(String kikan) {
        if (StringUtil.isEmpty(kikan)) {
            return false;
        }
        if (kikan.length() != 5) {
            return false;
        }
        try {
            getIntegerYear(kikan);
        } catch (NumberFormatException e) {
            return false;
        }

        return true;
    }

    /**
     * 指定期間の表記を取得()
     *
     * @param kikan
     * @return
     */
    public String kikanLabel(String kikan) {
        String convertKikan = changeDecodeKikanLabel(kikan);
        if (StringUtil.isEmpty(convertKikan)) {
            return "";
        }

        String label = "";

        if (convertKikan.substring(4).equals("K")) {
            label = getIntegerYear(convertKikan) + Label.getValue(Label.firstHalf);
        }
        if (convertKikan.substring(4).equals("S")) {
            label = getIntegerYear(convertKikan) + Label.getValue(Label.secondHalf);
        }

        return label;
    }

    /**
     * 指定期間の演算
     *
     * @param kikan 指定期間
     * @param nextIndex 指定期間を{nextIndex}先に進める。
     * @return 指定期間を{nextIndex}先に進めた期間を取得
     */
    public static String calcKikan(String kikan, Integer nextIndex) {
        String convertKikan = changeDecodeKikanLabel(kikan);
        if (StringUtil.isEmpty(convertKikan)) {
            return "";
        }

        if (nextIndex == null || nextIndex == 0) {
            return kikan;
        }

        String returnKikan = convertKikan;

        if (nextIndex > 0) {
            for (int i = 1; i <= nextIndex; i++) {
                if (returnKikan.substring(4).equals("K")) {
                    returnKikan = getIntegerYear(returnKikan) + "S";
                } else {
                    returnKikan = (getIntegerYear(returnKikan) + 1) + "K";
                }
            }
        } else {
            for (int i = -1; i >= nextIndex; i--) {
                if (returnKikan.substring(4).equals("K")) {
                    returnKikan = (getIntegerYear(returnKikan) - 1) + "S";
                } else {
                    returnKikan = getIntegerYear(returnKikan) + "K";
                }
            }
        }

        return labelKikan(returnKikan);
    }

    /**
     * 指定期間の月情報(YYYYMM形式)を配列で取得<br>
     * (例)2014K → {"201404", "201405", "201406", "201407", "201408", "201409"}
     * 2014S → {"201410", "201411", "201412", "201501", "201502", "201503"}
     *
     * @param kikan
     * @return 期間の月配列
     */
    public static String[] getKikanMonthAry(String kikan) {
        String convertKikan = "";
        if (StringUtils.length(kikan) == 5) {
            convertKikan = kikan;
        } else {
            convertKikan = changeDecodeKikanLabel(kikan);
        }

        if (StringUtil.isEmpty(convertKikan)) {
            return null;
        }

        String[] ary = new String[6];
        String nendo = String.valueOf(getIntegerYear(convertKikan));
        String ki = convertKikan.substring(4);
        int month = 0;

        if (ki.equals("K")) {
            month = 4;
        } else {
            month = 10;
        }

        for (int i = 0; i < 6; i++) {
            if (month == 13) {
                nendo = String.valueOf(Integer.parseInt(nendo) + 1);
                month = 1;
            }

            ary[i] = nendo + (month < 10 ? ("0" + month) : month);
            month++;
        }

        return ary;
    }

    /**
     * 指定日付(Date)の期の月情報(YYYYMM形式)を配列で取得<br>
     * (例)2014K → {"201404", "201405", "201406", "201407", "201408", "201409"}
     * 2014S → {"201410", "201411", "201412", "201501", "201502", "201503"}
     *
     * @param date
     * @return 期間の月配列
     */
    public String[] getKikanMonthAry(Date date) {
        String kikan = dateToKikan(date);
        return getKikanMonthAry(kikan);
    }

    /**
     * 指定予算期(etc:2015K1,2015K1,2015S0)より、期の月情報を配列で取得 (例)2014K0,2014K1,2014K2...
     * → {"201404", "201405", "201406", "201407", "201408", "201409"}
     * 2014S0,2014S1,2014S2... → {"201410", "201411", "201412", "201501",
     * "201502", "201503"}
     *
     * @param yosanki
     * @return
     */
    public String[] getYosanMonthAry(String yosanki) {
        String labelK = labelKikan(StringUtils.substring(yosanki, 0, 5));
        String[] monthAry = getKikanMonthAry(labelK);

        return monthAry;
    }

    /**
     * SP,NET(円貨)の表示書式(カンマ編集)を取得
     *
     * @return
     */
    public String formatJpyUnit() {
        //return jpyUnitFmt;
        return dateFormatDefin.getJpyUnitFmt();
    }

    /**
     * SP,NET(円貨)をカンマ区切りにフォーマット
     *
     * @return
     */
    public String exeFormatUnitStr(String value) {
        if (StringUtils.isEmpty(value)) {
            return null;
        }

        try {
            Double.parseDouble(value);
        } catch (NumberFormatException e) {
            return null;
        }

        BigDecimal big = new BigDecimal(value);
        return exeFormatUnit(big);
    }

    /**
     * SP,NET(円貨)をカンマ区切りにフォーマット
     *
     * @return
     */
    public String exeFormatUnit(BigDecimal value) {
        if (value == null) {
            return null;
        }

        DecimalFormat jpyUnitDf = new DecimalFormat(formatJpyUnit());
//        if (jpyUnitDf == null) {
//            jpyUnitDf = new DecimalFormat(formatJpyUnit());
//        }

        String returnValue = jpyUnitDf.format(value.setScale(0, BigDecimal.ROUND_HALF_UP));
        return returnValue;
    }

    /**
     * SP,NET(外貨)をカンマ区切りにフォーマット
     *
     * @param value：外貨
     * @param currency:通貨
     * @return フォーマット
     */
    public String exeFormatUnit(BigDecimal value, String currency) {
        String format;
        String returnValue;

        if (value == null) {
            return "";
        }

        //if (value == null || "JPY".equals(currency)) {
        //if (value == null || ConstantString.currencyCodeEn.equals(currency)) {
        if (ConstantString.currencyCodeEn.equals(currency)) {
            // 円貨の場合
            returnValue = exeFormatUnit(value);
        } else {
            // 外貨の場合
            Double sa = value.doubleValue() - (double) (value.longValue());
            if (sa == 0) {
                returnValue = exeFormatUnit(value);
            } else {
                DecimalFormat foreignUnitDf = new DecimalFormat(dateFormatDefin.getForeignUnitFmt());
//                if (foreignUnitDf == null) {
//                    foreignUnitDf = new DecimalFormat(dateFormatDefin.getForeignUnitFmt());
//                }
                returnValue = foreignUnitDf.format(value.setScale(3, BigDecimal.ROUND_HALF_UP));
            }
        }

        return returnValue;
    }

    public String exeChangeDispFormatUnit(BigDecimal value, int flg) {
        String returnValue = exeFormatUnit(value);
        if (returnValue.equals("0")) {
            returnValue = "";
        } else {
            returnValue = exeChangeFormatUnit(value, flg);
        }
        return returnValue;
    }

    /**
     * SP,NET(外貨)をカンマ区切りにフォーマット(期間損益進行基準画面)
     *
     * @param value：外貨
     * @param flg 0:整数フォーマット 1:小数点(2桁)のフォーマットを
     * @return フォーマット
     */
    public String exeChangeFormatUnit(BigDecimal value, int flg) {
        //String format;
        String returnValue;

        if (value == null) {
            return "";
        }

        if (flg == 0) {
            returnValue = exeFormatUnit(value);
        } else {
            DecimalFormat foreignUnitDf = new DecimalFormat(dateFormatDefin.getForeignUnitFmt());
//            if (foreignUnitDf == null) {
//                foreignUnitDf = new DecimalFormat(dateFormatDefin.getForeignUnitFmt());
//            }
            returnValue = foreignUnitDf.format(value.setScale(3, BigDecimal.ROUND_HALF_UP));
        }

        return returnValue;
    }

    /**
     * 通貨レートの表示書式を取得
     *
     * @return
     */
    public String formatRate() {
        //return "##0.00";
        return dateFormatDefin.getRateFmt();
    }

    /**
     * 通貨レートのフォーマット
     *
     * @return
     */
    public String exeFormatRate(BigDecimal rate) {
        if (rate == null) {
            return null;
        }

        DecimalFormat rateDf = new DecimalFormat(formatRate());
        String returnValue = rateDf.format(rate.setScale(2, BigDecimal.ROUND_HALF_UP));
        return returnValue;
    }

    /**
     * 通貨レートのフォーマット(文字列指定)
     */
    public String exeFormatRateString(String _rate) {
        return exeFormatRateString(_rate, null);
    }

    /**
     * 通貨レートのフォーマット(文字列指定)
     */
    public String exeFormatRateString(String _rate, String _currenyCode) {
        String rate = _rate;
        // 通貨JPYの場合でレート未指定の場合は強制的に"1"に変換
        if (StringUtils.isEmpty(rate) && ConstantString.currencyCodeEn.equals(_currenyCode)) {
            rate = "1";
        }
        if (StringUtils.isEmpty(rate)) {
            return null;
        }

        try {
            Double.parseDouble(rate);
        } catch (NumberFormatException e) {
            return null;
        }

        return exeFormatRate(new BigDecimal(rate));
    }

    /**
     * 日時のフォーマットを取得
     *
     * @return
     */
    public String formatTimeStamp() {
        return "yyyy/MM/dd HH:mm:ss";
        //return dateFormatDefin.getDateFormatTimestamp();
    }

    /**
     * 年月日のフォーマットを取得
     */
    public String formatYmd() {
        //return "yyyy/MM/dd";
        return dateFormatDefin.getDateFormatDate();
    }

    /**
     * 日付フォーマット実行
     *
     * @param date
     * @return
     */
    public String exeFormatYmd(Date date) {
        if (date == null) {
            return "";
        }

        SimpleDateFormat ymdSd = new SimpleDateFormat(formatYmd());
//        if (ymdSd == null) {
//            ymdSd = new SimpleDateFormat(formatYmd());
//        }
        String returnValue = ymdSd.format(date);
        return returnValue;
    }

    /**
     * 日時フォーマット実行
     *
     * @param date
     * @return
     */
    public String exeFormatTimeStamp(Date date) {
        if (date == null) {
            return "";
        }

        SimpleDateFormat timeStampSd = new SimpleDateFormat(formatTimeStamp());
//        if (timeStampSd == null) {
//            timeStampSd = new SimpleDateFormat(formatTimeStamp());
//        }
        String returnValue = timeStampSd.format(date);
        return returnValue;
    }

    /**
     * 年月のフォーマットを取得
     *
     * @return
     */
    public String formatYm() {
        //return "yyyy/MM";
        return dateFormatDefin.getDateFormatYm();
    }

    /**
     * 年月フォーマット実行
     *
     * @param date
     * @return
     */
    public String exeFormatYm(Date date) {
        if (date == null) {
            return "";
        }

        SimpleDateFormat ymSd = new SimpleDateFormat(formatYm());
//        if (ymSd == null) {
//            ymSd = new SimpleDateFormat(formatYm());
//        }
        String returnValue = ymSd.format(date);
        return returnValue;
    }

    /**
     * 通貨単位切り替え
     *
     * @param currency 通貨
     * @param unit 単位
     * @return 単位切り替え後の通貨
     */
    public BigDecimal switchingCurrencyUnit(BigDecimal currency, Integer unit) {
        // 通貨がnullか単位がnullか0の場合は通貨をそのまま返す
        if (currency == null || (unit == null || unit == 0)) {
            return currency;
        }
        BigDecimal decimalUnit = new BigDecimal(unit);
        BigDecimal retVal = BigDecimal.ZERO;

        // 小数点以下は四捨五入とする
        retVal = currency.divide(decimalUnit, 0, BigDecimal.ROUND_HALF_UP);

        return retVal;
    }

    /**
     * 通貨単位切り替え(通貨コード対応)
     *
     * @param currency 通貨
     * @param unit 単位
     * @param currencyCode
     * @return 単位切り替え後の通貨
     */
    public BigDecimal switchingCurrencyUnit(BigDecimal currency, Integer unit, String currencyCode) {
        // 通貨がnullか単位がnullか0の場合は通貨をそのまま返す
        if (currency == null || (unit == null || unit == 0) || currencyCode == null) {
            return currency;
        }
        BigDecimal decimalUnit = new BigDecimal(unit);
        BigDecimal retVal = BigDecimal.ZERO;

//        int scale = 0;
//        if(!currencyCode.equals("JPY")){
//            scale = 3;
//        }
        int scale = 3;

        // 小数点以下は四捨五入とする
        retVal = currency.divide(decimalUnit, scale, BigDecimal.ROUND_HALF_UP);

        return retVal;
    }

    /**
     * プラント名/設置先名称を取得
     *
     * @param plant
     * @param stch
     * @return
     */
    public String getPlantStch(String plant, String stch) {
        String value = null;
        if (StringUtil.isNotEmpty(plant) || StringUtil.isNotEmpty(stch)) {
            value = StringUtils.defaultString(plant) + "/" + StringUtils.defaultString(stch);
        }
        return value;
    }

    /**
     * 実施年度/回数を取得
     *
     * @param jissiNendo
     * @param teiken
     * @return
     */
    public String getJissiTeiken(String jissiNendo, Object teiken) {
        String value = null;
        if (StringUtil.isNotEmpty(jissiNendo)) {
            value = jissiNendo + Label.getValue(Label.nendo);
        } else if (teiken != null) {
            value = teiken + Label.getValue(Label.kai);
        }
        return value;
    }

    /**
     * 一般/進行基準のラベルを取得(一覧系画面用)
     *
     * @param salesClass
     * @return
     */
    public String getSalesClassLabel(String salesClass) {
        String value = "";
        if (StringUtil.isNotEmpty(salesClass)) {
            if (ConstantString.salesClassS.equals(salesClass)) {
                value = Label.getValue(Label.shinkoLabelShort);
            }
        }
        return value;
    }
    /**
     * 一般/進行基準のラベルを取得(案件の詳細画面用)
     *
     * @param salesClass
     * @return
     */
    public String getSalesClassLabelFull(String salesClass) {
        String value = "";
        if (StringUtil.isNotEmpty(salesClass)) {
            if (ConstantString.salesClassS.equals(salesClass)) {
                value = Label.getValue(Label.shinko);
            } else if (ConstantString.salesClassI.equals(salesClass)) {
                value = Label.getValue(Label.kansei);
            }
        }
        return value;
    }
     //20180302 原価回収基準対応　ADD START
     /**
     * 一般/進行基準/原価回収基準を取得(一覧系画面用)
     *
     * @param salesClass
     * @param salesClassGenka
     * @return
     */
    public String getSalesClassAllLabel(String salesClass ,String salesClassGenka) {
        String value = "";
        
        if(StringUtil.isNotEmpty(salesClassGenka)){
            value = Label.getValue(Label.genkaLabelShort);
        }else{
            
            if (StringUtil.isNotEmpty(salesClass)) {
                if (ConstantString.salesClassS.equals(salesClass)) {
                    value = Label.getValue(Label.shinkoLabelShort);
                }
            }
        
        }
        return value;
    }
     /**
     * 一般/進行基準/原価回収基準を取得(案件の詳細画面用)
     *
     * @param salesClass
     * @param salesClassGenka
     * @return
     */
    public String getSalesClassLabelGenFull(String salesClass ,String salesClassGenka) {
        String value = "";
        
        if(StringUtil.isNotEmpty(salesClassGenka)){
            value = Label.getValue(Label.genkaLabel);
        }else{
            if (StringUtil.isNotEmpty(salesClass)) {
                if (ConstantString.salesClassS.equals(salesClass)) {
                    value = Label.getValue(Label.shinko);
                } else if (ConstantString.salesClassI.equals(salesClass)) {
                    value = Label.getValue(Label.kansei);
                }
            }
        
        }
        return value;
    }
  /**
     * 一般/進行基準/原価回収基準を取得(月次確定用)
     *
     * @param salesClass
     * @param salesClassGenka
     * @return
     */
    public String getSalesClassLabelGetsujiFull(String salesClass) {
        String value = "";

        if (StringUtil.isNotEmpty(salesClass)) {
            if (ConstantString.salesClassS.equals(salesClass)) {
                value = Label.getValue(Label.genkaShinkoLabelShort);
            } else if (ConstantString.salesClassI.equals(salesClass)) {
                value = Label.getValue(Label.kansei);
            }
        }
        
        return value;
    }
    
     //20180302 原価回収基準対応　ADD END

     /**
     * ロスコン対象の場合、売上基準に表記を付加(頭*)  2018/06/01 add
     * @param _salesClassLabel 売上基準の表示
     * @param lossControlFlag ロスコン対象 Y:対象
     * @return
     */
    public String getSalesClassLabelAddLoss(String _salesClassLabel, String lossControlFlag) {
        String salesClassLabel = StringUtils.defaultString(_salesClassLabel);
        return ConstantString.lossControlTargetFlg.equals(lossControlFlag) ? ("*" + salesClassLabel) : salesClassLabel;
    }

    /**
     * 売上区分のラベルを取得
     *
     * @param uriageEndFlg 売上区分
     * @param miuriageFlg 未売上のラベルを取得するか(0:しない 1:する)
     */
    public String getUriageEndLabel(String uriageEndFlg, int miuriageFlg) {
        String value = null;
        if (StringUtil.isNotEmpty(uriageEndFlg)) {
            if (uriageEndFlg.equals("2")) {
                value = Label.getValue(Label.uriageEndFlg3);
            } else if (uriageEndFlg.equals("1")) {
                value = Label.getValue(Label.uriageEndFlg2);
            } else if (uriageEndFlg.equals("0") && miuriageFlg == 1) {
                value = Label.getValue(Label.uriageEndFlg1);
            }
        }
        return value;
    }

    /**
     * S/Nのラベルを取得
     *
     * @param hatsuban ステータス
     * @return ステータスラベル
     */
    public String getSNLabel(String hatsuban) {
        String value = null;
        if (StringUtil.isNotEmpty(hatsuban)) {
            if (hatsuban.equals("N")) {
                value = Label.getValue(Label.nHatsuban);
            } else if (hatsuban.equals("S")) {
                value = Label.getValue(Label.sHatsuban);
            }
        }
        return value;
    }

    /**
     * 確定ステータスのラベルを取得
     *
     * @param status ステータス
     * @return ステータスラベル
     */
    public String getKakuteiLabel(String status) {
        String value = null;
        if (StringUtil.isNotEmpty(status)) {
            switch (status) {
                case ConstantString.wfStatusKakutei:
                    value = Label.statusFixed.getLabel();
                    break;
                case ConstantString.wfStatusTeishutsu:
                    value = Label.statusTeishutsu.getLabel();
                    break;
                case ConstantString.wfStatusCreating:
                    value = Label.statusCreating.getLabel();
                    break;
                default:
                    break;
            }
        }
        return value;
    }

    /**
     * 見込/実績区分より、実績/見込のラベルを取得
     *
     * @param _jyKbn
     * @return
     */
    public String getJYLabel(String _jyKbn) {
        String label = null;
        if ("J".equals(_jyKbn)) {
            label = Label.getValue(Label.jisseki);
        } else if ("M".equals(_jyKbn)) {
            label = Label.getValue(Label.mikomi);
        }
        return label;
    }

    /**
     * 勘定日と対象年月より、実績/予算のラベルを取得
     *
     * @param kanjoDate
     * @param _targetYm
     * @return
     */
    public String getJYLabel(Date kanjoDate, String _targetYm) {
        String label;
        if (getJissekiFlg(kanjoDate, _targetYm)) {
            label = Label.getValue(Label.jisseki);
        } else {
            label = Label.getValue(Label.mikomi);
        }
        return label;
    }

    /**
     * データ種別より、月次/予算のラベルを取得
     *
     * @param _syubetsu
     * @return
     */
    public String getGYLabel(String _syubetsu) {
        String label = null;
        if ("G".equals(_syubetsu)) {
            label = Label.getValue(Label.monthly);
        } else if ("Y".equals(_syubetsu)) {
            label = Label.getValue(Label.yosan);
        }
        return label;
    }

    /**
     * 勘定日と対象年月より、対象年月が実績月であるかをチェック
     *
     * @param kanjoDate
     * @param _targetYm
     * @return 実績であればtrue
     */
    public boolean getJissekiFlg(Date kanjoDate, String _targetYm) {
        if (kanjoDate == null || StringUtil.isEmpty(_targetYm)) {
            return false;
        }

        SimpleDateFormat kanjoYmSd = new SimpleDateFormat(dateFormatDefin.getDataFormatCalcKanjoYm());
//        if (kanjoYmSd == null) {
//            kanjoYmSd = new SimpleDateFormat(dateFormatDefin.getDataFormatCalcKanjoYm());
//        }

        boolean isJisseki = false;

        String kanjoYm = kanjoYmSd.format(kanjoDate);
        String targetYm = StringUtils.replace(_targetYm, "/", "");
        targetYm = StringUtils.substring(targetYm, 0, 6);

        if (targetYm.compareTo(kanjoYm) < 0) {
            isJisseki = true;
        }

        return isJisseki;
    }

    /**
     * 月表記を取得(○月) → YYYY/MMに変更
     *
     * @param _targetYm
     * @return
     */
    public String getLabelMonth(String _targetYm) {
//        Integer month = getIntegerMonth(_targetYm);
//        String label = month + Label.getValue(Label.month);
        String year = StringUtils.substring(_targetYm, 0, 4);
        String month = StringUtils.substring(_targetYm, 4);
        String label = year + "/" + month;
        return label;
    }

    /**
     * ダッシュボードのURLを取得
     *
     * @param division 事業部コード
     * @return
     */
//    public String getDashBoardUrl(String division) {
//        try {
//            return Env.getDashBoardUrl(division);
//        } catch (java.util.MissingResourceException e) {
//            return "";
//        }
//    }

    /**
     * 検索条件格納Map 文字列形式で取得
     *
     * @param condition
     */
    public String changeStringCondtion(Map<String, Object> condition) {
        String charSet = Env.getValue(Env.Charset);

        Set<String> keySet = condition.keySet();
        Iterator<String> ite = keySet.iterator();
        StringBuilder sb = new StringBuilder();
        int count = 0;

        while (ite.hasNext()) {
            String key = ite.next();
            Object value = condition.get(key);
            String keyValue;

            if (value == null) {
                continue;
            }
            if (value instanceof String && "".equals((String) value)) {
                continue;
            }

            keyValue = key + "=" + value;
            if (count > 0) {
                sb.append(",");
            }
            sb.append(keyValue);

            count++;
        }

        return String.valueOf(sb);
    }

    /**
     * 指定した文字列が注番(半角7byte)として整合性がある文字列であるかをチェック
     *
     * @param ono
     */
    public static boolean isCheckAnkenOno(String ono) {
        if (StringUtil.isEmpty(ono)) {
            return false;
        }

        int iLen = ono.length();
        byte[] byteLen = ono.getBytes();

        // 文字数の倍＝バイト数　または　空文字
        if (iLen != byteLen.length) {
            return false;
        }

        if (iLen != 7) {
            return false;
        }

        return true;
    }

    public static Integer uriageYmCompare(String baseYm, String uriageYm) {
        String wkBaseYm = StringUtils.replace(baseYm, "/", "");
        String wkUriageYm = StringUtils.replace(uriageYm, "/", "");

        if (wkBaseYm.compareTo(wkUriageYm) > 0) {
            return 1;
        } else {
            return 0;
        }
    }

    public static Integer uriageYmCompare(String baseYm, String uriageYm, int addYear) {

        String wkBaseYm = StringUtils.replace(baseYm, "/", "");
        String wkUriageYm = addYear(StringUtils.replace(uriageYm, "/", ""), addYear);

        if (wkBaseYm.compareTo(wkUriageYm) > 0) {
            return 1;
        } else {
            return 0;
        }
    }

    public static String addYear(String ym, int addYear) {
        Calendar calendar = Calendar.getInstance();
        calendar.set(Integer.valueOf(ym.substring(0, 4)), Integer.valueOf(ym.substring(4, ym.length())) - 1, 1);
        calendar.add(Calendar.YEAR, addYear);
        int month = calendar.get(Calendar.MONTH) + 1;
        return calendar.get(Calendar.YEAR) + String.valueOf((month < 10 ? "0" + month : month));
    }

    public static String addMonth(String ym, int addMonth) {
        Calendar calendar = Calendar.getInstance();
        calendar.set(Integer.valueOf(ym.substring(0, 4)), Integer.valueOf(ym.substring(4, ym.length())) - 1, 1);
        calendar.add(Calendar.MONTH, addMonth);
        int month = calendar.get(Calendar.MONTH) + 1;
        return calendar.get(Calendar.YEAR) + String.valueOf((month < 10 ? "0" + month : month));
    }

    /**
     * 案件が外貨かどうかを判別<br/>
     * false : 円貨<br/>
     * true : 外貨
     *
     * @param currency
     * @return flg
     */
    public boolean isGaika(String currency) {
        boolean flg = false;
        //if (currency != null && !"".equals(currency) && !"JPY".equals(currency)) {
        if (currency != null && !"".equals(currency) && !ConstantString.currencyCodeEn.equals(currency)) {
            flg = true;
        }
        return flg;
    }

    /**
     * カテゴリコードが一括見込NETであるかを判定
     */
    public boolean isIkkatsuCategoryCode(String categoryCode) {
        if (ConstantString.ikkatsuCategoryCode.equals(categoryCode)) {
            return true;
        } else {
            return false;
        }
    }

    /**
     * 予算ベース　予算期を演算する。
     *
     * @param _yosanki
     * @param _addCount
     * @return
     */
    public static String addYosanKi(String _yosanki, int _addCount) {
        if (StringUtils.isEmpty(_yosanki)) {
            return _yosanki;
        }
        String yosanki = StringUtils.defaultString(_yosanki);
        String nendo = StringUtils.substring(yosanki, 0, 4);
        String nowKi = StringUtils.substring(yosanki, 4, 5);
        String nowCount = StringUtils.substring(yosanki, 5, 6);

        if (!StringUtils.isNumeric(nowCount)) {
            return _yosanki;
        }

        Integer newCount = (new Integer(nowCount)) + _addCount;
        if (newCount < 0) {
            return "";
        }

        nowCount = newCount.toString();

        yosanki = nendo + nowKi + nowCount;

        return yosanki;
    }

    /**
     * 勘定月、予算期より、基準年月に変換する。 年月(YYYYMM)を渡した場合はそのまま返す。
     * 予算期(2015K0,2015K1,2015S0,2015S1,2015S2...等)を渡した場合は、対象の期の期初月を戻す。
     * 5桁目がK(上期)かS(下期)かで判断する 例:2015K0,2015K1→201504 2015S0,2015S1→201510
     *
     * @param kanjyoYm
     * @return
     */
    public static String getChangeBaseYm(String kanjyoYm) {
        if (StringUtils.isEmpty(kanjyoYm)) {
            return "";
        }

        String baseYm = "";
        String ki = StringUtils.substring(kanjyoYm, 4, 5);
        if ("K".equals(ki) || "S".equals(ki)) {
            String[] monthAry = getKikanMonthAry(StringUtils.substring(kanjyoYm, 0, 5));
            baseYm = monthAry[0];
        } else {
            baseYm = kanjyoYm;
        }

        return baseYm;
    }

    /**
     * 指定年月の(4半期表記)を取得 例:201504～201506 → 201506Q、201507～201509 →
     * 201509Q、201510～201512 → 201512Q、201601～201603 → 201603Q
     *
     * @param date
     * @return
     */
    public static String getTargetQuarterLabel(Date date) {
        String ym = DateFormatUtils.format(date, "yyyyMM");
        return getTargetQuarterLabel(ym);
    }

    public static String getTargetQuarterLabel(String ym) {
        Integer year = getIntegerYear(ym);
        Integer month = getIntegerMonth(ym);
        String qLabel = "";
        if (month >= 4 && month <= 6) {
            qLabel = "06Q";
        } else if (month >= 7 && month <= 9) {
            qLabel = "09Q";
        } else if (month >= 10 && month <= 12) {
            qLabel = "12Q";
        } else if (month >= 1 && month <= 3) {
            qLabel = "03Q";
        }
        return year + qLabel;
    }
    
    /**
     * 四半期ラベルに変換
     * @param ym
     * @return 
     */
    public static String getChangeQLabel(String ym) {
        String qLabel = SyuuekiUtils.getTargetQuarterLabel(ym);
        String year = StringUtils.substring(qLabel, 0, 4);
        String q = StringUtils.substring(qLabel, 4, 6);
        if ("06".equals(q)) {
            q = "1Q";
        } else if ("09".equals(q)) {
            q = "2Q";
        } else if ("12".equals(q)) {
            q = "3Q";
        } else if ("03".equals(q)) {
            year = String.valueOf(Integer.parseInt(year) - 1);
            q = "4Q";
        }
        return year + "/" + q;
    }

    /**
     * 指定した年月(yyyyMM) or 4半期ラベル(yyyyMM+"Q")の月配列を取得 例:201506[Q]: →
     * {201504,201505,201506}、201509[Q] → {201507,201508,201509}、201512[Q] →
     * {201510,201511,201512}、201603[Q] → {201601,201602,201603}
     *
     * @param qLabel
     * @return
     */
    public static String[] getQuarterMonthAry(String qLabel) {
        if (StringUtils.isEmpty(qLabel)) {
            return null;
        }

        String ym = StringUtils.replace(qLabel, "/", null);
        ym = StringUtils.replace(qLabel, "-", null);
        Integer year = getIntegerYear(qLabel);
        Integer month = getIntegerMonth(qLabel);

        int startMonth = 1;
        int endMonth = 1;
        if (!(month >= 1 && month <= 12)) {
            return null;
        }

        List<String> monthList = new ArrayList<>();
        if (month >= 4 && month <= 6) {
            startMonth = 4;
            endMonth = 6;
        } else if (month >= 7 && month <= 9) {
            startMonth = 7;
            endMonth = 9;
        } else if (month >= 10 && month <= 12) {
            startMonth = 10;
            endMonth = 12;
        } else if (month >= 1 && month <= 3) {
            startMonth = 1;
            endMonth = 3;
        }

        for (int m = startMonth; m <= endMonth; m++) {
            int addMonth = m;
            monthList.add(year + (addMonth < 10 ? ("0" + String.valueOf(addMonth)) : String.valueOf(addMonth)));
        }

        String[] monthAry = (String[]) monthList.toArray(new String[0]);
        return monthAry;
    }

    /**
     * 指定した4半期ラベル(yyyyMM+"Q")四半期の演算を行う。
     *
     * @param qLabel
     * @return
     */
    public static String calaQuarter(String qLabel, int add) {
        Integer year = getIntegerYear(qLabel);
        Integer month = getIntegerMonth(qLabel);
        String q = StringUtils.substring(qLabel, 6);

        if (!((month >= 1 && month <= 12) && "Q".equals(q))) {
            return null;
        }

        if (add > 0) {
            for (int i = 0; i < add; i++) {
                month = month + 3;
                if (month > 12) {
                    year = year + 1;
                    month = 3;
                }
            }

        } else {
            for (int i = add; i < 0; i++) {
                month = month - 3;
                if (month <= 0) {
                    year = year - 1;
                    month = 12;
                }
            }

        }

        String strMonth = month < 10 ? ("0" + String.valueOf(month)) : String.valueOf(month);
        return year + strMonth + q;
    }

    /**
     * 見積種類のラベルを取得
     *
     * @param mitumoriKbn
     * @return
     */
    public String getMitumoriKbnLabel(String mitumoriKbn) {
        String value = null;
        if (StringUtil.isNotEmpty(mitumoriKbn)) {
            if (mitumoriKbn.equals("Y")) {
                value = Label.getValue(Label.yosan);
            } else if (mitumoriKbn.equals("T")) {
                value = Label.getValue(Label.yosanTehai3);
            } else if (mitumoriKbn.equals("S")) {
                value = Label.getValue(Label.seishiki);
            } else if (mitumoriKbn.equals("K")) {
                value = Label.getValue(Label.seishikiTehai);
            }
        }
        return value;
    }

    /**
     * ISP区分のラベルを取得
     *
     * @param ispKbn
     * @return
     */
    public String getIspKbnLabel(String ispKbn) {
        String value = null;
        if (StringUtil.isNotEmpty(ispKbn)) {
            if (ispKbn.equals("0")) {
                value = Label.getValue(Label.ispKbn0);
            } else if (ispKbn.equals("1")) {
                value = Label.getValue(Label.ispKbn1);
            } else if (ispKbn.equals("2")) {
                value = Label.getValue(Label.ispKbn2);
            }
        }
        return value;
    }

    /**
     * 取扱店を表示形式に変更
     *
     * @param toriatsu 取扱店(名)
     * @return
     */
    public String getToriatsuName(String toriatsu) {
        String resultToriatsuNm = StringUtils.defaultString(toriatsu);
        if (StringUtils.isEmpty(resultToriatsuNm)) {
            resultToriatsuNm = Label.toriatsuTyoku.getLabel();
        }
        return resultToriatsuNm;
    }

    public String exeFormatUnitRate(BigDecimal value, String currency) {
        String returnValue;

        if (value == null) {
            return "";
        }

        if (ConstantString.currencyCodeEn.equals(currency)) {
            // 円貨の場合
            returnValue = exeFormatUnit(value);
        } else {
            // 外貨の場合
            DecimalFormat foreignUnitDf = new DecimalFormat(dateFormatDefin.getForeignUnitFmt());
            returnValue = foreignUnitDf.format(value.setScale(3, BigDecimal.ROUND_HALF_UP));
        }

        return returnValue;
    }
    
    /**
     * 金種ラベルの取得
     * @param kinsyuKbn
     * @return
     */
    public String getLabelKinsyuKbn(String kinsyuKbn) {
        String value = null;
        if (StringUtil.isNotEmpty(kinsyuKbn)) {
            if ("1".equals(kinsyuKbn)) {
                value = Label.genkin.getLabel();
            } else if ("2".equals(kinsyuKbn)) {
                value = Label.tegata.getLabel();
            }
        }
        return value;
    }
    
    /**
     * 回収区分ラベルの取得
     * @param kaisyuKbn
     * @return
     */
    public String getLabelKaisyuKbn(String kaisyuKbn) {
        String value = null;
        if (StringUtil.isNotEmpty(kaisyuKbn)) {
            if ("0".equals(kaisyuKbn)) {
                value = Label.normal.getLabel();
            } else if ("1".equals(kaisyuKbn)) {
                value = Label.maeuke.getLabel();
            }
        }
        return value;
    }

    /**
     *項番フォーマットチェック
     * @param chkStr
     * @return 真：true　偽：false
     */
    public static boolean isformatKouban(String chkStr){
    
    //4ケタ以下の場合はエラーとする。
    if(chkStr.length()<4){
        return false;
    }
    Pattern p = Pattern.compile("^[0-9]{4}[A-Z\\s]+$"); //先頭4ケタが数値で末尾が半角空白か大文字英数字のみ
    Matcher m = p.matcher(chkStr);
    return m.find();
        
    }

    
    
     /**
     * @param chkStr
     * @return 真：半角英数字のみ　偽：半角英数字以外を含む
     */
    public static boolean isAlphabetNum(String chkStr){
        Pattern p = Pattern.compile("^[0-9A-Z]+$");
        Matcher m = p.matcher(chkStr);
        return m.find();
    }
    /**
     * @param chkStr
     * @return 真：半角英数字のみ　偽：半角英数字以外を含む
     */
    public static boolean isNum(String chkStr){
        Pattern p = Pattern.compile("^[0-9]+$");
        Matcher m = p.matcher(chkStr);
        return m.find();
    }
    /**
     * 
     * @param chkStr
     * @return 真：半角英数字、空白文字のみ　偽：半角英数字以外を含む
     */
    public static boolean isAlphabetNumSpace(String chkStr){
        
        
        
        Pattern p = Pattern.compile("^[A-Z\\s]+$");
        Matcher m = p.matcher(chkStr);
        return m.find();
    }
}
