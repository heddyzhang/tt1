package jp.co.toshiba.hby.pspromis.syuueki.bean;

import java.util.List;
import java.util.Map;
import javax.enterprise.context.RequestScoped;
import javax.inject.Named;
import jp.co.toshiba.hby.pspromis.syuueki.entity.SyuSearchPatternTbl;
import lombok.Getter;
import lombok.Setter;

/**
 *
 * @author 
 */
@Named(value = "s021Bean")
@RequestScoped
@Getter @Setter
public class S021Bean {

    /**
     * 画面表示区分(0:検索パターン追加 1:検索パターン整理)
     */
    private String dispKbn;
    
    /**
     * 画面名称
     */
    private String dispName;
    
    /**
     * 検索パターンを登録する画面ID
     */
    private String displayId;

    /**
     * 検索対象のパターンSEQ
     */
    private String patternSeq;

    /**
     * 登録を行うパターン名
     */
    private String newPatternName;

    /**
     * 表示するパターン名称一覧
     */
    private List<SyuSearchPatternTbl> dispPatternList;

    /**
     * パターン一覧の選択index
     */
    private String[] selectedIndex;

    /**
     * 更新対象のパターン名称一覧
     */
    private List<Map<String, String>> updatePatternList;

    /**
     * 登録対象の検索条件項目名＋項目値一覧
     */
    private List<Map<String, String>> conditionList;
    
}
