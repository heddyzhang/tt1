/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package jp.co.toshiba.hby.pspromis.syuueki.jdbc;

import java.io.ByteArrayOutputStream;
import java.io.Closeable;
import java.io.IOException;
import java.io.InputStream;
import java.util.Arrays;
import jp.co.toshiba.hby.pspromis.common.exception.PspRunTimeExceotion;
import jp.co.toshiba.hby.pspromis.common.jdbc.ClasspathSqlResource;
import jp.co.toshiba.hby.pspromis.common.jdbc.SqlResource;
import jp.co.toshiba.hby.pspromis.common.jdbc.bean.BeanDesc;
import jp.co.toshiba.hby.pspromis.common.jdbc.bean.BeanDescFactory;
import jp.co.toshiba.hby.pspromis.common.jdbc.bean.PropertyDesc;
import jp.co.toshiba.hby.pspromis.common.jdbc.paser.Node;
import jp.co.toshiba.hby.pspromis.common.jdbc.paser.SqlContext;
import jp.co.toshiba.hby.pspromis.common.jdbc.paser.SqlContextImpl;
import jp.co.toshiba.hby.pspromis.common.jdbc.paser.SqlParserImpl;
import org.apache.commons.lang3.StringUtils;

/**
 *
 * @author ibayashi
 */
public class SqlFile {
    
    public SqlContext getSqlContext(Object param) {
        SqlContext context = new SqlContextImpl();

        if (param != null) {
            BeanDesc beanDesc = BeanDescFactory.getBeanDesc(param);
            for (int i = 0; i < beanDesc.getPropertyDescSize(); i++) {
                PropertyDesc pd = beanDesc.getPropertyDesc(i);
                context.addArg(pd.getPropertyName(), pd.getValue(param), pd
                        .getPropertyType());
            }
        }

        return context;
    }
    
    public byte[] readStream(InputStream in) {
        if (in == null) {
            return null;
        }
        ByteArrayOutputStream out = null;
        try {
            out = new ByteArrayOutputStream();
            byte[] buf = new byte[1024 * 8];
            int length = 0;
            while ((length = in.read(buf)) != -1) {
                out.write(buf, 0, length);
            }
        } catch (IOException e) {
           throw new PspRunTimeExceotion(e);
        } finally {
            closeQuietly(in);
            closeQuietly(out);
        }
        return out.toByteArray();
    }
    
    public static void closeQuietly(Closeable closeable) {
        if (closeable != null) {
            try {
                closeable.close();
            } catch (IOException ex) {
                // ignore
            }
        }
    }
    
    protected Node prepareNode(SqlResource resource) {
        String sql;
        try {
            InputStream in = resource.getInputStream();
            if (in == null) {
                throw new RuntimeException(String.format("resource: %s is not found.", resource));
            }
            sql = new String(readStream(in), "UTF-8");
        } catch (IOException | RuntimeException ex) {
            throw new PspRunTimeExceotion(ex);
        }
        sql = sql.trim();
        if (sql.endsWith(";")) {
            sql = sql.substring(0, sql.length() - 1);
        }
        Node node = new SqlParserImpl(sql).parse();
        return node;
    }
    
    public Object[] getSqlParams(String sql, Object param) {
        Node node = prepareNode(new ClasspathSqlResource(sql));
        SqlContext context = getSqlContext(param);
        node.accept(context);
        
        return context.getBindVariables();
    }
    
    public String getSqlString(String sql, Object param) {
        Node node = prepareNode(new ClasspathSqlResource(sql));
        SqlContext context = getSqlContext(param);
        node.accept(context);
        context.getSql();
        return context.getSql();
    }

    public String getSqlWhereString(String sql, Object param) {
        String sqlString = this.getSqlString(sql, param);
        sqlString = StringUtils.upperCase(sqlString);
        
        int startWhereIndex = sqlString.indexOf("WHERE");
        int endWhereIndex = sqlString.indexOf("ORDER BY");
        
        if (startWhereIndex < 0) {
            return "";
        }

        if (endWhereIndex < 0) {
            sqlString = StringUtils.substring(sqlString, startWhereIndex);
        } else {
            sqlString = StringUtils.substring(sqlString, startWhereIndex, endWhereIndex);
        }

        return sqlString;
    }
    
    public Object[] getSqlWhereParam(String sql, Object param) {
        String sqlString = this.getSqlString(sql, param);
        Object[] paramsAry = this.getSqlParams(sql, param);
        
        int fromStartIndex = sqlString.indexOf("FROM");
        String selectString = StringUtils.substring(sqlString, 0, fromStartIndex);
 
        int selectParamCount = selectString.replaceAll("[^?]", "").length();
        int beforeWhereParamCount = selectParamCount;

        for (Object p : paramsAry) {
            System.out.println("p=" + p);
        }
        
        System.out.println("beforeWhereParamCount=" + beforeWhereParamCount + " length=" + paramsAry.length);
        Object[] whereParams = Arrays.copyOfRange(paramsAry, beforeWhereParamCount, paramsAry.length);
        
        for (Object p : whereParams) {
            System.out.println("p2=" + p);
        }
        
        return whereParams;
    }
}
