package jp.co.toshiba.hby.pspromis.syuueki.bean;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import javax.enterprise.context.SessionScoped;
import javax.inject.Named;

/**
 *
 * @author ibayashi
 */
@Named(value = "mikomiUploadErrorBean")
@SessionScoped
public class MikomiUploadErrorBean implements Serializable {

    /**
     * 処理結果Flg(true:成功 false:失敗)
     */
    private boolean isSuccess;
    
    /**
     * 見込アップロード結果のタイトル名
     */
    private String titleInfo;
    
    /**
     * アップロードを行った案件/注番数
     */
    private Integer uploadDataCount;

    /**
     * 出力メッセージ一覧(正常データ)
     */
    private List<String> resultMessage;

    /**
     * 出力メッセージ一覧(エラーデータ)
     */
    private List<String> errorMessage;
    
    public Integer getUploadDataCount() {
        return uploadDataCount;
    }

    public void setUploadDataCount(Integer uploadDataCount) {
        this.uploadDataCount = uploadDataCount;
    }

    public List<String> getResultMessage() {
        return resultMessage;
    }
    
    public List<String> getErrorMessage() {
        return errorMessage;
    }
/*
    public void setResultMessage(List<String> resultMessage) {
        this.resultMessage = resultMessage;
    }
*/
    public boolean isIsSuccess() {
        return isSuccess;
    }

    public void setIsSuccess(boolean isSuccess) {
        this.isSuccess = isSuccess;
    }

    public void addMessage(String message) {
        if (resultMessage == null) {
            resultMessage = new ArrayList<>();
        }
        resultMessage.add(message);
    }
    
    public void addErrorMessage(String message) {
        if (errorMessage == null) {
            errorMessage = new ArrayList<>();
        }
        errorMessage.add(message);
    }
    
    public void clearMessage() {
        resultMessage = null;
        errorMessage = null;
    }

    public String getTitleInfo() {
        return titleInfo;
    }

    public void setTitleInfo(String titleInfo) {
        this.titleInfo = titleInfo;
    }

}
