package jp.co.toshiba.hby.pspromis.syuueki.entity;

import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

/**
 *
 * @author ganryu
 */
@Entity
public class SyokusyuMstView implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 10)
    @Column(name = "JGRP_ID")
    private String jgrpId;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 10)
    @Column(name = "MEMBER_ID")
    @Id
    private String memberId;
    @Size(max = 84)
    @Column(name = "MEMBER_NAME")
    private String memberName;

    public String getJgrpId() {
        return jgrpId;
    }

    public void setJgrpId(String jgrpId) {
        this.jgrpId = jgrpId;
    }

    public String getMemberId() {
        return memberId;
    }

    public void setMemberId(String memberId) {
        this.memberId = memberId;
    }

    public String getMemberName() {
        return memberName;
    }

    public void setMemberName(String memberName) {
        this.memberName = memberName;
    }

}
