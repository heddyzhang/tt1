package jp.co.toshiba.hby.pspromis.syuueki.util;

import java.util.Date;
import jp.co.toshiba.hby.pspromis.common.util.BeanUtil;

/**
 * エンティティ操作
 * @author ibayashi
 */
public class EntityUtils {

    /**
     * 指定したentityに作成者,作成日をセット
     * @param obj
     * @param userId
     */
    public static void setCreatedInfo(Object obj, String userId) {
        Date now = new Date();
        BeanUtil.setProperty(obj, "createdBy", userId);
        BeanUtil.setProperty(obj, "createdAt", now);
        BeanUtil.setProperty(obj, "updatedBy", userId);
        BeanUtil.setProperty(obj, "updatedAt", now);
    }
  
    /**
     * 指定したentityに更新者,作成日をセット
     * @param obj
     * @param userId
     */
    public static void setUpdatedInfo(Object obj, String userId) {
        Date now = new Date();
        BeanUtil.setProperty(obj, "updatedBy", userId);
        BeanUtil.setProperty(obj, "updatedAt", now);
    }

}
