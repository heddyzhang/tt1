package jp.co.toshiba.hby.pspromis.syuueki.facade;

import java.util.List;
import java.util.Map;
import java.util.HashMap;
import javax.ejb.Stateless;
import javax.interceptor.Interceptors;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import jp.co.toshiba.hby.pspromis.common.util.BeanUtil;
import jp.co.toshiba.hby.pspromis.syuueki.entity.SyuKiLossTbl;
import jp.co.toshiba.hby.pspromis.syuueki.entity.KsLossData;
import jp.co.toshiba.hby.pspromis.syuueki.interceptor.TranceInterceptor;
import org.apache.commons.collections4.CollectionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * ロスコン情報TBL
 *
 * @author ibayashi
 */
@Stateless
@Interceptors({TranceInterceptor.class})
public class SyuKiLossTblFacade extends AbstractFacade<SyuKiLossTbl> {
    private static final Logger logger = LoggerFactory.getLogger(SyuKiLossTblFacade.class);

    @PersistenceContext(unitName = jp.co.toshiba.hby.pspromis.syuueki.util.ConstantString.syuuekiDataSourceName)
    private EntityManager em;

    @Override
    protected EntityManager getEntityManager() {
        return em;
    }

    public SyuKiLossTblFacade() {
        super(SyuKiLossTbl.class);
    }

    public void merge(SyuKiLossTbl facade) {
        this.em.merge(BeanUtil.createAndCopy(SyuKiLossTbl.class, facade));
    }

    /**
     * コピー(複写)対象の通貨/レート/契約金額一覧を取得
     * @param ankenId
     * @param rirekiId
     * @param dataKbn
     * @param syuekiYm
     * @param rirekiFlg
     * @return 
     */
    public SyuKiLossTbl findLossTblPk(String ankenId, Integer rirekiId, String dataKbn, String syuekiYm, String rirekiFlg) {
        Map<String, Object> collection = new HashMap<>();
        collection.put("ankenId", ankenId);
        collection.put("rirekiId", rirekiId);
        collection.put("dataKbn", dataKbn);
        collection.put("syuekiYm", syuekiYm);
        collection.put("rirekiFlg", rirekiFlg);
        
        List<SyuKiLossTbl> list = sqlExecutor.getResultList(em, SyuKiLossTbl.class, "/sql/syuKiLossTbl/selectKiLossTblPk.sql", collection);
        SyuKiLossTbl entity = null;
        if (CollectionUtils.isNotEmpty(list)) {
            entity = list.get(0);
        }
        return entity;
    }

    /**
     * 期間損益(進行・原価)画面でのロスコン関連情報の取得<br>
     * 1行分の情報(ロスコン補正 or 補正後の売上原価(今回) or ロスコン引当(今回) or ロスコン引当(累計))を取得
     * @param condition SQLパラメータ(期間損益(進行・原価)出力用専用の条件
     * @return 
     */
    public KsLossData findKsLossInfoData(Map<String, Object> condition) {
        logger.info("SyuKiLossTblFacade#findLossInfoData");
        
        KsLossData entity;
        List<KsLossData> list = sqlExecutor.getResultList(em, KsLossData.class, "/sql/S004/selectKsLossData.sql", condition);
        if (CollectionUtils.isNotEmpty(list)) {
            entity = list.get(0);
        } else {
            entity = new KsLossData();
        }
        
        return entity;
    }

}
