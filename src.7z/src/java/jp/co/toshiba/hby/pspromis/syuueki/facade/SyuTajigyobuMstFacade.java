package jp.co.toshiba.hby.pspromis.syuueki.facade;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.ejb.Stateless;
import javax.interceptor.Interceptors;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import jp.co.toshiba.hby.pspromis.syuueki.entity.SyuTajigyobuMst;
import jp.co.toshiba.hby.pspromis.syuueki.interceptor.TranceInterceptor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 *
 * @author ganryu
 */
@Stateless
@Interceptors({TranceInterceptor.class})
public class SyuTajigyobuMstFacade extends AbstractFacade<SyuTajigyobuMst> {

    private static final Logger logger = LoggerFactory.getLogger(SyuTajigyobuMst.class);

    @PersistenceContext(unitName = jp.co.toshiba.hby.pspromis.syuueki.util.ConstantString.syuuekiDataSourceName)
    private EntityManager em;

    @Override
    protected EntityManager getEntityManager() {
        return em;
    }

    public SyuTajigyobuMstFacade() {
        super(SyuTajigyobuMst.class);
    }

    /**
     *
     * @param divisionCode
     * @return
     */
    public List<SyuTajigyobuMst> getDivisionRnmList(String divisionCode) {
        logger.info("SyuTajigyobuMstFacade#getDivisionRnmList");
        Map<String, Object> condition = new HashMap<>();
        condition.put("divisionCode", divisionCode);

        List<SyuTajigyobuMst> list = sqlExecutor.getResultList(em, SyuTajigyobuMst.class, "/sql/syuTajigyobuMst/selectDivisionRnmList.sql", condition);

        return list;
    }

    /**
     *
     * @param divisionCode
     * @return
     */
    public SyuTajigyobuMst getDivisionRnm(String divisionCode) {
        logger.info("SyuTajigyobuMstFacade#getDivisionRnm");
        Map<String, Object> condition = new HashMap<>();
        condition.put("divisionCode", divisionCode);

        return sqlExecutor.getSingleResult(em, SyuTajigyobuMst.class, "/sql/syuTajigyobuMst/selectDivisionRnmList.sql", condition);
    }
}
