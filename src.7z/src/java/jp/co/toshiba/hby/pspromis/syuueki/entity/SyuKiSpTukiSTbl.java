/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package jp.co.toshiba.hby.pspromis.syuueki.entity;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

/**
 *
 * @author masaki
 */
@Entity
@Table(name = "SYU_KI_SP_TUKI_S_TBL")
@NamedQueries({
    @NamedQuery(name = "KiSpTukiSTbl.findPk", query = "SELECT s FROM SyuKiSpTukiSTbl s "
            + "where s.ankenId = :ankenId "
            + "and s.rirekiId = :rirekiId "
            + "and s.dataKbn = :dataKbn "
            + "and s.currencyCode = :currencyCode "
            + "and s.syuekiYm = :syuekiYm ")
})
public class SyuKiSpTukiSTbl implements Serializable {
    private static final long serialVersionUID = 1L;
        
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 32)
    @Column(name = "ANKEN_ID")
    @Id
    private String ankenId;
    @Basic(optional = false)
    @NotNull
    @Column(name = "RIREKI_ID")
    @Id
    private int rirekiId;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 2)
    @Column(name = "DATA_KBN")
    @Id
    private String dataKbn;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 3)
    @Column(name = "CURRENCY_CODE")
    @Id
    private String currencyCode;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 7)
    @Column(name = "SYUEKI_YM")
    @Id
    private String syuekiYm;
    @Column(name = "URI_RATE")
    private BigDecimal uriRate;
    @Column(name = "KEIYAKU_AMOUNT")
    private BigDecimal keiyakuAmount;
    @Column(name = "KEIYAKU_HOSEI_AMOUNT")
    private BigDecimal keiyakuHoseiAmount;
    @Column(name = "KEIYAKU_ENKA_AMOUNT")
    private BigDecimal keiyakuEnkaAmount;
    @Column(name = "URIAGE_AMOUNT")
    private BigDecimal uriageAmount;
    @Column(name = "URIAGE_KAWASESA")
    private BigDecimal uriageKawasesa;
    @Column(name = "URIAGE_ENKA_AMOUNT")
    private BigDecimal uriageEnkaAmount;
    @Column(name = "URIAGE_RUIKEI_AMOUNT")
    private BigDecimal uriageRuikeiAmount;
    @Column(name = "URIAGE_RUIKEI_ENKA_AMOUNT")
    private BigDecimal uriageRuikeiEnkaAmount;
    @Column(name = "CREATED_AT")
    @Temporal(TemporalType.TIMESTAMP)
    private Date createdAt;
    @Size(max = 32)
    @Column(name = "CREATED_BY")
    private String createdBy;
    @Column(name = "UPDATED_AT")
    @Temporal(TemporalType.TIMESTAMP)
    private Date updatedAt;
    @Size(max = 32)
    @Column(name = "UPDATED_BY")
    private String updatedBy;
    @Column(name = "UPDATED_BATCH_AT")
    @Temporal(TemporalType.DATE)
    private Date updatedBatchAt;
    @Size(max = 32)
    @Column(name = "UPDATED_BATCH_BY")
    private String updatedBatchBy;
    
    public SyuKiSpTukiSTbl() {
    }
    
    public String getAnkenId() {
        return ankenId;
    }

    public void setAnkenId(String ankenId) {
        this.ankenId = ankenId;
    }

    public int getRirekiId() {
        return rirekiId;
    }

    public void setRirekiId(int rirekiId) {
        this.rirekiId = rirekiId;
    }

    public String getDataKbn() {
        return dataKbn;
    }

    public void setDataKbn(String dataKbn) {
        this.dataKbn = dataKbn;
    }

    public String getCurrencyCode() {
        return currencyCode;
    }

    public void setCurrencyCode(String currencyCode) {
        this.currencyCode = currencyCode;
    }

    public String getSyuekiYm() {
        return syuekiYm;
    }

    public void setSyuekiYm(String syuekiYm) {
        this.syuekiYm = syuekiYm;
    }

    public BigDecimal getUriRate() {
        return uriRate;
    }

    public void setUriRate(BigDecimal uriRate) {
        this.uriRate = uriRate;
    }

    public BigDecimal getKeiyakuAmount() {
        return keiyakuAmount;
    }

    public void setKeiyakuAmount(BigDecimal keiyakuAmount) {
        this.keiyakuAmount = keiyakuAmount;
    }

    public BigDecimal getKeiyakuHoseiAmount() {
        return keiyakuHoseiAmount;
    }

    public void setKeiyakuHoseiAmount(BigDecimal keiyakuHoseiAmount) {
        this.keiyakuHoseiAmount = keiyakuHoseiAmount;
    }

    public BigDecimal getKeiyakuEnkaAmount() {
        return keiyakuEnkaAmount;
    }

    public void setKeiyakuEnkaAmount(BigDecimal keiyakuEnkaAmount) {
        this.keiyakuEnkaAmount = keiyakuEnkaAmount;
    }

    public BigDecimal getUriageAmount() {
        return uriageAmount;
    }

    public void setUriageAmount(BigDecimal uriageAmount) {
        this.uriageAmount = uriageAmount;
    }

    public BigDecimal getUriageKawasesa() {
        return uriageKawasesa;
    }

    public void setUriageKawasesa(BigDecimal uriageKawasesa) {
        this.uriageKawasesa = uriageKawasesa;
    }

    public BigDecimal getUriageEnkaAmount() {
        return uriageEnkaAmount;
    }

    public void setUriageEnkaAmount(BigDecimal uriageEnkaAmount) {
        this.uriageEnkaAmount = uriageEnkaAmount;
    }

    public BigDecimal getUriageRuikeiAmount() {
        return uriageRuikeiAmount;
    }

    public void setUriageRuikeiAmount(BigDecimal uriageRuikeiAmount) {
        this.uriageRuikeiAmount = uriageRuikeiAmount;
    }

    public BigDecimal getUriageRuikeiEnkaAmount() {
        return uriageRuikeiEnkaAmount;
    }

    public void setUriageRuikeiEnkaAmount(BigDecimal uriageRuikeiEnkaAmount) {
        this.uriageRuikeiEnkaAmount = uriageRuikeiEnkaAmount;
    }

    public Date getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(Date createdAt) {
        this.createdAt = createdAt;
    }

    public String getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    public Date getUpdatedAt() {
        return updatedAt;
    }

    public void setUpdatedAt(Date updatedAt) {
        this.updatedAt = updatedAt;
    }

    public String getUpdatedBy() {
        return updatedBy;
    }

    public void setUpdatedBy(String updatedBy) {
        this.updatedBy = updatedBy;
    }

    public Date getUpdatedBatchAt() {
        return updatedBatchAt;
    }

    public void setUpdatedBatchAt(Date updatedBatchAt) {
        this.updatedBatchAt = updatedBatchAt;
    }

    public String getUpdatedBatchBy() {
        return updatedBatchBy;
    }

    public void setUpdatedBatchBy(String updatedBatchBy) {
        this.updatedBatchBy = updatedBatchBy;
    }


}
