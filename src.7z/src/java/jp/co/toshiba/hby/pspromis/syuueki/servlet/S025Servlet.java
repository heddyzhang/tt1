package jp.co.toshiba.hby.pspromis.syuueki.servlet;

import java.util.HashMap;
import java.util.Map;
import javax.inject.Inject;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import jp.co.toshiba.hby.pspromis.syuueki.bean.ResultMessageBean;
import jp.co.toshiba.hby.pspromis.syuueki.bean.S025Bean;
import jp.co.toshiba.hby.pspromis.syuueki.service.S025Service;
import jp.co.toshiba.hby.pspromis.syuueki.util.CdiUtils;
import jp.co.toshiba.hby.pspromis.syuueki.util.ParameterBinder;

/**
 * PS-Promis収益管理システム
 * 注文主選択 Servlet
 * @author (NPC)S.horie
 */
@WebServlet(name="S025", urlPatterns={"/servlet/S025", "/servlet/S025/*"})
public class S025Servlet extends AbstractServlet {

    /**
     * jsp
     */
    private static final String INDEX_JSP = "S025/s025.jsp";

    /**
     * 使用serviceクラスをinjection(CDI)<br>
     * InjectアノテーションよりAPサーバー(Glassfish)側で自動的にインスタンス作成(new)される。<br>
     * service側はステートレスセッションbeanにするため、Statelessアノテーションをつけておくこと。<br>
     */
    @Inject
    private S025Service s025Service;

    /**
     * パラメータ格納クラスをinjection(CDI)<br>
     * InjectアノテーションよりAPサーバー(Glassfish)側で自動的にインスタンス作成(new)される。<br>
     */
    @Inject
    private S025Bean s025Bean;

    /**
     * 初期表示
     * @param req
     * @param resp
     * @return
     * @throws Exception
     */
    public String indexAction(HttpServletRequest req, HttpServletResponse resp) throws Exception {
        logger.info("S025Servlet#indexAction");

        // リクエストパラメータをS025Beanの同名フィールドに一括コピー
        ParameterBinder.Bind(s025Bean, req);

        s025Service.indexExecute();

        return INDEX_JSP;
    }

    /**
     * 保存(実行)処理
     * @param req
     * @param resp
     * @return
     * @throws Exception
     */
    public String saveAction(HttpServletRequest req, HttpServletResponse resp) throws Exception {
        logger.info("S025Servlet#saveAction");
        // リクエストパラメータをS025Beanの同名フィールドに一括コピー
        ParameterBinder.Bind(s025Bean, req);

        s025Service.saveExecute();

        // 処理結果を戻す。
        Map<String, Object> jsonMap = new HashMap<>();
        ResultMessageBean resultMessageBean = CdiUtils.getBean(ResultMessageBean.class);
        resultMessageBean.createResultMessage(jsonMap);
        resopnseDecodeJson(resp, jsonMap);

        return null;
    }
}
