package jp.co.toshiba.hby.pspromis.syuueki.entity;

import java.io.Serializable;
import java.math.BigDecimal;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import lombok.Getter;
import lombok.Setter;

/**
 *
 * @author ganryu
 */
@Entity
@Getter
@Setter
public class KaisyuList implements Serializable {

    private static final long serialVersionUID = 1L;

    public KaisyuList() {
    }

    @Id
    @Column(name = "ANKEN_ID")
    private String ankenId;
    @Id
    @Column(name = "RIREKI_ID")
    private int rirekiId;
    @Id
    @Column(name = "CURRENCY_CODE")
    private String currencyCode;
    @Column(name = "CURRENCY_CODE_SEQ")
    private String currencyCodeSeq;
    @Column(name = "RUIKEI_KAISYU_AMOUNT")
    private BigDecimal ruikeiKaisyuAmount;
    @Column(name = "KAISYU_AMOUNT")
    private BigDecimal kaisyuAmount;
    @Column(name = "MI_KAISYU_AMOUNT")
    private BigDecimal miKaisyuAmount;
    @Column(name = "KAISYU_RATE")
    private BigDecimal kaisyuRate;

}
