/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package jp.co.toshiba.hby.pspromis.syuueki.service;

import java.io.InputStream;
import java.util.Date;
import javax.ejb.Stateless;
import javax.enterprise.inject.New;
import javax.inject.Inject;
import javax.interceptor.Interceptors;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import jp.co.toshiba.hby.pspromis.syuueki.bean.MikomiUploadBean;
import jp.co.toshiba.hby.pspromis.syuueki.bean.MikomiUploadErrorBean;
import jp.co.toshiba.hby.pspromis.syuueki.entity.OperationLog;
import jp.co.toshiba.hby.pspromis.syuueki.entity.SyuMikomiUpInfoTbl;
import jp.co.toshiba.hby.pspromis.syuueki.enums.Label;
import jp.co.toshiba.hby.pspromis.syuueki.enums.MikomiUploadLabel;
import jp.co.toshiba.hby.pspromis.syuueki.facade.SyuGeBukenInfoTblFacade;
import jp.co.toshiba.hby.pspromis.syuueki.facade.SyuMikomiUpInfoTblFacade;
import jp.co.toshiba.hby.pspromis.syuueki.interceptor.TranceInterceptor;
import jp.co.toshiba.hby.pspromis.syuueki.service.mikomiupload.UploadComponent;
import jp.co.toshiba.hby.pspromis.syuueki.util.LoginUserInfo;
import jp.co.toshiba.hby.pspromis.syuueki.util.PoiUtil;
import jp.co.toshiba.hby.pspromis.syuueki.util.Utils;
import org.apache.commons.fileupload.FileItem;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.time.DateFormatUtils;
import org.apache.poi.ss.usermodel.Workbook;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * PS-Promis収益管理システム
 * 見込アップロード処理用 Service
 * @author sano
 */
@Stateless
@Interceptors({TranceInterceptor.class})
public class MikomiUploadService {

    @PersistenceContext(unitName = jp.co.toshiba.hby.pspromis.syuueki.util.ConstantString.syuuekiDataSourceName)
    private EntityManager em;
    
    @Inject
    private MikomiUploadBean mikomiUploadBean;

    @Inject
    private MikomiUploadErrorBean mikomiUploadErrorBean;
    
    @Inject
    private LoginUserInfo loginUserInfo;

    @Inject
    private SyuMikomiUpInfoTblFacade syuMikomiUpInfoTblFacade;
    
    @Inject
    private SyuGeBukenInfoTblFacade geBukenInfoTblFacade;
    
    @Inject @New(jp.co.toshiba.hby.pspromis.syuueki.service.mikomiupload.KoujoUploadImpl.class)
    private UploadComponent koujoUploadImpl;
    
    @Inject @New(jp.co.toshiba.hby.pspromis.syuueki.service.mikomiupload.IspUploadImpl.class)
    private UploadComponent ispUploadImpl;

    @Inject @New(jp.co.toshiba.hby.pspromis.syuueki.service.mikomiupload.ChokkaUploadImpl.class)
    private UploadComponent chokkaUploadImpl;

    @Inject @New(jp.co.toshiba.hby.pspromis.syuueki.service.mikomiupload.EtcUploadImpl.class)
    private UploadComponent etcUploadImpl;

    @Inject @New(jp.co.toshiba.hby.pspromis.syuueki.service.mikomiupload.BaihatsuUploadImpl.class)
    private UploadComponent baihatsuUploadImpl;

    @Inject @New(jp.co.toshiba.hby.pspromis.syuueki.service.mikomiupload.ShinkoUploadImpl.class)
    private UploadComponent shinkoUploadImpl;

    
    /**
     * Injection OperationLogService
     */
    @Inject
    private OperationLogService operationLogService;
    
    /**
     * ロガー
     */
    public static final Logger logger = LoggerFactory.getLogger(MikomiUploadService.class);

    /**
     * 各見込アップロードファイルに応じた処理クラスを取得
     */
    private UploadComponent getComponent() {
        UploadComponent component = null;
        String kbn = StringUtils.defaultString(mikomiUploadBean.getUploadKbn());
        logger.info("getComponent kbn=" + kbn);
        
        if (kbn.equals("00") || kbn.equals("01") || kbn.equals("02") || kbn.equals("03")) {
            // 工場(京浜),(府),(浜),(三)
            component = koujoUploadImpl;

        } else if (kbn.equals("04")) {
            // （電力ジ）ISP
            component = ispUploadImpl;
            
        } else if (kbn.equals("05")) {
            // (技)直課
            component = chokkaUploadImpl;
            
        } else if (kbn.equals("06") || kbn.equals("07")) {
            // (技)直課除くＢ項番等 or (営業)販直費
            component = etcUploadImpl;
            
        } else if (kbn.equals("08")) {
            // (電力生)売発費
            component = baihatsuUploadImpl;
        } else if (kbn.equals("KSS")) {
            // 期間損益_進行
            component = shinkoUploadImpl;
        }
        
        return component;
    }

    /**
     * アップロード処理の実行
     * @throws java.lang.Exception
     */
    public void executeUpload() throws Exception {

        FileItem upFileItem = mikomiUploadBean.getUploadFile();

        String kbn = StringUtils.defaultString(mikomiUploadBean.getUploadKbn());
        
        // アップロードファイルから、Workbookオブジェクトを生成
        boolean isCreateWorkbook = createWorkbook(upFileItem.getInputStream());
        if (!isCreateWorkbook) {
            return;
        }

        // 期間損益画面以外
        if (!"KSS".equals(kbn)) {
            // 画面から指定した処理開始年月をDateに変換
            String startYmStr = mikomiUploadBean.getStartYear() + mikomiUploadBean.getStartMonth();
            Date startYm = Utils.parseDate(startYmStr);
            mikomiUploadBean.setStartYm(startYm);
        }
        
        // 処理を行うcomponentを取得
        UploadComponent component = getComponent();

        // 処理結果画面のタイトルをセット
        mikomiUploadErrorBean.setTitleInfo(judgeUploadKbn());

        // データ取得/エラーチェック
        boolean isDataCheck = component.isDataCheck();
        isDataCheck = mikomiUploadErrorBean.isIsSuccess();

        if (isDataCheck) {
            // アップロード処理の実行
            component.executeUpload();

            if (!"KSS".equals(kbn)) {
                // 見込アップロード管理テーブル(SYU_MIKOMI_UP_INFO_TBL)の登録/更新
                updateMikomiUpInfo();
            }
            
            // 操作ログの登録
            this.insertOperationLog();
        }

    }

    /**
     * アップロードファイルからWorkbookオブジェクトを生成<br>
     * 作成したWorkbookはbeanにセット
     * @throws java.lang.Exception
     */
    private boolean createWorkbook(InputStream uploadFile) {
        boolean isCreate = true;
        try {
            //System.out.println("uploadFile=" + mikomiUploadBean.getUploadFile());
            //Workbook workbook = PoiUtil.getWorkbook(mikomiUploadBean.getUploadFile());
            Workbook workbook = PoiUtil.getWorkbook(uploadFile);
            mikomiUploadBean.setWorkBook(workbook);
        } catch (Exception e) {
            String errorMessage = MikomiUploadLabel.getValue(MikomiUploadLabel.fileReadError);
            
            logger.error(errorMessage, e);

            mikomiUploadErrorBean.clearMessage();
            mikomiUploadErrorBean.addErrorMessage(errorMessage);
            mikomiUploadErrorBean.setIsSuccess(false);
            
            isCreate = false;
        }

        return isCreate;
    }

    /**
     * 見込アップロード管理テーブルの登録/更新
     */
    private void updateMikomiUpInfo() {
        String kbn = StringUtils.defaultString(mikomiUploadBean.getUploadKbn());
        String div = mikomiUploadBean.getUploadDivisionCode();

        // 当日日付を取得
        //Date now = sysdateEntityFacade.getSysdate();
        
        // 見込アップロード管理テーブルから対象アップロードファイル区分、事業部のデータを取得
        SyuMikomiUpInfoTbl mikomiUpInfoEn = syuMikomiUpInfoTblFacade.getPkInfo(kbn, div);

        if (mikomiUpInfoEn != null) {
            // データが存在する場合は更新(最終更新者id、最終更新日をupdate)
            mikomiUpInfoEn.setLastUpdateBy(loginUserInfo.getUserId());
            //mikomiUpInfoEn.setLastUpdateDate(now);

            //syuMikomiUpInfoTblFacade.edit(mikomiUpInfoEn);
            syuMikomiUpInfoTblFacade.update(mikomiUpInfoEn);
            
        } else {
            // データが存在しない場合は新規登録
            mikomiUpInfoEn = new SyuMikomiUpInfoTbl();
            mikomiUpInfoEn.setDivisionCode(div);
            mikomiUpInfoEn.setKbn(kbn);
            mikomiUpInfoEn.setCreatedBy(loginUserInfo.getUserId());
            //mikomiUpInfoEn.setCreationDate(now);
            mikomiUpInfoEn.setLastUpdateBy(loginUserInfo.getUserId());
            //mikomiUpInfoEn.setLastUpdateDate(now);
            
            //syuMikomiUpInfoTblFacade.create(mikomiUpInfoEn);
            syuMikomiUpInfoTblFacade.insert(mikomiUpInfoEn);
        }
    }

    /**
     * 操作ログの登録
     */
    private void insertOperationLog() throws Exception{
        try{
            OperationLog operationLog = this.operationLogService.getOperationLog();

            if ("KSS".equals(StringUtils.defaultString(mikomiUploadBean.getUploadKbn()))) {
                operationLog.setOperationCode("UP_TPL");
                operationLog.setObjectId(15);
                operationLog.setObjectType("KIKAN_S");
                operationLog.setRemarks(mikomiUploadBean.getAnkenId());
            } else {
                operationLog.setOperationCode("UP_MIKOMI");
                operationLog.setObjectId(15);
                operationLog.setObjectType("KANRI");
                operationLog.setRemarks(this.judgeUploadKbn());
                operationLog.setRemarks2(this.mikomiUploadBean.getUploadFile().getName());
                operationLog.setRemarks3(DateFormatUtils.format(this.mikomiUploadBean.getStartYm(), "yyyy/MM"));    
            }
            
            this.operationLogService.insertOperationLogSearch(operationLog);
        }catch(Exception e){
            throw e;
        }
    }
    
    /**
     * アップロード区分による種類を取得
     * @return 
     */
    private String judgeUploadKbn(){
        String retStr = "";
        switch(StringUtils.defaultString(mikomiUploadBean.getUploadKbn())){
            case "00":
                retStr = Label.getValue(Label.uploadKbnLabelKeihin);
                break;
            case "01":
                retStr = Label.getValue(Label.uploadKbnLabelFu);
                break;
            case "02":
                retStr = Label.getValue(Label.uploadKbnLabelHama);
                break;
            case "03":
                retStr = Label.getValue(Label.uploadKbnLabelMi);
                break;
            case "04":
                retStr = Label.getValue(Label.uploadKbnLabelIsp);
                break;
            case "05":
                retStr = Label.getValue(Label.uploadKbnLabelChokka);
                break;
            case "06":
                retStr = Label.getValue(Label.uploadKbnLabelEtc1);
                break;
            case "07":
                retStr = Label.getValue(Label.uploadKbnLabelHanchoku);
                break;
            case "08":
                retStr = Label.getValue(Label.uploadKbnLabelBaihatsu);
                break;
            case "KSS":
                retStr = Label.getValue(Label.uploadKbnLabelKikanShinko);
                break;    
            default:
                break;    
        }
        return retStr;
    }
}
