package jp.co.toshiba.hby.pspromis.syuueki.bean;

import java.util.List;
import java.util.Map;
import javax.enterprise.context.RequestScoped;
import javax.inject.Named;
import jp.co.toshiba.hby.pspromis.syuueki.entity.SyuKiNetCateTitleTbl;
import jp.co.toshiba.hby.pspromis.syuueki.entity.SyuKiNetItemTukiTbl;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

/**
 *
 * @author horie
 */
@Named(value = "s025Bean")
@RequestScoped
@Getter @Setter
@ToString
public class S025Bean extends AbstractBean {

    /**
     *
     */
    private String kanjyoYm;

    /**
     *
     */
    private String oldYm;

    /**
     *
     */
    private String newYm;

    /**
     * 処理元の画面ID(操作ログの登録で利用)
     */
    private String procId;

    /**
     * 選択した項番(複数の可能性あるため配列)
     */
    private String[] orderItems;

    /**
     * カテゴリ設定する項番データの一覧
     */
    private List<SyuKiNetItemTukiTbl> targetItemList;

    /**
     * 共通カテゴリ一覧
     */
    private List<SyuKiNetCateTitleTbl> dispSelectItemList;

    /**
     * 選択したカテゴリのコード
     */
    private String selectCategoryCode;

    /**
     * 項番一覧のHiddenコード
     */
    private List<Map<String, String>> updateItemList;
}
