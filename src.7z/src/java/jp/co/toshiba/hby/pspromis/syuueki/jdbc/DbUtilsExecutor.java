/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package jp.co.toshiba.hby.pspromis.syuueki.jdbc;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.List;
import java.util.Map;
import javax.persistence.EntityManager;
import org.apache.commons.dbutils.QueryRunner;
import org.apache.commons.dbutils.ResultSetHandler;
import org.apache.commons.dbutils.handlers.MapHandler;
import org.apache.commons.dbutils.handlers.MapListHandler;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Apache CommonsのDBUtilsを使用してSQLの実行を行う
 * @author (NPC)K.Sano
 */
public class DbUtilsExecutor {
    private static final Logger logger = LoggerFactory.getLogger(DbUtilsExecutor.class);

    /**
     * SQL、パラメータをログ出力
     */
    private void outputLoggerSql(String sql, Object[] params) {
        int i = 0;

        logger.info(sql);
        StringBuilder paramString = new StringBuilder();
        
        // Step3 SQLパラメータのログを1行でまとめて出力するように修正。
        if (params != null) {
            boolean isFirst = true;
            paramString.append("[");
            for (Object param : params) {
                if (!isFirst) {
                    paramString.append(", ");
                }
                paramString.append(params[i]);

                //logger.info("param[" + i + "]=" + params[i]);
                isFirst = false;
                i++;
            }
            paramString.append("]");
            
            logger.info("SQL Parameters=" + paramString);
        }

    }

    /**
     * データ取得(複数件)
     * @param em
     * @param sql
     * @param params
     * @return
     * @throws SQLException 
     */
    public List<Map<String, Object>> dbUtilsGetSqlList(EntityManager em, String sql, Object[] params) throws SQLException{
        Connection conn = em.unwrap(Connection.class);
        QueryRunner qr = new QueryRunner();
        ResultSetHandler rsh = new MapListHandler();
        
        outputLoggerSql(sql, params);
        
        long startTime = System.currentTimeMillis();
        List<Map<String, Object>> list  = (List)qr.query(conn, sql, rsh, params);
        long entTime = System.currentTimeMillis();
        
        logger.info("DbUtilsExecutor#dbUtilsGetSqlList end sql processTime=" + (entTime - startTime) + "msec");
        
        return list;
    }
    
    /**
     * データ取得(複数件) ページング用
     * @param em
     * @param sql
     * @param params
     * @param offset
     * @param limit
     * @return
     * @throws SQLException 
     */
    public List<Map<String, Object>> dbUtilsGetSqlList(EntityManager em, String sql, Object[] params, int offset, int limit) throws SQLException{
        Connection conn = em.unwrap(Connection.class);
        QueryRunner qr = new QueryRunner();
        ResultSetHandler rsh = new MapListHandler();
        
        String pageSql = "select * from (select rownum as rowcnt, t.* from (" + sql + ") t ) where rowcnt between " + offset + " and " + (offset + limit);
        
        outputLoggerSql(pageSql, params);
        
        long startTime = System.currentTimeMillis();
        List<Map<String, Object>> list  = (List)qr.query(conn, pageSql, rsh, params);
        long entTime = System.currentTimeMillis();
        
        logger.info("DbUtilsExecutor#dbUtilsGetSqlList end sql processTime=" + (entTime - startTime) + "msec");
        
        return list;
    }

    /**
     * データ取得(1件)
     * @param em
     * @param sql
     * @param params
     * @return
     * @throws SQLException 
     */
    public Map<String, Object> dbUtilsGetSql(EntityManager em, String sql, Object[] params) throws SQLException{
        Connection conn = em.unwrap(Connection.class);
        QueryRunner qr = new QueryRunner();
        ResultSetHandler rsh = new MapHandler();

        outputLoggerSql(sql, params);

        long startTime = System.currentTimeMillis();
        Map<String, Object> list  = (Map)qr.query(conn, sql, rsh, params);
        long entTime = System.currentTimeMillis();
        
        logger.info("DbUtilsExecutor#dbUtilsGetSql end sql processTime=" + (entTime - startTime) + "msec");

        return list;
    }
}
