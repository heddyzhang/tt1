package jp.co.toshiba.hby.pspromis.syuueki.service;

import java.sql.SQLException;
import java.util.LinkedHashMap;
import java.util.Map;
import javax.ejb.Stateless;
import javax.inject.Inject;
import javax.interceptor.Interceptors;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import jp.co.toshiba.hby.pspromis.syuueki.interceptor.TranceInterceptor;
import jp.co.toshiba.hby.pspromis.syuueki.jdbc.DbUtilsExecutor;
import jp.co.toshiba.hby.pspromis.common.jdbc.SqlExecutor;
import jp.co.toshiba.hby.pspromis.syuueki.jdbc.SqlFile;
import jp.co.toshiba.hby.pspromis.syuueki.util.LoginUserInfo;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * PS-Promis収益管理システム
 * セッション情報検索 Service
 * @author (NPC)S.Ibayashi
 */
@Stateless
@Interceptors({TranceInterceptor.class})
public class SessionTblService {

    @PersistenceContext(unitName = jp.co.toshiba.hby.pspromis.syuueki.util.ConstantString.syuuekiDataSourceName)
    private EntityManager em;

    /**
     * ロガー
     */
    public static final Logger logger = LoggerFactory.getLogger(SessionTblService.class);

    /**
     * ログイン者情報
     */
    @Inject
    private LoginUserInfo loginUserInfo;

    /**
     * Injection SqlExecutor
     */
    @Inject
    protected SqlExecutor sqlExecutor;

    /**
     * Injection DbUtilsExecutor
     */
    @Inject
    protected DbUtilsExecutor dbUtilExecutor;

    /**
     * ログイン者セッション情報TBLのMapを取得
     * @return 
     * @throws java.sql.SQLException 
     */
    public Map<String, Object> getSessionMap() throws SQLException {
        // SQLパラメータ
        Map<String, Object> condition = new LinkedHashMap<>(); 
        condition.put("sessionId", loginUserInfo.getSessionId());
        condition.put("tuid", loginUserInfo.getUserId());

        String sql = getSessionInfoSql(condition);

        Object[] params = (Object[])(condition.values()).toArray(new Object[0]);
        Map<String, Object> result = dbUtilExecutor.dbUtilsGetSql(em, sql, params);

        return result;
    }

    /**
     * セッション情報を取得するSQLを取得
     */
    private String getSessionInfoSql(Map param) {
        SqlFile sqlFile = new SqlFile();
        String sql = sqlFile.getSqlString("/sql/selectSessionTbl.sql", param);
        return sql;
    }
}
