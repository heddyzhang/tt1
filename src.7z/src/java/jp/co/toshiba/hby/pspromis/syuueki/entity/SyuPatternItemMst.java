/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package jp.co.toshiba.hby.pspromis.syuueki.entity;

import java.io.Serializable;
import java.util.Date;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

/**
 *
 * @author sano
 */
@Entity
@Table(name = "SYU_PATTEN_ITEM_MST")
public class SyuPatternItemMst implements Serializable {
    private static final long serialVersionUID = 1L;
    @Basic(optional = false)
    @NotNull
    @Column(name = "CHUNYU_PTN_NO")
    @Id
    @Size(max = 8)
    private String chunyuPtnNo;
    @Column(name = "INFUSION_RATE_10")
    @Size(max = 3)
    private int infusionRate10;
    @Column(name = "INFUSION_RATE_20")
    @Size(max = 3)
    private int infusionRate20;
    @Column(name = "INFUSION_RATE_30")
    @Size(max = 3)
    private int infusionRate30;
    @Column(name = "INFUSION_RATE_40")
    @Size(max = 3)
    private int infusionRate40;
    @Column(name = "INFUSION_RATE_50")
    @Size(max = 3)
    private int infusionRate50;
    @Column(name = "INFUSION_RATE_60")
    @Size(max = 3)
    private int infusionRate60;
    @Column(name = "INFUSION_RATE_70")
    @Size(max = 3)
    private int infusionRate70;
    @Column(name = "INFUSION_RATE_80")
    @Size(max = 3)
    private int infusionRate80;
    @Column(name = "INFUSION_RATE_90")
    @Size(max = 3)
    private int infusionRate90;
    @Column(name = "INFUSION_RATE_100")
    @Size(max = 3)
    private int infusionRate100;
    @Column(name = "CREATED_BY")
    @Size(max = 8)
    private String createdBy;
    @Column(name = "CREATION_DATE")
    @Temporal(TemporalType.TIMESTAMP)
    private Date creationDate;
    @Column(name = "LAST_UPDATE_BY")
    @Size(max = 8)
    private String lastUpdateBy;
    @Column(name = "LAST_UPDATE_DATE")
    @Temporal(TemporalType.TIMESTAMP)
    private Date lastUpdateDate;

    public SyuPatternItemMst() {
    }
    
    public String getChunyuPtnNo() {
        return chunyuPtnNo;
    }

    public void setChunyuPtnNo(String chunyuPtnNo) {
        this.chunyuPtnNo = chunyuPtnNo;
    }

    public int getInfusionRate10() {
        return infusionRate10;
    }

    public void setInfusionRate10(int infusionRate10) {
        this.infusionRate10 = infusionRate10;
    }

    public int getInfusionRate20() {
        return infusionRate20;
    }

    public void setInfusionRate20(int infusionRate20) {
        this.infusionRate20 = infusionRate20;
    }

    public int getInfusionRate30() {
        return infusionRate30;
    }

    public void setInfusionRate30(int infusionRate30) {
        this.infusionRate30 = infusionRate30;
    }

    public int getInfusionRate40() {
        return infusionRate40;
    }

    public void setInfusionRate40(int infusionRate40) {
        this.infusionRate40 = infusionRate40;
    }

    public int getInfusionRate50() {
        return infusionRate50;
    }

    public void setInfusionRate50(int infusionRate50) {
        this.infusionRate50 = infusionRate50;
    }

    public int getInfusionRate60() {
        return infusionRate60;
    }

    public void setInfusionRate60(int infusionRate60) {
        this.infusionRate60 = infusionRate60;
    }

    public int getInfusionRate70() {
        return infusionRate70;
    }

    public void setInfusionRate70(int infusionRate70) {
        this.infusionRate70 = infusionRate70;
    }

    public int getInfusionRate80() {
        return infusionRate80;
    }

    public void setInfusionRate80(int infusionRate80) {
        this.infusionRate80 = infusionRate80;
    }

    public int getInfusionRate90() {
        return infusionRate90;
    }

    public void setInfusionRate90(int infusionRate90) {
        this.infusionRate90 = infusionRate90;
    }

    public int getInfusionRate100() {
        return infusionRate100;
    }

    public void setInfusionRate100(int infusionRate100) {
        this.infusionRate100 = infusionRate100;
    }

    public String getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    public Date getCreationDate() {
        return this.creationDate;
    }

    public void setCreationDate(Date creationDate) {
        this.creationDate = creationDate;
    }

    public String getLastUpdateBy() {
        return this.lastUpdateBy;
    }

    public void setLastUpdateBy(String lastUpdateBy) {
        this.lastUpdateBy = lastUpdateBy;
    }

    public Date getLastUpdateDate() {
        return this.lastUpdateDate;
    }

    public void setLastUpdateDate(Date lastUpdateDate) {
        this.lastUpdateDate = lastUpdateDate;
    }
}
