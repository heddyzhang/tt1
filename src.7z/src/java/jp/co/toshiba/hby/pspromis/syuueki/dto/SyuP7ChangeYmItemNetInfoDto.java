package jp.co.toshiba.hby.pspromis.syuueki.dto;

import lombok.Getter;
import lombok.Setter;

/**
 *
 * @author NPC
 */
@Getter @Setter
public class SyuP7ChangeYmItemNetInfoDto {
    
    /**
     * 案件id
     */
    private String ankenId;
    
    /**
     * 履歴id(最新:0/履歴:1)
     */
    private String rirekiId;
    
    /**
     * データ区分
     */
    private String dataKbn;
    
    /**
     * (変更前)売上年月
     */
    private String oSyuekiYm;

    /**
     * (変更後)売上年月
     */
    private String nSyuekiYm;
    
    /**
     * 削除FLG
     */
    private String delFlg;
    
    
    /**
     * 処理結果(0:成功、9:失敗)
     */
    private String errFlg;
    
    /**
     * エラー内容
     */
    private String errMsg;
    
    /**
     * 実行したパッケージ名
     */
    private String exeProcedureName;

}
