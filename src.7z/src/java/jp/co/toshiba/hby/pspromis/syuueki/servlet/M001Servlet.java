package jp.co.toshiba.hby.pspromis.syuueki.servlet;

import java.util.HashMap;
import java.util.Map;
import javax.inject.Inject;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpServletRequest;
import jp.co.toshiba.hby.pspromis.syuueki.bean.M001Bean;
import jp.co.toshiba.hby.pspromis.syuueki.enums.Env;
import jp.co.toshiba.hby.pspromis.syuueki.enums.Env;
import jp.co.toshiba.hby.pspromis.syuueki.service.M001Service;
import jp.co.toshiba.hby.pspromis.syuueki.util.FileUtils;
import jp.co.toshiba.hby.pspromis.syuueki.util.ParameterBinder;

/**
 * PS-Promis収益管理システム
 * 注入パターンマスタ詳細 Servlet
 * @author 
 */
@WebServlet(name="M001", urlPatterns={"/servlet/M001", "/servlet/M001/*"})
public class M001Servlet extends AbstractServlet {

    /**
     * jsp
     */
    private static final String INDEX_JSP = "M001/m001.jsp";

    /**
     * 使用serviceクラスをinjection(CDI)<br>
     * InjectアノテーションよりAPサーバー(Glassfish)側で自動的にインスタンス作成(new)される。<br>
     * service側はステートレスセッションbeanにするため、Statelessアノテーションをつけておくこと。<br>
     */
    @Inject
    private M001Service m001Service;

    /**
     * パラメータ格納クラスをinjection(CDI)<br>
     * InjectアノテーションよりAPサーバー(Glassfish)側で自動的にインスタンス作成(new)される。<br>
     */
    @Inject
    private M001Bean m001Bean;
    
    /**
     * 初期表示
     * @param req
     * @param resp
     * @return
     * @throws Exception 
     */
    public String indexAction(HttpServletRequest req, HttpServletResponse resp)
    throws Exception {
        logger.info("M001Servlet#indexAction");
        
        ParameterBinder.Bind(m001Bean, req);
        if ("4".equals(this.m001Bean.getOpenMode())) {
            this.m001Bean.setOpenMode("2");
        }
        // サービスの実行(トランザクションの単位にもなる)
        m001Service.indexExecute();

        return INDEX_JSP;
    }
    
    /**
     * 編集モード表示
     * @param req
     * @param resp
     * @return
     * @throws Exception 
     */
    public String editAction(HttpServletRequest req, HttpServletResponse resp)
    throws Exception {
        logger.info("M001Servlet#editAction");
        
        ParameterBinder.Bind(m001Bean, req);
        m001Bean.setOpenMode("4");
        m001Service.indexExecute();

        return INDEX_JSP;
    }
    
    /**
     * 保存
     * @param req
     * @param resp
     * @return
     * @throws Exception 
     */
    public String saveAction(HttpServletRequest req, HttpServletResponse resp)
    throws Exception {
        logger.info("M001Servlet#saveAction");
        
        ParameterBinder.Bind(m001Bean, req);
        
        // サービスの実行(トランザクションの単位にもなる)
        m001Service.save();

        return null;
    }
    
    /**
     * 注入パターン使用済みチェック
     * @param req
     * @param resp
     * @return
     * @throws Exception 
     */
    public String checkPattenAction(HttpServletRequest req, HttpServletResponse resp)
    throws Exception {
        logger.info("M001Servlet#deleteAction");
        
        ParameterBinder.Bind(m001Bean, req);
        
        int flg = 0;
        Map<String, Integer> resJson = new HashMap<>();

        // サービスの実行(トランザクションの単位にもなる)
        boolean isUsed = m001Service.checkPatten();
        if (isUsed) {
            flg = 1;
        }
        
        resJson.put("flg", flg);
        resopnseDecodeJson(resp, resJson);

        return null;
    }

    /**
     * 削除
     * @param req
     * @param resp
     * @return
     * @throws Exception 
     */
    public String deleteAction(HttpServletRequest req, HttpServletResponse resp)
    throws Exception {
        logger.info("M001Servlet#deleteAction");
        
        ParameterBinder.Bind(m001Bean, req);
        
        int flg = 0;
        Map<String, Integer> resJson = new HashMap<>();
        
        // サービスの実行(トランザクションの単位にもなる)
        boolean isUsed = m001Service.checkPatten();
        if (!isUsed) {
            m001Service.delete();
        } else {
            flg = 1;
        }

        resJson.put("flg", flg);
        resopnseDecodeJson(resp, resJson);

        return null;
    }

    /**
     * 注入パターン マスタファイルダウンロード
     * @param req
     * @param resp
     * @return
     * @throws java.lang.Exception
     */
    public String masterDownloadAction(HttpServletRequest req, HttpServletResponse resp)
    throws Exception {
        logger.info("M001Servlet#masterDownload");
        
        ParameterBinder.Bind(m001Bean, req);

        m001Service.masterDownloadFile();

        // 注入パターンマスタファイル保管ディレクトリとファイル名を取得
        String fileName = m001Bean.getSyuPatternMst().getImageUrl();
        String filePath = Env.getValue(Env.Patten_Mst_File_Dir);

        FileUtils.httpDownloadResponse(filePath + "/" + fileName, fileName, resp);
        
        return null;
    }

    /**
     * プラント種別マスタ再取得
     * @param req
     * @param resp
     * @return
     * @throws Exception 
     */
    public String plantTypeMstAction(HttpServletRequest req, HttpServletResponse resp)
    throws Exception {
        logger.info("M001Servlet#plantTypeMstAction");
    
        // リクエストパラメータをm001Beanの同名フィールドに一括コピー
        ParameterBinder.Bind(m001Bean, req);

        m001Service.plantTypeMstExecute();
    
        // 結果セットをjson出力
        Map<String, Object> jsonMap = new HashMap<>();
        jsonMap.put("plantTypeList", m001Bean.getPlantTypeMstList());
        resopnseDecodeJson(resp, jsonMap);

        // ここでは戻すjspが存在しないため、nullを返す。
        return null;
    }

}
