package jp.co.toshiba.hby.pspromis.syuueki.dto;

import java.io.Serializable;
import lombok.Getter;
import lombok.Setter;

/**
 * ES-Promis収益管理システム
 * 事業部定義情報Dto(1事業部の詳細項目を定義)
 * @author ibayashi
 */
@Getter @Setter
public class DivisionDto implements Serializable{
    
    private String divisionCode;
    
    private String divisionSubCode;

    private String divisionName;
    
    private String divisionNameEng;
 
    private boolean isEnableDivision;
    
    private String cAnkenHead;

    private String syoriType;

    private String ankenEditAuthKbn;
    
    private Short prioritySeq;

    private String dashBoardUrl;
    
    private String qlikViewgGraphUrl;
    
    private String allAnkenViewSyokusyuCd;
    
    public String getDivisionName() {
        // 将来的に英語対応を行う必要がある場合、ここで英語名称の切り分けをおこなう想定
        // 現状は日本語名固定
        return divisionName;
    }
 
}
