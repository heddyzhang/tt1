package jp.co.toshiba.hby.pspromis.syuueki.servlet;

import javax.inject.Inject;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import jp.co.toshiba.hby.pspromis.syuueki.bean.K003Bean;
import jp.co.toshiba.hby.pspromis.syuueki.service.K003Service;
import jp.co.toshiba.hby.pspromis.syuueki.util.ParameterBinder;

/**
 * PS-Promis収益管理システム
 * プラントコード選択 Servlet
 * @author (NPC)S.horie
 */
@WebServlet(name="K003", urlPatterns={"/servlet/K003", "/servlet/K003/*"})
public class K003Servlet extends AbstractServlet {

    /**
     * jsp
     */
    private static final String INDEX_JSP = "K003/k003.jsp";

    /**
     * 使用serviceクラスをinjection(CDI)<br>
     * InjectアノテーションよりAPサーバー(Glassfish)側で自動的にインスタンス作成(new)される。<br>
     * service側はステートレスセッションbeanにするため、Statelessアノテーションをつけておくこと。<br>
     */
    @Inject
    private K003Service k003Service;

    /**
     * パラメータ格納クラスをinjection(CDI)<br>
     * InjectアノテーションよりAPサーバー(Glassfish)側で自動的にインスタンス作成(new)される。<br>
     */
    @Inject
    private K003Bean k003Bean;

    /**
     * 初期表示
     * @param req
     * @param resp
     * @return
     * @throws Exception 
     */
    public String indexAction(HttpServletRequest req, HttpServletResponse resp)
    throws Exception {
        logger.info("K003Servlet#indexAction");
        
        // リクエストパラメータをk003Beanの同名フィールドに一括コピー
        ParameterBinder.Bind(k003Bean, req);

        k003Service.indexExecute();
        
        return INDEX_JSP;
    }

    /**
     * 一覧データ取得
     * @param req
     * @param resp
     * @return
     * @throws Exception 
     */
    public String searchAction(HttpServletRequest req, HttpServletResponse resp)
    throws Exception {
        logger.info("K003Servlet#searchAction");

        // リクエストパラメータをk003Beanの同名フィールドに一括コピー
        ParameterBinder.Bind(k003Bean, req);

        // サービスの実行(トランザクションの単位にもなる)
        // ※バリデーションチェックに通った場合のみサービス実行。
        k003Service.searchExecute();

        // jspをforward
        return INDEX_JSP;
    }
}
