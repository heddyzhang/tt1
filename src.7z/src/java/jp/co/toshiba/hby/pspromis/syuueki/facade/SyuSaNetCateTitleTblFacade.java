/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package jp.co.toshiba.hby.pspromis.syuueki.facade;

import java.util.List;
import java.util.Map;
import javax.ejb.Stateless;
import javax.interceptor.Interceptors;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import jp.co.toshiba.hby.pspromis.syuueki.entity.N7SetuBunruiMst;
import jp.co.toshiba.hby.pspromis.syuueki.entity.SyuSaNetCateTitleTbl;
import jp.co.toshiba.hby.pspromis.syuueki.entity.SyuSaNetCateTitleTblView;
import jp.co.toshiba.hby.pspromis.syuueki.interceptor.TranceInterceptor;
import org.apache.commons.collections.CollectionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 *
 * @author ibayashi
 */
@Stateless
@Interceptors({TranceInterceptor.class})
public class SyuSaNetCateTitleTblFacade extends AbstractFacade<SyuSaNetCateTitleTbl> {

    private static final Logger logger = LoggerFactory.getLogger(N7SetuBunruiMst.class);

    @PersistenceContext(unitName = jp.co.toshiba.hby.pspromis.syuueki.util.ConstantString.syuuekiDataSourceName)
    private EntityManager em;

    @Override
    protected EntityManager getEntityManager() {
        return em;
    }

    public SyuSaNetCateTitleTblFacade() {
        super(SyuSaNetCateTitleTbl.class);
    }

    /**
     * 最終見込損益　売上原価カテゴリ一覧を取得
     *
     * @param condition
     * @return
     */
    public List<SyuSaNetCateTitleTbl> getList(Map<String, Object> condition) {

        List<SyuSaNetCateTitleTbl> list
                = sqlExecutor.getResultList(em, SyuSaNetCateTitleTbl.class, "/sql/syuSaNetCateTitleTbl/selectSaNetCateTitleList.sql", condition);

        return list;
    }

    /**
     * 項番一覧検索　条件用リストを取得(カテゴリ1)
     *
     * @param condition
     * @return
     */
    public List<SyuSaNetCateTitleTblView> getSearchList1(final Map<String, Object> condition) {
        condition.put("no", "1");
//        List<SyuSaNetCateTitleTblView> list
//                = sqlExecutor.getResultList(em, SyuSaNetCateTitleTblView.class, "/sql/syuSaNetCateTitleTbl/selectSearchList1.sql", condition);

        List<SyuSaNetCateTitleTblView> list
                = sqlExecutor.getResultList(em, SyuSaNetCateTitleTblView.class, "/sql/syuSaNetCateTitleTbl/selectSearchList.sql", condition);
        
        return list;
    }

    /**
     * 項番一覧検索　条件用リストを取得(カテゴリ2)
     *
     * @param condition
     * @return
     */
    public List<SyuSaNetCateTitleTblView> getSearchList2(final Map<String, Object> condition) {
        condition.put("no", "2");
        
//        List<SyuSaNetCateTitleTblView> list
//                = sqlExecutor.getResultList(em, SyuSaNetCateTitleTblView.class, "/sql/syuSaNetCateTitleTbl/selectSearchList2.sql", condition);

        List<SyuSaNetCateTitleTblView> list
                = sqlExecutor.getResultList(em, SyuSaNetCateTitleTblView.class, "/sql/syuSaNetCateTitleTbl/selectSearchList.sql", condition);

        return list;
    }

    /**
     * NETカテゴリ(更新)
     *
     * @param condition
     * @return
     */
    public int updateSyuSaNetCateTitleTbl(Map<String, Object> condition) {
        int count = sqlExecutor.executeUpdateSql(em, "/sql/syuSaNetCateTitleTbl/updateSyuSaNetCateTitleTbl.sql", condition);
        return count;
    }

    /**
     * 最終見込損益(新規登録)
     *
     * @param condition
     * @return
     */
    public int insertSyuSaNetCateTitleTbl(Map<String, Object> condition) {
        int count = sqlExecutor.executeUpdateSql(em, "/sql/syuSaNetCateTitleTbl/insertSyuSaNetCateTitleTbl.sql", condition);
        return count;
    }

    /**
     * カテゴリの削除
     */
    public void deleteCategory(Map<String, Object> condition) {
        sqlExecutor.executeUpdateSql(em, "/sql/syuSaNetCateTitleTbl/deleteCategory.sql", condition);
    }

    /**
     *
     * @param condition
     * @return
     */
    public SyuSaNetCateTitleTbl selectPk(Map<String, Object> condition) {
        logger.info("SyuSaNetCateTitleTblFacade#selectPk");

        SyuSaNetCateTitleTbl ret = new SyuSaNetCateTitleTbl();
        List<SyuSaNetCateTitleTbl> list = sqlExecutor.getResultList(em, SyuSaNetCateTitleTbl.class, "/sql/syuSaNetCateTitleTbl/selectPk.sql", condition);
        if (CollectionUtils.isNotEmpty(list)) {
            ret = list.get(0);
        }

        return ret;
    }
}
