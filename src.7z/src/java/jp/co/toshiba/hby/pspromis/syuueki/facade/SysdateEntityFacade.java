package jp.co.toshiba.hby.pspromis.syuueki.facade;

import java.util.Date;
import javax.ejb.Stateless;
import javax.interceptor.Interceptors;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import jp.co.toshiba.hby.pspromis.syuueki.entity.SysdateEntity;
import jp.co.toshiba.hby.pspromis.syuueki.interceptor.TranceInterceptor;

/**
 *
 * @author ibayashi
 */
@Stateless
@Interceptors({TranceInterceptor.class})
public class SysdateEntityFacade extends AbstractFacade<SysdateEntity> {
    @PersistenceContext(unitName = jp.co.toshiba.hby.pspromis.syuueki.util.ConstantString.syuuekiDataSourceName)
    private EntityManager em;

    @Override
    protected EntityManager getEntityManager() {
        return em;
    }

    public SysdateEntityFacade() {
        super(SysdateEntity.class);
    }

    /**
     * RDBMのシステム日時を取得
     * @return システム日時
     */
    public Date getSysdate() {
        SysdateEntity entity = sqlExecutor.getSingleResult(em, SysdateEntity.class, "/sql/selectSysdat.sql", null);
        return entity.getSysdate();
    }
}
