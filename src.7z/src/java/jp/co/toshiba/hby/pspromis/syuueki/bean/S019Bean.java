package jp.co.toshiba.hby.pspromis.syuueki.bean;

import java.util.List;
import javax.enterprise.context.RequestScoped;
import javax.inject.Named;
import jp.co.toshiba.hby.pspromis.syuueki.entity.SyuGeNetItemTblView;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;
/**
 *
 * @author 
 */
@Named(value = "s019Bean")
@RequestScoped
@Getter @Setter
@ToString
public class S019Bean extends AbstractBean {

    /**
     * 処理元の画面ID(操作ログの登録で利用)
     */
    private String procId;

    /**
     * 事業部コード
     */
    private String divisionCode;

    /**
     * 呼出元で選択した項番
     */
    private String orderItem;

    /**
     * 対象の見込項番(カテゴリ1)
     */
    private String targetItemCategory1;
    
    /**
     * 対象の見込項番(カテゴリ2)
     */
    private String targetItemCategory2;
     
    /**
     * 対象の見込項番(注番)
     */
    private String targetItemOrderNo;
    
    /**
     * 対象の見込項番(製番記号)
     */
    private String targetItemSeiban;
    
    /**
     * 対象の見込項番(項番)
     */
    private String targetItemOrderItem;
    
    /**
     * 対象の見込項番(品名)
     */
    private String targetItemHinmei;

    /**
     * 検索条件:製番記号
     */
    private String inputseiban;

    /**
     * 検索条件:項番
     */
    private String inputorderItem;

    /**
     * 検索条件:品名
     */
    private String inputhinmei;

    /**
     * 検索条件:ソート順(最優先)
     */
    private String sort1;
    
    /**
     * 検索条件:並び順（最優先）
     */
    private String sort1Kbn;

    /**
     * 画面で選択した項番
     */
    private String selectorderItem;

    /**
     * 発番済データの一覧
     */
    private List<SyuGeNetItemTblView> dispTargetItemList;

    /**
     * 初期検索
     */
    private String initFlg;
    
    /**
     * 画面で選択したデータの注番
     */
    private String selectedOrderNo;

}
