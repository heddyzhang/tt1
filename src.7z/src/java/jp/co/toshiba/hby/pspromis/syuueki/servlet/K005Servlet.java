package jp.co.toshiba.hby.pspromis.syuueki.servlet;

import javax.inject.Inject;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import jp.co.toshiba.hby.pspromis.syuueki.bean.K005Bean;
import jp.co.toshiba.hby.pspromis.syuueki.service.K005Service;
import jp.co.toshiba.hby.pspromis.syuueki.util.ParameterBinder;

/**
 * PS-Promis収益管理システム
 * 注文主選択 Servlet
 * @author (NPC)S.horie
 */
@WebServlet(name="K005", urlPatterns={"/servlet/K005", "/servlet/K005/*"})
public class K005Servlet extends AbstractServlet {

    /**
     * jsp
     */
    private static final String INDEX_JSP = "K005/k005.jsp";

    /**
     * 使用serviceクラスをinjection(CDI)<br>
     * InjectアノテーションよりAPサーバー(Glassfish)側で自動的にインスタンス作成(new)される。<br>
     * service側はステートレスセッションbeanにするため、Statelessアノテーションをつけておくこと。<br>
     */
    @Inject
    private K005Service k005Service;

    /**
     * パラメータ格納クラスをinjection(CDI)<br>
     * InjectアノテーションよりAPサーバー(Glassfish)側で自動的にインスタンス作成(new)される。<br>
     */
    @Inject
    private K005Bean k005Bean;

    /**
     * 初期表示
     * @param req
     * @param resp
     * @return
     * @throws Exception 
     */
    public String indexAction(HttpServletRequest req, HttpServletResponse resp)
    throws Exception {
        logger.info("K005Servlet#indexAction");
        
        k005Service.indexExecute();
        
        return INDEX_JSP;
    }

    /**
     * 一覧データ取得
     * @param req
     * @param resp
     * @return
     * @throws Exception 
     */
    public String searchAction(HttpServletRequest req, HttpServletResponse resp)
    throws Exception {
        logger.info("K005Servlet#searchAction");

        // リクエストパラメータをk002Beanの同名フィールドに一括コピー
        ParameterBinder.Bind(k005Bean, req);

        // サービスの実行(トランザクションの単位にもなる)
        k005Service.searchExecute();

        // jspをforward
        return INDEX_JSP;
    }
}
