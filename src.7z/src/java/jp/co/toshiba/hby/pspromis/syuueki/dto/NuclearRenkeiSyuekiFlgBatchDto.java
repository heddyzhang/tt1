package jp.co.toshiba.hby.pspromis.syuueki.dto;

import lombok.Getter;
import lombok.Setter;

/**
 * ES-Promis収益管理システム
 * (原子力)収益管理システムへのデータ連携パッケージ(収益FLG付け替え)のパラメータ
 * @author ibayashi
 */
@Getter @Setter
public class NuclearRenkeiSyuekiFlgBatchDto {
   
    /**
     * 注番の代表案件
     */
    private String daihyoAnkenId;
    
    /**
     * 収益対象FLGを解除する案件
     */
    private String invaildAnkenId;
    
    /**
     * 対象の注番
     */
    private String ankenOrderNo;

    /**
     * 処理結果(0:成功、9:失敗)
     */
    private Integer status;
    
    /**
     * エラー内容
     */
    private String errMsg;

    /**
     * エラー発生した場合、エラーになった案件
     */
    private String errorAnkenId;

    /**
     * 実行したパッケージ名
     */
    private String exeProcedureName;

}