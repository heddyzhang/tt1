package jp.co.toshiba.hby.pspromis.syuueki.servlet;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import javax.inject.Inject;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpServletRequest;
import jp.co.toshiba.hby.pspromis.syuueki.bean.ResultMessageBean;
import jp.co.toshiba.hby.pspromis.syuueki.bean.S004Bean;
import jp.co.toshiba.hby.pspromis.syuueki.facade.SysdateEntityFacade;
import jp.co.toshiba.hby.pspromis.syuueki.service.S004DownloadService;
import jp.co.toshiba.hby.pspromis.syuueki.service.S004Service;
import jp.co.toshiba.hby.pspromis.syuueki.util.CdiUtils;
import jp.co.toshiba.hby.pspromis.syuueki.util.DetailExcelUtils;
import jp.co.toshiba.hby.pspromis.syuueki.util.FileUtils;
import jp.co.toshiba.hby.pspromis.syuueki.util.ParameterBinder;
import jp.co.toshiba.hby.pspromis.syuueki.util.PoiUtil;
import jp.co.toshiba.hby.pspromis.syuueki.service.StoredProceduresService;
import org.apache.poi.ss.usermodel.Workbook;

/**
 * PS-Promis収益管理システム
 * 期間損益(進行基準) Servlet
 * @author (NPC)K.Sano
 */
@WebServlet(name="S004", urlPatterns={"/servlet/S004", "/servlet/S004/*"})
public class S004Servlet extends AbstractServlet {

    /**
     * jsp
     */
    private static final String INDEX_JSP = "S004/s004.jsp";

    /**
     * jsp
     */
    private static final String UPLOAD_JSP = "S004/s004Upload.jsp";

    
    /**
     * 使用serviceクラスをinjection(CDI)<br>
     * InjectアノテーションよりAPサーバー(Glassfish)側で自動的にインスタンス作成(new)される。<br>
     * service側はステートレスセッションbeanにするため、Statelessアノテーションをつけておくこと。<br>
     */
    @Inject
    private S004Service s004Service;

    
    @Inject
    private S004DownloadService s004DlService;

    @Inject
    private StoredProceduresService storedProceduresService;
    
    @Inject
    private SysdateEntityFacade sysdateFacade;
    
    /**
     * パラメータ格納クラスをinjection(CDI)<br>
     * InjectアノテーションよりAPサーバー(Glassfish)側で自動的にインスタンス作成(new)される。<br>
     */
    @Inject
    private S004Bean s004Bean;
    
    /**
     * 初期表示
     * @param req
     * @param resp
     * @return
     * @throws Exception 
     */
    public String indexAction(HttpServletRequest req, HttpServletResponse resp)
    throws Exception {
        logger.info("S004Servlet#indexAction");

        // リクエストパラメータをs004Beanの同名フィールドに一括コピー
        ParameterBinder.Bind(s004Bean, req);
        s004Bean.setEditFlg("");
        s004Service.indexExecute();
        
        return INDEX_JSP;
    }
    
    /**
     * 編集表示
     * @param req
     * @param resp
     * @return
     * @throws Exception 
     */
    public String editAction(HttpServletRequest req, HttpServletResponse resp)
    throws Exception {
        logger.info("S004Servlet#editAction");

        // リクエストパラメータをs004Beanの同名フィールドに一括コピー
        ParameterBinder.Bind(s004Bean, req);

        // 表示円貨は1円単位に戻す
        s004Bean.setJpyUnit(1);
        s004Bean.setEditFlg("1");
        s004Service.indexExecute();
        
        return INDEX_JSP;
    }
    
    /**
     * 保存
     * @param req
     * @param resp
     * @return
     * @throws Exception 
     */
    public String saveAction(HttpServletRequest req, HttpServletResponse resp) throws Exception {
        logger.info("S004Servlet#saveAction");

        // リクエストパラメータをs004Beanの同名フィールドに一括コピー
        ParameterBinder.Bind(s004Bean, req);

        // 登録を行う
        s004Service.updateExpectedAmount(0);
        
        // (原子力)連携バッチを実行
        //storedProceduresService.callN7RenkeiBatchJudge(s004Bean.getAnkenId(), s004Bean.getRirekiId());
        
        // 処理結果を戻す。
        Map<String, Object> jsonMap = new HashMap<>();
        ResultMessageBean resultMessageBean = CdiUtils.getBean(ResultMessageBean.class);
        resultMessageBean.createResultMessage(jsonMap);
        resopnseDecodeJson(resp, jsonMap);
        
        return null;
    }
    
    /**
     * 見込差反映
     * @param req
     * @param resp
     * @return
     * @throws Exception 
     */
    public String reflectAction(HttpServletRequest req, HttpServletResponse resp) throws Exception {
        logger.info("S004Servlet#reflectAction");

        // リクエストパラメータをs004Beanの同名フィールドに一括コピー
        ParameterBinder.Bind(s004Bean, req);

        // 登録を行う
        s004Service.updateExpectedAmount(0);
        // 登録後、見込差反映を行う
        s004Service.updateExpectedReflect();
        
        // (原子力)連携バッチを実行
        //storedProceduresService.callN7RenkeiBatchJudge(s004Bean.getAnkenId(), s004Bean.getRirekiId());
        
        // 処理結果を戻す。
        Map<String, Object> jsonMap = new HashMap<>();
        ResultMessageBean resultMessageBean = CdiUtils.getBean(ResultMessageBean.class);
        resultMessageBean.createResultMessage(jsonMap);
        resopnseDecodeJson(resp, jsonMap);
        
        return null;
    }
    
    /**
     * 再計算処理
     * @param req
     * @param resp
     * @return
     * @throws Exception 
     */
    public String recalAction(HttpServletRequest req, HttpServletResponse resp) throws Exception {
        logger.info("S004Servlet#recalAction");

        // リクエストパラメータをs004Beanの同名フィールドに一括コピー
        ParameterBinder.Bind(s004Bean, req);

        // (画面データの保存＋)再計算を行う
        s004Service.updateExpectedAmount(0);
        
        // (原子力)連携バッチを実行
        //storedProceduresService.callN7RenkeiBatchJudge(s004Bean.getAnkenId(), s004Bean.getRirekiId());
        
        // 処理結果を戻す。
        Map<String, Object> jsonMap = new HashMap<>();
        ResultMessageBean resultMessageBean = CdiUtils.getBean(ResultMessageBean.class);
        resultMessageBean.createResultMessage(jsonMap);
        resopnseDecodeJson(resp, jsonMap);
        
        return null;
    }

    /**
     * Excelダウンロード処理
     * @param req
     * @param resp
     * @return
     * @throws Exception 
     */
    public String downloadAction(HttpServletRequest req, HttpServletResponse resp) throws Exception {
        ParameterBinder.Bind(s004Bean, req);
        
        Date now = sysdateFacade.getSysdate();
        SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMddHHmm");
        
        
        // テンプレートファイルの読み込み
        //String filePath = req.getServletContext().getRealPath("WEB-INF/template/shinko_template.xlsx");
        String filePath = req.getServletContext().getRealPath("WEB-INF/template/ankenDetail_template.xlsx");
//        HSSFWorkbook workbook = PoiUtil.getHSSFWorkbook(new File(filePath));
        Workbook workbook = PoiUtil.getWorkbook(new File(filePath));

        // 上記で読み込みしたテンプレートファイルは案件の詳細全般で利用しているものなので、
        // 不要なシートを全て削除する(期間損益(進行)で利用するシート以外を全て削除)
        DetailExcelUtils.leaveDetailSheet(workbook, "kikanS");
        
        // テンプレートにデータ埋め込み
        s004DlService.outputDownloadExcel(workbook);
        
        // テンプレート出力
        // ファイル名「[案件番号]_期間損益_[YYYYMMDDHH24MI].xlsx」
        FileUtils.httpDownloadExcelResponse(workbook, s004Bean.getAnkenId() + "_期間損益_" + sdf.format(now) + ".xlsx", resp);
//        FileUtils.httpDownloadExcelResponse(workbook, s004Bean.getAnkenId() + "_期間損益_" + sdf.format(now) + ".xls", resp);

        return null;
    }

    
    /**
     * Excelアップロード子画面表示
     * @param req
     * @param resp
     * @return
     * @throws Exception 
     */
    public String uploadAction(HttpServletRequest req, HttpServletResponse resp) throws Exception {
        logger.info("S004Servlet#uploadAction");

        // リクエストパラメータをs004Beanの同名フィールドに一括コピー
        ParameterBinder.Bind(s004Bean, req);
        
        return UPLOAD_JSP;
    }

    /**
     * 最新値更新
     */
    public String updateNewDataAction(HttpServletRequest req, HttpServletResponse resp)
    throws Exception {
        logger.info("S004Servlet#updateNewDataAction");

        ParameterBinder.Bind(s004Bean, req);

        if ("1".equals(s004Bean.getEditFlg())) {
            // 更新モードの場合は画面の値も更新する
            s004Service.updateExpectedAmount(1);
        } else {
            // 参照モード
            s004Service.calc(1);
        }

        // 処理結果を戻す。
        Map<String, Object> jsonMap = new HashMap<>();
        ResultMessageBean resultMessageBean = CdiUtils.getBean(ResultMessageBean.class);
        resultMessageBean.createResultMessage(jsonMap);
        resopnseDecodeJson(resp, jsonMap);
        
        return null;
    }
}
