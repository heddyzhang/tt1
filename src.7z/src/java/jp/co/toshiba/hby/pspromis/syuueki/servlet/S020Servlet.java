package jp.co.toshiba.hby.pspromis.syuueki.servlet;

import java.util.HashMap;
import java.util.Map;
import javax.inject.Inject;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpServletRequest;
import jp.co.toshiba.hby.pspromis.syuueki.bean.S020Bean;
import jp.co.toshiba.hby.pspromis.syuueki.bean.ValidationMessageBean;
import jp.co.toshiba.hby.pspromis.syuueki.service.S020Service;
import jp.co.toshiba.hby.pspromis.syuueki.util.ParameterBinder;

/**
 * ES-Promis収益管理システム
 * 見込項番作成
 * @author 
 */
@WebServlet(name="S020", urlPatterns={"/servlet/S020", "/servlet/S020/*"})
public class S020Servlet extends AbstractServlet {

    private static final String INDEX_JSP = "S020/createMitOrderItem.jsp";
    
    @Inject
    private S020Bean s020Bean;

    @Inject
    private S020Service s020Service;

    @Inject
    private ValidationMessageBean validationMessageBean;

    /**
     * 初期表示
     * @param req
     * @param resp
     * @return
     * @throws Exception 
     */
    public String indexAction(HttpServletRequest req, HttpServletResponse resp)
    throws Exception {
        // リクエストパラメータをs020Beanの同名フィールドに一括コピー
        ParameterBinder.Bind(s020Bean, req);

        // サービスの実行(トランザクションの単位にもなる)
        s020Service.indexExecute();

        return INDEX_JSP;
    }

    /**
     * 保存(実行)処理
     * @param req
     * @param resp
     * @return
     * @throws Exception 
     */
    public String saveAction(HttpServletRequest req, HttpServletResponse resp) throws Exception {
        // リクエストパラメータをs020Beanの同名フィールドに一括コピー
        ParameterBinder.Bind(s020Bean, req);

        // バリデーションチェック
        if (!s020Service.validation()) {
            // 入力エラーが存在する場合はエラー情報を返す
            resopnseDecodeJson(resp, validationMessageBean.errorJsonInfo());
        } else {
            s020Service.saveExecute();
            // (2017/11/22 連携バッチは自立型トランザクションになったため、いったん登録状態のcommitが確定された状態で実行するように変更
            s020Service.callNuclearSysRenkeiDisp();

            Map<String, Object> jsonMap = new HashMap<>();
            jsonMap.put("orderNo", s020Bean.getOrderNo());
            jsonMap.put("seiban", s020Bean.getSeiban());
            jsonMap.put("orderItem", s020Bean.getOrderItem());
            jsonMap.put("hinmei", s020Bean.getHinmei());
            resopnseDecodeJson(resp, jsonMap);
        }

        return null;
    }

}
