package jp.co.toshiba.hby.pspromis.syuueki.facade;

import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import jp.co.toshiba.hby.pspromis.syuueki.entity.SyuKiSpTotalTbl;

/**
 *
 * @author ibayashi
 */
@Stateless
public class SyuKiSpTotalTblFacade extends AbstractFacade<SyuKiSpTotalTbl> {
    @PersistenceContext(unitName = jp.co.toshiba.hby.pspromis.syuueki.util.ConstantString.syuuekiDataSourceName)
    private EntityManager em;

    @Override
    protected EntityManager getEntityManager() {
        return em;
    }

    public SyuKiSpTotalTblFacade() {
        super(SyuKiSpTotalTbl.class);
    }
}
