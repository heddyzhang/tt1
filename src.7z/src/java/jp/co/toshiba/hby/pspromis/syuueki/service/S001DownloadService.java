package jp.co.toshiba.hby.pspromis.syuueki.service;

import java.io.PrintWriter;
import java.math.BigDecimal;
import java.sql.ResultSet;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.HashMap;
import javax.ejb.Stateless;
import javax.inject.Inject;
import javax.interceptor.Interceptors;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import jp.co.toshiba.hby.pspromis.syuueki.bean.S001Bean;
import jp.co.toshiba.hby.pspromis.syuueki.interceptor.TranceInterceptor;
import jp.co.toshiba.hby.pspromis.common.jdbc.SqlExecutor;
import jp.co.toshiba.hby.pspromis.common.util.StringUtil;
import jp.co.toshiba.hby.pspromis.syuueki.entity.OperationLog;
import jp.co.toshiba.hby.pspromis.syuueki.enums.Env;
import jp.co.toshiba.hby.pspromis.syuueki.enums.Label;
import jp.co.toshiba.hby.pspromis.syuueki.facade.SysdateEntityFacade;
import jp.co.toshiba.hby.pspromis.syuueki.facade.SyuWfControlTblFacade;
import jp.co.toshiba.hby.pspromis.syuueki.jdbc.DbUtilsExecutor;
import jp.co.toshiba.hby.pspromis.syuueki.jdbc.ResultSetManeger;
import jp.co.toshiba.hby.pspromis.syuueki.jdbc.SqlFile;
import jp.co.toshiba.hby.pspromis.syuueki.util.ConstantString;
import jp.co.toshiba.hby.pspromis.syuueki.util.LoginUserInfo;
import jp.co.toshiba.hby.pspromis.syuueki.util.SyuuekiUtils;
import jp.co.toshiba.hby.pspromis.syuueki.util.Utils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
/**
 * PS-Promis収益管理システム
 * 案件検索 Service(受注売上見込一覧Csv出力)
 * @author (NPC)Horie
 */
@Stateless
@Interceptors({TranceInterceptor.class})
public class S001DownloadService {

    /**
     * ロガー
     */
    public static final Logger logger = LoggerFactory.getLogger(S001DownloadService.class);

    @PersistenceContext(unitName = jp.co.toshiba.hby.pspromis.syuueki.util.ConstantString.syuuekiDataSourceName)
    private EntityManager em;

    @Inject
    private S001Service s001Service;
    
    @Inject
    private SyuWfControlTblFacade syuWfControlTblFacade;
    
    @Inject
    private DbUtilsExecutor dbUtilsExecutor;
    
    /**
     * パラメータ格納クラスをinjection(CDI)<br>
     * InjectアノテーションよりAPサーバー(Glassfish)側で自動的にインスタンス作成(new)される。<br>
     */
    @Inject
    private S001Bean s001Bean;


    /**
     * Injection loginUserInfo
     * (ユーザー情報(ユーザーid,名称,所属部課名)を格納したオブジェクト)
     */
    @Inject
    private LoginUserInfo loginUserInfo;

    /**
     * Injection sqlExecutor
     */
    @Inject
    protected SqlExecutor sqlExecutor;

    /**
     * Injection SyuuekiUtils
     */
    @Inject
    private SyuuekiUtils syuuekiUtils;

    @Inject
    private Utils utils;

    @Inject
    private SysdateEntityFacade sysdateFacade;

    @Inject
    private OperationLogService operationLogService;

    static final String miriSecFormat = "yyyy-MM-dd HH:mm:ss";

    /**
     * CSV出力
     * @param writer
     * @throws java.lang.Exception
     */
    public void downloadCsvExecute(PrintWriter writer) throws Exception {

        ResultSetManeger resultSetManeger = null;
        ResultSet rset = null;
        final int MAX_COLUMNS = 65;

        try {
            // CSV設定値を取得
            String sep = Env.getValue(Env.CsvSeparator);
            String lineBreak = Env.getValue(Env.CsvLineBreak);

            // 検索条件をセット
            Map condition = s001Service.getCondition();
            // 円貨はデフォルト1(円)とする。
            if (this.s001Bean.getJpyUnit() == null) {
                this.s001Bean.setJpyUnit(1);
            }
            if (this.s001Bean.getJpyUnit() == 1000) {
                this.s001Bean.setJpyUnitKbn("2");
            } else if (this.s001Bean.getJpyUnit() == 1000000) {
                this.s001Bean.setJpyUnitKbn("3");
            } else {
                this.s001Bean.setJpyUnitKbn("1");
            }

            // 操作ログを出力
            OperationLog operationLog = getOperationLogDto(condition);
            operationLog.setOperationCode("DL_JOB");
            operationLog.setObjectId(10);
            operationLog.setRemarks("受注売上見込一覧CSV");
            operationLogService.insertOperationLogSearch(operationLog);

            condition.put("rirekiId", Arrays.asList(s001Bean.getRirekiIdList().split(",")));
            condition.put("listDispType", s001Bean.getListDispType());

            // 一覧出力データを取得
            resultSetManeger = new ResultSetManeger(sqlExecutor);
            // [最終見込 前回値]の対象となる履歴IDを取得し直す
            Map<String, Object> oldSearchCondition = new HashMap<>(condition);
            String oldRirekiId = s001Service.getOldRirekiID(oldSearchCondition);
            if (StringUtils.isNotEmpty(oldRirekiId)) {
                condition.put("rirekiIdOld", Arrays.asList(oldRirekiId.split(",")));
            }
            rset = resultSetManeger.getResultSet(em, "/sql/selectListSyuueki.sql", condition);

            ///// CSV作成 /////
            // 1行目(出力日、出力者)
            for (int i = 0; i < MAX_COLUMNS; i++) {
                writer.print(getCsvHeader(i));
                writer.print(sep);
            }
            writer.print(lineBreak);

            // 2行目(一覧タイトル)
            for (int i = 0; i < MAX_COLUMNS; i++) {
                writer.print(getCsvTitle(i));
                writer.print(sep);
            }
            writer.print(lineBreak);

            // 3行目以降(一覧データ)
            while (rset.next()) {
                for (int i = 0; i < MAX_COLUMNS; i++) {
                    writer.print(getCsvData(rset, resultSetManeger, i));
                    writer.print(sep);
                }
                writer.print(lineBreak);
            }
        } catch (Exception e) {
            throw e;
        } finally {
            if (resultSetManeger != null) {
                resultSetManeger.close(rset);
            }
        }
    }
    
    /**
     * CSVの1行目(出力日、出力者)を取得
     * @throws Exception 
     */
    private String getCsvHeader(int col) throws Exception {
        String res = "";
        switch(col){
            case 0:
                res = Label.getValue(Label.outputName);
                break;
            case 1:
                res = loginUserInfo.getUserName();
                break;
            case 2:
                res = Label.getValue(Label.outputDate);
                break;
            case 3:
                // 日時フォーマット
                SimpleDateFormat sdf = new SimpleDateFormat(syuuekiUtils.formatTimeStamp());
                res = sdf.format(sysdateFacade.getSysdate());
                break;
            case 4:
                String kbn = this.s001Bean.getJpyUnitKbn();
                if(kbn.equals("3")){
                    res = Label.getValue(Label.unitLabel) + ":" + Label.getValue(Label.jpyUnit3);
                }else if(kbn.equals("2")){
                    res = Label.getValue(Label.unitLabel) + ":" + Label.getValue(Label.jpyUnit2);
                }else{
                    res = Label.getValue(Label.unitLabel) + ":" + Label.getValue(Label.jpyUnit1);
                }
                break;
            case 5:
                String kbn1 = this.s001Bean.getJpyUnitKbn();
                if(kbn1.equals("3")){
                    res = Label.getValue(Label.unitCaution) ;
                }else if(kbn1.equals("2")){
                    res = Label.getValue(Label.unitCaution) ;
                }
                break;                
            default :
                break;
        }
        return utils.stringCsv(res);
    }

    /**
     * CSVの2行目(一覧タイトル)を取得
     * @throws Exception 
     */
    private String getCsvTitle(int col) throws Exception {
        String res = "";
        switch(col){
            case 0:
                // 案件番号
                res = Label.getValue(Label.ankenCode);
                break;
            case 1:
                // 売上基準
                res = Label.getValue(Label.uriageKijun);
                break;
            case 2:
                // 売上区分
                res = Label.getValue(Label.uriageKbn);
                break;
            case 3:
                // 注番
                res = Label.getValue(Label.oNo);
                break;
            case 4:
                // S/N
                res = Label.getValue(Label.sn);
                break;
            case 5:
                // (発番)売上予定
                res = Label.getValue(Label.hatsubanBracketed) + Label.getValue(Label.uriageYotei);
                break;
            case 6:
                // (発番)出荷日限
                res = Label.getValue(Label.hatsubanBracketed) + Label.getValue(Label.forwardTermYm);
                break;
            case 7:
                // (発番)回収年月
                res = Label.getValue(Label.hatsubanBracketed) + Label.getValue(Label.recoveryYm);
                break;
            case 8:
                // 本社部課
                res = Label.getValue(Label.headOfficeBuka);
                break;
            case 9:
                // 販売C
                res = Label.getValue(Label.salesC);
                break;

            case 10:
                // 注文主
                res = Label.getValue(Label.tradeName);
                break;
            case 11:
                // 設置場所
                res = Label.getValue(Label.stchName);
                break;
            case 12:
                // 品名
                res = Label.getValue(Label.hinmei);
                break;
            case 13:
                // 契約通貨
                res = Label.getValue(Label.keiyaku) + Label.getValue(Label.currency);
                break;
            case 14:
                // 前回外貨SP
                res = Label.getValue(Label.before) + Label.getValue(Label.foreignUnitLabel) + Label.getValue(Label.sp);
                break;
            case 15:
                // 前回受注レート
                res = Label.getValue(Label.before) + Label.getValue(Label.juchuRate);
                break;
            case 16:
                // 前回売上レート
                res = Label.getValue(Label.before) + Label.getValue(Label.uriageRate);
                break;
            case 17:
                // 前回最終見込SP
                res = Label.getValue(Label.before) + Label.getValue(Label.lastMikomi) + Label.getValue(Label.sp);
                break;
            case 18:
                // 前回最終見込NET
                res = Label.getValue(Label.before) + Label.getValue(Label.lastMikomi) + Label.getValue(Label.net);
                break;
            case 19:
                // 前回最終見込M率
                res = Label.getValue(Label.before) + Label.getValue(Label.lastMikomi) + Label.getValue(Label.mrate);
                break;

            case 20:
                // 前回受注月
                res = Label.getValue(Label.before) + Label.getValue(Label.jyuchuYm);
                break;
            case 21:
                // 前回売上月
                res = Label.getValue(Label.before) + Label.getValue(Label.uriageYm);
                break;
            case 22:
                // 今回外貨SP
                res = Label.getValue(Label.now) + Label.getValue(Label.foreignUnitLabel) + Label.getValue(Label.sp);
                break;
            case 23:
                // 今回受注レート
                res = Label.getValue(Label.now) + Label.getValue(Label.juchuRate);
                break;
            case 24:
                // 今回売上レート
                res = Label.getValue(Label.now) + Label.getValue(Label.uriageRate);
                break;
            case 25:
                // 今回最終見込SP
                res = Label.getValue(Label.now) + Label.getValue(Label.lastMikomi) + Label.getValue(Label.sp);
                break;
            case 26:
                // 今回最終見込NET
                res = Label.getValue(Label.now) + Label.getValue(Label.lastMikomi) + Label.getValue(Label.net);
                break;
            case 27:
                // 今回最終見込M率
                res = Label.getValue(Label.now) + Label.getValue(Label.lastMikomi) + Label.getValue(Label.mrate);
                break;
            case 28:
                // 今回受注月
                res = Label.getValue(Label.now) + Label.getValue(Label.jyuchuYm);
                break;
            case 29:
                // 今回売上月
                res = Label.getValue(Label.now) + Label.getValue(Label.uriageYm);
                break;

            case 30:
                // 予算SP
                res = Label.getValue(Label.yosan) + Label.getValue(Label.sp);
                break;
            case 31:
                // 予算NET
                res = Label.getValue(Label.yosan) + Label.getValue(Label.net);
                break;
            case 32:
                // 予算粗利
                res = Label.getValue(Label.yosan) + Label.getValue(Label.arari);
                break;
            case 33:
                // 発番SP
                res = Label.getValue(Label.hatsuban) + Label.getValue(Label.sp);
                break;
            case 34:
                // 発番NET
                res = Label.getValue(Label.hatsuban) + Label.getValue(Label.net);
                break;
            case 35:
                // 発番粗利
                res = Label.getValue(Label.hatsuban) + Label.getValue(Label.arari);
                break;
            case 36:
                // 発番M率
                res = Label.getValue(Label.hatsuban) + Label.getValue(Label.mrate);
                break;
            case 37:
                // 契約SP累計
                res = Label.getValue(Label.keiyaku) + Label.getValue(Label.sp) + Label.getValue(Label.ruikei);
                break;
            case 38:
                // 契約最終連番
                res = Label.getValue(Label.keiyaku) + Label.getValue(Label.last) + Label.getValue(Label.renban);
                break;
            case 39:
                // 売上済SP
                res = Label.getValue(Label.uriage) + Label.getValue(Label.end) + Label.getValue(Label.sp);
                break;

            case 40:
                // 売上済NET
                res = Label.getValue(Label.uriage) + Label.getValue(Label.end) + Label.getValue(Label.net);
                break;
            case 41:
                // 売上済粗利
                res = Label.getValue(Label.uriage) + Label.getValue(Label.end) + Label.getValue(Label.arari);
                break;
            case 42:
                // 残SP
                res = Label.getValue(Label.zan) + Label.getValue(Label.sp);
                break;
            case 43:
                // 残NET
                res = Label.getValue(Label.zan) + Label.getValue(Label.net);
                break;
            case 44:
                // 残粗利
                res = Label.getValue(Label.zan) + Label.getValue(Label.arari);
                break;
            case 45:
                // 中計SP
                res = Label.getValue(Label.chukei) + Label.getValue(Label.sp);
                break;
            case 46:
                // 中計NET
                res = Label.getValue(Label.chukei) + Label.getValue(Label.net);
                break;
            case 47:
                // 中計粗利
                res = Label.getValue(Label.chukei) + Label.getValue(Label.arari);
                break;
            case 48:
                // 備考
                res = Label.getValue(Label.biko);
                break;
            case 49:
                // 営業部門
                res = Label.getValue(Label.eigyoSectionName);
                break;

            case 50:
                // 担当者名
                res = Label.getValue(Label.tantosyaName);
                break;
            case 51:
                // サブBUコード
                res = Label.getValue(Label.subBuCode);
                break;
            case 52:
                // サブBU名称
                res = Label.getValue(Label.subBuName);
                break;
            case 53:
                // プラントコード
                res = Label.getValue(Label.plantCode);
                break;
            case 54:
                // 収益分類
                res = Label.getValue(Label.syuuekiBunrui);
                break;
            case 55:
                // 取扱店CD
                res = Label.getValue(Label.toriatsuCd2);
                break;
            case 56:
                // 販売チーム
                res = Label.getValue(Label.salesTeam);
                break;
            case 57:
                // 製造チーム
                res = Label.getValue(Label.seizouTeam);
                break;
            case 58:
                // 業態
                res = Label.getValue(Label.businessCategory);
                break;
            case 59:
                // 販売Ｃ
                res = Label.getValue(Label.salesEmC);
                break;

            case 60:
                // 販売Ｓ
                res = Label.getValue(Label.salesEmS);
                break;
            case 61:
                // 販売Ｅ
                res = Label.getValue(Label.salesEmE);
                break;
            case 62:
                // 製造Ｃ
                res = Label.getValue(Label.seizouEmC);
                break;
            case 63:
                // 製造Ｓ
                res = Label.getValue(Label.seizouEmS);
                break;
            case 64:
                // 製造Ｅ
                res = Label.getValue(Label.seizouEmE);
                break;

            default :
                break;
        }
        return utils.stringCsv(res);
    }

    /**
     * CSVの3行目以降(一覧データ)を取得
     * @throws Exception 
     */
    private String getCsvData(ResultSet rset, ResultSetManeger resultSetManeger, int col) throws Exception {
        String res = "";
        String val = "";
        String valGen = "";//20180302 原価回収基準対応　ADD
                        
        int csvQuartKbn =0;
        BigDecimal dec = null;
        switch(col){
            case 0:
                // 案件番号
                res = resultSetManeger.getResultSetValue(rset, "ANKEN_ID");
                break;
            case 1:
                // 売上基準
                val = resultSetManeger.getResultSetValue(rset, "SALES_CLASS");
                valGen = resultSetManeger.getResultSetValue(rset, "SALES_CLASS_GENKA");//20180302 原価回収基準対応　ADD

                //res = syuuekiUtils.getSalesClassLabelFull(val);//20180302 原価回収基準対応　REP
                res = syuuekiUtils.getSalesClassLabelAddLoss(syuuekiUtils.getSalesClassLabelGenFull(val,valGen), resultSetManeger.getResultSetValue(rset, "LOSS_CONTROL_FLAG"));//20180302 原価回収基準対応　REP  // 2018/06/01 ロスコン対応
                break;
            case 2:
                // 売上区分
                val = resultSetManeger.getResultSetValue(rset, "URIAGE_END_FLG");
                if("1".equals(val) || "2".equals(val)){
                    res = syuuekiUtils.getUriageEndLabel(val, 1);
                }
                break;
            case 3:
                // 注番
                res = resultSetManeger.getResultSetValue(rset, "ORDER_NO");
                break;
            case 4:
                // S/N
                res = resultSetManeger.getResultSetValue(rset, "SN_KBN");
                if("X".equals(res)){
                    res = "";
                }
                res = syuuekiUtils.getSNLabel(res);
                break;
            case 5:
                // (発番)売上予定
                val = resultSetManeger.getResultSetValue(rset, "HAT_URIAGE_YOTEI");
                if (StringUtil.isNotEmpty(val)) {
                    SimpleDateFormat sdf = new SimpleDateFormat(miriSecFormat);
                    res = syuuekiUtils.exeFormatYm(sdf.parse(val));
                    csvQuartKbn = 1;
                }
                break;
            case 6:
                // (発番)出荷日限
                val = resultSetManeger.getResultSetValue(rset, "HAT_SYUKKA_NICHIGEN");
                if (StringUtil.isNotEmpty(val)) {
                    SimpleDateFormat sdf = new SimpleDateFormat(miriSecFormat);
                    res = syuuekiUtils.exeFormatYmd(sdf.parse(val));
                    csvQuartKbn = 1;
                }
                break;
            case 7:
                // (発番)回収年月
                val = resultSetManeger.getResultSetValue(rset, "HAT_KAISYU_YOTEI");
                if (StringUtil.isNotEmpty(val)) {
                    SimpleDateFormat sdf = new SimpleDateFormat(miriSecFormat);
                    res = syuuekiUtils.exeFormatYm(sdf.parse(val));
                    csvQuartKbn = 1;
                }
                break;
            case 8:
                // 本社部課
                res = resultSetManeger.getResultSetValue(rset, "ATSUKAI_TEAM_CODE");
                break;
            case 9:
                // 販売C
                res = resultSetManeger.getResultSetValue(rset, "ATSUKAI_C_CODE");
                break;

            case 10:
                // 注文主
                res = resultSetManeger.getResultSetValue(rset, "TRADE_NAME");
                break;
            case 11:
                // 設置場所
                res = resultSetManeger.getResultSetValue(rset, "STCH_NAME");
                break;
            case 12:
                // 品名
                res = resultSetManeger.getResultSetValue(rset, "ANKEN_NAME");
                break;
            case 13:
                // 契約通貨
                res = resultSetManeger.getResultSetValue(rset, "KEIYAKU_CUR_CODE");
                break;
            case 14:
                // 前回外貨SP
                res = syuuekiUtils.changeDispCurrencyFormat(resultSetManeger.getResultSetValue(rset, "SAISYU_SP_GAIKA_OLD"), s001Bean.getJpyUnitKbn(), resultSetManeger.getResultSetValue(rset, "KEIYAKU_CUR_CODE"));
                break;
            case 15:
                // 前回受注レート
                res = syuuekiUtils.exeFormatRateString(resultSetManeger.getResultSetValue(rset, "SAISYU_JYUCHU_RATE_OLD"));
                break;
            case 16:
                // 前回売上レート
                res = syuuekiUtils.exeFormatRateString(resultSetManeger.getResultSetValue(rset, "SAISYU_URIAGE_RATE_OLD"));
                break;
            case 17:
                // 前回最終見込SP
                val = resultSetManeger.getResultSetValue(rset, "SAISYU_SP_OLD");
                if (StringUtil.isNotEmpty(val)) {
                    res = syuuekiUtils.exeFormatUnit(syuuekiUtils.changeUnit((new BigDecimal(val)), s001Bean.getJpyUnitKbn()));
                }
                break;
            case 18:
                // 前回最終見込NET
                val = resultSetManeger.getResultSetValue(rset, "SAISYU_NET_OLD");
                if (StringUtil.isNotEmpty(val)) {
                    res = syuuekiUtils.exeFormatUnit(syuuekiUtils.changeUnit((new BigDecimal(val)), s001Bean.getJpyUnitKbn()));
                }
                break;
            case 19:
                // 前回最終見込M率
                res = syuuekiUtils.exeFormatRateString(resultSetManeger.getResultSetValue(rset, "SAISYU_MRITU_OLD"));
                break;

            case 20:
                // 前回受注月
                val = resultSetManeger.getResultSetValue(rset, "JYUCHU_END_OLD");
                if (StringUtil.isNotEmpty(val)) {
                    SimpleDateFormat sdf = new SimpleDateFormat(miriSecFormat);
                    res = syuuekiUtils.exeFormatYm(sdf.parse(val));
                    csvQuartKbn = 1;
                }
                break;
            case 21:
                // 前回売上月
                val = resultSetManeger.getResultSetValue(rset, "URIAGE_END_OLD");
                if (StringUtil.isNotEmpty(val)) {
                    SimpleDateFormat sdf = new SimpleDateFormat(miriSecFormat);
                    res = syuuekiUtils.exeFormatYm(sdf.parse(val));
                    csvQuartKbn = 1;
                }
                break;
            case 22:
                // 今回外貨SP
                res = syuuekiUtils.changeDispCurrencyFormat(resultSetManeger.getResultSetValue(rset, "SAISYU_SP_GAIKA"), s001Bean.getJpyUnitKbn(), resultSetManeger.getResultSetValue(rset, "KEIYAKU_CUR_CODE"));
                break;
            case 23:
                // 今回受注レート
                res = syuuekiUtils.exeFormatRateString(resultSetManeger.getResultSetValue(rset, "SAISYU_JYUCHU_RATE"));
                break;
            case 24:
                // 今回売上レート
                res = syuuekiUtils.exeFormatRateString(resultSetManeger.getResultSetValue(rset, "SAISYU_URIAGE_RATE"));
                break;
            case 25:
                // 今回最終見込SP
                val = resultSetManeger.getResultSetValue(rset, "SAISYU_SP");
                if (StringUtil.isNotEmpty(val)) {
                    res = syuuekiUtils.exeFormatUnit(syuuekiUtils.changeUnit((new BigDecimal(val)), s001Bean.getJpyUnitKbn()));
                }
                break;
            case 26:
                // 今回最終見込NET
                val = resultSetManeger.getResultSetValue(rset, "SAISYU_NET");
                if (StringUtil.isNotEmpty(val)) {
                    res = syuuekiUtils.exeFormatUnit(syuuekiUtils.changeUnit((new BigDecimal(val)), s001Bean.getJpyUnitKbn()));
                }
                break;
            case 27:
                // 今回最終見込M率
                res = syuuekiUtils.exeFormatRateString(resultSetManeger.getResultSetValue(rset, "SAISYU_MRITU"));
                break;
            case 28:
                // 今回受注月
                val = resultSetManeger.getResultSetValue(rset, "JYUCHU_END");
                if (StringUtil.isNotEmpty(val)) {
                    SimpleDateFormat sdf = new SimpleDateFormat(miriSecFormat);
                    res = syuuekiUtils.exeFormatYm(sdf.parse(val));
                    csvQuartKbn = 1;
                }
                break;
            case 29:
                // 今回売上月
                val = resultSetManeger.getResultSetValue(rset, "URIAGE_END");
                if (StringUtil.isNotEmpty(val)) {
                    SimpleDateFormat sdf = new SimpleDateFormat(miriSecFormat);
                    res = syuuekiUtils.exeFormatYm(sdf.parse(val));
                    csvQuartKbn = 1;
                }
                break;

            case 30:
                // 予算SP
                val = resultSetManeger.getResultSetValue(rset, "YOSAN_SP");
                if (StringUtil.isNotEmpty(val)) {
                    res = syuuekiUtils.exeFormatUnit(syuuekiUtils.changeUnit((new BigDecimal(val)), s001Bean.getJpyUnitKbn()));
                }
                break;
            case 31:
                // 予算NET
                val = resultSetManeger.getResultSetValue(rset, "YOSAN_NET");
                if (StringUtil.isNotEmpty(val)) {
                    res = syuuekiUtils.exeFormatUnit(syuuekiUtils.changeUnit((new BigDecimal(val)), s001Bean.getJpyUnitKbn()));
                }
                break;
            case 32:
                // 予算粗利
                dec = syuuekiUtils.arari(Utils.changeBigDecimal(resultSetManeger.getResultSetValue(rset, "YOSAN_SP")), Utils.changeBigDecimal(resultSetManeger.getResultSetValue(rset, "YOSAN_NET")));
                if (dec != null) {
                    res = syuuekiUtils.exeFormatUnit(syuuekiUtils.changeUnit(dec, s001Bean.getJpyUnitKbn()));
                }
                break;
            case 33:
                // 発番SP
                val = resultSetManeger.getResultSetValue(rset, "HAT_SP");
                if (StringUtil.isNotEmpty(val)) {
                    res = syuuekiUtils.exeFormatUnit(syuuekiUtils.changeUnit((new BigDecimal(val)), s001Bean.getJpyUnitKbn()));
                }
                break;
            case 34:
                // 発番NET
                val = resultSetManeger.getResultSetValue(rset, "HAT_NET");
                if (StringUtil.isNotEmpty(val)) {
                    res = syuuekiUtils.exeFormatUnit(syuuekiUtils.changeUnit((new BigDecimal(val)), s001Bean.getJpyUnitKbn()));
                }
                break;
            case 35:
                // 発番粗利
                dec = syuuekiUtils.arari(Utils.changeBigDecimal(resultSetManeger.getResultSetValue(rset, "HAT_SP")), Utils.changeBigDecimal(resultSetManeger.getResultSetValue(rset, "HAT_NET")));
                if (dec != null) {
                    res = syuuekiUtils.exeFormatUnit(syuuekiUtils.changeUnit(dec, s001Bean.getJpyUnitKbn()));
                }
                break;
            case 36:
                // 発番M率
                res = syuuekiUtils.mrate(Utils.changeBigDecimal(resultSetManeger.getResultSetValue(rset, "HAT_SP")), Utils.changeBigDecimal(resultSetManeger.getResultSetValue(rset, "HAT_NET")));
                break;
            case 37:
                // 契約SP累計
                val = resultSetManeger.getResultSetValue(rset, "KEIYAKU_SP");
                if (StringUtil.isNotEmpty(val)) {
                    res = syuuekiUtils.exeFormatUnit(syuuekiUtils.changeUnit((new BigDecimal(val)), s001Bean.getJpyUnitKbn()));
                }
                break;
            case 38:
                // 契約最終連番
                res = resultSetManeger.getResultSetValue(rset, "KEIYAKU_RENBAN_MAX");
                if (StringUtil.isNotEmpty(res)) {
                    csvQuartKbn = 1;
                }
                break;
            case 39:
                // 売上済SP
                val = resultSetManeger.getResultSetValue(rset, "URIAGE_SP");
                if (StringUtil.isNotEmpty(val)) {
                    res = syuuekiUtils.exeFormatUnit(syuuekiUtils.changeUnit((new BigDecimal(val)), s001Bean.getJpyUnitKbn()));
                }
                break;

            case 40:
                // 売上済NET
                val = resultSetManeger.getResultSetValue(rset, "URIAGE_NET");
                if (StringUtil.isNotEmpty(val)) {
                    res = syuuekiUtils.exeFormatUnit(syuuekiUtils.changeUnit((new BigDecimal(val)), s001Bean.getJpyUnitKbn()));
                }
                break;
            case 41:
                // 売上済粗利
                dec = syuuekiUtils.arari(Utils.changeBigDecimal(resultSetManeger.getResultSetValue(rset, "URIAGE_SP")), Utils.changeBigDecimal(resultSetManeger.getResultSetValue(rset, "URIAGE_NET")));
                if (dec != null) {
                    res = syuuekiUtils.exeFormatUnit(syuuekiUtils.changeUnit(dec, s001Bean.getJpyUnitKbn()));
                }
                break;
            case 42:
                // 残SP
                val = resultSetManeger.getResultSetValue(rset, "JYUCHU_ZAN_SP");
                if (StringUtil.isNotEmpty(val)) {
                    res = syuuekiUtils.exeFormatUnit(syuuekiUtils.changeUnit((new BigDecimal(val)), s001Bean.getJpyUnitKbn()));
                }
                break;
            case 43:
                // 残NET
                val = resultSetManeger.getResultSetValue(rset, "JYUCHU_ZAN_NET");
                if (StringUtil.isNotEmpty(val)) {
                    res = syuuekiUtils.exeFormatUnit(syuuekiUtils.changeUnit((new BigDecimal(val)), s001Bean.getJpyUnitKbn()));
                }
                break;
            case 44:
                // 残粗利
                dec = syuuekiUtils.arari(Utils.changeBigDecimal(resultSetManeger.getResultSetValue(rset, "JYUCHU_ZAN_SP")), Utils.changeBigDecimal(resultSetManeger.getResultSetValue(rset, "JYUCHU_ZAN_NET")));
                if (dec != null) {
                    res = syuuekiUtils.exeFormatUnit(syuuekiUtils.changeUnit(dec, s001Bean.getJpyUnitKbn()));
                }
                break;
            case 45:
                // 中計SP
                val = resultSetManeger.getResultSetValue(rset, "CHUKEI_SP");
                if (StringUtil.isNotEmpty(val)) {
                    res = syuuekiUtils.exeFormatUnit(syuuekiUtils.changeUnit((new BigDecimal(val)), s001Bean.getJpyUnitKbn()));
                }
                break;
            case 46:
                // 中計NET
                val = resultSetManeger.getResultSetValue(rset, "CHUKEI_NET");
                if (StringUtil.isNotEmpty(val)) {
                    res = syuuekiUtils.exeFormatUnit(syuuekiUtils.changeUnit((new BigDecimal(val)), s001Bean.getJpyUnitKbn()));
                }
                break;
            case 47:
                // 中計粗利
                dec = syuuekiUtils.arari(Utils.changeBigDecimal(resultSetManeger.getResultSetValue(rset, "CHUKEI_SP")), Utils.changeBigDecimal(resultSetManeger.getResultSetValue(rset, "CHUKEI_NET")));
                if (dec != null) {
                    res = syuuekiUtils.exeFormatUnit(syuuekiUtils.changeUnit(dec, s001Bean.getJpyUnitKbn()));
                }
                break;
            case 48:
                // 備考
                val = resultSetManeger.getResultSetValue(rset, "BIKOU_KIKAN");
                if (StringUtil.isNotEmpty(val)) {
                    res = StringUtils.replace(val, Env.getValue(Env.CsvLineBreak), "");
                    res = StringUtils.replace(res, "\n", "");
                    //res = val.replaceAll(Env.getValue(Env.CsvLineBreak), "");
                }
                break;
            case 49:
                // 営業部門
                res = resultSetManeger.getResultSetValue(rset, "HAT_EG_BUKA_RNM");;
                break;

            case 50:
                // 担当者名
                res = resultSetManeger.getResultSetValue(rset, "HAT_EG_EMP_NM");
                break;
            case 51:
                // サブBUコード
                res = resultSetManeger.getResultSetValue(rset, "SUB_BU_ID");
                break;
            case 52:
                // サブBU名称
                res = resultSetManeger.getResultSetValue(rset, "SUB_BU_NAME");
                break;
            case 53:
                // プラントコード
                res = resultSetManeger.getResultSetValue(rset, "PLANT_CODE");
                break;
            case 54:
                // 収益分類
                res = resultSetManeger.getResultSetValue(rset, "BUNRUI_NM");
                break;
            case 55:
                // 取扱店CD
                res = resultSetManeger.getResultSetValue(rset, "TORIATSU_CD");
                break;
            case 56:
                // 販売チーム
                res = resultSetManeger.getResultSetValue(rset, "EG_TEAM_CD");
                break;
            case 57:
                // 製造チーム
                res = resultSetManeger.getResultSetValue(rset, "SZ_TEAM_CD");
                break;
            case 58:
                // 業態
                res = resultSetManeger.getResultSetValue(rset, "GYOTAI");
                break;
            case 59:
                // 販売Ｃ
                res = resultSetManeger.getResultSetValue(rset, "HB_C_CD");
                break;

            case 60:
                // 販売Ｓ
                res = resultSetManeger.getResultSetValue(rset, "HB_S_CD");
                break;
            case 61:
                // 販売Ｅ
                res = resultSetManeger.getResultSetValue(rset, "HB_E_CD");
                break;
            case 62:
                // 製造Ｃ
                res = resultSetManeger.getResultSetValue(rset, "SZ_C_CD");
                break;
            case 63:
                // 製造Ｓ
                res = resultSetManeger.getResultSetValue(rset, "SZ_S_CD");
                break;
            case 64:
                // 製造Ｅ
                res = resultSetManeger.getResultSetValue(rset, "SZ_E_CD");
                break;

            default :
                break;
        }
        return utils.stringCsv(res, csvQuartKbn);
    }

    /**
     * 初期表示 ビジネスロジック
     */
    public void downloadExecute() throws Exception {
        SqlFile sqlFile = new SqlFile();
        
        // 抽出対象案件の検索条件を取得
        Map<String, Object> condition = s001Service.getCondition();

        // 月次確定か予算だったら履歴IDを取得する
        if (!"R".equals(s001Bean.getRirekiFlg())) {
            s001Bean.setRirekiIdList("0");
        } else {
            s001Bean.setRirekiIdList(syuWfControlTblFacade.findRirekiId(condition));
        }
        condition.put("rirekiId", Arrays.asList(s001Bean.getRirekiIdList().split(",")));
        condition.put("listFlg", "0");
        
        String sqlFilePath = "/sql/selectListSyuueki.sql";
        String sqlString = sqlFile.getSqlString(sqlFilePath, condition);
        Object[] params = sqlFile.getSqlParams(sqlFilePath, condition);
        
        List<Map<String, Object>> ankenList = dbUtilsExecutor.dbUtilsGetSqlList(em, sqlString, params);
        if (ankenList != null && !ankenList.isEmpty()) {
            for (Map<String, Object> data : ankenList) {
                System.out.println("案件番号=" + data.get("ANKEN_ID") + " 履歴ID=" + data.get("RIREKI_ID"));
            }
        }
        
        int selectStartPosition = StringUtils.indexOf(sqlString, "SELECT ");
        int fromStartPosition = StringUtils.indexOf(sqlString, "FROM ");
        int whereStartPosition = StringUtils.indexOf(sqlString, "WHERE ");
        int orderByStartPosition = StringUtils.indexOf(sqlString, "ORDER BY ");
        
        String selectOnly = StringUtils.substring(sqlString, selectStartPosition, fromStartPosition-1);
        String fromOnly = StringUtils.substring(sqlString, fromStartPosition, whereStartPosition-1);
        String whereOnly = StringUtils.substring(sqlString, whereStartPosition, orderByStartPosition-1);

        int selectParamCount = selectOnly.replaceAll("[^?]", "").length();
        int fromParamCount = fromOnly.replaceAll("[^?]", "").length();
        int beforeWhereParamCount = selectParamCount + fromParamCount;
        
        System.out.println("beforeWhereParamCount=" + beforeWhereParamCount);
        Object[] whereParams = Arrays.copyOfRange(params, beforeWhereParamCount, params.length);
        
//        List<Object> paramList = Arrays.asList(params);
//        for (int i=0; i<beforeWhereParamCount; i++) paramList.remove(i);
//        Object[] whereParams = (Object[])paramList.toArray(new String[0]);

        for (Object a : whereParams) {
            System.out.println("a=" + a);
        }
        
        String newSQL = "select * from SYU_GE_BUKKEN_INFO_TBL A " + whereOnly + " ORDER BY A.ANKEN_ID DESC";
        List<Map<String, Object>> ankenList2 = dbUtilsExecutor.dbUtilsGetSqlList(em, newSQL, whereParams);
        if (ankenList2 != null && !ankenList2.isEmpty()) {
            for (Map<String, Object> data : ankenList2) {
                System.out.println("案件番号2=" + data.get("ANKEN_ID") + " 履歴ID2=" + data.get("RIREKI_ID"));
            }
        }
        
        // 出力対象が、受注残一覧もしくはサマリ表で、
        // データ種別が、月次確定もしくは予算の場合、
        // 検索条件の対象期を、年度と期にセットする。
//        if ("1".equals(s001Bean.getOutputKbn()) 
//                || "2".equals(s001Bean.getOutputKbn())) {
//            // データ種別 = 月次確定
//            if ("M".equals(s001Bean.getDataKbn()) && !StringUtils.isEmpty(s001Bean.getTaishoYm())) {
//                 Integer year = syuuekiUtils.getIntegerYear(s001Bean.getTaishoYm());
//                 Integer month = syuuekiUtils.getIntegerMonth(s001Bean.getTaishoYm());
//                 if (month <= 3) {
//                     year = year - 1;
//                     s001Bean.setTaishoKi("S");
//                 } else if (month >= 4 && month <= 9) {
//                     s001Bean.setTaishoKi("K");
//                 } else if (month >= 10) {
//                     s001Bean.setTaishoKi("S");
//                 }
//                 s001Bean.setTaishoY(year.toString());
//            // データ種別 = 予算     
//            } else if ("Y".equals(s001Bean.getDataKbn()) && !StringUtils.isEmpty(s001Bean.getTaishoYm())) {
//            
//                
//            }   
//        }
        
    }

    /**
     * 操作ログ登録用dtoの取得
     */
    private OperationLog getOperationLogDto(Map<String, Object> condition) {
        OperationLog operationLog = operationLogService.getOperationLog();
        operationLog.setObjectType("ANKEN");

        // 操作ログに記録の必要がない情報をmapから削除。
        Map<String, Object> cloneCondtion = new LinkedHashMap<>(condition);
        cloneCondtion.remove("memberJobGr");

//        String stringConditon = syuuekiUtils.changeStringCondtion(cloneCondtion);
//        operationLog.setRemarks(stringConditon);
        String remarks = "";
        String outPutKbn = StringUtils.defaultString(s001Bean.getOutputKbn());
        switch (outPutKbn) {
            case "1":
                remarks = "案件一覧(月展開)";
                break;
            case "2":
                remarks = "サマリ表(月展開)";
                break;
            case "3":
                remarks = "受注残一覧";
                break;
            case "4":
                remarks = "一覧CSV";
                break;
        }
        operationLog.setRemarks(remarks);

        return operationLog;
    }
}
