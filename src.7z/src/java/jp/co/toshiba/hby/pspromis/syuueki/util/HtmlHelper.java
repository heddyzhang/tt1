package jp.co.toshiba.hby.pspromis.syuueki.util;

import java.io.Serializable;
import javax.enterprise.context.ApplicationScoped;
import javax.inject.Named;
import org.apache.commons.lang3.StringUtils;

/**
 * HTML エスケープユーティリティ<br>
 * ELからも使用可能なようにCDI管理する(namespece="html", scope="ApplicationScoped")
 * @author (NPC)S.Ibayashi
 */
@Named(value = "html")
@ApplicationScoped
public class HtmlHelper implements Serializable {

    /**
     * 半角スペースをhtml表示用に変換(" " → &nbsp;)
     * @param label
     * @return 
     */
    public Object nbsp(Object label) {
        if (!(label instanceof String)) {
            return label;
        }

        String strLabel = (String)label;
        if (StringUtils.isEmpty(strLabel)) {
            return label;
        }

        return StringUtils.replace(strLabel, " ", "&nbsp;");
    }

    /**
     * 改行コードをhtml表示用に変換("\r\n","\n" → "<br/>")
     * @param label
     * @return 
     */
    public Object toBr(Object label) {
        if (!(label instanceof String)) {
            return label;
        }

        String strLabel = (String)label;
        if (StringUtils.isEmpty(strLabel)) {
            return label;
        }

        strLabel = StringUtils.replace(strLabel, "\r\n", "<br/>");
        strLabel = StringUtils.replace(strLabel, "\n", "<br/>");
        return strLabel;
    }
}
