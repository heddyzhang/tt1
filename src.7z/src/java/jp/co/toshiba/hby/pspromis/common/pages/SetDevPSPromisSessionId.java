package jp.co.toshiba.hby.pspromis.common.pages;

import javax.enterprise.context.RequestScoped;
import javax.inject.Named;
import javax.faces.context.ExternalContext;
import javax.faces.context.FacesContext;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 *
 * @author ibayashi
 */
@Named(value = "setDevPSPromisSessionId")
@RequestScoped
public class SetDevPSPromisSessionId {
    private static final Logger logger = LoggerFactory.getLogger(SetDevPSPromisSessionId.class);

    private Integer sessionIdFlg = 0;

    /**
     * Creates a new instance of SetDevPSPromisSessionId
     */
    public SetDevPSPromisSessionId() {
    }

    public void index() {
        logger.debug("SetDevPSPromisSessionId.index()");
        FacesContext facesContext = FacesContext.getCurrentInstance();
        ExternalContext externalContext = facesContext.getExternalContext();

        HttpServletRequest request = (HttpServletRequest)externalContext.getRequest();
        HttpServletResponse response = (HttpServletResponse)externalContext.getResponse();

        Cookie cookies[] = request.getCookies();
        if (cookies != null){
            for (Cookie cookie : cookies){
                logger.debug("CookieName=" + cookie.getName() + " CookieValue=" + cookie.getValue());
                if ("PSPromisSSOSessionIdDEV".equals(cookie.getName())) {
                    logger.debug("PSPromisSSOSessionIdDEVからPSPromisSessionInfoにコピー");
                    String val = cookie.getValue();

                    Cookie resCookie = new Cookie("PSPromisSessionId", val);
                    resCookie.setDomain(".hby.toshiba.co.jp");
                    resCookie.setPath("/");
                    response.addCookie(resCookie);
                    
                    this.setSessionIdFlg(1);
                }
            }
        }
 
    }
    
    public Integer getSessionIdFlg() {
        return sessionIdFlg;
    }

    public void setSessionIdFlg(Integer sessionIdFlg) {
        this.sessionIdFlg = sessionIdFlg;
    }

}
