/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package jp.co.toshiba.hby.pspromis.syuueki.bean;

import javax.enterprise.context.RequestScoped;
import javax.inject.Named;

/**
 *
 * @author ibayashi
 */
@Named(value = "bookMarkBean")
@RequestScoped
public class BookMarkBean extends AbstractBean {
    
    /**
     * 登録/解除FLG(1:登録 0:解除)
     */
    private String insertFlg = "0";

    /**
     * BookMark存在Flg(1:存在する 0:存在しない)
     */
    private int bookMarkFlg = 0;
    
    /**
     * Creates a new instance of BookMarkBean
     */
    public BookMarkBean() {
    }

    public String getInsertFlg() {
        return insertFlg;
    }

    public void setInsertFlg(String insertFlg) {
        this.insertFlg = insertFlg;
    }

    public int getBookMarkFlg() {
        return bookMarkFlg;
    }

    public void setBookMarkFlg(int bookMarkFlg) {
        this.bookMarkFlg = bookMarkFlg;
    }
    
}
