package jp.co.toshiba.hby.pspromis.syuueki.facade;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.ejb.Stateless;
import javax.interceptor.Interceptors;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import jp.co.toshiba.hby.pspromis.syuueki.entity.AnkenMitumoriTbl;
import jp.co.toshiba.hby.pspromis.syuueki.interceptor.TranceInterceptor;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 *
 * @author ganryu
 */
@Stateless
@Interceptors({TranceInterceptor.class})
public class AnkenMitsumoriNoFacade extends AbstractFacade<AnkenMitumoriTbl> {

    /**
     * ロガ－
     */
    private static final Logger logger = LoggerFactory.getLogger(AnkenMitsumoriNoFacade.class);

    @PersistenceContext(unitName = jp.co.toshiba.hby.pspromis.syuueki.util.ConstantString.syuuekiDataSourceName)
    private EntityManager em;

    @Override
    protected EntityManager getEntityManager() {
        return em;
    }

    public AnkenMitsumoriNoFacade() {
        super(AnkenMitumoriTbl.class);
    }

    /**
     *
     * @param condition
     * @return
     */
    public AnkenMitumoriTbl getAnkenMitsumoriNo(Object condition) {
        return sqlExecutor.getSingleResult(em, AnkenMitumoriTbl.class, "/sql/selectAnkenMitsumoriNo.sql", condition);
    }   
}
