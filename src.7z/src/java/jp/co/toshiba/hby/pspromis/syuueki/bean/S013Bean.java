package jp.co.toshiba.hby.pspromis.syuueki.bean;

import java.util.List;
import java.util.Map;
import javax.enterprise.context.RequestScoped;
import javax.inject.Named;
import jp.co.toshiba.hby.pspromis.syuueki.entity.SyuWfControlTbl;
import jp.co.toshiba.hby.pspromis.syuueki.entity.BuMst;

/**
 *
 * @author ibayashi
 */
@Named(value = "s013Bean")
@RequestScoped
public class S013Bean extends AbstractBean {

    /**
     * 一覧検索フラグ
     */
    private String listFlg = "0";

    /**
     * 現在表示するページ番号
     */
    private Integer page;

    /**
     * 一覧表示データ総件数
     */
    private Integer count;

    /**
     * 検索条件：事業部
     */
    private String[] divisionCode;

    /**
     * 検索条件・営業部門
     */
    private String eigyoSectionCode;
   
    /**
     * 検索条件・データ種別（G：月次確定、Y:予算ベース）
     * Step3(2015下)Add
     */
    private String syubetsu;
    
    /**
     * 検索条件・確定月From
     */
    private String fixedYmFrom;
    
    /**
     * 検索条件・確定月月To
     */
    private String fixedYmTo;

    /**
     * 検索条件・対象
     * Step3(2015下)Add
     */
    private String taisho;
    
    /**
     * 検索条件・売上基準(進行基準)
     */
    private String[] salesClass;

    /**
     * 検索条件・BUコード
     */
    private String[] buCode;
    
    /**
     * 検索条件：営業部門選択候補の一覧
     */
    private List<Map<String, Object>> eigyoSectionList;
    
    /**
     * 検索条件：BUマスタの情報
     */
    private List<BuMst> buMstList;

    /**
     * 対象選択候補の一覧
     */
    private List<Map<String, Object>> taishoList;
    
    /**
     * 一覧取得結果
     */
    private List<SyuWfControlTbl> list;

    /**
     * 検索条件:BUを出力する事業部コード(複数事業部が存在する場合、カンマ区切りにする)
     */
    private String buDivisionCodes;

    /**
     * Creates a new instance of S001Bean
     */
    public S013Bean() {
    }

    public String getListFlg() {
        return listFlg;
    }

    public void setListFlg(String listFlg) {
        this.listFlg = listFlg;
    }

    public String[] getDivisionCode() {
        return divisionCode;
    }

    public void setDivisionCode(String[] divisionCode) {
        this.divisionCode = divisionCode;
    }

    public String getEigyoSectionCode() {
        return eigyoSectionCode;
    }

    public void setEigyoSectionCode(String eigyoSectionCode) {
        this.eigyoSectionCode = eigyoSectionCode;
    }

    public String getSyubetsu() {
        return syubetsu;
    }

    public void setSyubetsu(String syubetsu) {
        this.syubetsu = syubetsu;
    }

    public String getFixedYmFrom() {
        return fixedYmFrom;
    }

    public void setFixedYmFrom(String fixedYmFrom) {
        this.fixedYmFrom = fixedYmFrom;
    }

    public String getFixedYmTo() {
        return fixedYmTo;
    }

    public void setFixedYmTo(String fixedYmTo) {
        this.fixedYmTo = fixedYmTo;
    }

    public String getTaisho() {
        return taisho;
    }

    public void setTaisho(String taisho) {
        this.taisho = taisho;
    }

    public String[] getSalesClass() {
        return salesClass;
    }

    public void setSalesClass(String[] salesClass) {
        this.salesClass = salesClass;
    }

    public List<SyuWfControlTbl> getList() {
        return list;
    }

    public void setList(List<SyuWfControlTbl> list) {
        this.list = list;
    }

    public Integer getPage() {
        return page;
    }

    public void setPage(Integer page) {
        this.page = page;
    }

    public Integer getCount() {
        return count;
    }

    public void setCount(Integer count) {
        this.count = count;
    }

    public List<Map<String, Object>> getEigyoSectionList() {
        return eigyoSectionList;
    }

    public void setEigyoSectionList(List<Map<String, Object>> eigyoSectionList) {
        this.eigyoSectionList = eigyoSectionList;
    }

    public List<Map<String, Object>> getTaishoList() {
        return taishoList;
    }

    public void setTaishoList(List<Map<String, Object>> taishoList) {
        this.taishoList = taishoList;
    }

    public String[] getBuCode() {
        return buCode;
    }

    public void setBuCode(String[] buCode) {
        this.buCode = buCode;
    }

    public List<BuMst> getBuMstList() {
        return buMstList;
    }

    public void setBuMstList(List<BuMst> buMstList) {
        this.buMstList = buMstList;
    }

    public String getBuDivisionCodes() {
        return buDivisionCodes;
    }

    public void setBuDivisionCodes(String buDivisionCodes) {
        this.buDivisionCodes = buDivisionCodes;
    }

}
