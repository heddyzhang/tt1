package jp.co.toshiba.hby.pspromis.syuueki.servlet;

import java.util.HashMap;
import java.util.Map;
import javax.inject.Inject;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpServletRequest;
import jp.co.toshiba.hby.pspromis.syuueki.bean.ResultMessageBean;
import jp.co.toshiba.hby.pspromis.syuueki.bean.S008Bean;
import jp.co.toshiba.hby.pspromis.syuueki.bean.ValidationInfoBean;
import jp.co.toshiba.hby.pspromis.syuueki.service.S008Service;
import jp.co.toshiba.hby.pspromis.syuueki.util.CdiUtils;
import jp.co.toshiba.hby.pspromis.syuueki.util.ConstantString;
import jp.co.toshiba.hby.pspromis.syuueki.util.ParameterBinder;
import jp.co.toshiba.hby.pspromis.syuueki.validation.S008Validation;
import org.apache.commons.lang3.StringUtils;

/**
 * PS-Promis収益管理システム 収益情報編集 Servlet
 *
 * @author kitajima
 */
@WebServlet(name = "S008", urlPatterns = {"/servlet/S008", "/servlet/S008/*"})
public class S008Servlet extends AbstractServlet {

    /**
     * jsp
     */
    private static final String INDEX_JSP = "S008/s008.jsp";

    /**
     * 使用serviceクラスをinjection(CDI)<br>
     * InjectアノテーションよりAPサーバー(Glassfish)側で自動的にインスタンス作成(new)される。<br>
     * service側はステートレスセッションbeanにするため、Statelessアノテーションをつけておくこと。<br>
     */
    @Inject
    private S008Service s008Service;

    /**
     * パラメータ格納クラスをinjection(CDI)<br>
     * InjectアノテーションよりAPサーバー(Glassfish)側で自動的にインスタンス作成(new)される。<br>
     */
    @Inject
    private S008Bean s008Bean;

    //@Inject
    //private SysdateEntityFacade sysdateFacade;
    @Inject
    private ValidationInfoBean validationInfoBean;

    /**
     * 初期表示
     *
     * @param req
     * @param resp
     * @return
     * @throws Exception
     */
    public String indexAction(HttpServletRequest req, HttpServletResponse resp)
            throws Exception {
        logger.info("S008Servlet#indexAction");

        ParameterBinder.Bind(s008Bean, req);

        // 参照モードとして開く
        s008Bean.setEditFlg("0");

        // サービスの実行(トランザクションの単位にもなる)
        s008Service.indexExecute();

        return INDEX_JSP;
    }

    /**
     * 編集表示
     *
     * @param req
     * @param resp
     * @return
     * @throws Exception
     */
    public String editAction(HttpServletRequest req, HttpServletResponse resp)
            throws Exception {
        logger.info("S008Servlet#editAction");

        // リクエストパラメータをs008Beanの同名フィールドに一括コピー
        ParameterBinder.Bind(s008Bean, req);

        s008Service.indexExecute();

        // 編集モードに変更。
        // 白地案件の場合はEditFlg=2にする
        if ("1".equals(s008Bean.getShirajiFlg())) {
            s008Bean.setEditFlg("2");
        } else {
            s008Bean.setEditFlg("1");
        }

        return INDEX_JSP;
    }

    /**
     * 保存
     *
     * @param req
     * @param resp
     * @return
     * @throws Exception
     */
    public String saveAction(HttpServletRequest req, HttpServletResponse resp)
            throws Exception {
        logger.info("S008Servlet#saveAction");

        ParameterBinder.Bind(s008Bean, req);

        // 当年月(現在の勘定年月)の取得
        s008Service.findKanjyoYm();

        // 2017/11/14 ADD #5 #12 #22 （収益）受注年月と（収益）売上予定を加える
        // それぞれの項目の編集権限を取得する(保存ボタン押下後に取得すること)
        s008Service.getYmEditFlg();
        
        // 処理対象事業部が(原子力)であるかを判断するための情報をbeanにセット(後続のバリデーションチェックで利用する)
        s008Service.setBeanIsNuclear();

        // パラメータのバリデーションチェック
        S008Validation validation = new S008Validation(s008Bean);
        validation.execListValidation(validationInfoBean);


        //存在チェックを追加する。
        s008Service.existsValidation();

        String flg;

        if (validationInfoBean.isSuccess()) {

            // サービスの実行(トランザクションの単位にもなる)
            // ※バリデーションチェックに通った場合のみサービス実行。
            s008Service.save();
            flg = "1";
        } else {
            flg = "9";
        }

        // 結果セットをjson出力
        Map<String, Object> jsonMap = new HashMap<>();
        ResultMessageBean resultMessageBean = CdiUtils.getBean(ResultMessageBean.class);
        resultMessageBean.createResultMessage(jsonMap);
        jsonMap.put("flg", flg);
        jsonMap.put("ankenId", s008Bean.getAnkenId());
        jsonMap.put("rirekiId", s008Bean.getRirekiId());
        jsonMap.put("shirajiFlg", s008Bean.getShirajiFlg());
        jsonMap.put("messageInfo", validationInfoBean.getMessages());
        resopnseDecodeJson(resp, jsonMap);

        return null;
    }

    /**
     * データチェック処理
     *
     * @param req
     * @param resp
     * @return
     * @throws Exception
     */
    public String checkAction(HttpServletRequest req, HttpServletResponse resp)
            throws Exception {
        logger.info("S008Servlet#checkAction");

        ParameterBinder.Bind(s008Bean, req);

        Map<String, Object> jsonMap = new HashMap<>();

        if (ConstantString.salesClassS.equals(s008Bean.getSalesClass())) {
            // 進行基準の場合
            Integer checkFlg = 0;
            Integer result1 = 0;
            Integer result2 = 0;

            // 注入パターンが選択されている場合のみ、保存前チェックを行う。
            if (StringUtils.isNotEmpty(s008Bean.getChunyuPtnNo())) {
                s008Service.check();
                checkFlg = 1;
                result1 = s008Bean.getSyuKiSpTukiSTblCount();
                result2 = s008Bean.getSyuKiNetCateTukiTblCount();
            }

            // 結果セットをjson出力
            jsonMap.put("checkFlg", checkFlg);
            jsonMap.put("result_1", result1);
            jsonMap.put("result_2", result2);

        } else {
            // 一般案件の場合
            int checkFlg = s008Service.checkTeamCd();
            // 結果セットをjson出力
            jsonMap.put("checkFlg", String.valueOf(checkFlg));
        }

        resopnseDecodeJson(resp, jsonMap);

        // ここでは戻すjspが存在しないため、nullを返す。
        return null;
    }

    /**
     * 事業部変更時の処理
     *
     * @param req
     * @param resp
     * @return
     * @throws Exception
     */
    public String chgDivisionAction(HttpServletRequest req, HttpServletResponse resp) throws Exception {
        logger.info("S008Servlet#chgDivisionAction");

        ParameterBinder.Bind(s008Bean, req);
        Map<String, Object> jsonMap = new HashMap<>();
        s008Service.division();
        // 結果セットをjson出力
        jsonMap.put("eigJobgrList", s008Bean.getEigJobgrList());
        jsonMap.put("syuJobgrList", s008Bean.getSyuJobgrList());
        //jsonMap.put("hatEgEmpNoList", s008Bean.getHatEgEmpNoList());
        jsonMap.put("hatEgEmpNoList", s008Bean.getEigTantoList());
        jsonMap.put("syuTantoIdList", s008Bean.getSyuTantoIdList());
        resopnseDecodeJson(resp, jsonMap);

        return null;
    }

    /**
     * JobGr変更時の処理
     *
     * @param req
     * @param resp
     * @return
     * @throws Exception
     */
    public String chgJobGrAction(HttpServletRequest req, HttpServletResponse resp) throws Exception {
        logger.info("S008Servlet#chgJobGrAcrion");

        ParameterBinder.Bind(s008Bean, req);
        Map<String, Object> jsonMap = new HashMap<>();
        s008Service.jobGr();
        // 結果セットをjson出力
        //jsonMap.put("hatEgEmpNoList", s008Bean.getHatEgEmpNoList());
        jsonMap.put("hatEgEmpNoList", s008Bean.getEigTantoList());
        jsonMap.put("syuTantoIdList", s008Bean.getSyuTantoIdList());
        resopnseDecodeJson(resp, jsonMap);

        return null;
    }

    /**
     * サブBU変更時の処理
     *
     * @param req
     * @param resp
     * @return
     * @throws Exception
     */
    public String chgSubBuAction(HttpServletRequest req, HttpServletResponse resp) throws Exception {
        logger.info("S008Servlet#chgSubBuAction");

        ParameterBinder.Bind(s008Bean, req);
        Map<String, Object> jsonMap = new HashMap<>();
        s008Service.subBu();
        // 結果セットをjson出力
        jsonMap.put("bunruiCdList", s008Bean.getBunruiCdList());
        jsonMap.put("setuBunruiCdList", s008Bean.getSetuBunruiCdList());
        resopnseDecodeJson(resp, jsonMap);

        return null;
    }
}
