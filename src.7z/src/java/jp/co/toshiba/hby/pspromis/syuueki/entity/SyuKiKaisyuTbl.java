/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package jp.co.toshiba.hby.pspromis.syuueki.entity;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

/**
 *
 * @author p8007icc
 */
@Entity
@Table(name = "SYU_KI_KAISYU_TBL", catalog = "", schema = "PSP0410")
@NamedQueries({
    @NamedQuery(name = "KiKaisyuTbl.findPk", query = "SELECT s FROM SyuKiKaisyuTbl s "
            + "where s.ankenId = :ankenId "
            + "and s.rirekiId = :rirekiId "
            + "and s.dataKbn = :dataKbn "
            + "and s.currencyCode = :currencyCode "
            + "and s.syuekiYm = :syuekiYm ")
})

public class SyuKiKaisyuTbl implements Serializable {

    private static final long serialVersionUID = 1L;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 32)
    @Column(name = "ANKEN_ID", nullable = false, length = 32)
    @Id
    private String ankenId;
    @Basic(optional = false)
    @NotNull
    @Column(name = "RIREKI_ID", nullable = false)
    private int rirekiId;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 2)
    @Column(name = "DATA_KBN", nullable = false, length = 2)
    private String dataKbn;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 3)
    @Column(name = "CURRENCY_CODE", nullable = false, length = 3)
    private String currencyCode;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 7)
    @Column(name = "SYUEKI_YM", nullable = false, length = 7)
    private String syuekiYm;

    @Size(max = 2)
    @Column(name = "CURRENCY_CODE_SEQ", length = 2)
    private String currencyCodeSeq;
    @Column(name = "KINSYU_KBN")
    private String kinsyuKbn;
    @Column(name = "KAISYU_KBN")
    private String kaisyuKbn;
    @Column(name = "ZEI_KBN")
    private String zeiKbn;
    // @Max(value=?)  @Min(value=?)//if you know range of your decimal fields consider using these annotations to enforce field validation
    @Column(name = "KAISYU_AMOUNT", precision = 18, scale = 3)
    private BigDecimal kaisyuAmount;
    @Column(name = "KAISYU_ZEI", precision = 18, scale = 3)
    private BigDecimal kaisyuZei;
    @Column(name = "RUIKEI_KAISYU_AMOUNT", precision = 18, scale = 3)
    private BigDecimal ruikeiKaisyuAmount;
    @Column(name = "MI_KAISYU_AMOUNT", precision = 18, scale = 3)
    private BigDecimal miKaisyuAmount;
    @Column(name = "KAISYU_ENKA_AMOUNT", precision = 18, scale = 3)
    private BigDecimal kaisyuEnkaAmount;
    @Column(name = "KAISYU_ENKA_ZEI", precision = 18, scale = 3)
    private BigDecimal kaisyuEnkaZei;
    @Column(name = "KAISYU_RATE", precision = 11, scale = 7)
    private BigDecimal kaisyuRate;
    @Column(name = "CREATED_AT")
    @Temporal(TemporalType.TIMESTAMP)
    private Date createdAt;
    @Size(max = 32)
    @Column(name = "CREATED_BY", length = 32)
    private String createdBy;
    @Column(name = "UPDATED_AT")
    @Temporal(TemporalType.TIMESTAMP)
    private Date updatedAt;
    @Size(max = 32)
    @Column(name = "UPDATED_BY", length = 32)
    private String updatedBy;
    @Column(name = "UPDATED_BATCH_AT")
    @Temporal(TemporalType.TIMESTAMP)
    private Date updatedBatchAt;
    @Size(max = 32)
    @Column(name = "UPDATED_BATCH_BY", length = 32)
    private String updatedBatchBy;

    public SyuKiKaisyuTbl() {
    }

    public String getCurrencyCodeSeq() {
        return currencyCodeSeq;
    }

    public void setCurrencyCodeSeq(String currencyCodeSeq) {
        this.currencyCodeSeq = currencyCodeSeq;
    }

    public BigDecimal getKaisyuAmount() {
        return kaisyuAmount;
    }

    public void setKaisyuAmount(BigDecimal kaisyuAmount) {
        this.kaisyuAmount = kaisyuAmount;
    }

    public BigDecimal getRuikeiKaisyuAmount() {
        return ruikeiKaisyuAmount;
    }

    public void setRuikeiKaisyuAmount(BigDecimal ruikeiKaisyuAmount) {
        this.ruikeiKaisyuAmount = ruikeiKaisyuAmount;
    }

    public BigDecimal getMiKaisyuAmount() {
        return miKaisyuAmount;
    }

    public void setMiKaisyuAmount(BigDecimal miKaisyuAmount) {
        this.miKaisyuAmount = miKaisyuAmount;
    }

    public Date getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(Date createdAt) {
        this.createdAt = createdAt;
    }

    public String getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    public Date getUpdatedAt() {
        return updatedAt;
    }

    public void setUpdatedAt(Date updatedAt) {
        this.updatedAt = updatedAt;
    }

    public String getUpdatedBy() {
        return updatedBy;
    }

    public void setUpdatedBy(String updatedBy) {
        this.updatedBy = updatedBy;
    }

    public Date getUpdatedBatchAt() {
        return updatedBatchAt;
    }

    public void setUpdatedBatchAt(Date updatedBatchAt) {
        this.updatedBatchAt = updatedBatchAt;
    }

    public String getUpdatedBatchBy() {
        return updatedBatchBy;
    }

    public void setUpdatedBatchBy(String updatedBatchBy) {
        this.updatedBatchBy = updatedBatchBy;
    }

    public String getAnkenId() {
        return ankenId;
    }

    public void setAnkenId(String ankenId) {
        this.ankenId = ankenId;
    }

    /**
     * @return the rirekiId
     */
    public int getRirekiId() {
        return rirekiId;
    }

    /**
     * @param rirekiId the rirekiId to set
     */
    public void setRirekiId(int rirekiId) {
        this.rirekiId = rirekiId;
    }

    /**
     * @return the dataKbn
     */
    public String getDataKbn() {
        return dataKbn;
    }

    /**
     * @param dataKbn the dataKbn to set
     */
    public void setDataKbn(String dataKbn) {
        this.dataKbn = dataKbn;
    }

    /**
     * @return the currencyCode
     */
    public String getCurrencyCode() {
        return currencyCode;
    }

    /**
     * @param currencyCode the currencyCode to set
     */
    public void setCurrencyCode(String currencyCode) {
        this.currencyCode = currencyCode;
    }

    /**
     * @return the syuekiYm
     */
    public String getSyuekiYm() {
        return syuekiYm;
    }

    /**
     * @param syuekiYm the syuekiYm to set
     */
    public void setSyuekiYm(String syuekiYm) {
        this.syuekiYm = syuekiYm;
    }

    public String getKinsyuKbn() {
        return kinsyuKbn;
    }

    public void setKinsyuKbn(String kinsyuKbn) {
        this.kinsyuKbn = kinsyuKbn;
    }

    public String getKaisyuKbn() {
        return kaisyuKbn;
    }

    public void setKaisyuKbn(String kaisyuKbn) {
        this.kaisyuKbn = kaisyuKbn;
    }

    public String getZeiKbn() {
        return zeiKbn;
    }

    public void setZeiKbn(String zeiKbn) {
        this.zeiKbn = zeiKbn;
    }

    public BigDecimal getKaisyuZei() {
        return kaisyuZei;
    }

    public void setKaisyuZei(BigDecimal kaisyuZei) {
        this.kaisyuZei = kaisyuZei;
    }

    public BigDecimal getKaisyuEnkaAmount() {
        return kaisyuEnkaAmount;
    }

    public void setKaisyuEnkaAmount(BigDecimal kaisyuEnkaAmount) {
        this.kaisyuEnkaAmount = kaisyuEnkaAmount;
    }

    public BigDecimal getKaisyuEnkaZei() {
        return kaisyuEnkaZei;
    }

    public void setKaisyuEnkaZei(BigDecimal kaisyuEnkaZei) {
        this.kaisyuEnkaZei = kaisyuEnkaZei;
    }

    public BigDecimal getKaisyuRate() {
        return kaisyuRate;
    }

    public void setKaisyuRate(BigDecimal kaisyuRate) {
        this.kaisyuRate = kaisyuRate;
    }

}
