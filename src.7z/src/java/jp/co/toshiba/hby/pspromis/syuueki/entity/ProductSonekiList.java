package jp.co.toshiba.hby.pspromis.syuueki.entity;

import java.io.Serializable;
import java.math.BigDecimal;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.validation.constraints.NotNull;

/**
 *
 * @author sano
 */
@Entity
public class ProductSonekiList implements Serializable {
    private static final long serialVersionUID = 1L;
    @Id
    @NotNull
    @Column(name = "ANKEN_ID")
    private String ankenId;
    
    @Id
    @Column(name = "KOJO_CODE")
    private String kojoCode;
    
    @Column(name = "KOJO_NAME")
    private String kojoName;
    
    @Column(name = "SEIBAN_SONEKI_NET_JS")
    private BigDecimal seibanSonekiNetJs;
    @Column(name = "SEIBAN_SONEKI_NET_JT")
    private BigDecimal seibanSonekiNetJt;
    @Column(name = "SEIBAN_SONEKI_NET_MH")
    private BigDecimal seibanSonekiNetMh;
    @Column(name = "SEIBAN_SONEKI_NET_SM")
    private BigDecimal seibanSonekiNetSm;
    @Column(name = "SEIBAN_SONEKI_NET_ST")
    private BigDecimal seibanSonekiNetSt;
    @Column(name = "SEIBAN_SONEKI_NET_HB")
    private BigDecimal seibanSonekiNetHb;
    @Column(name = "SEIBAN_SONEKI_NET_TR")
    private BigDecimal seibanSonekiNetTr;
    @Column(name = "SEIBAN_SONEKI_NET_FM")
    private BigDecimal seibanSonekiNetFm;
    @Column(name = "SEIBAN_SONEKI_NET_DIFF")
    private BigDecimal seibanSonekiNetDiff;
    @Column(name = "SEIBAN_SONEKI_NET_PD")
    private BigDecimal seibanSonekiNetPd;
    @Column(name = "SEIBAN_SONEKI_NET_PT")
    private BigDecimal seibanSonekiNetPt;
    @Column(name = "SEIBAN_SONEKI_NET_PS")
    private BigDecimal seibanSonekiNetPs;
    @Column(name = "SEIBAN_SONEKI_NET_PREV")
    private BigDecimal seibanSonekiNetPrev;

    public ProductSonekiList() {
    }

    public String getAnkenId() {
        return this.ankenId;
    }

    public void setAnkenId(String ankenId) {
        this.ankenId = ankenId;
    }

    public String getKojoCode() {
        return this.kojoCode;
    }

    public void setKojoCode(String kojoCode) {
        this.kojoCode = kojoCode;
    }

    public String getKojoName() {
        return this.kojoName;
    }

    public void setKojoName(String kojoName) {
        this.kojoName = kojoName;
    }

    public BigDecimal getSeibanSonekiNetJs() {
        return this.seibanSonekiNetJs;
    }

    public void setSeibanSonekiNetJs(BigDecimal seibanSonekiNetJs) {
        this.seibanSonekiNetJs = seibanSonekiNetJs;
    }

    public BigDecimal getSeibanSonekiNetJt() {
        return this.seibanSonekiNetJt;
    }

    public void setSeibanSonekiNetJt(BigDecimal seibanSonekiNetJt) {
        this.seibanSonekiNetJt = seibanSonekiNetJt;
    }

    public BigDecimal getSeibanSonekiNetMh() {
        return this.seibanSonekiNetMh;
    }

    public void setSeibanSonekiNetMh(BigDecimal seibanSonekiNetMh) {
        this.seibanSonekiNetMh = seibanSonekiNetMh;
    }

    public BigDecimal getSeibanSonekiNetSm() {
        return this.seibanSonekiNetSm;
    }

    public void setSeibanSonekiNetSm(BigDecimal seibanSonekiNetSm) {
        this.seibanSonekiNetSm = seibanSonekiNetSm;
    }

    public BigDecimal getSeibanSonekiNetSt() {
        return this.seibanSonekiNetSt;
    }

    public void setSeibanSonekiNetSt(BigDecimal seibanSonekiNetSt) {
        this.seibanSonekiNetSt = seibanSonekiNetSt;
    }

    public BigDecimal getSeibanSonekiNetHb() {
        return this.seibanSonekiNetHb;
    }

    public void setSeibanSonekiNetHb(BigDecimal seibanSonekiNetHb) {
        this.seibanSonekiNetHb = seibanSonekiNetHb;
    }

    public BigDecimal getSeibanSonekiNetTr() {
        return this.seibanSonekiNetTr;
    }

    public void setSeibanSonekiNetTr(BigDecimal seibanSonekiNetTr) {
        this.seibanSonekiNetTr = seibanSonekiNetTr;
    }

    public BigDecimal getSeibanSonekiNetFm() {
        return this.seibanSonekiNetFm;
    }

    public void setSeibanSonekiNetFm(BigDecimal seibanSonekiNetFm) {
        this.seibanSonekiNetFm = seibanSonekiNetFm;
    }

    public BigDecimal getSeibanSonekiNetDiff() {
        return this.seibanSonekiNetDiff;
    }

    public void setSeibanSonekiNetDiff(BigDecimal seibanSonekiNetDiff) {
        this.seibanSonekiNetDiff = seibanSonekiNetDiff;
    }

    public BigDecimal getSeibanSonekiNetPd() {
        return seibanSonekiNetPd;
    }

    public void setSeibanSonekiNetPd(BigDecimal seibanSonekiNetPd) {
        this.seibanSonekiNetPd = seibanSonekiNetPd;
    }

    public BigDecimal getSeibanSonekiNetPt() {
        return seibanSonekiNetPt;
    }

    public void setSeibanSonekiNetPt(BigDecimal seibanSonekiNetPt) {
        this.seibanSonekiNetPt = seibanSonekiNetPt;
    }

    public BigDecimal getSeibanSonekiNetPs() {
        return seibanSonekiNetPs;
    }

    public void setSeibanSonekiNetPs(BigDecimal seibanSonekiNetPs) {
        this.seibanSonekiNetPs = seibanSonekiNetPs;
    }

    public BigDecimal getSeibanSonekiNetPrev() {
        return seibanSonekiNetPrev;
    }

    public void setSeibanSonekiNetPrev(BigDecimal seibanSonekiNetPrev) {
        this.seibanSonekiNetPrev = seibanSonekiNetPrev;
    }
    
}
