/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package jp.co.toshiba.hby.pspromis.syuueki.facade;

import java.util.List;
import javax.ejb.Stateless;
import javax.inject.Inject;
import javax.interceptor.Interceptors;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import jp.co.toshiba.hby.pspromis.syuueki.entity.SyuKiKanbaijTbl;
import jp.co.toshiba.hby.pspromis.syuueki.entity.SyuKiSpCurTbl;
import jp.co.toshiba.hby.pspromis.syuueki.interceptor.TranceInterceptor;
import jp.co.toshiba.hby.pspromis.syuueki.util.Utils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 *
 * @author masaki
 */
@Stateless
@Interceptors({TranceInterceptor.class})
public class S010Facade extends AbstractFacade<S010Facade> {
    
    private static final Logger logger = LoggerFactory.getLogger(S010Facade.class);
    
    @PersistenceContext(unitName = jp.co.toshiba.hby.pspromis.syuueki.util.ConstantString.syuuekiDataSourceName)
    private EntityManager em;

    @Override
    protected EntityManager getEntityManager() {
        return em;
    }

    @Inject
    private Utils util;
    
    public S010Facade() {
        super(S010Facade.class);
    }

    /**
     * 完売実績を取得
     * @param condition
     * @param page
     * @return
     * @throws Exception 
     */
    public SyuKiKanbaijTbl getSyuKiKanbaij(Object condition) {
        logger.info("S010Facade#getSyuKiKanbaij");

        SyuKiKanbaijTbl syuKiKanbaijTbl = sqlExecutor.getSingleResult(em, SyuKiKanbaijTbl.class, "/sql/S010/selectSyuKiKanbaijTbl.sql", condition);
        
        return syuKiKanbaijTbl;
    }
    
    /**
     * 通貨タイトルを取得
     * @param condition
     * @param page
     * @return
     * @throws Exception 
     */
    public List<SyuKiSpCurTbl> getSyuKiSpCur(Object condition) {
        logger.info("S010Facade#getSyuKiSpCur");

        List<SyuKiSpCurTbl> syuKiSpCurTbl = sqlExecutor.getResultList(em, SyuKiSpCurTbl.class, "/sql/S010/selectSyuKiSpCurTbl.sql", condition);
        
        return syuKiSpCurTbl;
    }

    /**
     * 完売実績の更新
     * @param condition
     */
    public int updateSyuKiKanbaiJ(Object condition) {
        logger.info("S010Facade#updateSyuKiKanbaiJ");

        return sqlExecutor.executeUpdateSql(em, "/sql/S010/updateSyuKiKanbaiJTbl.sql", condition);
    }
    
   /**
     * 完売実績の登録
     * 
     * @param condition 
     */
    public int insertSyuKiKanbaiJ(Object condition){
        logger.info("S010Facade#insertSyuKiKanbaiJ");

        return sqlExecutor.executeUpdateSql(em, "/sql/S010/insertSyuKiKanbaiJTbl.sql", condition);
    }
}
