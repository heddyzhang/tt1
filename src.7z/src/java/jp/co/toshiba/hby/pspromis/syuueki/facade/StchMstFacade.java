package jp.co.toshiba.hby.pspromis.syuueki.facade;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.ejb.Stateless;
import javax.inject.Inject;
import javax.interceptor.Interceptors;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import jp.co.toshiba.hby.pspromis.syuueki.entity.Es88051Tbl;
import jp.co.toshiba.hby.pspromis.syuueki.interceptor.TranceInterceptor;
import jp.co.toshiba.hby.pspromis.syuueki.util.Utils;

/**
 *
 * @author horie
 */
@Stateless
@Interceptors({TranceInterceptor.class})
public class StchMstFacade extends AbstractFacade<Es88051Tbl> {
    @PersistenceContext(unitName = jp.co.toshiba.hby.pspromis.syuueki.util.ConstantString.syuuekiDataSourceName)
    private EntityManager em;

    @Override
    protected EntityManager getEntityManager() {
        return em;
    }

    @Inject
    private Utils util;
    
    public StchMstFacade() {
        super(Es88051Tbl.class);
    }

    /**
     * 設置先場所の件数を取得
     * @param condition
     * @return 
     */
    public Integer getCount(Object condition) {
        if (condition == null) {
            condition = new HashMap<>();
        }
        if (condition instanceof Map) {
            ((Map)condition).put("listFlg", "1");
        }
        Integer count = sqlExecutor.getCount(em, "/sql/selectStchMst.sql", condition);
        return count;
    }
    
    /**
     * 設置先場所の一覧を取得
     * @param condition
     * @return 
     */
    public List<Es88051Tbl> getList(Object condition, Integer page) {
        if (condition == null) {
            condition = new HashMap<>();
        }
        if (condition instanceof Map) {
            ((Map)condition).put("listFlg", "0");
        }

        int limit = util.getPageLimit();
        int offset = util.getPageOffset(page);

        List<Es88051Tbl> list = sqlExecutor.getResultList(em, Es88051Tbl.class, "/sql/selectStchMst.sql", condition, limit, offset);
        return list;
    }
}
