package jp.co.toshiba.hby.pspromis.syuueki.dto;

import lombok.Getter;
import lombok.Setter;

/**
 * ES-Promis収益管理システム
 * (原子力)収益管理システムへのデータ連携パッケージのパラメータ(画面から直接起動)
 * @author kitajima
 */
@Getter @Setter
public class NuclearRenkeiDispBatchDto {
   
    /**
     * 対象案件id
     */
    private String ankenId;
    
    /**
     * 対象履歴id
     */
    private String rirekiId;
    
    /**
     * APIを呼び出したプログラム(ADD_KOUBAN:見込項番追加 SAVE_BIKOU:備考の保存)
     */
    private String dispKbn;
    
    /**
     * 処理結果(0:成功、9:失敗)
     */
    private Integer status;
    
    /**
     * エラー内容
     */
    private String errMsg;
    
    /**
     * 実行したパッケージ名
     */
    private String exeProcedureName;

}