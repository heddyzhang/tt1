/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package jp.co.toshiba.hby.pspromis.syuueki.entity;

import java.io.Serializable;
import java.util.Date;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

/**
 *
 * @author sano
 */
@Entity
@Table(name = "SYU_PATTERN_MST")
public class SyuPatternMst implements Serializable {
    private static final long serialVersionUID = 1L;
    
    @Column(name = "CNT")
    private Long count;
    
    @Basic(optional = false)
    @NotNull
    @Column(name = "CHUNYU_PTN_NO")
    @Id
    @Size(max = 8)
    private String chunyuPtnNo;
    @Basic(optional = false)
    @NotNull
    @Size(max = 100)
    @Column(name = "CHUNYU_PTN_NAME")
    private String chunyuPtnName;
    @Column(name = "STANDARD_PTN_FLG")
    @Size(max = 1)
    private String standardPtnFlg;
    @Column(name = "SUB_BU_ID")
    private String subBuId;
    @Column(name = "DIVISION_CODE")
    @Size(max = 2)
    private String divisionCode;
    @Column(name = "PLANT_TYPE_CODE")
    @Size(max = 5)
    private String plantTypeCode;
    @Column(name = "PLANT_TYPE_NAME")
    private String plantTypeName;
    @Column(name = "CREATED_BY")
    @Size(max = 8)
    private String createdBy;
    @Column(name = "CREATION_DATE")
    @Temporal(TemporalType.TIMESTAMP)
    private Date creationDate;
    @Column(name = "LAST_UPDATE_BY")
    @Size(max = 8)
    private String lastUpdateBy;
    @Column(name = "LAST_UPDATE_DATE")
    @Temporal(TemporalType.TIMESTAMP)
    private Date lastUpdateDate;
    @Column(name = "SOURCE_CHUNYU_PTN_NAME")
    @Size(max = 100)
    private String sourceChunyuPtnName;
    @Column(name = "SOURCE_CHUNYU_PTN_NO")
    @Size(max = 5)
    private String sourceChunyuPtnNo;
    @Column(name = "CREATE_DIV_CODE")
    @Size(max = 8)
    private String createDivCode;
    @Size(max = 8)
    @Column(name = "LAST_UPDATE_DIV_CODE")
    private String lastUpdateDivCode;
    @Column(name = "IMAGE_URL")
    @Size(max = 50)
    private String imageUrl;
    @Column(name = "SUB_BU_NAME")
    private String subBuName;

    public SyuPatternMst() {
    }

    public SyuPatternMst(String plantTypeCode) {
        this.plantTypeCode = plantTypeCode;
    }

    public Long getCount() {
        return count;
    }

    public void setCount(Long count) {
        this.count = count;
    }
    
    public String getChunyuPtnNo() {
        return chunyuPtnNo;
    }

    public void setChunyuPtnNo(String chunyuPtnNo) {
        this.chunyuPtnNo = chunyuPtnNo;
    }

    public String getChunyuPtnName() {
        return chunyuPtnName;
    }

    public void setChunyuPtnName(String chunyuPtnName) {
        this.chunyuPtnName = chunyuPtnName;
    }

    public String getStandardPtnFlg() {
        return standardPtnFlg;
    }

    public void setStandardPtnFlg(String standardPtnFlg) {
        this.standardPtnFlg = standardPtnFlg;
    }

    public String getSubBuId() {
        return subBuId;
    }

    public void setSubBuId(String subBuId) {
        this.subBuId = subBuId;
    }

    public String getDivisionCode() {
        return divisionCode;
    }

    public void setDivisionCode(String divisionCode) {
        this.divisionCode = divisionCode;
    }

    public String getPlantTypeCode() {
        return plantTypeCode;
    }

    public void setPlantTypeCode(String plantTypeCode) {
        this.plantTypeCode = plantTypeCode;
    }

    public String getPlantTypeName() {
        return plantTypeName;
    }

    public void setPlantTypeName(String plantTypeName) {
        this.plantTypeName = plantTypeName;
    }

    public String getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    public Date getCreationDate() {
        return this.creationDate;
    }

    public void setCreationDate(Date creationDate) {
        this.creationDate = creationDate;
    }

    public String getLastUpdateBy() {
        return this.lastUpdateBy;
    }

    public void setLastUpdateBy(String lastUpdateBy) {
        this.lastUpdateBy = lastUpdateBy;
    }

    public Date getLastUpdateDate() {
        return this.lastUpdateDate;
    }

    public void setLastUpdateDate(Date lastUpdateDate) {
        this.lastUpdateDate = lastUpdateDate;
    }

    public String getSourceChunyuPtnName() {
        return sourceChunyuPtnName;
    }

    public void setSourceChunyuPtnName(String sourceChunyuPtnName) {
        this.sourceChunyuPtnName = sourceChunyuPtnName;
    }

    public String getSourceChunyuPtnNo() {
        return sourceChunyuPtnNo;
    }

    public void setSourceChunyuPtnNo(String sourceChunyuPtnNo) {
        this.sourceChunyuPtnNo = sourceChunyuPtnNo;
    }

    public String getCreateDivCode() {
        return createDivCode;
    }

    public void setCreateDivCode(String createDivCode) {
        this.createDivCode = createDivCode;
    }

    public String getLastUpdateDivCode() {
        return lastUpdateDivCode;
    }

    public void setLastUpdateDivCode(String lastUpdateDivCode) {
        this.lastUpdateDivCode = lastUpdateDivCode;
    }

    public String getImageUrl() {
        return this.imageUrl;
    }

    public void setImageUrl(String imageUrl) {
        this.imageUrl = imageUrl;
    }

    public String getSubBuName() {
        return this.subBuName;
    }

    public void setSubBuName(String subBuName) {
        this.subBuName = subBuName;
    }
}
