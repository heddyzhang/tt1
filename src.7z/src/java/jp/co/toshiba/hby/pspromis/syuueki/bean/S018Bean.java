package jp.co.toshiba.hby.pspromis.syuueki.bean;

import java.util.List;
import java.util.Map;
import javax.enterprise.context.RequestScoped;
import javax.inject.Named;
import jp.co.toshiba.hby.pspromis.syuueki.entity.SyuGeNetItemTblView;
import jp.co.toshiba.hby.pspromis.syuueki.entity.SyuKiNetCateTitleTbl;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

/**
 *
 * @author 
 */
@Named(value = "s018Bean")
@RequestScoped
@Getter @Setter
@ToString
public class S018Bean extends AbstractBean {

    /**
     * 処理元の画面ID(操作ログの登録で利用)
     */
    private String procId;

    /**
     * 事業部コード
     */
    private String divisionCode;
    
    /**
     * 選択した項番(複数の可能性あるため配列)
     */
    private String[] orderItems;

    /**
     * カテゴリ設定する項番データの一覧
     */
    private List<SyuGeNetItemTblView> dispTargetItemList;

    /**
     * 共通カテゴリ一覧
     */
    private List<SyuKiNetCateTitleTbl> dispSelectItemList;

    /**
     * 選択したカテゴリのコード
     */
    private String selectCategoryCode;
    
    /**
     * 項番一覧のHiddenコード
     */
    private List<Map<String, String>> updateItemList;
    
    /**
     * 画面表示用隠し項番
     */ 
    private List<String> dispOrderItems;
}
