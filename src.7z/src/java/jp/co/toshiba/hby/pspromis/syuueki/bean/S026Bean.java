/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package jp.co.toshiba.hby.pspromis.syuueki.bean;

import java.util.List;
import javax.enterprise.context.RequestScoped;
import javax.inject.Named;
import jp.co.toshiba.hby.pspromis.syuueki.entity.SyuInfoMessageMst;
import lombok.Getter;
import lombok.Setter;

/**
 *
 * @author watabe
 */
@Named(value = "s026Bean")
@RequestScoped
@Getter @Setter
public class S026Bean extends AbstractBean{

    private String divisionCode;
    
    private List<SyuInfoMessageMst> syuInfoMessageMst;

}
