package jp.co.toshiba.hby.pspromis.syuueki.facade;

import java.util.List;
import javax.ejb.Stateless;
import javax.interceptor.Interceptors;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import jp.co.toshiba.hby.pspromis.syuueki.entity.Cost;
import jp.co.toshiba.hby.pspromis.syuueki.entity.CostList;
import jp.co.toshiba.hby.pspromis.syuueki.entity.S004Cost;
import jp.co.toshiba.hby.pspromis.syuueki.interceptor.TranceInterceptor;
import org.apache.commons.collections4.CollectionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 *
 * @author sano
 */
@Stateless
@Interceptors({TranceInterceptor.class})
public class CostListFacade extends AbstractFacade<CostList> {

    /**
     * ロガ－
     */
    private static final Logger logger = LoggerFactory.getLogger(CostListFacade.class);

    @PersistenceContext(unitName = jp.co.toshiba.hby.pspromis.syuueki.util.ConstantString.syuuekiDataSourceName)
    private EntityManager em;

    public CostListFacade() {
        super(CostList.class);
    }

    @Override
    protected EntityManager getEntityManager() {
        return em;
    }

    /**
     * 売上原価の一覧を取得
     * @param condition
     * @return 
     */
    public List<CostList> findList(Object condition) {
        logger.info("CostListFacade#findList");

        List<CostList> list = sqlExecutor.getResultList(em, CostList.class, "/sql/S002/selectCostList.sql", condition);
        
        return list;
    }
    
    /**
     * 売上原価の合計を取得
     * @param condition
     * @return 
     */
    public CostList findTotalList(Object condition) {
        logger.info("CostListFacade#findTotalList");

        //CostList list = sqlExecutor.getSingleResult(em, CostList.class, "/sql/S002/selectTotalCost.sql", condition);
        //return list;
        
        CostList entity;
        List<CostList> list = sqlExecutor.getResultList(em, CostList.class, "/sql/S002/selectTotalCost.sql", condition);
        if (CollectionUtils.isNotEmpty(list)) {
            entity = list.get(0);
        } else {
            entity = new CostList();
        }
        return entity;
    }
    
    /**
     * 見積総原価の合計を取得
     * @param condition
     * @return 
     */
    public Cost findEstimateTotalCost(Object condition) {
        logger.info("CostListFacade#findEstimateTotalCost");

        //Cost list = sqlExecutor.getSingleResult(em, Cost.class, "/sql/S004/selectKsTotalCost.sql", condition);
        //return list;
        
        Cost entity;
        List<Cost> list = sqlExecutor.getResultList(em, Cost.class, "/sql/S004/selectKsTotalCost.sql", condition);
        if (CollectionUtils.isNotEmpty(list)) {
            entity = list.get(0);
        } else {
            entity = new Cost();
        }
        return entity;
    }
    
    /**
     * 見積総原価の詳細を取得
     * @param condition
     * @return 
     */
    public S004Cost findEstimateCostDetail(Object condition) {
        logger.info("CostListFacade#findEstimateCostDetail");

        //S004Cost list = sqlExecutor.getSingleResult(em, S004Cost.class, "/sql/S004/selectKsCurrencyCost.sql", condition);
        //return list;
        
        S004Cost entity;
        List<S004Cost> list = sqlExecutor.getResultList(em, S004Cost.class, "/sql/S004/selectKsCurrencyCost.sql", condition);
        if (CollectionUtils.isNotEmpty(list)) {
            entity = list.get(0);
        } else {
            entity = new S004Cost();
        }
        return entity;
    }
    
    /**
     * 子案件の売上原価の合計を取得
     * @param condition
     * @return 
     */
    public List<CostList> findChildTotalList(Object condition) {
        logger.info("CostListFacade#findChildTotalList");

        List<CostList> list = sqlExecutor.getResultList(em, CostList.class, "/sql/S002/selectTotalCost.sql", condition);
        
        return list;
    }
    
    /**
     * 売上原価の詳細を取得
     * @param condition
     * @return 
     */
    public List<Cost> findSalesCostDetail(Object condition) {
        logger.info("CostListFacade#findSalesCostDetail");

        List<Cost> list = sqlExecutor.getResultList(em, Cost.class, "/sql/S004/selectKsSalesCostDetail.sql", condition);
        
        return list;
    }
    
    /**
     * 売上原価の詳細を取得
     * @param condition
     * @return 
     */
    public List<Cost> findPreviousPeriodSalesCostDetail(Object condition) {
        logger.info("CostListFacade#findPreviousPeriodSalesCostDetail");

        List<Cost> list = sqlExecutor.getResultList(em, Cost.class, "/sql/S004/selectPreviousPeriodKsSalesCostDetail.sql", condition);

        return list;
    }
    
    /**
     * 売上原価詳細の翌月反映元を取得
     * @param condition
     * @return 
     */
    public Cost findSalesCostDetailReflectTarget(Object condition) {
        logger.info("CostListFacade#findSalesCostDetailReflectTarget");

        //Cost cost = sqlExecutor.getSingleResult(em, Cost.class, "/sql/S004/selectReflectTargetNet.sql", condition);
        //return cost;
        
        Cost entity;
        List<Cost> list = sqlExecutor.getResultList(em, Cost.class, "/sql/S004/selectReflectTargetNet.sql", condition);
        if (CollectionUtils.isNotEmpty(list)) {
            entity = list.get(0);
        } else {
            entity = new Cost();
        }
        return entity;
    }
    
    /**
     * 見積総原価詳細の翌月反映元を取得
     * @param condition
     * @return 
     */
    public S004Cost findEstimateCostDetailReflectTarget(Object condition) {
        logger.info("CostListFacade#findEstimateCostDetailReflectTarget");

        //S004Cost list = sqlExecutor.getSingleResult(em, S004Cost.class, "/sql/S004/selectReflectTargetSougenka.sql", condition);
        //return list;
        
        S004Cost entity;
        List<S004Cost> list = sqlExecutor.getResultList(em, S004Cost.class, "/sql/S004/selectReflectTargetSougenka.sql", condition);
        if (CollectionUtils.isNotEmpty(list)) {
            entity = list.get(0);
        } else {
            entity = new S004Cost();
        }
        return entity;
    }
}
