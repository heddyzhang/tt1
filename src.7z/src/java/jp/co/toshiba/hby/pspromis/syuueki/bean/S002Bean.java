package jp.co.toshiba.hby.pspromis.syuueki.bean;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import javax.enterprise.context.RequestScoped;
import javax.inject.Named;
import lombok.Getter;
import lombok.Setter;
import jp.co.toshiba.hby.pspromis.syuueki.entity.CurrencyRateList;
import jp.co.toshiba.hby.pspromis.syuueki.entity.IspDivisionList;

/**
 *
 * @author sano
 */
@Named(value = "s002Bean")
@RequestScoped
@Getter
@Setter
public class S002Bean extends AbstractBean {

    /**
     * 一括ダウンロード出力FLG (案件一覧の一括ダウンロード処理から指定された場合はtrueとなる)
     * (この場合は特定処理(この内部での操作ログ書き込み等)を行わない)
     */
    private boolean isIkkatsuFlg = false;

    /**
     * 円貨単位
     */
    private Integer jpyUnit;

    /**
     * 差分表示FLG
     */
    private String calcDiffFlg;

    /**
     * 契約金額（SP)・内訳ツリー展開openフラグ
     */
    private String spListOpenFlg = "1";

    /**
     * 売上原価（NET）・内訳ツリー展開openフラグ
     */
    private String netListOpenFlg = "1";

    /**
     * 製番損益・内訳ツリー展開openフラグ
     */
    private String sonekiListOpenFlg = "1";

    /**
     * 販売直接費・内訳ツリー展開openフラグ
     */
    private String hanchokuListOpenFlg = "1";

    /**
     * まとめ案件フラグ
     */
    private String ankenFlg;
    /**
     * まとめ案件番号
     */
    private String ankenMatomeNo;
    /**
     * まとめ案件注番
     */
    private String ankenMatomeOrderNo;

    /**
     * レート表
     */
    private List<CurrencyRateList> currencyRateList;

    /**
     * SP内訳
     */
    private List<HashMap<String, String>> currencyRateMapList;

    /**
     * 契約金額合計
     */
    private HashMap<String, String> totalContractAmountList;

    /**
     * 売上原価
     */
    private HashMap<String, String> totalCost;

    /**
     * 売上原価
     */
    private List<HashMap<String, String>> costList;

    /**
     * 損益表
     */
    private HashMap<String, String> sonekiList;
    private List<HashMap<String, String>> sonekiEditList;

    /**
     * 工場別製番損益
     */
    private List<HashMap<String, String>> productSonekiList;

    /**
     * 販直費カテゴリー別内訳
     */
    private List<HashMap<String, String>> categoryHanchokuList;

    /**
     * 粗利(受政)
     */
    private String arariJs;
    /**
     * 粗利(受注)
     */
    private String arariJt;
    /**
     * 粗利(目標)
     */
    private String arariMh;
    /**
     * 粗利(最新見積)
     */
    private String arariSm;
    /**
     * 粗利(査定)
     */
    private String arariSt;
    /**
     * 粗利(発番)
     */
    private String arariHb;
    /**
     * 粗利(注入累計)
     */
    private String arariTr;
    /**
     * 粗利(最終見込)
     */
    private String arariFm;
    /**
     * 粗利(差分)
     */
    private String arariDiff;
    /**
     * 見込_大
     */
    private String arariPd;
    /**
     * 見込_中
     */
    private String arariPt;
    /**
     * 見込_小
     */
    private String arariPs;
    /**
     * 見込_前回値
     */
    private String arariPrev;

    /**
     * M率(受政)
     */
    private String mrateJs;
    /**
     * M率(受注)
     */
    private String mrateJt;
    /**
     * M率(目標)
     */
    private String mrateMh;
    /**
     * M率(最新見積)
     */
    private String mrateSm;
    /**
     * M率(査定)
     */
    private String mrateSt;
    /**
     * M率(発番)
     */
    private String mrateHb;
    /**
     * M率(注入累計)
     */
    private String mrateTr;
    /**
     * M率(最終見込)
     */
    private String mrateFm;
    /**
     * M率(差分)
     */
    private String mrateDiff;
    /**
     * M率(見込_大)
     */
    private String mratePd;
    /**
     * M率(見込_中)
     */
    private String mratePt;
    /**
     * M率(見込_小)
     */
    private String mratePs;
    /**
     * M率(見込_前回値)
     */
    private String mratePrev;

    /**
     * 経常損益(受政)
     */
    private String ordinaryJs;
    /**
     * 経常損益(受注)
     */
    private String ordinaryJt;
    /**
     * 経常損益(目標)
     */
    private String ordinaryMh;
    /**
     * 経常損益(最新見積)
     */
    private String ordinarySm;
    /**
     * 経常損益(査定)
     */
    private String ordinarySt;
    /**
     * 経常損益(発番)
     */
    private String ordinaryHb;
    /**
     * 経常損益(注入累計)
     */
    private String ordinaryTr;
    /**
     * 経常損益(最終見込)
     */
    private String ordinaryFm;
    /**
     * 経常損益(差分)
     */
    private String ordinaryDiff;
    /**
     * 経常損益(見込_大)
     */
    private String ordinaryPd;
    /**
     * 経常損益(見込_中)
     */
    private String ordinaryPt;
    /**
     * 経常損益(見込_小)
     */
    private String ordinaryPs;
    /**
     * 経常損益(見込_前回値)
     */
    private String ordinaryPrev;

    /**
     * 経常損益ROS(受政)
     */
    private String rosJs;
    /**
     * 経常損益ROS(受注)
     */
    private String rosJt;
    /**
     * 経常損益ROS(目標)
     */
    private String rosMh;
    /**
     * 経常損益ROS(最新見積)
     */
    private String rosSm;
    /**
     * 経常損益ROS(査定)
     */
    private String rosSt;
    /**
     * 経常損益ROS(発番)
     */
    private String rosHb;
    /**
     * 経常損益ROS(注入累計)
     */
    private String rosTr;
    /**
     * 経常損益ROS(最終見込)
     */
    private String rosFm;
    /**
     * 経常損益ROS(差分)
     */
    private String rosDiff;
    /**
     * 経常損益ROS(見込_大)
     */
    private String rosPd;
    /**
     * 経常損益ROS(見込_中)
     */
    private String rosPt;
    /**
     * 経常損益ROS(見込_小)
     */
    private String rosPs;
    /**
     * 経常損益ROS(見込_前回値)
     */
    private String rosPrev;

    /**
     * まとめ案件
     */
    private HashMap<String, String> parentAnken;

    /**
     * 子案件リスト
     */
    private ArrayList<HashMap<String, String>> childAnkenList;

    /**
     * 注番
     */
    private String orderNo;

    /**
     * [最終見込　前回値]を表示に利用する前回履歴ID
     */
    private String zenkaiRirekiId;

    /**
     * [最終見込　前回値]を表示に利用する勘定年月
     */
    private String zenkaiKanjyoYm;

    /**
     * 回収
     */
    private ArrayList<HashMap<String, String>> kaisyuList;

    /**
     * 最新値更新区分(1:発番取込 2:契約取込 3:見積取込)
     */
    private String updateNewDataKbn;
    
    /**
     * 編集可否
     */
    private String editBtnFlg = "0";
    private String saisyuUpdeteBtnFlg = "0";
    private String editNetFlg = "0";

    private String ankenRev;
    private String spKakuteiFlg;
    private String netKakuteiFlg;
    private String bikou;
    private String zenkaiZenkaiId;
    private String salesClass;
    private String ispKbn;
    private List<IspDivisionList> ispDivisionList;
    private IspDivisionList ispDivisionTotal;
    private String bikouOpenFlg;
    private String procId = "S002";
    private String deptName;
    private String keihiListOpenFlg = "0";
    private String eigyogaiSonekiListOpenFlg = "0";
    private String sonekiListFlg;
    private String potentialFlg = "0";
    private HashMap<String, String> bikoFlg;
    private boolean matomeChildFlg = false;
    private boolean matomeParentFlg = false;
    private boolean ispDivisionFlg = false;
    private String parentPotentialFlg = "0";
    private String editFlg = "0";
    private String calcDiffFlgSv;

    /**
     *
     */
    public S002Bean() {
    }

    public Integer getJpyUnit() {
        return jpyUnit;
    }

    public void setJpyUnit(Integer jpyUnit) {
        this.jpyUnit = jpyUnit;
    }

    public String getCalcDiffFlg() {
        return calcDiffFlg;
    }

    public void setCalcDiffFlg(String calcDiffFlg) {
        this.calcDiffFlg = calcDiffFlg;
    }

    public String getSpListOpenFlg() {
        return spListOpenFlg;
    }

    public void setSpListOpenFlg(String spListOpenFlg) {
        this.spListOpenFlg = spListOpenFlg;
    }

    public String getNetListOpenFlg() {
        return netListOpenFlg;
    }

    public void setNetListOpenFlg(String netListOpenFlg) {
        this.netListOpenFlg = netListOpenFlg;
    }

    public String getSonekiListOpenFlg() {
        return sonekiListOpenFlg;
    }

    public void setSonekiListOpenFlg(String sonekiListOpenFlg) {
        this.sonekiListOpenFlg = sonekiListOpenFlg;
    }

    public String getHanchokuListOpenFlg() {
        return hanchokuListOpenFlg;
    }

    public void setHanchokuListOpenFlg(String hanchokuListOpenFlg) {
        this.hanchokuListOpenFlg = hanchokuListOpenFlg;
    }

    public String getAnkenFlg() {
        return ankenFlg;
    }

    public void setAnkenFlg(String ankenFlg) {
        this.ankenFlg = ankenFlg;
    }

    public String getAnkenMatomeNo() {
        return ankenMatomeNo;
    }

    public void setAnkenMatomeNo(String ankenMatomeNo) {
        this.ankenMatomeNo = ankenMatomeNo;
    }

    public String getAnkenMatomeOrderNo() {
        return ankenMatomeOrderNo;
    }

    public void setAnkenMatomeOrderNo(String ankenMatomeOrderNo) {
        this.ankenMatomeOrderNo = ankenMatomeOrderNo;
    }

    public List<CurrencyRateList> getCurrencyRateList() {
        return this.currencyRateList;
    }

    public void setCurrencyRateList(List<CurrencyRateList> currencyRateList) {
        this.currencyRateList = currencyRateList;
    }

    public List<HashMap<String, String>> getCurrencyRateMapList() {
        return this.currencyRateMapList;
    }

    public void setCurrencyRateMapList(List<HashMap<String, String>> currencyRateMapList) {
        this.currencyRateMapList = currencyRateMapList;
    }

    public HashMap<String, String> getTotalContractAmount() {
        return this.totalContractAmountList;
    }

    public void setTotalContractAmount(HashMap<String, String> totalContractAmountList) {
        this.totalContractAmountList = totalContractAmountList;
    }

    public HashMap<String, String> getTotalCost() {
        return this.totalCost;
    }

    public void setTotalCost(HashMap<String, String> totalCost) {
        this.totalCost = totalCost;
    }

    public List<HashMap<String, String>> getCostList() {
        return this.costList;
    }

    public void setCostList(List<HashMap<String, String>> costList) {
        this.costList = costList;
    }

    public HashMap<String, String> getSonekiList() {
        return this.sonekiList;
    }

    public void setSonekiList(HashMap<String, String> sonekiList) {
        this.sonekiList = sonekiList;
    }

    public List<HashMap<String, String>> getProductSonekiList() {
        return this.productSonekiList;
    }

    public void setProductSonekiList(List<HashMap<String, String>> productSonekiList) {
        this.productSonekiList = productSonekiList;
    }

    public List<HashMap<String, String>> getCategoryHanchokuList() {
        return this.categoryHanchokuList;
    }

    public void setCategoryHanchokuList(List<HashMap<String, String>> categoryHanchokuList) {
        this.categoryHanchokuList = categoryHanchokuList;
    }

    public String getArariJs() {
        return this.arariJs;
    }

    public void setArariJs(String arariJs) {
        this.arariJs = arariJs;
    }

    public String getArariJt() {
        return this.arariJt;
    }

    public void setArariJt(String arariJt) {
        this.arariJt = arariJt;
    }

    public String getArariMh() {
        return this.arariMh;
    }

    public void setArariMh(String arariMh) {
        this.arariMh = arariMh;
    }

    public String getArariSm() {
        return this.arariSm;
    }

    public void setArariSm(String arariSm) {
        this.arariSm = arariSm;
    }

    public String getArariSt() {
        return this.arariSt;
    }

    public void setArariSt(String arariSt) {
        this.arariSt = arariSt;
    }

    public String getArariHb() {
        return this.arariHb;
    }

    public void setArariHb(String arariHb) {
        this.arariHb = arariHb;
    }

    public String getArariTr() {
        return this.arariTr;
    }

    public void setArariTr(String arariTr) {
        this.arariTr = arariTr;
    }

    public String getArariFm() {
        return this.arariFm;
    }

    public void setArariFm(String arariFm) {
        this.arariFm = arariFm;
    }

    public String getArariDiff() {
        return this.arariDiff;
    }

    public void setArariDiff(String arariDiff) {
        this.arariDiff = arariDiff;
    }

    public String getMrateJs() {
        return this.mrateJs;
    }

    public void setMrateJs(String mrateJs) {
        this.mrateJs = mrateJs;
    }

    public String getMrateJt() {
        return this.mrateJt;
    }

    public void setMrateJt(String mrateJt) {
        this.mrateJt = mrateJt;
    }

    public String getMrateMh() {
        return this.mrateMh;
    }

    public void setMrateMh(String mrateMh) {
        this.mrateMh = mrateMh;
    }

    public String getMrateSm() {
        return this.mrateSm;
    }

    public void setMrateSm(String mrateSm) {
        this.mrateSm = mrateSm;
    }

    public String getMrateSt() {
        return this.mrateSt;
    }

    public void setMrateSt(String mrateSt) {
        this.mrateSt = mrateSt;
    }

    public String getMrateHb() {
        return this.mrateHb;
    }

    public void setMrateHb(String mrateHb) {
        this.mrateHb = mrateHb;
    }

    public String getMrateTr() {
        return this.mrateTr;
    }

    public void setMrateTr(String mrateTr) {
        this.mrateTr = mrateTr;
    }

    public String getMrateFm() {
        return this.mrateFm;
    }

    public void setMrateFm(String mrateFm) {
        this.mrateFm = mrateFm;
    }

    public String getMrateDiff() {
        return this.mrateDiff;
    }

    public void setMrateDiff(String mrateDiff) {
        this.mrateDiff = mrateDiff;
    }

    public String getOrdinaryJs() {
        return this.ordinaryJs;
    }

    public void setOrdinaryJs(String ordinaryJs) {
        this.ordinaryJs = ordinaryJs;
    }

    public String getOrdinaryJt() {
        return this.ordinaryJt;
    }

    public void setOrdinaryJt(String ordinaryJt) {
        this.ordinaryJt = ordinaryJt;
    }

    public String getOrdinaryMh() {
        return this.ordinaryMh;
    }

    public void setOrdinaryMh(String ordinaryMh) {
        this.ordinaryMh = ordinaryMh;
    }

    public String getOrdinarySm() {
        return this.ordinarySm;
    }

    public void setOrdinarySm(String ordinarySm) {
        this.ordinarySm = ordinarySm;
    }

    public String getOrdinarySt() {
        return this.ordinarySt;
    }

    public void setOrdinarySt(String ordinarySt) {
        this.ordinarySt = ordinarySt;
    }

    public String getOrdinaryHb() {
        return this.ordinaryHb;
    }

    public void setOrdinaryHb(String ordinaryHb) {
        this.ordinaryHb = ordinaryHb;
    }

    public String getOrdinaryTr() {
        return this.ordinaryTr;
    }

    public void setOrdinaryTr(String ordinaryTr) {
        this.ordinaryTr = ordinaryTr;
    }

    public String getOrdinaryFm() {
        return this.ordinaryFm;
    }

    public void setOrdinaryFm(String ordinaryFm) {
        this.ordinaryFm = ordinaryFm;
    }

    public String getOrdinaryDiff() {
        return this.ordinaryDiff;
    }

    public void setOrdinaryDiff(String ordinaryDiff) {
        this.ordinaryDiff = ordinaryDiff;
    }

    public String getRosJs() {
        return this.rosJs;
    }

    public void setRosJs(String rosJs) {
        this.rosJs = rosJs;
    }

    public String getRosJt() {
        return this.rosJt;
    }

    public void setRosJt(String rosJt) {
        this.rosJt = rosJt;
    }

    public String getRosMh() {
        return this.rosMh;
    }

    public void setRosMh(String rosMh) {
        this.rosMh = rosMh;
    }

    public String getRosSm() {
        return this.rosSm;
    }

    public void setRosSm(String rosSm) {
        this.rosSm = rosSm;
    }

    public String getRosSt() {
        return this.rosSt;
    }

    public void setRosSt(String rosSt) {
        this.rosSt = rosSt;
    }

    public String getRosHb() {
        return this.rosHb;
    }

    public void setRosHb(String rosHb) {
        this.rosHb = rosHb;
    }

    public String getRosTr() {
        return this.rosTr;
    }

    public void setRosTr(String rosTr) {
        this.rosTr = rosTr;
    }

    public String getRosFm() {
        return this.rosFm;
    }

    public void setRosFm(String rosFm) {
        this.rosFm = rosFm;
    }

    public String getRosDiff() {
        return this.rosDiff;
    }

    public void setRosDiff(String rosDiff) {
        this.rosDiff = rosDiff;
    }

    public HashMap<String, String> getParentAnken() {
        return this.parentAnken;
    }

    public void setParentAnken(HashMap<String, String> parentAnken) {
        this.parentAnken = parentAnken;
    }

    public ArrayList<HashMap<String, String>> getChildAnkenList() {
        return this.childAnkenList;
    }

    public void setChildAnkenList(ArrayList<HashMap<String, String>> childAnkenList) {
        this.childAnkenList = childAnkenList;
    }

    public boolean isIsIkkatsuFlg() {
        return isIkkatsuFlg;
    }

    public void setIsIkkatsuFlg(boolean isIkkatsuFlg) {
        this.isIkkatsuFlg = isIkkatsuFlg;
    }

    public String getOrderNo() {
        return orderNo;
    }

    public void setOrderNo(String orderNo) {
        this.orderNo = orderNo;
    }

    public boolean isEditNet() {
        return (editNetFlg.equals("1"));
    }
}
