package jp.co.toshiba.hby.pspromis.syuueki.service;

import java.util.List;
import java.util.Map;
import javax.ejb.Stateless;
import javax.inject.Inject;
import javax.interceptor.Interceptors;
import jp.co.toshiba.hby.pspromis.syuueki.bean.K004Bean;
import jp.co.toshiba.hby.pspromis.syuueki.entity.JgrpTbl;
import jp.co.toshiba.hby.pspromis.syuueki.entity.MSectionView;
import jp.co.toshiba.hby.pspromis.syuueki.facade.JgrpTblFacade;
import jp.co.toshiba.hby.pspromis.syuueki.facade.MSectionFacade;
import jp.co.toshiba.hby.pspromis.syuueki.interceptor.TranceInterceptor;
import jp.co.toshiba.hby.pspromis.syuueki.util.LoginUserInfo;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
/**
 * PS-Promis収益管理システム
 * 担当部門(組織)選択 Service
 * @author kitajima
 */
@Stateless
@Interceptors({TranceInterceptor.class})
public class K004Service {

    public static final Logger logger = LoggerFactory.getLogger(K004Service.class);

    @Inject
    private K004Bean k004Bean;

    @Inject
    private LoginUserInfo loginUserInfo;

    @Inject
    private MSectionFacade mSectionFacade;

    @Inject
    private JgrpTblFacade jgrpTblFacade;

    /**
     * 初期表示時機能
     * @throws Exception
     */
    public void indexExecute() throws Exception {
        // 事業部が選択されていない場合
        if (k004Bean.getDivisionCode() == null) {
            // ログイン者の事業部を強制セット
            k004Bean.setDivisionCode(loginUserInfo.getJobGrSyokusyuArrayInfo("division"));
        }
        
        // 部課一覧を取得
        List<Map<String, Object>> bukaList = mSectionFacade.findJigyobuTreeList(k004Bean.getDivisionCode());

        k004Bean.setJigyobuList(bukaList);
    }

    /**
     * 課一覧取得
     */
    public void kaExecute() throws Exception {
        logger.info("deptCd=" + k004Bean.getDeptCd());
        
        // 課一覧を取得
        List<MSectionView> kaList = mSectionFacade.findDeptKa(k004Bean.getDeptCd());

        k004Bean.setKaList(kaList);
    }

}
