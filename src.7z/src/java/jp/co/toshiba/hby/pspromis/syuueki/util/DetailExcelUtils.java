package jp.co.toshiba.hby.pspromis.syuueki.util;

import java.util.ArrayList;
import java.util.List;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;

/**
 *
 * @author
 */
public class DetailExcelUtils {

    /**
     * 最終見込損益、期間損益、項番一覧シートで、指定した種類のシートのみ残し、残りのシートは削除する。
     * @param workbook Excelワークブック
     * @param sheetPrefixNames 対象出力シート(saisyu:最終見込損益 kikanS:期間損益(進行基準) koban:項番一覧) ※複数指定可能
     */
    public static void leaveDetailSheet(Workbook workbook, String... sheetPrefixNames) {
        // 出力対象外のシート名を抽出
        int sheetCount = workbook.getNumberOfSheets();
        List<String> removeSheetNames = new ArrayList<>();
        for (int i=0; i<sheetCount; i++) {
            String sheetName = workbook.getSheetName(i);
            if (!isTargetSheet(sheetName, sheetPrefixNames)) {
                removeSheetNames.add(sheetName);
                //workbook.removeSheetAt(i);
            }
        }
        
        // 出力対象外のシートを削除
        for (String removeSheetName: removeSheetNames) {
            int sheetIndex = workbook.getSheetIndex(removeSheetName);
            workbook.removeSheetAt(sheetIndex);
        }
        
        // 1つめの表示されているシートをアクティブにして,A列1行目を選択状態にする。
        activeFirstSheet(workbook);
    }

    /**
     * 出力対象シートであるかを判定
     * @param sheetName 対象シート
     * @param sheetPrefixNames 対象出力シート(saisyu:最終見込損益 kikanS:期間損益(進行基準) koban:項番一覧) ※複数指定可能
     */
    private static boolean isTargetSheet(String sheetName, String... sheetPrefixNames) {
        for (String prefixName: sheetPrefixNames) {
            if (sheetName.startsWith(prefixName)) {
                return true;
            }
        }
        return false;
    }

    /**
     * 1つめの表示されているシートをアクティブにして,A列1行目を選択状態にする。
     * @param Workbook workbook
     */
    private static void activeFirstSheet(Workbook workbook) {
        // 1つめの表示されているシートをアクティブにして,A列1行目を選択状態にする。
        boolean isSetActivedSheet = false;
        int sheetCount = workbook.getNumberOfSheets();
        for (int i=0; i<sheetCount; i++) {
            Sheet sheet = workbook.getSheetAt(i);
            sheet.setSelected(false);
            if (!workbook.isSheetHidden(i) && !isSetActivedSheet) {
                workbook.setActiveSheet(i);
                sheet.setSelected(true);
                Cell cell = PoiUtil.getCell(sheet, 0, 0);
                cell.setAsActiveCell();
                isSetActivedSheet = true;
            }
        }
    }

}
