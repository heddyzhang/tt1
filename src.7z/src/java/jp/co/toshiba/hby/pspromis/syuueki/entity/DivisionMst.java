package jp.co.toshiba.hby.pspromis.syuueki.entity;

import java.math.BigInteger;
import java.io.Serializable;
import java.util.Date;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/**
 *
 * @author ibayashi
 */
@Entity
@Table(name = "DIVISION_MST")
public class DivisionMst implements Serializable {

    private static final long serialVersionUID = 1L;
    
    @Id
    @Column(name = "DATA_SEQ")
    private BigInteger dataSeq;
    @Column(name = "DIVISION_TYPE")
    private short divisionType;
    @Column(name = "DIVISION_CODE")
    private String divisionCode;
    @Column(name = "DIVISION_SUB_CODE")
    private String divisionSubCode;
    @Column(name = "DIVISION_NAME")
    private String divisionName;
    @Column(name = "DIVISION_NAME_ENG")
    private String divisionNameEng;
    @Column(name = "DIVISION_SUB_NAME")
    private String divisionSubName;
    @Column(name = "DIVISION_SUB_NAME_ENG")
    private String divisionSubNameEng;
    @Column(name = "SORT_ORDER")
    private Short sortOrder;
    @Column(name = "SYORI_TYPE")
    private String syoriType;
    @Column(name = "ANKEN_EDIT_AUTH_KBN")
    private String ankenEditAuthKbn;
    @Column(name = "ALL_ANKEN_VIEW_SYOKUSYU_CD")
    private String allAnkenViewSyokusyuCd;
    @Column(name = "C_ANKEN_HEAD")
    private String cAnkenHead;
    @Column(name = "PRIORITY_SEQ")
    private Short  prioritySeq;
    @Column(name = "DASH_BOARD_URL")
    private String  dashBoardUrl;
    @Column(name = "QLIK_VIEW_GRAPH_URL")
    private String  qlikViewgGraphUrl;
    @Column(name = "AVAIL_FROM")
    @Temporal(TemporalType.DATE)
    private Date availFrom;
    @Column(name = "AVAIL_TO")
    @Temporal(TemporalType.DATE)
    private Date availTo;
    @Column(name = "CREATED_AT")
    @Temporal(TemporalType.DATE)
    private Date createdAt;
    @Column(name = "CREATED_BY")
    private String createdBy;
    @Column(name = "UPDATED_AT")
    @Temporal(TemporalType.DATE)
    private Date updatedAt;
    @Column(name = "UPDATED_BY")
    private String updatedBy;
    @Column(name = "DELETED_AT")
    @Temporal(TemporalType.DATE)
    private Date deletedAt;
    @Column(name = "DELETED_BY")
    private String deletedBy;
    @Column(name = "IS_DELETED")
    private short isDeleted;

    public DivisionMst() {
    }

    public BigInteger getDataSeq() {
        return dataSeq;
    }

    public void setDataSeq(BigInteger dataSeq) {
        this.dataSeq = dataSeq;
    }

    public short getDivisionType() {
        return divisionType;
    }

    public void setDivisionType(short divisionType) {
        this.divisionType = divisionType;
    }

    public String getDivisionCode() {
        return divisionCode;
    }

    public void setDivisionCode(String divisionCode) {
        this.divisionCode = divisionCode;
    }

    public String getDivisionName() {
        return divisionName;
    }

    public void setDivisionName(String divisionName) {
        this.divisionName = divisionName;
    }

    public String getDivisionNameEng() {
        return divisionNameEng;
    }

    public void setDivisionNameEng(String divisionNameEng) {
        this.divisionNameEng = divisionNameEng;
    }

    public Short getSortOrder() {
        return sortOrder;
    }

    public void setSortOrder(Short sortOrder) {
        this.sortOrder = sortOrder;
    }

    public String getSyoriType() {
        return syoriType;
    }

    public void setSyoriType(String syoriType) {
        this.syoriType = syoriType;
    }

    public Date getAvailFrom() {
        return availFrom;
    }

    public void setAvailFrom(Date availFrom) {
        this.availFrom = availFrom;
    }

    public Date getAvailTo() {
        return availTo;
    }

    public void setAvailTo(Date availTo) {
        this.availTo = availTo;
    }

    public Date getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(Date createdAt) {
        this.createdAt = createdAt;
    }

    public String getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    public Date getUpdatedAt() {
        return updatedAt;
    }

    public void setUpdatedAt(Date updatedAt) {
        this.updatedAt = updatedAt;
    }

    public String getUpdatedBy() {
        return updatedBy;
    }

    public void setUpdatedBy(String updatedBy) {
        this.updatedBy = updatedBy;
    }

    public Date getDeletedAt() {
        return deletedAt;
    }

    public void setDeletedAt(Date deletedAt) {
        this.deletedAt = deletedAt;
    }

    public String getDeletedBy() {
        return deletedBy;
    }

    public void setDeletedBy(String deletedBy) {
        this.deletedBy = deletedBy;
    }

    public short getIsDeleted() {
        return isDeleted;
    }

    public void setIsDeleted(short isDeleted) {
        this.isDeleted = isDeleted;
    }

    public Short getPrioritySeq() {
        return prioritySeq;
    }

    public void setPrioritySeq(Short prioritySeq) {
        this.prioritySeq = prioritySeq;
    }

    public String getDashBoardUrl() {
        return dashBoardUrl;
    }

    public void setDashBoardUrl(String dashBoardUrl) {
        this.dashBoardUrl = dashBoardUrl;
    }

    public String getDivisionSubCode() {
        return divisionSubCode;
    }

    public void setDivisionSubCode(String divisionSubCode) {
        this.divisionSubCode = divisionSubCode;
    }

    public String getDivisionSubName() {
        return divisionSubName;
    }

    public void setDivisionSubName(String divisionSubName) {
        this.divisionSubName = divisionSubName;
    }

    public String getDivisionSubNameEng() {
        return divisionSubNameEng;
    }

    public void setDivisionSubNameEng(String divisionSubNameEng) {
        this.divisionSubNameEng = divisionSubNameEng;
    }

    public String getcAnkenHead() {
        return cAnkenHead;
    }

    public void setcAnkenHead(String cAnkenHead) {
        this.cAnkenHead = cAnkenHead;
    }

    public String getAnkenEditAuthKbn() {
        return ankenEditAuthKbn;
    }

    public void setAnkenEditAuthKbn(String ankenEditAuthKbn) {
        this.ankenEditAuthKbn = ankenEditAuthKbn;
    }

    public String getQlikViewgGraphUrl() {
        return qlikViewgGraphUrl;
    }

    public void setQlikViewgGraphUrl(String qlikViewgGraphUrl) {
        this.qlikViewgGraphUrl = qlikViewgGraphUrl;
    }

    public String getAllAnkenViewSyokusyuCd() {
        return allAnkenViewSyokusyuCd;
    }

    public void setAllAnkenViewSyokusyuCd(String allAnkenViewSyokusyuCd) {
        this.allAnkenViewSyokusyuCd = allAnkenViewSyokusyuCd;
    }

}
