package jp.co.toshiba.hby.pspromis.syuueki.enums;

import java.util.ResourceBundle;
/**
 * プロパティファイル(env)のキーを定義
 * @author ibayashi
 */
public enum Env {
    Charset, PageCount, LoginSessionName,
    Mitumori_Yosan, Mitumori_Tehai, Mitumori_Sei, Mitumori_Seitehai,
    CsvSeparator, CsvCharSet, CsvLineBreak, PageingRange, Chosei_New_Input_Count,
    Upload_Temp_Dir, Upload_Temp_Dir_Work, Download_Temp_Dir_Work, DebugSessionId, Patten_Mst_File_Dir,
    Download_Temp_File_Dir, Rate_New_Input_Count, Ippan_New_Mikomi_Count, Mikomi_New_CurrencyCode_Count,
    Upload_Base_Att_Path, bprAuthenticationUrl, bprEcasKessaiUrl, bprSyuSyushiUrl, bprSyuUriShijiUrl, bprHatKaniItemUrl,
    CallN7RenkeiBatchFlg, Attach_File_New_Count, Aggregate_Max_Range_Month, Aggregate_Max_Range_Period, Aggregate_Max_Range_Year,
    //Div_Den, 
    //Div_Gen, 
    //Div_Ka, 
    //All_Edit_Anken_I_JobGr, 
    //SuigiBukaCode, 
    Kaisyu_New_Count,
    Shinko_Excel_Kasyu_Input_KanbaiCount,
    Shinko_Kasyu_KanbaiCount
    ;

    /**
     * プロパティファイルの取得
     *
     * @return
     */
    public String getValue() {
        return getValue(this);
    }
    
    /**
     * プロパティファイルの取得
     * @param env
     */
    public static String getValue(Env env) {
        ResourceBundle rb = ResourceBundle.getBundle("env");
        String value= rb.getString(env.name());
        return value;
    }

    /**
     * ダッシュボードのURLを取得
     * @param division division
     */
//    public static String getDashBoardUrl(String division) {
//        ResourceBundle rb = ResourceBundle.getBundle("env");
//        String value= rb.getString("dashBoardUrl_" + division);
//        return value;
//    }
}

