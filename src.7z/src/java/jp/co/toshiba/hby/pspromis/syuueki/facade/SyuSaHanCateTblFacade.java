package jp.co.toshiba.hby.pspromis.syuueki.facade;

import java.util.List;
import java.util.Map;
import javax.ejb.Stateless;
import javax.interceptor.Interceptors;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import jp.co.toshiba.hby.pspromis.common.util.BeanUtil;
import jp.co.toshiba.hby.pspromis.syuueki.entity.SyuSaHanCateTbl;
import jp.co.toshiba.hby.pspromis.syuueki.interceptor.TranceInterceptor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * 最終見込損益　販直費-カテゴリ別-詳細
 *
 * @author ganryu
 */
@Stateless
@Interceptors({TranceInterceptor.class})
public class SyuSaHanCateTblFacade extends AbstractFacade<SyuSaHanCateTbl> {
    private static final Logger logger = LoggerFactory.getLogger(SyuSaHanCateTblFacade.class);

    @PersistenceContext(unitName = jp.co.toshiba.hby.pspromis.syuueki.util.ConstantString.syuuekiDataSourceName)
    private EntityManager em;

    @Override
    protected EntityManager getEntityManager() {
        return em;
    }

    public SyuSaHanCateTblFacade() {
        super(SyuSaHanCateTbl.class);
    }

    public void merge(SyuSaHanCateTbl facade) {
        this.em.merge(BeanUtil.createAndCopy(SyuSaHanCateTbl.class, facade));
    }

    /**
     * 販売直接費　更新
     *
     * @param entity
     */
    public void setHanChokuNet(SyuSaHanCateTbl entity) {
        logger.info("SyuSaHanCateTblFacade#setHanChokuNet");
        sqlExecutor.executeUpdateSql(em, "/sql/syuSaHanCateTbl/updateHanChokuNet.sql", entity);
    }

    /**
     * コピー(複写)対象の通貨/レート/契約金額一覧を取得
     * @param _params
     * @return 
     */
    public List<SyuSaHanCateTbl> findCopyList(Map<String, Object> _params) {
        List<SyuSaHanCateTbl> list = sqlExecutor.getResultList(em, SyuSaHanCateTbl.class, "/sql/syuSaHanCateTbl/copyListSyuSaHanCateTbl.sql", _params);
        return list;
    }

}
