/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package jp.co.toshiba.hby.pspromis.syuueki.service.mikomiupload;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import javax.ejb.Stateless;
import javax.inject.Inject;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import jp.co.toshiba.hby.pspromis.common.util.StringUtil;
import jp.co.toshiba.hby.pspromis.syuueki.bean.MikomiUploadBean;
import jp.co.toshiba.hby.pspromis.syuueki.bean.MikomiUploadErrorBean;
import jp.co.toshiba.hby.pspromis.syuueki.entity.SyuGeBukkenInfoTbl;
import jp.co.toshiba.hby.pspromis.syuueki.enums.MikomiUploadLabel;
import jp.co.toshiba.hby.pspromis.syuueki.util.PoiUtil;
import jp.co.toshiba.hby.pspromis.syuueki.util.Utils;
import org.apache.commons.lang3.StringUtils;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * PS-Promis収益管理システム
 * 見込アップロード処理「(技)直課」
 * @author (NPC)Kitajima
 */
@Stateless
public class ChokkaUploadImpl implements UploadComponent {

    @PersistenceContext(unitName = jp.co.toshiba.hby.pspromis.syuueki.util.ConstantString.syuuekiDataSourceName)
    private EntityManager em;

    // 案件フラグ
    private final String MATOME_ANKEN_FLG = "1";

    public static final String ORDER_PROJECT_TITLE = "直課額（千円）";
    
    /**
     * ロガー
     */
    public static final Logger logger = LoggerFactory.getLogger(ChokkaUploadImpl.class);

    @Inject
    private MikomiUploadBean mikomiUploadBean;

    @Inject
    private MikomiUploadErrorBean mikomiUploadErrorBean;

    @Inject
    private UploadDataAccess uploadDataAccess;
    
    /**
     * 入力内容のデータチェック
     * @return
     * @throws java.lang.Exception
     */
    @Override
    public boolean isDataCheck() throws Exception {
        logger.info("ChokkaUploadImpl isDataCheck");

        boolean isCheck = false;

        // 作業対象シートを取得
        Sheet targetSheet = getTargetSheet();

        // Excelのタイトル(工場名)チェック
        Map<String, Object> categoryMstInfo = getCategoryInfo(targetSheet);

        if (categoryMstInfo != null) {
            // Excel上の一覧を読み取って、DBに登録する値の取得/エラーチェックを行う。
            isCheck = exeGetData(targetSheet, categoryMstInfo);
        }

        // beanに成功/失敗FLGをセット
        mikomiUploadErrorBean.setIsSuccess(isCheck);

        return isCheck;
    }

    /**
     * アップロード処理の実行
     * @throws java.lang.Exception
     */
    @Override
    public void executeUpload() throws Exception {
        logger.info("ChokkaUploadImpl executeUpload");

        // データの登録
        List<Map<String, Object>> dataList = mikomiUploadBean.getDataList();
        
        if (dataList == null) {
            return;
        }

        // データを登録
        String ankenId = "";
        String befAnkenId = "";
        Set<String> ankenIdSet = new HashSet<>();
        String minSyuekiYm = "";

        for (Map<String, Object> data : dataList) {
            ankenId = (String)data.get("ankenId");
            
            // SYU_KI_NET_CATE_TITLE_TBLの新規登録
            if (!befAnkenId.equals(ankenId)) {
                uploadDataAccess.insertKiNetCateTitleTbl(data);
                
                // 指定案件に対して再計算FLGを立てる(進行基準画面の再計算ボタン用)。
                uploadDataAccess.setSaikeisanFlg(ankenId, (Integer)data.get("rirekiId"));
                
                ankenIdSet.add(ankenId);
            }

            // SYU_KI_NET_CATE_TUKI_TBLの更新(or新規登録)
            uploadDataAccess.updateKiNetCateTukiCdlTbl(data);
            //uploadDataAccess.updateKiNetCateTukiTbl(data);

            // 登録データ内で最小の年月を取得
            if (StringUtils.isEmpty(minSyuekiYm) || minSyuekiYm.compareTo((String)data.get("syuekiYm")) >= 0) {
                minSyuekiYm = (String)data.get("syuekiYm");
            }

            befAnkenId = ankenId;
        }

        // SYU_KI_NET_CATE_TUKI_CLD_TBLからSYU_KI_NET_CATE_TUKI_TBLへ集計値を登録する。
        String[] ankenIdList = ankenIdSet.toArray(new String[0]);
        List<Map<String, Object>> sumYmList = uploadDataAccess.getSumYmList(ankenIdList, minSyuekiYm);
        for (Map<String, Object> info : sumYmList) {
            Map<String, Object> cateTukiInfo = new HashMap<>();
            cateTukiInfo.put("ankenId", info.get("ANKEN_ID"));
            cateTukiInfo.put("rirekiId", 0);
            cateTukiInfo.put("dataKbn", "M");
            cateTukiInfo.put("syuekiYm", info.get("SYUEKI_YM"));
            cateTukiInfo.put("categoryCode", info.get("CATEGORY_CODE"));
            cateTukiInfo.put("categoryKbn1", info.get("CATEGORY_KBN1"));
            cateTukiInfo.put("categoryKbn2", info.get("CATEGORY_KBN2"));
            cateTukiInfo.put("net", info.get("NET"));

            uploadDataAccess.updateKiNetCateTukiTbl(cateTukiInfo);
        }
    }

    /**
     * 処理対象ワークシートの取得
     */
    private Sheet getTargetSheet() {
        Sheet sheet = (mikomiUploadBean.getWorkBook()).getSheetAt(0);
        return sheet;
    }

    /**
     * Excelのタイトルチェック(京浜,府などのタイトルと画面指定のファイル区分一致のチェック)
     */
    private Map<String, Object> getCategoryInfo(Sheet sheet) throws Exception{
        //String errorMessage = MikomiUploadLabel.getValue(MikomiUploadLabel.titleFormatError);
        
        Map<String, Object> categoryMstInfo = null;
        Cell titleCell = PoiUtil.getCell(sheet, 1, 1);
        String title = (String)PoiUtil.getCellValue(titleCell);

        // (2018/01)直課Excelには部課コードを入れるのをやめて、カテゴリコードを直接入れるようにするので、それでマスタを検索する。
        //title = UploadUtil.getBukaCategoryCode(title);
        //categoryMstInfo = uploadDataAccess.categoryMstInfo(title);
        categoryMstInfo = uploadDataAccess.categoryMstInfoFromCateCode(title);

        if (categoryMstInfo == null) {
            //mikomiUploadErrorBean.addErrorMessage(MikomiUploadLabel.getValue(MikomiUploadLabel.bukaError));
            mikomiUploadErrorBean.addErrorMessage(MikomiUploadLabel.getValue(MikomiUploadLabel.categoryError));
        }

        return categoryMstInfo;
    }

    /**
     * Excel上の一覧を読み取って、DBに登録する値の取得/エラーチェックを行う
     */
    private boolean exeGetData(Sheet sheet, Map<String, Object> categoryMstInfo){
        boolean isSuccess = true;

        Row row;

        SyuGeBukkenInfoTbl bukkenEn = null;
        
        String monthBeforeError = MikomiUploadLabel.getValue(MikomiUploadLabel.monthBeforeError);
        String monthFormatError = MikomiUploadLabel.getValue(MikomiUploadLabel.monthFormatError);
        
        int errorRow;
        int nullCellCount = 0;
        int startMonthCell =0;
        
        String dataMonth = "";
        String beforeMonth = "";
        
        ArrayList<Map<String, Object>> dataList = new ArrayList<>();

        String fileKbn = UploadUtil.getCldFileKbn("05", "");
        
        //////////// 日付を取得 //////////
        for (int i = 0; i < sheet.getLastRowNum(); i++) {
            //注番タイトル取得
            row = sheet.getRow(i + 1);
            if (row == null) {
                continue;
            }
            
            Cell dateCell = PoiUtil.getCell(row, 1);
            // 日付セルが計算式の場合はスルー
            if (dateCell.getCellType() == Cell.CELL_TYPE_FORMULA) {
                continue;
            }

            String val = Utils.getObjToStrValue(PoiUtil.getCellValue(dateCell));

            if (StringUtils.isNotEmpty(val) && val.equals(ORDER_PROJECT_TITLE)) {
                // セルの値が「直課額（千円）」の場合は、注番を読むためにカウンタを3プラス
                i = i + 3;
                row = sheet.getRow(i);
                startMonthCell = i + 1;
            } else if(startMonthCell == 0) {
                continue;
            }

            if (StringUtils.isNotEmpty(val) && val.equals("期計")){
                break;
            } else if (StringUtils.isNotEmpty(val) && !val.equals(ORDER_PROJECT_TITLE)) {
                dataMonth = convCellValToDate(val, beforeMonth);
                if (StringUtils.isEmpty(dataMonth)){
                    continue;
                }
                
                //日付エラーチェック
                if (dataMonth.equals("noUpdate")) {
                    // 指定年月以前の場合はスキップ
                    continue;
                } if (dataMonth.equals(monthBeforeError) || dataMonth.equals(monthFormatError)) {
                    // フォーマットエラー、または年月エラー
                    errorRow = row.getRowNum() + 1;
                    mikomiUploadErrorBean.addErrorMessage(val + "：" + "(" + errorRow + ")行目" + "：" + dataMonth + "(" + val + ")");
                    isSuccess = false;
                } else if(!beforeMonth.equals(monthBeforeError)) {
                    Map<String, Object> dataMap = new HashMap<>();
                    beforeMonth = dataMonth;
                    dataMap.put("syuekiYm", dataMonth);
                    dataMap.put("colNo", String.valueOf(row.getRowNum()));
                    dataList.add(dataMap);
                }
            }
        }

        //////////// 各注番のデータを取得 //////////
        if (isSuccess && dataList.size() > 0) {
            for(int i = 2; i <= 1000; i++){
                // 注番行に値が存在しないセルが３回連続した場合、ループを抜ける
                if (nullCellCount >= 3) {
                    break;
                }

                row = sheet.getRow(startMonthCell);
                String rawData = Utils.getObjToStrValue(PoiUtil.getCellValue(row, i));
                if (StringUtils.isEmpty(rawData)){
                    // 値が存在しない場合は、nullセルカウンタをカウントアップ
                    nullCellCount++;
                    continue;
                } else {
                    // 見つかった場合はnullセルカウンタをリセット
                    rawData = StringUtils.replace(rawData, " ", "");
                    nullCellCount = 0;
                }

                if (!UploadUtil.isTargetOrderNo(rawData)) {
                    continue;
                }

                //更新情報
                // 注番より収益物件TBLを検索し、案件情報を取得
                bukkenEn = uploadDataAccess.findOnoBuken(rawData, this.MATOME_ANKEN_FLG);
                if (bukkenEn == null || !bukkenEn.getDivisionCode().equals(mikomiUploadBean.getUploadDivisionCode())) {
                    isSuccess = false;
                    mikomiUploadErrorBean.addErrorMessage(MikomiUploadLabel.getValue(MikomiUploadLabel.projectError) + "(" + rawData + ")");
                    continue;
                }

                // 正常終了時のため、結果子画面に出力するメッセージ(案件番号/注番)を登録
                mikomiUploadErrorBean.addMessage("■" + bukkenEn.getAnkenId() + "/" + bukkenEn.getMainOrderNo());
                
                for(int n = 0; n < dataList.size(); n++){
                    Map<String, Object> dataMap = new HashMap<>();
                    dataMap.put("syuekiYm", dataList.get(n).get("syuekiYm"));
                    dataMap.put("orderNo", bukkenEn.getMainOrderNo());
                    dataMap.put("ankenId", bukkenEn.getAnkenId());

                    // 事前に取得した行数より金額取得
                    row = sheet.getRow(Integer.parseInt((String)dataList.get(n).get("colNo")));
                    String chunyuAmount = Utils.getObjToStrValue(PoiUtil.getCellValue(row, i));
                    
                    // 金額チェック
                    String amount = changeAmountStr(chunyuAmount);
                    
                    // 金額のフォーマットエラー、または桁数エラー
                    if("formatError".equals(amount)){
                        isSuccess = false;
                        errorRow = row.getRowNum() + 1;
                        mikomiUploadErrorBean.addErrorMessage(rawData + "(" + errorRow + ")行目：" + MikomiUploadLabel.getValue(MikomiUploadLabel.chunyuAmountFormatError) + "(" + chunyuAmount + ")");
                        continue;

                    } else if("ketaOverError".equals(amount)){
                        isSuccess = false;
                        errorRow = row.getRowNum() + 1;
                        mikomiUploadErrorBean.addErrorMessage(rawData + "(" + errorRow + ")行目：" + MikomiUploadLabel.getValue(MikomiUploadLabel.chunyuAmountKetaFormatError) + "(" + chunyuAmount + ")");
                        continue;
                    }
                    
                    dataMap.put("net", Utils.changeBigDecimal(amount));
                    
                    dataMap.put("rirekiId", 0);
                    dataMap.put("dataKbn", "M");
                    dataMap.put("kbn", fileKbn);
                    dataMap.put("categoryCode", categoryMstInfo.get("CATEGORY_CODE"));
                    dataMap.put("categoryKbn1", categoryMstInfo.get("CATEGORY_KBN1"));
                    dataMap.put("categoryKbn2", categoryMstInfo.get("CATEGORY_KBN2"));
                    dataMap.put("categoryName1", categoryMstInfo.get("CATEGORY_NAME1"));
                    dataMap.put("categoryName2", categoryMstInfo.get("CATEGORY_NAME2"));
                    dataMap.put("categorySeq", categoryMstInfo.get("CATEGORY_SEQ"));

                    this.mikomiUploadBean.addDataList(dataMap);
                }
            }
        }
        return isSuccess;
    }
    /**
     * セルの日付データの読込み
     * @param cellValue
     * @return
     */
    private String convCellValToDate(String cellValue, String beforeMonth) {
        String retStr;
        String BeforeFormMonthError = "noUpdate";

        if (StringUtils.isEmpty(cellValue)) {
            return null;
        }

        try {
            retStr = cellValue;
            retStr = Utils.convertToHankaku(retStr);
            retStr = StringUtils.replace(retStr, "/", "");
/*
            if (retStr.matches(".*実績.*")) {
                retStr = BeforeFormMonthError;
                return retStr;
            }
*/
            
            if (retStr.endsWith("年1Q計画")
                    || retStr.endsWith("年2Q計画")
                    || retStr.endsWith("年3Q計画")
                    || retStr.endsWith("1Q")
                    || retStr.endsWith("2Q")
                    || retStr.endsWith("3Q")
                    || retStr.endsWith("上期")
                ) {
                retStr = StringUtils.replace(retStr, "年1Q計画", "06");
                retStr = StringUtils.replace(retStr, "年1Q計画", "06");
                retStr = StringUtils.replace(retStr, "年2Q計画", "09");
                retStr = StringUtils.replace(retStr, "年3Q計画", "12");
                retStr = StringUtils.replace(retStr, "1Q", "06");
                retStr = StringUtils.replace(retStr, "2Q", "09");
                retStr = StringUtils.replace(retStr, "3Q", "12");
                retStr = StringUtils.replace(retStr, "上期", "09");

            } else if( retStr.endsWith("年4Q計画")
                    || retStr.endsWith("年度実績")
                    || retStr.endsWith("年計画")
                    || retStr.endsWith("4Q")
                    || retStr.endsWith("年度")
                    || retStr.endsWith("下期")){
                retStr = StringUtils.replace(retStr, "年4Q計画", "");
                retStr = StringUtils.replace(retStr, "年度実績", "");
                retStr = StringUtils.replace(retStr, "年計画", "");
                retStr = StringUtils.replace(retStr, "年度", "");
                retStr = StringUtils.replace(retStr, "下期", "");
                retStr = StringUtils.replace(retStr, "4Q", "");
                retStr = StringUtils.replace(retStr, "～", "");
                retStr = String.valueOf(Integer.parseInt(retStr) + 1);
                retStr = retStr + "03";

            } else if (retStr.matches(".*実績.*")) {
                retStr = BeforeFormMonthError;
                return retStr;
            }

            Date date = UploadUtil.changeStrToDate(retStr);
            retStr = UploadUtil.changeDateToStr(date);

            // セルの年月が画面で指定した開始年月より前であれば読み飛ばす。
            Date startYm = mikomiUploadBean.getStartYm();
            if (date.before(startYm)) {
                retStr = BeforeFormMonthError;
                return retStr;
            }

            // 取得した年月が前のセルより前年月(時系列になっていない)場合はエラーとする。
            if (StringUtil.isNotEmpty(beforeMonth)) {
                Date beforeDate = Utils.parseDate(beforeMonth);
                if (date.before(beforeDate)) {
                    retStr = MikomiUploadLabel.getValue(MikomiUploadLabel.monthBeforeError);
                }
            }

        } catch (Exception e) {
            retStr = MikomiUploadLabel.getValue(MikomiUploadLabel.monthFormatError);
        }

        return retStr;
    }

    private String changeAmountStr(String str) {
        String amount = str;

        //logger.info("amount=" + amount + " isNum=" + Utils.isNumeric(amount));

        if (!Utils.isNumeric(amount)) {
            return "formatError";
        } else {
            BigDecimal dAmount = Utils.changeBigDecimal(amount);
            if (dAmount != null) {
                amount = dAmount.setScale(3, BigDecimal.ROUND_HALF_UP).multiply(new BigDecimal(1000)).toString();
                amount = UploadUtil.changeAmountStrSub(amount);
                if (StringUtils.length(amount) > 13) {
                    return "ketaOverError";
                }
            }
        }

        return amount;
    }
/*
    private String changeAmountStrSub(String amount) {
        if (StringUtils.isEmpty(amount)) {
            return null;
        }

        String checkAmount = amount;
        checkAmount = StringUtils.replace(checkAmount, "-", "");
        int point = checkAmount.lastIndexOf('.');
        if (point > 0) {
            checkAmount = StringUtils.substring(checkAmount, 0, point);
        }

        return checkAmount;
    }
*/
}
