package jp.co.toshiba.hby.pspromis.syuueki.facade;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.ejb.Stateless;
import javax.inject.Inject;
import javax.interceptor.Interceptors;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import jp.co.toshiba.hby.pspromis.common.jdbc.SqlExecutor;
import jp.co.toshiba.hby.pspromis.syuueki.interceptor.TranceInterceptor;
import jp.co.toshiba.hby.pspromis.syuueki.util.LoginUserInfo;
import jp.co.toshiba.hby.pspromis.syuueki.entity.StringEntity;
import org.apache.commons.collections.CollectionUtils;

/**
 *
 * @author ibayashi
 */
@Stateless
@Interceptors({TranceInterceptor.class})
public class SyuKiJyuchuNetTblFacade {

    @PersistenceContext(unitName = jp.co.toshiba.hby.pspromis.syuueki.util.ConstantString.syuuekiDataSourceName)
    private EntityManager em;

    @Inject
    private LoginUserInfo loginUserInfo;
    
    @Inject
    protected SqlExecutor sqlExecutor;

    /**
     * パラメータにログイン者idをセット
     */
    private Map<String, Object> addParamLoginId(Map<String, Object> _params) {
        Map<String, Object> ret = _params;
        if (ret == null) {
            ret = new HashMap<>();
        }
        ret.put("userId", loginUserInfo.getUserId());
        return ret;
    }
    
    /**
     * 受注管理/受注NETの更新(新規登録)
     * @param _params
     * @return 
     */
    public int entryJyuchuNet(Map<String, Object> _params) {
        return entryJyuchuNet(_params, false);
    }

    /**
     * 受注管理/受注NETの更新(新規登録)
     * @param _params
     * @param isForceEntryFlg 受注SPが未登録(null)でも強制的にレコードを作成するFLG
     * @return 
     */
    public int entryJyuchuNet(Map<String, Object> _params, boolean isForceEntryFlg) {
        Map<String, Object> params = addParamLoginId(_params);
        int count = 0;
        Object amount = _params.get("jyuchuNet");
        
        if (amount == null && !isForceEntryFlg) {
            // 更新
            deleteJyuchuNet(_params);
        } else {
            // 更新
            count = sqlExecutor.executeUpdateSql(em, "/sql/syuKiJyuchuNetTbl/updateSyuKiJyuchuNetTbl.sql", params);
            // 更新データ存在しない場合は新規登録
            if (count == 0 && (amount != null || isForceEntryFlg)) {
                insertJyuchuNet(params);
            }
        }

        return count;
    }
    
    /**
     * 受注管理/受注NETの新規登録
     * @param _params
     * @return 
     */
    public int insertJyuchuNet(Map<String, Object> _params) {
        Map<String, Object> params = addParamLoginId(_params);
        int count = sqlExecutor.executeUpdateSql(em, "/sql/syuKiJyuchuNetTbl/insertSyuKiJyuchuNetTbl.sql", params);
        return count;
    }

    /**
     * 受注管理 削除
     * @param _params
     * @return 
     */
    public int deleteJyuchuNet(Map<String, Object> _params) {
        int count= sqlExecutor.executeUpdateSql(em, "/sql/syuKiJyuchuNetTbl/deleteSyuKiJyuchuNetTbl.sql", _params);
        return count;
    }
    
    /**
     * 最新の年月を取得
     * @param params
     * @return 
     */
    public String getMaxSyuekiYm(Map<String, Object> params){
        List<StringEntity> list = sqlExecutor.getResultList(em, StringEntity.class, "/sql/syuKiJyuchuNetTbl/selectMaxSyuekiYm.sql", params);
        
        if (CollectionUtils.isNotEmpty(list)) {
            return list.get(0).getString().trim();
        } else {
            return "";
        }
    }

    /**
     * 売上年月の更新
     * @param _params
     */
    public int changeSyuekiYm(Map<String, Object> _params){
        int count = sqlExecutor.executeUpdateSql(em, "/sql/syuKiJyuchuNetTbl/changeSyuekiYm.sql", _params);
        return count;
    }

}
