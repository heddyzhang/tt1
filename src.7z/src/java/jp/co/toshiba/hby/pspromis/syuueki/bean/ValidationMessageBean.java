package jp.co.toshiba.hby.pspromis.syuueki.bean;

import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;
import javax.annotation.PostConstruct;
import javax.inject.Named;
import javax.enterprise.context.RequestScoped;
import jp.co.toshiba.hby.pspromis.syuueki.enums.ValidatorMessage;
import lombok.Getter;
import lombok.Setter;
import org.apache.commons.lang3.StringUtils;

/**
 *
 * @author ibayashi
 */
@Named(value = "validationMessageBean")
@RequestScoped
@Getter @Setter
public class ValidationMessageBean {

    private LinkedHashMap<String, String> errorInfo;

    private Map<String, Object> customErrorInfo = null;
    
    private int successFlg = 0;
    
    private int updatedFlg = 0;
    
    @PostConstruct
    public void init() {
        errorInfo = new LinkedHashMap<>();
    }
    
    public void setErrorInfo(String key, String message) {
        errorInfo.put(key, message);
    }
    
    public String getErrorMessage(String key) {
        return StringUtils.defaultString(errorInfo.get(key));
    }
    
    public boolean isSuccess() {
        boolean validationSuccessFlg = false;
        if (errorInfo.isEmpty() && updatedFlg == 0) {
            validationSuccessFlg = true;
        }
        return validationSuccessFlg;
    }
    
    public String getInputErrorDispTag(String key) {
        String message = getErrorMessage(key);
        String tag = "<span id='error-info-" + key + "' class='error-info-message'>" + message + "</span>";
        return tag;
    }

    public String getResultMessageTag() {
        String resultClass;
        String resultMessage;
        
        if (customErrorInfo != null) {
            resultClass = StringUtils.defaultString((String)customErrorInfo.get("RESULT_MESSAGE_CLASS"));
            resultMessage = StringUtils.defaultString((String)customErrorInfo.get("RESULT_MESSAGE"));
        } else {
            Map<String, String> jsonResult = getResultInfo(successFlg);
            resultClass = StringUtils.defaultString(jsonResult.get("RESULT_MESSAGE_CLASS"));
            resultMessage = StringUtils.defaultString(jsonResult.get("RESULT_MESSAGE"));
        }

        String tag = "<div id='resultMessage' class='" + resultClass + "' style='margin-top:7px;margin-bottom:-5px;margin-left:21px;'>" + resultMessage + "</div>";
        return tag;
    }

    public void setCustomErrorMessage(String message) {
        if (customErrorInfo == null) {
            customErrorInfo = new HashMap<>();
            customErrorInfo.put("VALIDATION_ERROR_FLG", "1");
            customErrorInfo.put("RESULT_MESSAGE_CLASS", "resultError");
        }
        customErrorInfo.put("RESULT_MESSAGE", message);
    }
    
    public Map<String, Object> errorJsonInfo() {
        if (customErrorInfo != null) {
            return customErrorInfo;
        }
        
        Map<String, Object> jsonInfo = new LinkedHashMap<>();
        if (!isSuccess()) {
            // エラーがある場合
            jsonInfo.put("VALIDATION_ERROR_FLG", "1");
//            if (updatedFlg == 1) {
//                // 排他エラー
//                jsonInfo.put("RESULT_MESSAGE", ValidatorMessage.EXISTS_EFFECTIVE_ERROR.getMessae());
//                jsonInfo.put("RESULT_MESSAGE_CLASS", "resultError");
//            } else {
//                // 通常のバリデーションエラー
//                jsonInfo.put("ERROR_MESSAGE_LIST", errorInfo);
//                jsonInfo.putAll(getResultInfo(-1));
//            }
            
            jsonInfo.put("ERROR_MESSAGE_LIST", errorInfo);
            jsonInfo.putAll(getResultInfo(-1));
        }
        return jsonInfo;
    }

    public Map<String, String> getResultInfo(int successFlg) {
        Map<String, String> jsonInfo = new LinkedHashMap<>();
        if (successFlg < 0) {
            jsonInfo.put("RESULT_MESSAGE", ValidatorMessage.PROCESS_ERROR.getMessae());
            jsonInfo.put("RESULT_MESSAGE_CLASS", "resultError");
        } 
//        else if (successFlg >= 1) {
//            jsonInfo.put("RESULT_MESSAGE", ValidatorMessage.PROCESS_SAVE_SUCCESS.getMessae());
//            jsonInfo.put("RESULT_MESSAGE_CLASS", "resultSuccess");
//        }
        return jsonInfo;
    }
    
}
