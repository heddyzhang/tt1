package jp.co.toshiba.hby.pspromis.syuueki.facade;

import javax.ejb.Stateless;
import javax.inject.Inject;
import javax.interceptor.Interceptors;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import jp.co.toshiba.hby.pspromis.common.jdbc.SqlExecutor;
import jp.co.toshiba.hby.pspromis.syuueki.interceptor.TranceInterceptor;

/**
 * チームコード取得関連
 * @author ibayashi
 */
@Stateless
@Interceptors({TranceInterceptor.class})
public class NucUriageSetuFacade {

    @PersistenceContext(unitName = jp.co.toshiba.hby.pspromis.syuueki.util.ConstantString.syuuekiDataSourceName)
    private EntityManager em;
    
    @Inject
    protected SqlExecutor sqlExecutor;
    
    public int countUriageSetu(Object condition) {
        Integer count = sqlExecutor.getCount(em, "/sql/nucUriageSetu/selectCountNucUriageSetu.sql", condition);
        return count;
    }

}
