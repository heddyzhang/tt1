package jp.co.toshiba.hby.pspromis.syuueki.facade;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.interceptor.Interceptors;
import javax.ejb.Stateless;
import javax.inject.Inject;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import jp.co.toshiba.hby.pspromis.syuueki.entity.StringEntity;
import jp.co.toshiba.hby.pspromis.syuueki.entity.SyuKiKaisyuTblView;
import jp.co.toshiba.hby.pspromis.syuueki.entity.SyuKiSpTukiITbl;
import jp.co.toshiba.hby.pspromis.syuueki.interceptor.TranceInterceptor;
import jp.co.toshiba.hby.pspromis.syuueki.util.LoginUserInfo;
import org.apache.commons.collections.CollectionUtils;
//import org.apache.commons.lang3.StringUtils;

/**
 *
 * @author ibayashi
 */
@Stateless
@Interceptors({TranceInterceptor.class})
public class SyuKiKaisyuTblFacade extends AbstractFacade<SyuKiSpTukiITbl> {

    @PersistenceContext(unitName = jp.co.toshiba.hby.pspromis.syuueki.util.ConstantString.syuuekiDataSourceName)
    private EntityManager em;

    @Override
    protected EntityManager getEntityManager() {
        return em;
    }

    public SyuKiKaisyuTblFacade() {
        super(SyuKiSpTukiITbl.class);
    }

    @Inject
    private LoginUserInfo loginUserInfo;

    /**
     * パラメータにログイン者idをセット
     */
    private Map<String, Object> addParamLoginId(Map<String, Object> _params) {
        Map<String, Object> ret = _params;
        if (ret == null) {
            ret = new HashMap<>();
        }
        ret.put("userId", loginUserInfo.getUserId());
        return ret;
    }

    /**
     * 期間損益・月別詳細(一般) 回収 削除
     *
     * @param _params
     * @return
     */
    public int deleteSyuKiKaisyuTbl(Map<String, Object> _params) {
        int count = sqlExecutor.executeUpdateSql(em, "/sql/syuKiKaisyuTbl/deleteSyuKiKaisyuTbl.sql", _params);
        return count;
    }

    /**
     * 期間損益・月別詳細(一般) 回収(更新/新規登録)
     *
     * @param _params
     * @return
     */
    public int entrySyuKiKaisyuTbl(Map<String, Object> _params) throws Exception {
        return entrySyuKiKaisyuTbl(_params, false);
    }
        
    /**
     * 期間損益・月別詳細(一般) 回収(更新/新規登録)
     *
     * @param _params
     * @param isForceEntryFlg 回収額が未登録(null)でも強制的にレコードを作成するFLG
     * @return
     */
    public int entrySyuKiKaisyuTbl(Map<String, Object> _params, boolean isForceEntryFlg) throws Exception {
        int count = 0;

        Object amount = _params.get("kaisyuAmount");
        Object enkaAmount = _params.get("kaisyuEnkaAmount");

        Map<String, Object> param = new HashMap<>(_params);
        param.put("syuekiYm", param.get("syukeiYm"));   // 削除SQLと更新/登録SQLで年月のkeyが違っていたため、統一しておく
        
        if ((amount == null && enkaAmount == null) && !isForceEntryFlg) {
            // 回収額が未入力の場合はレコード削除
            deleteSyuKiKaisyuTbl(param);
        } else {
            // 更新
            count = this.updateSyuKiKaisyuTbl(param);
            // 更新データ存在しないかつ金額がNULLでない(または強制登録指示)の場合は新規登録
            if (count == 0 && (amount != null || enkaAmount != null || isForceEntryFlg)) {
                count = this.insertSyuKiKaisyuTbl(param);
            }
        }
        
        return count;
    }

    /**
     * 期間損益・月別詳細(一般) 回収 登録
     *
     * @param _params
     * @return
     */
    public int insertSyuKiKaisyuTbl(Map<String, Object> _params) throws Exception {
        Map<String, Object> params = addParamLoginId(_params);
        int count = sqlExecutor.executeUpdateSql(em, "/sql/syuKiKaisyuTbl/insertSyuKiKaisyuTbl.sql", params);
        return count;
    }

    /**
     * 期間損益・月別詳細(一般) 回収 更新
     *
     * @param _params
     * @return
     */
    public int updateSyuKiKaisyuTbl(Map<String, Object> _params) throws Exception {
        Map<String, Object> params = addParamLoginId(_params);
        int count = sqlExecutor.executeUpdateSql(em, "/sql/syuKiKaisyuTbl/updateSyuKiKaisyuTbl.sql", _params);
        return count;
    }
    
    /**
     * 回収種別取得
     * @param ankenId
     * @param rirekiId
     * @return 
     */
    public List<SyuKiKaisyuTblView> selectKaisyuSyubetuList(String ankenId, String rirekiId){
        Map<String, Object> condition = new HashMap<>();
        condition.put("ankenId", ankenId);
        condition.put("rirekiId", Integer.valueOf(rirekiId));
        
        List<SyuKiKaisyuTblView> list = sqlExecutor.getResultList(em, SyuKiKaisyuTblView.class, "/sql/syuKiKaisyuTbl/selectKaisyuSyubetuList.sql", condition);
        
        return list;
    }
    
    /**
     * 回収種別　存在チェック
     * @param condition
     * @return true:データが存在  false:データなし
     */
    public boolean countKaisyuSyubetsu(Map<String, Object> condition){
        boolean flg = false;
        
        List<StringEntity> list = sqlExecutor.getResultList(em, StringEntity.class, "/sql/syuKiKaisyuTbl/countKaisyuSyubetu.sql", condition);
        
        if(CollectionUtils.isNotEmpty(list)){
            flg = true;
        }
        
        return flg;
    }
    
    /**
     * 回収種別　勘定年月の取得
     * @param params
     * @return 
     */
    public String getMaxSyuekiYm(Map<String, Object> params){
        List<StringEntity> list = sqlExecutor.getResultList(em, StringEntity.class, "/sql/syuKiKaisyuTbl/selectMaxSyuekiYm.sql", params);
        
        if(CollectionUtils.isNotEmpty(list)){
            return list.get(0).getString().trim();
        } else {
            return "";
        }
        
    }

    /**
     * 回収種別　回収種別登録用の年月を取得
     * @param params
     * @return 
     */
    public String getMaxKaisyuShubetsuYm(Map<String, Object> params){
        List<StringEntity> list = sqlExecutor.getResultList(em, StringEntity.class, "/sql/syuKiKaisyuTbl/selectMaxKaisyuShubetsuYm.sql", params);
        
        if(CollectionUtils.isNotEmpty(list)){
            return list.get(0).getString().trim();
        } else {
            return "";
        }
    }

    /**
     * 回収種別 更新処理
     *
     * @param _params
     * @return
     */
    public int updateKaisyuSyubetu(Map<String, Object> _params) throws Exception {
        Map<String, Object> params = addParamLoginId(_params);
        int count = sqlExecutor.executeUpdateSql(em, "/sql/syuKiKaisyuTbl/updateKaisyuSyubetu.sql", params);
        return count;
    }

    /**
     * 回収種別 登録処理
     *
     * @param _params
     * @return
     */
    public int insertKaisyuSyubetu(Map<String, Object> _params) throws Exception {
        Map<String, Object> params = addParamLoginId(_params);
        int count = sqlExecutor.executeUpdateSql(em, "/sql/syuKiKaisyuTbl/insertKaisyuSyubetu.sql", params);
        return count;
    }

    /**
     * 回収種別 削除処理
     *
     * @param _params
     * @return
     */
    public int deleteKaisyuSyubetu(Map<String, Object> _params) {
        int count = sqlExecutor.executeUpdateSql(em, "/sql/syuKiKaisyuTbl/deleteKaisyuSyubetu.sql", _params);
        return count;
    }
    
    /**
     * 回収情報を特定年月から特定年月にコピー
     * @param condition
     */
    public int copyKaisyuYm(Map<String, Object> condition) {
        // 回収データの年月コピーを行う
        int count = sqlExecutor.executeUpdateSql(em, "/sql/syuKiKaisyuTbl/copyKaisyuTukiData.sql", condition);
        
        // 移動前の回収データを削除する
        //deleteSyuKiKaisyuTbl(condition);
        
        return count;
    }

}
