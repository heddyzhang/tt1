/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package jp.co.toshiba.hby.pspromis.syuueki.entity;

import java.io.Serializable;
import java.math.BigDecimal;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import lombok.Getter;
import lombok.Setter;

/**
 *
 * @author ibayashi
 */
@Entity
@Getter @Setter
public class KsLossData implements Serializable {
    private static final long serialVersionUID = 1L;

    @Id
    @Column(name = "ROW_NAME_ID")
    private String rowNameId;

    @Column(name = "LOSS_B_RUIKEI")
    private BigDecimal lossBRuikei;
    
    @Column(name = "LOSS_1")
    private BigDecimal loss1;
    
    @Column(name = "LOSS_2")
    private BigDecimal loss2;
    
    @Column(name = "LOSS_3")
    private BigDecimal loss3;
    
    @Column(name = "LOSS_4")
    private BigDecimal loss4;
    
    @Column(name = "LOSS_5")
    private BigDecimal loss5;
    
    @Column(name = "LOSS_6")
    private BigDecimal loss6;
    
    @Column(name = "LOSS_7")
    private BigDecimal loss7;
    
    @Column(name = "LOSS_8")
    private BigDecimal loss8;
    
    @Column(name = "LOSS_9")
    private BigDecimal loss9;
    
    @Column(name = "LOSS_10")
    private BigDecimal loss10;
    
    @Column(name = "LOSS_11")
    private BigDecimal loss11;
    
    @Column(name = "LOSS_12")
    private BigDecimal loss12;
    
    @Column(name = "LOSS_1Q")
    private BigDecimal loss1Q;
    
    @Column(name = "LOSS_2Q")
    private BigDecimal loss2Q;
    
    @Column(name = "LOSS_3Q")
    private BigDecimal loss3Q;
    
    @Column(name = "LOSS_4Q")
    private BigDecimal loss4Q;
    
    @Column(name = "LOSS_K1")
    private BigDecimal lossK1;
    
    @Column(name = "LOSS_K2")
    private BigDecimal lossK2;
    
    @Column(name = "LOSS_G")
    private BigDecimal lossG;
    
    @Column(name = "LOSS_K1_DIFF")
    private BigDecimal lossK1Diff;
    
    @Column(name = "LOSS_K2_DIFF")
    private BigDecimal lossK2Diff;
    
    @Column(name = "LOSS_G_DIFF")
    private BigDecimal lossGDiff;
    
    @Column(name = "LOSS_1Q_DIFF")
    private BigDecimal loss1QDiff;
    
    @Column(name = "LOSS_2Q_DIFF")
    private BigDecimal loss2QDiff;
    
    @Column(name = "LOSS_3Q_DIFF")
    private BigDecimal loss3QDiff;
    
    @Column(name = "LOSS_4Q_DIFF")
    private BigDecimal loss4QDiff;
    
    @Column(name = "LOSS_TM")
    private BigDecimal lossTm;
    
    
    
}
