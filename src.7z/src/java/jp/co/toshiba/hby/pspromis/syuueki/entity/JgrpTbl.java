/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package jp.co.toshiba.hby.pspromis.syuueki.entity;

import java.io.Serializable;
import java.math.BigInteger;
import java.util.Date;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

/**
 *
 * @author ibayashi
 */
@Entity
@Table(name = "JGRP_TBL")
public class JgrpTbl implements Serializable {
    private static final long serialVersionUID = 1L;
    @Id
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 10)
    @Column(name = "JGRP_ID")
    private String jgrpId;
    @Basic(optional = false)
    @NotNull
    @Column(name = "JGRP_SEQ")
    private BigInteger jgrpSeq;
    @Basic(optional = false)
    @NotNull
    @Column(name = "JGRP_UP_SEQ")
    private BigInteger jgrpUpSeq;
    @Size(max = 120)
    @Column(name = "JGRP_NAME")
    private String jgrpName;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 64)
    @Column(name = "JGRP_PET_NAME")
    private String jgrpPetName;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 6)
    @Column(name = "JGRP_BU_CD")
    private String jgrpBuCd;
    @Size(max = 60)
    @Column(name = "JGRP_BU_NAME")
    private String jgrpBuName;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 6)
    @Column(name = "JGRP_KA_CD")
    private String jgrpKaCd;
    @Size(max = 60)
    @Column(name = "JGRP_KA_NAME")
    private String jgrpKaName;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 1)
    @Column(name = "JGRP_TYPE")
    private String jgrpType;
    @Size(max = 256)
    @Column(name = "JGRP_NOTE")
    private String jgrpNote;
    @Size(max = 1)
    @Column(name = "JGRP_STS")
    private String jgrpSts;
    @Size(max = 41)
    @Column(name = "JGRP_JOB_ID")
    private String jgrpJobId;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 1)
    @Column(name = "JGRP_KBN")
    private String jgrpKbn;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 1)
    @Column(name = "DELETE_FLG")
    private String deleteFlg;
    @Size(max = 1)
    @Column(name = "DELETE_KBN")
    private String deleteKbn;
    @Size(max = 8)
    @Column(name = "LOCKER_UID")
    private String lockerUid;
    @Size(max = 144)
    @Column(name = "LOCKER")
    private String locker;
    @Column(name = "INSERT_DATE")
    @Temporal(TemporalType.TIMESTAMP)
    private Date insertDate;
    @Column(name = "UPDATE_DATE")
    @Temporal(TemporalType.TIMESTAMP)
    private Date updateDate;
    @Column(name = "DELETE_DATE")
    @Temporal(TemporalType.TIMESTAMP)
    private Date deleteDate;
    @Size(max = 8)
    @Column(name = "INSERTER_UID")
    private String inserterUid;
    @Size(max = 144)
    @Column(name = "INSERTER")
    private String inserter;
    @Size(max = 8)
    @Column(name = "UPDATER_UID")
    private String updaterUid;
    @Size(max = 144)
    @Column(name = "UPDATER")
    private String updater;
    @Size(max = 8)
    @Column(name = "DELETER_UID")
    private String deleterUid;
    @Size(max = 144)
    @Column(name = "DELETER")
    private String deleter;
    @Size(max = 1)
    @Column(name = "JGRP_LEVEL")
    private String jgrpLevel;

    public JgrpTbl() {
    }

    public String getJgrpId() {
        return jgrpId;
    }

    public void setJgrpId(String jgrpId) {
        this.jgrpId = jgrpId;
    }

    public BigInteger getJgrpSeq() {
        return jgrpSeq;
    }

    public void setJgrpSeq(BigInteger jgrpSeq) {
        this.jgrpSeq = jgrpSeq;
    }

    public BigInteger getJgrpUpSeq() {
        return jgrpUpSeq;
    }

    public void setJgrpUpSeq(BigInteger jgrpUpSeq) {
        this.jgrpUpSeq = jgrpUpSeq;
    }

    public String getJgrpName() {
        return jgrpName;
    }

    public void setJgrpName(String jgrpName) {
        this.jgrpName = jgrpName;
    }

    public String getJgrpPetName() {
        return jgrpPetName;
    }

    public void setJgrpPetName(String jgrpPetName) {
        this.jgrpPetName = jgrpPetName;
    }

    public String getJgrpBuCd() {
        return jgrpBuCd;
    }

    public void setJgrpBuCd(String jgrpBuCd) {
        this.jgrpBuCd = jgrpBuCd;
    }

    public String getJgrpBuName() {
        return jgrpBuName;
    }

    public void setJgrpBuName(String jgrpBuName) {
        this.jgrpBuName = jgrpBuName;
    }

    public String getJgrpKaCd() {
        return jgrpKaCd;
    }

    public void setJgrpKaCd(String jgrpKaCd) {
        this.jgrpKaCd = jgrpKaCd;
    }

    public String getJgrpKaName() {
        return jgrpKaName;
    }

    public void setJgrpKaName(String jgrpKaName) {
        this.jgrpKaName = jgrpKaName;
    }

    public String getJgrpType() {
        return jgrpType;
    }

    public void setJgrpType(String jgrpType) {
        this.jgrpType = jgrpType;
    }

    public String getJgrpNote() {
        return jgrpNote;
    }

    public void setJgrpNote(String jgrpNote) {
        this.jgrpNote = jgrpNote;
    }

    public String getJgrpSts() {
        return jgrpSts;
    }

    public void setJgrpSts(String jgrpSts) {
        this.jgrpSts = jgrpSts;
    }

    public String getJgrpJobId() {
        return jgrpJobId;
    }

    public void setJgrpJobId(String jgrpJobId) {
        this.jgrpJobId = jgrpJobId;
    }

    public String getJgrpKbn() {
        return jgrpKbn;
    }

    public void setJgrpKbn(String jgrpKbn) {
        this.jgrpKbn = jgrpKbn;
    }

    public String getDeleteFlg() {
        return deleteFlg;
    }

    public void setDeleteFlg(String deleteFlg) {
        this.deleteFlg = deleteFlg;
    }

    public String getDeleteKbn() {
        return deleteKbn;
    }

    public void setDeleteKbn(String deleteKbn) {
        this.deleteKbn = deleteKbn;
    }

    public String getLockerUid() {
        return lockerUid;
    }

    public void setLockerUid(String lockerUid) {
        this.lockerUid = lockerUid;
    }

    public String getLocker() {
        return locker;
    }

    public void setLocker(String locker) {
        this.locker = locker;
    }

    public Date getInsertDate() {
        return insertDate;
    }

    public void setInsertDate(Date insertDate) {
        this.insertDate = insertDate;
    }

    public Date getUpdateDate() {
        return updateDate;
    }

    public void setUpdateDate(Date updateDate) {
        this.updateDate = updateDate;
    }

    public Date getDeleteDate() {
        return deleteDate;
    }

    public void setDeleteDate(Date deleteDate) {
        this.deleteDate = deleteDate;
    }

    public String getInserterUid() {
        return inserterUid;
    }

    public void setInserterUid(String inserterUid) {
        this.inserterUid = inserterUid;
    }

    public String getInserter() {
        return inserter;
    }

    public void setInserter(String inserter) {
        this.inserter = inserter;
    }

    public String getUpdaterUid() {
        return updaterUid;
    }

    public void setUpdaterUid(String updaterUid) {
        this.updaterUid = updaterUid;
    }

    public String getUpdater() {
        return updater;
    }

    public void setUpdater(String updater) {
        this.updater = updater;
    }

    public String getDeleterUid() {
        return deleterUid;
    }

    public void setDeleterUid(String deleterUid) {
        this.deleterUid = deleterUid;
    }

    public String getDeleter() {
        return deleter;
    }

    public void setDeleter(String deleter) {
        this.deleter = deleter;
    }

    public String getJgrpLevel() {
        return jgrpLevel;
    }

    public void setJgrpLevel(String jgrpLevel) {
        this.jgrpLevel = jgrpLevel;
    }

}
