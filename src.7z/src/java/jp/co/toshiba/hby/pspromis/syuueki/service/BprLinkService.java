package jp.co.toshiba.hby.pspromis.syuueki.service;

import java.io.UnsupportedEncodingException;
import java.util.List;
import java.util.HashMap;
import java.util.Map;
import java.math.BigDecimal;
import javax.ejb.Stateless;
import javax.inject.Inject;
import javax.interceptor.Interceptors;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import jp.co.toshiba.hby.pspromis.syuueki.bean.BprLinkBean;
import jp.co.toshiba.hby.pspromis.syuueki.entity.SyuGeBukkenInfoTbl;
import jp.co.toshiba.hby.pspromis.syuueki.enums.Env;
import jp.co.toshiba.hby.pspromis.syuueki.facade.SyuGeBukenInfoTblFacade;
import jp.co.toshiba.hby.pspromis.syuueki.facade.KanjyoMstFacade;
import jp.co.toshiba.hby.pspromis.syuueki.interceptor.TranceInterceptor;
import jp.co.toshiba.hby.pspromis.syuueki.jdbc.DbUtilsExecutor;
import jp.co.toshiba.hby.pspromis.syuueki.jdbc.SqlFile;
import jp.co.toshiba.hby.pspromis.syuueki.util.UrlParamUtils;
import jp.co.toshiba.hby.pspromis.syuueki.util.LoginUserInfo;
import jp.co.toshiba.hby.pspromis.syuueki.util.ConstantString;
import jp.co.toshiba.hby.pspromis.syuueki.util.AuthorityUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.collections.CollectionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * (原子力)関連システムのリンク作成サービス
 * @author ibayashi
 */
@Stateless
@Interceptors({TranceInterceptor.class})
public class BprLinkService {

    public static final Logger log = LoggerFactory.getLogger(BprLinkService.class);
    
    @PersistenceContext(unitName = jp.co.toshiba.hby.pspromis.syuueki.util.ConstantString.syuuekiDataSourceName)
    private EntityManager em;
    
    @Inject
    private LoginUserInfo loginUserInfo;
    
    @Inject
    private BprLinkBean bprLinkBean;
    
    @Inject
    private KanjyoMstFacade kanjyoMstFacade;
    
    @Inject
    private DbUtilsExecutor dbUtilsExecutor;
    
    @Inject
    private AuthorityUtils authorityUtils;

    @Inject
    private SyuGeBukenInfoTblFacade syuGeBukenInfoTblFacade;

    /**
     * 各ボタンの表示判断
     */
    public void executeDispButton() throws Exception {
        // 案件の基本情報を取得
        SyuGeBukkenInfoTbl ankenInfo = getAnkenEntiy();

        // 決裁/見積情報ボタン
        dispButtonKessaiEst(ankenInfo);

        // ecas決裁情報ボタン
        dispButtonEcasKessai(ankenInfo);
        
        // (原子力)収支表ボタン
        dispButtonShushi(ankenInfo);
 
        // (原子力)売上指示ボタン
        dispButtonUriageShihi(ankenInfo);
        
        // (原子力)発番連携ボタン
        dispButtonHatRenkei(ankenInfo);
    }
    
    /**
     * 決裁/見積情報ボタン 表示判断
     */
    private void dispButtonKessaiEst(SyuGeBukkenInfoTbl ankenInfo) {
        // 画面の権限による表示判断
        if (isAuthKessaiEst(ankenInfo)) {
            bprLinkBean.setKessaiEstButton(true);
        }
    }

    /**
     * ecas決裁情報ボタン 表示判断
     */
    private void dispButtonEcasKessai(SyuGeBukkenInfoTbl ankenInfo) {
        String kessaiId = ankenInfo.getKessaiId();
        String spurtNo  = ankenInfo.getSpurtNo();

        // 画面の権限による表示判断
        if (isAuthEcas(ankenInfo)) {
            // データによる表示判断
            //if (StringUtils.isNotEmpty(kessaiId) && StringUtils.isNotEmpty(spurtNo)) {
                bprLinkBean.setEcasKessaiButton(true);
            //}
        }
    }

    /**
     * (原子力)収支表ボタン 表示判断
     */
    private void dispButtonShushi(SyuGeBukkenInfoTbl ankenInfo) {
        String oldTAnkenNo = ankenInfo.getOldTAnkenNo();
        String salesClass = ankenInfo.getSalesClass();
        String ankenFlg = ankenInfo.getAnkenFlg();

        // 画面の権限による表示判断
        if (isAuthSyushi(ankenInfo)) {
            // データによる表示判断(進行基準まとめ案件(SALES_CLASS=1 and ANKEN_FLG=1)以外は表示する)
            if (StringUtils.isNotEmpty(oldTAnkenNo) && !(ConstantString.salesClassS.equals(salesClass) && "1".equals(ankenFlg))) {
                bprLinkBean.setSyushiButton(true);
            }
        }

    }

    /**
     * (原子力)売上指示ボタン 表示判断
     */
    private void dispButtonUriageShihi(SyuGeBukkenInfoTbl ankenInfo) {
        String mitsumoriKbnSeiTehai = StringUtils.defaultString(Env.Mitumori_Seitehai.getValue());
        
        String oldTAnkenNo = ankenInfo.getOldTAnkenNo();
        String salesClass = ankenInfo.getSalesClass();
        String mitsumoriKbn = ankenInfo.getMitumoriKbn();
        String ankenFlg = ankenInfo.getAnkenFlg();

        // 画面の権限による表示判断
        if (isAuthUrishiji(ankenInfo)) {
            // データによる表示判断(進行基準まとめ案件(SALES_CLASS=1 and ANKEN_FLG=1)は非表示にする)
            if (StringUtils.isNotEmpty(oldTAnkenNo) && !(ConstantString.salesClassS.equals(salesClass) && "1".equals(ankenFlg)) && mitsumoriKbnSeiTehai.equals(mitsumoriKbn)) {
                bprLinkBean.setUriageShijiButton(true);
            }
        }

    }

    /**
     * (原子力)発番連携ボタン 表示判断
     */
    private void dispButtonHatRenkei(SyuGeBukkenInfoTbl ankenInfo) {
        String orderNo = getAnkenOrderNo(ankenInfo);
        //String salesClass = ankenInfo.getSalesClass();
        // 画面の権限による表示判断
        if (isAuthHatRenkei(ankenInfo)) {
            // データによる表示判断(2017B 一般,進行基準案件関係なくリンクできるようにする)
            //if (StringUtils.isNotEmpty(orderNo) && !ConstantString.salesClassS.equals(salesClass)) {
            if (StringUtils.isNotEmpty(orderNo)) {
                bprLinkBean.setHatRenkeiButton(true);
            }
        }
    }

    /**
     * 対象URLの取得
     */
    public void indexGetUrl() throws Exception {
        log.info("indexGetUrl params={}", bprLinkBean.toString());
        
        String targetUrl = "";

        switch(bprLinkBean.getLinkKbn()) {
            case "ecasKessai":
                targetUrl = getEcasLink();
                break;
            case "hatKaniItem":
                targetUrl = getHatSysLink();
                break;
            case "syuSyushi":
                targetUrl = getSyuSyushiLink();
                break;
            case "syuUriSjiji":
                targetUrl = getSyuUriShijiLink();
                break;
        }

        bprLinkBean.setTargetUrl(targetUrl);
    }
    
    /**
     * (原子力)ecAsリンク作成
     */
    private String getEcasLink() throws Exception {
        SyuGeBukkenInfoTbl ankenInfo = getAnkenEntiy();
        
        String mitYosan = StringUtils.defaultString(Env.Mitumori_Yosan.getValue());
        String mitTehai = StringUtils.defaultString(Env.Mitumori_Tehai.getValue());
        String mitSei = StringUtils.defaultString(Env.Mitumori_Sei.getValue());
        String mitSeiTehai = StringUtils.defaultString(Env.Mitumori_Seitehai.getValue());

        // 見積区分をecAs用に変換
        String mitsumoriKbn = StringUtils.defaultString(ankenInfo.getMitumoriKbn());
        String ecasMitumoriKbn = "";
        if (mitYosan.equals(mitsumoriKbn) || mitTehai.equals(mitsumoriKbn)) {
            ecasMitumoriKbn = mitYosan;
        } else if (mitSei.equals(mitsumoriKbn) || mitSeiTehai.equals(mitsumoriKbn)) {
            ecasMitumoriKbn = mitSei;
        }

        // ecAs URLを取得
        String redirectUrl = StringUtils.defaultString(Env.bprEcasKessaiUrl.getValue());
        redirectUrl = replaceAnkenBaseParameter(redirectUrl, ankenInfo);
        redirectUrl = StringUtils.replace(redirectUrl, "#MITSUMORI_KBN#", ecasMitumoriKbn);
        log.info("BPR ecAs Kessai URL=[{}]", redirectUrl);

        // 共通認証URLを取得
        String targetUrl = changeAuthUrl(redirectUrl);

        return targetUrl;
    }

    /**
     * (原子力)発番連携リンク作成
     */
    private String getHatSysLink() throws Exception {
        SyuGeBukkenInfoTbl ankenInfo = getAnkenEntiy();

        // 発番連携URLを取得
        String redirectUrl = StringUtils.defaultString(Env.bprHatKaniItemUrl.getValue());
        redirectUrl = replaceAnkenBaseParameter(redirectUrl, ankenInfo);
        log.info("BPR hat KaniItem URL=[{}]", redirectUrl);

        // 共通認証URLを取得
        String targetUrl = changeAuthUrl(redirectUrl);

        return targetUrl;
    }

    /**
     * (原子力)収益管理システム 収益収支表リンク作成
     */
    private String getSyuSyushiLink() throws Exception {
        SyuGeBukkenInfoTbl ankenInfo = getAnkenEntiy();

        // 発番連携URLを取得
        String redirectUrl = StringUtils.defaultString(Env.bprSyuSyushiUrl.getValue());
        redirectUrl = replaceAnkenBaseParameter(redirectUrl, ankenInfo);
        
        String linkSyokusyu = getNucSyuuekiSyokusyu();
        redirectUrl = StringUtils.replace(redirectUrl, "#SYOKUSYU#", linkSyokusyu);
        
        log.info("BPR syushi URL=[{}]", redirectUrl);

        // 共通認証URLを取得
        String targetUrl = changeAuthUrl(redirectUrl);

        return targetUrl;
    }
    
    /**
     * (原子力)収益管理システム 売上指示画面リンク作成
     */
    private String getSyuUriShijiLink() throws Exception {
        SyuGeBukkenInfoTbl ankenInfo = getAnkenEntiy();
        String errorMessage = "対象の売上指示情報が取得できないので、画面の表示はできませんでした。";
        
        // 売上指示画面URLを取得
        String redirectUrl = StringUtils.defaultString(Env.bprSyuUriShijiUrl.getValue());
        redirectUrl = replaceAnkenBaseParameter(redirectUrl, ankenInfo);
        
        // 連携対象の売上年月を取得
        String uriShijiYm = getUriShijiYm(ankenInfo);
        if (StringUtils.isEmpty(uriShijiYm)) {
            log.info("no data link uriageYm");
            bprLinkBean.setErrorMessage(errorMessage);
        } else {
            setUriageSeq(uriShijiYm, ankenInfo);
            if (bprLinkBean.getUriageSeq() == null) {
                log.info("no data nuclear-syuueki uriageYm");
                bprLinkBean.setErrorMessage(errorMessage);
            } else {
                String linkSyokusyu = getNucSyuuekiSyokusyu();
                log.info("nuclear-syuueki uriageShiji keiyakuSeq=[{}] uriageSeq=[{}] syokusyu=[{}]", bprLinkBean.getKeiyakuSeq(), bprLinkBean.getUriageSeq(), linkSyokusyu);
                redirectUrl = StringUtils.replace(redirectUrl, "#KEIYAKU_SEQ#", (bprLinkBean.getKeiyakuSeq()).toString());
                redirectUrl = StringUtils.replace(redirectUrl, "#URIAGE_SEQ#", (bprLinkBean.getUriageSeq()).toString());
                redirectUrl = StringUtils.replace(redirectUrl, "#SYOKUSYU#", linkSyokusyu);
            }
        }

        log.info("BPR uriSjiji URL=[{}]", redirectUrl);
        
        // 共通認証URLを取得
        String targetUrl = changeAuthUrl(redirectUrl);

        return targetUrl;
    }

    /**
     * (原子力)収益管理を開くときの職種権限を取得
     */
    private String getNucSyuuekiSyokusyu() {
        String linkSyokusyu = "";
        // ログイン者の所属JobGrの職種を全て取得
        String[] syokusyuCdAry =  loginUserInfo.getJobGrSyokusyuArrayInfo("syokusyuCd");
        
        if (syokusyuCdAry != null) {
            // 職種は[営業/原価/企画 ← 調達 ← 設計]の優先順位で取得する
            for (String syokusyu: syokusyuCdAry) {
                // 営業(L) or 原価(M) or 企画(K)の何れかの権限は、職種を渡さないようにする
                // ※(原子力)収益のリンク先は、職種を何も渡さないと(営業/原価/企画)の権限チェックを行うようになっている
                if ("L".equals(syokusyu) || "M".equals(syokusyu) || "K".equals(syokusyu)) {
                    linkSyokusyu = "";
                    break;
                }

                // 既に調達(C)職種の権限があるが、設計(E)権限も兼務している場合、設計権限を上書きしない
                if ("C".equals(linkSyokusyu) && "E".equals(syokusyu)) {
                    continue;
                }

                linkSyokusyu = syokusyu;
            }
        }

        log.info("(原子力)収益リンク 職種=[{}]", linkSyokusyu);
        return linkSyokusyu;
    }

    /**
     * 案件各種情報からパラメータ部分を置換
     */
    private String replaceAnkenBaseParameter(String baseUrl, SyuGeBukkenInfoTbl ankenInfo) {
        String url = baseUrl;
        String orderNo = getAnkenOrderNo(ankenInfo);

        url = StringUtils.replace(url, "#SPURT_NO#", StringUtils.defaultString(ankenInfo.getSpurtNo()));
        url = StringUtils.replace(url, "#BUKKEN_ID#", StringUtils.defaultString(ankenInfo.getOldTAnkenNo()));
        url = StringUtils.replace(url, "#ORDER_NO#", orderNo);

        return url;
    }
    
    /**
     * 共通認証URLに変換を行う
     */
    private String changeAuthUrl(String targetUrl) throws UnsupportedEncodingException {
        String authUrl = StringUtils.defaultString(Env.bprAuthenticationUrl.getValue());
        log.info("BPR Authentication URL=[{}]", authUrl);

        String resultUrl = authUrl;
        resultUrl = StringUtils.replace(resultUrl, "#SESSION_ID#", loginUserInfo.getSessionId());
        resultUrl = StringUtils.replace(resultUrl, "#REDIRECT_URL#", UrlParamUtils.encodeUrl(targetUrl));

        log.info("Call URL=[{}]", resultUrl);

        return resultUrl;
    }

    /**
     * 案件情報の取得
     */
    private SyuGeBukkenInfoTbl getAnkenEntiy() {
        Map<String, Object> condition = getBaseCondition();
        SyuGeBukkenInfoTbl geEntity = syuGeBukenInfoTblFacade.findPk(condition);
        return geEntity;
    }
    
    /**
     * ベースの条件を作成
     */
    private Map<String, Object> getBaseCondition() {
        Map<String, Object> condition = new HashMap<>();
        condition.put("ankenId", bprLinkBean.getAnkenId());
        condition.put("rirekiId", Integer.parseInt(ConstantString.geRirekiId));
        return condition;
    }
    
    /**
     * (売上指示画面用)対象の売上年月を取得
     */
    private String getUriShijiYm(SyuGeBukkenInfoTbl ankenInfo) throws Exception {
        String uriShijiYm = "";
        SqlFile sqlFile = new SqlFile();
        
        // SQLファイルの取得
        String splFilePath = "/sql/bprLink/selectSyuUriLinkYm.sql";
        log.info("[getUriShijiYm] SQL_SELECT_FILE=[{}]", splFilePath);
        
        String kanjyoYm = kanjyoMstFacade.getNowKanjoDate(ankenInfo.getSalesClass());
        
        // パラメータを作成
        //Map<String, Object> condition = getBaseCondition();
        Map<String, Object> condition = new HashMap<>();
        condition.put("bukkenId", ankenInfo.getOldTAnkenNo());
        condition.put("kanjyoYm", kanjyoYm);

        String sqlString = sqlFile.getSqlString(splFilePath, condition);
        Object[] sqlParams = sqlFile.getSqlParams(splFilePath, condition);

        // SQLを実行(Commons DbUtilで実行)
        List<Map<String, Object>> list = dbUtilsExecutor.dbUtilsGetSqlList(em, sqlString, sqlParams);
        if (CollectionUtils.isNotEmpty(list)) {
            Map<String, Object> info = list.get(0);
            for (int i=1; i<=5; i++) {
                uriShijiYm = (String)(info.get("SYUEKI_YM" + i));
                if (StringUtils.isNotEmpty(uriShijiYm)) {
                    break;
                }
            }
        }

        // (2017B)Promis収益から売上年月を特定できない場合、(原子力)収益の最新売上年月を対象にする
        log.info("[getUriShijiYm] uriShijiYm=[{}]", uriShijiYm);
//        boolean isUriShijiYm = false;
//        if (StringUtils.isNotEmpty(uriShijiYm)) {
//            isUriShijiYm = isCheckNucUriageYm(ankenInfo, uriShijiYm);
//        }
//        if (!isUriShijiYm) {
//            uriShijiYm = getNucNewestUriageYm(ankenInfo);
//        }

        return uriShijiYm;
    }

    /**
     * (売上指示画面用)対象の売上年月が実際に(原子力)収益に存在するかをチェック
     */
//    private boolean isCheckNucUriageYm(SyuGeBukkenInfoTbl ankenInfo, String uriageYm) throws Exception {
//        SqlFile sqlFile = new SqlFile();
//        
//        // SQLファイルの取得
//        String splFilePath = "/sql/bprLink/selectNucCheckUriageYm.sql";
//        log.info("[isCheckNucUriageYm] SQL_SELECT_FILE=[{}]", splFilePath);
//        
//        // パラメータを作成
//        Map<String, Object> condition = new HashMap<>();
//        condition.put("bukkenId", ankenInfo.getOldTAnkenNo());
//        condition.put("uriagetuki", uriageYm);
//        
//        String sqlString = sqlFile.getSqlString(splFilePath, condition);
//        Object[] sqlParams = sqlFile.getSqlParams(splFilePath, condition);
//        
//        List<Map<String, Object>> list = dbUtilsExecutor.dbUtilsGetSqlList(em, sqlString, sqlParams);
//        Map<String, Object> info = list.get(0);
//        BigDecimal count = (BigDecimal)info.get("COUNT");
//        
//        if (count.intValue() > 0) {
//            return true;
//        } else {
//            return false;
//        }
//    }
    
    /**
     * (売上指示画面用)対象の売上年月を取得(原子力収益の最新売上年月)
     */
//    private String getNucNewestUriageYm(SyuGeBukkenInfoTbl ankenInfo) throws Exception {
//        String uriShijiYm = "";
//        SqlFile sqlFile = new SqlFile();
//        
//        // SQLファイルの取得
//        String splFilePath = "/sql/bprLink/selectNucNewestUriageYm.sql";
//        log.info("[getNucNewestUriageYm] SQL_SELECT_FILE=[{}]", splFilePath);
//        
//        // パラメータを作成
//        Map<String, Object> condition = new HashMap<>();
//        condition.put("bukkenId", ankenInfo.getOldTAnkenNo());
//        
//        String sqlString = sqlFile.getSqlString(splFilePath, condition);
//        Object[] sqlParams = sqlFile.getSqlParams(splFilePath, condition);
//        
//        List<Map<String, Object>> list = dbUtilsExecutor.dbUtilsGetSqlList(em, sqlString, sqlParams);
//        if (CollectionUtils.isNotEmpty(list)) {
//            Map<String, Object> info = list.get(0);
//            Object urishijiObj = info.get("URIAGETUKI");
//            if (urishijiObj != null) {
//                uriShijiYm = StringUtils.defaultString((String)urishijiObj);
//            }
//        }
//
//        return uriShijiYm;
//    }

    /**
     * (売上指示画面用)対象の売上年月を取得
     */
    private void setUriageSeq(String uriShijiYm, SyuGeBukkenInfoTbl ankenInfo) throws Exception {
        SqlFile sqlFile = new SqlFile();
        
        // SQLファイルの取得
        String splFilePath = "/sql/bprLink/selectNucUriageSeq.sql";
        log.info("[findMainList] SQL_SELECT_FILE=[{}]", splFilePath);
        
        // パラメータを作成
        Map<String, Object> condition = new HashMap<>();
        condition.put("bukkenId", ankenInfo.getOldTAnkenNo());
        condition.put("uriagetuki", uriShijiYm);

        String sqlString = sqlFile.getSqlString(splFilePath, condition);
        Object[] sqlParams = sqlFile.getSqlParams(splFilePath, condition);
        
        // SQLを実行(Commons DbUtilで実行)
        List<Map<String, Object>> list = dbUtilsExecutor.dbUtilsGetSqlList(em, sqlString, sqlParams);
        if (CollectionUtils.isNotEmpty(list)) {
            Map<String, Object> info = list.get(0);
            if (info.get("URIAGE_SEQ") != null) {
                BigDecimal uriageSeq = (BigDecimal)info.get("URIAGE_SEQ");
                BigDecimal keiyakuSeq = (BigDecimal)info.get("KEIYAKU_SEQ");

                bprLinkBean.setUriageSeq(uriageSeq);
                bprLinkBean.setKeiyakuSeq(keiyakuSeq);
            }
        }

    }

    /**
     * 決裁/見積情報ボタン 権限マスタによるボタン表示制御
     */
    private boolean isAuthKessaiEst(SyuGeBukkenInfoTbl ankenInfo) {
        boolean isDisp = false;
        String funcCd = getFuncCdHead() + "ecAs";
        int authFlg = authorityUtils.enableFlg(funcCd, ankenInfo.getDivisionCode(), bprLinkBean.getRirekiFlg());
        if (authFlg == 1) {
            isDisp = true;
        }
        log.info("kessaiEst Button funcCd=[{}] divisionCode=[{}] rirekiFlg=[{}] authFlg=[{}]", funcCd, ankenInfo.getDivisionCode(), bprLinkBean.getRirekiFlg(), authFlg);
        return isDisp;
    }

    /**
     * ecAs決裁情報ボタン 権限マスタによるボタン表示制御
     */
    private boolean isAuthEcas(SyuGeBukkenInfoTbl ankenInfo) {
        boolean isDisp = false;
        String funcCd = getFuncCdHead() + "ecAs";
        int authFlg = authorityUtils.enableFlg(funcCd, ankenInfo.getDivisionCode(), bprLinkBean.getRirekiFlg());
        if (authFlg == 1) {
            isDisp = true;
        }
        log.info("ecas Button funcCd=[{}] divisionCode=[{}] rirekiFlg=[{}] authFlg=[{}]", funcCd, ankenInfo.getDivisionCode(), bprLinkBean.getRirekiFlg(), authFlg);
        return isDisp;
    }
    
    /**
     * (原子力)収支表ボタン 権限マスタによるボタン表示制御
     */
    private boolean isAuthSyushi(SyuGeBukkenInfoTbl ankenInfo) {
        boolean isDisp = false;
        String funcCd = getFuncCdHead() + "SYUSHI";
        int authFlg = authorityUtils.enableFlg(funcCd, ankenInfo.getDivisionCode(), bprLinkBean.getRirekiFlg());
        if (authFlg == 1) {
            isDisp = true;
        }
        log.info("ecas Button funcCd=[{}] divisionCode=[{}] rirekiFlg=[{}] authFlg=[{}]", funcCd, ankenInfo.getDivisionCode(), bprLinkBean.getRirekiFlg(), authFlg);
        return isDisp;
    }
    
    /**
     * (原子力)売上指示ボタン 権限マスタによるボタン表示制御
     */
    private boolean isAuthUrishiji(SyuGeBukkenInfoTbl ankenInfo) {
        boolean isDisp = false;
        String funcCd = getFuncCdHead() + "URIAGE";
        int authFlg = authorityUtils.enableFlg(funcCd, ankenInfo.getDivisionCode(), bprLinkBean.getRirekiFlg());
        if (authFlg == 1) {
            isDisp = true;
        }
        log.info("ecas Button funcCd=[{}] divisionCode=[{}] rirekiFlg=[{}] authFlg=[{}]", funcCd, ankenInfo.getDivisionCode(), bprLinkBean.getRirekiFlg(), authFlg);
        return isDisp;
    }
    
    /**
     * （原子力）発番連携ボタン 権限マスタによるボタン表示制御
     */
    private boolean isAuthHatRenkei(SyuGeBukkenInfoTbl ankenInfo) {
        boolean isDisp = false;
        String funcCd = getFuncCdHead() + "HAT";
        int authFlg = authorityUtils.enableFlg(funcCd, ankenInfo.getDivisionCode(), bprLinkBean.getRirekiFlg());
        if (authFlg == 1) {
            isDisp = true;
        }
        log.info("hatRenkei Button funcCd=[{}] divisionCode=[{}] rirekiFlg=[{}] authFlg=[{}]", funcCd, ankenInfo.getDivisionCode(), bprLinkBean.getRirekiFlg(), authFlg);
        return isDisp;
    }

    /**
     * 画面IDによるボタン権限マスタ機能コード(FUNC_CD)の頭文字を取得
     */
    private String getFuncCdHead() {
        String procId = StringUtils.defaultString(bprLinkBean.getProcId());
        String funcCdHead = "";

        switch(procId) {
            case "S002":    // 最終見込損益
                funcCdHead = "SAISYU_";
                break;
            case "S003":    // 期間損益(一般)
                funcCdHead = "KIKAN_I_";
                break;
            case "S004":    // 期間損益(進行)
                funcCdHead = "KIKAN_S_";
                break;
            case "S005_K":  // 項番一覧(期間)
                funcCdHead = "KIKAN_ITEM_";
                break;
            case "S005_S":  // 項番一覧(最終)
                funcCdHead = "SAISYU_ITEM_";
                break;
        }
        
        return funcCdHead;
    }

    /**
     * 対象案件の注番を取得
     */
    private String getAnkenOrderNo(SyuGeBukkenInfoTbl ankenInfo) {
        String orderNo = "";
        String ankenFlg = StringUtils.defaultString(ankenInfo.getAnkenFlg());
        // まとめ案件は代表注番をリンク
        if ("1".equals(ankenFlg)) {
            orderNo = StringUtils.defaultString(ankenInfo.getMainOrderNo());
        } else {
            orderNo = StringUtils.defaultString(ankenInfo.getOrderNo());
        }
        return orderNo;
    }
 
}
