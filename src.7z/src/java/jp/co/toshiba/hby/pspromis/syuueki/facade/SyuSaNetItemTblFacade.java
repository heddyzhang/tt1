/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package jp.co.toshiba.hby.pspromis.syuueki.facade;

import java.util.Map;
import javax.ejb.Stateless;
import javax.interceptor.Interceptors;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import jp.co.toshiba.hby.pspromis.syuueki.entity.SyuSaNetItemTbl;
import jp.co.toshiba.hby.pspromis.syuueki.interceptor.TranceInterceptor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 *
 * @author rnomura
 */
@Stateless
@Interceptors({TranceInterceptor.class})
public class SyuSaNetItemTblFacade extends AbstractFacade<SyuSaNetItemTbl> {

    @PersistenceContext(unitName = jp.co.toshiba.hby.pspromis.syuueki.util.ConstantString.syuuekiDataSourceName)
    private EntityManager em;

    @Override
    protected EntityManager getEntityManager() {
        return em;
    }

    public SyuSaNetItemTblFacade() {
        super(SyuSaNetItemTbl.class);
    }
    
    /**
     * 項番一覧(期間)保存処理(最新見込)
     * @param condition
     */
    public void updateSeibanSyuSaNetItem(Map<String, Object> condition) {
        // 更新
        int count = sqlExecutor.executeUpdateSql(em, "/sql/S005/updateSeibanSyuSaNetItem.sql", condition);

    }
    
    /**
     * 見込項番削除処理
     * @param condition
     */
    public void deleteKobanSyuSaNetItem(Map<String, Object> condition){
        // 削除
        int count = sqlExecutor.executeUpdateSql(em, "/sql/S005/deleteKobanSyuSaNetItem.sql", condition);
    }
    
    /**
     * 項番一覧(最終)　更新処理
     * @param condition
     */
    public int updateNetItem(Map<String, Object> condition){
        // 更新
        int count = sqlExecutor.executeUpdateSql(em, "/sql/syuSaNetItemTbl/updateNetItem.sql", condition);
    
        return count;
    }
    
    /**
     * 項番一覧(最終)　更新処理
     * @param condition
     */
    public void insertNetItem(Map<String, Object> condition){
        // 更新
        int count = sqlExecutor.executeUpdateSql(em, "/sql/syuSaNetItemTbl/insertNetItem.sql", condition);

    }
    
}
