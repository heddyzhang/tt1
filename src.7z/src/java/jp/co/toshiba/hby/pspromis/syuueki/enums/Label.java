package jp.co.toshiba.hby.pspromis.syuueki.enums;

import java.util.ResourceBundle;
import org.apache.commons.lang3.StringUtils;
/**
 * プロパティファイル(appLabel)のキーを定義
 * @author ibayashi
 */
public enum Label {
    nendo, kai, shinko, ippan, hikiwatashi, unitLabel, jpyUnitLabel, jpyUnit1, jpyUnit2, jpyUnit3, last, mikomi, jisseki,
    ankenCode, oNo, oNoRyaku, mitsumoriNo, mitsumoriNoRyaku, ankenName, plantStchName, subBu,
    eigyoJobGroupId2, jisshiNendo, kaisu, uriageKijun, uriageYotei, keiyakuSp, uriageNet, arari, mrate,
    outputName, outputDate, now, before, history, month, firstHalf, secondHalf, estimateCost, kawase, uriageAmount,
    recoveryAmount, notRecoveryAmount, ruikeiRecoveryAmount, ki, lastMikomi, total, befDiff, diff, enka, keiyakuJisseki, hatsubanJisseki,
    hanchoku, hankan, keihi, sougenka, isp, kawaseYoyaku, seibanSoneki, keijoSoneki, keijoSonekiRate, matomeAnken, firstMikomi, monthlyRate, keiyakuTime,
    sp1, ros, s002RateListTitle, pj, yochu, seiban, uriageEndFlg, giBukacd, sekkeiBukaCd, hinmei, dispContent, hatyuInfo, zan, genjoHatsuban, tanki, hatyu,
    hatyuForeignUnitLabel, currency, rate, cyunyuRuikei, uriageRuikei ,end, koban, chunyu, uriage, errorNoAnkenDate, alertNoSyuueki, errorKanjoDate,
    errorNoAnkenAuthority, uriageYoteiYm, teiken, tatene, hatsubanNet, miHatsubanNet, kawaseEikyo, seibanSonekiNet, kawaseRate, kawaseDiff, hosei, hatsuban,hanei,
    uploadKbnLabelKeihin, uploadKbnLabelFu, uploadKbnLabelHama, uploadKbnLabelMi, uploadKbnLabelIsp, uploadKbnLabelChokka, uploadKbnLabelEtc1,
    uploadKbnLabelHanchoku, uploadKbnLabelBaihatsu, selMenu, uriageStartYm, shinkoLabelShort, uriageKbn, uriageYoteiListLbl,
    uriageEndFlg1, uriageEndFlg2, uriageEndFlg3, uriageEndFlg4,kanrenOrderNo, seibanSonekiRuikei, jissekiRuikei, year, statusCreating, statusFixed,
    fixedYm, confirmFixedMessage, confirmFixedReleaseMessage, mikomiRateType, ruikei2, uploadKbnLabelKikanShinko, daihyoOrderNo ,zenkiruikei,
    downloadSaishumikomisonekiName, mokuhyo, jyusei, jyuchu, mit, sp, net, yosan, monthly, juchuYm, forwardTermYm, recoveryYoteiYm, taishoYm2, taisho,
    toriatsuCd, tradeName, stchName, salesTeam, salesCSE, seizouTeam, seizouCSE, sn, hatsubanBracketed, recoveryYm, headOfficeBuka, salesC, keiyaku,
    foreignUnitLabel, juchuRate, uriageRate, jyuchuYm, uriageYm, ruikei, renban, chukei, biko, eigyoSectionName, tantosyaName, subBuCode, subBuName,
    plantCode, syuuekiBunrui, toriatsuCd2, businessCategory, salesEmC, salesEmS, salesEmE, seizouEmC, seizouEmS, seizouEmE, sHatsuban, nHatsuban, tenkai,unitCaution,
    split, errorPluralAnken, outputFormSaisyu, outputFormKikan, outputFormKoban, excelSheetLast, excelSheetKikan, excelSheetKoban, yosanTehai2, seishiki, seishikiTehai2,
    mitumoriKbn, anken, rank, ankenJyokyoMondai, choka, mondai, important, ari, fixedLabel, yosanTehai3, seishikiTehai,ispKbn0,ispKbn1,ispKbn2,currentValue, previousValue,
    bracketStart, bracketEnd, recoveryYm2, documentName, urlName, fileName, errorKobanExists, validKoban, fixed, noFixed, labelKari, labelZiten, labelBefFixedNet,
    dispNameAddSearchPattern, dispNameFinishingSearchPattern, patternName, division, ispKbn, ispRelateId, setuBunrui, noki, chunyuStartYm, kensyutuki,
    labelCategory1, errorCategoryOverlap, errorCategoryExists, alertNoAuthSyuekiFlgEdit, alertNoAuthSyuekiFlgRel, alertOnlyOneOrderNoSyuekiFlgEdit,
    alertRequiredOneSyuekiFlg, alertMatomeAnkenSyuekiFlgRel, kobanMikomi, statusTeishutsu, dispNameWfCommentS, dispNameWfCommentH, dispNameWfCommentTS, dispNameWfCommentTH,
    confirmTeishutsuMessage, confirmTeishutsuReleaseMessage, kaisyu, diff2, secondary, countingUnit, yokozikuAggregate, outputItem, taishoData, kagetu, kibun, nendobun,
    grandTotal, errorSetSyuekiFlgIppan, errorSetSyuekiFlgIppanNuclearRenkei, errorSetSyuekiFlgMatome, errorClearSyuekiFlgIppan, errorClearSyuekiFlgMatome,
    successSetSyuekiFlgIppan, successSetSyuekiFlgIppanClear, successSetSyuekiFlgMatome, successClearSyuekiFlgIppan, successClearSyuekiFlgMatome,genkin,tegata,maeuke,normal,taxRate,kinsyu,
    alreadySyuekiFlg,alreadyNoSyuekiFlg,category,errorSetSyuekiFlgMatomeNuclearRenkei,errorSetSyuekiFlgRecalMatome,errorSetSyuekiFlgRecalIppan,ankenJyokyoMondaiComment,
    hatJuchuYm,hatForwardTermYm,hatUriageYotei,hatRecoveryYoteiYm,syuJuchuYm,syuUriageYotei,syuRecoveryYm2,
    errorAlreadyNucUriSiji,kaisyuYm,toriatsuTyoku,kansei,kaisyuZeiKomi
    ,genkaLabelShort,genkaLabel,genkaShinkoLabelShort
    ;

    private static String getLabelValue(String key) {
        ResourceBundle rb = ResourceBundle.getBundle("label.appLabel");
        String value = rb.getString(key);
        return value;
    }

    /**
     * プロパティファイルの取得
     *
     * @return
     */
    public String getLabel() {
        return getLabelValue(this.toString());
    }

    /**
     * プロパティファイルの取得
     * @param label
     * @return
     */
    public static String getValue(Label label) {
        return getLabelValue(label.name());
    }

    public String getMessage(Object... changeValues) {
        String message = getLabel();
        if (changeValues != null && changeValues.length > 0) {
            int no = 0;
            for (Object changeValue : changeValues) {
                String sChangeValue = "";
                if (changeValue != null) {
                    sChangeValue = String.valueOf(changeValue);
                }
                message = StringUtils.replace(message, "{" + no + "}", sChangeValue);
                message = StringUtils.replace(message, "#" + no + "#", sChangeValue);
                no++;
            }
        }
        return message;
    }

}
