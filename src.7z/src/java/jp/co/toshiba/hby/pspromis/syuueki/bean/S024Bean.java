/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package jp.co.toshiba.hby.pspromis.syuueki.bean;

import java.util.List;
import java.util.Map;
import javax.inject.Named;
import javax.enterprise.context.RequestScoped;
import jp.co.toshiba.hby.pspromis.syuueki.entity.SyuCurMst;
import jp.co.toshiba.hby.pspromis.syuueki.entity.SyuKiKaisyuTblView;
import jp.co.toshiba.hby.pspromis.syuueki.entity.SyuZeikbnMst;
import lombok.Getter;
import lombok.Setter;

/**
 *
 * @author ibayashi
 */
@Named(value = "s024Bean")
@RequestScoped
@Getter @Setter
public class S024Bean extends AbstractBean {

    /**
     * 処理元の画面ID(操作ログの登録で利用)
     */
    private String procId;
    
    /**
     * 回収情報の画面データ
     */
    private List<Map<String, Object>> kaisyuList;
    
    /**
     * 回収情報の一覧取得データ
     */
    private List<SyuKiKaisyuTblView> dataList;

    /**
     * 削除指定したデータ行のindex
     */
    private String[] delIndexs;
    
    /**
     *  通貨セレクトボックス候補
     */
    private List<SyuCurMst> currencyCodeList;
    
    /**
     *  税区分選択候補
     */
    private List<SyuZeikbnMst> zeiKbnList;
}
