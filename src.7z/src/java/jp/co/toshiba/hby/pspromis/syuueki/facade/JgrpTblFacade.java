/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package jp.co.toshiba.hby.pspromis.syuueki.facade;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.ejb.Stateless;
import javax.interceptor.Interceptors;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import jp.co.toshiba.hby.pspromis.syuueki.entity.JgrpMemberTbl;
import jp.co.toshiba.hby.pspromis.syuueki.entity.JgrpTbl;
import jp.co.toshiba.hby.pspromis.syuueki.interceptor.TranceInterceptor;

/**
 *
 * @author ibayashi
 */
@Stateless
@Interceptors({TranceInterceptor.class})
public class JgrpTblFacade extends AbstractFacade<JgrpTbl> {

    @PersistenceContext(unitName = jp.co.toshiba.hby.pspromis.syuueki.util.ConstantString.syuuekiDataSourceName)
    private EntityManager em;

    @Override
    protected EntityManager getEntityManager() {
        return em;
    }

    public JgrpTblFacade() {
        super(JgrpTbl.class);
    }

    /**
     * 指定部課のJobGr一覧を取得
     *
     * @param deptCd
     * @return
     */
    public List<JgrpTbl> findDeptJobGr(String deptCd) {
        Map<String, Object> condition = new HashMap<>();
        condition.put("jgrpKaCd", deptCd);

        List<JgrpTbl> list
                = sqlExecutor.getResultList(em, JgrpTbl.class, "/sql/jgrp/selectJobGroup.sql", condition);

        return list;
    }

    /**
     * 指定担当者のJobGr一覧を取得
     *
     * @param tuid 担当者
     * @return 指定担当者のJobGr一覧
     */
    public List<JgrpTbl> findTuidJobGr(String tuid) {
        Map<String, Object> condition = new HashMap<>();
        condition.put("tuid", tuid);

        List<JgrpTbl> list
                = sqlExecutor.getResultList(em, JgrpTbl.class, "/sql/jgrp/selectJobGroup.sql", condition);

        return list;
    }

    /**
     *
     * @param syokusyuCd
     * @param divisionCode
     * @return
     */
    public List<JgrpTbl> getJobGrList(String syokusyuCd, String divisionCode) {
        Map<String, Object> condition = new HashMap<>();
        condition.put("syokusyuCd", syokusyuCd);
        condition.put("divisionCode", divisionCode);

        List<JgrpTbl> list = sqlExecutor.getResultList(em, JgrpTbl.class, "/sql/jgrp/selectJobGrList.sql", condition);

        return list;
    }
    
}
