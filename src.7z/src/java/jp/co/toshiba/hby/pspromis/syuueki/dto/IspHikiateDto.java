/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package jp.co.toshiba.hby.pspromis.syuueki.dto;

import java.math.BigDecimal;

/**
 *
 * @author watabe
 */
public class IspHikiateDto {
    
    
    /**
     * 対象：案件id
     */
    private String taisyoAnkenId;
    /**
     * 引当：案件id
     */
    private String hikiateAnkenId;
    /**
     * 履歴ID
     */
    private int rirekiId; 
    /**
     * 対象年月（検索結果として出したもの）
     */
    private String taisyoYm;
    /**
     * 金額指定区分(実績全額(1)、金額指定(2))
     */
    private String shiteiKbn;
    /**
     *  ISP(上記の金額指定区分が、金額指定(2)の場合のみ指定される)
     */
    private BigDecimal hikiateIsp;
    /**
     * NET(上記の金額指定区分が、金額指定(2)の場合のみ指定される)
     */
    private BigDecimal hikiateNet;
    /**
     * 処理結果ステータス 0:成功 9：失敗
     */
    private String errFlg;
    /**
     * 処理結果メッセージ
     */
    private String errMsg;

    public String getTaisyoAnkenId() {
        return taisyoAnkenId;
    }

    public void setTaisyoAnkenId(String taisyoAnkenId) {
        this.taisyoAnkenId = taisyoAnkenId;
    }

    public String getHikiateAnkenId() {
        return hikiateAnkenId;
    }

    public void setHikiateAnkenId(String hikiateAnkenId) {
        this.hikiateAnkenId = hikiateAnkenId;
    }

    public int getRirekiId() {
        return rirekiId;
    }

    public void setRirekiId(int rirekiId) {
        this.rirekiId = rirekiId;
    }

    public String getTaisyoYm() {
        return taisyoYm;
    }

    public void setTaisyoYm(String taisyoYm) {
        this.taisyoYm = taisyoYm;
    }

    public String getShiteiKbn() {
        return shiteiKbn;
    }

    public void setShiteiKbn(String shiteiKbn) {
        this.shiteiKbn = shiteiKbn;
    }

    public BigDecimal getHikiateIsp() {
        return hikiateIsp;
    }

    public void setHikiateIsp(BigDecimal hikiateIsp) {
        this.hikiateIsp = hikiateIsp;
    }

    public BigDecimal getHikiateNet() {
        return hikiateNet;
    }

    public void setHikiateNet(BigDecimal hikiateNet) {
        this.hikiateNet = hikiateNet;
    }

    public String getErrFlg() {
        return errFlg;
    }

    public void setErrFlg(String errFlg) {
        this.errFlg = errFlg;
    }

    public String getErrMsg() {
        return errMsg;
    }

    public void setErrMsg(String errMsg) {
        this.errMsg = errMsg;
    }
}
