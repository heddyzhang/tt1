/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package jp.co.toshiba.hby.pspromis.syuueki.entity;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

/**
 *
 * @author ibayashi
 */
@Entity
@Table(name = "SYU_ZEIKBN_MST")
public class SyuZeikbnMst implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 1)
    @Column(name = "ZEI_KBN")
    private String zeiKbn;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 1)
    @Column(name = "KEIYAKU_ZEI_KBN")
    private String keiyakuZeiKbn;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 32)
    @Column(name = "ZEI_NM")
    private String zeiNm;
    @Basic(optional = false)
    @Size(min = 1, max = 32)
    @Column(name = "ZEI_RNM")
    private String zeiRnm;
    // @Max(value=?)  @Min(value=?)//if you know range of your decimal fields consider using these annotations to enforce field validation
    @Basic(optional = false)
    @NotNull
    @Column(name = "ZEI_RATE")
    private BigDecimal zeiRate;
    @Basic(optional = false)
    @NotNull
    @Column(name = "DEFAULT_FLG")
    private short defaultFlg;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 1)
    @Column(name = "IS_DELETES")
    private String isDeletes;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 8)
    @Column(name = "UPDATED_AT")
    private String updatedAt;
    @Basic(optional = false)
    @NotNull
    @Column(name = "UPDATE_BY")
    @Temporal(TemporalType.DATE)
    private Date updateBy;

    public SyuZeikbnMst() {
    }

    public SyuZeikbnMst(String zeiKbn) {
        this.zeiKbn = zeiKbn;
    }

    public SyuZeikbnMst(String zeiKbn, String keiyakuZeiKbn, String zeiNm, BigDecimal zeiRate, short defaultFlg, String isDeletes, String updatedAt, Date updateBy) {
        this.zeiKbn = zeiKbn;
        this.keiyakuZeiKbn = keiyakuZeiKbn;
        this.zeiNm = zeiNm;
        this.zeiRate = zeiRate;
        this.defaultFlg = defaultFlg;
        this.isDeletes = isDeletes;
        this.updatedAt = updatedAt;
        this.updateBy = updateBy;
    }

    public String getZeiKbn() {
        return zeiKbn;
    }

    public void setZeiKbn(String zeiKbn) {
        this.zeiKbn = zeiKbn;
    }

    public String getKeiyakuZeiKbn() {
        return keiyakuZeiKbn;
    }

    public void setKeiyakuZeiKbn(String keiyakuZeiKbn) {
        this.keiyakuZeiKbn = keiyakuZeiKbn;
    }

    public String getZeiNm() {
        return zeiNm;
    }

    public void setZeiNm(String zeiNm) {
        this.zeiNm = zeiNm;
    }
    public String getZeiRnm() {
        return zeiRnm;
    }

    public void setZeiRnm(String zeiRnm) {
        this.zeiRnm = zeiRnm;
    }

    public BigDecimal getZeiRate() {
        return zeiRate;
    }

    public void setZeiRate(BigDecimal zeiRate) {
        this.zeiRate = zeiRate;
    }

    public short getDefaultFlg() {
        return defaultFlg;
    }

    public void setDefaultFlg(short defaultFlg) {
        this.defaultFlg = defaultFlg;
    }

    public String getIsDeletes() {
        return isDeletes;
    }

    public void setIsDeletes(String isDeletes) {
        this.isDeletes = isDeletes;
    }

    public String getUpdatedAt() {
        return updatedAt;
    }

    public void setUpdatedAt(String updatedAt) {
        this.updatedAt = updatedAt;
    }

    public Date getUpdateBy() {
        return updateBy;
    }

    public void setUpdateBy(Date updateBy) {
        this.updateBy = updateBy;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (zeiKbn != null ? zeiKbn.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof SyuZeikbnMst)) {
            return false;
        }
        SyuZeikbnMst other = (SyuZeikbnMst) object;
        if ((this.zeiKbn == null && other.zeiKbn != null) || (this.zeiKbn != null && !this.zeiKbn.equals(other.zeiKbn))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "jp.co.toshiba.hby.pspromis.syuueki.entity.SyuZeikbnMst[ zeiKbn=" + zeiKbn + " ]";
    }
    
}
