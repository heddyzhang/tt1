/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package jp.co.toshiba.hby.pspromis.syuueki.service;

import javax.ejb.Stateless;
import javax.inject.Inject;
import javax.interceptor.Interceptors;
import jp.co.toshiba.hby.pspromis.syuueki.bean.TakeAnkenInfoBean;
import jp.co.toshiba.hby.pspromis.syuueki.entity.OperationLog;
import jp.co.toshiba.hby.pspromis.syuueki.interceptor.TranceInterceptor;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 *
 * @author ibayashi
 */
@Stateless
@Interceptors({TranceInterceptor.class})
public class TakeAnkenInfoService {
    private static final Logger logger = LoggerFactory.getLogger(TakeAnkenInfoService.class);
    
    @Inject
    private TakeAnkenInfoBean takeAnkenInfoBean;

    @Inject
    private OperationLogService operationLogService;
    
    /**
     * 発番見合/中計取込操作ログの登録
     * @throws Exception 
     */
    public void copyInfoExecute() throws Exception {
        String[] ankenIdAry = takeAnkenInfoBean.getAnkenId();
        if (ankenIdAry == null || ankenIdAry.length == 0) {
            logger.error("発番見合/中計取込(操作LOG登録) 処理対象の物件KEYが指定されていません。");
            return;
        }
        if (StringUtils.isEmpty(takeAnkenInfoBean.getKbn())) {
            logger.info("発番見合/中計取込(操作LOG登録) 区分が指定されていません。");
            return;
        }
        
        // 操作ログを登録。
        String objectType = getObjectType();
        String ankenIds = changeStringAnkenId(ankenIdAry);
        registOperationLog(objectType, ankenIds);
    }
    
    /**
     * 案件情報をカンマ区切り文字列で取得
     */
    private String changeStringAnkenId(String[] ankenIdAry) {
        StringBuilder ankenIds = new StringBuilder();
        boolean isCount = false;
        for (String ankenId : ankenIdAry) {
            if (isCount) {
                ankenIds.append(",");
            }
            ankenIds.append(ankenId);
            isCount = true;
        }
        return String.valueOf(ankenIds);
    }

    /**
     * 操作ログに登録する機能IDを取得
     */
    private String getObjectType() {
        if ("S001".equals(takeAnkenInfoBean.getProcId())) {
            return "ICHIRAN_I";
        } else if ("S003".equals(takeAnkenInfoBean.getProcId())) {
            return "KIKAN_I";
        }
        return "";
    }

    /**
     * 操作ログの登録
     * @param operationCode
     * @throws Exception
     */
    private void registOperationLog(String objectType, String ankenId) throws Exception{
        OperationLog operationLog = this.operationLogService.getOperationLog();

        String operationCode = "";
        if ("H".equals(takeAnkenInfoBean.getKbn())) {
            operationCode = "COPY_HAT";
        } else if ("C".equals(takeAnkenInfoBean.getKbn())) {
            operationCode = "COPY_CHUKEI";
        }
        
        operationLog.setOperationCode(operationCode);
        operationLog.setObjectId(20);
        operationLog.setObjectType(objectType);
        operationLog.setRemarks(ankenId);

        operationLogService.insertOperationLogSearch(operationLog);
    }
    
}
