/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package jp.co.toshiba.hby.pspromis.syuueki.entity;

import java.io.Serializable;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Column;
import java.util.Date;
import javax.persistence.Temporal;
import javax.validation.constraints.NotNull;

/**
 *
 * @author watabe
 */
@Entity
@Table(name = "SYU_INFO_MESSAGE_MST")
public class SyuInfoMessageMst implements Serializable {
    private static final long serialVersionUID = 1L;

    @Id
    @Column(name = "KEY")
    private int keyInformation;
    @Id
    @Column(name = "SORT_NO")
    private int sortNo;
    @NotNull
    @Column(name = "INFO_MESSAGE")
    private String infoMessage;
    @Column(name = "IS_DELETED")
    private int isDeleted;
    @Column(name = "VALID_ABLE_FROM")
    private int validAbleFrom;
    @Column(name = "VALID_ABLE_TO")
    private int validAbleTo;
    @Column(name = "CREATED_AT")
    @Temporal(javax.persistence.TemporalType.DATE)
    private Date createdAt;
    @Column(name = "CREATED_BY")
    private String createdBy;
    @Column(name = "UPDATED_AT")
    @Temporal(javax.persistence.TemporalType.DATE)
    private Date updatedAt;
    @Column(name = "UPDATED_BY")
    private String updatedBy;
    @Column(name = "UPDATED_BATCH_AT")
    @Temporal(javax.persistence.TemporalType.DATE)
    private Date updatedBatchAt;
    @Column(name = "UPDATED_BATCH_BY")
    private String updatedBatchBy;

    public int getKeyInformation() {
        return keyInformation;
    }

    public void setKeyInformation(int keyInformation) {
        this.keyInformation = keyInformation;
    }

    public int getSortNo() {
        return sortNo;
    }

    public void setSortNo(int sortNo) {
        this.sortNo = sortNo;
    }

    public String getInfoMessage() {
        return infoMessage;
    }

    public void setInfoMessage(String infoMessage) {
        this.infoMessage = infoMessage;
    }

    public int getIsDeleted() {
        return isDeleted;
    }

    public void setIsDeleted(int isDeleted) {
        this.isDeleted = isDeleted;
    }

    public int getValidAbleFrom() {
        return validAbleFrom;
    }

    public void setValidAbleFrom(int validAbleFrom) {
        this.validAbleFrom = validAbleFrom;
    }

    public int getValidAbleTo() {
        return validAbleTo;
    }

    public void setValidAbleTo(int validAbleTo) {
        this.validAbleTo = validAbleTo;
    }

    public Date getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(Date createdAt) {
        this.createdAt = createdAt;
    }

    public String getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    public Date getUpdatedAt() {
        return updatedAt;
    }

    public void setUpdatedAt(Date updatedAt) {
        this.updatedAt = updatedAt;
    }

    public String getUpdatedBy() {
        return updatedBy;
    }

    public void setUpdatedBy(String updatedBy) {
        this.updatedBy = updatedBy;
    }

    public Date getUpdatedBatchAt() {
        return updatedBatchAt;
    }

    public void setUpdatedBatchAt(Date updatedBatchAt) {
        this.updatedBatchAt = updatedBatchAt;
    }

    public String getUpdatedBatchBy() {
        return updatedBatchBy;
    }

    public void setUpdatedBatchBy(String updatedBatchBy) {
        this.updatedBatchBy = updatedBatchBy;
    }
    
}
