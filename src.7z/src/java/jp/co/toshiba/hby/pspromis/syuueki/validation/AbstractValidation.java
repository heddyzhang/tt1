/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package jp.co.toshiba.hby.pspromis.syuueki.validation;

import java.math.BigDecimal;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.ResourceBundle;
import java.util.Set;
import javax.validation.ConstraintViolation;
import javax.validation.Validation;
import javax.validation.Validator;
import javax.validation.ValidatorFactory;
import jp.co.toshiba.hby.pspromis.common.util.StringUtil;
import jp.co.toshiba.hby.pspromis.syuueki.util.Utils;
import org.apache.commons.lang3.StringUtils;

/**
 *
 * @author ibayashi
 * @param <T>
 */
public abstract class AbstractValidation<T> {

    /**
     * bean
     */
    private T bean;

    /**
     * バリデーション結果
     */
    private Set<ConstraintViolation<T>> result;

    /**
     * コンストラクタ
     *
     * @param bean
     */
    public AbstractValidation(T bean) {
        this.bean = bean;
    }

    /**
     * アノテーションベースのバリデーションを行う。
     */
    public void annotationValidate() {
        ValidatorFactory vf = Validation.buildDefaultValidatorFactory();
        Validator v = vf.getValidator();
        result = v.validate(bean);
    }

    /**
     * バリデーション結果のメッセージを取得
     *
     * @return
     */
    public Map<String, String> getValidateMessagess() {
        if (result == null) {
            return null;
        }

        Map<String, String> messages = new LinkedHashMap<>();
        for (ConstraintViolation<T> cv : result) {
            messages.put(cv.getPropertyPath().toString(), cv.getMessage());
        }

        return messages;
    }

    /**
     * リソースからvalidationメッセージを取得
     *
     * @param key
     * @return
     */
    public String getValidationMessage(String key) {
        ResourceBundle rb = ResourceBundle.getBundle("ValidationMessages");
        String value = rb.getString(key);
        return value;
    }

    /**
     * 年月チェック<br>
     * 空文字・nullの場合はチェックしない
     *
     * @param value
     * @return true:年月 false:年月でない
     */
    public boolean isValidYm(String value) {
        boolean isValid = true;
        try {
            if (StringUtil.isNotEmpty(value)) {
                Utils.parseDate(value);
            }
        } catch (ParseException e) {
            isValid = false;
        }
        return isValid;
    }

    /**
     * 2017/11/14 ADD #5 #12 #22 納期を年月日に変更
     * 年月日チェック<br>
     * 空文字・nullの場合はチェックしない
     *
     * @param value
     * @return true:年月 false:年月でない
     */
    public boolean isValidYmd(String value) {
        boolean isValid = true;
        try {
            if (StringUtil.isNotEmpty(value)) {
                Utils.parseDateWithDate(value);
            }
        } catch (ParseException e) {
            isValid = false;
        }
        return isValid;
    }

    /**
     * 年期チェック<br>
     * 空文字・nullの場合はチェックしない
     *
     * @param value
     * @return true:年期 false:年期でない
     */
    public boolean isValidYki(String value) {
        boolean isValid = false;
        try {
            if (StringUtil.isNotEmpty(value)) {
                if (StringUtils.isNumeric(value.substring(0, 4))
                        && ("K".equals(value.substring(4, 5)) || "S".equals(value.substring(4, 5)))
                        && StringUtils.isNumeric(value.substring(5, 6))
                        && value.length() == 6) {
                    isValid = true;
                }
            } else {
                // 空文字・null
                isValid = true;
            }
        } catch (Exception e) {
            isValid = false;
        }
        return isValid;
    }

    /**
     * 数値チェック
     *
     * @param value
     * @param intLen 整数部の最大桁数
     * @param scale 小数部の最大桁数
     * @return
     */
    public boolean isValidNumber(String value, int intLen, int scale) {
        boolean isValid = true;

        if (StringUtil.isNotEmpty(value)) {
            isValid = Utils.isNumeric(value);
            if (isValid) {
                BigDecimal chk = Utils.changeBigDecimal(value);
                // 整数部の桁数が上限を超えてる場合
                if (chk.precision() - chk.scale() > intLen) {
                    isValid = false;
                    // 小数点以下の桁数が上限を超えてる場合
                } else if (chk.scale() > scale) {
                    isValid = false;
                }
            }
        }
        return isValid;
    }

    public T getBean() {
        return bean;
    }

    public void setBean(T bean) {
        this.bean = bean;
    }

    public Set<ConstraintViolation<T>> getResult() {
        return result;
    }

    public void setResult(Set<ConstraintViolation<T>> result) {
        this.result = result;
    }

}
