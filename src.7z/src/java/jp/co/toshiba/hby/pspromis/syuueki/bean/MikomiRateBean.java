package jp.co.toshiba.hby.pspromis.syuueki.bean;

import java.util.ArrayList;
import java.util.Date;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import javax.enterprise.context.RequestScoped;
import javax.inject.Named;
/**
 *
 * @author masaki
 */
@Named(value = "mikomiRateBean")
@RequestScoped
public class MikomiRateBean extends AbstractBean {

    /**
     * 見込レートマスタ　種類（PK）
     */
    private String hidType;
    
    /**
     * 見込レートマスタ　事業部コード（PK）
     */
    private String hidDivisionCode;
    
    /**
     * 見込レートマスタ　削除チェックボックス
     */
    private String[] listIndex;
    
    /**
     * 見込レートマスタ 代表注番
     */
    private String[] listMainOrderNo;
    
    /**
     * 見込レートマスタ　通貨コード（PK）
     */
    private String[] listCurrencyCode;
        
    /**
     * 作成者（見込レートマスタ）
     */
    private String[] listCreateBy;
    
    /**
     * 作成日（見込レートマスタ）
     */
    private String[] listCreateDate;
    
    /**
     * 最終更新者（見込レートマスタ）
     */
    private String[] listUpdateBy;
    
    /**
     * 最終更新日（見込レートマスタ）
     */
    private String[] listUpdateDate;

    /**
     * 変更フラグ
     */
    private String[] txtChangeFlg;
    
    /**
     * 新規行フラグ
     */
    private String[] txtShinkiFlg;
    
    /**
     * 代表注番（見込レートマスタ）
     */
    private String[] txtMainOrderNo;
    
    /**
     * 案件名称（見込レートマスタ）
     */
    private String[] txtAnkenName;

    /**
     * 通貨（見込レートマスタ）
     */
    private String[] subCur;
    
    /**
     * レート（見込レートマスタ）
     */
    private String[] txtMikomiRate;

    /**
     * TYPE（ARI:前受あり／NASHI:前受なし）
     */
    private String typeFlg;
    
    /**
     * 設定する見込レートの売上基準
     */
    private String rateSalesClass;
    
    /**
     * エラーメッセージ
     */
    private Map<String, String> messageInfo;
    
    public String getHidType() {
        return hidType;
    }

    public void setHidType(String hidType) {
        this.hidType = hidType;
    }

    public String getHidDivisionCode() {
        return hidDivisionCode;
    }

    public void setHidDivisionCode(String hidDivisionCode) {
        this.hidDivisionCode = hidDivisionCode;
    }


    public String[] getListIndex() {
        return listIndex;
    }

    public void setListIndex(String[] listIndex) {
        this.listIndex = listIndex;
    }

    public String[] getListMainOrderNo() {
        return listMainOrderNo;
    }

    public void setListMainOrderNo(String[] listMainOrderNo) {
        this.listMainOrderNo = listMainOrderNo;
    }

    public String[] getListCurrencyCode() {
        return listCurrencyCode;
    }

    public void setListCurrencyCode(String[] listCurrencyCode) {
        this.listCurrencyCode = listCurrencyCode;
    }

    public String[] getListCreateBy() {
        return listCreateBy;
    }

    public void setListCreateBy(String[] listCreateBy) {
        this.listCreateBy = listCreateBy;
    }

    public String[] getListCreateDate() {
        return listCreateDate;
    }

    public void setListCreateDate(String[] listCreateDate) {
        this.listCreateDate = listCreateDate;
    }

    public String[] getListUpdateBy() {
        return listUpdateBy;
    }

    public void setListUpdateBy(String[] listUpdateBy) {
        this.listUpdateBy = listUpdateBy;
    }

    public String[] getListUpdateDate() {
        return listUpdateDate;
    }

    public void setListUpdateDate(String[] listUpdateDate) {
        this.listUpdateDate = listUpdateDate;
    }

    public String[] getTxtMainOrderNo() {
        return txtMainOrderNo;
    }

    public void setTxtMainOrderNo(String[] txtMainOrderNo) {
        this.txtMainOrderNo = txtMainOrderNo;
    }

    public String[] getTxtAnkenName() {
        return txtAnkenName;
    }

    public void setTxtAnkenName(String[] txtAnkenName) {
        this.txtAnkenName = txtAnkenName;
    }

    public String[] getSubCur() {
        return subCur;
    }

    public void setSubCur(String[] subCur) {
        this.subCur = subCur;
    }

    public String[] getTxtMikomiRate() {
        return txtMikomiRate;
    }

    public void setTxtMikomiRate(String[] txtMikomiRate) {
        this.txtMikomiRate = txtMikomiRate;
    }

    public String[] getTxtChangeFlg() {
        return txtChangeFlg;
    }

    public void setTxtChangeFlg(String[] txtChangeFlg) {
        this.txtChangeFlg = txtChangeFlg;
    }

    public String[] getTxtShinkiFlg() {
        return txtShinkiFlg;
    }

    public void setTxtShinkiFlg(String[] txtShinkiFlg) {
        this.txtShinkiFlg = txtShinkiFlg;
    }

    public String getTypeFlg() {
        return typeFlg;
    }

    public void setTypeFlg(String typeFlg) {
        this.typeFlg = typeFlg;
    }

    public Map<String, String> getMessageInfo() {
        return messageInfo;
    }

    public String getMessage(String key) {
        String msg = "";
        if (messageInfo != null) {
            msg = messageInfo.get(key);
        }
        return msg;
    }

    public void setMessage(String key, String _message) {
        if (messageInfo == null) {
            messageInfo = new LinkedHashMap<>();
        }
        
        messageInfo.put(key, _message);
    }

    public String getRateSalesClass() {
        return rateSalesClass;
    }

    public void setRateSalesClass(String rateSalesClass) {
        this.rateSalesClass = rateSalesClass;
    }

}
