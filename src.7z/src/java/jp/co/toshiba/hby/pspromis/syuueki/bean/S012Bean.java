package jp.co.toshiba.hby.pspromis.syuueki.bean;

import java.util.List;
import java.util.Map;
import javax.enterprise.context.RequestScoped;
import javax.inject.Named;
import jp.co.toshiba.hby.pspromis.syuueki.entity.SyuCurMst;

/**
 *
 * @author horie
 */
@Named(value = "s012Bean")
@RequestScoped
public class S012Bean extends AbstractBean {

    /**
     * 処理元の画面ID(操作ログの登録で利用)
     */
    private String procId;

    /**
     * 案件フラグ
     */
    private String ankenFlg;
    
    /**
     * 物件の事業部コード
     */
    private String divisionCode;
    
    /**
     * 通貨選択候補リスト（通貨マスタ）
     */
    private List<SyuCurMst> listCurMst;
    
    /**
     * 見込通貨一覧
     */
    private List<Map<String, Object>> currencyList;

    /**
     * 通貨コード(保存処理)
     */
    private String[] currencyCode;
    
    /**
     * 変更前・通貨コード(保存処理)
     */
    private String[] orgCurrencyCode;
    
    /**
     * 削除フラグ(保存処理)
     */
    private String[] delFlg;
    
    /**
     * 契約レート
     */
    private String[] keiyakuRate;
    
    /**
     * 契約レート(編集可能であれば1)
     */
    private String[] editKeiyakuRateFlg;

    /**
     * 売上基準
     */
    private String salesClass;

    /**
     * 契約レート表示FLG
     */
    private String dispKeiyakuRateFlg;

    /**
     * データ作成済フラグ(保存処理)
     */
    private String[] createdFlg;

    public String getAnkenFlg() {
        return ankenFlg;
    }

    public void setAnkenFlg(String ankenFlg) {
        this.ankenFlg = ankenFlg;
    }

    public String[] getDelFlg() {
        return delFlg;
    }

    public void setDelFlg(String[] delFlg) {
        this.delFlg = delFlg;
    }

    public String getDivisionCode() {
        return divisionCode;
    }

    public void setDivisionCode(String divisionCode) {
        this.divisionCode = divisionCode;
    }

    public List<Map<String, Object>> getCurrencyList() {
        return currencyList;
    }

    public void setCurrencyList(List<Map<String, Object>> currencyList) {
        this.currencyList = currencyList;
    }

    public List<SyuCurMst> getListCurMst() {
        return listCurMst;
    }

    public void setListCurMst(List<SyuCurMst> listCurMst) {
        this.listCurMst = listCurMst;
    }

    public String[] getCurrencyCode() {
        return currencyCode;
    }

    public void setCurrencyCode(String[] currencyCode) {
        this.currencyCode = currencyCode;
    }

    public String[] getOrgCurrencyCode() {
        return orgCurrencyCode;
    }

    public void setOrgCurrencyCode(String[] orgCurrencyCode) {
        this.orgCurrencyCode = orgCurrencyCode;
    }

    public String[] getCreatedFlg() {
        return createdFlg;
    }

    public void setCreatedFlg(String[] createdFlg) {
        this.createdFlg = createdFlg;
    }

    public String getProcId() {
        return procId;
    }

    public void setProcId(String procId) {
        this.procId = procId;
    }

    public String[] getKeiyakuRate() {
        return keiyakuRate;
    }

    public void setKeiyakuRate(String[] keiyakuRate) {
        this.keiyakuRate = keiyakuRate;
    }

    public String[] getEditKeiyakuRateFlg() {
        return editKeiyakuRateFlg;
    }

    public void setEditKeiyakuRateFlg(String[] editKeiyakuRateFlg) {
        this.editKeiyakuRateFlg = editKeiyakuRateFlg;
    }

    public String getSalesClass() {
        return salesClass;
    }

    public void setSalesClass(String salesClass) {
        this.salesClass = salesClass;
    }

    public String getDispKeiyakuRateFlg() {
        return dispKeiyakuRateFlg;
    }

    public void setDispKeiyakuRateFlg(String dispKeiyakuRateFlg) {
        this.dispKeiyakuRateFlg = dispKeiyakuRateFlg;
    }

}
