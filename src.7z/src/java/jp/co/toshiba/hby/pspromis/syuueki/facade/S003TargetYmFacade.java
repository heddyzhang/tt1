package jp.co.toshiba.hby.pspromis.syuueki.facade;

import java.util.ArrayList;
import java.util.List;
import javax.ejb.Stateless;
import javax.interceptor.Interceptors;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import jp.co.toshiba.hby.pspromis.common.util.CollectionUtil;
import jp.co.toshiba.hby.pspromis.syuueki.entity.S003TargetYm;
import jp.co.toshiba.hby.pspromis.syuueki.entity.S003UriageSpRowInfo;
import jp.co.toshiba.hby.pspromis.syuueki.entity.StringEntity;
import jp.co.toshiba.hby.pspromis.syuueki.interceptor.TranceInterceptor;
import org.apache.commons.beanutils.BeanUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 *
 * @author sano
 */
@Stateless
@Interceptors({TranceInterceptor.class})
public class S003TargetYmFacade extends AbstractFacade<S003TargetYm> {

    /**
     * ロガ－
     */
    private static final Logger logger = LoggerFactory.getLogger(S003TargetYmFacade.class);

    @PersistenceContext(unitName = jp.co.toshiba.hby.pspromis.syuueki.util.ConstantString.syuuekiDataSourceName)
    private EntityManager em;

    public S003TargetYmFacade() {
        super(S003TargetYm.class);
    }

    @Override
    protected EntityManager getEntityManager() {
        return em;
    }

    /**
     * 表示対象年月一覧を取得
     * @param condition
     * @return 
     */
    public List<S003TargetYm> findList(Object condition) throws Exception {
        logger.info("S003TargetYmFacade#findList");

        List<S003TargetYm> list =
                sqlExecutor.getResultList(em, S003TargetYm.class, "/sql/S003/selectTargetYm.sql", condition);
        List<S003TargetYm> copyList
                = CollectionUtil.createAndCopyList(S003TargetYm.class, list);

//        List<S003TargetYm> copyList = new ArrayList<>();
//        if (list != null && !list.isEmpty()) {
//            for (S003TargetYm entity : list) {
//                S003TargetYm newEntity = new S003TargetYm();
//                BeanUtils.copyProperties(newEntity, entity);
//                copyList.add(newEntity);
//            }
//        }

        return copyList;
    }

    /**
     * 表示対象通貨一覧を取得
     * @param condition
     * @return 
     */
    public List<String> findCurrencyList(Object condition) {
        logger.info("S003TargetYmFacade#findCurrencyList");

        List<StringEntity> list =
                sqlExecutor.getResultList(em, StringEntity.class, "/sql/S003/selectTargetCurrency.sql", condition);
        
        List<String> resultList = null;
        if (list != null && !list.isEmpty()) {
            resultList = new ArrayList<>();
            for (StringEntity entity : list) {
                resultList.add(entity.getString());
            }
        }

        return resultList;
    }
    
    public List<S003UriageSpRowInfo> findUriageSpRowInfo(Object condition) {
        logger.info("S003TargetYmFacade#findUriageSpRowInfo");

        List<S003UriageSpRowInfo> list =
                sqlExecutor.getResultList(em, S003UriageSpRowInfo.class, "/sql/S003/selectUriageSpRowInfo.sql", condition);
        
        return list;
    }

}
