package jp.co.toshiba.hby.pspromis.syuueki.service;

import java.util.HashMap;
import java.util.Map;
import javax.ejb.Stateless;
import javax.inject.Inject;
import javax.interceptor.Interceptors;
import jp.co.toshiba.hby.pspromis.syuueki.bean.ShirajiEditBean;
import jp.co.toshiba.hby.pspromis.syuueki.entity.TeamEntity;
import jp.co.toshiba.hby.pspromis.syuueki.facade.SyuGeBukenInfoTblFacade;
import jp.co.toshiba.hby.pspromis.syuueki.interceptor.TranceInterceptor;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * PS-Promis収益管理システム
 * 白地調整案件 取消/復活 Service
 * @author (NPC)S.Ibayashi
 */
@Stateless
@Interceptors({TranceInterceptor.class})
public class ShirajiEditService {

    public static final Logger logger = LoggerFactory.getLogger(ShirajiEditService.class);
    
    @Inject
    private ShirajiEditBean shirajiEditBean;

    @Inject
    private SyuGeBukenInfoTblFacade syuGeBukenInfoTblFacade;

    /**
     * 白地調整案件 復活/取消 実行
     * @throws Exception 
     */
    public void updateExecute() throws Exception {
        // BookMark登録FLGを取得
        String deleteFlg = StringUtils.defaultString(shirajiEditBean.getDeleteFlg(), "0");

        Map<String, Object> updateParam = new HashMap<>();
        
        updateParam.put("ankenId", shirajiEditBean.getAnkenId());
        updateParam.put("rirekiId", shirajiEditBean.getRirekiId());
        
        if ("1".equals(deleteFlg)) {
            // 白地取消の場合、削除FLGに"2"を立てる(これを白地取消の意味とした)
            updateParam.put("deleteFlg", "2");
        } else {
            updateParam.put("deleteFlg", "0");
        }
        
        // 白地取消/復活 実行
        syuGeBukenInfoTblFacade.updateShiraji(updateParam);
    }
    
}
