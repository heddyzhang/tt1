/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package jp.co.toshiba.hby.pspromis.syuueki.entity;

import java.io.Serializable;
import java.math.BigDecimal;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.validation.constraints.NotNull;

/**
 *
 * @author kitajima
 */
@Entity
public class S004DownloadEntity implements Serializable {
    private static final long serialVersionUID = 1L;
    
    @Id
    @Column(name = "ANKEN_ID")
    private String ankenId;

    @Id
    @Column(name = "CURRENCY_CODE")
    private String currencyCode;

    @Column(name = "CATEGORY_KBN1")
    private String categoryKbn1;
    @Column(name = "CATEGORY_KBN2")
    private String categoryKbn2;
    @Column(name = "CATEGORY_NAME1")
    private String categoryName1;
    @Column(name = "CATEGORY_NAME2")
    private String categoryName2;
    @Column(name = "DATA_KBN")
    private String dataKbn;
    @Column(name = "KEIYAKU_AMOUNT")
    private String keiyakuAmount;
    @Column(name = "KEIYAKU_ENKA_AMOUNT")
    private String keiyakuEnkaAmount;
    @Column(name = "URIAGE_AMOUNT")
    private String uriageAmount;
    @Column(name = "URI_RATE")
    private String uriRate;
    @Column(name = "URIAGE_ENKA_AMOUNT")
    private String uriageEnkaAmount;
    @Column(name = "URIAGE_KAWASESA")
    private String uriageKawasesa;
    @Column(name = "URIAGE_RUIKEI_AMOUNT")
    private String uriageRuikeiAmount;
    @Column(name = "URIAGE_RUIKEI_ENKA_AMOUNT")
    private String uriageRuikeiEnkaAmount;

    @Column(name = "KEIYAKU_RATE")
    private BigDecimal keiyakuRate;

    
    @Column(name = "KANJO_YM")
    private String kanjoYm;

    public void setAnkenId(String ankenId) {
        this.ankenId = ankenId;
    }

    public String getAnkenId() {
        return ankenId;
    }
    
    public void setCurrencyCode(String currencyCode) {
        this.currencyCode = currencyCode;
    }

    public String getCurrencyCode() {
        return currencyCode;
    }
    
    public String getCategoryKbn1() {
        return categoryKbn1;
    }

    public void setCategoryKbn1(String categoryKbn1) {
        this.categoryKbn1 = categoryKbn1;
    }

    public String getCategoryKbn2() {
        return categoryKbn2;
    }

    public void setCategoryKbn2(String categoryKbn2) {
        this.categoryKbn2 = categoryKbn2;
    }

    public String getCategoryName1() {
        return categoryName1;
    }

    public void setCategoryName1(String categoryName1) {
        this.categoryName1 = categoryName1;
    }

    public String getCategoryName2() {
        return categoryName2;
    }

    public void setCategoryName2(String categoryName2) {
        this.categoryName2 = categoryName2;
    }
    
    public String getDataKbn() {
        return dataKbn;
    }

    public void setDataKbn(String dataKbn) {
        this.dataKbn = dataKbn;
    }

    public String getKeiyakuAmount() {
        return keiyakuAmount;
    }

    public void setKeiyakuAmount(String keiyakuAmount) {
        this.keiyakuAmount = keiyakuAmount;
    }

    public String getKeiyakuEnkaAmount() {
        return keiyakuEnkaAmount;
    }

    public void setKeiyakuEnkaAmount(String keiyakuEnkaAmount) {
        this.keiyakuEnkaAmount = keiyakuEnkaAmount;
    }

    public String getUriageAmount() {
        return uriageAmount;
    }

    public void setUriageAmount(String uriageAmount) {
        this.uriageAmount = uriageAmount;
    }

    public String getUriRate() {
        return uriRate;
    }

    public void setUriRate(String uriRate) {
        this.uriRate = uriRate;
    }

    public String getUriageEnkaAmount() {
        return uriageEnkaAmount;
    }

    public void setUriageEnkaAmount(String uriageEnkaAmount) {
        this.uriageEnkaAmount = uriageEnkaAmount;
    }

    public String getUriageKawasesa() {
        return uriageKawasesa;
    }

    public void setUriageKawasesa(String uriageKawasesa) {
        this.uriageKawasesa = uriageKawasesa;
    }

    public String getUriageRuikeiAmount() {
        return uriageRuikeiAmount;
    }

    public void setUriageRuikeiAmount(String uriageRuikeiAmount) {
        this.uriageRuikeiAmount = uriageRuikeiAmount;
    }

    public String getUriageRuikeiEnkaAmount() {
        return uriageRuikeiEnkaAmount;
    }

    public void setUriageRuikeiEnkaAmount(String uriageRuikeiEnkaAmount) {
        this.uriageRuikeiEnkaAmount = uriageRuikeiEnkaAmount;
    }
    
    public String getKanjoYm() {
        return kanjoYm;
    }

    public void setKanjoYm(String kanjoYm) {
        this.kanjoYm = kanjoYm;
    }
    
    
    public BigDecimal getKeiyakuRate() {
        return keiyakuRate;
    }

    public void setKeiyakuRate(BigDecimal keiyakuRate) {
        this.keiyakuRate = keiyakuRate;
    }
    
}
