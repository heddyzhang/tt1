/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package jp.co.toshiba.hby.pspromis.syuueki.bean;

import java.util.List;
import java.util.Map;
import javax.enterprise.context.RequestScoped;
import javax.inject.Named;
import jp.co.toshiba.hby.pspromis.syuueki.entity.JgrpTbl;

/**
 *
 * @author horie
 */
@Named(value = "k001Bean")
@RequestScoped
public class K001Bean {
    /**
     * 事業部・部課リスト
     */
    List<Map<String, Object>> bukaList;

    /**
     * JobGrリスト
     */
    List<JgrpTbl> jobGrList;

    /**
     * 検索条件・部課コード
     */
    private String deptCd;

    /**
     * 検索条件・事業部(元画面から取得)
     */
    private String[] divisionCode;

    public List<Map<String, Object>> getBukaList() {
        return bukaList;
    }

    public void setBukaList(List<Map<String, Object>> bukaList) {
        this.bukaList = bukaList;
    }

    /**
     * 親事業部 or 部のid文字列を取得
     * @param map
     * @return 
     */
    public Object perentTreeIdStr(Map<String, Object> map) {
        Object perentId = map.get("parentId");
        if (perentId != null) {
            perentId = "data-tt-parent-id='" + perentId + "'";
        }
        return perentId;
    }

    public String getDeptCd() {
        return deptCd;
    }

    public void setDeptCd(String deptCd) {
        this.deptCd = deptCd;
    }

    public List<JgrpTbl> getJobGrList() {
        return jobGrList;
    }

    public void setJobGrList(List<JgrpTbl> jobGrList) {
        this.jobGrList = jobGrList;
    }

    public String[] getDivisionCode() {
        return divisionCode;
    }

    public void setDivisionCode(String[] divisionCode) {
        this.divisionCode = divisionCode;
    }

}
