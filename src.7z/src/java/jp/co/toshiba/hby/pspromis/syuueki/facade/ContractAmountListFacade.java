package jp.co.toshiba.hby.pspromis.syuueki.facade;

import java.util.List;
import javax.ejb.Stateless;
//import javax.inject.Inject;
import javax.interceptor.Interceptors;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import jp.co.toshiba.hby.pspromis.syuueki.entity.CurrencyRateList;
import jp.co.toshiba.hby.pspromis.syuueki.entity.ContractAmount;
import jp.co.toshiba.hby.pspromis.syuueki.interceptor.TranceInterceptor;
//import jp.co.toshiba.hby.pspromis.common.jdbc.SqlExecutor;
import org.apache.commons.collections4.CollectionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 *
 * @author sano
 */
@Stateless
@Interceptors({TranceInterceptor.class})
public class ContractAmountListFacade extends AbstractFacade<CurrencyRateList> {

    /**
     * ロガ－
     */
    private static final Logger logger = LoggerFactory.getLogger(ContractAmountListFacade.class);

    @PersistenceContext(unitName = jp.co.toshiba.hby.pspromis.syuueki.util.ConstantString.syuuekiDataSourceName)
    private EntityManager em;

    public ContractAmountListFacade() {
        super(CurrencyRateList.class);
    }

    @Override
    protected EntityManager getEntityManager() {
        return em;
    }
    
    /**
     * 最終見込損益　契約金額の合計を取得
     * @param condition
     * @return 
     */
    public CurrencyRateList findTotalList(Object condition) {
        logger.info("ContractAmountListFacade#findTotalList");

        CurrencyRateList list = 
                sqlExecutor.getSingleResult(em, CurrencyRateList.class, "/sql/S002/selectTotalContractAmount.sql", condition);
        
        return list;
    }
    
    /**
     * 期間損益　契約金額の合計を取得
     * @param condition
     * @return 
     */
    public ContractAmount findTotalListKs(Object condition) {
        logger.info("ContractAmountListFacade#findTotalListKs");

        //ContractAmount list = 
        //        sqlExecutor.getSingleResult(em, ContractAmount.class, "/sql/S004/selectKsTotalContractAmount.sql", condition);
        //return list;
        
        ContractAmount entity;
        List<ContractAmount> list = sqlExecutor.getResultList(em, ContractAmount.class, "/sql/S004/selectKsTotalContractAmount.sql", condition);
        if (CollectionUtils.isNotEmpty(list)) {
            entity = list.get(0);
        } else {
            entity = new ContractAmount();
        }
        return entity;
    }
    
    /**
     * 期間損益　契約金額内訳を取得
     * @param condition
     * @return 
     */
    public List<ContractAmount> findListKs(Object condition) {
        logger.info("ContractAmountListFacade#findListKs");

        List<ContractAmount> list = 
                sqlExecutor.getResultList(em, ContractAmount.class, "/sql/S004/selectKsCurrencyContractAmount.sql", condition);
        
        return list;
    }
    
    /**
     * 最終見込損益　子案件の契約金額の合計を取得
     * @param condition
     * @return 
     */
    public List<CurrencyRateList> findChildTotalList(Object condition) {
        logger.info("ContractAmountListFacade#findChildTotalList");

        List<CurrencyRateList> list = 
                sqlExecutor.getResultList(em, CurrencyRateList.class, "/sql/S002/selectTotalContractAmount.sql", condition);
        
        return list;
    }
    
    /**
     * 期間損益　契約金額内訳の翌月反映元を取得
     * @param condition
     * @return 
     */
    public ContractAmount findReflectTarget(Object condition) {
        logger.info("ContractAmountListFacade#findReflectTarget");

        //ContractAmount contractAmount = sqlExecutor.getSingleResult(em, ContractAmount.class, "/sql/S004/selectReflectTargetKeiyakuAmount.sql", condition);
        //return contractAmount;
        
        ContractAmount entity;
        List<ContractAmount> list = sqlExecutor.getResultList(em, ContractAmount.class, "/sql/S004/selectReflectTargetKeiyakuAmount.sql", condition);
        if (CollectionUtils.isNotEmpty(list)) {
            entity = list.get(0);
        } else {
            entity = new ContractAmount();
        }
        return entity;
    }
}
