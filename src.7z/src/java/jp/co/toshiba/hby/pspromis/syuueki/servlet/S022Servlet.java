package jp.co.toshiba.hby.pspromis.syuueki.servlet;

import java.io.File;
//import java.io.IOException;
//import java.io.PrintWriter;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import javax.inject.Inject;
//import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
//import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import jp.co.toshiba.hby.pspromis.syuueki.bean.AggregateConditionBean;
import jp.co.toshiba.hby.pspromis.syuueki.bean.S021Bean;
import jp.co.toshiba.hby.pspromis.syuueki.bean.S022Bean;
import jp.co.toshiba.hby.pspromis.syuueki.bean.S023Bean;
import jp.co.toshiba.hby.pspromis.syuueki.bean.S001MstBean;
import jp.co.toshiba.hby.pspromis.syuueki.bean.ValidationInfoBean;
//import jp.co.toshiba.hby.pspromis.syuueki.bean.ValidationMessageBean;
import jp.co.toshiba.hby.pspromis.syuueki.facade.SysdateEntityFacade;
import jp.co.toshiba.hby.pspromis.syuueki.service.S021Service;
import jp.co.toshiba.hby.pspromis.syuueki.service.S022Service;
import jp.co.toshiba.hby.pspromis.syuueki.service.download.ShukeiAnkenListService;
import jp.co.toshiba.hby.pspromis.syuueki.service.download.ShukeiListService;
import jp.co.toshiba.hby.pspromis.syuueki.util.FileUtils;
import jp.co.toshiba.hby.pspromis.syuueki.util.ParameterBinder;
import jp.co.toshiba.hby.pspromis.syuueki.util.PoiUtil;
import jp.co.toshiba.hby.pspromis.syuueki.validation.S022Validation;
import org.apache.commons.beanutils.PropertyUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.poi.ss.usermodel.Workbook;

/**
 * ES-Promis収益管理システム
 * 集計表 Servlet
 * @author rnomura
 */
@WebServlet(name = "S022Servlet", urlPatterns = {"/servlet/S022", "/servlet/S022/*"})
public class S022Servlet extends AbstractServlet {

    /**
     * jsp
     */
    private static final String INDEX_JSP = "S022/s022.jsp";
    
    @Inject
    private S022Bean s022Bean;
    
    @Inject
    private S023Bean s023Bean;
    
    @Inject
    private AggregateConditionBean aggregateConditionBean;

    @Inject
    private S021Bean s021Bean;

    @Inject
    private S001MstBean s001MstBean;

    @Inject
    private S022Service s022Service;
    
    @Inject
    private S021Service s021Service;
    
    @Inject
    private ValidationInfoBean validationInfoBean;
    
    @Inject
    private ShukeiListService shukeiListService;
    
    @Inject
    private ShukeiAnkenListService shukeiAnkenListService;
    
    @Inject
    private SysdateEntityFacade sysdateFacade;
    
    /**
     * 初期表示
     * @param req
     * @param resp
     * @return
     * @throws Exception 
     */
    public String indexAction(HttpServletRequest req, HttpServletResponse resp)
    throws Exception {
        logger.info("S022Servlet#indexAction");

        // リクエストパラメータをs022Beanの同名フィールドに一括コピー
        ParameterBinder.Bind(s022Bean, req);
        ParameterBinder.Bind(aggregateConditionBean, req);
        
        // 不要な情報もパラメータに含まれている可能性があるので事業部以外削除
        String dCode = aggregateConditionBean.getDivisionCode();
        PropertyUtils.copyProperties(aggregateConditionBean, (new AggregateConditionBean()));
        aggregateConditionBean.setDivisionCode(dCode);

        // 一覧検索状態をクリアしておく。
        s022Bean.setListFlg("0");
        
        // サービスの実行(トランザクション単位)
        s022Service.indexExecute();

        return INDEX_JSP;
    }
    
    /**
     * 一覧検索処理
     * @param req
     * @param resp
     * @return 
     * @throws Exception 
     */
    public String listAction(HttpServletRequest req, HttpServletResponse resp)
    throws Exception {
        logger.info("S022Servlet#listAction");

        // 検索条件用beanの初期化を行っておく
        PropertyUtils.copyProperties(aggregateConditionBean, (new AggregateConditionBean()));

        // リクエストパラメータをs022Beanの同名フィールドに一括コピー
        ParameterBinder.Bind(s022Bean, req);
        ParameterBinder.Bind(aggregateConditionBean, req);

        // ダイレクトアクセスされた場合はindexにリダイレクト
        String sendMethod = StringUtils.upperCase(req.getMethod());
        if (!"POST".equals(sendMethod)) {
            resp.sendRedirect(req.getContextPath() + "/servlet/S022");
            return null;
        }

        // 処理対象事業部が(原子力)であるかを判断するための情報をbeanにセット(後続のバリデーションチェックで利用する)
        s022Service.setBeanIsNuclear();

        // パラメータのバリデーションチェック
        S022Validation validation = new S022Validation(aggregateConditionBean);
        validation.execListValidation(validationInfoBean);

        if (validationInfoBean.isSuccess()) {
            // サービスの実行(トランザクションの単位にもなる)
            // ※バリデーションチェックに通った場合のみサービス実行。
            s022Service.listExecute();
        } else {
            if(aggregateConditionBean.getComparison().equals("Y")){
                s022Service.getYosanList();
            }
        }
        
        return INDEX_JSP;
    }

    /**
     * BU選択時に収益分類マスタを絞り込み
     * @param req
     * @param resp
     * @return
     * @throws Exception 
     */
    public String syukanJobGrMstAction(HttpServletRequest req, HttpServletResponse resp) 
    throws Exception {
        logger.info("S022Servlet#bunruiMstAction");

        // リクエストパラメータをs001Beanの同名フィールドに一括コピー
        ParameterBinder.Bind(aggregateConditionBean, req);

        s022Service.syukanJobGrMstExecute();

        // 結果セットをjson出力
        Map<String, Object> jsonMap = new HashMap<>();
        jsonMap.put("syukanJobGrMst", s001MstBean.getSyukanSectList());
        jsonMap.put("syukanJobGrId", aggregateConditionBean.getSyukanJobGrId());
        resopnseDecodeJson(resp, jsonMap);

        // ここでは戻すjspが存在しないため、nullを返す。
        return null;
    }
    
    /**
     * 検索条件:確定月取得
     * @param req
     * @param resp
     * @return 
     */
    public String taishoAction(HttpServletRequest req, HttpServletResponse resp)
    throws Exception {
        logger.info("S022Servlet#taishoAction");

        // 検索条件用beanの初期化を行っておく
        PropertyUtils.copyProperties(aggregateConditionBean, (new AggregateConditionBean()));

        // リクエストパラメータをS022Beanの同名フィールドに一括コピー
        ParameterBinder.Bind(s022Bean, req);
        ParameterBinder.Bind(aggregateConditionBean, req);

        s022Service.taishoExecute();
        
        // 結果セットをjson出力
        Map<String, Object> jsonMap = new HashMap<>();
        jsonMap.put("yosanList", s022Bean.getYosanList());
        resopnseDecodeJson(resp, jsonMap);
        
        return null;
    }
    
    /**
     * パターン検索用の検索条件設定処理(検索条件を保存した検索パターンより取得する)
     * @param req
     * @param resp
     * @return
     * @throws Exception 
     */
    public String patternSearchsCondtionAction(HttpServletRequest req, HttpServletResponse resp)
    throws Exception {
        logger.info("S022Servlet#patternSearchCondtionAction");
        
        // 検索条件用beanの初期化を行っておく
        PropertyUtils.copyProperties(aggregateConditionBean, (new AggregateConditionBean()));

        ParameterBinder.Bind(s022Bean, req);
        
        // 初期処理
        s022Service.patternIndexExecute();

        // 保存していたパターン検索用の条件をセット
        s021Bean.setDisplayId("SHUKEI");
        s021Bean.setPatternSeq(s022Bean.getSearchPatternSeq());
        s021Service.copySearchPattern(aggregateConditionBean);

        // 再セットしたパターンの条件を元に、各種マスタの選択候補を再取得
        s022Service.setMstDataAll();
        s022Service.getYosanList();

        return INDEX_JSP;
    }

    /**
     * excel出力
     * @param req
     * @param resp
     * @return
     * @throws Exception 
     */
    public String outputAggregateExcelAction(HttpServletRequest req, HttpServletResponse resp)
    throws Exception {
        logger.info("S022Servlet#outputAggregateExcelAction");

        // リクエストパラメータをs022Beanの同名フィールドに一括コピー
        ParameterBinder.Bind(s022Bean, req);
        
        Date now = sysdateFacade.getSysdate();
        SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMddHHmm");

        // テンプレートファイルの読み込み
        String filePath = req.getServletContext().getRealPath("WEB-INF/template/shukeiList_template.xlsx");
        Workbook workbook = PoiUtil.getWorkbook(new File(filePath));
        //Workbook workbook = PoiUtil.getSXSSFWorkbook(new File(filePath));

        // テンプレートにデータ埋め込み
        shukeiListService.outputDownloadExcel(workbook);
        
        // クライアントにダウンロード完了通知をお知らせするためにCookieをセット
        setCookie(resp, "syuueki_DownloadFinishFlg", "1");

        // テンプレート出力
        FileUtils.httpDownloadExcelResponse(workbook, "集計リスト_" + sdf.format(now) + ".xlsx", resp);

        return null;
    }
    
    /**
     * excel出力
     * @param req
     * @param resp
     * @return
     * @throws Exception 
     */
    public String outputAnkenExcelAction(HttpServletRequest req, HttpServletResponse resp)
    throws Exception {
        logger.info("S022Servlet#outputAnkenExcelAction");

        // リクエストパラメータをs023Beanの同名フィールドに一括コピー
        ParameterBinder.Bind(s023Bean, req);
        
        Date now = sysdateFacade.getSysdate();
        SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMddHHmm");

        // テンプレートファイルの読み込み
        String filePath = req.getServletContext().getRealPath("WEB-INF/template/shukeiAnkenList_template.xlsx");
        Workbook workbook = PoiUtil.getWorkbook(new File(filePath));
        //Workbook workbook = PoiUtil.getSXSSFWorkbook(new File(filePath));

        // テンプレートにデータ埋め込み
        shukeiAnkenListService.outputDownloadExcel(workbook);
        
        // クライアントにダウンロード完了通知をお知らせするためにCookieをセット
        setCookie(resp, "syuueki_DownloadFinishFlg", "1");

        // テンプレート出力
        FileUtils.httpDownloadExcelResponse(workbook, "集計案件リスト_" + sdf.format(now) + ".xlsx", resp);

        return null;
    }

    /**
     * Cookieセット
     *
     * @param resp
     * @param name
     * @param value
     */
    private void setCookie(HttpServletResponse resp, String name, String value) {
        Cookie cookieFlg = new Cookie(name, value);
        cookieFlg.setPath("/");
        resp.addCookie(cookieFlg);
    }

}
