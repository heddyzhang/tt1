package jp.co.toshiba.hby.pspromis.syuueki.entity;

import java.io.Serializable;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;
import javax.persistence.Id;

/**
 *
 * @author ibayashi
 */
@Entity
@Table(name = "M0130_LINE_EIG_JOBGR")
public class M0130LineEigJobgr implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @Column(name = "LINE_TANTO_CD")
    private String lineTantoCd;
    @Id
    @Column(name = "EIG_JOBGR_CD")
    private String eigJobgrCd;

    @Column(name = "LINE_TANTO_NM")
    private String lineTantoNm;

    @Column(name = "DIVISION_CODE")
    private String divisionCode;

    @Column(name = "TEAM_CODE")
    private String teamCode;

    public M0130LineEigJobgr() {
    }

    public String getLineTantoCd() {
        return lineTantoCd;
    }

    public void setLineTantoCd(String lineTantoCd) {
        this.lineTantoCd = lineTantoCd;
    }

    public String getEigJobgrCd() {
        return eigJobgrCd;
    }

    public void setEigJobgrCd(String eigJobgrCd) {
        this.eigJobgrCd = eigJobgrCd;
    }

    public String getLineTantoNm() {
        return lineTantoNm;
    }

    public void setLineTantoNm(String lineTantoNm) {
        this.lineTantoNm = lineTantoNm;
    }

    public String getDivisionCode() {
        return divisionCode;
    }

    public void setDivisionCode(String divisionCode) {
        this.divisionCode = divisionCode;
    }

    public String getTeamCode() {
        return teamCode;
    }

    public void setTeamCode(String teamCode) {
        this.teamCode = teamCode;
    }

}
