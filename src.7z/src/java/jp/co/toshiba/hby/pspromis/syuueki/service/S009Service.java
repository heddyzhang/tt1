package jp.co.toshiba.hby.pspromis.syuueki.service;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import javax.ejb.Stateless;
import javax.inject.Inject;
import javax.interceptor.Interceptors;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import jp.co.toshiba.hby.pspromis.syuueki.bean.S009Bean;
import jp.co.toshiba.hby.pspromis.syuueki.bean.S009MstBean;
import jp.co.toshiba.hby.pspromis.syuueki.entity.BuMst;
import jp.co.toshiba.hby.pspromis.syuueki.entity.PlantTypeMst;
import jp.co.toshiba.hby.pspromis.syuueki.entity.SyuMikomiRateMst;
import jp.co.toshiba.hby.pspromis.syuueki.entity.SyuMikomiUpInfoTbl;
import jp.co.toshiba.hby.pspromis.syuueki.entity.SyuPatternMst;
import jp.co.toshiba.hby.pspromis.syuueki.enums.Env;
import jp.co.toshiba.hby.pspromis.syuueki.facade.BuMstFacade;
import jp.co.toshiba.hby.pspromis.syuueki.facade.KanjyoMstFacade;
import jp.co.toshiba.hby.pspromis.syuueki.facade.PlantTypeMstFacade;
import jp.co.toshiba.hby.pspromis.syuueki.facade.SyuMikomiUpInfoTblFacade;
import jp.co.toshiba.hby.pspromis.syuueki.facade.SyuPatternMstFacade;
import jp.co.toshiba.hby.pspromis.syuueki.facade.SyuMikomiRateMstFacade;
import jp.co.toshiba.hby.pspromis.syuueki.facade.SyuCurMstFacade;
import jp.co.toshiba.hby.pspromis.syuueki.interceptor.TranceInterceptor;
import jp.co.toshiba.hby.pspromis.common.jdbc.SqlExecutor;
import jp.co.toshiba.hby.pspromis.syuueki.util.ConstantString;
import jp.co.toshiba.hby.pspromis.syuueki.util.LoginUserInfo;
import jp.co.toshiba.hby.pspromis.syuueki.util.SyuuekiUtils;
import jp.co.toshiba.hby.pspromis.syuueki.util.Utils;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.ArrayUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.time.DateUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
/**
 * PS-Promis収益管理システム
 * 管理メニュー Service
 * @author kitajima
 */
@Stateless
@Interceptors({TranceInterceptor.class})
public class S009Service {

    /**
     * ロガー
     */
    public static final Logger logger = LoggerFactory.getLogger(S009Service.class);

    @PersistenceContext(unitName = jp.co.toshiba.hby.pspromis.syuueki.util.ConstantString.syuuekiDataSourceName)
    private EntityManager em;

    /**
     * パラメータ格納クラスをinjection(CDI)<br>
     * InjectアノテーションよりAPサーバー(Glassfish)側で自動的にインスタンス作成(new)される。<br>
     */
    @Inject
    private S009Bean s009Bean;

    /**
     * マスタ情報格納クラスをinjection(CDI)<br>
     * InjectアノテーションよりAPサーバー(Glassfish)側で自動的にインスタンス作成(new)される。<br>
     */
    @Inject
    private S009MstBean s009MstBean;

    /**
     * Injection loginUserInfo
     * (ユーザー情報(ユーザーid,名称,所属部課名)を格納したオブジェクト)
     */
    @Inject
    private LoginUserInfo loginUserInfo;

    /**
     * Injection sqlExecutor
     */
    @Inject
    protected SqlExecutor sqlExecutor;

    /**
     * Injection SyuuekiUtils
     */
    @Inject
    private SyuuekiUtils syuuekiUtils;

    @Inject
    private SyuPatternMstFacade syuPatternMstFacade;

    @Inject
    private SyuMikomiRateMstFacade syuMikomiRateMstFacade;
        
    @Inject
    private PlantTypeMstFacade plantTypeMstFacade;

    @Inject
    private BuMstFacade buMstFacade;

    @Inject
    private OperationLogService operationLogService;

    @Inject
    private SyuMikomiUpInfoTblFacade syuMikomiUpInfoTblFacade;

    @Inject
    private KanjyoMstFacade kanjyoMstFacade;
    
    @Inject
    private SyuCurMstFacade syuCurMstFacade;
    
    @Inject
    private SyuuekiCommonService syuuekiCommonService;
    
    @Inject
    private Utils utils;

    //@Inject
    //private M0130BunruiOrgFacade bunruiMstFacade;
    
    /**
     * 検索条件用Mapを作成
     */
    private Map<String, Object> getCondition() {
        Map<String, Object> condition = new LinkedHashMap<>();
        
        //// 検索条件をセット
        // ログイン者が所属するJobGrに属する案件全てを検索
        // 事業部
        if (s009Bean.getDivisionCode() != null) {
            condition.put("division", Arrays.asList(s009Bean.getDivisionCode()));
        }

        if (s009Bean.getSubBuId() != null) {
            condition.put("sbuId", Arrays.asList(s009Bean.getSubBuId()));
        }
        // プラント種別
        condition.put("plantKbn", s009Bean.getPlantKbn());
        // パターン区分
        condition.put("patternKbn", s009Bean.getPatternKbn());
        // パターン名称
        condition.put("patternName", s009Bean.getPatternName());
        // 複写元パターン名称
        condition.put("copyPatternName", s009Bean.getCopyPatternName());

        // 見込レート種類
        condition.put("mikomiRateType", s009Bean.getMikomiRateType());
        
        return condition;
    }

    /**
     * 検索条件初期化
     */
    private void initCondition() {
        // 一覧表示FLG
        s009Bean.setListFlg("0");
        s009Bean.setConditionFlg("1");
        s009Bean.setCount(null);
        s009Bean.setPage(null);

        // 事業部(案件検索で指定していた内容を引き継ぐ)
        if (s009Bean.getDivisionCode() == null) {
            s009Bean.setDivisionCode(loginUserInfo.getJobGrSyokusyuArrayInfo("division"));
        }

        // メニュー選択
        s009Bean.setSelMenu("");
        
        // BU、SUBBU
        s009Bean.setBuId(null);
        s009Bean.setSubBuId(null);

        // プラント種別
        s009Bean.setPlantKbn("");
        // パターン区分
        s009Bean.setPatternKbn("");
        // パターン名称
        s009Bean.setPatternName("");
        // 複写元パターン名称
        s009Bean.setCopyPatternName("");
    }

    /**
     * ログイン者のdivisionSubNameと検索条件指定のBUコードが等しいBU情報をデフォルトで選択状態にする
     * (検索条件:BUのデフォルト選択で利用)
     * @param buMstList buマスタ一覧(BU/SBU検索条件の候補となるリスト)
     */
    private void setInitLoginDefaultBuSelect(String[] divisionCodes, List<BuMst> buMstList) {
        String[] buArray = s009Bean.getBuId();
        String[] sbuArray = s009Bean.getSubBuId();

        for (String divisionCode: divisionCodes) {
            String[] defaultBuArray = getLoginDefaultBuSbuSelect(divisionCode, buMstList, 0);
            String[] defaultSbuArray = getLoginDefaultBuSbuSelect(divisionCode, buMstList, 1);
            
            buArray = ArrayUtils.addAll(defaultBuArray, buArray);
            sbuArray = ArrayUtils.addAll(defaultSbuArray, sbuArray);
        }

        s009Bean.setBuId(buArray);
        s009Bean.setSubBuId(sbuArray);
    }
    
    /**
     * ログイン者のdivisionSubNameと検索条件指定のBUコードが等しいBU情報をデフォルトで選択状態にする
     * (検索条件:BUのデフォルト選択で利用)
     * @param buMstList buマスタ一覧(BU/SBU検索条件の候補となるリスト)
     */
    private void setSearchAfterLoginDefaultBuSelect(List<BuMst> buMstList) {
        if (CollectionUtils.isEmpty(buMstList)) {
            return;
        }

        // 検索条件で選択している以外のBUを取得
        String[] targetDivisionCodes = loginUserInfo.getJobGrSyokusyuArrayInfo("division");
        List<String> oterDivisionCodeList = new ArrayList<>();
        for (String loginDivisionCode: targetDivisionCodes) {
            if (!utils.isArrayValue(loginDivisionCode, s009Bean.getDivisionCode())) {
                oterDivisionCodeList.add(loginDivisionCode);
            }
        }
        
        targetDivisionCodes = (String[])oterDivisionCodeList.toArray(new String[0]);
        setInitLoginDefaultBuSelect(targetDivisionCodes, s009MstBean.getBuMstList());
    }

    /**
     * ログイン者のdivisionSubNameと検索条件指定のBUコードが等しいBU情報を配列で取得
     * @param buMstList buマスタ一覧(BU/SBU検索条件の候補となるリスト)
     * @kbn BU配列を取得するかSBU配列を取得するかを決定(0:BU配列 1:SBU配列)
     */
    private String[] getLoginDefaultBuSbuSelect(String divisionCode, List<BuMst> buMstList, int kbn) {
        String[] defaultBuSbuArray = syuuekiCommonService.getDefaultLoginSameBuArray(divisionCode, buMstList, kbn);
        logger.info("kbn=[{}], defaultBuSbuArray=[{}]", kbn, defaultBuSbuArray);
        return defaultBuSbuArray;
    }

    /**
     * マスタデータ取得
     */
    private void setMstDate() {
        // ログイン者の所属事業部コード(事業部兼務を考慮して配列で取得される)
        String[] loginDivisionCodes = loginUserInfo.getJobGrSyokusyuArrayInfo("division");
        
        // buマスタ
        if (s009MstBean.getBuMstList() == null) {
            // (電力ジ対応)
            // 事業部が増えることで、全てのBUを取得すると沢山とれてしまうことで、パフォーマンスやセキュリティに影響を与えたくないので、
            // ログイン者が所属している事業部のBU情報のみを取得するようにする
            //List<BuMst> buMstList = buMstFacade.findAll();
            Map<String, Object> buMstCondtion = new HashMap<>();
            buMstCondtion.put("divisionCode", loginDivisionCodes);
            List<BuMst> buMstList = buMstFacade.findConditionList(buMstCondtion);
            s009MstBean.setBuMstList(buMstList);
        }

        // プラント種別マスタ
        setPlantTypeMstData();
    }

    /**
     * マスタデータ取得
     */
    private void setPlantTypeMstData() {
        // プラント種別マスタ
        Map<String, Object> condition = new HashMap<>();
        String[] sbuCode = s009Bean.getSubBuId();
        if (sbuCode == null) {
            sbuCode = new String[1];
            sbuCode[0] = "@@@@";
        }
        condition.put("sbuCode", sbuCode);
        List<PlantTypeMst> plantTypeList = plantTypeMstFacade.getPlantTypeMstList(condition);
        s009MstBean.setPlantTypeList(plantTypeList);
    }

    /**
     * 初期表示 ビジネスロジック
     */
    public void indexExecute() {
        // 検索条件の初期化
        initCondition();        

        // 検索条件の各種候補のマスタデータ取得
        setMstDate();
        
        // ログイン者所属JobGrによるBU/SBU検索条件のデフォルト選択
        String[] loginDivisionCodes = loginUserInfo.getJobGrSyokusyuArrayInfo("division");
        setInitLoginDefaultBuSelect(loginDivisionCodes, s009MstBean.getBuMstList());
    }

    /**
     * プラント種別マスタ再取得
     * @throws Exception 
     */ 
    public void plantTypeMstExecute() throws Exception {
        setPlantTypeMstData();
    }

    /**
     * 一覧表示(注入パターンマスタ) ビジネスロジック
     * @throws Exception 
     */
    public void listExecute() throws Exception {
        s009Bean.setDispCount(0L);

        // ページ切り替えか否かを判定
        boolean isPageing = true;
        if (s009Bean.getPage() == null || s009Bean.getPage() <= 0) {
            isPageing = false;
            s009Bean.setPage(1);
        }

        // 事業部が選択されていない場合
        if (s009Bean.getDivisionCode() == null) {
            // ログイン者の優先事業部を強制セット
            String[] priorityDivCdAry = new String[]{loginUserInfo.getPriorityDivCode()};
            s009Bean.setDivisionCode(priorityDivCdAry);
        }
        
        // 検索条件をセット
        Map<String, Object> condition = getCondition();

        // 一覧データの総件数を取得(ページ切り替え時は省略)
        Long totalCount = s009Bean.getCount();
        //SyuPatternMst totalResultEntity = new SyuPatternMst();
        
        if (!isPageing) {
            ////// 検索ボタン
            // 操作ログを出力
            //OperationLog operationLog = getOperationLogDto(condition);
            //operationLogService.insertOperationLogSearch(operationLog);

            // データ総件数を取得
            condition.put("listFlg", "1");
            totalCount = syuPatternMstFacade.getPatternMstListCount(condition);
        }
        
        // 一覧検索実行(データが存在する場合のみ実行)
        List<SyuPatternMst> list = null;
        if (totalCount != null && totalCount > 0) {
            condition.put("listFlg", "0");
            list = syuPatternMstFacade.getPatternMstList(condition, s009Bean.getPage());
            s009Bean.setDispCount(new Long(list.size()));
        }

        // 結果をbeanセット
        s009Bean.setCount(totalCount);
        s009Bean.setList(list);

        // 検索条件の各種候補のマスタデータ取得
        setMstDate();
        
        // (事業部を兼務している場合を考慮)
        // 検索条件で選択した事業部以外のBUデフォルト選択が外れてしまうため
        // 選択した事業部以外のBUデフォルト選択を元に戻す
        setSearchAfterLoginDefaultBuSelect(s009MstBean.getBuMstList());
    }

    /**
     * 一覧データ取得(見込アップロード) ビジネスロジック
     * @throws Exception 
     */
    public void uploadlistExecute() throws Exception {
        Map<String, SyuMikomiUpInfoTbl> uploadInfoList = new HashMap<>();
    
        // 事業部
        String div;
        // 事業部が選択されていない or 複数選択されている場合(ログイン者の優先事業部(火水ジ所属なら火水ジ優先)を強制セット)
        if (s009Bean.getDivisionCode() == null || s009Bean.getDivisionCode().length > 1) {
            div = loginUserInfo.getPriorityDivCode();
            
            String[] priorityDivCdAry = new String[]{div};
            s009Bean.setDivisionCode(priorityDivCdAry);
        } else {
            // 1件のみ選択されている場合、その事業部を使用
            div = s009Bean.getDivisionCode()[0];
        }
        
        // 現在の勘定月を取得
        // (進行基準案件の見込アップロードを行うため、進行基準の勘定月を取得)
        String kanjoYm = kanjyoMstFacade.getNowKanjoDate(ConstantString.salesClassS);
        Date kanjoDate = Utils.parseDate(kanjoYm);
        //Date now = sysdateEntityFacade.getSysdate();
        String stringNow = syuuekiUtils.exeFormatYm(kanjoDate);

        // 工場(京浜) のアップロード情報を取得
        String kbnKeihin = "00";
        SyuMikomiUpInfoTbl keihinEn = syuMikomiUpInfoTblFacade.getPkInfo(kbnKeihin, div);
        uploadInfoList.put("keihin", keihinEn);
      
        // 工場(府中) のアップロード情報を取得
        String kbnFuchu = "01";
        SyuMikomiUpInfoTbl fuchuEn = syuMikomiUpInfoTblFacade.getPkInfo(kbnFuchu, div);
        uploadInfoList.put("fu", fuchuEn);
        
        // 工場(浜) のアップロード情報を取得
        String kbnHama = "02";
        SyuMikomiUpInfoTbl hamaEn = syuMikomiUpInfoTblFacade.getPkInfo(kbnHama, div);
        uploadInfoList.put("hama", hamaEn);
        
        // 工場(三) のアップロード情報を取得
        String kbnMi = "03";
        SyuMikomiUpInfoTbl miEn = syuMikomiUpInfoTblFacade.getPkInfo(kbnMi, div);
        uploadInfoList.put("mi", miEn);
        
        // （電力ジ）ＩＳＰ のアップロード情報を取得
        String kbnIsp = "04";
        SyuMikomiUpInfoTbl ispEn = syuMikomiUpInfoTblFacade.getPkInfo(kbnIsp, div);
        uploadInfoList.put("isp", ispEn);
        
        // （技）直課 のアップロード情報を取得
        String kbnChokka = "05";
        SyuMikomiUpInfoTbl chokkaEn = syuMikomiUpInfoTblFacade.getPkInfo(kbnChokka, div);
        uploadInfoList.put("chokka", chokkaEn);
        
        // （技）直課除くＢ項番 のアップロード情報を取得
        String kbnEtc = "06";
        SyuMikomiUpInfoTbl etcEn = syuMikomiUpInfoTblFacade.getPkInfo(kbnEtc, div);
        uploadInfoList.put("etc", etcEn);
        
        // （営業）販直費 のアップロード情報を取得
        String kbnHanchoku = "07";
        SyuMikomiUpInfoTbl hanchokuEn = syuMikomiUpInfoTblFacade.getPkInfo(kbnHanchoku, div);
        uploadInfoList.put("hanchoku", hanchokuEn);
        
        // （電力生）売発費 のアップロード情報を取得
        String kbnBaihatsu = "08";
        SyuMikomiUpInfoTbl baihatsuEn = syuMikomiUpInfoTblFacade.getPkInfo(kbnBaihatsu, div);
        uploadInfoList.put("baihatsu", baihatsuEn);

        s009Bean.setNowYear(stringNow.substring(0, 4));
        s009Bean.setNowMonth(stringNow.substring(5));
        s009Bean.setUploadDivisionCode(div);
        s009Bean.setUploadInfo(uploadInfoList);
    }

    
    /**
     * 見込レートマスタ一覧・新規作成用の行を確保する。
     */
    private List<SyuMikomiRateMst> addNewRateTypeList(List<SyuMikomiRateMst> list) {
        List<SyuMikomiRateMst> newList = list;
        if (newList == null || newList.isEmpty()) {
            newList = new ArrayList<>();
        }
        
        // 5行追加する(この5行はプロパティファイルenvの設定から取得)
        int newInputCount = 0;
        newInputCount = Integer.parseInt(Env.getValue(Env.Rate_New_Input_Count));
        for (int i=0; i < newInputCount; i++) {
            SyuMikomiRateMst entity = new SyuMikomiRateMst();
            newList.add(entity);
        }

        return newList;
    }
    
    /**
     * 一覧表示(見込レートマスタ) ビジネスロジック
     * @throws Exception 
     */
    public void listRateTypeExecute() throws Exception {
        s009Bean.setDispCount(0L);
        
        // 事業部
        String div;
        
        // 事業部が選択されていない場合 or 複数選択されている場合(ログイン者の優先事業部(火水ジ所属なら火水ジ優先)を強制セット)
        if (s009Bean.getDivisionCode() == null || s009Bean.getDivisionCode().length > 1) {
            div = loginUserInfo.getPriorityDivCode();
            
            // ログイン者の優先事業部を強制セット
            String[] priorityDivCdAry = new String[]{loginUserInfo.getPriorityDivCode()};
            s009Bean.setDivisionCode(priorityDivCdAry);
        } else {
            // 1件のみ選択されている場合、その事業部を使用
            div = s009Bean.getDivisionCode()[0];
        }
        
        // 検索対象の事業部
        s009Bean.setMikomiRateDivisionCode(div);
        
        // レート適用月の取得
        rateMonth();
        
        // 通貨リスト
        s009Bean.setListCurMst(syuCurMstFacade.findAll());
        
        // 検索条件をセット
        Map<String, Object> condition = getCondition();
        condition.put("divisionCode", div);

        // 見込レートマスタを検索
        List<SyuMikomiRateMst> list = syuMikomiRateMstFacade.getMikomiRateMstList(condition);
        Long count = 0L;
        if (list != null) {
            count = new Long(list.size());
        }
        
        // 検索件数
        s009Bean.setListRateTypeCnt(count);

        // 編集モードは新規作成用の行を確保する。
        if ("1".equals(s009Bean.getEditFlg())) {
            list = addNewRateTypeList(list);
        }

        // 結果をbeanセット
        s009Bean.setListRateType(list);
        s009Bean.setDispCount(count);
        s009Bean.setCount(count);
    }

    /**
     * 見込レートマスタ一覧・レート適用月の取得
     */
    private void rateMonth() throws Exception {
       
        // 現在の勘定月を取得
        // (進行基準案件の見込レート設定を行うため、進行基準の勘定月を取得)
        //String kanjoYm = kanjyoMstFacade.getNowKanjoDate(ConstantString.salesClassS);
        // 2016A 売上基準は検索条件から指定するようにし、売上基準に応じた勘定月を取得するように修正
        String kanjoYm = kanjyoMstFacade.getNowKanjoDate(s009Bean.getSearchRateSalesClass());
        Date kanjoDate = Utils.parseDate(kanjoYm);
        String strkanjoYm = syuuekiUtils.exeFormatYm(kanjoDate); //YYYY/MM形式
        
        // ※現在の勘定月の期の最終の月(9月か3月)をセット
        String[] monthAry = syuuekiUtils.getKikanMonthAry(kanjoDate);
        s009Bean.setRateMonthTo(syuuekiUtils.exeFormatYm(Utils.parseDate(monthAry[5])));
        
        // 期末月
        String periodLastMonth = monthAry[5];
        
        // 前受金あり当期
        if("MAEUKE_TOKI".equals(s009Bean.getMikomiRateType())){
            s009Bean.setRateMonthFrom(strkanjoYm);
        // 前受金あり翌期以降 又は 前受金なし翌期以降 又は (一般)翌期以降
        }else if("MAEUKE_YOKUKI".equals(s009Bean.getMikomiRateType()) || "NASI_YOKUKI".equals(s009Bean.getMikomiRateType()) || "IPPAN_YOKUKI".equals(s009Bean.getMikomiRateType())){
            String strkanjoKi = SyuuekiUtils.dateToKikan(kanjoDate); //YYYYMM（KorS）
            // 一期後に移動
            String yokuki = syuuekiUtils.calcKikan(strkanjoKi, 1);
            // 現在勘定月の期の翌期の最初月の取得
            monthAry = SyuuekiUtils.getKikanMonthAry(yokuki);
            s009Bean.setRateMonthFrom(syuuekiUtils.exeFormatYm(Utils.parseDate(monthAry[0])));
            s009Bean.setRateMonthTo("");
        // 前受金なし当期 or (一般)当期(翌月以降USD/EUR）
        }else if("NASI_USD_EUR".equals(s009Bean.getMikomiRateType()) || "IPPAN_USD_EUR".equals(s009Bean.getMikomiRateType())){
            // 勘定月の翌月(ただし、勘定月が期の最終月であれば、その期ではもう翌月がないため、空欄にする)
            if (kanjoYm.equals(periodLastMonth)) {
                s009Bean.setRateMonthFrom("");
                s009Bean.setRateMonthTo("");
            } else {
                Date nextMonthDate = DateUtils.addMonths(kanjoDate, 1);
                s009Bean.setRateMonthFrom(syuuekiUtils.exeFormatYm(nextMonthDate));
            }         
        }
    }
}
