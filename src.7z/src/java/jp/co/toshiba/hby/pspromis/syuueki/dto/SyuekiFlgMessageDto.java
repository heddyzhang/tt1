package jp.co.toshiba.hby.pspromis.syuueki.dto;

import lombok.Getter;
import lombok.Setter;

/**
 * 収益対象を設定／解除した場合の処理結果メッセージ
 * @author ibayashi
 */
@Getter @Setter
public class SyuekiFlgMessageDto {
    
    /**
     * 処理結果(0:成功 9:失敗)
     */
    private Integer resultFlg = 0;
    
    /**
     * 処理結果メッセージ
     */
    private String message;

    public String getMessageColor() {
        if (resultFlg == 0) {
            return "blue";
        } else {
            return "red";
        }
    }

}
 