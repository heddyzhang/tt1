package jp.co.toshiba.hby.pspromis.syuueki.facade;

import java.util.Map;
import java.util.List;
import javax.ejb.Stateless;
import javax.interceptor.Interceptors;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import jp.co.toshiba.hby.pspromis.syuueki.entity.SyuSaSpCurTitleTbl;
import jp.co.toshiba.hby.pspromis.syuueki.entity.SyuSaSpCurCurrencyTbl;
import jp.co.toshiba.hby.pspromis.syuueki.interceptor.TranceInterceptor;

/**
 *
 * @author ibayashi
 */
@Stateless
@Interceptors({TranceInterceptor.class})
public class SyuSaSpCurTitleTblFacade extends AbstractFacade<SyuSaSpCurTitleTbl> {

    @PersistenceContext(unitName = jp.co.toshiba.hby.pspromis.syuueki.util.ConstantString.syuuekiDataSourceName)
    private EntityManager em;

    @Override
    protected EntityManager getEntityManager() {
        return em;
    }

    public SyuSaSpCurTitleTblFacade() {
        super(SyuSaSpCurTitleTbl.class);
    }

    /**
     * 完成基準案件・登録済の通貨情報リストを取得
     */
    //public List<SyuSaSpCurTitleTbl> findAnkenCurrencyList(Map<String, Object> _params) {
    public List<SyuSaSpCurCurrencyTbl> findAnkenCurrencyList(Map<String, Object> _params) {
        return sqlExecutor.getResultList(em, SyuSaSpCurCurrencyTbl.class, "/sql/syuSaSpCurTitleTbl/selectAnkenCurrencyList.sql", _params);
    }

    /**
     * 進行(原価)基準案件・登録済の通貨情報リストを取得
     */
    //public List<SyuSaSpCurTitleTbl> findShinkoAnkenCurrencyList(Map<String, Object> _params) {
    public List<SyuSaSpCurCurrencyTbl> findShinkoAnkenCurrencyList(Map<String, Object> _params) {
        return sqlExecutor.getResultList(em, SyuSaSpCurCurrencyTbl.class, "/sql/syuSaSpCurTitleTbl/selectShinkoAnkenCurrencyList.sql", _params);
    }

    /**
     * 最終見込/通貨情報の件数を取得
     * @param _params
     * @return 
     */
    public Integer getCountCurrency(Map<String, Object> _params) {
        Integer count = sqlExecutor.getCount(em, "/sql/syuSaSpCurTitleTbl/countCurrencyCode.sql", _params);
        return count;
    }
    
    /**
     * 最終見込/通貨情報を新規登録
     * @param _params
     * @return 
     */
    public Integer insertSyuSaSpCurTitleTbl(Map<String, Object> _params) {
        Integer count = sqlExecutor.executeUpdateSql(em, "/sql/syuSaSpCurTitleTbl/insertSyuSaSpCurTitleTbl.sql", _params);
        return count;
    }

    /**
     * 最終見込/通貨情報を削除
     * @param _params
     * @return 
     */
    public Integer deleteSyuSaSpCurTitleTbl(Map<String, Object> _params) {
        Integer count = sqlExecutor.executeUpdateSql(em, "/sql/syuSaSpCurTitleTbl/deleteSyuSaSpCurTitleTbl.sql", _params);
        return count;
    }
    
}
