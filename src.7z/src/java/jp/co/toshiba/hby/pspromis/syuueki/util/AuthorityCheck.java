/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package jp.co.toshiba.hby.pspromis.syuueki.util;

//import java.util.List;
import org.apache.commons.lang3.StringUtils;
import jp.co.toshiba.hby.pspromis.syuueki.entity.SyuGeBukkenInfoTbl;
//import jp.co.toshiba.hby.pspromis.syuueki.entity.TeamEntity;
//import jp.co.toshiba.hby.pspromis.syuueki.enums.Env;
//import org.apache.commons.collections4.CollectionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * PS-Promis収益管理システム
 * 権限チェック
 * @author (NPC)S.Ibayashi
 */
public class AuthorityCheck {
    private static final Logger logger = LoggerFactory.getLogger(AuthorityCheck.class);

    /**
     * 職種のチェック
     * @param syokusyuCdAry 職種コード格納配列
     * @return true:システム利用可能職種 false:システム利用不可職種
     */
//    public static boolean isSyokushu(String[] syokusyuCdAry) {
//        if (syokusyuCdAry == null) {
//            return false;
//        }
//
//        for (String syokusyuCd : syokusyuCdAry) {
//            syokusyuCd = StringUtils.defaultString(syokusyuCd);
//            logger.warn("syokusyuCd："+syokusyuCd);
//            // Step4インシデント#021 調達(C)権限も自事業部の全案件閲覧をOKとする
//            if (syokusyuCd.equals("L") || syokusyuCd.equals("M") || syokusyuCd.equals("K") || syokusyuCd.equals("C")) {
//                return true;
//            }
//        }
//
//        return false;
//    }
    
    /**
     * ログイン者チームコードのチェック
     * @param myTeamList ログイン者所属のチームコード
     * @param atsukaiTeamCode 扱いチームコード(SYU_GE_BUKKEN_INFO_TBL.ATSUKAI_TEAM_CODE)
     * @param atsukaiCCode 扱いC(SYU_GE_BUKKEN_INFO_TBL.ATSUKAI_C_CODE)
     * @param shirajiFlg 白地FLG(SYU_GE_BUKKEN_INFO_TBL.SHIRAJI_FLG)
     * @param divisionCode 事業部コード(SYU_GE_BUKKEN_INFO_TBL.DIVISION_CODE)
     * @return ログイン者チームは扱いチームor扱いCのどちらかに所属している場合、true(事業部毎に参照方法異なる)
     */
//    private static boolean isMyTeam(List<TeamEntity> myTeamList, String atsukaiTeamCode, String atsukaiCCode, String shirajiFlg, String divisionCode) {
//        if (CollectionUtils.isEmpty(myTeamList)) {
//            return false;
//        }
//
//        // 事業部:(火水ジ)コードを取得(N8のはず)
//        String divKa = StringUtils.defaultString(Env.getValue(Env.Div_Ka));
//
//        for (TeamEntity tEntity : myTeamList) {
//            String targetTeamCode = "";
//            String myTeamCd = StringUtils.defaultString(tEntity.getTeamCd());
//            
//            if (divKa.equals(divisionCode)) {
//                // (火水ジ)ATSUKAI_C_CODEと保有チームコード3桁目以降でチェック
//                targetTeamCode = atsukaiCCode;
//                myTeamCd = StringUtils.substring(myTeamCd, 2);
//            }
//
//            if (myTeamCd.equals(targetTeamCode)) {
//                return true;
//            }
//        }
//        
//        return false;
//    }
    
    /**
     * ログイン者チームコードのチェック
     * @param myTeamList ログイン者所属のチームコード
     * @param geBukkenEntity 該当案件のSYU_GE_BUKKEN_INFO_TBLエンティティ
     * @return ログイン者チームは扱いチームor扱いCのどちらかに所属している場合、true
     */
//    public static boolean isMyTeam(List<TeamEntity> myTeamList, SyuGeBukkenInfoTbl geBukkenEntity) {
//        String atsukaiTeamCode = geBukkenEntity.getAtsukaiTeamCode();
//        String atsukaiCCode = geBukkenEntity.getAtsukaiCCode();
//        String shirajiFlg = geBukkenEntity.getShirajiFlg();
//        String divisionCode = geBukkenEntity.getDivisionCode();
//
//        return isMyTeam(myTeamList, atsukaiTeamCode, atsukaiCCode, shirajiFlg, divisionCode);
//    }
    
    /**
     * 白地案件削除チェック(白地削除案件の場合は編集不可にする)
     * @param geBukkenEntity 該当案件のSYU_GE_BUKKEN_INFO_TBLエンティティ
     * @return 白地取消(IS_DELETE=2)の場合、true
     */
    public static boolean isShirajiDeleteCheck(SyuGeBukkenInfoTbl geBukkenEntity) {
        if ("2".equals(geBukkenEntity.getIsDeleted())) {
            return true;
        }
        return false;
    }
}
