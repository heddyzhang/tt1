package jp.co.toshiba.hby.pspromis.syuueki.bean;

import java.util.List;
import javax.enterprise.context.RequestScoped;
import javax.inject.Named;
import jp.co.toshiba.hby.pspromis.syuueki.entity.BuMst;
import jp.co.toshiba.hby.pspromis.syuueki.entity.PlantTypeMst;
import jp.co.toshiba.hby.pspromis.syuueki.entity.SyuPatternItemMst;
import jp.co.toshiba.hby.pspromis.syuueki.entity.SyuPatternMst;
/**
 *
 * @author sano
 */
@Named(value = "m001Bean")
@RequestScoped
public class M001Bean extends AbstractBean {

    /**
     * 注入パターンマスタ
     */
    private SyuPatternMst syuPatternMst;

    /**
     * 注入パターンマスタ内訳
     */
    private SyuPatternItemMst syuPatternItemMst;

    /**
     * 【複写元】注入パターンマスタ
     */
    private SyuPatternMst syuPatternMstCopy;

    /**
     * 【複写元】注入パターンマスタ内訳
     */
    private SyuPatternItemMst syuPatternItemMstCopy;
    
    /**
     * ログイン者所属事業部コード
     */
    private String[] loginDivisionCode;
    
    /**
     * BUマスタ
     */
    private List<BuMst> buMstList;

    /**
     * プラント種別マスタ
     */
    private List<PlantTypeMst> plantTypeMstList;

    /**
     * 注入パターンNO
     */
    private String chunyuPtnNo;
    
    /**
     * パターン名称
     */
    private String patternName;
    
    /**
     * サブBU
     */
    private String subBu;
    
    /**
     * プラント種別
     */
    private String plantType;
    
    /**
     * 事業部コード
     */
    private String divisionCode;

    /**
     * 複写元注入パターンNO
     */
    private String sourceChunyuPtnNo;
    
    /**
     * 複写元パターン名称
     */
    private String sourceChunyuPtnName;
    
    /**
     * モード(1:登録　2:詳細　3:複写)
     */
    private String openMode;

    /**
     * 複写元注入パターンNO
     */
    private String copyChunyuPtnNo;
    
    /**
     * 期間経過時注入率10%
     */
    private String infusionRate10;
    
    /**
     * 期間経過時注入率20%
     */
    private String infusionRate20;
    
    /**
     * 期間経過時注入率30%
     */
    private String infusionRate30;
    
    /**
     * 期間経過時注入率40%
     */
    private String infusionRate40;
    
    /**
     * 期間経過時注入率50%
     */
    private String infusionRate50;
    
    /**
     * 期間経過時注入率60%
     */
    private String infusionRate60;
    
    /**
     * 期間経過時注入率70%
     */
    private String infusionRate70;
    
    /**
     * 期間経過時注入率80%
     */
    private String infusionRate80;
    
    /**
     * 期間経過時注入率90%
     */
    private String infusionRate90;
    
    /**
     * 期間経過時注入率100%
     */
    private String infusionRate100;
    
    /**
     * 登録、編集、削除実行フラグ
     */
    private String registerFlg;

    /**
     * Creates a new instance of S001Bean
     */
    public M001Bean() {
    }

    public SyuPatternMst getSyuPatternMst() {
        return syuPatternMst;
    }

    public void setSyuPatternMst(SyuPatternMst syuPatternMst) {
        this.syuPatternMst = syuPatternMst;
    }
    
    public SyuPatternItemMst getSyuPatternItemMst() {
        return syuPatternItemMst;
    }

    public void setSyuPatternItemMst(SyuPatternItemMst syuPatternItemMst) {
        this.syuPatternItemMst = syuPatternItemMst;
    }
    
    public SyuPatternMst getSyuPatternMstCopy() {
        return syuPatternMstCopy;
    }

    public void setSyuPatternMstCopy(SyuPatternMst syuPatternMstCopy) {
        this.syuPatternMstCopy = syuPatternMstCopy;
    }
    
    public SyuPatternItemMst getSyuPatternItemMstCopy() {
        return syuPatternItemMstCopy;
    }

    public void setSyuPatternItemMstCopy(SyuPatternItemMst syuPatternItemMstCopy) {
        this.syuPatternItemMstCopy = syuPatternItemMstCopy;
    }
    
    public List<BuMst> getBuMstList() {
        return buMstList;
    }

    public void setBuMstList(List<BuMst> buMstList) {
        this.buMstList = buMstList;
    }
    
    public List<PlantTypeMst> getPlantTypeMstList() {
        return this.plantTypeMstList;
    }

    public void setPlantTypeMstList(List<PlantTypeMst> plantTypeMstList) {
        this.plantTypeMstList = plantTypeMstList;
    }

    public String getChunyuPtnNo() {
        return chunyuPtnNo;
    }

    public void setChunyuPtnNo(String chunyuPtnNo) {
        this.chunyuPtnNo = chunyuPtnNo;
    }

    public String getPatternName() {
        return patternName;
    }

    public void setPatternName(String patternName) {
        this.patternName = patternName;
    }

    public String getSubBu() {
        return subBu;
    }

    public void setSubBu(String subBu) {
        this.subBu = subBu;
    }

    public String getPlantType() {
        return plantType;
    }

    public void setPlantType(String plantType) {
        this.plantType = plantType;
    }

    public String getDivisionCode() {
        return divisionCode;
    }

    public void setDivisionCode(String divisionCode) {
        this.divisionCode = divisionCode;
    }

    public String getSourceChunyuPtnNo() {
        return sourceChunyuPtnNo;
    }

    public void setSourceChunyuPtnNo(String sourceChunyuPtnNo) {
        this.sourceChunyuPtnNo = sourceChunyuPtnNo;
    }

    public String getSourceChunyuPtnName() {
        return sourceChunyuPtnName;
    }

    public void setSourceChunyuPtnName(String sourceChunyuPtnName) {
        this.sourceChunyuPtnName = sourceChunyuPtnName;
    }

    public String getOpenMode() {
        return openMode;
    }

    public void setOpenMode(String openMode) {
        this.openMode = openMode;
    }

    public String getCopyChunyuPtnNo() {
        return copyChunyuPtnNo;
    }

    public void setCopyChunyuPtnNo(String copyChunyuPtnNo) {
        this.copyChunyuPtnNo = copyChunyuPtnNo;
    }

    public String getInfusionRate10() {
        return infusionRate10;
    }

    public void setInfusionRate10(String infusionRate10) {
        this.infusionRate10 = infusionRate10;
    }

    public String getInfusionRate20() {
        return infusionRate20;
    }

    public void setInfusionRate20(String infusionRate20) {
        this.infusionRate20 = infusionRate20;
    }

    public String getInfusionRate30() {
        return infusionRate30;
    }

    public void setInfusionRate30(String infusionRate30) {
        this.infusionRate30 = infusionRate30;
    }

    public String getInfusionRate40() {
        return infusionRate40;
    }

    public void setInfusionRate40(String infusionRate40) {
        this.infusionRate40 = infusionRate40;
    }

    public String getInfusionRate50() {
        return infusionRate50;
    }

    public void setInfusionRate50(String infusionRate50) {
        this.infusionRate50 = infusionRate50;
    }

    public String getInfusionRate60() {
        return infusionRate60;
    }

    public void setInfusionRate60(String infusionRate60) {
        this.infusionRate60 = infusionRate60;
    }

    public String getInfusionRate70() {
        return infusionRate70;
    }

    public void setInfusionRate70(String infusionRate70) {
        this.infusionRate70 = infusionRate70;
    }

    public String getInfusionRate80() {
        return infusionRate80;
    }

    public void setInfusionRate80(String infusionRate80) {
        this.infusionRate80 = infusionRate80;
    }

    public String getInfusionRate90() {
        return infusionRate90;
    }

    public void setInfusionRate90(String infusionRate90) {
        this.infusionRate90 = infusionRate90;
    }

    public String getInfusionRate100() {
        return infusionRate100;
    }

    public void setInfusionRate100(String infusionRate100) {
        this.infusionRate100 = infusionRate100;
    }

    public String getRegisterFlg() {
        return registerFlg;
    }

    public void setRegisterFlg(String registerFlg) {
        this.registerFlg = registerFlg;
    }

    public String[] getLoginDivisionCode() {
        return loginDivisionCode;
    }

    public void setLoginDivisionCode(String[] loginDivisionCode) {
        this.loginDivisionCode = loginDivisionCode;
    }
}
