package jp.co.toshiba.hby.pspromis.syuueki.facade;

import java.util.List;
import javax.ejb.Stateless;
import javax.interceptor.Interceptors;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import jp.co.toshiba.hby.pspromis.syuueki.entity.ProductSonekiList;
import jp.co.toshiba.hby.pspromis.syuueki.entity.SonekiList;
import jp.co.toshiba.hby.pspromis.syuueki.interceptor.TranceInterceptor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 *
 * @author sano
 */
@Stateless
@Interceptors({TranceInterceptor.class})
public class ProductSonekiListFacade extends AbstractFacade<SonekiList> {

    /**
     * ロガ－
     */
    private static final Logger logger = LoggerFactory.getLogger(ProductSonekiListFacade.class);

    @PersistenceContext(unitName = jp.co.toshiba.hby.pspromis.syuueki.util.ConstantString.syuuekiDataSourceName)
    private EntityManager em;

    public ProductSonekiListFacade() {
        super(SonekiList.class);
    }

    @Override
    protected EntityManager getEntityManager() {
        return em;
    }

    /**
     * 工場別製番損益内訳を取得
     * @param condition
     * @return 
     */
    public List<ProductSonekiList> findList(Object condition) {
        logger.info("ProductSonekiListFacade#findList");

        List<ProductSonekiList> list = sqlExecutor.getResultList(em, ProductSonekiList.class, "/sql/S002/selectProductSonekiList.sql", condition);
        
        return list;
    }
}
