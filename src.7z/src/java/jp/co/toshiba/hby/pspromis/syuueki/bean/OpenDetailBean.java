package jp.co.toshiba.hby.pspromis.syuueki.bean;

import javax.enterprise.context.RequestScoped;
import javax.inject.Named;
import lombok.Getter;
import lombok.Setter;
/**
 *
 * @author koga
 */
@Named(value = "openDetailBean")
@RequestScoped
@Getter @Setter
public class OpenDetailBean{

    /**
     * 番号(案件ID,注番,見積番号)
     */
    private String no;

    /**
     * 区分(案件or注番or見積番号 区分
     */
    private String kbn;
    
    /**
     * 事業部コード
     */
    private String divisionCode;
    
    private String salesClass;
    
    private String ankenId;
    
    private String redirectUrl;
}