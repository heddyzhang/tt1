package jp.co.toshiba.hby.pspromis.syuueki.util;

//import org.eclipse.persistence.logging.AbstractSessionLog;
//import org.eclipse.persistence.logging.SessionLog;
//import org.eclipse.persistence.logging.SessionLogEntry;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;


//public class CustomAbstractSessionLog extends AbstractSessionLog implements SessionLog {
public class CustomAbstractSessionLog {
    
    //private static final Logger logger = LoggerFactory.getLogger(CustomAbstractSessionLog.class.getName());
    
    //Override
    //public void log(SessionLogEntry sessionLogEntry) {
    public void log() {
        //if(sessionLogEntry.getLevel()==3){
        //    logger.info(sessionLogEntry.getMessage()); // untranslated/undecoded message_id
        //}else{
        //    logger.debug(sessionLogEntry.getMessage()); // untranslated/undecoded message_id
        //}
    }
}