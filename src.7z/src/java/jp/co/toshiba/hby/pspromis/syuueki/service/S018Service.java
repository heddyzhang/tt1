package jp.co.toshiba.hby.pspromis.syuueki.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;
import javax.ejb.Stateless;
import javax.inject.Inject;
import javax.interceptor.Interceptors;
import jp.co.toshiba.hby.pspromis.common.exception.PspRunTimeExceotion;
import jp.co.toshiba.hby.pspromis.syuueki.bean.S018Bean;
import jp.co.toshiba.hby.pspromis.syuueki.enums.Label;
import jp.co.toshiba.hby.pspromis.syuueki.entity.OperationLog;
import jp.co.toshiba.hby.pspromis.syuueki.entity.SyuGeNetItemTblView;
import jp.co.toshiba.hby.pspromis.syuueki.entity.SyuKiNetCateTitleTbl;
import jp.co.toshiba.hby.pspromis.syuueki.entity.SyuGeBukkenInfoTbl;
import jp.co.toshiba.hby.pspromis.syuueki.facade.SyuGeNetItemTblViewFacade;
import jp.co.toshiba.hby.pspromis.syuueki.facade.SyuKiNetCateTitleTblFacade;
import jp.co.toshiba.hby.pspromis.syuueki.facade.SyuGeBukenInfoTblFacade;
import jp.co.toshiba.hby.pspromis.syuueki.facade.SyuKiNetCateTukiTblFacade;
import jp.co.toshiba.hby.pspromis.syuueki.facade.SyuSaNetCateTblFacade;
import jp.co.toshiba.hby.pspromis.syuueki.facade.KanjyoMstFacade;
import jp.co.toshiba.hby.pspromis.syuueki.interceptor.TranceInterceptor;
import jp.co.toshiba.hby.pspromis.syuueki.util.ConstantString;
import jp.co.toshiba.hby.pspromis.syuueki.util.EntityUtils;
import jp.co.toshiba.hby.pspromis.syuueki.util.LoginUserInfo;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
/**
 * ES-Promis収益管理システム
 * 項番カテゴリ設定 Service
 * @author 
 */
@Stateless
@Interceptors({TranceInterceptor.class})
public class S018Service {

    public static final Logger log = LoggerFactory.getLogger(S018Service.class);

    @Inject
    private S018Bean s018Bean;

    @Inject
    private LoginUserInfo loginUserInfo;

    @Inject
    private SyuGeNetItemTblViewFacade syuGeNetItemTblViewFacade;
    
    @Inject
    private SyuKiNetCateTitleTblFacade syuKiNetCateTitleTblFacade;

    @Inject
    private SyuGeBukenInfoTblFacade syuGeBukenInfoTblFacade;

    @Inject
    private SyuKiNetCateTukiTblFacade syuKiNetCateTukiTblFacade;
    
    @Inject
    private SyuSaNetCateTblFacade syuSaNetCateTblFacade;
    
    @Inject
    private KanjyoMstFacade kanjyoMstFacade;
    
    @Inject
    private OperationLogService operationLogService;
    
    @Inject
    private StoredProceduresService storedProceduresService;

    /**
     * 初期表示時機能
     * @throws Exception
     */
    public void indexExecute() throws Exception {
        SyuGeBukkenInfoTbl ankenEntity = getAnkenEntity();
        s018Bean.setDivisionCode(StringUtils.defaultString(ankenEntity.getDivisionCode()));
        
        // カテゴリ設定対象の項番一覧の検索
        findTargetOrderItem();
        
        // カテゴリの一覧を検索
        findSelectList();
        
        // 画面再表示用リストをセット
        s018Bean.setDispOrderItems(Arrays.asList(s018Bean.getOrderItems()));

    }

    /**
     * 共通の条件を作成して取得
     */
    private Map<String, Object> getBaseCondition() {
        Map<String, Object> condition = new HashMap<>();
        condition.put("ankenId", s018Bean.getAnkenId());
        condition.put("rirekiId", s018Bean.getRirekiId());
        return condition;
    }
    
    /**
     * 案件情報を取得
     */
    private SyuGeBukkenInfoTbl getAnkenEntity() {
        Map<String, Object> condition = getBaseCondition();
        SyuGeBukkenInfoTbl geEntity = syuGeBukenInfoTblFacade.findPk(condition);
        if (geEntity == null) {
            String errorMessage = Label.errorNoAnkenDate.getLabel();
            log.error(errorMessage + " ankenId=" + s018Bean.getAnkenId() + " rirekiId=" + s018Bean.getRirekiId());
            throw new PspRunTimeExceotion(errorMessage);
        }
        return geEntity;
    }
    
    /**
     * カテゴリ設定対象の項番一覧の検索
     */
    private void findTargetOrderItem() {
        // 検索条件
        Map<String, Object> condition = getBaseCondition();
        condition.put("orderItemList", Arrays.asList(s018Bean.getOrderItems()));

        // 一覧を検索
        List<SyuGeNetItemTblView> list = syuGeNetItemTblViewFacade.getSubTargetItemList(condition);

        s018Bean.setDispTargetItemList(list);
    }

    /**
     * 選択カテゴリ一覧の検索
     */
    private void findSelectList() {
        // 検索条件
        Map<String, Object> condition = getBaseCondition();

        // 一覧を検索
        List<SyuKiNetCateTitleTbl> list = syuKiNetCateTitleTblFacade.getSearchKobnCategory(condition);
        s018Bean.setDispSelectItemList(list);
    }

    /**
     * 保存処理
     * @throws java.lang.Exception
     */
    public void saveExecute() throws Exception {
        String strKobn = "";
        String strBeforeKiCategoryCode = "";
        List<String> beforeKiCategoryList = new ArrayList<String>();
        
        // 一覧情報の取得
        for (Map<String, String> currencyDataMap : s018Bean.getUpdateItemList()) {
            if(!"".equals(strKobn)){
                strKobn += ",";
                strBeforeKiCategoryCode += ",";
            }
            strKobn += currencyDataMap.get("orderItem");
            strBeforeKiCategoryCode += currencyDataMap.get("kiCategoryCode");
            
            beforeKiCategoryList.add(currencyDataMap.get("kiCategoryCode"));
        }
        
        // カテゴリ設定
        saveItemCategory(strKobn);

        // 2017/10/04NPC
        // 対象アイテムの更新前カテゴリのNETをクリアするべきか確認し、クリアすると見なしたら各NETをクリア
        // (アイテムからNETを集約する設定になっている場合、カテゴリを変更したら、変更前カテゴリと変更後カテゴリのアイテム積み上げ値がダブってしまうための処置)
        // (期間損益や最終見込画面でNETを直接入力可能なこともあり、アイテム件数が0件でもNETをクリアしないためこの処理を行う)
        clearCategoryNetSummary(beforeKiCategoryList);
        
        // (原子力)収益管理システム連携APIの実行
        // 操作ログの登録
        registOperationLog(strKobn, strBeforeKiCategoryCode);
        // 再計算（集計）パッケージ呼出
        storedProceduresService.callAnkenRecalAuto(s018Bean.getAnkenId(), s018Bean.getRirekiId(), "1");
    }

    /**
     * カテゴリ設定
     * @throws Exception
     */
    private void saveItemCategory(String strKobn) {
        log.info("selectCatgory=[{}]", s018Bean.getSelectCategoryCode());
        
        // 検索条件
        Map<String, Object> condition = getBaseCondition();
        String[] strKobnList = strKobn.split(",");
        condition.put("orderItemList", Arrays.asList(strKobnList));
        condition.put("kiCategoryCode", s018Bean.getSelectCategoryCode());
        
        // 2018/01/18 (NPC)S.Ibayashi
        // 進行基準案件の場合、進行基準まとめ用のカテゴリも設定する。
        // このカテゴリは、進行基準まとめ案件から検索したときの条件：最終カテゴリ,期間カテゴリとマッチさせる。
        condition.put("shinkoCategoryUpdateFlg", "0");
        String salesClass = syuGeBukenInfoTblFacade.getSalesClass(s018Bean.getAnkenId(), s018Bean.getRirekiId());
        if (ConstantString.salesClassS.equals(salesClass)) {
            condition.put("shinkoCategoryUpdateFlg", "1");
        }
        
        EntityUtils.setCreatedInfo(condition, loginUserInfo.getUserId());

        // 更新処理
        int intCnt = syuGeNetItemTblViewFacade.updateCategory(condition);
    }
    
    /**
     * 変更対象のカテゴリに紐づくアイテムがなくなる場合、カテゴリ単位の最終見込や最新見積の集計値をクリアする。
     */
    private void clearCategoryNetSummary(List<String> beforeKiCategoryList) {
        if (CollectionUtils.isEmpty(beforeKiCategoryList)) {
            return;
        }
        
        SyuGeBukkenInfoTbl ankenEntity = getAnkenEntity();
        String kanjyoYm = kanjyoMstFacade.getNowKanjoDate(ankenEntity.getSalesClass());
        
        for (String categoryCode: beforeKiCategoryList) {
            clearCategoryNetSummary(s018Bean.getAnkenId(), s018Bean.getRirekiId(), categoryCode, kanjyoYm);
        }
        
    }

    /**
     * 変更対象のカテゴリに紐づくアイテムがなくなる場合、カテゴリ単位の最終見込や最新見積の集計値をクリアする。
     */
    public void clearCategoryNetSummary(String ankenId, String rirekiId, String categoryCode, String kanjyoYm) {
        Map<String, Object> condition = new HashMap<>();
        condition.put("ankenId", ankenId);
        condition.put("rirekiId", rirekiId);
        condition.put("categoryCode", categoryCode);
        condition.put("kanjyoYm", kanjyoYm);
        
        String[] dataLbnList = {"JS", "JT", "MH", "SM", "FM", "PD", "PT", "PS"};
        condition.put("dataKbnList", dataLbnList);

        // カテゴリに紐づくアイテム件数を取得
        Integer categoryItemCount = syuGeNetItemTblViewFacade.countCategoryItem(condition);
        log.info("ankenId=[{}] rirekiId=[{}], kanjyoYm=[{}], categoryCode=[{}], itemCount=[{}]", ankenId, rirekiId,  kanjyoYm, categoryCode, categoryItemCount);

        // 対象カテゴリのアイテムが存在しない場合、最終見込や最新見積をクリアする
        if (categoryItemCount == 0) {
            // 期間損益画面に表示している最終見込NET・各月の見込NETをクリア
            syuKiNetCateTukiTblFacade.deleteTargetCategoryMikomiNet(condition);
            // 最終見込損益画面に表示している最新見積NET等をクリア
            syuSaNetCateTblFacade.deleteMultiDataKbnCategory(condition);
        }
    }
    
    /**
     * 操作ログの登録
     * @throws Exception
     */
    private void registOperationLog(String strKobn, String strBeforeKiCategoryCode) throws Exception{
        OperationLog operationLog = operationLogService.getOperationLog();

//        String objectType = operationLogService.getObjectType(s016Bean.getProcId());
        String objectType = operationLogService.getObjectType("S005");
        
        operationLog.setOperationCode("SET_KOUBAN_CATEGORY");
        operationLog.setObjectId(20);
        operationLog.setObjectType(objectType);
        operationLog.setRemarks(s018Bean.getAnkenId()); // 備考1(引数.物件Key)
        operationLog.setRemarks2(strKobn); // 備考2(項番)
        operationLog.setRemarks3(s018Bean.getSelectCategoryCode()); // 備考3(設定したCATEGORY_CODE)
        operationLog.setRemarks4(strBeforeKiCategoryCode); // 備考4(設定する前のCATEGORY_CODE)

        operationLogService.insertOperationLogSearch(operationLog);
    }

}
