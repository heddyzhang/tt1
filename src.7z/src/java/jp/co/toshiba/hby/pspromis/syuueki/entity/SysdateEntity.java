package jp.co.toshiba.hby.pspromis.syuueki.entity;

import java.io.Serializable;
import java.util.Date;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.NotNull;

/**
 *
 * @author ibayashi
 */
@Entity
public class SysdateEntity implements Serializable {
    private static final long serialVersionUID = 1L;
    @NotNull
    @Column(name = "SYS_DATE")
    @Id
    @Temporal(TemporalType.TIMESTAMP)
    private Date sysdate;

    public Date getSysdate() {
        return sysdate;
    }

    public void setSysdate(Date sysdate) {
        this.sysdate = sysdate;
    }

}
