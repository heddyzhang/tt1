package jp.co.toshiba.hby.pspromis.syuueki.service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.ejb.Stateless;
import javax.inject.Inject;
import javax.interceptor.Interceptors;
import jp.co.toshiba.hby.pspromis.syuueki.bean.K002Bean;
import jp.co.toshiba.hby.pspromis.syuueki.entity.Es88051Tbl;
import jp.co.toshiba.hby.pspromis.syuueki.facade.StchMstFacade;
import jp.co.toshiba.hby.pspromis.syuueki.interceptor.TranceInterceptor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * PS-Promis収益管理システム
 * 設置場所選択 Service
 * @author (NPC)S.horie
 */
@Stateless
@Interceptors({TranceInterceptor.class})
public class K002Service {

    public static final Logger logger = LoggerFactory.getLogger(K002Service.class);

    @Inject
    private K002Bean k002Bean;

    @Inject
    private StchMstFacade stchMstFacade;

    /**
     * 検索条件用Mapを作成
     */
    private Map getCondition() {
        Map<String, Object> condition = new HashMap<>();

        // 設置場所名称
        condition.put("stchName", k002Bean.getStchName());
        // 設置場所コード(Step3追加)
        condition.put("stchCode", k002Bean.getStchCode());
        
        return condition;
    }

    /**
     * 初期表示時機能
     * @throws Exception
     */
    public void indexExecute() throws Exception {
        searchExecute();
    }

    /**
     * 検索機能
     * @throws Exception
     */
    
    public void searchExecute() throws Exception {
        // ページ切り替えか否かを判定
        boolean isPageing = true;
        if (k002Bean.getPage() == null || k002Bean.getPage() <= 0) {
            isPageing = false;
            k002Bean.setPage(1);
        }

        // 検索条件をセット
        //SyuBukenInfoTblFacade facade = getSyuuekiFacade();
        Map condition = getCondition();
        
        if (!isPageing) {
            // 検索ボタン
            condition.put("listFlg", "1");
            getListCount(condition);
        }

       if (k002Bean.getCount() > 0) {
           stchListExecute(condition);
       }
    }

    /**
     * 設置先場所データ一覧取得
     * @throws Exception 
     */
    public void stchListExecute(Map condition) throws Exception {
        // STCH一覧データ取得
        List<Es88051Tbl> stchList = stchMstFacade.getList(condition, k002Bean.getPage());

        // 取得データをbeanにセット
        k002Bean.setStchList(stchList);
    }

    /**
     * 一覧データの件数を取得
     * @throws Exception
     */
    public void getListCount(Map condition) throws Exception {
        // リクエストパラメータをfacadeに設定
        //EmpViewFacade empViewFacade = getEmpViewFacade();

        // 一覧データ件数を取得
        Integer count = stchMstFacade.getCount(condition);

        // 取得データをbeanにセット
        k002Bean.setCount(count);
    }

}
