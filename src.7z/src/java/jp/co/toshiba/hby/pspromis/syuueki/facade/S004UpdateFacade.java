/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package jp.co.toshiba.hby.pspromis.syuueki.facade;

import javax.ejb.Stateless;
import javax.inject.Inject;
import javax.interceptor.Interceptors;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import jp.co.toshiba.hby.pspromis.syuueki.interceptor.TranceInterceptor;
import jp.co.toshiba.hby.pspromis.common.jdbc.SqlExecutor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 *
 * @author sano
 */
@Stateless
@Interceptors({TranceInterceptor.class})
public class S004UpdateFacade {
    
    /**
     * ロガ－
     */
    private static final Logger logger = LoggerFactory.getLogger(S004UpdateFacade.class);

    @PersistenceContext(unitName = jp.co.toshiba.hby.pspromis.syuueki.util.ConstantString.syuuekiDataSourceName)
    private EntityManager em;

    @Inject
    protected SqlExecutor sqlExecutor;

    public S004UpdateFacade() {
    }
    
    /**
     * 契約金額補正の更新
     * 
     * @param condition 
     */
    public int updateContractAmount(Object condition){
        logger.info("S004UpdateFacade#updateContractAmount");

        return sqlExecutor.executeUpdateSql(em, "/sql/S004/updateKeiyakuAmount.sql", condition);
    }
    
    /**
     * 見積総原価の更新
     * 
     * @param condition 
     */
    public int updateCurrencyCost(Object condition){
        logger.info("S004UpdateFacade#updateCurrencyCost");

        return sqlExecutor.executeUpdateSql(em, "/sql/S004/updateSougenka.sql", condition);
    }
    
    /**
     * 売上原価内訳の更新
     * 
     * @param condition 
     */
    public int updateSaleCostDetail(Object condition){
        logger.info("S004UpdateFacade#updateSaleCostDetail");

        return sqlExecutor.executeUpdateSql(em, "/sql/S004/updateNet.sql", condition);
    }
    
    /**
     * 回収金額の更新
     * 
     * @param condition 
     */
    public int updateRecoveryAmount(Object condition){
        logger.info("S004UpdateFacade#updateRecoveryAmount");

        return sqlExecutor.executeUpdateSql(em, "/sql/S004/updateKaisyuAmount.sql", condition);
    }
    
    /**
     * 回収金額の更新
     * 
     * @param condition 
     */
    public int updateRecoveryJissekiAmount(Object condition){
        logger.info("S004UpdateFacade#updateJissekiRecoveryAmount");

        return sqlExecutor.executeUpdateSql(em, "/sql/S004/updateKaisyuJissekiAmount.sql", condition);
    }
    
    /**
     * 契約金額補正の登録
     * 
     * @param condition 
     */
    public int insertContractAmount(Object condition){
        logger.info("S004UpdateFacade#insertContractAmount");

        return sqlExecutor.executeUpdateSql(em, "/sql/S004/insertKeiyakuAmount.sql", condition);
    }
    
    /**
     * 見積総原価の登録
     * 
     * @param condition 
     */
    public int insertCurrencyCost(Object condition){
        logger.info("S004UpdateFacade#insertCurrencyCost");

        return sqlExecutor.executeUpdateSql(em, "/sql/S004/insertSougenka.sql", condition);
    }
    
    /**
     * 売上原価内訳の登録
     * 
     * @param condition 
     */
    public int insertSaleCostDetail(Object condition){
        logger.info("S004UpdateFacade#insertSaleCostDetail");

        return sqlExecutor.executeUpdateSql(em, "/sql/S004/insertNet.sql", condition);
    }
    
    /**
     * 回収金額の登録
     * 
     * @param condition 
     */
    public int insertRecoveryAmount(Object condition){
        logger.info("S004UpdateFacade#insertRecoveryAmount");

        return sqlExecutor.executeUpdateSql(em, "/sql/S004/insertKaisyuAmount.sql", condition);
    }
    
    /**
     * 回収金額の登録
     * 
     * @param condition 
     */
    public int insertRecoveryJissekiAmount(Object condition){
        logger.info("S004UpdateFacade#insertRecoveryJissekiAmount");

        return sqlExecutor.executeUpdateSql(em, "/sql/S004/insertKaisyuJissekiAmount.sql", condition);
    }
    
    /**
     * 収益物件の更新
     * 
     * @param condition 
     */
    public int updateSyuekiBukken(Object condition){
        logger.info("S004UpdateFacade#updateSyuekiBukken");

        return sqlExecutor.executeUpdateSql(em, "/sql/S004/updateSyuekiBukken.sql", condition);
    }
}
