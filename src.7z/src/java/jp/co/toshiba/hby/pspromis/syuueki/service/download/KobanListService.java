package jp.co.toshiba.hby.pspromis.syuueki.service.download;

import java.math.BigDecimal;
import jp.co.toshiba.hby.pspromis.syuueki.service.*;
import java.util.Date;
import java.util.List;
import java.util.Map;
import javax.ejb.Stateless;
import javax.inject.Inject;
import javax.interceptor.Interceptors;
import jp.co.toshiba.hby.pspromis.syuueki.bean.S005Bean;
import jp.co.toshiba.hby.pspromis.syuueki.entity.OperationLog;
import jp.co.toshiba.hby.pspromis.syuueki.entity.SyuGeBukkenInfoTbl;
import jp.co.toshiba.hby.pspromis.syuueki.entity.SyuGeNetItemTblView;
import jp.co.toshiba.hby.pspromis.syuueki.enums.Label;
import jp.co.toshiba.hby.pspromis.syuueki.facade.SysdateEntityFacade;
import jp.co.toshiba.hby.pspromis.syuueki.facade.SyuGeNetItemTblViewFacade;
import jp.co.toshiba.hby.pspromis.syuueki.interceptor.TranceInterceptor;
import jp.co.toshiba.hby.pspromis.syuueki.pages.DetailHeader;
import jp.co.toshiba.hby.pspromis.syuueki.util.LoginUserInfo;
import jp.co.toshiba.hby.pspromis.syuueki.util.PoiUtil;
import jp.co.toshiba.hby.pspromis.syuueki.util.SyuuekiUtils;
import jp.co.toshiba.hby.pspromis.syuueki.util.Utils;
import org.apache.commons.lang3.StringUtils;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
/**
 * PS-Promis収益管理システム
 * 項番一覧（期間）Excelダウンロード Service
 * @author (NPC)Y.Kitajima
 */
@Stateless
@Interceptors({TranceInterceptor.class})
public class KobanListService {
    
    private final String dispChunyu         = "0"; // 表示内容：注入
    private final String dispUriage         = "1"; // 表示内容：売上
    private final String dispSeibanSoneki   = "2"; // 表示内容：製番損益
    
    @Inject
    private LoginUserInfo loginUserInfo;
    
    @Inject
    private OperationLogService operationLogService;
    
    @Inject
    private SysdateEntityFacade sysdateFacade;
    
    @Inject
    private SyuGeNetItemTblViewFacade syuGeNetItemTblViewFacade;
    
    @Inject
    private S005Bean s005Bean;
    
    @Inject
    private DetailHeader dateilHeader;
    
    @Inject
    private S005Service s005Service;
    
    @Inject
    private SyuuekiUtils sUtils;

    
    /**
     * ロガー
     */
    public static final Logger logger = LoggerFactory.getLogger(KobanListService.class);
    
    /**
     * 操作ログの登録
     * @throws Exception
     */
    public void registOperationLog() throws Exception{
        OperationLog operationLog = this.operationLogService.getOperationLog();

        operationLog.setOperationCode("DL_JOB");
        operationLog.setObjectId(10);
        operationLog.setObjectType("KOUBAN");
        operationLog.setRemarks(s005Bean.getAnkenId());
        //operationLogService.insertOperationLogSearch(operationLog);
        
        operationLogService.insertOperationLogSearch(operationLog);
    }


    /**
     * Excelダウンロードのデータ埋め込み(一括ダウンロードより実行)
     * @param workbook
     * @param param
     * @throws Exception
     */
    public void outputDownloadExcel(Workbook workbook, S005Bean param) throws Exception {
        s005Bean = param;
        outputDownloadExcel(workbook);
    }
    
    /**
     * Excelダウンロードのデータ埋め込み
     * @param workbook
     * @throws Exception
     */
    public void outputDownloadExcel(Workbook workbook) throws Exception {
        // インスタンス変数を全て初期化
        //initInstanceValue();

        // 物件基本情報を取得(ヘッダ部＋履歴管理・備考部＋勘定月の取得)
        s005Service.findAnkenInfo();

        // 一括出力の場合は検索条件を初期化しておく
        if(s005Bean.isIsIkkatsuFlg()) {
            s005Service.initCondition();
        }
        
        // 表示内容がNULLの場合は、「売上」をセット ⇒s005Service.initCondition()内でセット
//        if (StringUtils.isEmpty(s005Bean.getDispKbn())) {
//            s005Bean.setDispKbn(dispUriage);
//        }
        
        // 勘定月から現在の期を取得
        String nowKikan = dateilHeader.getDefaultKikan(s005Bean.getKikanFromList());
        logger.info("nowKikan=" + nowKikan);
        logger.info("s005Bean.getKikanForm()=" +  s005Bean.getKikanForm());
        // 画面に表示する値をbeanにセット(期間(FROM))
        if (StringUtils.isEmpty(s005Bean.getKikanForm())) {
            s005Bean.setKikanForm(nowKikan);
        }
        
        // 期間をセット
        s005Service.setKikan();

        // シート取得
        Sheet sheet = workbook.getSheet("koban_list");
        // スタイルコピー用シートを取得
        Sheet styleSheet = workbook.getSheet("koban_style");
        
        SyuGeBukkenInfoTbl ankenEntity = dateilHeader.getAnkenEntity();
        
        // シート名の設定
        final String sheetName = StringUtils.defaultString(ankenEntity.getOrderNo()) + "_" + Label.getValue(Label.excelSheetKoban);      
        workbook.setSheetName(workbook.getSheetIndex(sheet), sheetName);
        
        // ヘッダ情報をセット
        setHeadData(sheet);
        
        // ヘッダ部の合計値をセット
        setSumData(sheet);
        
        // 一覧項目のデータ
        setListData(sheet, styleSheet);

        String poten = StringUtils.defaultString(ankenEntity.getPotentialFlg(), "0");
        
        if(!poten.equals("1")){
            sheet.setColumnWidth(53, 0);
            sheet.setColumnWidth(54, 0);
            sheet.setColumnWidth(55, 0);
            sheet.setColumnWidth(56, 0);
            sheet.setColumnWidth(57, 0);
            sheet.setColumnWidth(58, 0);
            sheet.setColumnWidth(59, 0);
            sheet.setColumnWidth(60, 0);
            sheet.setColumnWidth(61, 0);
            sheet.setColumnWidth(62, 0);
            sheet.setColumnWidth(63, 0);
            sheet.setColumnWidth(64, 0);
        }
        
        // スタイルコピー用シートの削除
        workbook.removeSheetAt(workbook.getSheetIndex(styleSheet));
        
        // 操作ログへの書き込み
        // (案件一覧の一括出力処理から出力した場合はここでのログ書き込みは行わない)
        if (!s005Bean.isIsIkkatsuFlg()) {
            registOperationLog();
        }
    }
    
    /**
     * ヘッダ情報のデータ埋め込み
     */
    private void setHeadData(Sheet sheet) throws Exception {
        
        // 年月行
        Integer ymRow = 3;
        // 「残」下の項目 AND "実績"or"見込"行
        Integer dispKbnRow = 4;
        
        // 出力日時取得
        Date now = sysdateFacade.getSysdate();
        
        ////// ヘッダ情報セット
        //// ログイン者名
        PoiUtil.setCellValue(sheet, 0, 1, loginUserInfo.getUserName());
        //// 現在日時
        PoiUtil.setCellValue(sheet, 0, 3, now);
        
        //// 表示内容
        String dispName = "";
        String zanLabel = "";
        switch (s005Bean.getDispKbn()) {
            case dispChunyu:
                dispName = Label.getValue(Label.chunyu);
                zanLabel = Label.getValue(Label.mikomi) + "-" + Label.getValue(Label.chunyu);
                break;
            case dispUriage:
                dispName = Label.getValue(Label.uriage);
                zanLabel = Label.getValue(Label.hatsuban) + "-" + Label.getValue(Label.uriage);
                break;
            case dispSeibanSoneki:
                dispName = Label.getValue(Label.seibanSoneki);
                break;
            default: break;    
        }
        PoiUtil.setCellValue(sheet, 1, 1, dispName);

        // 前回確定NET
        String zen = Label.labelBefFixedNet.getLabel();
        if(StringUtils.isNotEmpty(s005Bean.getBefMonth())){
            zen = zen + "(" + s005Bean.getBefMonth() + ")";
        }
        PoiUtil.setCellValue(sheet, ymRow, 14, zen);
        
        //最終見込　前回値(yyyy/mm時点)
        String ziten = Label.lastMikomi.getLabel() + "　" + Label.previousValue.getLabel();
        if(StringUtils.isNotEmpty(s005Bean.getBefMonth())){
            ziten = ziten + "(" + s005Bean.getBefMonth() + Label.labelZiten.getLabel() + ")";
        }
        PoiUtil.setCellValue(sheet, ymRow, 45, ziten);
        
        // 「残」の下に項目名をセット
        PoiUtil.setCellValue(sheet, dispKbnRow, 83, zanLabel);
        
        // 年月の埋め込み
        Integer ymStartCol = 84;
        Integer colIdx = 0;
        
        PoiUtil.setCellValue(sheet, ymRow, ymStartCol+colIdx, sUtils.getLabelMonth(s005Bean.getKikan01()));
        colIdx++;
        PoiUtil.setCellValue(sheet, ymRow, ymStartCol+colIdx, sUtils.getLabelMonth(s005Bean.getKikan02()));
        colIdx++;
        PoiUtil.setCellValue(sheet, ymRow, ymStartCol+colIdx, sUtils.getLabelMonth(s005Bean.getKikan03()));
        colIdx++;
        PoiUtil.setCellValue(sheet, ymRow, ymStartCol+colIdx, sUtils.getLabelMonth(s005Bean.getKikan04()));
        colIdx++;
        PoiUtil.setCellValue(sheet, ymRow, ymStartCol+colIdx, sUtils.getLabelMonth(s005Bean.getKikan05()));
        colIdx++;
        PoiUtil.setCellValue(sheet, ymRow, ymStartCol+colIdx, sUtils.getLabelMonth(s005Bean.getKikan06()));
        colIdx++;
        PoiUtil.setCellValue(sheet, ymRow, ymStartCol+colIdx, sUtils.kikanLabel(s005Bean.getKikanForm()));
        colIdx++;
        PoiUtil.setCellValue(sheet, ymRow, ymStartCol+colIdx, sUtils.getLabelMonth(s005Bean.getKikan07()));
        colIdx++;
        PoiUtil.setCellValue(sheet, ymRow, ymStartCol+colIdx, sUtils.getLabelMonth(s005Bean.getKikan08()));
        colIdx++;
        PoiUtil.setCellValue(sheet, ymRow, ymStartCol+colIdx, sUtils.getLabelMonth(s005Bean.getKikan09()));
        colIdx++;
        PoiUtil.setCellValue(sheet, ymRow, ymStartCol+colIdx, sUtils.getLabelMonth(s005Bean.getKikan10()));
        colIdx++;
        PoiUtil.setCellValue(sheet, ymRow, ymStartCol+colIdx, sUtils.getLabelMonth(s005Bean.getKikan11()));
        colIdx++;
        PoiUtil.setCellValue(sheet, ymRow, ymStartCol+colIdx, sUtils.getLabelMonth(s005Bean.getKikan12()));
        colIdx++;
        PoiUtil.setCellValue(sheet, ymRow, ymStartCol+colIdx, sUtils.kikanLabel(sUtils.calcKikan(s005Bean.getKikanForm(), 1)));
        
        // 実績or見込の埋め込み
        colIdx = 0;
        PoiUtil.setCellValue(sheet, dispKbnRow, ymStartCol+colIdx, sUtils.getJYLabel(dateilHeader.getKanjoDate(), s005Bean.getKikan01()));
        colIdx++;
        PoiUtil.setCellValue(sheet, dispKbnRow, ymStartCol+colIdx, sUtils.getJYLabel(dateilHeader.getKanjoDate(), s005Bean.getKikan02()));
        colIdx++;
        PoiUtil.setCellValue(sheet, dispKbnRow, ymStartCol+colIdx, sUtils.getJYLabel(dateilHeader.getKanjoDate(), s005Bean.getKikan03()));
        colIdx++;
        PoiUtil.setCellValue(sheet, dispKbnRow, ymStartCol+colIdx, sUtils.getJYLabel(dateilHeader.getKanjoDate(), s005Bean.getKikan04()));
        colIdx++;
        PoiUtil.setCellValue(sheet, dispKbnRow, ymStartCol+colIdx, sUtils.getJYLabel(dateilHeader.getKanjoDate(), s005Bean.getKikan05()));
        colIdx++;
        PoiUtil.setCellValue(sheet, dispKbnRow, ymStartCol+colIdx, sUtils.getJYLabel(dateilHeader.getKanjoDate(), s005Bean.getKikan06()));
        colIdx++;
        PoiUtil.setCellValue(sheet, dispKbnRow, ymStartCol+colIdx, sUtils.getJYLabel(dateilHeader.getKanjoDate(), s005Bean.getKikan06()));
        colIdx++;
        PoiUtil.setCellValue(sheet, dispKbnRow, ymStartCol+colIdx, sUtils.getJYLabel(dateilHeader.getKanjoDate(), s005Bean.getKikan07()));
        colIdx++;
        PoiUtil.setCellValue(sheet, dispKbnRow, ymStartCol+colIdx, sUtils.getJYLabel(dateilHeader.getKanjoDate(), s005Bean.getKikan08()));
        colIdx++;
        PoiUtil.setCellValue(sheet, dispKbnRow, ymStartCol+colIdx, sUtils.getJYLabel(dateilHeader.getKanjoDate(), s005Bean.getKikan09()));
        colIdx++;
        PoiUtil.setCellValue(sheet, dispKbnRow, ymStartCol+colIdx, sUtils.getJYLabel(dateilHeader.getKanjoDate(), s005Bean.getKikan10()));
        colIdx++;
        PoiUtil.setCellValue(sheet, dispKbnRow, ymStartCol+colIdx, sUtils.getJYLabel(dateilHeader.getKanjoDate(), s005Bean.getKikan11()));
        colIdx++;
        PoiUtil.setCellValue(sheet, dispKbnRow, ymStartCol+colIdx, sUtils.getJYLabel(dateilHeader.getKanjoDate(), s005Bean.getKikan12()));
        colIdx++;
        PoiUtil.setCellValue(sheet, dispKbnRow, ymStartCol+colIdx, sUtils.getJYLabel(dateilHeader.getKanjoDate(), s005Bean.getKikan12()));
        
    }

    
    /**
     * 合計値のデータ埋め込み
     */
    private void setSumData(Sheet sheet) throws Exception {
        
        // 合計値行
        Integer sumRow = 2;

        // 検索条件をセット
        Map<String, Object> condition = s005Service.getCondition();
        condition.put("listFlg", "1");
        condition.put("kikanFlg", "1");
        condition.put("saishuFlg", "1");
        // 合計値の取得
        SyuGeNetItemTblView totalResultEntity = syuGeNetItemTblViewFacade.getItemSum(condition);
        
        // 発番NET(円合価)
        PoiUtil.setCellValue(sheet, sumRow, 12, convBigDecimal(totalResultEntity.getHatNet()));
        // 前回NET(yyyy/mm)
        PoiUtil.setCellValue(sheet, sumRow, 14, convBigDecimal(totalResultEntity.getHatNetBef()));
        // 当初見込(受政)
        PoiUtil.setCellValue(sheet, sumRow, 17, convBigDecimal(totalResultEntity.getJuseiEnka()));
        // 受注(契約時)
        PoiUtil.setCellValue(sheet, sumRow, 21, convBigDecimal(totalResultEntity.getJutyuEnka()));
        // 目標NET
        PoiUtil.setCellValue(sheet, sumRow, 25, convBigDecimal(totalResultEntity.getMokuhyoEnka()));
        // 最新見積
        PoiUtil.setCellValue(sheet, sumRow, 29, convBigDecimal(totalResultEntity.getSaishinmitumoriEnka()));
        // 設定査定
        PoiUtil.setCellValue(sheet, sumRow, 33, convBigDecimal(totalResultEntity.getSekeisateiEnka()));
        // 調達査定
        PoiUtil.setCellValue(sheet, sumRow, 37, convBigDecimal(totalResultEntity.getChotatusateiEnka()));
        // 最終見込(今回値)
        PoiUtil.setCellValue(sheet, sumRow, 41, convBigDecimal(totalResultEntity.getFixedMikomiNet()));
        // 最終見込(前回値)
        PoiUtil.setCellValue(sheet, sumRow, 45, convBigDecimal(totalResultEntity.getFixedMikomiNetBef()));
        // 最終見込(前回差)
        PoiUtil.setCellValue(sheet, sumRow, 49, sUtils.arari(convBigDecimal(totalResultEntity.getFixedMikomiNet()), convBigDecimal(totalResultEntity.getFixedMikomiNetBef())));
        // ポテンシャル値　大
        PoiUtil.setCellValue(sheet, sumRow, 53, convBigDecimal(totalResultEntity.getPotenDaiEnka()));
        // ポテンシャル値　中
        PoiUtil.setCellValue(sheet, sumRow, 57, convBigDecimal(totalResultEntity.getPotenTyuEnka()));
        // ポテンシャル値　小
        PoiUtil.setCellValue(sheet, sumRow, 61, convBigDecimal(totalResultEntity.getPotenShoEnka()));
        // 実績累計：注入累計
        PoiUtil.setCellValue(sheet, sumRow, 65, convBigDecimal(totalResultEntity.getCyunyuNet()));
        // 実績累計：製番損益累計
        PoiUtil.setCellValue(sheet, sumRow, 66, convBigDecimal(totalResultEntity.getSeibanSonekiNet()));
        // 実績累計：売上累計
        PoiUtil.setCellValue(sheet, sumRow, 67, convBigDecimal(totalResultEntity.getUriageNet()));
        // 発注金額
        PoiUtil.setCellValue(sheet, sumRow, 69, convBigDecimal(totalResultEntity.getHachuEnka()));
        // 検収済累計
        PoiUtil.setCellValue(sheet, sumRow, 74, convBigDecimal(totalResultEntity.getUriageNet()));
        // 未検収累計
        PoiUtil.setCellValue(sheet, sumRow, 78, convBigDecimal(totalResultEntity.getHachuEnka()));
        // 発注外貨
        //PoiUtil.setCellValue(sheet, sumRow, 15, totalResultEntity.getHachuAmount());
        // 残　見込-注入　発番-売上
        BigDecimal zanMikomi = null;
        if (dispChunyu.equals(s005Bean.getDispKbn())) {
            if ( !(totalResultEntity.getFixedMikomiNet() == null && totalResultEntity.getCyunyuNet() == null)) {
                zanMikomi = sUtils.arari(convBigDecimal(totalResultEntity.getFixedMikomiNet()), convBigDecimal(totalResultEntity.getCyunyuNet()));
            }
        } else if (dispUriage.equals(s005Bean.getDispKbn())) {
            if ( !(totalResultEntity.getHatNet() == null && totalResultEntity.getUriageNet() == null)) {
               zanMikomi = sUtils.arari(convBigDecimal(totalResultEntity.getHatNet()), convBigDecimal(totalResultEntity.getUriageNet()));
            }
        }
        PoiUtil.setCellValue(sheet, sumRow, 83, zanMikomi);

        // 各月
        PoiUtil.setCellValue(sheet, sumRow, 84, convBigDecimal(totalResultEntity.getNet01()));
        PoiUtil.setCellValue(sheet, sumRow, 85, convBigDecimal(totalResultEntity.getNet02()));
        PoiUtil.setCellValue(sheet, sumRow, 86, convBigDecimal(totalResultEntity.getNet03()));
        PoiUtil.setCellValue(sheet, sumRow, 87, convBigDecimal(totalResultEntity.getNet04()));
        PoiUtil.setCellValue(sheet, sumRow, 88, convBigDecimal(totalResultEntity.getNet05()));
        PoiUtil.setCellValue(sheet, sumRow, 89, convBigDecimal(totalResultEntity.getNet06()));
        PoiUtil.setCellValue(sheet, sumRow, 90, convBigDecimal(totalResultEntity.getNetFrom()));
        PoiUtil.setCellValue(sheet, sumRow, 91, convBigDecimal(totalResultEntity.getNet07()));
        PoiUtil.setCellValue(sheet, sumRow, 92, convBigDecimal(totalResultEntity.getNet08()));
        PoiUtil.setCellValue(sheet, sumRow, 93, convBigDecimal(totalResultEntity.getNet09()));
        PoiUtil.setCellValue(sheet, sumRow, 94, convBigDecimal(totalResultEntity.getNet10()));
        PoiUtil.setCellValue(sheet, sumRow, 95, convBigDecimal(totalResultEntity.getNet11()));
        PoiUtil.setCellValue(sheet, sumRow, 96, convBigDecimal(totalResultEntity.getNet12()));
        PoiUtil.setCellValue(sheet, sumRow, 97, convBigDecimal(totalResultEntity.getNetTo()));
        // 各月合計
        PoiUtil.setCellValue(sheet, sumRow, 98, convBigDecimal(totalResultEntity.getNetG()));
    }
    
    
    
    /**
     * 一覧データの埋め込み
     */
    private void setListData(Sheet sheet, Sheet styleSheet) throws Exception {
        
        // 一覧データ描画開始行
        Integer dataStartRow = 5;
        // 一覧データ描画開始列
        Integer dataStartCol = 0;
        Integer colIdx = 0;
        
        // コピー元のセルスタイル行
        Row styleRow = PoiUtil.getRow(styleSheet, 2, true);
        // コピー元のセルスタイル行（発番区分：D 用）
        Row styleRowD = PoiUtil.getRow(styleSheet, 4, true);
        
        
        // 検索条件をセット
        Map<String, Object> condition = s005Service.getCondition();
        condition.put("kikanFlg", "1");
        condition.put("saishuFlg", "1");
        condition.put("zenkaiId", s005Bean.getZenkaiId());
        condition.put("editFlg", "0");
        
        // 一覧出力データを取得
        List<SyuGeNetItemTblView> SyuGeNetList = syuGeNetItemTblViewFacade.getItemList(condition);
        
        if (SyuGeNetList.isEmpty()) {
            return;
        }
        
        for (int index=0; index<SyuGeNetList.size(); index++) {
            colIdx = 0;
            SyuGeNetItemTblView SyuGeNetItem = SyuGeNetList.get(index);
            
            // 注番
            PoiUtil.setCellValue(sheet, dataStartRow+index, dataStartCol+colIdx, SyuGeNetItem.getOrderNo());
            colIdx++;
            // 製番記号
            PoiUtil.setCellValue(sheet, dataStartRow+index, dataStartCol+colIdx, SyuGeNetItem.getSeiban());
            colIdx++;
            // 項番
            PoiUtil.setCellValue(sheet, dataStartRow+index, dataStartCol+colIdx, SyuGeNetItem.getOrderItem());
            colIdx++;
            // 発番
            String hat = "";
            if("1".equals(SyuGeNetItem.getMikomiFlg())){
                hat = Label.mikomi.getLabel();
            } else {
                hat = Label.hatsuban.getLabel() + Label.end.getLabel();
            }
            
            PoiUtil.setCellValue(sheet, dataStartRow+index, dataStartCol+colIdx, hat);
            colIdx++;
            // 品名
            PoiUtil.setCellValue(sheet, dataStartRow+index, dataStartCol+colIdx, SyuGeNetItem.getHinmei());
            colIdx++;
            //製番納期
            PoiUtil.setCellValue(sheet, dataStartRow+index, dataStartCol+colIdx, sUtils.exeFormatYmd(SyuGeNetItem.getSeibanNoki()));
            colIdx++;
            //(期間)カテゴリ1
            PoiUtil.setCellValue(sheet, dataStartRow+index, dataStartCol+colIdx, SyuGeNetItem.getKiCategoryName1());
            colIdx++;
            //(期間)カテゴリ2
            PoiUtil.setCellValue(sheet, dataStartRow+index, dataStartCol+colIdx, SyuGeNetItem.getKiCategoryName2());
            colIdx++;
            //(最終)カテゴリ1
            PoiUtil.setCellValue(sheet, dataStartRow+index, dataStartCol+colIdx, SyuGeNetItem.getSaCategoryName1());
            colIdx++;
            //(最終)カテゴリ2
            PoiUtil.setCellValue(sheet, dataStartRow+index, dataStartCol+colIdx, SyuGeNetItem.getSaCategoryName2());
            colIdx++;
            // 技術部課
            PoiUtil.setCellValue(sheet, dataStartRow+index, dataStartCol+colIdx, SyuGeNetItem.getGiBukaName());
            colIdx++;
            // 設計部課
            PoiUtil.setCellValue(sheet, dataStartRow+index, dataStartCol+colIdx, SyuGeNetItem.getSekkeiBukaName());
            colIdx++;
            // 発番NET
            PoiUtil.setCellValue(sheet, dataStartRow+index, dataStartCol+colIdx, convBigDecimal(SyuGeNetItem.getHatNet()));
            colIdx++;
            // 単記
            PoiUtil.setCellValue(sheet, dataStartRow+index, dataStartCol+colIdx, SyuGeNetItem.getHatTanka());
            colIdx++;
            // 前回確定NET
            PoiUtil.setCellValue(sheet, dataStartRow+index, dataStartCol+colIdx, convBigDecimal(SyuGeNetItem.getHatNetBef()));
            colIdx++;
            // 単記
            PoiUtil.setCellValue(sheet, dataStartRow+index, dataStartCol+colIdx, SyuGeNetItem.getHatNetBefTanka());
            colIdx++;
            // 前回差
            PoiUtil.setCellValue(sheet, dataStartRow+index, dataStartCol+colIdx, sUtils.arari(convBigDecimal(SyuGeNetItem.getHatNet()), convBigDecimal(SyuGeNetItem.getHatNetBef())));
            colIdx++;
            //当初見込(受政)　円価
            PoiUtil.setCellValue(sheet, dataStartRow+index, dataStartCol+colIdx, convBigDecimal(SyuGeNetItem.getJuseiEnka()));
            colIdx++;
            //当初見込(受政)　通貨
            PoiUtil.setCellValue(sheet, dataStartRow+index, dataStartCol+colIdx, SyuGeNetItem.getJuseiCurrencyCode());
            colIdx++;
            //当初見込(受政)　レート
            PoiUtil.setCellValue(sheet, dataStartRow+index, dataStartCol+colIdx, convBigDecimal(SyuGeNetItem.getJuseiRate()));
            colIdx++;
            //当初見込(受政)　外貨
            PoiUtil.setCellValue(sheet, dataStartRow+index, dataStartCol+colIdx, convBigDecimal(SyuGeNetItem.getJuseiGaika()));
            colIdx++;
            //受注(契約時)　円価
            PoiUtil.setCellValue(sheet, dataStartRow+index, dataStartCol+colIdx, convBigDecimal(SyuGeNetItem.getJutyuEnka()));
            colIdx++;
            //受注(契約時)　通貨
            PoiUtil.setCellValue(sheet, dataStartRow+index, dataStartCol+colIdx, SyuGeNetItem.getJutyuCurrencyCode());
            colIdx++;
            //受注(契約時)　レート
            PoiUtil.setCellValue(sheet, dataStartRow+index, dataStartCol+colIdx, convBigDecimal(SyuGeNetItem.getJutyuRate()));
            colIdx++;
            //受注(契約時)　外貨
            PoiUtil.setCellValue(sheet, dataStartRow+index, dataStartCol+colIdx, convBigDecimal(SyuGeNetItem.getJutyuGaika()));
            colIdx++;
            //目標NET　円価
            PoiUtil.setCellValue(sheet, dataStartRow+index, dataStartCol+colIdx, convBigDecimal(SyuGeNetItem.getMokuhyoEnka()));
            colIdx++;
            //目標NET　通貨
            PoiUtil.setCellValue(sheet, dataStartRow+index, dataStartCol+colIdx, SyuGeNetItem.getMokuhyoCurrencyCode());
            colIdx++;
            //目標NET　レート
            PoiUtil.setCellValue(sheet, dataStartRow+index, dataStartCol+colIdx, convBigDecimal(SyuGeNetItem.getMokuhyoRate()));
            colIdx++;
            //目標NET　外貨
            PoiUtil.setCellValue(sheet, dataStartRow+index, dataStartCol+colIdx, convBigDecimal(SyuGeNetItem.getMokuhyoGaika()));
            colIdx++;
            //最新見積　円価
            PoiUtil.setCellValue(sheet, dataStartRow+index, dataStartCol+colIdx, convBigDecimal(SyuGeNetItem.getSaishinmitumoriEnka()));
            colIdx++;
            //最新見積　通貨
            PoiUtil.setCellValue(sheet, dataStartRow+index, dataStartCol+colIdx, SyuGeNetItem.getSaishinmitumoriCurrencyCode());
            colIdx++;
            //最新見積　レート
            PoiUtil.setCellValue(sheet, dataStartRow+index, dataStartCol+colIdx, convBigDecimal(SyuGeNetItem.getSaishinmitumoriRate()));
            colIdx++;
            //最新見積　外貨
            PoiUtil.setCellValue(sheet, dataStartRow+index, dataStartCol+colIdx, convBigDecimal(SyuGeNetItem.getSaishinmitumoriGaika()));
            colIdx++;
            //設計査定　円価
            PoiUtil.setCellValue(sheet, dataStartRow+index, dataStartCol+colIdx, convBigDecimal(SyuGeNetItem.getSekeisateiEnka()));
            colIdx++;
            //設計査定　通貨
            PoiUtil.setCellValue(sheet, dataStartRow+index, dataStartCol+colIdx, SyuGeNetItem.getSekeisateiCurrencyCode());
            colIdx++;
            //設計査定　レート
            PoiUtil.setCellValue(sheet, dataStartRow+index, dataStartCol+colIdx, convBigDecimal(SyuGeNetItem.getSekeisateiRate()));
            colIdx++;
            //設計査定　外貨
            PoiUtil.setCellValue(sheet, dataStartRow+index, dataStartCol+colIdx, convBigDecimal(SyuGeNetItem.getSekeisateiGaika()));
            colIdx++;
            //調達査定　円価
            PoiUtil.setCellValue(sheet, dataStartRow+index, dataStartCol+colIdx, convBigDecimal(SyuGeNetItem.getChotatusateiEnka()));
            colIdx++;
            //調達査定　通貨
            PoiUtil.setCellValue(sheet, dataStartRow+index, dataStartCol+colIdx, SyuGeNetItem.getChotatusateiCurrencyCode());
            colIdx++;
            //調達査定　レート
            PoiUtil.setCellValue(sheet, dataStartRow+index, dataStartCol+colIdx, convBigDecimal(SyuGeNetItem.getChotatusateiRate()));
            colIdx++;
            //調達査定　外貨
            PoiUtil.setCellValue(sheet, dataStartRow+index, dataStartCol+colIdx, convBigDecimal(SyuGeNetItem.getChotatusateiGaika()));
            colIdx++;
            //最終見込(今回値)　円価
            PoiUtil.setCellValue(sheet, dataStartRow+index, dataStartCol+colIdx, convBigDecimal(SyuGeNetItem.getFixedMikomiNet()));
            colIdx++;
            //最終見込(今回値)　通貨
            PoiUtil.setCellValue(sheet, dataStartRow+index, dataStartCol+colIdx, SyuGeNetItem.getFixedMikomiCurrecyCode());
            colIdx++;
            //最終見込(今回値)　レート
            PoiUtil.setCellValue(sheet, dataStartRow+index, dataStartCol+colIdx, convBigDecimal(SyuGeNetItem.getFixedMikomiNetRate()));
            colIdx++;
            //最終見込(今回値)　外貨
            PoiUtil.setCellValue(sheet, dataStartRow+index, dataStartCol+colIdx, convBigDecimal(SyuGeNetItem.getFixedMikomiNetGaika()));
            colIdx++;
            //最終見込(前回値)　円価
            PoiUtil.setCellValue(sheet, dataStartRow+index, dataStartCol+colIdx, convBigDecimal(SyuGeNetItem.getFixedMikomiNetBef()));
            colIdx++;
            //最終見込(前回値)　通貨
            PoiUtil.setCellValue(sheet, dataStartRow+index, dataStartCol+colIdx, SyuGeNetItem.getFixedMikomiBefCurrencyCode());
            colIdx++;
            //最終見込(前回値)　レート
            PoiUtil.setCellValue(sheet, dataStartRow+index, dataStartCol+colIdx, convBigDecimal(SyuGeNetItem.getFixedMikomiBefRate()));
            colIdx++;
            //最終見込(前回値)　外貨
            PoiUtil.setCellValue(sheet, dataStartRow+index, dataStartCol+colIdx, convBigDecimal(SyuGeNetItem.getFixedMikomiBefGaika()));
            colIdx++;
            //最終見込(前回差)　円価
            PoiUtil.setCellValue(sheet, dataStartRow+index, dataStartCol+colIdx, sUtils.arari(convBigDecimal(SyuGeNetItem.getFixedMikomiNet()), convBigDecimal(SyuGeNetItem.getFixedMikomiNetBef())));
            colIdx++;
            //最終見込(前回差)　レート
            PoiUtil.setCellValue(sheet, dataStartRow+index, dataStartCol+colIdx, sUtils.arari(convBigDecimal(SyuGeNetItem.getFixedMikomiNetRate()), convBigDecimal(SyuGeNetItem.getFixedMikomiBefRate())));
            colIdx++;
            //最終見込(前回差)　外貨
            PoiUtil.setCellValue(sheet, dataStartRow+index, dataStartCol+colIdx, sUtils.arari(convBigDecimal(SyuGeNetItem.getFixedMikomiNetGaika()), convBigDecimal(SyuGeNetItem.getFixedMikomiBefGaika())));
            colIdx++;
            //確定
            String kakutei = "";
            if(StringUtils.isNotEmpty(SyuGeNetItem.getNetKakuteiFlg()) && SyuGeNetItem.getNetKakuteiFlg().equals("1")){
                kakutei = Label.fixed.getLabel();
            } else {
                kakutei = Label.noFixed.getLabel();
            }
            PoiUtil.setCellValue(sheet, dataStartRow+index, dataStartCol+colIdx, kakutei);
            colIdx++;
            //ポテンシャル値　大　円価
            PoiUtil.setCellValue(sheet, dataStartRow+index, dataStartCol+colIdx, convBigDecimal(SyuGeNetItem.getPotenDaiEnka()));
            colIdx++;
            //ポテンシャル値　大　通貨
            PoiUtil.setCellValue(sheet, dataStartRow+index, dataStartCol+colIdx, SyuGeNetItem.getPotenDaiCurrencyCode());
            colIdx++;
            //ポテンシャル値　大　レート
            PoiUtil.setCellValue(sheet, dataStartRow+index, dataStartCol+colIdx, convBigDecimal(SyuGeNetItem.getPotenDaiRate()));
            colIdx++;
            //ポテンシャル値　大　外貨
            PoiUtil.setCellValue(sheet, dataStartRow+index, dataStartCol+colIdx, convBigDecimal(SyuGeNetItem.getPotenDaiGaika()));
            colIdx++;
            //ポテンシャル値　中　円価
            PoiUtil.setCellValue(sheet, dataStartRow+index, dataStartCol+colIdx, convBigDecimal(SyuGeNetItem.getPotenTyuEnka()));
            colIdx++;
            //ポテンシャル値　中　通貨
            PoiUtil.setCellValue(sheet, dataStartRow+index, dataStartCol+colIdx, SyuGeNetItem.getPotenTyuCurrencyCode());
            colIdx++;
            //ポテンシャル値　中　レート
            PoiUtil.setCellValue(sheet, dataStartRow+index, dataStartCol+colIdx, convBigDecimal(SyuGeNetItem.getPotenTyuRate()));
            colIdx++;
            //ポテンシャル値　中　外貨
            PoiUtil.setCellValue(sheet, dataStartRow+index, dataStartCol+colIdx, convBigDecimal(SyuGeNetItem.getPotenTyuGaika()));
            colIdx++;
            //ポテンシャル値　小　円価
            PoiUtil.setCellValue(sheet, dataStartRow+index, dataStartCol+colIdx, convBigDecimal(SyuGeNetItem.getPotenShoEnka()));
            colIdx++;
            //ポテンシャル値　小　通貨
            PoiUtil.setCellValue(sheet, dataStartRow+index, dataStartCol+colIdx, SyuGeNetItem.getPotenShoCurrencyCode());
            colIdx++;
            //ポテンシャル値　小　レート
            PoiUtil.setCellValue(sheet, dataStartRow+index, dataStartCol+colIdx, convBigDecimal(SyuGeNetItem.getPotenShoRate()));
            colIdx++;
            //ポテンシャル値　小　外貨
            PoiUtil.setCellValue(sheet, dataStartRow+index, dataStartCol+colIdx, convBigDecimal(SyuGeNetItem.getPotenShoGaika()));
            colIdx++;
            // 注入累計
            PoiUtil.setCellValue(sheet, dataStartRow+index, dataStartCol+colIdx, convBigDecimal(SyuGeNetItem.getCyunyuNet()));
            colIdx++;
            // 製番損益累計
            PoiUtil.setCellValue(sheet, dataStartRow+index, dataStartCol+colIdx, convBigDecimal(SyuGeNetItem.getSeibanSonekiNet()));
            colIdx++;
            // 売上累計
            PoiUtil.setCellValue(sheet, dataStartRow+index, dataStartCol+colIdx, convBigDecimal(SyuGeNetItem.getUriageNet()));
            colIdx++;
            // 発注日
            PoiUtil.setCellValue(sheet, dataStartRow+index, dataStartCol+colIdx, sUtils.exeFormatYmd(SyuGeNetItem.getHachuDate()));
            colIdx++;
            // 円価
            PoiUtil.setCellValue(sheet, dataStartRow+index, dataStartCol+colIdx, convBigDecimal(SyuGeNetItem.getHachuEnka()));            
            colIdx++;
            // 通貨
            PoiUtil.setCellValue(sheet, dataStartRow+index, dataStartCol+colIdx, SyuGeNetItem.getHachuCurrencyCode());
            colIdx++;
            // レート
            PoiUtil.setCellValue(sheet, dataStartRow+index, dataStartCol+colIdx, convBigDecimal(SyuGeNetItem.getHachuRate()));
            colIdx++;
            // 発注外貨
            PoiUtil.setCellValue(sheet, dataStartRow+index, dataStartCol+colIdx, convBigDecimal(SyuGeNetItem.getHachuGaika()));
            colIdx++;
            // 検収日
            PoiUtil.setCellValue(sheet, dataStartRow+index, dataStartCol+colIdx, sUtils.exeFormatYmd(SyuGeNetItem.getKenshuDate()));
            colIdx++;
            // 円価　検収済
            PoiUtil.setCellValue(sheet, dataStartRow+index, dataStartCol+colIdx, convBigDecimal(SyuGeNetItem.getKenshuEnka()));            
            colIdx++;
            // 通貨　検収済
            PoiUtil.setCellValue(sheet, dataStartRow+index, dataStartCol+colIdx, SyuGeNetItem.getKenshuCurrencyCode());
            colIdx++;
            // レート　検収済
            PoiUtil.setCellValue(sheet, dataStartRow+index, dataStartCol+colIdx, convBigDecimal(SyuGeNetItem.getKenshuRate()));
            colIdx++;
            // 外貨　検収済
            PoiUtil.setCellValue(sheet, dataStartRow+index, dataStartCol+colIdx, convBigDecimal(SyuGeNetItem.getKenshuGaika()));
            colIdx++;
            // 円価　未検収
            PoiUtil.setCellValue(sheet, dataStartRow+index, dataStartCol+colIdx, convBigDecimal(SyuGeNetItem.getMikenshuEnka()));            
            colIdx++;
            // 通貨　未検収
            PoiUtil.setCellValue(sheet, dataStartRow+index, dataStartCol+colIdx, SyuGeNetItem.getMikenshuCurrencyCode());
            colIdx++;
            // レート　未検収
            PoiUtil.setCellValue(sheet, dataStartRow+index, dataStartCol+colIdx, convBigDecimal(SyuGeNetItem.getMikenshuRate()));
            colIdx++;
            // 外貨　未検収
            PoiUtil.setCellValue(sheet, dataStartRow+index, dataStartCol+colIdx, convBigDecimal(SyuGeNetItem.getMikenshuGaika()));
            colIdx++;
            //再確認
            String sai = "";
            if(StringUtils.isNotEmpty(SyuGeNetItem.getKariNetFlg()) && SyuGeNetItem.getKariNetFlg().equals("1")){
                sai = Label.labelKari.getLabel();
            }
            PoiUtil.setCellValue(sheet, dataStartRow+index, dataStartCol+colIdx, sai);
            colIdx++;
            // 見込-注入　発番-売上
            BigDecimal zanMikomi = null;
            if (dispChunyu.equals(s005Bean.getDispKbn())) {
                zanMikomi = sUtils.arari(convBigDecimal(SyuGeNetItem.getFixedMikomiNet()), convBigDecimal(SyuGeNetItem.getCyunyuNet()));
            } else if (dispUriage.equals(s005Bean.getDispKbn())) {
                zanMikomi = sUtils.arari(convBigDecimal(SyuGeNetItem.getHatNet()), convBigDecimal(SyuGeNetItem.getUriageNet()));
            }
            PoiUtil.setCellValue(sheet, dataStartRow+index, dataStartCol+colIdx, zanMikomi);
            colIdx++;
            // NET01
            PoiUtil.setCellValue(sheet, dataStartRow+index, dataStartCol+colIdx, convBigDecimal(SyuGeNetItem.getNet01()));
            colIdx++;
            // NET02
            PoiUtil.setCellValue(sheet, dataStartRow+index, dataStartCol+colIdx, convBigDecimal(SyuGeNetItem.getNet02()));
            colIdx++;
            // NET03
            PoiUtil.setCellValue(sheet, dataStartRow+index, dataStartCol+colIdx, convBigDecimal(SyuGeNetItem.getNet03()));
            colIdx++;
            // NET04
            PoiUtil.setCellValue(sheet, dataStartRow+index, dataStartCol+colIdx, convBigDecimal(SyuGeNetItem.getNet04()));
            colIdx++;
            // NET05
            PoiUtil.setCellValue(sheet, dataStartRow+index, dataStartCol+colIdx, convBigDecimal(SyuGeNetItem.getNet05()));
            colIdx++;
            // NET06
            PoiUtil.setCellValue(sheet, dataStartRow+index, dataStartCol+colIdx, convBigDecimal(SyuGeNetItem.getNet06()));
            colIdx++;
            // NET_FROM
            PoiUtil.setCellValue(sheet, dataStartRow+index, dataStartCol+colIdx, convBigDecimal(SyuGeNetItem.getNetFrom()));
            colIdx++;
            // NET07
            PoiUtil.setCellValue(sheet, dataStartRow+index, dataStartCol+colIdx, convBigDecimal(SyuGeNetItem.getNet07()));
            colIdx++;
            // NET08
            PoiUtil.setCellValue(sheet, dataStartRow+index, dataStartCol+colIdx, convBigDecimal(SyuGeNetItem.getNet08()));
            colIdx++;
            // NET09
            PoiUtil.setCellValue(sheet, dataStartRow+index, dataStartCol+colIdx, convBigDecimal(SyuGeNetItem.getNet09()));
            colIdx++;
            // NET10
            PoiUtil.setCellValue(sheet, dataStartRow+index, dataStartCol+colIdx, convBigDecimal(SyuGeNetItem.getNet10()));
            colIdx++;
            // NET11
            PoiUtil.setCellValue(sheet, dataStartRow+index, dataStartCol+colIdx, convBigDecimal(SyuGeNetItem.getNet11()));
            colIdx++;
            // NET12
            PoiUtil.setCellValue(sheet, dataStartRow+index, dataStartCol+colIdx, convBigDecimal(SyuGeNetItem.getNet12()));
            colIdx++;
            // NET_TO
            PoiUtil.setCellValue(sheet, dataStartRow+index, dataStartCol+colIdx, convBigDecimal(SyuGeNetItem.getNetTo()));
            colIdx++;
            // NET_G
            PoiUtil.setCellValue(sheet, dataStartRow+index, dataStartCol+colIdx, convBigDecimal(SyuGeNetItem.getNetG()));
            colIdx++;
            // 備考
            PoiUtil.setCellValue(sheet, dataStartRow+index, dataStartCol+colIdx, SyuGeNetItem.getBikou());
            colIdx++;
            
            // セルスタイルのコピー
            Row copyStyleRow = null;
            // 発番区分がDの場合は、行を赤くする
            if ("D".equals(SyuGeNetItem.getHatKbn())) {
                copyStyleRow = styleRowD;
            } else {
                copyStyleRow = styleRow;
            }
            PoiUtil.copyRowStyleValue(PoiUtil.getRow(sheet, dataStartRow+index, false), copyStyleRow, false);
           
            
        }
        
    }
    
    
    /**
     * ObjectをBigDecimal型に変換
     * @param obj
     * @return
     * @throws Exception
     */
    private BigDecimal convBigDecimal(Object obj) throws Exception {
    
        return Utils.changeBigDecimal(Utils.getObjToStrValue(obj));
    
    }
    
    /**
     * ObjectをInteger型に変換
     * @param obj
     * @return
     * @throws Exception
     */
    private Integer convInteger(Object obj) throws Exception {
        
        if (obj==null) {
            return null;
        }
        return new Integer(obj.toString()).intValue();
    }

}
