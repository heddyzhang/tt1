package jp.co.toshiba.hby.pspromis.syuueki.entity;

import java.io.Serializable;
import java.util.Date;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

/**
 *
 * @author ibayashi
 */
@Entity
@Table(name = "ANKEN_MATOME_MAP_TBL")
public class AnkenMatomeMapTbl implements Serializable {
    private static final long serialVersionUID = 1L;
    @NotNull
    @Size(min = 1, max = 32)
    @Column(name = "ANKEN_MATOME_NO")
    @Id
    private String ankenMatomeNo;
    @NotNull
    @Size(min = 1, max = 32)
    @Column(name = "ANKEN_NO")
    @Id
    private String ankenNo;
    @Column(name = "CREATED_AT")
    @Temporal(TemporalType.TIMESTAMP)
    private Date createdAt;
    @Size(max = 32)
    @Column(name = "CREATED_BY")
    private String createdBy;
    @Column(name = "UPDATE_AT")
    @Temporal(TemporalType.TIMESTAMP)
    private Date updateAt;
    @Size(max = 32)
    @Column(name = "UPDATED_BY")
    private String updatedBy;

    public AnkenMatomeMapTbl() {
    }

    public String getAnkenMatomeNo() {
        return ankenMatomeNo;
    }

    public void setAnkenMatomeNo(String ankenMatomeNo) {
        this.ankenMatomeNo = ankenMatomeNo;
    }

    public String getAnkenNo() {
        return ankenNo;
    }

    public void setAnkenNo(String ankenNo) {
        this.ankenNo = ankenNo;
    }

    public Date getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(Date createdAt) {
        this.createdAt = createdAt;
    }

    public String getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    public Date getUpdateAt() {
        return updateAt;
    }

    public void setUpdateAt(Date updateAt) {
        this.updateAt = updateAt;
    }

    public String getUpdatedBy() {
        return updatedBy;
    }

    public void setUpdatedBy(String updatedBy) {
        this.updatedBy = updatedBy;
    }
    
}
