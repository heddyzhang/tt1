package jp.co.toshiba.hby.pspromis.syuueki.entity;

import java.io.Serializable;
import java.util.Date;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

/**
 *
 * @author ibayashi
 */
@Entity
@Table(name = "SYU_GE_RIREKI_INFO_TBL")
@NamedQuery(name="findPk", query="select p from SyuGeRirekiInfoTbl p where p.ankenId = :ankenId and p.rirekiId = :rirekiId")
public class SyuGeRirekiInfoTbl implements Serializable {
    private static final long serialVersionUID = 1L;
    @Size(min = 1, max = 32)
    @Column(name = "ANKEN_ID")
    @Id
    private String ankenId;
    @NotNull
    @Column(name = "RIREKI_ID")
    @Id
    private int rirekiId;
    @Size(max = 200)
    @Column(name = "RIREKI_TITLE")
    private String rirekiTitle;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 256)
    @Column(name = "FIXED_JOB_GROUP_CODE")
    private String fixedJobGroupCode;
    @Column(name = "FIXED_DATE")
    @Temporal(TemporalType.TIMESTAMP)
    private Date fixedDate;
    @Size(max = 32)
    @Column(name = "FIXED_KBN_MEI")
    private String fixedKbnMei;
    @Column(name = "FIXED_BY")
    private String fixedBy;
    @Column(name = "CREATED_AT")
    @Temporal(TemporalType.TIMESTAMP)
    private Date createdAt;
    @Size(max = 32)
    @Column(name = "CREATED_BY")
    private String createdBy;
    @Column(name = "UPDATED_AT")
    @Temporal(TemporalType.TIMESTAMP)
    private Date updatedAt;
    @Size(max = 32)
    @Column(name = "UPDATED_BY")
    private String updatedBy;
    @Column(name = "UPDATED_BATCH_AT")
    @Temporal(TemporalType.TIMESTAMP)
    private Date updatedBatchAt;
    @Size(max = 32)
    @Column(name = "UPDATED_BATCH_BY")
    private String updatedBatchBy;

    public SyuGeRirekiInfoTbl() {
    }

    public String getAnkenId() {
        return ankenId;
    }

    public void setAnkenId(String ankenId) {
        this.ankenId = ankenId;
    }

    public int getRirekiId() {
        return rirekiId;
    }

    public void setRirekiId(int rirekiId) {
        this.rirekiId = rirekiId;
    }

    public String getRirekiTitle() {
        return rirekiTitle;
    }

    public void setRirekiTitle(String rirekiTitle) {
        this.rirekiTitle = rirekiTitle;
    }

    public String getFixedJobGroupCode() {
        return fixedJobGroupCode;
    }

    public void setFixedJobGroupCode(String fixedJobGroupCode) {
        this.fixedJobGroupCode = fixedJobGroupCode;
    }

    public Date getFixedDate() {
        return fixedDate;
    }

    public void setFixedDate(Date fixedDate) {
        this.fixedDate = fixedDate;
    }

    public String getFixedKbnMei() {
        return fixedKbnMei;
    }

    public void setFixedKbnMei(String fixedKbnMei) {
        this.fixedKbnMei = fixedKbnMei;
    }

    public String getFixedBy() {
        return fixedBy;
    }

    public void setFixedBy(String fixedBy) {
        this.fixedBy = fixedBy;
    }

    public Date getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(Date createdAt) {
        this.createdAt = createdAt;
    }

    public String getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    public Date getUpdatedAt() {
        return updatedAt;
    }

    public void setUpdatedAt(Date updatedAt) {
        this.updatedAt = updatedAt;
    }

    public String getUpdatedBy() {
        return updatedBy;
    }

    public void setUpdatedBy(String updatedBy) {
        this.updatedBy = updatedBy;
    }

    public Date getUpdatedBatchAt() {
        return updatedBatchAt;
    }

    public void setUpdatedBatchAt(Date updatedBatchAt) {
        this.updatedBatchAt = updatedBatchAt;
    }

    public String getUpdatedBatchBy() {
        return updatedBatchBy;
    }

    public void setUpdatedBatchBy(String updatedBatchBy) {
        this.updatedBatchBy = updatedBatchBy;
    }

}
