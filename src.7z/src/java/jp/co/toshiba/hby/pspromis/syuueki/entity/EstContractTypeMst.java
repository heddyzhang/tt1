package jp.co.toshiba.hby.pspromis.syuueki.entity;

import java.io.Serializable;
import java.util.Date;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/**
 *
 * @author ibayashi
 */
@Entity
@Table(name = "EST_CONTRACT_TYPE_MST")
public class EstContractTypeMst implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @Column(name = "CONTRACT_CODE")
    private String contractCode;

    @Column(name = "PARENT_CONTRACT_CODE")
    private String parentContractCode;

    @Column(name = "CONTRACT_NAME")
    private String contractName;

    @Column(name = "CONTRACT_NAME_ENG")
    private String contractNameEng;

    @Column(name = "DIVISION_CODE")
    private String divisionCode;

    @Column(name = "VALID_FROM")
    @Temporal(TemporalType.DATE)
    private Date validFrom;

    @Column(name = "VALID_TO")
    @Temporal(TemporalType.DATE)
    private Date validTo;

    @Column(name = "REMARKS")
    private String remarks;
    @Column(name = "SORT_ORDER")
    private Integer sortOrder;

    @Column(name = "IS_DELETED")
    private short isDeleted;
    @Column(name = "CREATED_AT")
    @Temporal(TemporalType.TIMESTAMP)
    private Date createdAt;

    @Column(name = "CREATED_BY")
    private String createdBy;
    
    @Column(name = "UPDATED_AT")
    @Temporal(TemporalType.TIMESTAMP)
    private Date updatedAt;

    @Column(name = "UPDATED_BY")
    private String updatedBy;
    
    @Column(name = "DELETED_AT")
    @Temporal(TemporalType.TIMESTAMP)
    private Date deletedAt;

    @Column(name = "DELETED_BY")
    private String deletedBy;

    public EstContractTypeMst() {
    }

    public EstContractTypeMst(String contractCode) {
        this.contractCode = contractCode;
    }

    public EstContractTypeMst(String contractCode, short isDeleted) {
        this.contractCode = contractCode;
        this.isDeleted = isDeleted;
    }

    public String getContractCode() {
        return contractCode;
    }

    public void setContractCode(String contractCode) {
        this.contractCode = contractCode;
    }

    public String getParentContractCode() {
        return parentContractCode;
    }

    public void setParentContractCode(String parentContractCode) {
        this.parentContractCode = parentContractCode;
    }

    public String getContractName() {
        return contractName;
    }

    public void setContractName(String contractName) {
        this.contractName = contractName;
    }

    public String getContractNameEng() {
        return contractNameEng;
    }

    public void setContractNameEng(String contractNameEng) {
        this.contractNameEng = contractNameEng;
    }

    public String getDivisionCode() {
        return divisionCode;
    }

    public void setDivisionCode(String divisionCode) {
        this.divisionCode = divisionCode;
    }

    public Date getValidFrom() {
        return validFrom;
    }

    public void setValidFrom(Date validFrom) {
        this.validFrom = validFrom;
    }

    public Date getValidTo() {
        return validTo;
    }

    public void setValidTo(Date validTo) {
        this.validTo = validTo;
    }

    public String getRemarks() {
        return remarks;
    }

    public void setRemarks(String remarks) {
        this.remarks = remarks;
    }

    public Integer getSortOrder() {
        return sortOrder;
    }

    public void setSortOrder(Integer sortOrder) {
        this.sortOrder = sortOrder;
    }

    public short getIsDeleted() {
        return isDeleted;
    }

    public void setIsDeleted(short isDeleted) {
        this.isDeleted = isDeleted;
    }

    public Date getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(Date createdAt) {
        this.createdAt = createdAt;
    }

    public String getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    public Date getUpdatedAt() {
        return updatedAt;
    }

    public void setUpdatedAt(Date updatedAt) {
        this.updatedAt = updatedAt;
    }

    public String getUpdatedBy() {
        return updatedBy;
    }

    public void setUpdatedBy(String updatedBy) {
        this.updatedBy = updatedBy;
    }

    public Date getDeletedAt() {
        return deletedAt;
    }

    public void setDeletedAt(Date deletedAt) {
        this.deletedAt = deletedAt;
    }

    public String getDeletedBy() {
        return deletedBy;
    }

    public void setDeletedBy(String deletedBy) {
        this.deletedBy = deletedBy;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (contractCode != null ? contractCode.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof EstContractTypeMst)) {
            return false;
        }
        EstContractTypeMst other = (EstContractTypeMst) object;
        if ((this.contractCode == null && other.contractCode != null) || (this.contractCode != null && !this.contractCode.equals(other.contractCode))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "jp.co.toshiba.hby.pspromis.syuueki.entity.EstContractTypeMst[ contractCode=" + contractCode + " ]";
    }
    
}
