package jp.co.toshiba.hby.pspromis.syuueki.facade;

import java.util.List;
import java.util.Map;
import javax.ejb.Stateless;
import javax.interceptor.Interceptors;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import jp.co.toshiba.hby.pspromis.common.util.BeanUtil;
import jp.co.toshiba.hby.pspromis.syuueki.entity.SyuSaSeibansonekiTbl;
import jp.co.toshiba.hby.pspromis.syuueki.interceptor.TranceInterceptor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * 最終見込損益TBL(原価) 製番損益-工場別
 *
 * @author ganryu
 */
@Stateless
@Interceptors({TranceInterceptor.class})
public class SyuSaSeibansonekiTblFacade extends AbstractFacade<SyuSaSeibansonekiTbl> {
    private static final Logger logger = LoggerFactory.getLogger(SyuSaSeibansonekiTblFacade.class);

    @PersistenceContext(unitName = jp.co.toshiba.hby.pspromis.syuueki.util.ConstantString.syuuekiDataSourceName)
    private EntityManager em;

    @Override
    protected EntityManager getEntityManager() {
        return em;
    }

    public SyuSaSeibansonekiTblFacade() {
        super(SyuSaSeibansonekiTbl.class);
    }

    public void merge(SyuSaSeibansonekiTbl facade) {
        this.em.merge(BeanUtil.createAndCopy(SyuSaSeibansonekiTbl.class, facade));
    }

    /**
     * 製番損益内訳更新
     *
     * @param entity
     */
    public void setSeibanSonekiNet(SyuSaSeibansonekiTbl entity) {
        logger.info("SyuSaSeibansonekiTblFacade#setSeibanSonekiNet");
        sqlExecutor.executeUpdateSql(em, "/sql/syuSaSeibansonekiTbl/updateSeibanSonekiNet.sql", entity);
    }
    
    /**
     * コピー(複写)対象の通貨/レート/契約金額一覧を取得
     * @param _params
     * @return 
     */
    public List<SyuSaSeibansonekiTbl> findCopyList(Map<String, Object> _params) {
        List<SyuSaSeibansonekiTbl> list = sqlExecutor.getResultList(em, SyuSaSeibansonekiTbl.class, "/sql/syuSaSeibansonekiTbl/copyListSyuSaSeibansonekiTbl.sql", _params);
        return list;
    }
    
}
