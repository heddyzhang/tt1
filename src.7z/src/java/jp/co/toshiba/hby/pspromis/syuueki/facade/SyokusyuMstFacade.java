package jp.co.toshiba.hby.pspromis.syuueki.facade;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.ejb.Stateless;
import javax.interceptor.Interceptors;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import jp.co.toshiba.hby.pspromis.syuueki.entity.SyokusyuMst;
import jp.co.toshiba.hby.pspromis.syuueki.entity.SyokusyuMstView;
import jp.co.toshiba.hby.pspromis.syuueki.interceptor.TranceInterceptor;

/**
 *
 * @author ibayashi
 */
@Stateless
@Interceptors({TranceInterceptor.class})
public class SyokusyuMstFacade extends AbstractFacade<SyokusyuMst> {

    @PersistenceContext(unitName = jp.co.toshiba.hby.pspromis.syuueki.util.ConstantString.syuuekiDataSourceName)
    private EntityManager em;

    @Override
    protected EntityManager getEntityManager() {
        return em;
    }

    public SyokusyuMstFacade() {
        super(SyokusyuMst.class);
    }

    /**
     * 対象ユーザーのJobGr職種情報を取得
     *
     * @param tuid
     * @return
     */
    public List<SyokusyuMst> getJobGrSyokusyu(String tuid) {
        Map<String, Object> condition = new HashMap<>();
        condition.put("tuid", tuid);

        List<SyokusyuMst> list
                = sqlExecutor.getResultList(em, SyokusyuMst.class, "/sql/syokusyuMst/selectTuidSyokusyu.sql", condition);

        return list;
    }

    /**
     *
     * @param jgrpId
     * @return
     */
    public List<SyokusyuMstView> getMemberList(String jgrpId) {
        Map<String, Object> condition = new HashMap<>();
        condition.put("jgrpId", jgrpId);

        List<SyokusyuMstView> list = sqlExecutor.getResultList(em, SyokusyuMstView.class, "/sql/syokusyuMst/selectMemberList.sql", condition);

        return list;
    }

}
