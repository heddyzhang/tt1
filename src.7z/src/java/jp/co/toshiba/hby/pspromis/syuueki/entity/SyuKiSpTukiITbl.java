package jp.co.toshiba.hby.pspromis.syuueki.entity;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/**
 *
 * @author ibayashi
 */
@Entity
@Table(name = "SYU_KI_SP_TUKI_I_TBL")
@NamedQueries({
    @NamedQuery(name = "SyuKiSpTukiITbl.findAll", query = "SELECT s FROM SyuKiSpTukiITbl s")})
public class SyuKiSpTukiITbl implements Serializable {
    private static final long serialVersionUID = 1L;

    @Id
    @Column(name = "ANKEN_ID")
    private String ankenId;
    @Id
    @Column(name = "RIREKI_ID")
    private int rirekiId;
    @Id
    @Column(name = "DATA_KBN")
    private String dataKbn;
    @Id
    @Column(name = "CURRENCY_CODE")
    private String currencyCode;
    @Id
    @Column(name = "SYUEKI_YM")
    private String syuekiYm;
    @Id
    @Column(name = "RENBAN")
    private String renban;
    @Column(name = "ORDER_NO")
    private String orderNo;
    @Column(name = "URI_RATE")
    private BigDecimal uriRate;
    @Column(name = "URIAGE_AMOUNT")
    private BigDecimal uriageAmount;
    @Column(name = "URIAGE_ENKA_AMOUNT")
    private Long uriageEnkaAmount;
    @Column(name = "KEIYAKU_HID")
    private Integer keiyakuHid;
    @Column(name = "GYOTAI")
    private String gyotai;
    @Column(name = "ISP_FLG")
    private String ispFlg;
    @Column(name = "HINMEI")
    private String hinmei;
    @Column(name = "CREATED_AT")
    @Temporal(TemporalType.TIMESTAMP)
    private Date createdAt;
    @Column(name = "CREATED_BY")
    private String createdBy;
    @Column(name = "UPDATED_AT")
    @Temporal(TemporalType.TIMESTAMP)
    private Date updatedAt;
    @Column(name = "UPDATED_BY")
    private String updatedBy;
    @Column(name = "UPDATED_BATCH_AT")
    @Temporal(TemporalType.TIMESTAMP)
    private Date updatedBatchAt;
    @Column(name = "UPDATED_BATCH_BY")
    private String updatedBatchBy;

    public SyuKiSpTukiITbl() {
    }

    public String getAnkenId() {
        return ankenId;
    }

    public void setAnkenId(String ankenId) {
        this.ankenId = ankenId;
    }

    public int getRirekiId() {
        return rirekiId;
    }

    public void setRirekiId(int rirekiId) {
        this.rirekiId = rirekiId;
    }

    public String getDataKbn() {
        return dataKbn;
    }

    public void setDataKbn(String dataKbn) {
        this.dataKbn = dataKbn;
    }

    public String getCurrencyCode() {
        return currencyCode;
    }

    public void setCurrencyCode(String currencyCode) {
        this.currencyCode = currencyCode;
    }

    public String getSyuekiYm() {
        return syuekiYm;
    }

    public void setSyuekiYm(String syuekiYm) {
        this.syuekiYm = syuekiYm;
    }

    public String getRenban() {
        return renban;
    }

    public void setRenban(String renban) {
        this.renban = renban;
    }

    public String getOrderNo() {
        return orderNo;
    }

    public void setOrderNo(String orderNo) {
        this.orderNo = orderNo;
    }

    public BigDecimal getUriRate() {
        return uriRate;
    }

    public void setUriRate(BigDecimal uriRate) {
        this.uriRate = uriRate;
    }

    public BigDecimal getUriageAmount() {
        return uriageAmount;
    }

    public void setUriageAmount(BigDecimal uriageAmount) {
        this.uriageAmount = uriageAmount;
    }

    public Long getUriageEnkaAmount() {
        return uriageEnkaAmount;
    }

    public void setUriageEnkaAmount(Long uriageEnkaAmount) {
        this.uriageEnkaAmount = uriageEnkaAmount;
    }

    public Integer getKeiyakuHid() {
        return keiyakuHid;
    }

    public void setKeiyakuHid(Integer keiyakuHid) {
        this.keiyakuHid = keiyakuHid;
    }

    public String getGyotai() {
        return gyotai;
    }

    public void setGyotai(String gyotai) {
        this.gyotai = gyotai;
    }

    public String getIspFlg() {
        return ispFlg;
    }

    public void setIspFlg(String ispFlg) {
        this.ispFlg = ispFlg;
    }

    public String getHinmei() {
        return hinmei;
    }

    public void setHinmei(String hinmei) {
        this.hinmei = hinmei;
    }

    public Date getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(Date createdAt) {
        this.createdAt = createdAt;
    }

    public String getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    public Date getUpdatedAt() {
        return updatedAt;
    }

    public void setUpdatedAt(Date updatedAt) {
        this.updatedAt = updatedAt;
    }

    public String getUpdatedBy() {
        return updatedBy;
    }

    public void setUpdatedBy(String updatedBy) {
        this.updatedBy = updatedBy;
    }

    public Date getUpdatedBatchAt() {
        return updatedBatchAt;
    }

    public void setUpdatedBatchAt(Date updatedBatchAt) {
        this.updatedBatchAt = updatedBatchAt;
    }

    public String getUpdatedBatchBy() {
        return updatedBatchBy;
    }

    public void setUpdatedBatchBy(String updatedBatchBy) {
        this.updatedBatchBy = updatedBatchBy;
    }

}
