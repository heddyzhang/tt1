package jp.co.toshiba.hby.pspromis.syuueki.entity;

import java.io.Serializable;
import java.math.BigInteger;
import java.util.Date;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/**
 *
 * @author 
 */
@Entity
@Table(name = "SYU_ATTACH_TBL")
public class SyuAttachTbl implements Serializable {
    private static final long serialVersionUID = 1L;

    @Id
    @Column(name = "ANKEN_ID")
    private String ankenId;

    @Id
    @Column(name = "RIREKI_ID")
    private int rirekiId;

    @Id
    @Column(name = "SEQ")
    private BigInteger seq;

    @Column(name = "TITLE")
    private String title;

    @Column(name = "ATT_FILE_NAME")
    private String attFileName;

    @Column(name = "URL_NAME")
    private String urlName;

    @Column(name = "ATT_FILE_SERV_NAME")
    private String attFileServName;

    @Column(name = "ATT_FILE_PATH")
    private String attFilePath;

    @Column(name = "CREATED_AT")
    @Temporal(TemporalType.TIMESTAMP)
    private Date createdAt;

    @Column(name = "CREATED_BY")
    private String createdBy;
    
    @Column(name = "UPDATED_AT")
    @Temporal(TemporalType.TIMESTAMP)
    private Date updatedAt;

    @Column(name = "UPDATED_BY")
    private String updatedBy;

    @Column(name = "UPDATED_BATCH_AT")
    @Temporal(TemporalType.TIMESTAMP)
    private Date updatedBatchAt;

    @Column(name = "UPDATED_BATCH_BY")
    private String updatedBatchBy;

    public SyuAttachTbl() {
    }

    public String getAnkenId() {
        return ankenId;
    }

    public void setAnkenId(String ankenId) {
        this.ankenId = ankenId;
    }

    public int getRirekiId() {
        return rirekiId;
    }

    public void setRirekiId(int rirekiId) {
        this.rirekiId = rirekiId;
    }

    public BigInteger getSeq() {
        return seq;
    }

    public void setSeq(BigInteger seq) {
        this.seq = seq;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getAttFileName() {
        return attFileName;
    }

    public void setAttFileName(String attFileName) {
        this.attFileName = attFileName;
    }

    public String getUrlName() {
        return urlName;
    }

    public void setUrlName(String urlName) {
        this.urlName = urlName;
    }

    public String getAttFileServName() {
        return attFileServName;
    }

    public void setAttFileServName(String attFileServName) {
        this.attFileServName = attFileServName;
    }

    public String getAttFilePath() {
        return attFilePath;
    }

    public void setAttFilePath(String attFilePath) {
        this.attFilePath = attFilePath;
    }

    public Date getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(Date createdAt) {
        this.createdAt = createdAt;
    }

    public String getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    public Date getUpdatedAt() {
        return updatedAt;
    }

    public void setUpdatedAt(Date updatedAt) {
        this.updatedAt = updatedAt;
    }

    public String getUpdatedBy() {
        return updatedBy;
    }

    public void setUpdatedBy(String updatedBy) {
        this.updatedBy = updatedBy;
    }

    public Date getUpdatedBatchAt() {
        return updatedBatchAt;
    }

    public void setUpdatedBatchAt(Date updatedBatchAt) {
        this.updatedBatchAt = updatedBatchAt;
    }

    public String getUpdatedBatchBy() {
        return updatedBatchBy;
    }

    public void setUpdatedBatchBy(String updatedBatchBy) {
        this.updatedBatchBy = updatedBatchBy;
    }
    
}
