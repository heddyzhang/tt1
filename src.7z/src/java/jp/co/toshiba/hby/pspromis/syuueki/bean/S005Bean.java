package jp.co.toshiba.hby.pspromis.syuueki.bean;

import java.math.BigDecimal;
import java.math.BigInteger;
//import java.util.ArrayList;
//import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.enterprise.context.RequestScoped;
import javax.inject.Named;
import jp.co.toshiba.hby.pspromis.syuueki.entity.SyuCurMst;
import jp.co.toshiba.hby.pspromis.syuueki.entity.SyuGeNetItemTblView;

/**
 *
 * @author wakamatsu
 */
@Named(value = "s005Bean")
@RequestScoped
public class S005Bean extends AbstractBean {

    /**
     * 一括ダウンロード出力FLG
     * (案件一覧の一括ダウンロード処理から指定された場合はtrueとなる)
     * (この場合は特定処理(この内部での操作ログ書き込み等)を行わない)
     */
    private boolean isIkkatsuFlg = false;
    
    /**
     * 一覧検索フラグ
     */
    private String listFlg = "0";

    /**
     * 検索条件:注番
     */
    private String orderNo;

    /**
     * 検索条件:項番(from)
     */
    private String orderItemFrom;
    
    /**
     * 検索条件:項番(to)
     */
    private String orderItemTo;
    
    /**
     * 検索条件:製番記号
     */
    private String seiban;
    
    /**
     * 検索条件:売上残
     */
    private String uriageEndFlg;
    
    /**
     * 検索条件:（技）/IEC(設計）
     */
    private String giBukaCd;
    
    /**
     * 検索条件:（工場）設計
     */
    private String sekkeiBukaCd;

    /**
     * カテゴリ(期間)
     */
    private String kiCategory;

    /**
     * カテゴリ(最終) 
     */
    private String saCategory;
    
    /**
     * カテゴリ1(期間)
     */
    private String kiCate1;
    
    /**
     * カテゴリ2(期間)
     */
    private String kiCate2;

    /**
     * カテゴリ1(最終) 
     */
    private String saCate1;

    /**
     * カテゴリ1(最終) 
     */
    private String saCate2;

    /**
     * 検索条件:ソート順(最優先)
     */
    private String sort1;
    
    /**
     * 検索条件:並び順（最優先）
     */
    private String sort1Kbn;
    
    /**
     * 検索条件:ソート順(２番目)
     */
    private String sort2;
    
    /**
     * 検索条件:並び順（２番目）
     */
    private String sort2Kbn;
    
    /**
     * 注入/売上 リストボックス
     */
    private String dispKbn = "0";

    /**
     * 注入/売上フラグ
     */
    private String oldDispKbn;

    /**
     * 一覧表示データ総件数
     */
    private Integer count;

    /**
     * 現在表示するページ番号
     */
    private Integer page;

    /**
     * 期間変更FLG("B":一期前に移動 "A":一期先に移動)
     */
    private String kikanChangeFlg;

    /**
     * リセット処理FLG(1:リセット)
     */
    private String resetFlg;
    
    /**
     * 一覧取得結果
     */
    private List<SyuGeNetItemTblView> syuGeNetItemTblViewList;
        
    /**
     * 現状発番合計
     */
    private BigInteger sumHatNet;
    
    /**
     * 注入累計合計
     */
    private BigInteger sumCyunyuNet;
    
    /**
     * 製番損益累計合計(Step2追加)
     */
    private BigInteger sumSeibanSonekiNet;

    /**
     * 売上累計合計
     */
    private BigInteger sumUriageNet;
    
    /**
     * 最終見込
     */
    private BigInteger sumFixedMikomiNet;
    
    /**
     * 発注外貨合計
     */
    private BigDecimal sumHachuAmount;
    
    /**
     * 残合計
     */
    private BigInteger sumZanMikomi;
    
    /**
     * NET合計
     */
    private BigInteger sumNet01;
    private BigInteger sumNet02;
    private BigInteger sumNet03;
    private BigInteger sumNet04;
    private BigInteger sumNet05;
    private BigInteger sumNet06;
    private BigInteger sumNetFrom;
    private BigInteger sumNet07;
    private BigInteger sumNet08;
    private BigInteger sumNet09;
    private BigInteger sumNet10;
    private BigInteger sumNet11;
    private BigInteger sumNet12;
    private BigInteger sumNetTo;
    private BigInteger sumNetG;
    
    /**
     * 期間
     */
    private String kikan01;
    private String kikan02;
    private String kikan03;
    private String kikan04;
    private String kikan05;
    private String kikan06;
    private String kikan07;
    private String kikan08;
    private String kikan09;
    private String kikan10;
    private String kikan11;
    private String kikan12;

    /**
     * まとめ案件フラグ
     */
    private String ankenFlg;
    
    /**
     * 子案件番号リスト
     */
    //private ArrayList<HashMap<String,Object>> childAnkenList;
    private List<String> childAnkenIdList = null;

    /**
     * 期間Fromの選択候補(2014下add)
     */
    private List<String> kikanFromList;
    
    /**
     * 項番一覧表示部変更フラグ
     * (0:期間、1:最終)
     */
    private String viewFlg = "0";
    
     /**
     * 参照・編集FLG(0:参照 1:編集)
     */
    private String editFlg = "0";
    
    /**
     * 項番一覧(最終)画面表示内容フラグ
     * (0:外貨含 1:円価)
     */
    private String dispFlg = "1";
    
    /**
     * 項番一覧(最終)　現状発番合計行
     */
    private BigInteger sumGenjoHat;
    
    /**
     * 項番一覧(最終)　前回発番合計行
     */
    private BigInteger sumZenkaiHat;
    
    /**
     * 項番一覧(最終)　当初見込合計行
     */
    private BigInteger sumJusei;
    
    /**
     * 項番一覧(最終)　受注合計行
     */
    private BigInteger sumJutyu;
    
    /**
     * 項番一覧(最終)　目標NET合計行
     */
    private BigInteger sumMokuhyo;
    
    /**
     * 項番一覧(最終)　最新見積合計行
     */
    private BigInteger sumSaishinMitumori;
    
    /**
     * 項番一覧(最終)　設計査定合計行
     */
    private BigInteger sumSekeisatei;
    
    /**
     * 項番一覧(最終)　調達査定合計行
     */
    private BigInteger sumChotatusatei;
    
    /**
     * 項番一覧(最終)　最終見込今回値合計行
     */
    private BigInteger sumSaishuMikomiNow;
    
    /**
     * 項番一覧(最終)　最終見込前回値合計行
     */
    private BigInteger sumSaishuMikomiBef;
    
    /**
     * 項番一覧(最終)　ポテンシャル値　大　合計行
     */
    private BigInteger sumPotenDai;
    
    /**
     * 項番一覧(最終)　ポテンシャル値 中　合計行
     */
    private BigInteger sumPotenTyu;
    
    /**
     * 項番一覧(最終)　ポテンシャル値　小　合計行
     */
    private BigInteger sumPotenSho;
    
    /**
     * 項番一覧(最終)　発注金額 合計行
     */
    private BigInteger sumHachu;
    
    /**
     * 項番一覧(最終)　検収済み累計　合計行
     */
    private BigInteger sumKenshu;
    
    /**
     * 項番一覧(最終)　未検収　合計行
     */
    private BigInteger sumMikenshu;
    
    /**
     *  項番一覧(最終)　通貨セレクトボックス
     */
    private List<SyuCurMst> currencyCodeList;
    
    /**
     * チェックされたチェックボックスのindex
     */
    private String[] checkIndex;
    
    /**
     * 項番一覧 入力値
     */
    private List<Map<String, String>> dispList;
    
    /**
     * 勘定月
     */
    private String targetKanjoDate;
    
    /**
     * 保存用編集フラグ
     */
     private String[] listSaveFlg;
     
     /**
     * 検索条件・発番発行
     */
    private String[] hatHako;
    
    /**
     * 検索条件・差分チェック(発番と最終見込)
     */
    private String diffCheckKbnHatFixedMikomi;
    
    /**
     * 検索条件・差分チェック(発番と注入累計)
     */
    private String diffCheckKbnHatChunyu;

    /**
     * sql用フラグ(期間)
     */
    private int kikanFlg = 0;
    
    /**
     * sql用フラグ(最終)
     */
    private int saishuFlg = 0;
    
    /**
     * 前回値表示用前回ID
     */
    private String zenkaiId;
    
    /**
     * 項番一覧(最終)　前回月
     */
    private String befMonth;
    
    /**
     * 見込項番検索FLG
     */
    private String mikomiItemSearchFlg;
    
    /**
     * ポテンシャルフラグ
     */
    private String potenFlg;
    
    /**
     * 案件の編集可否チェックFLG(0:不可 1:可能)
     */
    private String editAuthFlg = "0";

    /**
     * [最新値更新]ボタンがりようできるか？(1:可能 0:不可)
     */
    private String saisyuUpdeteBtnFlg = "0";

    /**
     * 最新値更新区分(1:発番取込 2:契約取込 3:見積取込)
     */
    private String updateNewDataKbn;
    
    /**
     * 対象案件の売上基準(0:一般 1:進行基準)
     */
    private String salesClass;

    /**
     * 最終見込NETが入力可能であるか？(0:入力不可  1;入力可能)
     */
    private String inputSaisyuMikomiNetFlg = "0";

    /**
     * Creates a new instance of S001Bean
     */
    public S005Bean() {
    }

    public String getListFlg() {
        return listFlg;
    }

    public void setListFlg(String listFlg) {
        this.listFlg = listFlg;
    }

    public Integer getCount() {
        return count;
    }

    public void setCount(Integer count) {
        this.count = count;
    }

    public Integer getPage() {
        return page;
    }

    public void setPage(Integer page) {
        this.page = page;
    }

    public String getDispKbn() {
        return dispKbn;
    }

    public void setDispKbn(String dispKbn) {
        this.dispKbn = dispKbn;
    }

    public String getOldDispKbn() {
        return oldDispKbn;
    }

    public void setOldDispKbn(String oldDispKbn) {
        this.oldDispKbn = oldDispKbn;
    }

    public String getResetFlg() {
        return resetFlg;
    }

    public void setResetFlg(String resetFlg) {
        this.resetFlg = resetFlg;
    }

    public String getKikanChangeFlg() {
        return kikanChangeFlg;
    }

    public void setKikanChangeFlg(String kikanChangeFlg) {
        this.kikanChangeFlg = kikanChangeFlg;
    }

    public String getOrderNo() {
        return orderNo;
    }

    public void setOrderNo(String orderNo) {
        this.orderNo = orderNo;
    }

    public String getOrderItemFrom() {
        return orderItemFrom;
    }

    public void setOrderItemFrom(String orderItemFrom) {
        this.orderItemFrom = orderItemFrom;
    }

    public String getOrderItemTo() {
        return orderItemTo;
    }

    public void setOrderItemTo(String orderItemTo) {
        this.orderItemTo = orderItemTo;
    }

    public String getSeiban() {
        return seiban;
    }

    public void setSeiban(String seiban) {
        this.seiban = seiban;
    }

    public String getUriageEndFlg() {
        return uriageEndFlg;
    }

    public void setUriageEndFlg(String uriageEndFlg) {
        this.uriageEndFlg = uriageEndFlg;
    }

    public String getGiBukaCd() {
        return giBukaCd;
    }

    public void setGiBukaCd(String giBukaCd) {
        this.giBukaCd = giBukaCd;
    }

    public String getSekkeiBukaCd() {
        return sekkeiBukaCd;
    }

    public void setSekkeiBukaCd(String sekkeiBukaCd) {
        this.sekkeiBukaCd = sekkeiBukaCd;
    }

    public String getSort1() {
        return sort1;
    }

    public void setSort1(String sort1) {
        this.sort1 = sort1;
    }

    public String getSort1Kbn() {
        return sort1Kbn;
    }

    public void setSort1Kbn(String sort1Kbn) {
        this.sort1Kbn = sort1Kbn;
    }
   
    public String getSort2() {
        return sort2;
    }
    
    public void setSort2(String sort2) {
        this.sort2 = sort2;
    }

    public String getSort2Kbn() {
        return sort2Kbn;
    }

    public void setSort2Kbn(String sort2Kbn) {
        this.sort2Kbn = sort2Kbn;
    }

    public List<SyuGeNetItemTblView> getSyuGeNetItemTblViewList() {
        return syuGeNetItemTblViewList;
    }

    public void setSyuGeNetItemTblViewList(List<SyuGeNetItemTblView> syuGeNetItemTblViewList) {
        this.syuGeNetItemTblViewList = syuGeNetItemTblViewList;
    }

    public BigInteger getSumHatNet() {
        return sumHatNet;
    }

    public void setSumHatNet(BigInteger sumHatNet) {
        this.sumHatNet = sumHatNet;
    }

    public BigInteger getSumCyunyuNet() {
        return sumCyunyuNet;
    }

    public void setSumCyunyuNet(BigInteger sumCyunyuNet) {
        this.sumCyunyuNet = sumCyunyuNet;
    }

    public BigInteger getSumUriageNet() {
        return sumUriageNet;
    }

    public void setSumUriageNet(BigInteger sumUriageNet) {
        this.sumUriageNet = sumUriageNet;
    }

    public BigInteger getSumFixedMikomiNet() {
        return sumFixedMikomiNet;
    }

    public void setSumFixedMikomiNet(BigInteger sumFixedMikomiNet) {
        this.sumFixedMikomiNet = sumFixedMikomiNet;
    }

    public BigDecimal getSumHachuAmount() {
        return sumHachuAmount;
    }

    public void setSumHachuAmount(BigDecimal sumHachuAmount) {
        this.sumHachuAmount = sumHachuAmount;
    }

    public BigInteger getSumZanMikomi() {
        return sumZanMikomi;
    }

    public void setSumZanMikomi(BigInteger sumZanMikomi) {
        this.sumZanMikomi = sumZanMikomi;
    }

    public BigInteger getSumNet01() {
        return sumNet01;
    }

    public void setSumNet01(BigInteger sumNet01) {
        this.sumNet01 = sumNet01;
    }

    public BigInteger getSumNet02() {
        return sumNet02;
    }

    public void setSumNet02(BigInteger sumNet02) {
        this.sumNet02 = sumNet02;
    }

    public BigInteger getSumNet03() {
        return sumNet03;
    }

    public void setSumNet03(BigInteger sumNet03) {
        this.sumNet03 = sumNet03;
    }

    public BigInteger getSumNet04() {
        return sumNet04;
    }

    public void setSumNet04(BigInteger sumNet04) {
        this.sumNet04 = sumNet04;
    }

    public BigInteger getSumNet05() {
        return sumNet05;
    }

    public void setSumNet05(BigInteger sumNet05) {
        this.sumNet05 = sumNet05;
    }

    public BigInteger getSumNet06() {
        return sumNet06;
    }

    public void setSumNet06(BigInteger sumNet06) {
        this.sumNet06 = sumNet06;
    }

    public BigInteger getSumNetFrom() {
        return sumNetFrom;
    }

    public void setSumNetFrom(BigInteger sumNetFrom) {
        this.sumNetFrom = sumNetFrom;
    }

    public BigInteger getSumNet07() {
        return sumNet07;
    }

    public void setSumNet07(BigInteger sumNet07) {
        this.sumNet07 = sumNet07;
    }

    public BigInteger getSumNet08() {
        return sumNet08;
    }

    public void setSumNet08(BigInteger sumNet08) {
        this.sumNet08 = sumNet08;
    }

    public BigInteger getSumNet09() {
        return sumNet09;
    }

    public void setSumNet09(BigInteger sumNet09) {
        this.sumNet09 = sumNet09;
    }

    public BigInteger getSumNet10() {
        return sumNet10;
    }

    public void setSumNet10(BigInteger sumNet10) {
        this.sumNet10 = sumNet10;
    }

    public BigInteger getSumNet11() {
        return sumNet11;
    }

    public void setSumNet11(BigInteger sumNet11) {
        this.sumNet11 = sumNet11;
    }

    public BigInteger getSumNet12() {
        return sumNet12;
    }

    public void setSumNet12(BigInteger sumNet12) {
        this.sumNet12 = sumNet12;
    }

    public BigInteger getSumNetTo() {
        return sumNetTo;
    }

    public void setSumNetTo(BigInteger sumNetTo) {
        this.sumNetTo = sumNetTo;
    }

    public BigInteger getSumNetG() {
        return sumNetG;
    }

    public void setSumNetG(BigInteger sumNetG) {
        this.sumNetG = sumNetG;
    }

    public String getKikan01() {
        return kikan01;
    }

    public void setKikan01(String kikan01) {
        this.kikan01 = kikan01;
    }

    public String getKikan02() {
        return kikan02;
    }

    public void setKikan02(String kikan02) {
        this.kikan02 = kikan02;
    }

    public String getKikan03() {
        return kikan03;
    }

    public void setKikan03(String kikan03) {
        this.kikan03 = kikan03;
    }

    public String getKikan04() {
        return kikan04;
    }

    public void setKikan04(String kikan04) {
        this.kikan04 = kikan04;
    }

    public String getKikan05() {
        return kikan05;
    }

    public void setKikan05(String kikan05) {
        this.kikan05 = kikan05;
    }

    public String getKikan06() {
        return kikan06;
    }

    public void setKikan06(String kikan06) {
        this.kikan06 = kikan06;
    }

    public String getKikan07() {
        return kikan07;
    }

    public void setKikan07(String kikan07) {
        this.kikan07 = kikan07;
    }

    public String getKikan08() {
        return kikan08;
    }

    public void setKikan08(String kikan08) {
        this.kikan08 = kikan08;
    }

    public String getKikan09() {
        return kikan09;
    }

    public void setKikan09(String kikan09) {
        this.kikan09 = kikan09;
    }

    public String getKikan10() {
        return kikan10;
    }

    public void setKikan10(String kikan10) {
        this.kikan10 = kikan10;
    }

    public String getKikan11() {
        return kikan11;
    }

    public void setKikan11(String kikan11) {
        this.kikan11 = kikan11;
    }

    public String getKikan12() {
        return kikan12;
    }

    public void setKikan12(String kikan12) {
        this.kikan12 = kikan12;
    }

    public String getAnkenFlg() {
        return ankenFlg;
    }

    public void setAnkenFlg(String ankenFlg) {
        this.ankenFlg = ankenFlg;
    }

//    public ArrayList<HashMap<String, Object>> getChildAnkenList() {
//        return childAnkenList;
//    }
//
//    public void setChildAnkenList(ArrayList<HashMap<String, Object>> childAnkenList) {
//        this.childAnkenList = childAnkenList;
//    }

    public List<String> getKikanFromList() {
        return kikanFromList;
    }

    public void setKikanFromList(List<String> kikanFromList) {
        this.kikanFromList = kikanFromList;
    }

    public String getKiCategory() {
        return kiCategory;
    }

    public void setKiCategory(String kiCategory) {
        this.kiCategory = kiCategory;
    }

    public String getSaCategory() {
        return saCategory;
    }

    public void setSaCategory(String saCategory) {
        this.saCategory = saCategory;
    }

    public BigInteger getSumSeibanSonekiNet() {
        return sumSeibanSonekiNet;
    }

    public void setSumSeibanSonekiNet(BigInteger sumSeibanSonekiNet) {
        this.sumSeibanSonekiNet = sumSeibanSonekiNet;
    }

    public boolean isIsIkkatsuFlg() {
        return isIkkatsuFlg;
    }

    public void setIsIkkatsuFlg(boolean isIkkatsuFlg) {
        this.isIkkatsuFlg = isIkkatsuFlg;
    }

    public String getViewFlg() {
        return viewFlg;
    }

    public void setViewFlg(String viewFlg) {
        this.viewFlg = viewFlg;
    }

    public String getEditFlg() {
        return editFlg;
    }

    public void setEditFlg(String editFlg) {
        this.editFlg = editFlg;
    }

    public String getDispFlg() {
        return dispFlg;
    }

    public void setDispFlg(String dispFlg) {
        this.dispFlg = dispFlg;
    }
    
    public BigInteger getSumGenjoHat() {
        return sumGenjoHat;
    }

    public void setSumGenjoHat(BigInteger sumGenjoHat) {
        this.sumGenjoHat = sumGenjoHat;
    }
    
    public BigInteger getSumZenkaiHat() {
        return sumZenkaiHat;
    }

    public void setSumZenkaiHat(BigInteger sumZenkaiHat) {
        this.sumZenkaiHat = sumZenkaiHat;
    }
    
    public BigInteger getSumJusei() {
        return sumJusei;
    }

    public void setSumJusei(BigInteger sumJusei) {
        this.sumJusei = sumJusei;
    }
    
    public BigInteger getSumJutyu() {
        return sumJutyu;
    }

    public void setSumJutyu(BigInteger sumJutyu) {
        this.sumJutyu = sumJutyu;
    }
    
    public BigInteger getSumMokuhyo() {
        return sumMokuhyo;
    }

    public void setSumMokuhyo(BigInteger sumMokuhyo) {
        this.sumMokuhyo = sumMokuhyo;
    }
            
    public BigInteger getSumSaishinMitumori() {
        return sumSaishinMitumori;
    }

    public void setSumSaishinMitumori(BigInteger sumSaishinMitumori) {
        this.sumSaishinMitumori = sumSaishinMitumori;
    }
            
    public BigInteger getSumSekeisatei() {
        return sumSekeisatei;
    }

    public void setSumSekeisatei(BigInteger sumSekeisatei) {
        this.sumSekeisatei = sumSekeisatei;
    }
            
    public BigInteger getSumChotatusatei() {
        return sumChotatusatei;
    }

    public void setSumChotatusatei(BigInteger sumChotatusatei) {
        this.sumChotatusatei = sumChotatusatei;
    }
            
    public BigInteger getSumSaishuMikomiNow() {
        return sumSaishuMikomiNow;
    }

    public void setSumSaishuMikomiNow(BigInteger sumSaishuMikomiNow) {
        this.sumSaishuMikomiNow = sumSaishuMikomiNow;
    }
            
    public BigInteger getSumSaishuMikomiBef() {
        return sumSaishuMikomiBef;
    }

    public void setSumSaishuMikomiBef(BigInteger sumSaishuMikomiBef) {
        this.sumSaishuMikomiBef = sumSaishuMikomiBef;
    }
    
    public BigInteger getSumPotenDai() {
        return sumPotenDai;
    }

    public void setSumPotenDai(BigInteger sumPotenDai) {
        this.sumPotenDai = sumPotenDai;
    }
    
    public BigInteger getSumPotenTyu() {
        return sumPotenTyu;
    }

    public void setSumPotenTyu(BigInteger sumPotenTyu) {
        this.sumPotenTyu = sumPotenTyu;
    }
    
    public BigInteger getSumPotenSho() {
        return sumPotenSho;
    }

    public void setSumPotenSho(BigInteger sumPotenSho) {
        this.sumPotenSho = sumPotenSho;
    }
    
    public BigInteger getSumHachu() {
        return sumHachu;
    }

    public void setSumHachu(BigInteger sumHachu) {
        this.sumHachu = sumHachu;
    }
    
    public BigInteger getSumKenshu() {
        return sumKenshu;
    }

    public void setSumKenshu(BigInteger sumKenshu) {
        this.sumKenshu = sumKenshu;
    }
    
    public BigInteger getSumMikenshu() {
        return sumMikenshu;
    }

    public void setSumMikenshu(BigInteger sumMikenshu) {
        this.sumMikenshu = sumMikenshu;
    }
    
    public List<SyuCurMst> getCurrencyCodeList() {
        return currencyCodeList;
    }
    
    public void setCurrencyCodeList(List<SyuCurMst> currencyCodeList) {
        this.currencyCodeList = currencyCodeList;
    }
    
    public String[] getCheckIndex(){
        return checkIndex;
    }
    
    public void setCheckIndex(String[] checkIndex){
        this.checkIndex = checkIndex;
    }
    
    public List<Map<String, String>> getDispList(){
        return dispList;
    }
    
    public void setDispList(List<Map<String, String>> dispList){
        this.dispList = dispList;
    }
    
    public String getTargetKanjoDate(){
        return targetKanjoDate;
    }
    
    public void setTargetKanjoDate(String targetKanjoDate){
        this.targetKanjoDate = targetKanjoDate;
    }
    
    public String[] getListSaveFlg(){
        return listSaveFlg;
    }
    
    public void setListSaveFlg(String[] listSaveFlg){
        this.listSaveFlg = listSaveFlg;
    }
    
    public String[] getHatHako(){
        return hatHako;
    }
    
    public void setHatHako(String[] hatHako){
        this.hatHako = hatHako;
    }
    
    public int getKikanFlg() {
        return kikanFlg;
    }
    
    public void setKikanFlg(int kikanFlg) {
        this.kikanFlg = kikanFlg;
    }
    
    public int getSaishuFlg() {
        return saishuFlg;
    }
    
    public void setSaishuFlg(int saishuFlg) {
        this.saishuFlg = saishuFlg;
    }
    
    public String getSaCate1(){
        return saCate1;
    }
    
    public void setSaCate1(String saCate1){
        this.saCate1 = saCate1;
    }
    
    public String getSaCate2(){
        return saCate2;
    }
    
    public void setSaCate2(String saCate2){
        this.saCate2 = saCate2;
    }
    
    public String getKiCate1(){
        return kiCate1;
    }
    
    public void setKiCate1(String kiCate1){
        this.kiCate1 = kiCate1;
    }
    
    public String getKiCate2(){
        return kiCate2;
    }
    
    public void setKiCate2(String kiCate2){
        this.kiCate2 = kiCate2;
    }
    
    public String getZenkaiId(){
        return zenkaiId;
    }
    
    public void setZenkaiId(String zenkaiId){
        this.zenkaiId = zenkaiId;
    }
    
    public String getBefMonth(){
        return befMonth;
    }
    
    public void setBefMonth(String befMonth){
        this.befMonth = befMonth;
    }

    public String getMikomiItemSearchFlg() {
        return mikomiItemSearchFlg;
    }

    public void setMikomiItemSearchFlg(String mikomiItemSearchFlg) {
        this.mikomiItemSearchFlg = mikomiItemSearchFlg;
    }
    
    public String getPotenFlg(){
        return potenFlg;
    }
    
    public void setPotenFlg(String potenFlg){
        this.potenFlg = potenFlg;
    }

    public String getEditAuthFlg() {
        return editAuthFlg;
    }

    public void setEditAuthFlg(String editAuthFlg) {
        this.editAuthFlg = editAuthFlg;
    }

    public String getUpdateNewDataKbn() {
        return updateNewDataKbn;
    }

    public void setUpdateNewDataKbn(String updateNewDataKbn) {
        this.updateNewDataKbn = updateNewDataKbn;
    }

    public String getSalesClass() {
        return salesClass;
    }

    public void setSalesClass(String salesClass) {
        this.salesClass = salesClass;
    }

    public String getSaisyuUpdeteBtnFlg() {
        return saisyuUpdeteBtnFlg;
    }

    public void setSaisyuUpdeteBtnFlg(String saisyuUpdeteBtnFlg) {
        this.saisyuUpdeteBtnFlg = saisyuUpdeteBtnFlg;
    }

    public List<String> getChildAnkenIdList() {
        return childAnkenIdList;
    }

    public void setChildAnkenIdList(List<String> childAnkenIdList) {
        this.childAnkenIdList = childAnkenIdList;
    }

    public String getInputSaisyuMikomiNetFlg() {
        return inputSaisyuMikomiNetFlg;
    }

    public void setInputSaisyuMikomiNetFlg(String inputSaisyuMikomiNetFlg) {
        this.inputSaisyuMikomiNetFlg = inputSaisyuMikomiNetFlg;
    }

    public String getDiffCheckKbnHatFixedMikomi() {
        return diffCheckKbnHatFixedMikomi;
    }

    public void setDiffCheckKbnHatFixedMikomi(String diffCheckKbnHatFixedMikomi) {
        this.diffCheckKbnHatFixedMikomi = diffCheckKbnHatFixedMikomi;
    }

    public String getDiffCheckKbnHatChunyu() {
        return diffCheckKbnHatChunyu;
    }

    public void setDiffCheckKbnHatChunyu(String diffCheckKbnHatChunyu) {
        this.diffCheckKbnHatChunyu = diffCheckKbnHatChunyu;
    }

}
