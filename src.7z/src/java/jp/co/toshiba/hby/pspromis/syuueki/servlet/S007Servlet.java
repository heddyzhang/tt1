package jp.co.toshiba.hby.pspromis.syuueki.servlet;

import java.util.List;
import java.util.ArrayList;
import java.util.Map;
import java.util.HashMap;
import javax.inject.Inject;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpServletRequest;
import jp.co.toshiba.hby.pspromis.syuueki.bean.ResultMessageBean;
import jp.co.toshiba.hby.pspromis.syuueki.bean.S007Bean;
import jp.co.toshiba.hby.pspromis.syuueki.bean.ValidationMessageBean;
import jp.co.toshiba.hby.pspromis.syuueki.service.S007Service;
import jp.co.toshiba.hby.pspromis.syuueki.util.CdiUtils;
import jp.co.toshiba.hby.pspromis.syuueki.util.ParameterBinder;

/**
 * PS-Promis収益管理システム
 * 売上原価調整口画面 Servlet
 * @author sano
 */
@WebServlet(name = "S007", urlPatterns = {"/servlet/S007", "/servlet/S007/*"})
public class S007Servlet extends AbstractServlet {

    /**
     * jsp
     */
    private static final String INDEX_JSP = "S007/editNetCategory.jsp";

    /**
     * 使用serviceクラスをinjection(CDI)<br>
     * InjectアノテーションよりAPサーバー(Glassfish)側で自動的にインスタンス作成(new)される。<br>
     * service側はステートレスセッションbeanにするため、Statelessアノテーションをつけておくこと。<br>
     */
    @Inject
    private S007Service s007Service;

    /**
     * パラメータ格納クラスをinjection(CDI)<br>
     * InjectアノテーションよりAPサーバー(Glassfish)側で自動的にインスタンス作成(new)される。<br>
     */
    @Inject
    private S007Bean s007Bean;
    
    @Inject
    private ValidationMessageBean validationMessageBean;
    
    /**
     * 初期表示(調整口の取得)
     * @param req
     * @param resp
     * @return
     * @throws Exception 
     */
    public String indexAction(HttpServletRequest req, HttpServletResponse resp)
    throws Exception {
        logger.info("S007Servlet#indexAction");
        
        // リクエストパラメータをs007Beanの同名フィールドに一括コピー
        ParameterBinder.Bind(s007Bean, req);

        s007Service.indexExecute();

        return INDEX_JSP;
    }

    /**
     * 調整口データの保存/削除
     * @param req
     * @param resp
     * @return
     * @throws Exception 
     */
    public String execAction(HttpServletRequest req, HttpServletResponse resp)
    throws Exception {
        logger.info("S007Servlet#execAction");

        // リクエストパラメータをs007Beanの同名フィールドに一括コピー
        ParameterBinder.Bind(s007Bean, req);
        
        if(!s007Service.validation()){
            resopnseDecodeJson(resp, validationMessageBean.errorJsonInfo());
        } else {
            s007Service.updateExecute();
            
            // 処理結果を戻す。
            Map<String, Object> jsonMap = new HashMap<>();
            ResultMessageBean resultMessageBean = CdiUtils.getBean(ResultMessageBean.class);
            resultMessageBean.createResultMessage(jsonMap);
            resopnseDecodeJson(resp, jsonMap);
        }
        
        // resopnseDecodeJson(resp, s007Bean.getKaList());
        return null;
    }
    
    /**
     * カテゴリ選択候補の再取得
     * @param req
     * @param resp
     * @return
     * @throws Exception 
     */
    public String categoryDetailListAction(HttpServletRequest req, HttpServletResponse resp)
    throws Exception {
        logger.info("S007Servlet#categoryDetailListAction");
        
        ParameterBinder.Bind(s007Bean, req);
        
        List<String> detailList = new ArrayList<>();

        detailList.add("原Ｐ１");
        detailList.add("原Ｓ２");
        detailList.add("原Ｃ３");
        detailList.add("ＴＰＳＣ");
        detailList.add("ＩＨＩ");
        
        Map<String, Object> jsonMap = new HashMap<>();
        jsonMap.put("detailList", detailList);
        resopnseDecodeJson(resp, jsonMap);

        return null;
    }    
    
    /**
     * 
     */
    public String cateListAction(HttpServletRequest req, HttpServletResponse resp)
    throws Exception {
        logger.info("S007Servlet#cateListAction");
        
        ParameterBinder.Bind(s007Bean, req);
        
        s007Service.getChoiceList();
        
        resopnseDecodeJson(resp, s007Bean.getCateChoiceList());
//        List<String> detailList = new ArrayList<>();

//        detailList.add("原Ｐ１");
//        detailList.add("原Ｓ２");
//        detailList.add("原Ｃ３");
//        detailList.add("ＴＰＳＣ");
//        detailList.add("ＩＨＩ");
        
        
//        resopnseDecodeJson(resp, detailList);
                
        return null;
    }

}