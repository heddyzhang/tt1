package jp.co.toshiba.hby.pspromis.syuueki.service;

import java.lang.reflect.InvocationTargetException;
import java.util.List;
import java.util.Map;
import java.util.HashMap;
import java.util.Arrays;
import javax.ejb.Stateless;
import javax.inject.Inject;
import javax.interceptor.Interceptors;
import jp.co.toshiba.hby.pspromis.common.exception.PspRunTimeExceotion;
import jp.co.toshiba.hby.pspromis.syuueki.bean.S016Bean;
import jp.co.toshiba.hby.pspromis.syuueki.entity.OperationLog;
import jp.co.toshiba.hby.pspromis.syuueki.entity.SyuGeBukkenInfoTbl;
import jp.co.toshiba.hby.pspromis.syuueki.entity.SyuSaSpCurTbl;
import jp.co.toshiba.hby.pspromis.syuueki.entity.SyuSaNetCateTbl;
import jp.co.toshiba.hby.pspromis.syuueki.entity.SyuSaSonekiTitleTbl;
import jp.co.toshiba.hby.pspromis.syuueki.entity.SyuSaHanCateTbl;
//import jp.co.toshiba.hby.pspromis.syuueki.entity.SyuSaSeibansonekiTbl;
import jp.co.toshiba.hby.pspromis.syuueki.enums.Label;
import jp.co.toshiba.hby.pspromis.syuueki.facade.SyuGeBukenInfoTblFacade;
import jp.co.toshiba.hby.pspromis.syuueki.facade.SyuSaSpCurTblFacade;
import jp.co.toshiba.hby.pspromis.syuueki.facade.SyuSaNetCateTblFacade;
import jp.co.toshiba.hby.pspromis.syuueki.facade.SyuSaSonekiTitleTblFacade;
import jp.co.toshiba.hby.pspromis.syuueki.facade.SyuSaHanCateTblFacade;
import jp.co.toshiba.hby.pspromis.syuueki.interceptor.TranceInterceptor;
import jp.co.toshiba.hby.pspromis.syuueki.util.ConstantString;
import jp.co.toshiba.hby.pspromis.syuueki.util.EntityUtils;
import jp.co.toshiba.hby.pspromis.syuueki.util.LoginUserInfo;
import org.apache.commons.beanutils.PropertyUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
/**
 * ES-Promis収益管理システム
 * 見込列複写 Service
 * @author (NPC)S.Ibayashi
 */
@Stateless
@Interceptors({TranceInterceptor.class})
public class S016Service {

    public static final Logger log = LoggerFactory.getLogger(S016Service.class);

    @Inject
    private S016Bean s016Bean;

    @Inject
    private LoginUserInfo loginUserInfo;

    @Inject
    private SyuGeBukenInfoTblFacade syuGeBukenInfoTblFacade;
    
    @Inject
    private SyuSaSpCurTblFacade syuSaSpCurTblFacade;
    
    @Inject
    private SyuSaNetCateTblFacade syuSaNetCateTblFacade;
    
    @Inject
    private SyuSaSonekiTitleTblFacade syuSaSonekiTitleTblFacade;
    
    @Inject
    private SyuSaHanCateTblFacade syuSaHanCateTblFacade;
    
//    @Inject
//    private SyuSaSeibansonekiTblFacade syuSaSeibansonekiTblFacade;

    @Inject
    private StoredProceduresService storedProceduresService;

    @Inject
    private OperationLogService operationLogService;

    /**
     * 初期表示時機能
     * @throws Exception
     */
    public void indexExecute() throws Exception {
        // 案件基本情報(GE)を取得
        Map<String, Object> condition = getBaseCondition();
        SyuGeBukkenInfoTbl geEntity = getGeEntity(condition);

        String comparisonZenkaiId = StringUtils.defaultString(String.valueOf(geEntity.getZenkaiId()), ConstantString.geRirekiId);

        // 前回月次確定時の案件基本情報を取得
        if (!ConstantString.geRirekiId.equals(comparisonZenkaiId) && !ConstantString.teishutsuRirekiId.equals(comparisonZenkaiId)) {
            String zenkaiId = String.valueOf(geEntity.getZenkaiId());
            SyuGeBukkenInfoTbl zenkaiGeEntity = getZenkaiGeEntity(condition, zenkaiId);

            s016Bean.setZenkaiId(zenkaiId);
            if (zenkaiGeEntity != null) {
                s016Bean.setZenkaiKanjyoYm(zenkaiGeEntity.getKanjoYm());
            }
        }
        
        // ポテンシャル状態をチェック
        s016Bean.setPotentialFlg(StringUtils.defaultString(geEntity.getPotentialFlg()));
        // 事業部コード
        s016Bean.setDivisionCode(StringUtils.defaultString(geEntity.getDivisionCode()));

        // 複写先のデータ存在チェック
        checkDataCopyTo();
    }

    /**
     * 案件基本情報(GE)を取得
     */
    private SyuGeBukkenInfoTbl getGeEntity(final Map<String, Object> condition) throws Exception {
        SyuGeBukkenInfoTbl geEntity = syuGeBukenInfoTblFacade.findPk(condition);
        if (geEntity == null) {
            String errorMessage = Label.errorNoAnkenDate.getLabel();
            log.error(errorMessage + " ankenId=" + s016Bean.getAnkenId() + " rirekiId=" + s016Bean.getRirekiId());
            throw new PspRunTimeExceotion(errorMessage);
        }
        return geEntity;
    }

    /**
     * 前回月次確定時の案件基本情報を取得
     */
    private SyuGeBukkenInfoTbl getZenkaiGeEntity(final Map<String, Object> condition, String zenkaiId) throws Exception {
        Map<String, Object> zenkaiCondition = new HashMap<>();
        zenkaiCondition.putAll(condition);
        zenkaiCondition.put("rirekiId", Integer.parseInt(zenkaiId));

        SyuGeBukkenInfoTbl zenkaiGeEntity = syuGeBukenInfoTblFacade.findZenkaiRirekiInfo(zenkaiCondition);
        return zenkaiGeEntity;
    }

    /**
     * 複写先のデータ存在チェック
     */
    private void checkDataCopyTo() {
        int count = 0;

        Map<String, Object> condition = getBaseCondition();
        
        // 複写先データ有無区分(客先予算・最新見積)
        condition.put("dataKbn", "SM");
        count = syuSaSonekiTitleTblFacade.getDataKbnSpNetFlg(condition);
        if (count > 0) {
            s016Bean.setDataSmAmountCount(1);
        }

        // 複写先データ有無区分(当初見込(受政))
        condition.put("dataKbn", "JS");
        count = syuSaSonekiTitleTblFacade.getDataKbnSpNetFlg(condition);
        if (count > 0) {
            s016Bean.setDataJsAmountCount(1);
        }
    
        // 複写先データ有無区分(受注(契約時))
        condition.put("dataKbn", "JT");
        count = syuSaSonekiTitleTblFacade.getDataKbnSpNetFlg(condition);
        if (count > 0) {
            s016Bean.setDataJtAmountCount(1);
        }

        // 複写先データ有無区分(目標)
        condition.put("dataKbn", "MH");
        count = syuSaSonekiTitleTblFacade.getDataKbnSpNetFlg(condition);
        if (count > 0) {
            s016Bean.setDataMhAmountCount(1);
        }
    
        // 複写先データ有無区分(最終見込)
        condition.put("dataKbn", "FM");
        count = syuSaSonekiTitleTblFacade.getDataKbnSpNetFlg(condition);
        if (count > 0) {
            s016Bean.setDataFmAmountCount(1);
        }

        if ("1".equals(s016Bean.getPotentialFlg())) {
            // 複写先データ有無区分(見込大)
            condition.put("dataKbn", "PD");
            count = syuSaSonekiTitleTblFacade.getDataKbnSpNetFlg(condition);
            if (count > 0) {
                s016Bean.setDataPdAmountCount(1);
            }

            // 複写先データ有無区分(見込中)
            condition.put("dataKbn", "PT");
            count = syuSaSonekiTitleTblFacade.getDataKbnSpNetFlg(condition);
            if (count > 0) {
                s016Bean.setDataPtAmountCount(1);
            }

            // 複写先データ有無区分(見込小)
            condition.put("dataKbn", "PS");
            count = syuSaSonekiTitleTblFacade.getDataKbnSpNetFlg(condition);
            if (count > 0) {
                s016Bean.setDataPsAmountCount(1);
            }
        }
    }

    /**
     * 保存処理
     * @throws java.lang.Exception
     */
    public void saveExecute() throws Exception {
        // 複写処理
        exeCopy();
        
        // 操作ログの登録
        registOperationLog();
        
        // 再計算処理
        storedProceduresService.callAnkenRecalAuto(s016Bean.getAnkenId(), s016Bean.getRirekiId(), "2");
    }

    /**
     * 複写処理を実行
     */
    private void exeCopy() throws Exception {
//        Map<String, Object> baseCondition = getBaseCondition();
//
//        Map<String, Object> fromCondition = new HashMap<>(baseCondition);
//        fromCondition.put("fromDataKbn", s016Bean.getCopyFromCol());
//        fromCondition.put("toDataKbnList", Arrays.asList(s016Bean.getCopyToCol()));

        Map<String, Object> fromCondition = getCopyFromCondition();

        // SYU_SA_SP_CUR_TBLの転記(複写元が査定 or 注入累計はSP存在しないはずのため、複写対象外にする必要あり？)
        if (!"ST".equals(s016Bean.getCopyFromCol()) && !"TR".equals(s016Bean.getCopyFromCol())) {
            copySyuSaSpCurTbl(fromCondition);
        }

        // SYU_SA_NET_CATE_TBLの転記
        copySyuSaNetCateTbl(fromCondition);

        // 複写元が査定 or 発番 or 注入累計は以下のデータが存在しないはずのため、複写対象外にする必要あり？
        if (!"ST".equals(s016Bean.getCopyFromCol()) && !"HB".equals(s016Bean.getCopyFromCol()) && !"TR".equals(s016Bean.getCopyFromCol())) {
            // SYU_SA_SONEKI_TITLE_TBLの転記
            copySyuSaSonekiTitleTbl(fromCondition);
        
            // SYU_SA_HAN_CATE_TBLの転記
            copySyuSaHanCateTbl(fromCondition);
        }
        
        // SYU_SA_SEIBANSONEKI_TBLの転記
        //copySyuSaSeibansonekiTbl(fromCondition);
    }
    
    /**
     * ベースの条件を作成
     */
    private Map<String, Object> getBaseCondition() {
        Map<String, Object> condition = new HashMap<>();
        condition.put("ankenId", s016Bean.getAnkenId());
        condition.put("rirekiId", Integer.parseInt(s016Bean.getRirekiId()));
        return condition;
    }

    /**
     * 複写元のデータ取得条件を作成
     */
    private Map<String, Object> getCopyFromCondition() {
        Map<String, Object> condition = getBaseCondition();
        
        //condition.put("geRirekiId", Integer.parseInt(ConstantString.geRirekiId));
        condition.put("geRirekiId", Integer.parseInt(s016Bean.getRirekiId()));
        condition.put("toDataKbnList", Arrays.asList(s016Bean.getCopyToCol()));

        if ("FM_PREV".equals(s016Bean.getCopyFromCol())) {
            // 複写元に"最終見込(前回値)"を選択した場合、複写元をRテーブルにするための検索条件設定
            condition.put("fromDataKbn", "FM");
            condition.put("fromRirekiFlg", "R");
            if (StringUtils.isEmpty(s016Bean.getZenkaiId())) {
                condition.put("fromRirekiId", -999999999);   // 前回確定の履歴IDが存在しない場合、あり得ない履歴IDを取得(SQLでNULL状態で拾うために設定)
            } else {
                condition.put("fromRirekiId", Integer.parseInt(s016Bean.getZenkaiId()));
            }

        } else {
            condition.put("fromDataKbn", s016Bean.getCopyFromCol());
            condition.put("fromRirekiFlg", "");
            condition.put("fromRirekiId", Integer.parseInt(s016Bean.getRirekiId()));
        }
        return condition;
    }

    /**
     * entityを更新用データに加工
     */
    private <T> T getUpdateEntity(Class<T> entityClass, T fromEntity, String dataKbn)
    throws InstantiationException, IllegalAccessException, InvocationTargetException, NoSuchMethodException {
        T toEntity = entityClass.newInstance();
        PropertyUtils.copyProperties(toEntity, fromEntity);
        PropertyUtils.setProperty(toEntity, "dataKbn", dataKbn);
        EntityUtils.setCreatedInfo(toEntity, loginUserInfo.getUserId());

        return toEntity;
    }

    /**
     * SYU_SA_SP_CUR_TBLの転記
     */
    private void copySyuSaSpCurTbl(final Map<String, Object> fromCondition)
    throws InstantiationException, IllegalAccessException, InvocationTargetException, NoSuchMethodException {
        List<SyuSaSpCurTbl> list = syuSaSpCurTblFacade.findCopyList(fromCondition);
        for (SyuSaSpCurTbl entity: list) {
            for (String toDataKbn: s016Bean.getCopyToCol()) {
                SyuSaSpCurTbl updateEntity = getUpdateEntity(SyuSaSpCurTbl.class, entity, toDataKbn);
                syuSaSpCurTblFacade.setKeiyakuAmount(updateEntity);
            }
        }
    }

    /**
     * SYU_SA_NET_CATE_TBLの転記
     */
    private void copySyuSaNetCateTbl(final Map<String, Object> fromCondition)
    throws InstantiationException, IllegalAccessException, InvocationTargetException, NoSuchMethodException {
        List<SyuSaNetCateTbl> list = syuSaNetCateTblFacade.findCopyList(fromCondition);
        for (SyuSaNetCateTbl entity: list) {
            for (String toDataKbn: s016Bean.getCopyToCol()) {
                SyuSaNetCateTbl updateEntity = getUpdateEntity(SyuSaNetCateTbl.class, entity, toDataKbn);
                syuSaNetCateTblFacade.setNet(updateEntity);
            }
        }
    }
    
    /**
     * SYU_SA_SONEKI_TITLE_TBLの転記
     */
    private void copySyuSaSonekiTitleTbl(final Map<String, Object> fromCondition)
    throws InstantiationException, IllegalAccessException, InvocationTargetException, NoSuchMethodException {
        List<SyuSaSonekiTitleTbl> list = syuSaSonekiTitleTblFacade.findCopyList(fromCondition);
        for (SyuSaSonekiTitleTbl entity: list) {
            for (String toDataKbn: s016Bean.getCopyToCol()) {
                SyuSaSonekiTitleTbl updateEntity = getUpdateEntity(SyuSaSonekiTitleTbl.class, entity, toDataKbn);
                syuSaSonekiTitleTblFacade.setSonekiNet(updateEntity);
            }
        }
    }
    
    /**
     * SYU_SA_HAN_CATE_TBLの転記
     */
    private void copySyuSaHanCateTbl(final Map<String, Object> fromCondition)
    throws InstantiationException, IllegalAccessException, InvocationTargetException, NoSuchMethodException {
        List<SyuSaHanCateTbl> list = syuSaHanCateTblFacade.findCopyList(fromCondition);
        for (SyuSaHanCateTbl entity: list) {
            for (String toDataKbn: s016Bean.getCopyToCol()) {
                SyuSaHanCateTbl updateEntity = getUpdateEntity(SyuSaHanCateTbl.class, entity, toDataKbn);
                syuSaHanCateTblFacade.setHanChokuNet(updateEntity);
            }
        }
    }
    
    /**
     * SYU_SA_SEIBANSONEKI_TBLの転記
     */
//    private void copySyuSaSeibansonekiTbl(final Map<String, Object> fromCondition)
//    throws InstantiationException, IllegalAccessException, InvocationTargetException, NoSuchMethodException {
//        List<SyuSaSeibansonekiTbl> list = syuSaSeibansonekiTblFacade.findCopyList(fromCondition);
//        for (SyuSaSeibansonekiTbl entity: list) {
//            for (String toDataKbn: s016Bean.getCopyToCol()) {
//                SyuSaSeibansonekiTbl updateEntity = getUpdateEntity(SyuSaSeibansonekiTbl.class, entity, toDataKbn);
//                syuSaSeibansonekiTblFacade.setSeibanSonekiNet(updateEntity);
//            }
//        }
//    }
    
    /**
     * 操作ログの登録
     * @throws Exception
     */
    private void registOperationLog() throws Exception{
        OperationLog operationLog = operationLogService.getOperationLog();

        String objectType = operationLogService.getObjectType(s016Bean.getProcId());
        
        operationLog.setOperationCode("COPY_MIKOMI");
        operationLog.setObjectId(20);
        operationLog.setObjectType(objectType);
        operationLog.setRemarks(s016Bean.getAnkenId());

        operationLogService.insertOperationLogSearch(operationLog);
    }

}
