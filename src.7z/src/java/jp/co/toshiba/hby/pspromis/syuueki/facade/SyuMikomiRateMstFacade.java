/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package jp.co.toshiba.hby.pspromis.syuueki.facade;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.ejb.Stateless;
import javax.inject.Inject;
import javax.interceptor.Interceptors;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import jp.co.toshiba.hby.pspromis.syuueki.entity.SyuMikomiRateMst;
import jp.co.toshiba.hby.pspromis.syuueki.interceptor.TranceInterceptor;
import jp.co.toshiba.hby.pspromis.syuueki.util.Utils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 *
 * @author masaki
 */
@Stateless
@Interceptors({TranceInterceptor.class})
public class SyuMikomiRateMstFacade extends AbstractFacade<SyuMikomiRateMst> {
    
    private static final Logger logger = LoggerFactory.getLogger(SyuMikomiRateMstFacade.class);
    
    @PersistenceContext(unitName = jp.co.toshiba.hby.pspromis.syuueki.util.ConstantString.syuuekiDataSourceName)
    private EntityManager em;

    @Override
    protected EntityManager getEntityManager() {
        return em;
    }

    @Inject
    private Utils util;
    
    public SyuMikomiRateMstFacade() {
        super(SyuMikomiRateMst.class);
    }

    /**
     * 見込レートマスタ一覧を取得
     * @param condition
     * @param page
     * @return
     * @throws Exception 
     */
    public List<SyuMikomiRateMst> getMikomiRateMstList(Object condition) throws Exception {
        List<SyuMikomiRateMst> list
                = sqlExecutor.getResultList(em, SyuMikomiRateMst.class, "/sql/syuMikomiRateMst/selectSyuMikomiRateMstList.sql", condition);

        return list;
    }
    
    /**
     * 見込レートマスタ一覧を取得
     * @param condition
     * @param page
     * @return
     * @throws Exception 
     */
    public SyuMikomiRateMst getSyuMikomiRateMst(Object condition) {
        logger.info("SyuMikomiRateMstFacade#getSyuMikomiRateMst");

        SyuMikomiRateMst syuKiKanbaijTbl = sqlExecutor.getSingleResult(em, SyuMikomiRateMst.class, "/sql/syuMikomiRateMst/selectSyuMikomiRateMstList.sql", condition);
        
        return syuKiKanbaijTbl;
    }

    /**
     * 見込レートマスタの指定PKデータを取得
     */
    public SyuMikomiRateMst findPk(String type, String divisionCode, String mainOrderNo, String currencyCode) {
        SyuMikomiRateMst entity = null;
        
        Map<String, Object> condition = new HashMap<>();
        condition.put("mikomiRateType", type);
        condition.put("divisionCode", divisionCode);
        condition.put("mainOrderNo", mainOrderNo);
        condition.put("currencyCode", currencyCode);
        
        List<SyuMikomiRateMst> list
                = sqlExecutor.getResultList(em, SyuMikomiRateMst.class, "/sql/syuMikomiRateMst/selectSyuMikomiRateMstPk.sql", condition);
        
        if (list.size() > 0) {
            entity = list.get(0);
        }
        
        return entity;
    }
    
    /**
     * 見込レートマスタの削除
     * 
     * @param condition 
     */
    public int deleteMikomiRateMst(Object condition){
        logger.info("SyuMikomiRateMstFacade#deleteMikomiRateMst");

        return sqlExecutor.executeUpdateSql(em, "/sql/syuMikomiRateMst/deleteSyuMikomiRateMst.sql", condition);
    }
    
    /**
     * 見込レートマスタの登録
     * 
     * @param condition 
     */
    public int insertMikomiRateMst(Object condition){
        logger.info("SyuMikomiRateMstFacade#insertMikomiRateMst");
        
        return sqlExecutor.executeUpdateSql(em, "/sql/syuMikomiRateMst/insertSyuMikomiRateMst.sql", condition);
    }
    
    /**
     * 見込レートマスタの更新
     * 
     * @param condition 
     */
    public int updateMikomiRateMst(Object condition){
        logger.info("SyuMikomiRateMstFacade#updateMikomiRateMst");
        
        return sqlExecutor.executeUpdateSql(em, "/sql/syuMikomiRateMst/updateSyuMikomiRateMst.sql", condition);
    }
    
}
