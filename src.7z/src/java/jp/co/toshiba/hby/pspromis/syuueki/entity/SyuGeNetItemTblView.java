/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package jp.co.toshiba.hby.pspromis.syuueki.entity;

import java.io.Serializable;
import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.Date;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

/**
 *
 * @author wakamatsu
 */
@Entity
public class SyuGeNetItemTblView implements Serializable {
    private static final long serialVersionUID = 1L;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 32)
    @Column(name = "ANKEN_ID")
    @Id
    private String ankenId;
    @Basic(optional = false)
    @NotNull
    @Column(name = "RIREKI_ID")
    @Id
    private int rirekiId;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 5)
    @Column(name = "ORDER_ITEM")
    @Id
    private String orderItem;
    @Size(max = 12)
    @Column(name = "ORDER_NO")
    private String orderNo;
    @Size(max = 5)
    @Column(name = "SEIBAN")
    private String seiban;
    @Size(max = 256)
    @Column(name = "HINMEI")
    private String hinmei;
    @Column(name = "HAT_NET")
    private BigInteger hatNet;
    @Size(max = 2)
    @Column(name = "HAT_TANKA")
    private String hatTanka;
    @Column(name = "END_HAT_NET")
    private BigInteger endHatNet;
    @Size(max = 2)
    @Column(name = "END_HAT_NET_TANKA")
    private String endHatNetTanka;
    @Column(name = "CYUNYU_NET")
    private BigInteger cyunyuNet;
    @Column(name = "URIAGE_NET")
    private BigInteger uriageNet;
    @Column(name = "SEIBAN_SONEKI_NET")
    private BigInteger seibanSonekiNet;
    @Column(name = "HAT_ZAN_NET")
    private BigInteger hatZanNet;
    @Column(name = "FIXED_MIKOMI_NET")
    private BigInteger fixedMikomiNet;
    @Size(max = 1)
    @Column(name = "HACHU_FLG")
    private String hachuFlg;
    @Size(max = 3)
    @Column(name = "HACHU_CURRENCY_CODE")
    private String hachuCurrencyCode;
    // @Max(value=?)  @Min(value=?)//if you know range of your decimal fields consider using these annotations to enforce field validation
    @Column(name = "HACHU_RATE")
    private BigDecimal hachuRate;
    @Column(name = "HACHU_AMOUNT")
    private BigDecimal hachuAmount;
    @Column(name = "HACHU_GAIKA")
    private BigDecimal hachuGaika;
    @Size(max = 2)
    @Column(name = "URIAGE_END_FLG")
    private String uriageEndFlg;
    @Size(max = 2)
    @Column(name = "KOJO_CD")
    private String kojoCd;
    @Size(max = 6)
    @Column(name = "GI_BUKA_CD")
    private String giBukaCd;
    @Size(max = 32)
    @Column(name = "GI_BUKA_NAME")
    private String giBukaName;
    @Size(max = 6)
    @Column(name = "SEKKEI_BUKA_CD")
    private String sekkeiBukaCd;
    @Size(max = 32)
    @Column(name = "SEKKEI_BUKA_NAME")
    private String sekkeiBukaName;
    @Size(max = 2)
    @Column(name = "HAT_KBN")
    private String hatKbn;
    @Column(name = "CREATED_AT")
    @Temporal(TemporalType.TIMESTAMP)
    private Date createdAt;
    @Size(max = 32)
    @Column(name = "CREATED_BY")
    private String createdBy;
    @Column(name = "UPDATED_AT")
    @Temporal(TemporalType.TIMESTAMP)
    private Date updatedAt;
    @Size(max = 32)
    @Column(name = "UPDATED_BY")
    private String updatedBy;
    @Column(name = "UPDATED_BATCH_AT")
    @Temporal(TemporalType.TIMESTAMP)
    private Date updatedBatchAt;
    @Size(max = 32)
    @Column(name = "UPDATED_BATCH_BY")
    private String updatedBatchBy;

    /**
     * データ総件数
     */
    @Column(name = "COUNT")
    private Integer count = 0;
    
    /**
     * 月別
     */
    @Column(name = "NET01")
    private BigInteger net01;
    @Column(name = "NET02")
    private BigInteger net02;
    @Column(name = "NET03")
    private BigInteger net03;
    @Column(name = "NET04")
    private BigInteger net04;
    @Column(name = "NET05")
    private BigInteger net05;
    @Column(name = "NET06")
    private BigInteger net06;
    @Column(name = "NET_FROM")
    private BigInteger netFrom;
    @Column(name = "NET07")
    private BigInteger net07;
    @Column(name = "NET08")
    private BigInteger net08;
    @Column(name = "NET09")
    private BigInteger net09;
    @Column(name = "NET10")
    private BigInteger net10;
    @Column(name = "NET11")
    private BigInteger net11;
    @Column(name = "NET12")
    private BigInteger net12;
    @Column(name = "NET_TO")
    private BigInteger netTo;
    @Column(name = "NET_G")
    private BigInteger netG;
    
    /**
     * 項番一覧(最終)用項目      //データ型中途半端な状態, DBにない項目もある
     */
    @Column(name = "JUSEI_ENKA")
    private BigInteger juseiEnka;
    @Column(name = "JUSEI_CURRENCY_CODE")
    private String juseiCurrencyCode;
    @Column(name = "JUSEI_RATE")
    private BigDecimal juseiRate;
    @Column(name = "JUSEI_GAIKA")
    private BigDecimal juseiGaika;
    @Column(name = "JUTYU_ENKA")
    private BigInteger jutyuEnka;
    @Column(name = "JUTYU_CURRENCY_CODE")
    private String jutyuCurrencyCode;
    @Column(name = "JUTYU_RATE")
    private BigDecimal jutyuRate;
    @Column(name = "JUTYU_GAIKA")
    private BigDecimal jutyuGaika;
    @Column(name = "MOKUHYO_ENKA")
    private BigInteger mokuhyoEnka;
    @Column(name = "MOKUHYO_CURRENCY_CODE")
    private String mokuhyoCurrencyCode;
    @Column(name = "MOKUHYO_RATE")
    private BigDecimal mokuhyoRate;
    @Column(name = "MOKUHYO_GAIKA")
    private BigDecimal mokuhyoGaika;
    @Column(name = "SAISHINMITUMORI_ENKA")
    private BigInteger saishinmitumoriEnka;
    @Column(name = "SAISHINMITUMORI_CURRENCY_CODE")
    private String saishinmitumoriCurrencyCode;
    @Column(name = "SAISHINMITUMORI_RATE")
    private BigDecimal saishinmitumoriRate;
    @Column(name = "SAISHINMITUMORI_GAIKA")
    private BigDecimal saishinmitumoriGaika;
    @Column(name = "POTEN_DAI_ENKA")
    private BigInteger potenDaiEnka;
    @Column(name = "POTEN_DAI_CURRENCY_CODE")
    private String potenDaiCurrencyCode;
    @Column(name = "POTEN_DAI_RATE")
    private BigDecimal potenDaiRate;
    @Column(name = "POTEN_DAI_GAIKA")
    private BigDecimal potenDaiGaika;
    @Column(name = "POTEN_TYU_ENKA")
    private BigInteger potenTyuEnka;
    @Column(name = "POTEN_TYU_CURRENCY_CODE")
    private String potenTyuCurrencyCode;
    @Column(name = "POTEN_TYU_RATE")
    private BigDecimal potenTyuRate;
    @Column(name = "POTEN_TYU_GAIKA")
    private BigDecimal potenTyuGaika;
    @Column(name = "POTEN_SHO_ENKA")
    private BigInteger potenShoEnka;
    @Column(name = "POTEN_SHO_CURRENCY_CODE")
    private String potenShoCurrencyCode;
    @Column(name = "POTEN_SHO_RATE")
    private BigDecimal potenShoRate;
    @Column(name = "POTEN_SHO_GAIKA")
    private BigDecimal potenShoGaika;
    @Column(name = "SEKEISATEI_ENKA")
    private BigInteger sekeisateiEnka;
    @Column(name = "SEKEISATEI_CURRENCY_CODE")
    private String sekeisateiCurrencyCode;
    @Column(name = "SEKEISATEI_RATE")
    private BigDecimal sekeisateiRate;
    @Column(name = "SEKEISATEI_GAIKA")
    private BigDecimal sekeisateiGaika;
    @Column(name = "CHOTATUSATEI_ENKA")
    private BigInteger chotatusateiEnka;
    @Column(name = "CHOTATUSATEI_CURRENCY_CODE")
    private String chotatusateiCurrencyCode;
    @Column(name = "CHOTATUSATEI_RATE")
    private BigDecimal chotatusateiRate;
    @Column(name = "CHOTATUSATEI_GAIKA")
    private BigDecimal chotatusateiGaika;
    @Column(name = "HACHU_ENKA")
    private BigInteger hachuEnka;
    @Column(name = "KENSHU_ENKA")
    private BigInteger kenshuEnka;
    @Column(name = "MIKENSHU_ENKA")
    private BigInteger mikenshuEnka;
    @Column(name = "NET_KAKUTEI_FLG")
    private String netKakuteiFlg;
    @Column(name = "HACHU_DATE")
    @Temporal(TemporalType.TIMESTAMP)
    private Date hachuDate;
    @Column(name = "KENSHU_DATE")
    @Temporal(TemporalType.TIMESTAMP)
    private Date kenshuDate;
    @Column(name = "KENSHU_CURRENCY_CODE")
    private String kenshuCurrencyCode;
    @Column(name = "KENSHU_RATE")
    private BigDecimal kenshuRate;
    @Column(name = "KENSHU_GAIKA")
    private BigDecimal kenshuGaika;
    @Column(name = "MIKENSHU_CURRENCY_CODE")
    private String mikenshuCurrencyCode;
    @Column(name = "MIKENSHU_RATE")
    private BigDecimal mikenshuRate;
    @Column(name = "MIKENSHU_GAIKA")
    private BigDecimal mikenshuGaika;
    @Column(name = "BIKOU")
    private String bikou;
    @Column(name = "END_FIXED_MIKOMI_NET")
    private BigInteger endFixedMikomiNet;
    @Column(name = "FIXED_MIKOMI_NET_BEF")
    private BigInteger fixedMikomiNetBef;
    @Column(name = "MIKOMI_FLG")
    private String mikomiFlg;
    @Column(name = "SEIBAN_NOKI")
    @Temporal(TemporalType.DATE)
    private Date seibanNoki;
    @Column(name = "KI_CATEGORY_NAME1")
    private String kiCategoryName1;
    @Column(name = "KI_CATEGORY_NAME2")
    private String kiCategoryName2;
    @Column(name = "KI_CATEGORY_SEQ")
    private String kiCategorySeq;
    @Column(name = "SA_CATEGORY_NAME1")
    private String saCategoryName1;
    @Column(name = "SA_CATEGORY_NAME2")
    private String saCategoryName2;
    @Column(name = "SA_CATEGORY_SEQ")
    private String saCategorySeq;
    @Column(name = "HAT_NET_CURRENCY_CODE")
    private String hatNetCurrencyCode;
    @Column(name = "HAT_NET_RATE")
    private BigDecimal hatNetRate;
    @Column(name = "HAT_NET_GAIKA")
    private BigDecimal hatNetGaika;
    @Column(name = "HAT_NET_BEF")
    private BigInteger hatNetBef;
    @Column(name = "HAT_NET_BEF_CURRENCY_CODE")
    private String hatNetBefCurrencyCode;
    @Column(name = "HAT_NET_BEF_RATE")
    private BigDecimal hatNetBefRate;
    @Column(name = "HAT_NET_BEF_GAIKA")
    private BigDecimal hatNetBefGaika;
    @Column(name = "HAT_NET_BEF_TANKA")
    private String hatNetBefTanka;
    @Column(name = "FIXED_MIKOMI_CURRENCY_CODE")
    private String fixedMikomiCurrecyCode;
    @Column(name = "FIXED_MIKOMI_RATE")
    private BigDecimal fixedMikomiNetRate;
    @Column(name = "FIXED_MIKOMI_NET_GAIKA")
    private BigDecimal fixedMikomiNetGaika;
    @Column(name = "END_FIXED_NET_CURRENCY_CODE")
    private String endFixedNetCurrecyCode;
    @Column(name = "END_FIXED_NET_RATE")
    private BigDecimal endFixedNetRate;
    @Column(name = "END_FIXED_NET_GAIKA")
    private BigDecimal endFixedNetGaika;
    @Column(name = "FIXED_MIKOMI_BEF_CURRENCY_CODE")
    private String fixedMikomiBefCurrencyCode;
    @Column(name = "FIXED_MIKOMI_BEF_RATE")
    private BigDecimal fixedMikomiBefRate;
    @Column(name = "FIXED_MIKOMI_BEF_GAIKA")
    private BigDecimal fixedMikomiBefGaika;
    @Column(name = "CHUTYU_NET_CURRENCY_CODE")
    private String chutyuNetCurrencyCode;
    @Column(name = "CHUTYU_NET_RATE")
    private BigDecimal chutyuNetRate;
    @Column(name = "CHUTYU_NET_GAIKA")
    private BigDecimal chutyuNetGaika;
    @Column(name = "SEIBAN_NET_CURRENCY_CODE")
    private String seibanNetCurrencyCode;
    @Column(name = "SEIBAN_NET_RATE")
    private BigDecimal seibanNetRate;
    @Column(name = "SEIBAN_NET_GAIKA")
    private BigDecimal seibanNetGaika;
    @Column(name = "URIAGE_NET_CURRENCY_CODE")
    private String uriageNetCurrencyCode;
    @Column(name = "URIAGE_NET_RATE")
    private BigDecimal uriageNetRate;
    @Column(name = "URIAGE_NET_GAIKA")
    private BigDecimal uriageNetGaika;
    @Column(name = "HAT_TANKA_BEF")
    private String hatTankaBef;
    @Column(name = "HAT_NET_DIFF")
    private BigInteger hatNetDiff;
    @Column(name = "HAT_NET_DIFF_RATE")
    private BigDecimal hatNetDiffRate;
    @Column(name = "HAT_NET_DIFF_GAIKA")
    private BigDecimal hatNetDiffGaika;
    @Column(name = "KANJO_YM")
    private String kanjoYm;
    @Column(name = "KI_CATEGORY_CODE")
    private String kiCategoryCode;

    
    /**
     *　検索条件 （）/IEC（設計）
     */
    @Column(name = "DEPT_ABB_NAME2")
    private String DeptAbbName2;
    
    /**
     * 検索条件　（工場）設計
     */
    @Column(name = "DEPT_ABB_NAME3")
    private String DeptAbbName3;
    
    @Column(name = "KARI_NET_FLG")
    private String kariNetFlg;
    
    /**
     * 見積Link用
     */
    @Column(name = "SPURT_NO")
    private String spurtNo;
    @Column(name = "JOBGR_SEQ")
    private Long jobgrSeq;
    @Column(name = "REQ_SEQ")
    private Short reqSeq;
    @Column(name = "REQ_REV")
    private Short reqRev;
    @Column(name = "IRAI_KBN")
    private String iraiKbn;
    @Column(name = "BUNDLE_CODE")
    private String bundleCode;
    @Column(name = "QNO")
    private String qno;
    
    
    public SyuGeNetItemTblView() {
    }

    public String getAnkenId() {
        return ankenId;
    }

    public void setAnkenId(String ankenId) {
        this.ankenId = ankenId;
    }

    public int getRirekiId() {
        return rirekiId;
    }

    public void setRirekiId(int rirekiId) {
        this.rirekiId = rirekiId;
    }

    public String getOrderItem() {
        return orderItem;
    }

    public void setOrderItem(String orderItem) {
        this.orderItem = orderItem;
    }

    public String getOrderNo() {
        return orderNo;
    }

    public void setOrderNo(String orderNo) {
        this.orderNo = orderNo;
    }

    public String getSeiban() {
        return seiban;
    }

    public void setSeiban(String seiban) {
        this.seiban = seiban;
    }

    public String getHinmei() {
        return hinmei;
    }

    public void setHinmei(String hinmei) {
        this.hinmei = hinmei;
    }

    public BigInteger getHatNet() {
        return hatNet;
    }

    public void setHatNet(BigInteger hatNet) {
        this.hatNet = hatNet;
    }

    public String getHatTanka() {
        return hatTanka;
    }

    public void setHatTanka(String hatTanka) {
        this.hatTanka = hatTanka;
    }

    public BigInteger getEndHatNet() {
        return endHatNet;
    }

    public void setEndHatNet(BigInteger endHatNet) {
        this.endHatNet = endHatNet;
    }

    public String getEndHatNetTanka() {
        return endHatNetTanka;
    }

    public void setEndHatNetTanka(String endHatNetTanka) {
        this.endHatNetTanka = endHatNetTanka;
    }

    public BigInteger getCyunyuNet() {
        return cyunyuNet;
    }

    public void setCyunyuNet(BigInteger cyunyuNet) {
        this.cyunyuNet = cyunyuNet;
    }

    public BigInteger getUriageNet() {
        return uriageNet;
    }

    public void setUriageNet(BigInteger uriageNet) {
        this.uriageNet = uriageNet;
    }

    public BigInteger getHatZanNet() {
        return hatZanNet;
    }

    public void setHatZanNet(BigInteger hatZanNet) {
        this.hatZanNet = hatZanNet;
    }

    public BigInteger getFixedMikomiNet() {
        return fixedMikomiNet;
    }

    public void setFixedMikomiNet(BigInteger fixedMikomiNet) {
        this.fixedMikomiNet = fixedMikomiNet;
    }

    public String getHachuFlg() {
        return hachuFlg;
    }

    public void setHachuFlg(String hachuFlg) {
        this.hachuFlg = hachuFlg;
    }

    public String getHachuCurrencyCode() {
        return hachuCurrencyCode;
    }

    public void setHachuCurrencyCode(String hachuCurrencyCode) {
        this.hachuCurrencyCode = hachuCurrencyCode;
    }

    public BigDecimal getHachuRate() {
        return hachuRate;
    }

    public void setHachuRate(BigDecimal hachuRate) {
        this.hachuRate = hachuRate;
    }

    public BigDecimal getHachuAmount() {
        return hachuAmount;
    }

    public void setHachuAmount(BigDecimal hachuAmount) {
        this.hachuAmount = hachuAmount;
    }

    public String getUriageEndFlg() {
        return uriageEndFlg;
    }

    public void setUriageEndFlg(String uriageEndFlg) {
        this.uriageEndFlg = uriageEndFlg;
    }

    public String getKojoCd() {
        return kojoCd;
    }

    public void setKojoCd(String kojoCd) {
        this.kojoCd = kojoCd;
    }

    public String getGiBukaCd() {
        return giBukaCd;
    }

    public void setGiBukaCd(String giBukaCd) {
        this.giBukaCd = giBukaCd;
    }

    public String getGiBukaName() {
        return giBukaName;
    }

    public void setGiBukaName(String giBukaName) {
        this.giBukaName = giBukaName;
    }

    public String getSekkeiBukaCd() {
        return sekkeiBukaCd;
    }

    public void setSekkeiBukaCd(String sekkeiBukaCd) {
        this.sekkeiBukaCd = sekkeiBukaCd;
    }

    public String getSekkeiBukaName() {
        return sekkeiBukaName;
    }

    public void setSekkeiBukaName(String sekkeiBukaName) {
        this.sekkeiBukaName = sekkeiBukaName;
    }

    public String getHatKbn() {
        return hatKbn;
    }

    public void setHatKbn(String hatKbn) {
        this.hatKbn = hatKbn;
    }

    public Date getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(Date createdAt) {
        this.createdAt = createdAt;
    }

    public String getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    public Date getUpdatedAt() {
        return updatedAt;
    }

    public void setUpdatedAt(Date updatedAt) {
        this.updatedAt = updatedAt;
    }

    public String getUpdatedBy() {
        return updatedBy;
    }

    public void setUpdatedBy(String updatedBy) {
        this.updatedBy = updatedBy;
    }

    public Date getUpdatedBatchAt() {
        return updatedBatchAt;
    }

    public void setUpdatedBatchAt(Date updatedBatchAt) {
        this.updatedBatchAt = updatedBatchAt;
    }

    public String getUpdatedBatchBy() {
        return updatedBatchBy;
    }

    public void setUpdatedBatchBy(String updatedBatchBy) {
        this.updatedBatchBy = updatedBatchBy;
    }

    public Integer getCount() {
        return count;
    }

    public void setCount(Integer count) {
        this.count = count;
    }
    
    public BigInteger getNet01() {
        return net01;
    }

    public void setNet01(BigInteger net01) {
        this.net01 = net01;
    }

    public BigInteger getNet02() {
        return net02;
    }

    public void setNet02(BigInteger net02) {
        this.net02 = net02;
    }

    public BigInteger getNet03() {
        return net03;
    }

    public void setNet03(BigInteger net03) {
        this.net03 = net03;
    }

    public BigInteger getNet04() {
        return net04;
    }

    public void setNet04(BigInteger net04) {
        this.net04 = net04;
    }

    public BigInteger getNet05() {
        return net05;
    }

    public void setNet05(BigInteger net05) {
        this.net05 = net05;
    }

    public BigInteger getNet06() {
        return net06;
    }

    public void setNet06(BigInteger net06) {
        this.net06 = net06;
    }

    public BigInteger getNetFrom() {
        return netFrom;
    }

    public void setNetFrom(BigInteger netFrom) {
        this.netFrom = netFrom;
    }

    public BigInteger getNet07() {
        return net07;
    }

    public void setNet07(BigInteger net07) {
        this.net07 = net07;
    }

    public BigInteger getNet08() {
        return net08;
    }

    public void setNet08(BigInteger net08) {
        this.net08 = net08;
    }

    public BigInteger getNet09() {
        return net09;
    }

    public void setNet09(BigInteger net09) {
        this.net09 = net09;
    }

    public BigInteger getNet10() {
        return net10;
    }

    public void setNet10(BigInteger net10) {
        this.net10 = net10;
    }

    public BigInteger getNet11() {
        return net11;
    }

    public void setNet11(BigInteger net11) {
        this.net11 = net11;
    }

    public BigInteger getNet12() {
        return net12;
    }

    public void setNet12(BigInteger net12) {
        this.net12 = net12;
    }

    public BigInteger getNetTo() {
        return netTo;
    }

    public void setNetTo(BigInteger netTo) {
        this.netTo = netTo;
    }

    public BigInteger getNetG() {
        return netG;
    }

    public void setNetG(BigInteger netG) {
        this.netG = netG;
    }

    public String getDeptAbbName2() {
        return DeptAbbName2;
    }

    public void setDeptAbbName2(String DeptAbbName2) {
        this.DeptAbbName2 = DeptAbbName2;
    }

    public String getDeptAbbName3() {
        return DeptAbbName3;
    }

    public void setDeptAbbName3(String DeptAbbName3) {
        this.DeptAbbName3 = DeptAbbName3;
    }

    public BigInteger getSeibanSonekiNet() {
        return seibanSonekiNet;
    }

    public void setSeibanSonekiNet(BigInteger seibanSonekiNet) {
        this.seibanSonekiNet = seibanSonekiNet;
    }
    
    public BigInteger getJuseiEnka() {
        return juseiEnka;
    }

    public void setJuseiEnka(BigInteger juseiEnka) {
        this.juseiEnka = juseiEnka;
    }
    
    public String getJuseiCurrencyCode() {
        return juseiCurrencyCode;
    }

    public void setJuseiCurrencyCode(String juseiCurrencyCode) {
        this.juseiCurrencyCode = juseiCurrencyCode;
    }
    
    public BigDecimal getJuseiRate() {
        return juseiRate;
    }

    public void setJuseiRate(BigDecimal juseiRate) {
        this.juseiRate = juseiRate;
    }
    
    public BigDecimal getJuseiGaika() {
        return juseiGaika;
    }

    public void setJuseiGaika(BigDecimal juseiGaika) {
        this.juseiGaika = juseiGaika;
    }
    
    public BigInteger getJutyuEnka() {
        return jutyuEnka;
    }

    public void setJutyuEnka(BigInteger jutyuEnka) {
        this.jutyuEnka = jutyuEnka;
    }
    
    public String getJutyuCurrencyCode() {
        return jutyuCurrencyCode;
    }

    public void setJutyuCurrencyCode(String jutyuCurrencyCode) {
        this.jutyuCurrencyCode = jutyuCurrencyCode;
    }
    
    public BigDecimal getJutyuRate() {
        return jutyuRate;
    }

    public void setJutyuRate(BigDecimal jutyuRate) {
        this.jutyuRate = jutyuRate;
    }
    
    public BigDecimal getJutyuGaika() {
        return jutyuGaika;
    }

    public void setJutyuGaika(BigDecimal jutyuGaika) {
        this.jutyuGaika = jutyuGaika;
    }
    
    public BigInteger getMokuhyoEnka() {
        return mokuhyoEnka;
    }

    public void setMokuhyoEnka(BigInteger mokuhyoEnka) {
        this.mokuhyoEnka = mokuhyoEnka;
    }
    
    public String getMokuhyoCurrencyCode() {
        return mokuhyoCurrencyCode;
    }

    public void setMokuhyoCurrencyCode(String mokuhyoCurrencyCode) {
        this.mokuhyoCurrencyCode = mokuhyoCurrencyCode;
    }
    
    public BigDecimal getMokuhyoRate() {
        return mokuhyoRate;
    }

    public void setMokuhyoRate(BigDecimal mokuhyoRate) {
        this.mokuhyoRate = mokuhyoRate;
    }
    
    public BigDecimal getMokuhyoGaika() {
        return mokuhyoGaika;
    }

    public void setMokuhyoGaika(BigDecimal mokuhyoGaika) {
        this.mokuhyoGaika = mokuhyoGaika;
    }
    
    public BigInteger getSaishinmitumoriEnka() {
        return saishinmitumoriEnka;
    }

    public void setSaishinmitumoriEnka(BigInteger saishinmitumoriEnka) {
        this.saishinmitumoriEnka = saishinmitumoriEnka;
    }
    
    public String getSaishinmitumoriCurrencyCode() {
        return saishinmitumoriCurrencyCode;
    }

    public void setSaishinmitumoriCurrencyCode(String saishinmitumoriCurrencyCode) {
        this.saishinmitumoriCurrencyCode = saishinmitumoriCurrencyCode;
    }
    
    public BigDecimal getSaishinmitumoriRate() {
        return saishinmitumoriRate;
    }

    public void setSaishinmitumoriRate(BigDecimal saishinmitumoriRate) {
        this.saishinmitumoriRate = saishinmitumoriRate;
    }
    
    public BigDecimal getSaishinmitumoriGaika() {
        return saishinmitumoriGaika;
    }

    public void setSaishinmitumoriGaika(BigDecimal saishinmitumoriGaika) {
        this.saishinmitumoriGaika = saishinmitumoriGaika;
    }
    
    public BigInteger getPotenDaiEnka() {
        return potenDaiEnka;
    }

    public void setPotenDaiEnka(BigInteger potenDaiEnka) {
        this.potenDaiEnka = potenDaiEnka;
    }
    
    public String getPotenDaiCurrencyCode() {
        return potenDaiCurrencyCode;
    }

    public void setPotenDaiCurrencyCode(String potenDaiCurrencyCode) {
        this.potenDaiCurrencyCode = potenDaiCurrencyCode;
    }
    
    public BigDecimal getPotenDaiRate() {
        return potenDaiRate;
    }

    public void setPotenDaiRate(BigDecimal potenDaiRate) {
        this.potenDaiRate = potenDaiRate;
    }
    
    public BigDecimal getPotenDaiGaika() {
        return potenDaiGaika;
    }

    public void setPotenDaiGaika(BigDecimal potenDaiGaika) {
        this.potenDaiGaika = potenDaiGaika;
    }
    
    public BigInteger getPotenTyuEnka() {
        return potenTyuEnka;
    }

    public void setPotenTyuEnka(BigInteger potenTyuEnka) {
        this.potenTyuEnka = potenTyuEnka;
    }
    
    public String getPotenTyuCurrencyCode() {
        return potenTyuCurrencyCode;
    }

    public void setPotenTyuCurrencyCode(String potenTyuCurrencyCode) {
        this.potenTyuCurrencyCode = potenTyuCurrencyCode;
    }
    
    public BigDecimal getPotenTyuRate() {
        return potenTyuRate;
    }

    public void setPotenTyuRate(BigDecimal potenTyuRate) {
        this.potenTyuRate = potenTyuRate;
    }
    
    public BigDecimal getPotenTyuGaika() {
        return potenTyuGaika;
    }

    public void setPotenTyuGaika(BigDecimal potenTyuGaika) {
        this.potenTyuGaika = potenTyuGaika;
    }
    
    public BigInteger getPotenShoEnka() {
        return potenShoEnka;
    }

    public void setPotenShoEnka(BigInteger potenShoEnka) {
        this.potenShoEnka = potenShoEnka;
    }
    
    public String getPotenShoCurrencyCode() {
        return potenShoCurrencyCode;
    }

    public void setPotenShoCurrencyCode(String potenShoCurrencyCode) {
        this.potenShoCurrencyCode = potenShoCurrencyCode;
    }
    
    public BigDecimal getPotenShoRate() {
        return potenShoRate;
    }

    public void setPotenShoRate(BigDecimal potenShoRate) {
        this.potenShoRate = potenShoRate;
    }
    
    public BigDecimal getPotenShoGaika() {
        return potenShoGaika;
    }

    public void setPotenShoGaika(BigDecimal potenShoGaika) {
        this.potenShoGaika = potenShoGaika;
    }
    
    public BigInteger getSekeisateiEnka() {
        return sekeisateiEnka;
    }

    public void setSekeisateiEnka(BigInteger sekeisateiEnka) {
        this.sekeisateiEnka = sekeisateiEnka;
    }
    
    public String getSekeisateiCurrencyCode() {
        return sekeisateiCurrencyCode;
    }

    public void setSekeisateiCurrencyCode(String sekeisateiCurrencyCode) {
        this.sekeisateiCurrencyCode = sekeisateiCurrencyCode;
    }
    
    public BigDecimal getSekeisateiRate() {
        return sekeisateiRate;
    }

    public void setSekeisateiRate(BigDecimal sekeisateiRate) {
        this.sekeisateiRate = sekeisateiRate;
    }
    
    public BigDecimal getSekeisateiGaika() {
        return sekeisateiGaika;
    }

    public void setSekeisateiGaika(BigDecimal sekeisateiGaika) {
        this.sekeisateiGaika = sekeisateiGaika;
    }
    
    public BigInteger getChotatusateiEnka() {
        return chotatusateiEnka;
    }

    public void setChotatusateiEnka(BigInteger chotatusateiEnka) {
        this.chotatusateiEnka = chotatusateiEnka;
    }
    
    public String getChotatusateiCurrencyCode() {
        return chotatusateiCurrencyCode;
    }

    public void setChotatusateiCurrencyCode(String chotatusateiCurrencyCode) {
        this.chotatusateiCurrencyCode = chotatusateiCurrencyCode;
    }
    
    public BigDecimal getChotatusateiRate() {
        return chotatusateiRate;
    }

    public void setChotatusateiRate(BigDecimal chotatusateiRate) {
        this.chotatusateiRate = chotatusateiRate;
    }
    
    public BigDecimal getChotatusateiGaika() {
        return chotatusateiGaika;
    }

    public void setChotatusateiGaika(BigDecimal chotatusateiGaika) {
        this.chotatusateiGaika = chotatusateiGaika;
    }
    
    public BigInteger getHachuEnka() {
        return hachuEnka;
    }

    public void setHachuEnka(BigInteger hachuEnka) {
        this.hachuEnka = hachuEnka;
    }
    
    public BigInteger getKenshuEnka() {
        return kenshuEnka;
    }

    public void setKenshuEnka(BigInteger kenshuEnka) {
        this.kenshuEnka = kenshuEnka;
    }
    
    public BigInteger getMikenshuEnka() {
        return mikenshuEnka;
    }

    public void setMikenshuEnka(BigInteger mikenshuEnka) {
        this.mikenshuEnka = mikenshuEnka;
    }
    
    public String getNetKakuteiFlg() {
        return netKakuteiFlg;
    }

    public void setNetKakuteiFlg(String netKakuteiFlg) {
        this.netKakuteiFlg = netKakuteiFlg;
    }
    
    public Date getHachuDate() {
        return hachuDate;
    }

    public void setHachuDate(Date hachuDate) {
        this.hachuDate = hachuDate;
    }
    
    public String getKenshuCurrencyCode() {
        return kenshuCurrencyCode;
    }

    public void setKenshuCurrencyCode(String kenshuCurrencyCode) {
        this.kenshuCurrencyCode = kenshuCurrencyCode;
    }
    
    public BigDecimal getKenshuRate() {
        return kenshuRate;
    }

    public void setKenshuRate(BigDecimal kenshuRate) {
        this.kenshuRate = kenshuRate;
    }
    
    public BigDecimal getKenshuGaika() {
        return kenshuGaika;
    }

    public void setKenshuGaika(BigDecimal kenshuGaika) {
        this.kenshuGaika = kenshuGaika;
    }
    
    public String getMikenshuCurrencyCode() {
        return mikenshuCurrencyCode;
    }

    public void setMikenshuCurrencyCode(String mikenshuCurrencyCode) {
        this.mikenshuCurrencyCode = mikenshuCurrencyCode;
    }
    
    public BigDecimal getMikenshuRate() {
        return mikenshuRate;
    }

    public void setMikenshuRate(BigDecimal mikenshuRate) {
        this.mikenshuRate = mikenshuRate;
    }
    
    public BigDecimal getMikenshuGaika() {
        return mikenshuGaika;
    }

    public void setMikenshuGaika(BigDecimal mikenshuGaika) {
        this.mikenshuGaika = mikenshuGaika;
    }
    
    public String getBikou() {
        return bikou;
    }

    public void setBikou(String bikou) {
        this.bikou = bikou;
    }
    
    public BigInteger getEndFixedMikomiNet() {
        return endFixedMikomiNet;
    }

    public void setEndFixedMikomiNet(BigInteger endFixedMikomiNet) {
        this.endFixedMikomiNet = endFixedMikomiNet;
    }
    
    public String getMikomiFlg() {
        return mikomiFlg;
    }

    public void setMikomiFlg(String mikomiFlg) {
        this.mikomiFlg = mikomiFlg;
    }

    public Date getSeibanNoki() {
        return seibanNoki;
    }

    public void setSeibanNoki(Date seibanNoki) {
        this.seibanNoki = seibanNoki;
    }
    
    public String getKiCategoryName1() {
        return kiCategoryName1;
    }

    public void setKiCategoryName1(String kiCategoryName1) {
        this.kiCategoryName1 = kiCategoryName1;
    }
    
    public String getKiCategoryName2() {
        return kiCategoryName2;
    }

    public void setKiCategoryName2(String kiCategoryName2) {
        this.kiCategoryName2 = kiCategoryName2;
    }
    
    public String getKiCategorySeq() {
        return kiCategorySeq;
    }

    public void setKiCategorySeq(String kiCategorySeq) {
        this.kiCategorySeq = kiCategorySeq;
    }
    
    public String getSaCategoryName1() {
        return saCategoryName1;
    }

    public void setSaCategoryName1(String saCategoryName1) {
        this.saCategoryName1 = saCategoryName1;
    }
    
    public String getSaCategoryName2() {
        return saCategoryName2;
    }

    public void setSaCategoryName2(String saCategoryName2) {
        this.saCategoryName2 = saCategoryName2;
    }
    
    public String getSaCategorySeq() {
        return saCategorySeq;
    }

    public void setSaCategorySeq(String saCategorySeq) {
        this.saCategorySeq = saCategorySeq;
    }
    
    public String getHatNetCurrencyCode() {
        return hatNetCurrencyCode;
    }

    public void setHatNetCurrencyCode(String hatNetCurrencyCode) {
        this.hatNetCurrencyCode = hatNetCurrencyCode;
    }
    
    public BigDecimal getHatNetRate() {
        return hatNetRate;
    }

    public void setHatNetRate(BigDecimal hatNetRate) {
        this.hatNetRate = hatNetRate;
    }
    
    public BigDecimal getHatNetGaika() {
        return hatNetGaika;
    }

    public void setHatNetGaika(BigDecimal hatNetGaika) {
        this.hatNetGaika = hatNetGaika;
    }
    
    public BigInteger getHatNetBef() {
        return hatNetBef;
    }

    public void setHatNetBef(BigInteger hatNetBef) {
        this.hatNetBef = hatNetBef;
    }
    
    public String getHatNetBefCurrencyCode() {
        return hatNetBefCurrencyCode;
    }

    public void setHatNetBefCurrencyCode(String hatNetBefCurrencyCode) {
        this.hatNetBefCurrencyCode = hatNetBefCurrencyCode;
    }
    
    public BigDecimal getHatNetBefRate() {
        return hatNetBefRate;
    }

    public void setHatNetBefRate(BigDecimal hatNetBefRate) {
        this.hatNetBefRate = hatNetBefRate;
    }
    
    public BigDecimal getHatNetBefGaika() {
        return hatNetBefGaika;
    }

    public void setHatNetBefGaika(BigDecimal hatNetBefGaika) {
        this.hatNetBefGaika = hatNetBefGaika;
    }
    
    public String getFixedMikomiCurrecyCode() {
        return fixedMikomiCurrecyCode;
    }

    public void setFixedMikomiCurrecyCode(String fixedMikomiCurrecyCode) {
        this.fixedMikomiCurrecyCode = fixedMikomiCurrecyCode;
    }
    
    public BigDecimal getFixedMikomiNetRate() {
        return fixedMikomiNetRate;
    }

    public void setFixedMikomiNetRate(BigDecimal fixedMikomiNetRate) {
        this.fixedMikomiNetRate = fixedMikomiNetRate;
    }
    
    public BigDecimal getFixedMikomiNetGaika() {
        return fixedMikomiNetGaika;
    }

    public void setFixedMikomiNetGaika(BigDecimal fixedMikomiNetGaika) {
        this.fixedMikomiNetGaika = fixedMikomiNetGaika;
    }
    
    public String getEndFixedNetCurrecyCode() {
        return endFixedNetCurrecyCode;
    }

    public void setEndFixedNetCurrecyCode(String endFixedNetCurrecyCode) {
        this.endFixedNetCurrecyCode = endFixedNetCurrecyCode;
    }
    
    public BigDecimal getEndFixedNetRate() {
        return endFixedNetRate;
    }

    public void setEndFixedNetRate(BigDecimal endFixedNetRate) {
        this.endFixedNetRate = endFixedNetRate;
    }
    
    public BigDecimal getEndFixedNetGaika() {
        return endFixedNetGaika;
    }

    public void setEndFixedNetGaika(BigDecimal endFixedNetGaika) {
        this.endFixedNetGaika = endFixedNetGaika;
    }
    
    public String getFixedMikomiBefCurrencyCode() {
        return fixedMikomiBefCurrencyCode;
    }

    public void setFixedMikomiBefCurrencyCode(String fixedMikomiBefCurrencyCode) {
        this.fixedMikomiBefCurrencyCode = fixedMikomiBefCurrencyCode;
    }
    
    public BigDecimal getFixedMikomiBefRate() {
        return fixedMikomiBefRate;
    }

    public void setFixedMikomiBefRate(BigDecimal fixedMikomiBefRate) {
        this.fixedMikomiBefRate = fixedMikomiBefRate;
    }
    
    public BigDecimal getFixedMikomiBefGaika() {
        return fixedMikomiBefGaika;
    }

    public void setFixedMikomiBefGaika(BigDecimal fixedMikomiBefGaika) {
        this.fixedMikomiBefGaika = fixedMikomiBefGaika;
    }
    
    public String getChutyuNetCurrencyCode() {
        return chutyuNetCurrencyCode;
    }

    public void setChutyuNetCurrencyCode(String chutyuNetCurrencyCode) {
        this.chutyuNetCurrencyCode = chutyuNetCurrencyCode;
    }
    
    public BigDecimal getChutyuNetRate() {
        return chutyuNetRate;
    }

    public void setChutyuNetRate(BigDecimal chutyuNetRate) {
        this.chutyuNetRate = chutyuNetRate;
    }
    
    public BigDecimal getChutyuNetGaika() {
        return chutyuNetGaika;
    }

    public void setChutyuNetGaika(BigDecimal chutyuNetGaika) {
        this.chutyuNetGaika = chutyuNetGaika;
    }
    
    public String getSeibanNetCurrencyCode() {
        return seibanNetCurrencyCode;
    }

    public void setSeibanNetCurrencyCode(String seibanNetCurrencyCode) {
        this.seibanNetCurrencyCode = seibanNetCurrencyCode;
    }
    
    public BigDecimal getSeibanNetRate() {
        return seibanNetRate;
    }

    public void setSeibanNetRate(BigDecimal seibanNetRate) {
        this.seibanNetRate = seibanNetRate;
    }
    
    public BigDecimal getSeibanNetGaika() {
        return seibanNetGaika;
    }

    public void setSeibanNetGaika(BigDecimal seibanNetGaika) {
        this.seibanNetGaika = seibanNetGaika;
    }
    
    public String getUriageNetCurrencyCode() {
        return uriageNetCurrencyCode;
    }

    public void setUriageNetCurrencyCode(String uriageNetCurrencyCode) {
        this.uriageNetCurrencyCode = uriageNetCurrencyCode;
    }
    
    public BigDecimal getUriageNetRate() {
        return uriageNetRate;
    }

    public void setUriageNetRate(BigDecimal uriageNetRate) {
        this.uriageNetRate = uriageNetRate;
    }
    
    public BigDecimal getUriageNetGaika() {
        return uriageNetGaika;
    }

    public void setUriageNetGaika(BigDecimal uriageNetGaika) {
        this.uriageNetGaika = uriageNetGaika;
    }
    
    public String getHatTankaBef() {
        return hatTankaBef;
    }

    public void setHatTankaBef(String hatTankaBef) {
        this.hatTankaBef = hatTankaBef;
    }
    
    public Date getKenshuDate() {
        return kenshuDate;
    }
    
    public void setKenshuDate(Date kenshuDate) {
        this.kenshuDate = kenshuDate;
    }
    
    public BigInteger getHatNetDiff() {
        return hatNetDiff;
    }

    public void setHatNetDiff(BigInteger hatNetDiff) {
        this.hatNetDiff = hatNetDiff;
    }
    
    public BigDecimal getHatNetDiffRate() {
        return hatNetDiffRate;
    }

    public void setHatNetDiffRate(BigDecimal hatNetDiffRate) {
        this.hatNetDiffRate = hatNetDiffRate;
    }
    
    public BigDecimal getHatNetDiffGaika() {
        return hatNetDiffGaika;
    }

    public void setHatNetDiffGaika(BigDecimal hatNetDiffGaika) {
        this.hatNetDiffGaika = hatNetDiffGaika;
    }
    
    public BigDecimal getHachuGaika() {
        return hachuGaika;
    }

    public void setHachuGaika(BigDecimal hachuGaika) {
        this.hachuGaika = hachuGaika;
    }
    
    public String getHatNetBefTanka() {
        return hatNetBefTanka;
    }

    public void setHatNetBefTanka(String hatNetBefTanka) {
        this.hatNetBefTanka = hatNetBefTanka;
    }
    
    public BigInteger getFixedMikomiNetBef() {
        return fixedMikomiNetBef;
    }
    
    public void setFixedMikomiNetBef(BigInteger fixedMikomiNetBef) {
        this.fixedMikomiNetBef = fixedMikomiNetBef;
    }
    
    public String getKariNetFlg(){
        return kariNetFlg;
    }
    
    public void setKariNetFlg(String kariNetFlg){
        this.kariNetFlg = kariNetFlg;
    }
    
    public String getKanjoYm() {
        return kanjoYm;
    }
    
    public void setKanjoYm (String kanjoYm) {
        this.kanjoYm = kanjoYm;
    }

    public String getKiCategoryCode() {
        return kiCategoryCode;
    }

    public void setKiCategoryCode(String kiCategoryCode) {
        this.kiCategoryCode = kiCategoryCode;
    }

    public String getSpurtNo() {
        return spurtNo;
    }

    public void setSpurtNo(String spurtNo) {
        this.spurtNo = spurtNo;
    }

    public Long getJobgrSeq() {
        return jobgrSeq;
    }

    public void setJobgrSeq(Long jobgrSeq) {
        this.jobgrSeq = jobgrSeq;
    }

    public Short getReqSeq() {
        return reqSeq;
    }

    public void setReqSeq(Short reqSeq) {
        this.reqSeq = reqSeq;
    }

    public Short getReqRev() {
        return reqRev;
    }

    public void setReqRev(Short reqRev) {
        this.reqRev = reqRev;
    }

    public String getIraiKbn() {
        return iraiKbn;
    }

    public void setIraiKbn(String iraiKbn) {
        this.iraiKbn = iraiKbn;
    }

    public String getBundleCode() {
        return bundleCode;
    }

    public void setBundleCode(String bundleCode) {
        this.bundleCode = bundleCode;
    }

    public String getQno() {
        return qno;
    }

    public void setQno(String qno) {
        this.qno = qno;
    }

}
