package jp.co.toshiba.hby.pspromis.syuueki.bean;

import java.util.Arrays;
import java.util.List;
import java.util.Map;
import javax.enterprise.context.RequestScoped;
import javax.inject.Named;
import jp.co.toshiba.hby.pspromis.common.util.StringUtil;
import jp.co.toshiba.hby.pspromis.syuueki.entity.SyuWfControlTbl;
import jp.co.toshiba.hby.pspromis.syuueki.enums.Label;
import lombok.Getter;
import lombok.Setter;

/**
 *
 * @author rnomura
 */
@Named(value = "s023Bean")
@RequestScoped
@Getter @Setter
public class S023Bean extends AbstractBean {
    
    /**
     * 一覧検索フラグ
     */
    private String listFlg = "0";
    
    /**
     * 一覧表示データ総件数
     */
    private Integer count;

    /**
     * 現在表示するページ番号
     */
    private Integer page;
    
    /**
     * リセットフラグ
     */
    private String resetFlg;
    
    /**
     * 検索結果リスト
     */
    private List<Map<String, Object>> aggregateList;
    
    /**
     * データ取得SQL用keyカウント 
     */
    private int keyCount;
    
    /**
     * 集計画面で選択されたアンカーのコード0
     */
    private String aggregateKey0;
    
    /**
     * 集計画面で選択されたアンカーのコード1
     */
    private String aggregateKey1;
    
    /**
     * 集計画面で選択されたアンカーのコード2
     */
    private String aggregateKey2;
    
    /**
     * 検索結果リスト
     */
    private List<Map<String, Object>> summaryList;
    
    /**
     *  画面表示1次集計キー
     */
    private String headPrimaryKey;
    
    /**
     *  画面表示2次集計キー
     */
    private String headSecondaryKey;
    
    
    public String getListFlg(){
        return listFlg;
    }
    
    public void setListFlg(String listFlg) {
        this.listFlg = listFlg;
    }
    
    public String getResetFlg(){
        return resetFlg;
    }
    
    public void setResetFlg(String resetFlg){
        this.resetFlg = resetFlg;
    }

    public Integer getCount() {
        return count;
    }

    public void setCount(Integer count) {
        this.count = count;
    }

    public Integer getPage() {
        return page;
    }

    public void setPage(Integer page) {
        this.page = page;
    }
    
    public List<Map<String, Object>> getAggregateList(){
        return aggregateList;
    }
    
    public void setAggregateList(List<Map<String, Object>> aggregateList){
        this.aggregateList = aggregateList;
    }
    
    public int getKeyCount(){
        return keyCount;
    }
    
    public void setKeyCount(int keyCount){
        this.keyCount = keyCount;
    }
    
    public String getAggregateKey0(){
        return aggregateKey0;
    }
    
    public void setAggregateKey0(String aggregateKey0){
        this.aggregateKey0 = aggregateKey0;
    }
    
    public String getAggregateKey1(){
        return aggregateKey1;
    }
    
    public void setAggregateKey1(String aggregateKey1){
        this.aggregateKey1 = aggregateKey1;
    }
    
    public String getAggregateKey2(){
        return aggregateKey2;
    }
    
    public void setAggregateKey2(String aggregateKey2){
        this.aggregateKey2 = aggregateKey2;
    }
    
    public List<Map<String, Object>> getSummaryList(){
        return summaryList;
    }
    
    public void setSummaryList(List<Map<String, Object>> summaryList){
        this.summaryList = summaryList;
    }
    
    public String getHeadPrimaryKey(){
        return headPrimaryKey;
    }
    
    public void setHeadPrimaryKey(String headPrimaryKey){
        this.headPrimaryKey = headPrimaryKey;
    }
    
    public String getHeadSecondaryKey(){
        return headSecondaryKey;
    }
    
    public void setHeadSecondaryKey(String headSecondaryKey){
        this.headSecondaryKey = headSecondaryKey;
    }
    
    /**
     * ラベルからKEYを判断
     * @param label
     * @return 
     */
    public String keyDecision(String label){
        String key = "";
        
        if(label.equals(Label.now.getLabel())){
            key = "NOW";
        }
        if(label.equals(Label.before.getLabel())){
            key = "BEF";
        }
        if(label.equals(Label.diff2.getLabel())){
            key = "DIF";
        }
        
        if(label.equals(Label.jyuchu.getLabel())){
            key = "J";
        }
        if(label.equals(Label.uriage.getLabel())){
            key = "U";
        }
        if(label.equals(Label.kaisyu.getLabel())){
            key = "K";
        }
        
        return key;
    }
    
    /**
     * 集計行のclassを判断する
     * @param comparison
     * @return 
     */
    public String getCellStyle(String comparison) {
        String style = ""; 
        
        if(comparison.equals(Label.before.getLabel())){
            style = "before";
        }
        if(comparison.equals(Label.diff2.getLabel())){
            style = "diff";
        }
        
        return style;
    }

}
