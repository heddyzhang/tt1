package jp.co.toshiba.hby.pspromis.syuueki.facade;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.ejb.Stateless;
import javax.inject.Inject;
import javax.interceptor.Interceptors;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import jp.co.toshiba.hby.pspromis.common.util.BeanUtil;
import jp.co.toshiba.hby.pspromis.syuueki.bean.OrderNoLinkBean;
import jp.co.toshiba.hby.pspromis.syuueki.entity.AnkenMatomeMapTbl;
import jp.co.toshiba.hby.pspromis.syuueki.entity.IspJissekiData;
import jp.co.toshiba.hby.pspromis.syuueki.entity.StringEntity;
import jp.co.toshiba.hby.pspromis.syuueki.entity.SyuGeBukkenInfoTbl;
import jp.co.toshiba.hby.pspromis.syuueki.interceptor.TranceInterceptor;
import jp.co.toshiba.hby.pspromis.syuueki.jdbc.SqlExecutorOriginal;
import jp.co.toshiba.hby.pspromis.syuueki.jdbc.SqlFile;
import jp.co.toshiba.hby.pspromis.syuueki.util.LoginUserInfo;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 *
 * @author ibayashi
 */
@Stateless
@Interceptors({TranceInterceptor.class})
public class SyuGeBukenInfoTblFacade extends AbstractFacade<SyuGeBukkenInfoTbl> {

    /**
     * ロガ－
     */
    private static final Logger logger = LoggerFactory.getLogger(SyuGeBukenInfoTblFacade.class);

    @PersistenceContext(unitName = jp.co.toshiba.hby.pspromis.syuueki.util.ConstantString.syuuekiDataSourceName)
    private EntityManager em;

    @Inject
    private LoginUserInfo loginUserInfo;

    @Inject
    private SqlExecutorOriginal sqlExecutorExtend;
    
    @Inject
    private OrderNoLinkBean orderNoLinkBean;
    
    @Inject
    private SyuGeBukkenInfoTbl bukkenEntity;

    @Override
    protected EntityManager getEntityManager() {
        return em;
    }

    /**
     * Injection sqlExecutor
     */
    @Inject
    SysdateEntityFacade sysdateEntityFacade;

    public SyuGeBukenInfoTblFacade() {
        super(SyuGeBukkenInfoTbl.class);
    }

    /**
     * パラメータにログイン者idをセット
     */
    private Map<String, Object> addParamLoginId(Map<String, Object> _params) {
        Map<String, Object> ret = _params;
        if (ret == null) {
            ret = new HashMap<>();
        }
        ret.put("userId", loginUserInfo.getUserId());
        return ret;
    }

    /**
     * 指定PKのデータ(Entity)を取得
     *
     * @param condition
     * @return
     */
    public SyuGeBukkenInfoTbl findPk(Object condition) {
//        SyuGeBukkenInfoTbl entity
//                = sqlExecutor.getSingleResult(em, SyuGeBukkenInfoTbl.class, "/sql/selectSyuueki.sql", condition);

        List<SyuGeBukkenInfoTbl> list
                = sqlExecutor.getResultList(em, SyuGeBukkenInfoTbl.class, "/sql/selectSyuueki.sql", condition);

        SyuGeBukkenInfoTbl entity = null;

        if (CollectionUtils.isNotEmpty(list)) {
            entity = list.get(0);
        }

        return entity;
    }

    /**
     * 対象案件(物件Key)の見積番号を取得(複数のためカンマ区切り)
     *
     * @param condition
     * @return
     */
    public String findMitumoriNo(Object condition) {
        SqlFile sqlFile = new SqlFile();
        String mitumoriNo
                = sqlExecutorExtend.getString(em, "/sql/selectMitumoriNo.sql", condition);

        return mitumoriNo;
    }

    /**
     * 対象案件(物件Key)の指定職種(営業:L 原価:M)のJobGrを取得(複数のためカンマ区切り)
     *
     * @param ankenId
     * @param syokusyuCode
     * @return
     */
    public String findSyokusyuJobGrName(String ankenId, String syokusyuCode) {
        Map<String, String> condition = new HashMap<>();
        condition.put("ankenId", ankenId);
        condition.put("syokusyuCode", syokusyuCode);

        String jobGrName
                = sqlExecutorExtend.getString(em, "/sql/selectAnkenJobGr.sql", condition);

        return jobGrName;
    }

    /**
     * 対象案件(物件Key)のまとめ案件を取得
     *
     * @param condition
     * @return
     */
    public SyuGeBukkenInfoTbl findParentAnken(Object condition) {
        SyuGeBukkenInfoTbl entity
                = sqlExecutor.getSingleResult(em, SyuGeBukkenInfoTbl.class, "/sql/selectParentAnken.sql", condition);

        return entity;
    }

    /**
     * 対象案件(物件Key)の子案件を取得
     *
     * @param condition
     * @return
     */
    public List<SyuGeBukkenInfoTbl> findChildAnken(Object condition) {
        List<SyuGeBukkenInfoTbl> entity
                = sqlExecutor.getResultList(em, SyuGeBukkenInfoTbl.class, "/sql/selectChildAnken.sql", condition);

        return entity;
    }

    /**
     * 対象案件(物件Key)の子案件の案件番号のみを取得
     *
     * @param condition
     * @return
     */
    public List<String> findChildAnkenNo(Object condition) {
        List<AnkenMatomeMapTbl> list
                = sqlExecutor.getResultList(em, AnkenMatomeMapTbl.class, "/sql/selectChildAnkenNo.sql", condition);

        List<String> childList = new ArrayList<>();
        for (AnkenMatomeMapTbl entity : list) {
            childList.add(entity.getAnkenNo());
        }

        return childList;
    }

    /**
     * 注番から対象案件を取得
     *
     * @param condition
     * @return
     */
    public SyuGeBukkenInfoTbl findOnBukken(Map<String, Object> condition) {
        List<SyuGeBukkenInfoTbl> list
                = sqlExecutor.getResultList(em, SyuGeBukkenInfoTbl.class, "/sql/mikomiUpload/selectOnoBukken.sql", condition);

        SyuGeBukkenInfoTbl en = null;

        if (list != null) {
            if (list.size() > 0) {
                en = list.get(0);
            }
        }

        return en;
    }

    /**
     * 指定物件に対して再計算FLGを立てる
     *
     * @param ankenId 案件id
     * @param rirekiId 履歴id
     */
    public void setSaikeisanFlg(String ankenId, Integer rirekiId, String saikeisanFlg) {
        Map<String, Object> condition = new HashMap<>();
        condition.put("saikeisanFlg", saikeisanFlg);
        condition.put("ankenId", ankenId);
        condition.put("rirekiId", rirekiId);
        condition.put("updatedBy", loginUserInfo.getUserId());

        sqlExecutor.executeUpdateSql(em, "/sql/mikomiUpload/updateSaikeisanFlg.sql", condition);
    }

    /**
     * 指定物件に対して再計算FLGを立てる（見込レートマスタ更新時）
     *
     * @param typeFlg 種類(前受金あり当期or前受金あり翌期="ARI"／前受金なし翌期or前受金なし当期翌月="NASI")
     * @param mainOrderNo 代表注番
     * @param division 事業部
     */
    public int setSaikeisanFlgMikomiRate(Map<String, Object> condition) {
        /*
        Map<String, Object> condition = new HashMap<>();
        condition.put("typeFlg", typeFlg);
        condition.put("mainOrderNo", mainOrderNo);
        condition.put("division", division);
        condition.put("userId", loginUserInfo.getUserId());
        condition.put("currencyCode", currencyCode);
         */

        return sqlExecutor.executeUpdateSql(em, "/sql/syuMikomiRateMst/updateSaikeisanFlg.sql", condition);
    }

    /**
     * 指定物件の備考を登録する
     *
     * @param ankenId 案件id
     * @param rirekiId 履歴id
     * @param bikou 備考
     * @param kbn "SA":最終見込損益の備考にセット "KI":期間損益備考にセット
     */
    public void setBiko(String ankenId, Integer rirekiId, String bikou, String kbn) {
        Map<String, Object> condition = new HashMap<>();
        condition.put("ankenId", ankenId);
        condition.put("rirekiId", rirekiId);
        condition.put("bikou", bikou);
        condition.put("kbn", kbn);
        condition.put("updatedBy", loginUserInfo.getUserId());

        sqlExecutor.executeUpdateSql(em, "/sql/syuGeBukkenInfoTbl/updateBikou.sql", condition);
    }

    /**
     * 代表注番から案件を取得する
     */
    public SyuGeBukkenInfoTbl getMainOrderNoAnken(Map<String, Object> condition) {
        List<SyuGeBukkenInfoTbl> list
                = sqlExecutor.getResultList(em, SyuGeBukkenInfoTbl.class, "/sql/syuGeBukkenInfoTbl/selectMainOrderAnken.sql", condition);

        SyuGeBukkenInfoTbl en = null;

        if (list != null) {
            if (list.size() > 0) {
                en = list.get(0);
            }
        }

        return en;
    }

    /**
     * 代表注番から案件番号を取得
     */
    public String getMainOrderNoAnkenId(Map<String, Object> condition) {
        String ankenId = "";
        SyuGeBukkenInfoTbl en = getMainOrderNoAnken(condition);
        if (en != null) {
            ankenId = en.getAnkenId();
        }
        return ankenId;
    }

    /**
     * 白地調整案件の復活/取消
     */
    public void updateShiraji(Map<String, Object> condition) {
        sqlExecutor.executeUpdateSql(em, "/sql/syuGeBukkenInfoTbl/updateShirajiEdit.sql", condition);
    }

    /**
     * 受注売上見込一覧編集の受注月/売上月の保存
     *
     * @param condition
     * @return
     */
    public int updateEndMonth(Map<String, Object> _params) {
        Map<String, Object> params = addParamLoginId(_params);
        int count = sqlExecutor.executeUpdateSql(em, "/sql/syuGeBukkenInfoTbl/updateEndMonth.sql", params);
        return count;
    }

    /**
     * 検収月の保存
     * 2017/11/14 MOD #5 #12 #22 （収益）受注年月と（収益）売上予定を加える
     * @param _params
     * @return
     */
    public int updateKaisyuEndMonth(Map<String, Object> _params) {
        Map<String, Object> params = addParamLoginId(_params);
        int count = sqlExecutor.executeUpdateSql(em, "/sql/syuGeBukkenInfoTbl/updateKaisyuEndMonth.sql", params);
        return count;
    }

    /**
     * 収益物件TBLへの登録or更新
     */
    public void merge(SyuGeBukkenInfoTbl facade) {
        this.em.merge(BeanUtil.createAndCopy(SyuGeBukkenInfoTbl.class, facade));
    }

    /**
     * 前回の履歴情報を取得
     */
    public SyuGeBukkenInfoTbl findZenkaiRirekiInfo(Map<String, Object> _params) {

        List<SyuGeBukkenInfoTbl> list
                = sqlExecutor.getResultList(em, SyuGeBukkenInfoTbl.class, "/sql/syuGeBukkenInfoTbl/selectRirekiInfo.sql", _params);

        SyuGeBukkenInfoTbl entity = null;
        if (CollectionUtils.isNotEmpty(list)) {
            entity = list.get(0);
        }

        return entity;
    }

    /**
     * SP確定,NET確定,備考を更新
     *
     * @param entity
     */
    public void setSpKakuteiFlg(SyuGeBukkenInfoTbl entity) {
        sqlExecutor.executeUpdateSql(em, "/sql/syuGeBukkenInfoTbl/updateSyuGeBukenInfoTbl.sql", entity);
    }

    /**
     *
     * @param condition
     * @return
     */
    public String getZenkaiId(Map<String, Object> condition){
        StringEntity zenkaiId = null;

        List<StringEntity> list = sqlExecutor.getResultList(em, StringEntity.class, "/sql/syuGeBukkenInfoTbl/selectZenkaiId.sql", condition);

        if(CollectionUtils.isNotEmpty(list)){
            zenkaiId = list.get(0);
            try{
                int id = new Integer(zenkaiId.getString());
            } catch(NumberFormatException e){
                return null;
            }
        } else {
            return null;
        }

        return zenkaiId.getString();
    }

    /**
     *
     * @param ankenId
     * @param rirekiId
     * @param rirekiFlg
     * @return
     */
    public String getChotatuGaikaFlg(String ankenId, String rirekiId, String rirekiFlg){
        Map<String, Object> condition = new HashMap<>();
        condition.put("ankenId", ankenId);
        condition.put("rirekiId", rirekiId);
        condition.put("rirekiFlg", rirekiFlg);

        String flg = null;

        List<StringEntity> list = sqlExecutor.getResultList(em, StringEntity.class, "/sql/syuGeBukkenInfoTbl/selectChotatuGaikaFlg.sql", condition);

        if(CollectionUtils.isNotEmpty(list)){
            flg = list.get(0).getString();
        }

        return flg;
    }

    /**
     * 注番を条件に、既存の収益FLG設定済の案件を取得
     * @param orderNo 注番
     * @param targetAnkenId 対象の案件ID(この案件以外を対象にする)
     * @param rirekiId 履歴ID
     * @param ankenFlg 案件FLG
     * @return 対象の注番の案件ID
     */
    //public String getNowSyuekiFlgAnkenId(String orderNo, String targetAnkenId, String rirekiId, String ankenFlg) {
    public String getNowSyuekiFlgAnkenId(Map<String, Object> condition) {
//        Map<String, Object> condition = new HashMap<>();
//        condition.put("orderNo", orderNo);
//        condition.put("targetAnkenId", targetAnkenId);
//        condition.put("rirekiId", Integer.parseInt(rirekiId));
//        condition.put("ankenFlg", ankenFlg);

        List<StringEntity> list = sqlExecutor.getResultList(em, StringEntity.class, "/sql/syuGeBukkenInfoTbl/selectNowSyuekiFlgAnkenId.sql", condition);
        String ankenId = "";

        if (CollectionUtils.isNotEmpty(list)) {
            ankenId = StringUtils.defaultString(list.get(0).getString());
        }

        return ankenId;
    }

    /**
     * 対象案件の収益FLGを設定
     */
    public Integer updateSyuekiFlg(Map<String, Object> condition) {
        Integer count = sqlExecutor.executeUpdateSql(em, "/sql/syuGeBukkenInfoTbl/updateSyuekiFlg.sql", condition);
        return count;
    }

    /**
     * 売上基準を取得
     * @param ankenId 物件key
     * @param rirekiId 履歴ID
     * @param rirekiFlg 履歴FLG("R"の場合はSYU_R_GE_BUKKEN_INFO_TBLを検索)
     * @return
     */
    public String getSalesClass(String ankenId, String rirekiId, String rirekiFlg){
        String salesClass = "";

        Map<String, Object> condition = new HashMap<>();
        condition.put("ankenId", ankenId);
        condition.put("rirekiId", Integer.parseInt(rirekiId));
        if (StringUtils.isNotEmpty(rirekiFlg)) {
            condition.put("rirekiFlg", rirekiFlg);
        }

        List<StringEntity> list = sqlExecutor.getResultList(em, StringEntity.class, "/sql/syuGeBukkenInfoTbl/selectSalesClass.sql", condition);

        if (CollectionUtils.isNotEmpty(list)) {
            salesClass = StringUtils.defaultString(list.get(0).getString());
        }

        return salesClass;
    }

    /**
     * 売上基準を取得
     * @param ankenId 物件key
     * @param rirekiId 履歴ID
     * @return
     */
    public String getSalesClass(String ankenId, String rirekiId){
        return getSalesClass(ankenId, rirekiId, "");
    }

    
    public List<SyuGeBukkenInfoTbl> getOrderNoLink(String orderNo, Integer rirekiId, String[] divisionCodes){
        Map<String, Object> condition = new HashMap<>();
        condition.put("orderNo", orderNo);
        condition.put("rirekiId", rirekiId);
        condition.put("divisionCode", divisionCodes);

        List<SyuGeBukkenInfoTbl> list
            = sqlExecutor.getResultList(em, SyuGeBukkenInfoTbl.class, "/sql/syuGeBukkenInfoTbl/selectOrderNoLink.sql", condition);            

        return list;
    }
    
     public List<IspJissekiData> getDataList(Map<String, Object> condition){
        List<IspJissekiData> list = sqlExecutor.getResultList(em, IspJissekiData.class, "/sql/syuGeBukkenInfoTbl/selectBukkenIspNetList.sql", condition);
        return list;
    }
    
}
