package jp.co.toshiba.hby.pspromis.syuueki.bean;

import java.util.List;
import java.util.Map;
import javax.enterprise.context.RequestScoped;
import javax.inject.Named;
import jp.co.toshiba.hby.pspromis.syuueki.entity.SyuGeCategoryMapView;

/**
 *
 * @author kitajima
 */
@Named(value = "s007Bean")
@RequestScoped
public class S007Bean extends AbstractBean {
    
    /**
     * 処理元の画面ID(操作ログの登録で利用)
     */
    private String procId;

    /**
     * 案件フラグ
     */
    private String ankenFlg;
    
    /**
     * 注番
     */
    private String orderNo;
    
    /**
     * 代表注番
     */
    private String mainOrderNo;
    
    /**
     * 物件の事業部コード
     */
    private String divisionCode;
    
    /**
     * 原価調整口リスト
     */
    private List<Map<String, Object>> choseiList;
    
    /**
     * カテゴリーコード
     */
    private String[] categoryCode;
    
    /**
     * 分類1
     */
    private String[] categoryKbn1;
    
    /**
     * 分類2
     */
    private String[] categoryKbn2;
    
    /**
     * カテゴリ名称1
     */
    private String[] categoryName1;
    
    /**
     * カテゴリ名称2
     */
    private String[] categoryName2;
    
    /**
     * カテゴリ名称1
     */
    private String[] befCategoryName1;
    
    /**
     * カテゴリ名称2
     */
    private String[] befCategoryName2;
    
    /**
     * カテゴリSEQ
     */
    private String[] categorySeq;
    
    /**
     * 削除フラグ
     */
    private String[] delFlg;
    
    /**
     * 削除注釈ラベル表示FLG
     */
    private Integer delLabelFlg;
    
    /**
     * 画面入力値リスト
     */
    private String[] listSaveFlg;
    
    /**
     * 対象案件の事業部
     */
    private String salesClass;
    
    /**
     * カテゴリ選択候補リスト
     */
    private List<SyuGeCategoryMapView> cateList;
    
    /**
     * 新規行フラグ
     */
    private String[] createdFlg;
    
    /**
     *  選択候補用フラグ
     */
    private String cateListFlg;
    
    /**
     *  選択候補リスト
     */
    private List<String> cateChoiceList;
    
    /**
     *  選択候補入力値1
     */
    private String choiceName1;
    
    /**
     *  選択候補入力値2
     */
    private String choiceName2;
/*
    public String getAnkenId() {
        return ankenId;
    }

    public void setAnkenId(String ankenId) {
        this.ankenId = ankenId;
    }
*/
    public String getAnkenFlg() {
        return ankenFlg;
    }

    public void setAnkenFlg(String ankenFlg) {
        this.ankenFlg = ankenFlg;
    }

    public String getOrderNo() {
        return orderNo;
    }

    public void setOrderNo(String orderNo) {
        this.orderNo = orderNo;
    }

    public String getMainOrderNo() {
        return mainOrderNo;
    }

    public void setMainOrderNo(String mainOrderNo) {
        this.mainOrderNo = mainOrderNo;
    }
    
    public List<Map<String, Object>> getChoseiList() {
        return choseiList;
    }
    
    public void setChoseiList(List<Map<String, Object>> choseiList) {
        this.choseiList = choseiList;
    }
    
    public String[] getCategoryCode() {
        return categoryCode;
    }

    public void setCategoryCode(String[] categoryCode) {
        this.categoryCode = categoryCode;
    }
    
    public String[] getCategoryKbn1() {
        return categoryKbn1;
    }

    public void setCategoryKbn1(String[] categoryKbn1) {
        this.categoryKbn1 = categoryKbn1;
    }
    
    public String[] getCategoryKbn2() {
        return categoryKbn2;
    }

    public void setCategoryKbn2(String[] categoryKbn2) {
        this.categoryKbn2 = categoryKbn2;
    }
    
    public String[] getCategoryName1() {
        return categoryName1;
    }

    public void setCategoryName1(String[] categoryName1) {
        this.categoryName1 = categoryName1;
    }
    
    public String[] getCategoryName2() {
        return categoryName2;
    }

    public void setCategoryName2(String[] categoryName2) {
        this.categoryName2 = categoryName2;
    }

    public String[] getCategorySeq() {
        return categorySeq;
    }

    public void setCategorySeq(String[] categorySeq) {
        this.categorySeq = categorySeq;
    }
    
    public String[] getDelFlg() {
        return delFlg;
    }

    public void setDelFlg(String[] delFlg) {
        this.delFlg = delFlg;
    }

    public String getDivisionCode() {
        return divisionCode;
    }

    public void setDivisionCode(String divisionCode) {
        this.divisionCode = divisionCode;
    }

    public Integer getDelLabelFlg() {
        return delLabelFlg;
    }

    public void setDelLabelFlg(Integer delLabelFlg) {
        this.delLabelFlg = delLabelFlg;
    }

    public String getProcId() {
        return procId;
    }

    public void setProcId(String procId) {
        this.procId = procId;
    }
    
    public String[] getListSaveFlg(){
        return listSaveFlg;
    }
    
    public void setListSaveFlg(String[] listSaveFlg){
        this.listSaveFlg = listSaveFlg;
    }
    
    public String getSalesClass(){
        return salesClass;
    }
    
    public void setSalesClass(String salesClass){
        this.salesClass = salesClass;
    }
    
    public List<SyuGeCategoryMapView> getCateList(){
        return cateList;
    }
    
    public void setCateList(List<SyuGeCategoryMapView> cateList){
        this.cateList = cateList;
    }
    
    public String[] getCreatedFlg(){
        return createdFlg;
    }
    
    public void setCreatedFlg(String[] flg){
        this.createdFlg = flg;
    }
    
   public String getCateListFlg(){
       return cateListFlg;
   }
   
   public void setCateListFlg(String cateListFlg){
       this.cateListFlg = cateListFlg;
   }
   
   public List<String> getCateChoiceList(){
       return cateChoiceList;
   }
   
   public void setCateChoiceList(List<String> cateChoiceList){
       this.cateChoiceList = cateChoiceList;
   }
   
   public String getChoiceName1(){
       return choiceName1;
   }
   
   public void setChoiceName1(String choiceName1){
       this.choiceName1 = choiceName1;
   }
   
   public String getChoiceName2(){
       return choiceName2;
   }
   
   public void setChoiceName2(String choiceName2){
       this.choiceName2 = choiceName2;
   }
   
   public String[] getBefCategoryName1(){
       return befCategoryName1;
   }
   
   public void setBefCategoryName1(String[] befCategoryName1){
       this.befCategoryName1 = befCategoryName1;
   }
   
   public String[] getBefCategoryName2(){
       return befCategoryName2;
   }
   
   public void setBefCategoryName2(String[] befCategoryName2){
       this.befCategoryName2 = befCategoryName2;
   }

}
