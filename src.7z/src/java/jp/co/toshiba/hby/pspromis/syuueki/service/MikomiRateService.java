/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package jp.co.toshiba.hby.pspromis.syuueki.service;

import java.io.UnsupportedEncodingException;
import java.math.BigDecimal;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.ResourceBundle;
import java.util.Set;
import javax.ejb.Stateless;
import javax.inject.Inject;
import javax.interceptor.Interceptors;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import jp.co.toshiba.hby.pspromis.common.exception.PspRunTimeExceotion;
import jp.co.toshiba.hby.pspromis.syuueki.bean.MikomiRateBean;
import jp.co.toshiba.hby.pspromis.syuueki.entity.SyuMikomiRateMst;
import jp.co.toshiba.hby.pspromis.syuueki.enums.Label;
import jp.co.toshiba.hby.pspromis.syuueki.facade.SyuGeBukenInfoTblFacade;
import jp.co.toshiba.hby.pspromis.syuueki.facade.SyuMikomiRateMstFacade;
import jp.co.toshiba.hby.pspromis.syuueki.interceptor.TranceInterceptor;
import jp.co.toshiba.hby.pspromis.syuueki.util.ConstantString;
import jp.co.toshiba.hby.pspromis.syuueki.util.LoginUserInfo;
import jp.co.toshiba.hby.pspromis.syuueki.util.Utils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * PS-Promis収益管理システム
 * 見込レートマスタマスタ詳細 Service
 * @author kitajima
 */
@Stateless
@Interceptors({TranceInterceptor.class})
public class MikomiRateService {

    /**
     * ロガー
     */
    public static final Logger logger = LoggerFactory.getLogger(MikomiRateService.class);

    @PersistenceContext(unitName = jp.co.toshiba.hby.pspromis.syuueki.util.ConstantString.syuuekiDataSourceName)
    private EntityManager em;

    /**
     * Injection loginUserInfo
     * (ユーザー情報(ユーザーid,名称,所属部課名)を格納したオブジェクト)
     */
    @Inject
    private LoginUserInfo loginUserInfo;
    /**
     * パラメータ格納クラスをinjection(CDI)<br>
     * InjectアノテーションよりAPサーバー(Glassfish)側で自動的にインスタンス作成(new)される。<br>
     */
    @Inject
    private MikomiRateBean mikomiRateBean;

    @Inject
    private SyuMikomiRateMstFacade syuMikomiRateMstFacade;
    
    @Inject
    private SyuGeBukenInfoTblFacade syuGeBukenInfoTblFacade;

    //@Inject
    //private JgrpMemberTblFacade jgrpMemberTblFacade;
    
    private final Integer rirekiId = 0;
    
    /**
     * ログイン者の部課コードを取得
     */
//    private String getLoginBukaCd() {
//        String deptCd = loginUserInfo.getDepartmentCd();
//        if (StringUtil.isEmpty(deptCd)) {
//            deptCd = jgrpMemberTblFacade.getBukaCd(loginUserInfo.getUserId());
//        }
//        return deptCd;
//    }
    
    /**
     * 見込レートマスタの該当データを取得
     */
//    public SyuMikomiRateMst getMikomiRateEntity(String type, String divisionCode, String mainOrderNo, String currencyCode) {
//        SyuMikomiRateMst entity = syuMikomiRateMstFacade.findPk(type, divisionCode, mainOrderNo, currencyCode);
//        return entity;
//    }

    /**
     * 保存 ビジネスロジック
     * @throws Exception
     */
    public void save() throws Exception {
        //Set<String> noMainOrderNo = new LinkedHashSet<>();
        
        Set<String> currencySet = new HashSet<>();
        Map<String, Object> condition = new HashMap<>();
        
        String[] indexs = mikomiRateBean.getListIndex();
        String   mrType = mikomiRateBean.getHidType();         // 検索条件 見込レート種類
        String   div    = mikomiRateBean.getHidDivisionCode(); // 検索条件 事業部

        condition.put("userId", this.loginUserInfo.getUserId());  
        condition.put("mikomiRateType", mrType);
        condition.put("divisionCode", div);
//        SyuMikomiRateMst mikomiRateEntity = syuMikomiRateMstFacade.getSyuMikomiRateMst(condition);
//        if (mikomiRateEntity != null) {
//            syuMikomiRateMstFacade.deleteMikomiRateMst(condition);
//        }
        
        // 前受金あり当期　or 前受金あり翌期
        String typeFlg = "ARI";
        // 前受金なし翌期以降 or 前受金なし当期（翌月以降　USD/EUR)
        if( "NASI_USD_EUR".equals(mrType) || "NASI_YOKUKI".equals(mrType) || "IPPAN_USD_EUR".equals(mrType) || "IPPAN_YOKUKI".equals(mrType) ){
            typeFlg = "NASI";
        }
        mikomiRateBean.setTypeFlg(typeFlg);
        
        int idx = 0;
        for (int i = 0; i < mikomiRateBean.getListCurrencyCode().length; i++) {
            String newFlg = mikomiRateBean.getTxtShinkiFlg()[i];
            
            // 削除データのindexを取得
            Integer delIndex = -1;
            if (indexs != null) {
                try {
                    delIndex = Integer.parseInt(indexs[idx]);
                } catch (java.lang.ArrayIndexOutOfBoundsException e){}
            }

            // データ登録値を設定
            condition.put("mainOrderNo", mikomiRateBean.getTxtMainOrderNo()[i]);
            condition.put("ankenName", mikomiRateBean.getTxtAnkenName()[i]);
            condition.put("currencyCode", mikomiRateBean.getSubCur()[i]);
            
            if (delIndex == i) {
                // [削除]選択されている場合、データ削除
                syuMikomiRateMstFacade.deleteMikomiRateMst(condition);
                idx++;

            } else {
                // 未更新の行はスルー
                if ("0".equals(mikomiRateBean.getTxtChangeFlg()[i])) {
                    continue;
                }

                // データのバリデーションチェック
                int errorFlg = validation(i, newFlg);
                if (errorFlg != 0) {
                    continue;
                }
                
                condition.put("mikomiRate", Utils.changeBigDecimal(mikomiRateBean.getTxtMikomiRate()[i]));

                // レートをSetに登録しておく
                currencySet.add(mikomiRateBean.getSubCur()[i]);

                // 処理対象の見込レートを更新
                int saveCount = syuMikomiRateMstFacade.updateMikomiRateMst(condition);
                if (saveCount == 0) {
                    // 更新対象が存在しない場合、新規登録
                    syuMikomiRateMstFacade.insertMikomiRateMst(condition);
                }

                // 収益物件TBLの再計算フラグを設定（前受金あり当期　or 前受金あり翌期　の場合）
                if ("ARI".equals(typeFlg)) {
                    updateAriMainOrderAnken(i);
                }
            }

        }

        // ここまででエラーが存在した場合は、ここまでの更新状態をrollbackするためにExceptionを発生させる
        Map<String, String> messageInfo = mikomiRateBean.getMessageInfo();
        if (messageInfo != null) {
            throw new PspRunTimeExceotion();
        }

        // 収益物件TBLの再計算フラグを設定（前受金あり当期　or 前受金あり翌期　の場合）
        // 売上基準:進行基準の場合のみ実行
        if (ConstantString.salesClassS.equals(mikomiRateBean.getRateSalesClass())) {
            if ("NASI".equals(typeFlg) && !currencySet.isEmpty()) {
                updateNasiMainOrderAnken(currencySet);
            }
        }

    }

    /**
     * バリデーションチェック
     * @param idx 対象行
     * @param newFlg 1=更新行 2=新規追加行
     * @return 0:エラー無 1:エラー有り
     */
    private int validation(int idx, String newFlg) throws UnsupportedEncodingException {
        int errorFlg = 0;
        byte[] buff;
        int errorFlgRate = 0;
        int lineNo = idx + 1;
        
        String lineLabel = getLineNoLabel(lineNo);
        
        // 代表注番の入力チェック
        if (StringUtils.isEmpty(mikomiRateBean.getTxtMainOrderNo()[idx])) {
            String message = StringUtils.replace(getValidationMessage("required"), "{0}", Label.getValue(Label.daihyoOrderNo));
            mikomiRateBean.setMessage("noOrderNo" + idx, lineLabel + message);
            errorFlg = 1;
        }
        
        // 代表注番のバイトチェック
        buff = Utils.getBytes(mikomiRateBean.getTxtMainOrderNo()[idx]);
        if (buff.length > 7) {
            String message = StringUtils.replace(getValidationMessage("byteOverError"), "{0}", Label.getValue(Label.daihyoOrderNo));
            message = StringUtils.replace(message, "{1}", "7");
            mikomiRateBean.setMessage("overOrderNo" + idx, lineLabel + message);
            errorFlg = 1;
        }

        // 案件名称の入力チェック
        if (StringUtils.isEmpty(mikomiRateBean.getTxtAnkenName()[idx])) {
            String message = StringUtils.replace(getValidationMessage("required"), "{0}", Label.getValue(Label.ankenName));
            mikomiRateBean.setMessage("noAnkenName" + idx, lineLabel + message);
            errorFlg = 1;
        }

        // 案件名称のバイトチェック
        buff = Utils.getBytes(mikomiRateBean.getTxtAnkenName()[idx]);
        if (buff.length > 256) {
            String message = StringUtils.replace(getValidationMessage("byteOverError"), "{0}", Label.getValue(Label.ankenName));
            message = StringUtils.replace(message, "{1}", "256");
            mikomiRateBean.setMessage("overAnkenName" + idx, lineLabel + message);
            errorFlg = 1;
        }

        // レートの入力チェック
        if (StringUtils.isEmpty(mikomiRateBean.getTxtMikomiRate()[idx])) {
            String message = StringUtils.replace(getValidationMessage("required"), "{0}", Label.getValue(Label.rate));
            mikomiRateBean.setMessage("noRate" + idx, lineLabel + message);
            errorFlg = 1;
            errorFlgRate = 1;
        }
        
        // レートの数値チェック
        if (!(Utils.isNumeric(mikomiRateBean.getTxtMikomiRate()[idx],false))) {
            String message = StringUtils.replace(getValidationMessage("integerError"), "{0}", Label.getValue(Label.rate));
            mikomiRateBean.setMessage("noNumRate" + idx, lineLabel + message);
            errorFlg = 1;
            errorFlgRate = 1;
        }
        
        // レートのバイトチェック
        if (errorFlgRate!=1) {
            BigDecimal bigdRate = Utils.changeBigDecimal(mikomiRateBean.getTxtMikomiRate()[idx]);
            String rateErrChk = "0";
            // 整数部の桁数が上限を超えてる場合
            if (bigdRate.precision() - bigdRate.scale() > 13) {
                rateErrChk = "1";
            // 小数点以下の桁数が上限を超えてる場合
            } else if (bigdRate.scale() > 7) {
                rateErrChk = "1";
            }
            if ("1".equals(rateErrChk)) {
                String message = StringUtils.replace(getValidationMessage("bigDecimalError"), "{0}", Label.getValue(Label.rate));
                message = StringUtils.replace(message, "{1}", "13");
                message = StringUtils.replace(message, "{2}", "7");
                mikomiRateBean.setMessage("overRate" + idx, lineLabel + message);
                errorFlg = 1;
            }
        }
        
        // 重複チェック(新規追加行のみ)
        if ("2".equals(newFlg)) {
            String mainOrderNo = mikomiRateBean.getTxtMainOrderNo()[idx];
            String curNo = mikomiRateBean.getSubCur()[idx];
            SyuMikomiRateMst entity = syuMikomiRateMstFacade.findPk(mikomiRateBean.getHidType(), mikomiRateBean.getHidDivisionCode(), mainOrderNo, curNo);
            if (entity != null) {
                if("ARI".equals(mikomiRateBean.getTypeFlg())){
                    String message = StringUtils.replace(getValidationMessage("rateKeyErrorMaeukeAri"), "{0}", mainOrderNo + "," + curNo);
                    mikomiRateBean.setMessage("pkError_" + mainOrderNo + "_" + curNo + idx, lineLabel + message);
                }else{
                    String message = StringUtils.replace(getValidationMessage("rateKeyErrorMaeukeNashi"), "{0}", curNo);
                    mikomiRateBean.setMessage("pkError_" + curNo + idx, lineLabel + message);
                }
                errorFlg = 1;
            }
        }
        
        return errorFlg;
    }

    /**
     * 見込レートに該当する案件に再計算FLGを立てる(前受金あり)
     * @param idx
     * @return 
     */
    private void updateAriMainOrderAnken(int idx) {
        String mainOrderNo = mikomiRateBean.getTxtMainOrderNo()[idx];
        String div = mikomiRateBean.getHidDivisionCode();
        String currencyCode[] = new String[1];
        currencyCode[0] = mikomiRateBean.getSubCur()[idx];

        Map<String, Object> condition = new HashMap<>();
        condition.put("mainOrderNo", mainOrderNo);
        condition.put("rirekiId", this.rirekiId);
        condition.put("divisionCode", div);
        condition.put("userId", loginUserInfo.getUserId());
        condition.put("currencyCode", currencyCode);

        // 代表注番から案件を取得
        String ankenId = syuGeBukenInfoTblFacade.getMainOrderNoAnkenId(condition);
 
        // 案件が取得できない場合はエラーメッセージを登録して処理を終了
        if (StringUtils.isEmpty(ankenId)) {
            String lineLabel = getLineNoLabel(idx + 1);
            String message = StringUtils.replace(getValidationMessage("noDataError"), "{0}", Label.getValue(Label.daihyoOrderNo));
            mikomiRateBean.setMessage("noMainOrderNo" + idx, lineLabel + message);
            return;
        }

        // 取得した案件の再計算FLGをセット
        condition.put("ankenId", ankenId);
        syuGeBukenInfoTblFacade.setSaikeisanFlgMikomiRate(condition);
    }
    
    /**
     * 見込レートに該当する案件に再計算FLGを立てる([前受金なし]に該当する全案件に対して行う)
     * @return 
     */
    private void updateNasiMainOrderAnken(Set<String> currencySet) {
        String div = mikomiRateBean.getHidDivisionCode();

        Map<String, Object> condition = new HashMap<>();
        condition.put("userId", loginUserInfo.getUserId());
        condition.put("rirekiId", this.rirekiId);
        condition.put("divisionCode", div);
        condition.put("typeFlg", "NASHI");
        condition.put("currencyCode", currencySet.toArray());

        syuGeBukenInfoTblFacade.setSaikeisanFlgMikomiRate(condition);
    }

//    private void setNoMainOrderNoMessage(Set<String> noMainOrderNo) {
//        String message = StringUtils.replace(getValidationMessage("noDataError"), "{0}", Label.getValue(Label.daihyoOrderNo));
//        String orderNoLabel = "";
//        
//        Iterator<String> ite = noMainOrderNo.iterator();
//        while(ite.hasNext()) {
//            String val = ite.next();
//            if (StringUtils.isEmpty(orderNoLabel)) {
//                orderNoLabel = val;
//            } else {
//                orderNoLabel = orderNoLabel + "," + val;
//            }
//        }
//        
//        orderNoLabel = "(" + orderNoLabel + ")";
//        message = StringUtils.replace(message, "{1}", orderNoLabel);
//        mikomiRateBean.setMessage("noMainOrderNo", message);
//    }
    
    /**
     * 行数ラベルを取得
     */
    private String getLineNoLabel(int lineNo) {
        return "(" + lineNo + ")行目：";
    }

    /**
     * リソースからvalidationメッセージを取得
     * @param key
     * @return
     */
    private String getValidationMessage(String key) {
        ResourceBundle rb = ResourceBundle.getBundle("ValidationMessages");
        String value= rb.getString(key);
        return value;
    }

}
