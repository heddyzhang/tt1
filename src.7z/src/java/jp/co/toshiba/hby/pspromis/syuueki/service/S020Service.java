package jp.co.toshiba.hby.pspromis.syuueki.service;

import java.util.List;
import java.util.HashMap;
import java.util.Map;
import javax.ejb.Stateless;
import javax.inject.Inject;
import javax.interceptor.Interceptors;
import jp.co.toshiba.hby.pspromis.syuueki.bean.S020Bean;
import jp.co.toshiba.hby.pspromis.syuueki.bean.ValidationMessageBean;
import jp.co.toshiba.hby.pspromis.syuueki.entity.OperationLog;
import jp.co.toshiba.hby.pspromis.syuueki.entity.SyuGeBukkenInfoTbl;
import jp.co.toshiba.hby.pspromis.syuueki.entity.SyuGeNetItemTbl;
import jp.co.toshiba.hby.pspromis.syuueki.entity.SyuKiNetCateTitleTbl;
import jp.co.toshiba.hby.pspromis.syuueki.enums.Label;
import jp.co.toshiba.hby.pspromis.syuueki.enums.ValidatorMessage;
import jp.co.toshiba.hby.pspromis.syuueki.dto.NuclearRenkeiDispBatchDto;
import jp.co.toshiba.hby.pspromis.syuueki.facade.SyuGeBukenInfoTblFacade;
import jp.co.toshiba.hby.pspromis.syuueki.facade.SyuGeNetItemTblViewFacade;
import jp.co.toshiba.hby.pspromis.syuueki.facade.SyuKiNetCateTitleTblFacade;
import jp.co.toshiba.hby.pspromis.syuueki.interceptor.TranceInterceptor;
import jp.co.toshiba.hby.pspromis.syuueki.util.ConstantString;
import jp.co.toshiba.hby.pspromis.syuueki.util.EntityUtils;
import jp.co.toshiba.hby.pspromis.syuueki.util.LoginUserInfo;
import jp.co.toshiba.hby.pspromis.syuueki.util.SyuuekiUtils;
import jp.co.toshiba.hby.pspromis.syuueki.util.ValidationUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
/**
 * ES-Promis収益管理システム
 * 見込項番作成 Service
 * @author 
 */
@Stateless
@Interceptors({TranceInterceptor.class})
public class S020Service {

    public static final Logger log = LoggerFactory.getLogger(S020Service.class);

    @Inject
    private S020Bean s020Bean;

    @Inject
    private ValidationMessageBean validationMessageBean;
    
    @Inject
    private SyuGeBukenInfoTblFacade syuGeBukenInfoTblFacade;

    @Inject
    private SyuGeNetItemTblViewFacade syuGeNetItemTblViewFacade;
    
    @Inject
    private SyuKiNetCateTitleTblFacade syuKiNetCateTitleTblFacade;
    
    @Inject
    private LoginUserInfo loginUserInfo;

    @Inject
    private OperationLogService operationLogService;

    @Inject
    private StoredProceduresService storedProceduresService;
    
    /**
     * 初期表示時機能
     * @throws Exception
     */
    public void indexExecute() throws Exception {
        // 検索条件
        Map<String, Object> condition = getBaseCondition();

        // 注番、事業部取得
        // 対象案件をentityにセット
        SyuGeBukkenInfoTbl ankenEntity = syuGeBukenInfoTblFacade.findPk(condition);
        s020Bean.setOrderNo(StringUtils.defaultString(ankenEntity.getOrderNo()));
        s020Bean.setDivisionCode(StringUtils.defaultString(ankenEntity.getDivisionCode()));
        
        // カテゴリの一覧を検索
        findSelectList();
    }

    /**
     * 選択カテゴリ一覧の検索
     */
    private void findSelectList() {
            // 検索条件
        Map<String, Object> condition = getBaseCondition();

        // 一覧を検索
        List<SyuKiNetCateTitleTbl> list = syuKiNetCateTitleTblFacade.getSearchKobnCategory(condition);
        s020Bean.setDispSelectItemList(list);
    }
    
    /**
     * 共通の条件を作成して取得
     */
    private Map<String, Object> getBaseCondition() {
        Map<String, Object> condition = new HashMap<>();
        condition.put("ankenId", s020Bean.getAnkenId());
        condition.put("rirekiId", s020Bean.getRirekiId());
        return condition;
    }
    
    /**
     * 保存前のバリデーションチェック
     */
    public boolean validation() throws Exception {
        String message;
        String label;
        
        // 製番記号
        label = Label.seiban.getLabel();
// (2017/09/20)NPC 見込項番は製番記号のなしでも問題ないため、必須チェックをやめる(見積管理からの取込アイテムと統一)
//        if (StringUtils.isEmpty(s020Bean.getSeiban())) {
//            message = ValidatorMessage.REQUIRED.getMessae(label);
//            validationMessageBean.setErrorInfo("seiban", message);
//        }
//        //else if (!ValidationUtils.isHanStringCheck(s020Bean.getSeiban(), 5)) {
        String sbnKigo = StringUtils.defaultString(s020Bean.getSeiban()); 
        if (!ValidationUtils.isHanStringCheck(sbnKigo, 5)) {
            message = ValidatorMessage.BYTE_OVER_HAN_ONLY.getMessae(label, 5);
            validationMessageBean.setErrorInfo("seiban", message);
        }

        //半角英字チェック
// (2017/09/20)NPC 見込項番は製番記号のなしでも問題ないため、必須チェックをやめる(見積管理からの取込アイテムと統一)
        //}else if (StringUtils.isNotEmpty(sbnKigo) && !SyuuekiUtils.isAlphabetNumSpace(sbnKigo)) {
        //    message = ValidatorMessage.HBN_ERROR.getMessae(label);
        //    validationMessageBean.setErrorInfo("seiban", message);            
        //}

        // 項番
        label = Label.koban.getLabel();
        if (StringUtils.isEmpty(s020Bean.getOrderItem())) {
            message = ValidatorMessage.REQUIRED.getMessae(label);
            validationMessageBean.setErrorInfo("orderItem", message);
        }else if (!ValidationUtils.isHanStringCheck(s020Bean.getOrderItem(), 15)) {
            message = ValidatorMessage.BYTE_OVER_HAN_ONLY.getMessae(label, 15);
            validationMessageBean.setErrorInfo("orderItem", message);

        }
        //チェック追加フォーマットチェック
//(2017/09/20)NPC 見込項番は項番が厳密でなくても問題ないため、このチェックをやめる(見積管理からの取込アイテムと統一)
//        else if(!SyuuekiUtils.isformatKouban(s020Bean.getOrderItem())){
//            message = ValidatorMessage.FORM_ERROR.getMessae(label);
//            validationMessageBean.setErrorInfo("orderItem", message);  
//        }

        // 品名
        label = Label.hinmei.getLabel();
//(2017/09/20)NPC 見込項番は品名がNULLでも問題ないため、このチェックをやめる(見積管理からの取込アイテムと統一)
//        if (StringUtils.isEmpty(s020Bean.getHinmei())) {
//            message = ValidatorMessage.REQUIRED.getMessae(label);
//            validationMessageBean.setErrorInfo("hinmei", message);
//        //}else if (!ValidationUtils.isByteOver(s020Bean.getHinmei(), 256)) {        
        if (!ValidationUtils.isByteOver(s020Bean.getHinmei(), 256)) {
            message = ValidatorMessage.BYTE_OVER_HAN_ZEN.getMessae(label, 256, ValidationUtils.getZenCharCount(256));
            validationMessageBean.setErrorInfo("hinmei", message);
        }
        
        // (2017/08/30)カテゴリ1／カテゴリ2
        // 見込項番作成時点でもアイテムにカテゴリの紐付が必須((原子力)では紐づいていないと登録できない)のため、チェック追加
        label = Label.category.getLabel();
        if (StringUtils.isEmpty(s020Bean.getCategory())) {
            message = ValidatorMessage.REQUIRED.getMessae(label);
            validationMessageBean.setErrorInfo("category", message);
        }

        // 重複チェック
        SyuGeNetItemTbl entity = syuGeNetItemTblViewFacade.getDispKoban(
                            s020Bean.getAnkenId()
                          , s020Bean.getRirekiId()
                          , s020Bean.getOrderItem()
                          , ""
                    );
//        if(entity != null && !"".equals(entity.getOrderNo())){
        if (entity != null) {
            if (StringUtils.isNotEmpty(entity.getOrderItem())){
                message = Label.getValue(Label.errorKobanExists);
                validationMessageBean.setErrorInfo("orderItem", message);
            }
        }
        return validationMessageBean.isSuccess();
    }

    /**
     * 保存処理
     * @throws java.lang.Exception
     */
    public void saveExecute() throws Exception {
        log.info("parameter=[{}]", s020Bean.toString());
        
        // 見込項番作成処理
        createMikomiOrderItem();

        // 操作ログの登録
        registOperationLog();
        
        // （原子力）収益連携バッチをコール
        // (2017/11/22 連携バッチは自立型トランザクションになり、ここでCALLしても変更情報が反映されないようなので、S020Servletから直接呼ぶように修正)
        //callNuclearSysRenkeiDisp();
    }

    /**
     * 見込項番作成
     * @throws Exception
     */
    private void createMikomiOrderItem() {
        // 項目設定
        Map<String, Object> condition = getBaseCondition();

        // 注番が未発行の場合は半角スペース
        String orderNo = s020Bean.getOrderNo();
        if (StringUtils.isEmpty(s020Bean.getOrderNo())) {
            orderNo = " ";
        }

        condition.put("orderNo", orderNo);
        condition.put("seiban", s020Bean.getSeiban());
        condition.put("orderItem", s020Bean.getOrderItem());
        condition.put("hinmei", s020Bean.getHinmei());
        condition.put("kiCategoryCode", s020Bean.getCategory());
        condition.put("saCategoryCode", s020Bean.getCategory());       
        condition.put("mikomiFlg", "1");
        condition.put("netKakuteiFlg", "0");
        condition.put("kariNetFlg", "0");
        
        // 2018/01/18 (NPC)S.Ibayashi
        // 進行基準案件の場合、進行基準まとめ用のカテゴリも設定する。
        // このカテゴリは、進行基準まとめ案件から検索したときの条件：最終カテゴリ,期間カテゴリとマッチさせる。
        condition.put("shinkoCategoryUpdateFlg", "0");
        String salesClass = syuGeBukenInfoTblFacade.getSalesClass(s020Bean.getAnkenId(), s020Bean.getRirekiId());
        if (ConstantString.salesClassS.equals(salesClass)) {
            condition.put("shinkoCategoryUpdateFlg", "1");
        }
        
        EntityUtils.setCreatedInfo(condition, loginUserInfo.getUserId());

        // 更新処理
        syuGeNetItemTblViewFacade.insertMikomiKobn(condition);
    }

    /**
     * 操作ログの登録
     * @throws Exception
     */
    private void registOperationLog() throws Exception{
        OperationLog operationLog = operationLogService.getOperationLog();

//        String objectType = operationLogService.getObjectType(s016Bean.getProcId());
        String objectType = operationLogService.getObjectType("S005");
        
        operationLog.setOperationCode("ADD_KOUBAN");
        operationLog.setObjectId(20);
        operationLog.setObjectType(objectType);
        operationLog.setRemarks(s020Bean.getAnkenId()); // 備考1(引数.物件Key)
        operationLog.setRemarks2(s020Bean.getOrderItem()); // 備考2(項番)

        operationLogService.insertOperationLogSearch(operationLog);
    }

   /**
     * （原子力）収益連携バッチをCallする
     */
    public void callNuclearSysRenkeiDisp() throws Exception {
        String dispKbn = "ADD_KOUBAN";
        NuclearRenkeiDispBatchDto dto = new NuclearRenkeiDispBatchDto();
        dto.setAnkenId(s020Bean.getAnkenId());
        dto.setRirekiId(s020Bean.getRirekiId());
        dto.setDispKbn(dispKbn);
        
        storedProceduresService.callNuclearSysRenkeiDispBatch(dto);
        
        if (0 != dto.getStatus()) {
            String errorInfo = "ankenId=" + s020Bean.getAnkenId()
                    + " rirekiId=" + s020Bean.getRirekiId()
                    + " dispKbn=" + dispKbn;
                    
            throw new Exception("[SYU_N7_RENKEI_BATCH.PROC_DISP_CALL_MAIN]でエラーが発生しました。" + errorInfo);
        }
    }
    

}