package jp.co.toshiba.hby.pspromis.syuueki.facade;

import java.util.List;
import java.util.Map;
import java.util.HashMap;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.interceptor.Interceptors;
import jp.co.toshiba.hby.pspromis.syuueki.interceptor.TranceInterceptor;
import jp.co.toshiba.hby.pspromis.syuueki.entity.SyuZeikbnMst;
import org.apache.commons.collections.CollectionUtils;

/**
 *
 * @author ibayashi
 */
@Stateless
@Interceptors({TranceInterceptor.class})
public class SyuZeikbnMstFacade extends AbstractFacade<SyuZeikbnMst> {

    @PersistenceContext(unitName = jp.co.toshiba.hby.pspromis.syuueki.util.ConstantString.syuuekiDataSourceName)
    private EntityManager em;

    @Override
    protected EntityManager getEntityManager() {
        return em;
    }

    public SyuZeikbnMstFacade() {
        super(SyuZeikbnMst.class);
    }
    
    public SyuZeikbnMst findZeiKbnMst(Map<String, Object> condition) {
        List<SyuZeikbnMst> list
                = sqlExecutor.getResultList(em, SyuZeikbnMst.class, "/sql/syuZeikbnMst/selectSyuZeikbnMstList.sql", condition);
        
        SyuZeikbnMst entity = null;
        if (CollectionUtils.isNotEmpty(list)) {
            entity = list.get(0);
        }
        
        return entity;
    }
    
    /**
     * デフォルトの税区分データを取得
     * @return 
     */
    public SyuZeikbnMst findDefaultZeiKbnMst() {
        Map<String, Object> condition = new HashMap<>();
        condition.put("defaultFlg", "1");
        
        return findZeiKbnMst(condition);
    }

    /**
     * 指定した税区分のデータを取得
     * @param zeiKbn
     * @return 
     */
    public SyuZeikbnMst findPkZeiKbnMst(String zeiKbn) {
        Map<String, Object> condition = new HashMap<>();
        condition.put("zeiKbn", zeiKbn);
        
        return findZeiKbnMst(condition);
    }
    
   /**
     * 税区分の一覧データを取得
     * @return 
     */
    public List<SyuZeikbnMst> findAll(){
        List<SyuZeikbnMst> list
                = sqlExecutor.getResultList(em, SyuZeikbnMst.class, "/sql/syuZeikbnMst/selectSyuZeikbnMstList.sql", null);
        
        return list;
    }
}
