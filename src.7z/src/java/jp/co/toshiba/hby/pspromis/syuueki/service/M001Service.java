package jp.co.toshiba.hby.pspromis.syuueki.service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.inject.Inject;
import javax.interceptor.Interceptors;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import jp.co.toshiba.hby.pspromis.common.util.StringUtil;
import jp.co.toshiba.hby.pspromis.syuueki.bean.M001Bean;
import jp.co.toshiba.hby.pspromis.syuueki.entity.PlantTypeMst;
import jp.co.toshiba.hby.pspromis.syuueki.entity.SyuPatternItemMst;
import jp.co.toshiba.hby.pspromis.syuueki.entity.SyuPatternMst;
import jp.co.toshiba.hby.pspromis.syuueki.facade.BuMstFacade;
import jp.co.toshiba.hby.pspromis.syuueki.facade.JgrpMemberTblFacade;
import jp.co.toshiba.hby.pspromis.syuueki.facade.M001Facade;
import jp.co.toshiba.hby.pspromis.syuueki.facade.PlantTypeMstFacade;
import jp.co.toshiba.hby.pspromis.syuueki.facade.SyuPatternItemMstFacade;
import jp.co.toshiba.hby.pspromis.syuueki.facade.SyuPatternMstFacade;
import jp.co.toshiba.hby.pspromis.syuueki.interceptor.TranceInterceptor;
import jp.co.toshiba.hby.pspromis.syuueki.util.LoginUserInfo;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
/**
 * PS-Promis収益管理システム
 * 注入パターンマスタ詳細 Service
 * @author kitajima
 */
@Stateless
@Interceptors({TranceInterceptor.class})
public class M001Service {

    /**
     * ロガー
     */
    public static final Logger logger = LoggerFactory.getLogger(M001Service.class);

    @PersistenceContext(unitName = jp.co.toshiba.hby.pspromis.syuueki.util.ConstantString.syuuekiDataSourceName)
    private EntityManager em;

    /**
     * Injection loginUserInfo
     * (ユーザー情報(ユーザーid,名称,所属部課名)を格納したオブジェクト)
     */
    @Inject
    private LoginUserInfo loginUserInfo;
    /**
     * パラメータ格納クラスをinjection(CDI)<br>
     * InjectアノテーションよりAPサーバー(Glassfish)側で自動的にインスタンス作成(new)される。<br>
     */
    @Inject
    private M001Bean m001Bean;

    @Inject
    private SyuPatternMstFacade syuPatternMstFacade;

    @Inject
    private SyuPatternItemMstFacade syuPatternItemMstFacade;
    
    @Inject
    private JgrpMemberTblFacade jgrpMemberTblFacade;
    
    @Inject
    private PlantTypeMstFacade plantTypeMstFacade;
    
    @Inject
    private BuMstFacade buMstFacade;
    
    @Inject
    private M001Facade m001Facade;

    /**
     * ログイン者の部課コードを取得
     */
    private String getLoginBukaCd() {
        String deptCd = loginUserInfo.getDepartmentCd();
        if (StringUtil.isEmpty(deptCd)) {
            deptCd = jgrpMemberTblFacade.getBukaCd(loginUserInfo.getUserId());
        }
        return deptCd;
    }

    /**
     * 初期表示 ビジネスロジック
     * @throws Exception 
     */
    @TransactionAttribute(TransactionAttributeType.NOT_SUPPORTED)
    public void indexExecute() throws Exception {
        // 検索条件をセット
        Map<String, Object> condition = new HashMap<>();
        
        // ログイン者所属事業部コード
        m001Bean.setLoginDivisionCode(loginUserInfo.getJobGrSyokusyuArrayInfo("division"));

        SyuPatternMst syuPatternMst = null;
        
        if ("1".equals(m001Bean.getOpenMode())) {
            // 新規登録
            m001Bean.setDivisionCode(loginUserInfo.getPriorityDivCode());
        
        } else {
            condition.put("chunyuPtnNo", m001Bean.getChunyuPtnNo());

            syuPatternMst = syuPatternMstFacade.getPatternMst(condition);
            SyuPatternItemMst syuPatternItemMst = syuPatternItemMstFacade.getPatternItemMst(condition);

            // 注入パターンマスタ取得
            m001Bean.setSyuPatternMst(syuPatternMst);
            // 注入パターンマスタ内訳取得
            m001Bean.setSyuPatternItemMst(syuPatternItemMst);

            if ("3".equals(m001Bean.getOpenMode())) {
                ////////// 複写作成 ///////////////
                // 注入パターンマスタ取得
                m001Bean.setSyuPatternMstCopy(syuPatternMstFacade.getPatternMst(condition));
                // 注入パターンマスタ内訳取得
                m001Bean.setSyuPatternItemMstCopy(syuPatternItemMst);

                m001Bean.setCopyChunyuPtnNo(m001Bean.getChunyuPtnNo());
                
                // 新規作成のため、元の注入パターン番号は空にしておく(保存時に発番されるようにしておく)。
                m001Bean.getSyuPatternMst().setChunyuPtnNo(null);
                // 複写元が[マスタ]でも、オンラインで作成するため[作成]に強制変換する。
                m001Bean.getSyuPatternMst().setStandardPtnFlg(null);

            } else {
                ////////// 更新処理 ///////////////
                // 複写元注入パターンが存在すれば、それを取得
                String sourcePtnNo = syuPatternMst.getSourceChunyuPtnNo();
                sourceData(sourcePtnNo);
            }

            m001Bean.setDivisionCode(syuPatternMst.getDivisionCode());
        }

        // BUマスタの選択候補を取得
        m001Bean.setBuMstList(buMstFacade.findAll());
        // プラント種別マスタの選択候補を取得
        if (syuPatternMst != null) {
            setPlantTypeMstData(syuPatternMst.getSubBuId());
        }
        //m001Bean.setPlantTypeMstList(plantTypeMstFacade.getPlantTypeMstList(null));
    }
    
    /**
     * プラント種別マスタの取得 ビジネスロジック
     */
    public void plantTypeMstExecute() throws Exception {
        String sbuCode = m001Bean.getSubBu();
        setPlantTypeMstData(sbuCode);
    }

    /**
     * プラント種別マスタデータ取得
     */
    private void setPlantTypeMstData(String sbuCode) {
        // プラント種別マスタ
        Map<String, Object> condition = new HashMap<>();
        String[] conditionSbuCode = {sbuCode};
        if (StringUtils.isEmpty(sbuCode)) {
            conditionSbuCode = new String[1];
            conditionSbuCode[0] = "@@@@";
        }
        condition.put("sbuCode", conditionSbuCode);
        List<PlantTypeMst> plantTypeList = plantTypeMstFacade.getPlantTypeMstList(condition);
        m001Bean.setPlantTypeMstList(plantTypeList);
    }

    /**
     * 複写元のデータを取得
     */
    private void sourceData(String sourcePtnNo) throws Exception {
        if (StringUtil.isEmpty(sourcePtnNo)) {
            return;
        }
        
        // 検索条件をセット
        Map<String, Object> condition = new HashMap<>();
        condition.put("chunyuPtnNo", sourcePtnNo);

        SyuPatternMst syuPatternMst = syuPatternMstFacade.getPatternMst(condition);
        SyuPatternItemMst syuPatternItemMst = syuPatternItemMstFacade.getPatternItemMst(condition);
     
        m001Bean.setSyuPatternMstCopy(syuPatternMst);
        m001Bean.setSyuPatternItemMstCopy(syuPatternItemMst);
        m001Bean.setCopyChunyuPtnNo(sourcePtnNo);
    }

    /**
     * 登録処理 ビジネスロジック
     * @throws Exception 
     */
    public void save() throws Exception {
        Map<String, Object> condition = new HashMap<>();
        String deptCd = getLoginBukaCd();

        condition.put("chunyuPtnNo", m001Bean.getChunyuPtnNo());
        condition.put("chunyuPtnName", m001Bean.getPatternName());
        condition.put("subBu", m001Bean.getSubBu());
        condition.put("division", m001Bean.getDivisionCode());
        condition.put("plantTypeCode", m001Bean.getPlantType());
        condition.put("userId", loginUserInfo.getUserId());
        condition.put("divCode", deptCd);
        condition.put("infusionRate10", m001Bean.getInfusionRate10());
        condition.put("infusionRate20", m001Bean.getInfusionRate20());
        condition.put("infusionRate30", m001Bean.getInfusionRate30());
        condition.put("infusionRate40", m001Bean.getInfusionRate40());
        condition.put("infusionRate50", m001Bean.getInfusionRate50());
        condition.put("infusionRate60", m001Bean.getInfusionRate60());
        condition.put("infusionRate70", m001Bean.getInfusionRate70());
        condition.put("infusionRate80", m001Bean.getInfusionRate80());
        condition.put("infusionRate90", m001Bean.getInfusionRate90());
        condition.put("infusionRate100", m001Bean.getInfusionRate100());

        // 複写での新規登録の場合
        if (StringUtil.isNotEmpty(m001Bean.getSourceChunyuPtnNo())) {
            condition.put("sourceChunyuPtnNo", m001Bean.getSourceChunyuPtnNo());
        }
        
        // 新規登録の注入パターン番号を取得
        if (StringUtils.isEmpty((String)condition.get("chunyuPtnNo"))) {
            m001Bean.setChunyuPtnNo(syuPatternMstFacade.seqCyunyuPtnNo(condition));
            condition.put("chunyuPtnNo", m001Bean.getChunyuPtnNo());
        }

        // 編集
        editPatternMst(condition);
        editPatteItemMst(condition);
    }
    
    /**
     * 編集処理(注入パターンマスタ)
     */
    private void editPatternMst(Map<String, Object> data) {
        // 対象データの更新
        int count = m001Facade.updatePatternMst(data);
        if (count == 0) {
            m001Facade.insertPatternMst(data);
        }
        
        // 複写先の注入パターン名を更新
        m001Facade.updateCopyPatternMst(data);
    }
    
    /**
     * 編集処理(注入パターンitemマスタ)
     */
    private void editPatteItemMst(Map<String, Object> data) {
        // 対象データの更新
        int count = m001Facade.updatePatternItemMst(data);
        if (count == 0) {
            m001Facade.insertPatternItemMst(data);
        }
    }
    
    /**
     * 注入パターン使用済チェック
     * @return true:使用済 false:未使用
     * @throws java.lang.Exception
     */
    public boolean checkPatten() throws Exception {
        int count = m001Facade.findUserdPatternCount(m001Bean.getChunyuPtnNo());
        if (count > 0) {
            return true;
        } else {
            return false;
        }
    }
    
    /**
     * 削除 ビジネスロジック
     * @throws Exception
     */
    public void delete() throws Exception {
        Map<String, Object> condition = new HashMap<>();
        condition.put("chunyuPtnNo", m001Bean.getChunyuPtnNo());
        
        // 注入パターンマスタと注入パターンマスタ内訳を削除
        m001Facade.deletePatternMst(condition);
        m001Facade.deletePatternItemMst(condition);
    }

    /**
     * マスタ参照ダウンロードファイル取得
     * @throws Exception
     */
    public void masterDownloadFile() throws Exception {
        Map<String, Object> condition = new HashMap<>();
        condition.put("chunyuPtnNo", m001Bean.getChunyuPtnNo());
        
        SyuPatternMst syuPatternMst = syuPatternMstFacade.getPatternMst(condition);
        m001Bean.setSyuPatternMst(syuPatternMst);
    }

    
}