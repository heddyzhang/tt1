package jp.co.toshiba.hby.pspromis.syuueki.bean;

import javax.enterprise.context.RequestScoped;
import javax.inject.Named;

/**
 *
 * @author ibayashi
 */
@Named(value = "takeAnkenInfoBean")
@RequestScoped
public class TakeAnkenInfoBean {
    
    /**
     * 物件Key(複数指定の可能性あ)
     */
    private String[] ankenId;
    
    /**
     * 履歴Key(複数指定の可能性あり)
     */
    private String[] rirekiId;

    /**
     * 実行対象の機能id(S001:案件一覧 S003:期間損益(一般))
     */
    private String procId;
    
    /**
     * 区分(H:発番見合 C:中計取込)
     */
    private String kbn;
    
    public String[] getAnkenId() {
        return ankenId;
    }

    public void setAnkenId(String[] ankenId) {
        this.ankenId = ankenId;
    }

    public String[] getRirekiId() {
        return rirekiId;
    }

    public void setRirekiId(String[] rirekiId) {
        this.rirekiId = rirekiId;
    }

    public String getProcId() {
        return procId;
    }

    public void setProcId(String procId) {
        this.procId = procId;
    }

    public String getKbn() {
        return kbn;
    }

    public void setKbn(String kbn) {
        this.kbn = kbn;
    }

}
